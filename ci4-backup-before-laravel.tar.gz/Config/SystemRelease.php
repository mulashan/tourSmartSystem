<?php

namespace App\Config;

use CodeIgniter\Config\BaseConfig;

class SystemRelease extends BaseConfig
{
    public string $copyrightName = 'MHI';

    public string $copyrightUrl = 'http://microhealthinitiative.org';

    public array $releases = [
        [
            'version' => '2.0.16',
            'released_at' => '2026-03-20 01:21',
            'title' => 'System improvements and update awareness',
            'changes' => [
                'Added a footer that shows copyright information and the current system version.',
                'Added a system update notification so users can see what changed in the latest release.',
                'Improved release visibility with a detailed changelog modal and a view-all history section.',
            ],
        ],
    ];
}
