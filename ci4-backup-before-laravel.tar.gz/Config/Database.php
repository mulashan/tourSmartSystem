<?php

namespace Config;

use CodeIgniter\Database\Config;

/**
 * Database Configuration
 */
class Database extends Config
{
    /**
     * The directory that holds the Migrations
     * and Seeds directories.
     *
     * @var string
     */
    public $filesPath = APPPATH . 'Database' . DIRECTORY_SEPARATOR;

    /**
     * Lets you choose which connection group to
     * use if no other is specified.
     *
     * @var string
     */
    public $defaultGroup = 'default';

    /**
     * The default database connection.
     *
     * @var array
     */
    public $default = [
        'DSN'      => '',
        'hostname' => 'localhost',
         'username' => 'advamhwe_default_users',
        'password' => 'mhi@default!',
        'database' => 'advamhwe_default_db',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
    public $advamhwe_elimu_db = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_eget',
        'password' => 'mhi@eget!',
        'database' => 'advamhwe_elimu_db',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
     public $advamhwe_st_anne = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_anne',
        'password' => 'Anne32!',
        'database' => 'advamhwe_st_anne',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];

   public $advamhwe_minnesota_db = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_minnesota_user',
        'password' => 'minnesota32!',
        'database' => 'advamhwe_minnesota_db',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
      public $advamhwe_usariverseminary = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_usariver_user',
        'password' => 'mhi@usariver!',
        'database' => 'advamhwe_usariverseminary',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
     public $advamhwe_demo = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_demo_user',
        'password' => 'mhi@Demo1!',
        'database' => 'advamhwe_demo',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
     public $advamhwe_littleAcorns_db = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_littleAcorns_user',
        'password' => 'mhi@littleAcorns',
        'database' => 'advamhwe_littleAcorns_db',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
     public $advamhwe_guardian_angles_db = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_guardian_angles_user',
        'password' => 'mhi@guardianAngles',
        'database' => 'advamhwe_guardian_angles_db',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => false,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => true,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
    public $advamhwe_moshiAcademy_db = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_moshiAcademy_user',
        'password' => 'mhi@moshiAcademy',
        'database' => 'advamhwe_moshiAcademy_db',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
      public $advamhwe_nothernHighlands_db = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_nothernHighlands_user',
        'password' => 'mhi@nothernHighlands',
        'database' => 'advamhwe_nothernHighlands_db',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
     public $advamhwe_kilimanjaroSports_db = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_kilimanjaroSports_user',
        'password' => 'mhi@kilimanjaroSports',
        'database' => 'advamhwe_kilimanjaroSports_db',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
     public $advamhwe_springInstitute_db = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_springInstitute_user',
        'password' => 'mhi@springInstitute',
        'database' => 'advamhwe_springInstitute_db',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
     public $advamhwe_bridge = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_bridge_user',
        'password' => 'mhi@Bridge',
        'database' => 'advamhwe_bridge',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
       public $advamhwe_kilemaVTC_db = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_kilemaVTC_user',
        'password' => 'mhi@kilemaVTC',
        'database' => 'advamhwe_kilemaVTC_db',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
      public $advamhwe_kisarika_db = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_kisarika_user',
        'password' => 'mhi@Kisarika',
        'database' => 'advamhwe_kisarika_db',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
      public $advamhwe_kusiriye_db = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_kusiriye_user',
        'password' => 'mhi@Kusiriye',
        'database' => 'advamhwe_kusiriye_db',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    
    public $advamhwe_winners_db = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_winners_user',
        'password' => 'mhi@winners25',
        'database' => 'advamhwe_winners_db',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
        public $advamhwe_nkinga_referral_hospital = [
        'DSN'      => '',
        'hostname' => 'localhost',
        'username' => 'advamhwe_nkinga_referral',
        'password' => 'Adminmhi@2025',
        'database' => 'advamhwe_nkinga_referral_hospital',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => true,
        'DBDebug'  => (ENVIRONMENT !== 'production'),
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    /**
     * This database connection is used when
     * running PHPUnit database tests.
     *
     * @var array
     */
    public $tests = [
        'DSN'         => '',
        'hostname'    => '127.0.0.1',
        'username'    => '',
        'password'    => '',
        'database'    => ':memory:',
        'DBDriver'    => 'SQLite3',
        'DBPrefix'    => 'db_',  // Needed to ensure we're working correctly with prefixes live. DO NOT REMOVE FOR CI DEVS
        'pConnect'    => false,
        'DBDebug'     => (ENVIRONMENT !== 'production'),
        'charset'     => 'utf8',
        'DBCollat'    => 'utf8_general_ci',
        'swapPre'     => '',
        'encrypt'     => false,
        'compress'    => false,
        'strictOn'    => false,
        'failover'    => [],
        'port'        => 3306,
        'foreignKeys' => true,
    ];

    public function __construct()
    {
        parent::__construct();

        // Ensure that we always set the database group to 'tests' if
        // we are currently running an automated test suite, so that
        // we don't overwrite live data on accident.
        if (ENVIRONMENT === 'testing') {
            $this->defaultGroup = 'tests';
        }
    }
}
