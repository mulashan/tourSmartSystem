<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('HomeController');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'HomeController::index');
$routes->get('dashboard', 'HomeController::home');
$routes->post('dashboard_school_calendar_widget', 'HomeController::dashboard_school_calendar_widget');
$routes->get('dashboard_attendance_flag_list', 'CompanyController::dashboard_attendance_flag_list');
$routes->get('student', 'StudentController::student_registration');
$routes->get('employee', 'StaffController::staff');
$routes->get('admission', 'AdmissionController::student_admission');
$routes->get('payments', 'BillingController::invoice');
$routes->get('receipt', 'BillingController::receipt');
$routes->get('incomeStatements', 'ReportsController::reports');
$routes->get('transport', 'TransportController::transport');
$routes->get('accomodation', 'AccomodationController::accomodation');
$routes->get('transport_setup', 'TransportController::transport_setup');
$routes->get('accomodation_Edit', 'AccomodationController::editAcc');
$routes->get('user_Edit/(:num)/(:num)', 'UsersController::editUser/$1/$1');
$routes->get('profile_edit/(:num)', 'UsersController::profile_Edit/$1');
$routes->post('userEdit', 'UsersController::userEdit');

$routes->get('accomodation/(:num)', 'AccomodationController::editAcc/$1');


$routes->get('rooms', 'ClassController::classes');
$routes->get('applicaction', 'StudentController::student_application');
$routes->get('users', 'UsersController::users');
$routes->post('save_newUser', 'UsersController::add_new_users');
$routes->get('users_type', 'UsersController::users_type');

$routes->get('deleteUser/(:num)', 'UsersController::deleteUser/$1');
$routes->post('DeleteUser', 'UsersController::DeleteUserType');
$routes->post('UpdateUser', 'UsersController::UpdateUserType');

$routes->post('saveUserType', 'UsersController::saveUserType');
$routes->get('account', 'ItemsController::account');
$routes->post('add_Account', 'ItemsController::saveAccount');
$routes->get('getSingle_data', 'ItemsController::get_AccntData');
$routes->get('getSingle_data2', 'ItemsController::get_AccntData2');

$routes->post('editAccomodationHostel', 'AccomodationController::update_accomodation_hostel');
$routes->post('editAccomodationItems', 'AccomodationController::update_accomodation_item');
$routes->post('editLevelItems', 'ClassController::update_level_item');


$routes->post('updateData', 'ItemsController::update_account');
$routes->get('delete/(:num)', 'ItemsController::delete/$1');
$routes->get('deleteAcc/(:num)', 'AccomodationController::deleteAcc/$1');
$routes->get('deletehostelItem/(:num)', 'AccomodationController::deletehostelItem/$1');
$routes->get('deletelevelItem/(:num)', 'ClassController::deletelevelItem/$1');

$routes->get('item', 'ItemsController::items');
$routes->get('schoolTerms', 'SemisterController::semister');
$routes->get('login', 'Login::index');
$routes->get('Levels', 'ClassController::clss_level');
$routes->post('sub_accnt', 'ItemsController::get_SubAccount');
$routes->post('addItem', 'ItemsController::Create_Item');
$routes->get('edit_item', 'ItemsController::Update_Item');
$routes->get('view_item', 'ItemsController::view_Item');
$routes->post('updte_item', 'ItemsController::update_items_details');

// $routes->post('updte_item', 'ItemsController::update');
$routes->post('get_data', 'TransportController::load_item_data');
$routes->get('load_driver', 'TransportController::load_driver');
$routes->post('get_item_data', 'TransportController::load_item_data1');
$routes->post('get_item_selected', 'TransportController::get_item_selected');

$routes->post('item_data/(:num)', 'TransportController::load_item_dat/$1');
$routes->post('vehicle','TransportController::add_new_vehicle');
$routes->post('Update_vehicle_item','TransportController::update_vehicle');
$routes->post('Allvehicles','TransportController::getAllVehicles');
$routes->post('Update','TransportController::UpdateVehicle');
$routes->post('returnData','TransportController::load_items_data');
$routes->post('returnItemData','TransportController::load_item_data');
$routes->get('VehicleUpdate','TransportController::loadVehicleUpdate');
$routes->get('VehicleView','TransportController::ViewVehicleUpdate');
$routes->post('Delete','TransportController::DeleteVehicle');

$routes->get('DeleteVehicleItem/(:num)','TransportController::DeleteVehicleItem/$1');
$routes->post('updateItem','TransportController::update_items');

$routes->get('item_dlt/(:num)', 'ItemsController::deleteItem/$1');
$routes->post('load_data', 'ClassController::load_item_data');
$routes->post('load_datalv', 'ClassController::load_item_datalv');
$routes->post('load_accomodation', 'AccomodationController::load_accomodation_data');

$routes->post('load_Itemdata', 'ClassController::load_item_data1');
$routes->post('load_Itemdata2/(:num)', 'ClassController::load_item_data2/$1');
$routes->post('load_Accomodationdata1', 'AccomodationController::load_accomodation_data1');
$routes->post('load_Accomodationdata2/(:num)', 'AccomodationController::load_accomodation_data2/$1');
$routes->post('createLevel', 'ClassController::saveLevels');
$routes->get('class_View', 'ClassController::class_view');
$routes->get('classLevel_View', 'ClassController::classLevel_View');

$routes->post('createAccomodation', 'AccomodationController::saveAccomodation');

$routes->get('editLevel', 'ClassController::manage_Levels');
$routes->post('updateLvel', 'ClassController::UpdateLevel');
$routes->get('classLevel_dlt/(:num)', 'ClassController::remove_classLevel/$1');

$routes->post('new_Semister', 'ClassController::add_Semister');
$routes->get('editSchoolTerm', 'ClassController::manage_SchoolTerms_Details');
$routes->get('viewSchoolTerm', 'ClassController::view_SchoolTerms_Details');
$routes->post('save_Terms', 'ClassController::Update_SchoolTerms');
$routes->get('deleteterm/(:num)', 'ClassController::delete_schoolTerms/$1');

$routes->post('createNewClass', 'ClassController::Creating_newClass');
$routes->post('createStation', 'TransportController::createStation');
$routes->get('remove_class/(:num)', 'ClassController::Remove_class_details/$1');
$routes->get('edit_class', 'ClassController::manage_class_details');
$routes->post('addStream', 'ClassController::adding_stream_data');
$routes->post('addStation', 'ClassController::adding_station_data');
$routes->post('updateAccount', 'ClassController::updateAccount');
$routes->post('updateAccountstation', 'ClassController::updateAccountstation');
$routes->post('updateAccountLevel', 'ClassController::updateAccountLevel');
$routes->post('addinstallments/(:num)', 'ClassController::adding_installment_data/$1');
$routes->post('addinstallments2/(:num)', 'AccomodationController::adding_installment_data2/$1');
$routes->post('temporary', 'ClassController::adding_temporary_data');
$routes->post('temporaryaccomodation', 'AccomodationController::adding_temporary_data2');
$routes->get('fetchdata', 'ClassController::getting_stream_data');
$routes->get('fetchstationdata', 'ClassController::getting_station_data');
$routes->get('fetchstationrdata', 'TransportController::getting_station_data');
$routes->get('fetchinstallments', 'ClassController::getting_installments');
$routes->get('fetchinstallments2', 'AccomodationController::getting_installments2');
$routes->get('fetchinst', 'ClassController::getting_tempo');
$routes->get('fetchinst2', 'AccomodationController::getting_tempo2');
$routes->get('deleteStream/(:num)', 'ClassController::delete_stream_data/$1');
$routes->get('deleteStation/(:num)', 'ClassController::delete_station_data/$1');
$routes->get('deleteMents/(:num)', 'ClassController::delete_installment_data/$1');
$routes->post('update_class', 'ClassController::update_class_details');
$routes->post('update_session', 'TransportController::update_session_details');
$routes->get('fetch_Level_data', 'ClassController::getting_level_data');
$routes->post('add_anotherItem', 'ClassController::adding_another_items');
$routes->get('deleteChargdItem/(:num)', 'ClassController::remove_charged_item/$1');
$routes->get('fetch_classItems_data', 'ClassController::getting_class_chargeddItems');
$routes->get('fetch_clsItems_data', 'ClassController::get_class_chargeddItems');
$routes->get('fetch_station_data', 'ClassController::get_station_chargeddItems');
$routes->get('fetch_levelItems_data', 'ClassController::getting_level_chargeddItems');
$routes->get('fetch_lItems_data', 'ClassController::getting_level_Items');
$routes->post('add_class_Item', 'ClassController::add_Class_chargedItems');
$routes->post('add_station_Item', 'ClassController::add_station_chargedItems');
$routes->post('add_level_Item', 'ClassController::add_level_chargedItems');
$routes->get('delete_Class_ChargdItem/(:num)', 'ClassController::remove_Class_chargedItems/$1');
$routes->get('delete_station_ChargdItem/(:num)', 'ClassController::remove_station_chargedItems/$1');
$routes->get('delete_temp/(:num)', 'ClassController::remove_temp/$1');

$routes->post('createAccomodation', 'AccomodationController::saveAccomodation');


$routes->post('/validate', 'Login::users_login');
$routes->post('/save_student', 'StudentController::save_student_details');
$routes->post('/save_parent', 'StudentController::save_parent_details');
$routes->get('show_parent/(:num)/(:num)', 'StudentController::load_parent_details/$1/$2');
$routes->get('show_parent1/(:num)', 'StudentController::load_parent_details1/$1');
$routes->get('delete_parent/(:num)', 'StudentController::delete_parent_details/$1');
$routes->get('previous_school/(:num)', 'StudentController::show_previous_school/$1');
$routes->post('save_previous_school', 'StudentController::save_previous_school');
$routes->post('save_bill_info', 'StudentController::save_bill_info');
$routes->post('delete_item', 'StudentController::delete_item');
$routes->post('delete_item1', 'StudentController::delete_item1');
$routes->get('edit_student/(:num)', 'StudentController::edit_student_details/$1');
$routes->post('update_student', 'StudentController::update_student');
$routes->post('get_parent', 'StudentController::get_parent_details');
$routes->post('update_parent', 'StudentController::update_parent_details');
$routes->post('update_previous_school', 'StudentController::update_previous_school');
$routes->post('update_bill_info', 'StudentController::update_bill_info');

$routes->get('admission_details', 'AdmissionController::student_admission_details');
$routes->get('manage_transport_setup', 'TransportController::manage_transport_setup');
$routes->post('getStreamdta', 'AdmissionController::class_streams_details');
$routes->post('getSessiondta', 'AdmissionController::getSessiondta');
$routes->post('getStationdata', 'AdmissionController::getStationdata');
$routes->post('save_admission', 'AdmissionController::save_admission_details');
$routes->post('load_classRooms', 'AdmissionController::load_class_details');
$routes->post('close_academic_year', 'AdmissionController::close_academic_year');
$routes->get('fetch_hostelItems_data', 'AdmissionController::get_hostel_chargedItems');
$routes->get('fetch_vehicleItems_data', 'AdmissionController::get_transport_chargedItems');
$routes->get('view_admissions/(:num)', 'AdmissionController::view_admissions_details/$1');

$routes->post('save_application', 'StudentController::save_application');
$routes->get('get_application/(:num)', 'StudentController::get_application/$1');
$routes->post('class_list', 'StudentController::get_classes');
$routes->post('updat_application', 'StudentController::update_student_application');
$routes->get('view_invoice/(:num)/(:num)', 'BillingController::view_invoice_details/$1/$2');
$routes->get('invoice_details/(:num)/(:num)', 'BillingController::edit_invoice_details/$1/$2');
$routes->get('print_invoice/(:num)', 'BillingController::print_invoice_details/$1');
$routes->get('edit_application/(:num)', 'StudentController::edit_application/$1');
$routes->get('edit_user_type/(:num)', 'UsersController::edit_user_type/$1');
$routes->get('asssign_privileges/(:num)/(:num)', 'UsersController::asssign_privileges/$1/$1');
$routes->get('remove_privilege/(:num)/(:num)', 'UsersController::remove_privilege/$1/$1');
$routes->get('remove_usertype/(:num)', 'UsersController::remove_usertype/$1');
$routes->get('unassgnd_permissions/(:num)/(:any)', 'UsersController::unassgnd_permissions/$1/$2');
$routes->get('load_special_permissions/(:any)', 'UsersController::load_special_permissions/$1');
$routes->post('add_special_permissions', 'UsersController::add_special_permissions');
$routes->post('remove_special_permissions', 'UsersController::remove_special_permissions');
$routes->post('password_reset', 'UsersController::password_reset');
$routes->post('username_updator', 'UsersController::username_updator');
$routes->post('profileEdit', 'UsersController::profileEdit');
$routes->post('password_change', 'UsersController::password_change');
$routes->get('Logout', 'LogoutController::Logout');


$routes->post('request_control_number', 'StudentController::prepare_invoice');
$routes->post('check_payment', 'StudentController::check_payment');
$routes->post('receiverPayment', 'StudentController::receiverPayment_auto');
$routes->get('view_receipt/(:num)', 'BillingController::view_receipt_details/$1');
$routes->get('print_receipt/(:num)', 'BillingController::print_receipt_details/$1');
$routes->get('company', 'CompanyController::company');
$routes->post('createCompany', 'CompanyController::saveCompany');
$routes->get('edit_company/(:num)', 'CompanyController::edit_company_details/$1');
$routes->get('view_company/(:num)', 'CompanyController::view_company_details/$1');
$routes->post('editCompany', 'CompanyController::edit_Company');
$routes->get('deleteCompany/(:num)', 'CompanyController::delete_company/$1');
$routes->post('temporaryLevel', 'ClassController::adding_temporary_data3');
$routes->get('fetchinst3', 'ClassController::getting_tempo3');
$routes->post('addinstallments3/(:num)', 'ClassController::adding_installment_data3/$1');
$routes->get('fetchinstallments3', 'ClassController::getting_installments3');
// $routes->post('createLevel', 'ClassController::saveLevel');
$routes->post('temporaryTransport', 'TransportController::adding_temporary_data4');
$routes->get('fetchinst4', 'TransportController::getting_tempo4');
$routes->get('fetchinstallments4', 'TransportController::getting_installments4');
$routes->post('addinstallments4/(:num)', 'TransportController::adding_installment_data4/$1');
$routes->get('view_student', 'StudentController::view_student');
$routes->get('parent_info/(:num)', 'StudentController::parent_info/$1');
$routes->get('class_info/(:num)', 'StudentController::class_info/$1');
$routes->get('prev_school/(:num)', 'StudentController::prev_school/$1');
$routes->get('bill_address/(:num)', 'StudentController::bill_address/$1');
$routes->get('stu_transaction/(:num)', 'StudentController::stu_transaction/$1');
$routes->post('income_info', 'ReportsController::income_info');
$routes->get('getSingle_ledger', 'ReportsController::getSingle_ledger');
$routes->get('getSingle_ledgerapp', 'ReportsController::getSingle_ledgerapp');
$routes->post('generate_cashcollection_rpt', 'ReportsController::generate_cashcollection_rpt');
$routes->get('sales_classes', 'ReportsController::sales_by_classes');
$routes->post('sales_by_classes1', 'ReportsController::sales_by_classes1');
$routes->get('class_sales_report', 'ReportsController::class_sales_report');
$routes->get('collection_by_classes', 'ReportsController::collection_by_classes');
$routes->post('collection_by_classes1', 'ReportsController::collection_by_classes1');
$routes->get('student_collection_report', 'ReportsController::student_collection_report');
$routes->post('staff_report', 'StaffController::staff_report');
$routes->post('receipt2', 'BillingController::receipt2');
$routes->get('boarding_list', 'ReportsController::boarding_list');
$routes->post('boarding_list2', 'ReportsController::boarding_list2');
$routes->get('route_list', 'ReportsController::route_list');
$routes->get('class_list', 'ReportsController::class_list');
$routes->post('class_list2', 'ReportsController::class_list2');
$routes->post('route_list2', 'ReportsController::route_list2');

$routes->get('messages', 'SystemController::messages');
$routes->get('recharge', 'SystemController::messages_recharge');
$routes->get('school_calendar', 'SystemController::school_calendar');
$routes->post('load_school_calendar', 'SystemController::load_school_calendar');
$routes->post('save_school_calendar', 'SystemController::save_school_calendar');
$routes->post('view_school_calendar', 'SystemController::view_school_calendar');
$routes->post('edit_school_calendar', 'SystemController::edit_school_calendar');
$routes->post('update_school_calendar', 'SystemController::update_school_calendar');
$routes->post('delete_school_calendar', 'SystemController::delete_school_calendar');
$routes->post('send_school_calendar_now', 'SystemController::send_school_calendar_now');
$routes->post('school_calendar_sms_group', 'SystemController::school_calendar_sms_group');
$routes->post('school_calendar_sms_individual', 'SystemController::school_calendar_sms_individual');
$routes->post('school_calendar_sms_staff', 'SystemController::school_calendar_sms_staff');
$routes->post('new_deposit', 'SystemController::make_newDeposit');
$routes->post('load_messages', 'SystemController::load_messages_details');
$routes->get('pay_application/(:num)', 'BillingController::pay_application/$1');
$routes->get('attendance', 'ReportsController::attendance');
$routes->get('attendance_record', 'ReportsController::attendance_record');
$routes->get('get_student_list/(:num)/(:num)', 'ReportsController::get_student_list/$1/$2');
$routes->post('stream_list', 'ReportsController::stream_list');
$routes->post('save_attendance', 'ReportsController::save_attendance');
$routes->post('get_attendance_list_summary', 'ReportsController::get_attendance_list_summary');
$routes->post('get_attendance_record/(:num)/(:num)/(:any)/(:num)', 'ReportsController::get_attendance_record/$1/$2/$3/$4');
$routes->post('attendance_edit/(:num)', 'ReportsController::attendance_edit/$1');
$routes->post('edit_attendance', 'ReportsController::edit_attendance');
$routes->get('class_attendance_report', 'ReportsController::class_attendance_report');
$routes->post('get_attendance_report/(:num)/(:num)/(:any)/(:num)', 'ReportsController::get_attendance_report/$1/$2/$3/$4');

$routes->get('attendance_record_summary','ReportsController::attendance_record_summary');
$routes->post('get_attendance_summary', 'ReportsController::get_attendance_summary');
$routes->get('parent_attendance/(:num)', 'ReportsController::parent_attendance/$1');
$routes->get('load_routeList', 'TransportController::load_routeList');
$routes->get('new_transport', 'TransportController::new_transport');
$routes->post('save_route', 'TransportController::save_route');
$routes->post('save_vehicle', 'TransportController::save_vehicle');
$routes->post('save_route_vehicle', 'TransportController::save_route_vehicle');
$routes->get('load_vehicleList', 'TransportController::load_vehicleList');
$routes->get('load_vehicleRouteList', 'TransportController::load_vehicleRouteList');
$routes->get('edit_Route', 'TransportController::edit_Route');
$routes->get('view_Route', 'TransportController::view_Route');
$routes->get('edit_Vehicle', 'TransportController::edit_Vehicle');
$routes->get('edit_RouteVehicle', 'TransportController::edit_RouteVehicle');
$routes->get('view_RouteVehicle', 'TransportController::view_RouteVehicle');
$routes->post('save_edit_Route', 'TransportController::save_edit_Route');
$routes->post('save_edit_vehicle', 'TransportController::save_edit_Vehicle');
$routes->post('edit_RouteVehicleData', 'TransportController::edit_RouteVehicleData');
$routes->get('deleteroute/(:num)', 'TransportController::deleteroute/$1');
$routes->get('deletevehicle/(:num)', 'TransportController::delete_vehicle/$1');
$routes->get('deleteRouteVehicle/(:num)', 'TransportController::deleteRouteVehicle/$1');
$routes->get('fetch_stationItems_data', 'TransportController::getting_station_chargeddItems');
$routes->get('template', 'SystemController::messages_template');
$routes->post('save_invoice_created/(:num)', 'AdmissionController::save_newinvoice_transaction_items/$1');

$routes->get('parent', 'ParentController::parent');
$routes->get('view_parent/(:num)', 'ParentController::view_parent_info/$1');
$routes->get('applications_summary', 'StudentController::applications_summary');
$routes->get('admission_dash', 'AdmissionController::admission_dash');
$routes->get('student_dashboard', 'StudentController::student_dashboard');
$routes->get('parents_dashboard/(:num)', 'StudentController::parents_dashboard/$1');
$routes->get('transport_dashboard', 'TransportController::transport_dashboard');
$routes->get('boarding', 'StaffController::boarding_setup');
$routes->get('boarding_details', 'StaffController::boarding_details');
$routes->get('deposit', 'BillingController::deposit');
$routes->post('class_list_report', 'ReportsController::class_list_report');
$routes->get('edit_receipt/(:num)', 'BillingController::edit_receipt_details/$1');
$routes->get('credit_note', 'BillingController::credit_note');
$routes->get('view_note/(:num)', 'BillingController::view_note_details/$1');
$routes->get('print_note/(:num)', 'BillingController::print_note/$1');
$routes->get('credit_note_details/(:num)', 'BillingController::edit_credit_note_details/$1');
$routes->get('school_routes', 'ReportsController::school_route');
$routes->get('bank', 'BillingController::bank');
$routes->get('balance_sheet', 'ReportsController::balance_sheet');
$routes->get('aliens', 'StudentController::aliens_others');
$routes->post('save_others', 'StudentController::save_others');
$routes->get('application_report', 'ReportsController::application_report');
$routes->get('vehicle_report', 'ReportsController::vehicle_report');
$routes->get('pocket_money_list', 'ReportsController::pocket_money');
$routes->get('gratuations', 'AdmissionController::manage_gratuation');
$routes->get('absconds', 'AdmissionController::manage_absconds');
$routes->get('cash_transfer', 'SemisterController::cash_transfer');
$routes->get('refund', 'SemisterController::refund_back');
$routes->get('project_report', 'ReportsController::project_report');
$routes->get('projects', 'CompanyController::education_trip');
$routes->get('course_period', 'SemisterController::course_period');
$routes->get('pocket_money_bod', 'ReportsController::pocket_money_bod');
$routes->get('cash_bank_report', 'ReportsController::cash_bank_report');

$routes->get('student_absconds/(:num)', 'StaffController::student_absconds/$1');
$routes->get('student_graduants/(:num)', 'StaffController::student_graduants/$1');


//$routes->get('load_approval', 'BillController::Load_approvals_data');
//////////////////bill here////////////////////////////
$routes->post('load_accounts', 'BillController::load_accounts_data');
$routes->post('load_accountdata1', 'BillController::load_account_data');
$routes->post('load_payable', 'BillController::load_payable_data');
$routes->post('load_acc_payable', 'BillController::load_accounts_payable');
$routes->get('Billing', 'BillController::Billing');
$routes->post('save_bill', 'BillController::Save_Bill_details');
$routes->post('load_supplier', 'BillController::load_supplier_data');
$routes->get('get_bill_data', 'BillController::get_View_bill_data');
$routes->get('get_approval_data', 'BillController::get_View_approval_data');
////////////////////// suppliers here///////////////////////
$routes->get('suppliers', 'SupplierController::Suppliers');
$routes->get('get_supplier_data', 'SupplierController::get_supplier_info');
$routes->post('register_supplier', 'SupplierController::New_Supplier');
$routes->post('updatesupplierData', 'SupplierController::Save_suppl_data');
$routes->get('getSingle_supplier_data', 'SupplierController::getSingle_supplier_info');
$routes->get('getSingle_bill_data', 'BillController::getSingle_bill_data');
$routes->get('fetch_ledgers_bill', 'BillController::fetch_ledgers_bills');
$routes->get('BillController/displayImage/(:any)','BillController::displayImage/$1');
$routes->get('payment_voucher','BillController::Payment_Voucher');
$routes->get('send_approved_data','BillController::Approved_Data');
$routes->get('send_rejected', 'BillController::Send_Rejected_bill');
$routes->post('request_overdue_transport_delete', 'TransportController::request_overdue_transport_delete');
$routes->post('receiptdata','BillController::receiptdata');
$routes->post('billfilterdata','BillController::billfilterdata');
$routes->post('updt_bill','BillController::Update_Bill_info');
$routes->get('pay_voucher', 'BillController::pay_voucher');

$routes->get('not_show', 'AdmissionController::student_not_show');
$routes->get('transfered_students', 'AdmissionController::transfered_students');
$routes->get('student_transfered/(:num)', 'StaffController::student_transfered/$1');
$routes->get('student_noshow/(:num)', 'StaffController::student_noshow/$1');
$routes->get('reapproval', 'BillController::Load_approvals_data');

$routes->get('transfer', 'BillController::transfer');
//////////////////// Receipt Starts Here ////////////////////
$routes->get('class_list_Summary', 'ReportsController::class_list_Summary');
$routes->get('Logout2', 'LogoutController::Logout2');
$routes->get('student_admissions_dashboard/(:num)', 'AdmissionController::admission_dash/$1');

$routes->get('automatic_run/(:num)', 'CronjobsController::automatic_run/$1');
$routes->get('transport_massages/(:num)', 'CronjobsController::manage_transport_messages/$1');
$routes->get('school_calendar_messages/(:num)', 'CronjobsController::manage_school_calendar_messages/$1');

$routes->get('exportReceipt', 'BillingController::exportReceiptToExcel');
$routes->get('exportInvoice', 'BillingController::exportInvoiceToExcel');

$routes->get('reconciliation', 'BillController::reconciliation');

$routes->get('trial_balance', 'ReportsController::trial_balance');
$routes->get('view_trial_balance', 'ReportsController::view_trial_balance');
$routes->post('get_trial_balance', 'ReportsController::get_trial_balance');

$routes->get('account_receivable_report', 'ReportsController::receivable_report');
$routes->get('vfd_settings', 'SystemController::vfd_settings');

$routes->get('load_privacy', 'LogoutController::loaded_privacy');

$routes->get('transport_type', 'TransportController::transport_type');
$routes->get('today_collection', 'StaffController::today_collection');

$routes->get('whatsap_message', 'CronjobsController::whatsap_message');
$routes->post('whatsap_message', 'CronjobsController::receiveMessage');
$routes->get('chatMessages', 'CronjobsController::chatMessages');

$routes->get('opening_balances', 'BillController::opening_balances');
$routes->get('database', 'LogoutController::importTable');
$routes->get('exportDatabases', 'LogoutController::exportDatabases');
// =========================Exam route===============================
$routes->get('examination', 'AcademicController::view_exams');
$routes->post('saveExamination', 'AcademicController::saveExamination');
$routes->get('remove_exam/(:num)', 'AcademicController::remove_exam/$1');
$routes->post('update_exam', 'AcademicController::update_exam');
$routes->get('edit_examination', 'AcademicController::edit_examination/$1');
//<===================Exam route Ends==========================>
//<===================subject route starts==========================>
$routes->get('subject', 'AcademicController::view_subject');
$routes->post('save_Subject', 'AcademicController::save_Subject');
$routes->post('update_Subject', 'AcademicController::update_Subject');
$routes->get('remove_subject/(:num)', 'AcademicController::remove_subject/$1');
//<===================subject route Ends==========================>
//<===================character route starts==========================>
$routes->get('character', 'AcademicController::view_charcter');
$routes->post('save_character', 'AcademicController::save_character');
$routes->post('update_character', 'AcademicController::update_character');
$routes->get('remove_character/(:num)', 'AcademicController::remove_character/$1');
//<===================character route Ends==========================>
//<===================comb route starts==========================>
$routes->get('combination', 'AcademicController::view_combs');
$routes->post('save_comb', 'AcademicController::save_comb');
$routes->post('update_comb', 'AcademicController::update_comb');
$routes->get('remove_comb/(:num)', 'AcademicController::remove_comb/$1');
//<===================comb route Ends==========================>
//<===================comb route starts==========================>
$routes->get('grades', 'AcademicController::view_grades');
$routes->post('save_grade', 'AcademicController::save_grade');
$routes->post('update_grade', 'AcademicController::update_grade');
$routes->get('remove_grade/(:num)', 'AcademicController::remove_grade/$1');
$routes->get('get_combination_data', 'AcademicController::get_combinations_details');

//<===================comb route Ends==========================>

//<=============teacher subject route Starts=====================>
$routes->get('techers_subject', 'AcademicController::view_techer_subject');
$routes->post('allocate_teacher', 'AcademicController::save_teachers_allocation');
$routes->get('delete_allocation/(:num)', 'AcademicController::delete_allocation/$1');
$routes->get('allocation_Edit', 'AcademicController::editAllocation');
$routes->post('save_changes', 'AcademicController::Updateallocation');
$routes->post('ViewAllocation', 'AcademicController::ViewAllocation');
$routes->get('my_subject', 'AcademicController::ViewMySubjects');
//<===================teacher subject route Ends====================>
//<=============Class subject route Starts=====================>
$routes->get('Subject_class', 'AcademicController::manage_subjects_class');
$routes->post('allocation_details', 'AcademicController::Allocation_report');
 $routes->get('delete_stream_allocation/(:num)', 'AcademicController::remove_stream_allocation/$1');
$routes->post('Save_class_allocation', 'AcademicController::Save_class_allocation');
$routes->get('ViewCombSubjects', 'AcademicController::ViewCombSubjects');
$routes->get('stream_Edit', 'AcademicController::editStreamAllocation');
$routes->Post('savestream_Edit', 'AcademicController::UpdateStreamAllocation');
$routes->get('ViewStreamAllocation', 'AcademicController::ReadAllocation');
// $routes->get('my_subject', 'AcademicController::ViewMySubjects');
//<===================Class subject route Ends====================>
//<===================Exam results route Starts====================>
$routes->get('exam_results', 'ResultsController::view_results');
$routes->post('exam_report', 'ResultsController::exam_report');
$routes->post('list_terms', 'ResultsController::get_terms');
$routes->post('list_exams', 'ResultsController::get_exams');

//<===================Exam results route Ends====================>
//<===================Accademmic inputs route Starts====================>
$routes->get('fill_student_character', 'AcademicInputsController::view_charcters');
$routes->post('list_stream', 'AcademicInputsController::get_stream_by_class');
$routes->post('fetch_students', 'AcademicInputsController::get_students_ByStream');
$routes->post('fetch_students_Results', 'AcademicInputsController::get_students_ByStream_Results');
$routes->post('SaveCharacter', 'AcademicInputsController::SaveCharacter');
$routes->post('save_character_record', 'AcademicInputsController::save_yearly_record');
$routes->post('delete_character_record', 'AcademicInputsController::delete_yearly_record');
$routes->post('View_Character_List', 'AcademicInputsController::ViewcharctersList');
$routes->post('View_Stream_Character_List', 'AcademicInputsController::ViewStreamcharctersList');
$routes->get('fill_exam_results', 'AcademicInputsController::view_exam_results');
$routes->post('SaveExam', 'AcademicInputsController::SaveExamResult');
$routes->post('save_Monthly_record', 'AcademicInputsController::saveMonthly_yearly_record');
$routes->post('delete_Monthly_record', 'AcademicInputsController::delete_yearly_record');
//<===================Accademmic inputs route Ends====================>
//<===================Accademmic Outputs route Starts====================>
$routes->get('GeneralReport', 'AcademicOutputsController::ViewGeneralReports');
$routes->post('FetchGeneralReports', 'AcademicOutputsController::FetchGeneralReports');
$routes->post('FetchDetailedReports', 'AcademicOutputsController::FetchDetailedReports');
$routes->post('view_student_report', 'AcademicOutputsController::view_student_report');
$routes->post('search_name', 'AcademicOutputsController::fetch_search_byname');
$routes->get('Detailed_results', 'AcademicOutputsController::SubjectResultsDetailed');
$routes->get('top_10_students', 'AcademicOutputsController::top_10_students');
$routes->post('FetchTop10Reports', 'AcademicOutputsController::FetchTop10Reports');
$routes->post('SubjectWisePerformance', 'AcademicOutputsController::SubjectWisePerformance');
$routes->get('subject_performance', 'AcademicOutputsController::subject_performance');
$routes->get('examtype_results', 'AcademicOutputsController::examtype_results');
$routes->post('FetchExamTypeReport', 'AcademicOutputsController::FetchExamTypeReports');
//<===================Accademmic Output route Ends====================>
//<===================TEACHER ALLOCATION route STARTS====================>
$routes->post('ViewStreamSubjects', 'AcademicController::ViewStreamSubjects');
$routes->post('GetGradesTable', 'AcademicController::GetGradesTable');
$routes->post('GetCombTable', 'AcademicController::GetCombTable');
$routes->post('GetCombstreamDetails', 'AcademicController::get_combstream_details');
$routes->get('unassigned_subjects/(:any)/(:any)', 'AcademicController::load_unassigned_stream_subject');
$routes->get('assigned_subjects/(:any)', 'AcademicController::load_assigned_stream_subjects');
$routes->post('view_grade_updateform', 'AcademicController::view_grade_updateform');
$routes->post('load_unassigned_stream_subject', 'AcademicController::load_unassigned_stream_subject');
$routes->post('load_assigned_stream_subjects', 'AcademicController::load_assigned_stream_subjects');
$routes->get('allocate_teacher', 'AcademicController::save_teachers_allocation');
$routes->get('unallocate_teacher', 'AcademicController::remove_teachers_allocation');
$routes->post('allocate_all_teacher', 'AcademicController::add_all_teachers_allocation');
$routes->post('unallocate_all_teacher', 'AcademicController::remove_all_teachers_allocation');
$routes->post('Get_stream_list', 'AcademicController::get_stream_list');
$routes->post('Check_stream_alocation_status', 'AcademicController::stream_comb_allocation_status');

$routes->post('view_comb_updateform', 'AcademicController::view_comb_updateform');
$routes->post('view_comb_details', 'AcademicController::get_comb_details');
$routes->post('RefreshExamGrades', 'AcademicInputsController::RefreshExamGrades');
$routes->post('save_Exam_record', 'AcademicInputsController::SaveExam_yearly_record');
$routes->post('delete_Exam_record', 'AcademicInputsController::delete_Exam_yearly_record');
$routes->post('View_ExamResult_List', 'AcademicInputsController::View_ExamResult_List');
$routes->post('View_Exam_Result_List', 'AcademicInputsController::ViewExamResultsList');
$routes->get('load_class/(:any)', 'AcademicOutputsController::load_class/$1');
$routes->get('load_stream/(:any)', 'AcademicOutputsController::load_stream_data/$1');
$routes->post('view_Character_details', 'AcademicController::get_character_details');
$routes->get('classification', 'CompanyController::classification');
$routes->get('term_balance_report', 'ReportsController::term_balance_report');
$routes->get('school_fees_schedule', 'ReportsController::school_fees_schedule');
$routes->post('load_school_fees_schedule', 'ReportsController::load_school_fees_schedule');
$routes->get('public_school_fees_schedule', 'ReportsController::public_school_fees_schedule');
$routes->post('fetch_my_students_Results', 'AcademicInputsController::teacher_based_students_ByStream_Results');
$routes->post('SubmitExamResults', 'AcademicInputsController::SubmitExam_details');
$routes->post('update_Exam_results', 'AcademicInputsController::Allow_update_Exam_results');
$routes->get('others', 'StaffController::others');

$routes->get('school_departments', 'StaffController::school_departments');
$routes->get('job_tittle', 'StaffController::job_tittle');
$routes->get('salary_advance', 'StaffController::salary_advance');
$routes->post('academic-report', 'AcademicOutputsController::my_student_academic_report');
$routes->post('student-performance', 'AcademicOutputsController::StudentPerformance');
$routes->post('get-subject_position', 'AcademicOutputsController::CheckSubjectAverage');
$routes->get('edit-depertment/(:num)', 'StaffController::edit_depertment/$1');
$routes->post('update-depertment', 'StaffController::update_depertment');
$routes->get('view-depertment/(:num)', 'StaffController::view_depertment/$1');
$routes->get('edit-job_tittle/(:num)', 'StaffController::edit_job_tittle/$1');
$routes->post('update-job_tittle', 'StaffController::update_job_tittle');
$routes->post('delete-job_title', 'StaffController::delete_job_title');
$routes->post('delete-department', 'StaffController::delete_department');
$routes->get('view-job_tittle/(:num)', 'StaffController::view_job_tittle/$1');

$routes->get('detailed_term_balances', 'ReportsController::detailed_term_balances');
$routes->post('export-report', 'ReportsController::fetch_balance_detaialed_report');

$routes->get('payroll', 'StaffController::payroll');
$routes->post('add-payroll', 'StaffController::add_payroll');
$routes->post('pay-payroll', 'BillController::pay_payroll');
$routes->post('pay-goverment', 'BillController::pay_government_payroll');
$routes->post('pay-staff', 'BillController::pay_staff_payroll');
$routes->post('Get_comb_ByClass', 'AcademicController::GetAllCombByClassLevel');
$routes->post('Get-Details', 'StaffController::GetPaymentDetails');
$routes->post('get-search_staffs', 'BillController::search_staff_payroll');
$routes->get('get-salary_advances/(:num)/(:num)', 'BillController::salary_advances/$1/$2');
$routes->post('fetch_payroll_month', 'BillController::fetch_payroll_month');
$routes->post('save-advances', 'BillController::save_advances');
$routes->post('fetch-payroll-staff', 'StaffController::fetchPayrollStaff');
$routes->post('get_slip_data', 'BillController::get_slip_data');
$routes->get('slp/(:num)/(:num)/(:num)', 'LogoutController::salary_slip/$1/$2/$3');
$routes->get('net_salary_report', 'StaffController::payroll_reports');
$routes->post('get-net-report', 'StaffController::get_net_report');
$routes->get('paye_report', 'StaffController::get_paye_report');
$routes->post('get-paye-report', 'StaffController::paye_report');
$routes->get('wcf_report', 'StaffController::get_wcf_report');
$routes->post('get-wcf-report', 'StaffController::wcf_report');
$routes->get('nssf_report', 'StaffController::get_nssf_report');
$routes->post('get-nssf-report', 'StaffController::nssf_report');
$routes->post('nssfexport-excel', 'ReportsController::exportNSSFdata');
$routes->post('PAYEfexport-excel', 'ReportsController::exportPAYEdata');
$routes->post('WCFfexport-excel', 'ReportsController::exportWCFdata');
$routes->post('NETfexport-excel', 'ReportsController::exportNETdata');
$routes->post('delete_staff_details', 'StaffController::delete_staff');
$routes->post('get_grouped_data', 'StaffController::getGrouped');
$routes->get('view-payroll/(:num)', 'StaffController::view_payrolls/$1');
$routes->post('get-staff_data', 'StaffController::Get_staffData');
$routes->get('over_time', 'StaffController::view_overtime');
$routes->post('Get-Advances', 'StaffController::GetAdvanceDetails');
$routes->post('get-staff_data', 'StaffController::Get_staffData');
$routes->post('save-overtime', 'StaffController::save_overtime');
$routes->post('delete-payroll', 'StaffController::delete_payroll');
$routes->post('delete-payroll_payment', 'BillController::delete_payroll_payment');
$routes->post('view-messages', 'SystemController::view_messages');
$routes->get('electricity_charges', 'StaffController::electricity_deductions');
$routes->post('electricity_charges_list', 'StaffController::electricity_list');
$routes->post('save-charges', 'StaffController::saveCharges');
$routes->post('load_electricity_data', 'StaffController::load_electricity_data');
$routes->post('edit_charges', 'StaffController::edit_charges');
$routes->post('upadte-charges', 'StaffController::upadte_charges');
$routes->post('view_deductions', 'StaffController::view_deductions');
$routes->post('deletecharges', 'StaffController::deletecharges');
$routes->post('view_single_charges', 'StaffController::view_single_charges');
$routes->post('deletesinglecharges', 'StaffController::deletesinglecharges');
$routes->get('overdue_transport', 'TransportController::overdue_transport');
$routes->get('loan_deductions', 'StaffController::loans_deductions');
$routes->post('load_loans_info', 'StaffController::load_loans_info');
$routes->post('save_loan_info', 'StaffController::save_loan_info');
$routes->post('fetch_loan_month', 'StaffController::fetch_loan_month');
$routes->post('view_loans_deduction', 'StaffController::view_loans_deduction');
$routes->post('view_single_loan', 'StaffController::view_single_loan');
$routes->post('edit_single_loan', 'StaffController::edit_single_loan');
$routes->post('upadate-loan', 'StaffController::upadate_loan');
$routes->post('deleteloans', 'StaffController::deleteloans');
$routes->post('deletesingleloan', 'StaffController::deletesingleloan');
//<===================TEACHER ALLOCATION route Ends====================>

$routes->post('app_users_validate', 'CronjobsController::app_users_login');
$routes->get('schools_item/(:num)', 'CronjobsController::fetchSchools/$1');
$routes->get('school_chosen/(:num)', 'CronjobsController::school_chosen/$1');
  $routes->get('class_students/(:num)/(:num)', 'CronjobsController::class_students/$1/$2');
  $routes->post('store_students_images', 'CronjobsController::store');

/*


 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
