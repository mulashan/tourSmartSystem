<?php

/*
 | --------------------------------------------------------------------
 | App Namespace
 | --------------------------------------------------------------------
 |
 | This defines the default Namespace that is used throughout
 | CodeIgniter to refer to the Application directory. Change
 | this constant to change the namespace that all application
 | classes should use.
 |
 | NOTE: changing this will require manually modifying the
 | existing namespaces of App\* namespaced-classes.
 */
defined('APP_NAMESPACE') || define('APP_NAMESPACE', 'App');

/*
 | --------------------------------------------------------------------------
 | Composer Path
 | --------------------------------------------------------------------------
 |
 | The path that Composer's autoload file is expected to live. By default,
 | the vendor folder is in the Root directory, but you can customize that here.
 */
defined('COMPOSER_PATH') || define('COMPOSER_PATH', ROOTPATH . 'vendor/autoload.php');

/*
 |--------------------------------------------------------------------------
 | Timing Constants
 |--------------------------------------------------------------------------
 |
 | Provide simple ways to work with the myriad of PHP functions that
 | require information to be in seconds.
 */
defined('SECOND') || define('SECOND', 1);
defined('MINUTE') || define('MINUTE', 60);
defined('HOUR')   || define('HOUR', 3600);
defined('DAY')    || define('DAY', 86400);
defined('WEEK')   || define('WEEK', 604800);
defined('MONTH')  || define('MONTH', 2592000);
defined('YEAR')   || define('YEAR', 31536000);
defined('DECADE') || define('DECADE', 315360000);

/*
 | --------------------------------------------------------------------------
 | Exit Status Codes
 | --------------------------------------------------------------------------
 |
 | Used to indicate the conditions under which the script is exit()ing.
 | While there is no universal standard for error codes, there are some
 | broad conventions.  Three such conventions are mentioned below, for
 | those who wish to make use of them.  The CodeIgniter defaults were
 | chosen for the least overlap with these conventions, while still
 | leaving room for others to be defined in future versions and user
 | applications.
 |
 | The three main conventions used for determining exit status codes
 | are as follows:
 |
 |    Standard C/C++ Library (stdlibc):
 |       http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
 |       (This link also contains other GNU-specific conventions)
 |    BSD sysexits.h:
 |       http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sysexits
 |    Bash scripting:
 |       http://tldp.org/LDP/abs/html/exitcodes.html
 |
 */
defined('EXIT_SUCCESS')        || define('EXIT_SUCCESS', 0); // no errors
defined('EXIT_ERROR')          || define('EXIT_ERROR', 1); // generic error
defined('EXIT_CONFIG')         || define('EXIT_CONFIG', 3); // configuration error
defined('EXIT_UNKNOWN_FILE')   || define('EXIT_UNKNOWN_FILE', 4); // file not found
defined('EXIT_UNKNOWN_CLASS')  || define('EXIT_UNKNOWN_CLASS', 5); // unknown class
defined('EXIT_UNKNOWN_METHOD') || define('EXIT_UNKNOWN_METHOD', 6); // unknown class member
defined('EXIT_USER_INPUT')     || define('EXIT_USER_INPUT', 7); // invalid user input
defined('EXIT_DATABASE')       || define('EXIT_DATABASE', 8); // database error
defined('EXIT__AUTO_MIN')      || define('EXIT__AUTO_MIN', 9); // lowest automatically-assigned error code
defined('EXIT__AUTO_MAX')      || define('EXIT__AUTO_MAX', 125); // highest automatically-assigned error code

// defined('BASEURL')             || define('BASEURL','http://localhost/elimu-connect/');
/**
 * @deprecated Use \CodeIgniter\Events\Events::PRIORITY_LOW instead.
 */
define('EVENT_PRIORITY_LOW', 200);

/**
 * @deprecated Use \CodeIgniter\Events\Events::PRIORITY_NORMAL instead.
 */
define('EVENT_PRIORITY_NORMAL', 100);

/**
 * @deprecated Use \CodeIgniter\Events\Events::PRIORITY_HIGH instead.
 */
define('EVENT_PRIORITY_HIGH', 10);
//NMB
define('NMB_USERNAME', '519M224W9RMS75'); 
define('NMB_PASSWORD', '04RzzWCTax2p!a&q@QbRmb??%G0vd4w7M*c'); 
define('NMB_URL', 'https://wip.mpayafrica.co.tz/v2/'); 
define('NMB_CALLBACK','http://41.78.170.7/medex/index.php/Payment_processor/');

define('SMS_UNAME', 'john');
define('SMS_PASSWORD', '34bc8q.08');
define('SENDER_ID', 'EGET');

define('SMS_UNAME_USA', 'john');
define('SMS_PASSWORD_USA', '34bc8q.08');
define('SENDER_ID_USA', 'UsaSeminary');
define('API_KEY', '35abdc42-4437-49fc-a35a-84b4a50c2d99');

define('SENDER_ID_1', 'EGET');
define('SENDER_ID_2', 'ST ANNE');
define('SENDER_ID_4', 'UsaSeminary');
define('SENDER_ID_5', 'AFYA MHI');
define('SENDER_ID_7', 'GuardianAng');
define('SENDER_ID_6', 'LITTLEACORN');
define('SENDER_ID_8', 'MoshiAcadmy');
define('SENDER_ID_13', 'PAPABRIDGE');
define('SENDER_ID_10', 'KilimSports');
define('SENDER_ID_14', 'KISARIKASEC');
//sms mhi
define('SMS_UNAME_AFYA', 'john');
define('SMS_PASSWORD_AFYA', '34bc8q.08');
define('SENDER_ID_AFYA', 'AFYA MHI');

define('FACILITY_ID_1', 17721695217602);            
define('PAYMENT_TYPE_1', 2233);            
define('PREFIX_1', 'EG1');            
define('CRDB_URL_1', 'http://41.220.137.109:8000/api/');            
define('CRDB_CALLBACK_1','/index.php/PaymentsController/receive_crdb_payment/advamhwe_elimu_db');
define('CRDB_CALLBACK_APPLICATION_1','/index.php/PaymentsController/receive_crdb_app/advamhwe_elimu_db');
define('CRDB_CALLBACK_DEPOSIT_1','/index.php/PaymentsController/receive_crdb_deposit/advamhwe_elimu_db');
define('ALIENS_1','/index.php/PaymentsController/receive_aliens/advamhwe_elimu_db');
define('CHARGES_1', 1180);

//crdb usa
define('FACILITY_ID_4', 68471711017662);            
define('PAYMENT_TYPE_4', 778);            
define('PREFIX_4', 'USE');            
define('CRDB_URL_4', 'http://41.220.137.109:8000/api/');            
define('CRDB_CALLBACK_4','/index.php/PaymentsCrdb/receive_crdb_payment/4');
define('CRDB_CALLBACK_APPLICATION_4','/index.php/PaymentsCrdb/receive_crdb_app/4');
define('CRDB_CALLBACK_DEPOSIT_4','/index.php/PaymentsCrdb/receive_crdb_deposit/4');
define('CHARGES_4', 0);

//crdb st anne
define('FACILITY_ID_2', 98141610881113);            
define('PAYMENT_TYPE_2', '0001');            
define('PREFIX_2', 'ANN');            
define('CRDB_URL_2', 'http://41.220.137.109:8000/api/');            
define('CRDB_CALLBACK_2','/index.php/PaymentsController/receive_crdb_payment/advamhwe_st_anne');
define('CRDB_CALLBACK_APPLICATION_2','/index.php/PaymentsController/receive_crdb_app/advamhwe_st_anne');
define('CRDB_CALLBACK_DEPOSIT_2','/index.php/PaymentsController/receive_crdb_deposit/advamhwe_st_anne');
define('CHARGES_2', 0);

define('DB1', 'advamhwe_elimu_db');
define('DB2', 'advamhwe_st_anne');
define('DB4', 'advamhwe_usariverseminary');
define('DB6', 'advamhwe_littleAcorns_db');
define('DB7', 'advamhwe_guardian_angles_db');

define('TMSG1', 1);
define('TMSG2', 1);
define('TMSG3', 0);
define('TMSG4', 1);
define('TMSG5', 0);
define('TMSG6', 1);
define('TMSG7', 1);
define('TMSG8', 1);
define('TMSG9', 0);
define('TMSG10', 0);
define('TMSG11', 0);
define('TMSG12', 0);
define('TMSG13', 0);
define('TMSG14', 0);

define('msgDESC1','Application');
define('msgDESC2','Ada');
define('msgDESC3','Vinginevyo');
define('msgDESC4','Usafiri');
define('msgDESC5','Boarding');
define('msgDESC6','Deposit');
define('msgDESC7','project');
define('msgDESC8','Opening Balance');
define('msgDESC9','Poket Money');