<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\WebSocket\WsServer;

class StartWebSocketServer extends BaseCommand
{
    protected $group = 'WebSockets';
    protected $name = 'websocket:start';
    protected $description = 'Start the WebSocket server for real-time communication';

    public function run(array $params)
    {
        // Set up WebSocket server
        $server = IoServer::factory(
            new WsServer(new ChatComponent()), 8080 // Use port 8080 or your preferred port
        );

        CLI::write("WebSocket server started on ws://localhost:8080", 'green');
        $server->run();
    }
}

// Create a new class for WebSocket behavior
class ChatComponent implements MessageComponentInterface
{
    protected $clients;

    public function __construct()
    {
        $this->clients = new \SplObjectStorage;
    }

    public function onOpen(ConnectionInterface $conn)
    {
        // New client connected
        $this->clients->attach($conn);
    }

    public function onClose(ConnectionInterface $conn)
    {
        // Client disconnected
        $this->clients->detach($conn);
    }

    public function onMessage(ConnectionInterface $from, $msg)
    {
        // Broadcast the received message to all connected clients
        foreach ($this->clients as $client) {
            if ($from !== $client) {
                $client->send($msg);
            }
        }
    }

    public function onError(ConnectionInterface $conn, \Exception $e)
    {
        $conn->close();
    }
}
