          <?php  
$imodel = new App\Models\ItemsModel();
 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
 ?>
           <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">General Academic Reports</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">General Academic Reports</li>
                </ol>
            </div>
         </div><br><br>
          <!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="box box-danger">
           
            <div class="box-body">
          
            <div class="container mt-1">
    <form id="getReport1" class="row g-3 needs-validation" novalidate>
          <div class="row">
      <div class="col-md-6">
                        <div class="row mb-4">
                                 <label for="year" class="col-md-4 form-label">Academic Year:<span class="text-danger">*</span></label>
                                <div class="col-md-4">
                                   <select id="year" name="year" class="report-select" style="width: 200px;" required>
                <script>
                    const currentYear = new Date().getFullYear();
                    const startYear = 2023;
                    for (let year = currentYear + 1; year >= startYear; year--) {
                        if (year === currentYear) {
                            document.write(`<option value="${year}" selected>${year}</option>`);
                        } else {
                            document.write(`<option value="${year}">${year}</option>`);
                        }
                    }
                </script>
            </select>
            <div class="invalid-feedback">Academic Year is required.</div>
                                </div>
                            </div>

<div class="row mb-4">
  <label for="reporttypes" class="col-md-4 form-label">Report Type:<span class="text-danger">*</span></label>
  <div class="col-md-6">
    <div class="input-group">
      <button type="button" class="btn btn-default form-control" id="reportrange-btn">
        <!-- <span>
          <i class="fa fa-clipboard"></i> Select Report Type
        </span> -->
        <span id="selected-report-label">
  <i class="fa fa-clipboard"></i> Select Report Type
</span>

        <i class="fa fa-caret-down float-end"></i>
      </button>
    </div>
    <input type="hidden" name="exam_type_label" id="exam_type_label">
    <input type="hidden" id="exam_type_value" name="exam_type_value">
    <input type="hidden" name="start_date" id="start_date">
    <input type="hidden" name="end_date" id="end_date">
    <div class="invalid-feedback">Examination Report Type is required.</div>
  </div>
</div>

    <div class="row mb-4">
         <label for="classlevel" class="col-md-4 form-label">Level:<span class="text-danger">*</span></label>
        <div class="col-md-4">
            <select class="report-select" name="classlevel" id="classlevel" style="width: 200px;" required>
                <option value="" selected disabled>--Select Level--</option>
                <?php
                $l = $remodel->get_levels();
                foreach ($l as $le) {
                    echo '<option value="' . $le->id . '">' . $le->level_name . '</option>';
                }
                ?>
            </select>
            <div class="invalid-feedback">Class Level is required.</div>
        </div>
    </div>
    <div class="row mb-4">
         <label for="class" class="form-label col-md-4">Class:<span class="text-danger">*</span></label>
        <div class="col-md-4">
    
            <select class="report-select" name="class" id="class" style="width: 200px;" required>
                <option value="" selected disabled>--Require Level first--</option>
            </select>
            <div class="invalid-feedback">Class is required.</div>
        </div>
    </div>
      <div class="row mb-4">
          <label for="stream" class="form-label col-md-4">Stream:<span class="text-danger">*</span></label>
        <div class="col-md-4">
          
            <select class="report-select" name="stream" id="stream" style="width: 200px;" required>
                <option value="" selected disabled>--Require Level first--</option>
            </select>
            <div class="invalid-feedback">Stream is required.</div>
        </div>
    </div>
    <div class="row mb-4">
    <label for="status" class="form-label  col-md-4">Status: <span class="text-danger">*</span></label>
        <div class="col-md-4">
            
            <select id="status" name="status" class="report-select" style="width: 200px;" required>
                <option value="0">All</option>
                <option value="1">Pending</option>
                <option value="2" selected>Admitted</option>
                <option value="4">Graduates</option>
                <option value="3">Transferred</option>
                <option value="5">Absconded</option>
            </select>
            <div class="invalid-feedback">Status is required.</div>
        </div>
    </div>
        <div class="col-12 text-right mt-2">
            <button type="submit" class="btn btn-primary px-5">Create</button>
        </div>



                        </div>
                    </div>
 

    </form>
</div>

                <center>
                <!--  <div class="input-group col-md-4 mt-3">
                                                    
                    <input type="text" class="form-control" name="payer_name" id="search_name"   placeholder="Search Student Name" aria-label="Student Name" aria-describedby="button-st">
                    <button class="btn btn-outline-success" type="button" id="button-y">
                        <span>
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                        </span></button>
                    <button class="btn btn-outline-primary" type="button" id="button-st" onclick="searchnamebtn()"><i class="fa fa-search" aria-hidden="true"></i></button>
                </div> -->
                </center>
                
                 <hr>
                 
                    <center>
                        <div style="font-size: 18px;">
                                <div id="load_status">
                                   
                                </div>
                    <strong><span id="selected_class"></span></strong> 
                    <strong><span id="all_selected_stream"></span></strong> 
                    <strong><span id="selected_stream"></span></strong> 
                    <strong> <span id="selected_comb"></span></strong> 
                    <strong>  <span id="report_title"></span></strong> 
                    <br>
                    <strong>  <span id="selected_year"><?=date('Y');?></span></strong> 
                     
                     
                    
                    
                 </div>
                    </center>
            
                &nbsp;
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>
           
            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
</div>
</div>
<script type="text/javascript">
      $(document).ready(function() {
        $(".report-select").select2();
    });
       $("#year").change(function(){
           $('#Rept1ResultViewResults').html('');
        var year = $(this).val();
        $.ajax({
            url: 'list_terms',
            type: 'post',
            data: {year:year},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#terms").empty();
                $("#terms").append("<option value='' disabled selected>--Choose term--</option>");
                $("#terms").append("<option value='0'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['term_name'];
                   
                   $("#terms").append("<option value='"+id+"'>"+name+"</option>");
                }
            }
        });
    });
   $("#classlevel").change(function(){
       $('#Rept1ResultViewResults').html('');
        var clvl = $(this).val(); 
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value='' selected disabled>--Choose Class--</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#class").append("<option value='"+id+"'>"+name+"</option>");
                }
            }
        });
    });

        $("#class").change(function(){
               $('#Rept1ResultViewResults').html('');
        var clvl = $(this).val(); 
        $.ajax({
             url: '<?php echo base_url() . '/list_stream'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#stream").empty();
                $("#stream").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['stream_name'];
                    var comb = response[i]['comb_name'];
                    $("#stream").append("<option value='"+id+"'>"+name+" ("+comb+")"+"</option>");
                }
            }
        });
    });
          $("#stream").change(function(){
           $('#Rept1ResultViewResults').html('');
       });
             $("#status").change(function(){
           $('#Rept1ResultViewResults').html('');
       });
   $('#getReport1').submit(function (e) {
            $(this).serialize();
       e.preventDefault();
    if (!this.checkValidity()) {
        this.classList.add("was-validated");
        return;
             }
            
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var formData = $(this).serialize();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/FetchGeneralReports'; ?>',

                data: formData,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
   function initDateRangePicker(year) {
    var start = moment(`${year}-01-01`);
    var end = moment(`${year}-12-31`);

    // Full range with exam type ID
    const fullRanges = {
        'First Midterm': [2, moment(`${year}-03-01`), moment(`${year}-03-31`)],
        'Terminal Report': [3, moment(`${year}-01-01`), moment(`${year}-06-30`)],
        'Second Midterm': [5, moment(`${year}-09-01`), moment(`${year}-09-30`)],
        'Annual Report': [4, moment(`${year}-07-01`), moment(`${year}-11-30`)],
        'Whole Year': [0, start, end]
    };

    // Create a simplified ranges object for daterangepicker
    let displayRanges = {};
    for (let label in fullRanges) {
        const [, startDate, endDate] = fullRanges[label];
        displayRanges[label] = [startDate, endDate];
    }

    function cb(start, end, label) {
        const formattedRange = `${start.format('YYYY/MM/DD')} - ${end.format('YYYY/MM/DD')}`;

        if (label && fullRanges[label]) {
            const [examType] = fullRanges[label];
             $('#selected-report-label').html(`<i class="fa fa-clipboard"></i> ${label}`);
             $('#report_title').html(` ${label}`);
            $('#reportrange-text').html(`${label} (${formattedRange})`);
            $('#exam_type_label').val(label);
            $('#exam_type_value').val(examType);
        } else {
              $('#selected-report-label').html(`<i class="fa fa-clipboard"></i> ${formattedRange}`);
               $('#report_title').html(` ${label}`);
            $('#reportrange-text').html(`${formattedRange} (Custom Range)`);
            $('#exam_type_label').val('Custom Range');
            $('#exam_type_value').val('custom');
        }

        $('#start_date').val(start.format('YYYY-MM-DD'));
        $('#end_date').val(end.format('YYYY-MM-DD'));
    }

    $('#reportrange-btn').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: displayRanges
    }, cb);

    // Initialize with default range
    cb(start, end, 'Whole Year');
}

$(function () {
    const initialYear = $('#year').val();
    initDateRangePicker(initialYear);
});

$('#year').change(function () {
    const selectedYear = $(this).val();
    initDateRangePicker(selectedYear);
});


      $(document).ready(function() {
        $(".report-select").select2();
    });
$("#class").change(function () {
    var class_id = $(this).val();
    $('#load_status').html('<span class="fa fa-spinner fa-spin"></span> Loading class data...').show();
    $('#selected_class').load('<?= base_url("/load_class") ?>/' + class_id, function () {
        $('#load_status').hide();
    });

    $('#all_selected_stream').html('<span>All streams</span>');
    $('#selected_stream').html('');
});

$("#stream").change(function () {
    var stream = $(this).val();
    $('#load_status').html('<span class="fa fa-spinner fa-spin"></span> Loading stream data...').show();
    $('#selected_stream').load('<?= base_url("/load_stream") ?>/' + stream, function () {
        $('#load_status').hide();
    });

    $('#all_selected_stream').html('');
});
$("#year").change(function () {
    var year = $(this).val();
    $('#load_status').html('<span class="fa fa-spinner fa-spin"></span> Loading stream data...').show();
    $('#selected_year').html(year);
        $('#load_status').hide();
    $('#all_selected_stream').html('');
});


//                     $("#stream").change(function() {
//     var stream = $(this).val();
//     $('#selected_stream').load('<?= base_url("/load_stream") ?>/' + stream);
// });
  </script>