 <style>
    table {
      margin: 20px auto;
      border-collapse: collapse;
      width: 90%;
      background-color: #fdf8f2;
    }
    th, td {
      border: 1px solid #333;
      padding: 6px 10px;
      text-align: center;
    }
    th {
      background-color: #f0e6d6;
    }
    caption {
      font-weight: bold;
      margin-bottom: 10px;
      font-size: 18px;
    }
  </style>
</head>
  <table>
    <h4> ANNUAL RESULTS<br>SUBJECT WISE PERFORMANCE<br><?=esc($year);?></h4>
    <thead>
      <tr>
        <th rowspan="2">S/N</th>
        <th rowspan="2">SUBJECT</th>
        <th colspan="5">GRADE PERFORMANCE</th>
        <th rowspan="2">% PASS</th>
        <th rowspan="2">SUBJECT POSITION</th>
      </tr>
      <tr>
        <th>A</th><th>B</th><th>C</th><th>D</th><th>F</th>
      </tr>
    </thead>
    <tbody>
      <tr><td>1</td><td>CIVICS</td><td>9</td><td>8</td><td>16</td><td>11</td><td>8</td><td>84.61538462</td><td>12</td></tr>
      <tr><td>2</td><td>HISTORY</td><td>8</td><td>8</td><td>25</td><td>10</td><td>1</td><td>98.07692308</td><td>4</td></tr>
      <tr><td>3</td><td>GEOGRAPHY</td><td>6</td><td>14</td><td>25</td><td>7</td><td>0</td><td>100</td><td>1</td></tr>
      <tr><td>4</td><td>KISWAHILI</td><td>19</td><td>22</td><td>11</td><td>3</td><td>0</td><td>100</td><td>2</td></tr>
      <tr><td>5</td><td>ENGLISH</td><td>21</td><td>13</td><td>15</td><td>0</td><td>0</td><td>100</td><td>3</td></tr>
      <tr><td>6</td><td>BIOLOGY</td><td>9</td><td>11</td><td>23</td><td>8</td><td>1</td><td>98.07692308</td><td>6</td></tr>
      <tr><td>7</td><td>B. MATHS</td><td>7</td><td>6</td><td>16</td><td>5</td><td>3</td><td>90.38461538</td><td>10</td></tr>
      <tr><td>8</td><td>PHYSICS</td><td>7</td><td>13</td><td>27</td><td>3</td><td>0</td><td>96.15384615</td><td>7</td></tr>
      <tr><td>9</td><td>CHEMISTRY</td><td>24</td><td>17</td><td>8</td><td>2</td><td>1</td><td>98.07692308</td><td>5</td></tr>
      <tr><td>10</td><td>COMMERCE</td><td>10</td><td>8</td><td>11</td><td>6</td><td>5</td><td>92.30769231</td><td>9</td></tr>
      <tr><td>11</td><td>B/KEEPING</td><td>8</td><td>7</td><td>17</td><td>2</td><td>3</td><td>88.46153846</td><td>11</td></tr>
      <tr><td>12</td><td>BIBLE</td><td>14</td><td>12</td><td>19</td><td>5</td><td>2</td><td>96.15384615</td><td>8</td></tr>
    </tbody>
  </table>