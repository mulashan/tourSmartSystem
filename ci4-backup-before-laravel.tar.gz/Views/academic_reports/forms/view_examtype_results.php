<head>
    <style>
        table {
    width: 80%;
    border-collapse: collapse;
    white-space: nowrap;
}

   th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

th {
   background-color: #ddd;
    font-weight: bold;
}
.rotate {
    writing-mode: vertical-rl;
    transform: rotate(180deg);
    text-align: center;
    white-space: nowrap;
}
td.centa{
    text-align: left;
}

    </style>
</head>

<div class="card">
    <?php
$positionsByAverage = [];
foreach ($cl as $student) {
    $total_marks = 0;
    $total_subjects = 0;

    foreach ($subjectsByComb as $comb) {
        foreach ($comb['subjects'] as $subject) {
            foreach ($results as $r) {
                if ($r->student_id == $student->id && $r->subject_id == $subject['subject_id']) {
                    $total_marks += $r->marks_scored;
                    $total_subjects++;
                    break;
                }
            }
        }
    }

    $avg = $total_subjects > 0 ? $total_marks / $total_subjects : 0;
    $positionsByAverage[] = [
        'student_id' => $student->id,
        'average' => $avg
    ];
}
?>

<?php
usort($positionsByAverage, function($a, $b) {
    return $b['average'] <=> $a['average'];
});
?>
<?php
$averageRanks = [];
$position = 1;
foreach ($positionsByAverage as $index => $item) {
    if ($index > 0 && $item['average'] == $positionsByAverage[$index - 1]['average']) {
        $position = $averageRanks[$positionsByAverage[$index - 1]['student_id']];
    }
    $averageRanks[$item['student_id']] = $position;
    $position++;
}
?>

<div class="container mt-4">
    <div class="table-responsive">
    <table class="" >
      <thead>
    <tr>
        <th rowspan="3">S/N</th>
        <th rowspan="3">NAME</th>
        <th rowspan="3">SEX</th>
        <?php 
        $total_subjects = 0;
        foreach ($subjectsByComb as $comb) {
            $total_subjects += count($comb['subjects']);
        }
        $colspan = $total_subjects * 2;

        echo "<th colspan='{$colspan}'>SUBJECTS</th>";
        ?>
        <th colspan="6">RESULTS SUMMARY</th>
         <!-- <th rowspan="3">ACTION</th> -->
    </tr>
    <tr>
        <?php
        foreach ($subjectsByComb as $combId => $combData) {
            foreach ($combData['subjects'] as $subject) {
                echo "<th colspan='2' class='rotate'>" . strtoupper($subject['subject_name']) . "</th>";
            }
        }
        ?>
        <th class="rotate">TOTAL MARKS</th>
        <th class="rotate">AVERAGE</th>
        <th class="rotate">GRADE</th>
        <th class="rotate">POSITION</th>
        <!-- <th class="rotate">POINT</th>
        <th class="rotate">DIVISION</th> -->
    </tr>
</thead>
        <tbody>
<?php
$total_students = count($cl);
$digit_length = strlen((string)$total_students);
$i = 0;
?>
<?php foreach ($cl as $student): ?>
    <?php
        $i++;
        $formatted_i = sprintf("%0" . $digit_length . "d", $i);
        $total_marks = 0;
        $total_subjects = 0;
        $total_points = 0;
    ?>
    <tr>
        <td><?= $formatted_i; ?></td>
        <td class="centa"><?= $student->full_name; ?></td>
        <td><?= $student->gender == 'Male' ? 'M' : 'F'; ?></td>

        <?php foreach ($subjectsByComb as $combId => $info): ?>
            <?php foreach ($info['subjects'] as $subject): ?>
                <?php
                    $marks = '';
                    $grade_name = '';
                    $points = 0;

                    if (isset($results)) {
                        foreach ($results as $r) {
                            if ($r->student_id == $student->id && $r->subject_id == $subject['subject_id']) {
                                $marks = $r->marks_scored;
                                $grade_name = $r->grade_name;
                                foreach ($gradeBoundaries as $boundary) {
                                    if ($marks >= $boundary->lower_performance && $marks <= $boundary->upper_performance) {
                                        $points = $boundary->division_point;
                                        break;
                                    }
                                }

                                $total_marks += $marks;
                                $total_subjects++;
                                $total_points += $points;
                                break;
                            }
                        }
                    }
                ?>
                <td>&nbsp;<?= $marks; ?>&nbsp;</td>
                <td>&nbsp;<?= $grade_name; ?>&nbsp;</td>
            <?php endforeach; ?>
        <?php endforeach; ?>

        <?php
            $average = $total_subjects > 0 ? $total_marks / $total_subjects : 0;
            $averageGrade = '';
            foreach ($gradeBoundaries as $boundary) {
                if ($average >= $boundary->lower_performance && $average <= $boundary->upper_performance) {
                    $averageGrade = $boundary->grade_name;
                    break;
                }
            }
        ?>
        <td><?= $total_marks; ?></td>
        <td>&nbsp;<?= number_format($average, 1); ?> &nbsp;</td>
        <td>&nbsp;<?= $averageGrade; ?> &nbsp;</td>      
<td>&nbsp;<?= $averageRanks[$student->id] ?? '-'; ?> &nbsp;</td>

 <!--<td>&nbsp;<?= $total_points; ?> &nbsp;</td>
         <td>&nbsp;
            <?php
if ($total_points <= 17 && $total_points !==0) {
   echo $division = ' I';
} elseif ($total_points <= 21 && $total_points !==0) {
    echo $division = ' II';
} elseif ($total_points <= 25 && $total_points !==0) {
   echo $division = ' III';
} elseif ($total_points <= 30 && $total_points !==0) {
  echo  $division = ' IV';
} else if($total_points ==0){
    echo $division = 'ABS';
}
else {
    echo $division = '0';
}

            ?>
            &nbsp;
        </td> -->
        <!-- <td>
            <a href="#" data-toggle="modal"
               data-target="<?= $student->id; ?>"
               data-year="<?= $student->academic_year; ?>"
               data-class="<?= esc($class); ?>"
               data-stream="<?= $student->stream_id; ?>"
               data-terms="<?=esc($terms);?>"
               data-examtypes="<?= esc($examtypes); ?>"
               data-sn="<?= $formatted_i; ?>"
               class="ViewID text-light btn btn-xs btn-flat btn-primary">
               <i class="fa fa-eye"></i> View
            </a>
        </td> -->
    </tr>
<?php endforeach; ?>

</tbody>
    </table>
<!-- view model -->
 <div class="modal fade" id="viewModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Student Report</h5>
               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

       <div id="ViewStudentReport"></div>
            </div>
             <div class="modal-footer">
                   <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('showLedger')"><i class="fa fa-print"></i> Print</button>
        </div>
        </div>
    </div>
</div>
<!-- ========================== -->
</div>
</div>
</div>
<script type="text/javascript">
        $(".ViewID").click(function () {
      var id=$(this).attr('data-target');
      var year = $(this).data("year");
      var clas = $(this).data("class");
      var stream = $(this).data("stream");
      var examtypes = $(this).data("examtypes");
      var terms = $(this).data("terms");
      var sn = $(this).data("sn");
        $('#viewModal').modal('show');
        $.ajax({
            type: "POST",
            url: "<?= base_url('/view_student_report')?>",
            data: {id,year,sn,stream,clas,examtypes,terms},
            beforSend: function()
            {
                $('#ViewStudentReport').html('<div class="text-center"><div class="spinner-border text-primary" role="status"><span class="sr-only">Loading...</span></div></div>');
            },
            success: function(res){
                $('#ViewStudentReport').html(res);
                 
            },
            error: function ()
            {
         $('#ViewStudentReport').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
            }
        });
    });
</script>