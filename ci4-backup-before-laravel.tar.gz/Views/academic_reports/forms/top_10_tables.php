 <style>
    table {
      margin: 20px auto;
      border-collapse: collapse;
      width: 80%;
      /*background-color: #f9f9f9;*/
        background-color: #fdf1c7;
    }
    th, td {
      border: 1px solid #333;
      padding: 8px 12px;
    }
    th {
      background-color: #e0e0e0;
    }
     .highlight {
            background-color: #fdf1c7;
        }
        .top10avg{
       background-color: #21d263;
       text-align: center;
       font-weight: bold;
/*color: white;*/
        }
         .bottom10avg{
background-color:#ff0033;
text-align: center;
font-weight: bold;
color:white;
        }
        .lasthead{
         background-color:#bdd7ee;
text-align: center;
font-weight: bold; 
/*color:white;*/
        }
  </style>
</head>
          <?php
     if(isset($message) && !empty($message)){
            ?>
            <span class="alert alert-danger"><?=esc($message);?> not Published</span>
    <?php
} else{
$positionsByAverage = [];
foreach ($cl as $student) {
    $total_marks = 0;
    $total_subjects = 0;
    foreach ($subjectsByComb as $comb) {
        foreach ($comb['subjects'] as $subject) {
            if(isset($results)){
            foreach ($results as $r) {
                if ($r['student_id'] == $student->id && $r['subject_id'] == $subject['subject_id']) {
                $marks = array_sum($r['marks']);
             $total_marks += $marks; 
                  $total_subjects += count($r['marks']);
                    break;
                }
            }
        }
        }
    }


    $avg = $total_subjects > 0 ? $total_marks / $total_subjects : 0;
    $positionsByAverage[] = [
        'student_id' => $student->id,
        'average' => $avg
    ];
}
?>

<?php
usort($positionsByAverage, function($a, $b) {
    return $b['average'] <=> $a['average'];
});
?>
<?php
$averageRanks = [];
$position = 1;
foreach ($positionsByAverage as $index => $item) {
    if ($index > 0 && $item['average'] == $positionsByAverage[$index - 1]['average']) {
        $position = $averageRanks[$positionsByAverage[$index - 1]['student_id']];
    }
    $averageRanks[$item['student_id']] = $position;
    $position++;
}
?>
 <?php
 if (empty($positionsByAverage)) {
    echo "<p>No student data available to rank.</p>";
}
else{
?>
 <div class="mt-1">
<?php
$topCount = min(10, count($positionsByAverage));
$topStudents = array_slice($positionsByAverage, 0, $topCount);
?>
  <h2><!-- <?=esc($class);?> (<?=esc($stream);?>) --> <?= esc(strtoupper($exam_details)); ?><br>BEST TEN AND LAST TEN STUDENTS<br><?=esc($year);?></h2>
<hr>
  <table>

    <thead>
        <tr>
    <div class="mt-4 mb-4">
    <th class="lasthead" colspan="5">BEST TEN STUDENTS PERFORMANCE</th>
    </div>
  </tr>
      <tr>
        <th>S/N</th>
        <th>STUDENT NAME</th>
        <th>SEX</th>
        <th>AVERAGE</th>
        <th>POSITION</th>
      </tr>
    </thead>
    <tbody>
      <?php 
               $i=1;
                $rank = 1;
      foreach ($topStudents as $student): 
$name = getStudentNameById($student['student_id'], $cl);
$gender = getStudentGenderById($student['student_id'], $cl);
        ?>

      <tr>
        <td><?= $i;?></td>
       <td style="text-align: left;"><?= $name; ?></td> 
         <td><?= $gender == 'Male' ? 'M' : 'F' ?></td> 
        <td class="top10avg"><?= round($student['average'],1)?></td>
        <td><?=$rank;?></td>
      </tr>

      <?php
      $i++;
$rank++;
       endforeach; ?>
 
    </tbody>
  
  
    <div class="mt-4">
      <?php
$bottomCount = min(10, count($positionsByAverage));
$bottomStudents = array_slice($positionsByAverage, -$bottomCount);
      ?>
      <thead>
        <tr>
    <div class="mt-4 mb-4">
    <th class="lasthead" colspan="5">LAST TEN STUDENTS PERFORMANCE</th>
    </div>
  </tr>
      <tr>
        <th>S/N</th>
        <th>STUDENT NAME</th>
        <th>SEX</th>
        <th>AVERAGE</th>
        <th>POSITION</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      $t=1;
        $rank = count($positionsByAverage) - $bottomCount + 1;
      foreach ($bottomStudents as $student): 
       
$name = getStudentNameById($student['student_id'], $cl);
$gender = getStudentGenderById($student['student_id'], $cl);
        ?>

      <tr>
        <td><?= $t ?></td>
        <td style="text-align: left;"><?= $name ?></td>
        <td><?= $gender == 'Male' ? 'M' : 'F' ?></td>
        <td class="bottom10avg"><?= round($student['average'],1)?></td>
        <td><?= $rank ?></td>
      </tr>
      <?php 
 $rank++;
  $t++;
    endforeach; ?>
    </tbody>
    </div>
    <?php
}
  }  ?>
