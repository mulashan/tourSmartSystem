<head>
    <style>
        table {
    width: 80%;
    border-collapse: collapse;
    white-space: nowrap;
}

   th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

th {
   background-color: #ddd;
    font-weight: bold;
}
.rotate {
    writing-mode: vertical-rl;
    transform: rotate(180deg);
    text-align: center;
    white-space: nowrap;
}
td.centa{
    text-align: left;
}
table.summary,td.summary{
    background-color: #fdf1c7;
        border: 2px solid #000;



}
.summary_special_th{
    background-color: #fdf1c7;
        border: 1px solid #000;
  
  
}
.summary_special_td{
    background-color: #ddd;
        border: 1px solid #000; 


}
    </style>

</head>

<div class="card">
    <center>
        <div class=" mt-4">
            <div class="mb-4">
            <?php
     if(isset($message) && !empty($message)){
            ?>
            <span class="alert alert-danger"><?=esc($message);?> not Published</span>
        <?php
        return;
    }
        ?>
        </div>

            <?php
$maleCount = 0;
$femaleCount = 0;

foreach ($cl as $details) {
    if ($details->gender == 'Male') {
        $maleCount++;
    } elseif ($details->gender == 'Female') {
        $femaleCount++;
    }
}

$sum_of_students=$femaleCount+$maleCount;
?>

<?php
  if ($government_level == 3) {
$divisionCounts = [
    'F' => ['I' => 0, 'II' => 0, 'III' => 0, 'IV' => 0, '0' => 0],
    'M' => ['I' => 0, 'II' => 0, 'III' => 0, 'IV' => 0, '0' => 0],
];

foreach ($cl as $student) {
    $gender = $student->gender == 'Male' ? 'M' : 'F';
    $division = '-';
    $studentResults = array_filter($results, fn($res) => $res['student_id'] == $student->id);
    $studentSubjectPoints = [];
    foreach ($subjectsByComb as $comb) {
        foreach ($comb['subjects'] as $subject) {
            foreach ($studentResults as $res) {
                if ($res['subject_id'] == $subject['subject_id']) {
                    $marks = array_sum($res['marks']) / $exam_types_count;
                    $point = getSubjectPoint($marks, $gradeBoundaries);
                    $studentSubjectPoints[] = [
                        'marks' => $marks,
                        'point' => $point,
                    ];
                    break;
                }
            }
        }
    }

        usort($studentSubjectPoints, fn($a, $b) => $b['marks'] <=> $a['marks']);
        $best7 = array_slice($studentSubjectPoints, 0, 7);
        $totalPoints = array_sum(array_column($best7, 'point'));
        $division = getDivisionFromPoints($totalPoints, 3); // get "I", "II", etc.
    if (in_array($division, ['I', 'II', 'III', 'IV'])) {
        $divisionCounts[$gender][$division]++;
    } elseif ($division === '0' || $division === '-' || $division === '') {
        $divisionCounts[$gender]['0']++;
    }
}

$divisionCounts['TOTAL'] = [
    'I' => $divisionCounts['F']['I'] + $divisionCounts['M']['I'],
    'II' => $divisionCounts['F']['II'] + $divisionCounts['M']['II'],
    'III' => $divisionCounts['F']['III'] + $divisionCounts['M']['III'],
    'IV' => $divisionCounts['F']['IV'] + $divisionCounts['M']['IV'],
    '0' => $divisionCounts['F']['0'] + $divisionCounts['M']['0'],
];



?>

<center>
<div style="max-width: 500px;">
<table class="summary">
    <strong><span>DIVISION PERFORMANCE SUMMARY</span></strong>
    <th colspan="7">RESULTS SUMMARY</th>
    <tr>
        <th class="summary_special_th">SEX</th><td>I</td><td>II</td><td>III</td><td>IV</td><td>0</td><td class="summary_special_td"><b>TOTAL</b></td>
    </tr>
    <tr>
        <th class="summary_special_th">F</th>
        <td><?= $divisionCounts['F']['I'] ?></td>
        <td><?= $divisionCounts['F']['II'] ?></td>
        <td><?= $divisionCounts['F']['III'] ?></td>
        <td><?= $divisionCounts['F']['IV'] ?></td>
        <td><?= $divisionCounts['F']['0'] ?></td>
        <td class="summary_special_td"><b><?= array_sum($divisionCounts['F']) ?></b></td>
    </tr>
    <tr>
        <th class="summary_special_th">M</th>
        <td><?= $divisionCounts['M']['I'] ?></td>
        <td><?= $divisionCounts['M']['II'] ?></td>
        <td><?= $divisionCounts['M']['III'] ?></td>
        <td><?= $divisionCounts['M']['IV'] ?></td>
        <td><?= $divisionCounts['M']['0'] ?></td>
        <td class="summary_special_td"><b><?= array_sum($divisionCounts['M']) ?></b></td>
    </tr>
    <tr>
        <th class="summary_special_td">TOTAL</th>
        <td class="summary_special_td"><?= $divisionCounts['TOTAL']['I'] ?></td>
        <td class="summary_special_td"><?= $divisionCounts['TOTAL']['II'] ?></td>
        <td class="summary_special_td"><?= $divisionCounts['TOTAL']['III'] ?></td>
        <td class="summary_special_td"><?= $divisionCounts['TOTAL']['IV'] ?></td>
        <td class="summary_special_td"><?= $divisionCounts['TOTAL']['0'] ?></td>
        <td class="summary_special_td"><b><?= array_sum($divisionCounts['TOTAL']) ?></b></td>
    </tr>
</table>
</div>
</center>
<?php
}
  else if ($government_level == 4) { 
$divisionCounts = [
    'F' => ['I' => 0, 'II' => 0, 'III' => 0, 'IV' => 0, '0' => 0],
    'M' => ['I' => 0, 'II' => 0, 'III' => 0, 'IV' => 0, '0' => 0],
];

foreach ($cl as $student) {
    $gender = $student->gender == 'Male' ? 'M' : 'F';
    $division = '-';

    $studentResults = array_filter($results, fn($res) => $res['student_id'] == $student->id);

    $studentSubjectPoints = [];
    foreach ($subjectsByComb as $comb) {
        foreach ($comb['subjects'] as $subject) {
            // Only core subjects
            if ($subject['selection'] == 1) {
                foreach ($studentResults as $res) {
                    if ($res['subject_id'] == $subject['subject_id']) {
                        $marks = array_sum($res['marks']) / $exam_types_count;
                        $point = getSubjectPoint($marks, $gradeBoundaries);
                        $studentSubjectPoints[] = [
                            'marks' => $marks,
                            'point' => $point,
                        ];
                        break;
                    }
                }
            }
        }
    }

    if ($government_level == 4) { // A-Level
        // Take all core subject points
        $totalPoints = array_sum(array_column($studentSubjectPoints, 'point'));
        $division = getDivisionFromPoints($totalPoints, 4);
    }

    if (in_array($division, ['I', 'II', 'III', 'IV'])) {
        $divisionCounts[$gender][$division]++;
    } elseif ($division === '0' || $division === '-' || $division === '') {
        $divisionCounts[$gender]['0']++;
    }
}

$divisionCounts['TOTAL'] = [
    'I' => $divisionCounts['F']['I'] + $divisionCounts['M']['I'],
    'II' => $divisionCounts['F']['II'] + $divisionCounts['M']['II'],
    'III' => $divisionCounts['F']['III'] + $divisionCounts['M']['III'],
    'IV' => $divisionCounts['F']['IV'] + $divisionCounts['M']['IV'],
    '0' => $divisionCounts['F']['0'] + $divisionCounts['M']['0'],
];
?>
<center>
    <div style="max-width: 500px;">
<table class="summary">
    <strong><span>DIVISION PERFORMANCE SUMMARY</span></strong>
    <th colspan="7">RESULTS SUMMARY</th>
    <tr>
        <th class="summary_special_th">SEX</th><td>I</td><td>II</td><td>III</td><td>IV</td><td>0</td><td class="summary_special_td"><b>TOTAL</b></td>
    </tr>
    <tr>
        <th class="summary_special_th">F</th>
        <td><?= $divisionCounts['F']['I'] ?></td>
        <td><?= $divisionCounts['F']['II'] ?></td>
        <td><?= $divisionCounts['F']['III'] ?></td>
        <td><?= $divisionCounts['F']['IV'] ?></td>
        <td><?= $divisionCounts['F']['0'] ?></td>
        <td class="summary_special_td"><b><?= array_sum($divisionCounts['F']) ?></b></td>
    </tr>
    <tr>
        <th class="summary_special_th">M</th>
        <td><?= $divisionCounts['M']['I'] ?></td>
        <td><?= $divisionCounts['M']['II'] ?></td>
        <td><?= $divisionCounts['M']['III'] ?></td>
        <td><?= $divisionCounts['M']['IV'] ?></td>
        <td><?= $divisionCounts['M']['0'] ?></td>
        <td class="summary_special_td"><b><?= array_sum($divisionCounts['M']) ?></b></td>
    </tr>
    <tr>
        <th>TOTAL</th>
        <td class="summary_special_td"><?= $divisionCounts['TOTAL']['I'] ?></td>
        <td class="summary_special_td"><?= $divisionCounts['TOTAL']['II'] ?></td>
        <td class="summary_special_td"><?= $divisionCounts['TOTAL']['III'] ?></td>
        <td class="summary_special_td"><?= $divisionCounts['TOTAL']['IV'] ?></td>
        <td class="summary_special_td"><?= $divisionCounts['TOTAL']['0'] ?></td>
        <td class="summary_special_td"><b><?= array_sum($divisionCounts['TOTAL']) ?></b></td>
    </tr>
</table>
</div>
</center>


<?php

}
?>
        </div>
    </center>
 
    <hr>
    <?php
$positionsByAverage = [];
foreach ($cl as $student) {
    $total_marks = 0;
    $total_subjects = 0;
    foreach ($subjectsByComb as $comb) {
        foreach ($comb['subjects'] as $subject) {
            if(isset($results)){
            foreach ($results as $r) {
                if ($r['student_id'] == $student->id && $r['subject_id'] == $subject['subject_id']) {
                $marks = array_sum($r['marks']);
             $total_marks += $marks; 
                  $total_subjects += count($r['marks']);
                    break;
                }
            }
        }
        }
    }


    $avg = $total_subjects > 0 ? $total_marks / $total_subjects : 0;
    $positionsByAverage[] = [
        'student_id' => $student->id,
        'average' => $avg
    ];
}
?>

<?php
usort($positionsByAverage, function($a, $b) {
    return $b['average'] <=> $a['average'];
});
?>
<?php
// $averageRanks = [];
// $position = 1;
// foreach ($positionsByAverage as $index => $item) {
//     if ($index > 0 && $item['average'] == $positionsByAverage[$index - 1]['average']) {
//         $position = $averageRanks[$positionsByAverage[$index - 1]['student_id']];
//     }
//     $averageRanks[$item['student_id']] = $position;
//     $position++;
// }

?>
<?php
$averageRanks = [];
$index = 0;
$position = 1;

while ($index < count($positionsByAverage)) {
    $start = $index;
    $currentAverage = $positionsByAverage[$index]['average'];
    $tieGroup = [];
    while (
        $index < count($positionsByAverage) &&
        $positionsByAverage[$index]['average'] == $currentAverage
    ) {
        $tieGroup[] = $positionsByAverage[$index];
        $index++;
    }
    $countTied = count($tieGroup);
    if ($countTied > 1) {
        $tiedRank = $position + 0.5;
    } else {
        $tiedRank = $position;
    }
    foreach ($tieGroup as $item) {
        $averageRanks[$item['student_id']] = $tiedRank;
    }
    $position += $countTied;
}
?>


<div class="container mt-4">
    <div class="table-responsive">
    <table class="" >
      <thead>
    <tr>
        <th rowspan="3">S/N</th>
        <?php if(isset($row_stream_data)){
            ?>
       <th rowspan="3">COMB</th>
        <?php
    }
    ?>
        <th rowspan="3">NAME</th>
        <th rowspan="3">SEX</th>
        <?php 
        $total_subjects = 0;
        if(isset($subjectsByComb)){
        foreach ($subjectsByComb as $comb) {
            $total_subjects += count($comb['subjects']);
        }
        $colspan = $total_subjects * 2;

        echo "<th colspan='{$colspan}'>SUBJECTS</th>";
    }
        ?>

        <?php if($government_level==1 || $government_level==2){?>
        <th colspan="4">RESULTS SUMMARY</th>
        <?php
}elseif($government_level==3 || $government_level==4){
        ?>
        <th colspan="6">RESULTS SUMMARY</th>
         <?php
}elseif($government_level==5 || $government_level==6 || $government_level==7){
        ?>
        <th colspan="6">RESULTS SUMMARY</th>
    <?php
}else{
        ?>
   <th colspan="1">RESULTS SUMMARY</th>
           <?php
}
        ?>

         <th rowspan="3">ACTION</th>
    </tr>
    <tr>
        <?php
        if(isset($subjectsByComb )){
        foreach ($subjectsByComb as $combId => $combData) {
            foreach ($combData['subjects'] as $subject) {
                echo "<th colspan='2' class='rotate'>" . strtoupper($subject['subject_name']) . "</th>";
            }
        }}
        ?>
        <?php if($government_level==1 || $government_level==2){?>
        <th class="rotate">TOTAL MARKS</th>
        <th class="rotate">AVERAGE</th>
        <th class="rotate">GRADE</th>
        <th class="rotate">POSITION</th>
        <?php
}elseif($government_level==3 || $government_level==4){
        ?>
     <th class="rotate">TOTAL MARKS</th>
        <th class="rotate">AVERAGE</th>
        <th class="rotate">GRADE</th>
        <th class="rotate">POSITION</th>
    <th class="rotate">POINT</th>
        <th class="rotate">DIVISION</th>
         <?php
}elseif($government_level==5 || $government_level==6 || $government_level==7){
        ?>
   <th class="rotate">TOTAL MARKS</th>
        <th class="rotate">AVERAGE</th>
        <th class="rotate">GRADE</th>
        <th class="rotate">POSITION</th>
    <th class="rotate">POINT</th>
        <th class="rotate">G.P.A</th>
    <?php
}else{
        ?>
        <th class="rotate">TOTAL MARKS</th>
           <?php
}
        ?>
    </tr>
</thead>
        <tbody>
<?php
$total_students = count($cl);
$digit_length = strlen((string)$total_students);
$i = 0;
?>
<?php foreach ($cl as $student): ?>
    <?php
        $i++;
        $formatted_i = sprintf("%0" . $digit_length . "d", $i);
        $total_marks = 0;
        $total_subjects = 0;
        $total_points = 0;
         $subjectPointsMap = [];
    ?>
    <tr>
        <td><?= $formatted_i; ?></td>
<?php
$found = false;
if (isset($row_stream_data)) {
    foreach ($row_stream_data as $rowdata) {
        if ($student->stream_id == $rowdata->stream_id) {
            ?>
            <td><?= $rowdata->comb_name ?></td>
            <?php
            $found = true;
            break;
        }
    }
}
if (!$found) {
    echo "<td>-</td>";
}
?>

        <td style="text-align:left; font-weight: bold;"><?= $student->full_name; ?></td>
        <td><?= $student->gender == 'Male' ? 'M' : 'F'; ?></td>
<?php
$subject_points = [];
$total_marks = 0;
$total_subjects = 0;
$subjectMarksMap = [];
if (isset($results)) {
foreach ($results as $r) {
    $rowmark = array_sum(array_map('floatval', $r['marks']));
    $avgMark = $rowmark / $exam_types_count;
    $subjectMarksMap[$r['subject_id']][$r['student_id']] = $avgMark;

}}



$subjectRanks = [];
$k=0;
foreach ($subjectMarksMap as $subject_id => $marksList) {
    $k++;
    arsort($marksList);
    $rank = 1;
    $lastMark = null;
    $position = 1;

    foreach ($marksList as $student_id => $mark) {
        if ($lastMark !== null && $mark < $lastMark) {
            $position = $rank;
        }
        $subjectRanks[$subject_id][$student_id] = $position;
        $lastMark = $mark;
        $rank++;
    }
}


$subject_positions = [];
foreach ($subjectsByComb as $info){
    foreach ($info['subjects'] as $subject) {
          $marks = 0;
         $grade = '';
          $found = false;
          if (isset($results)){
        foreach ($results as $r) {
            if ($r['student_id'] == $student->id && $r['subject_id'] == $subject['subject_id']) {
                        $rowmark = array_sum(array_map('floatval', $r['marks']));
                     $marks += $rowmark/$exam_types_count;
            $total_marks += $marks;
                $grade = getGradeFromAverage($marks, $gradeBoundaries);
                $total_subjects++;
                   if ($marks !== '') {
                    $subjectPointsMap[] = [
                        'marks' => $marks,
                        'point' => getSubjectPoint($marks, $gradeBoundaries)
                    ];
                }
             
                echo "<td>".round($marks)."</td><td>$grade</td>";
                 $subject_id = $subject['subject_id'];
                $position = $subjectRanks[$subject_id][$student->id] ?? '';
                   $subject_name = $subject['subject_name'];

        $subject_positions[] = [
            'subject' => $subject_id,
            'position' => $position
        ];
               $found = true;
                break;
            }
        }}
         if (!$found) {
            echo "<td> </td><td> </td>";
        }
    }
}
$subject_positions_json = htmlspecialchars(json_encode($subject_positions), ENT_QUOTES, 'UTF-8');
$subjects_position = !empty($subject_positions_json) ? $subject_positions_json : null;
$average = $total_subjects ? $total_marks / $total_subjects : 0;
$averageGrade = getGradeFromAverage($average, $gradeBoundaries);
$total_points = 0;
$total_points = 0;
$division = '-';
if(isset($government_level) && !empty($government_level)){
if ($government_level == 3) {
    usort($subjectPointsMap, function ($a, $b) {
    return $b['marks'] <=> $a['marks'];
});

$best7 = array_slice($subjectPointsMap, 0, 7);
$O_level_total_points = array_sum(array_column($best7, 'point'));
$O_level_division = getDivisionFromPoints($O_level_total_points, $government_level);
} elseif ($government_level == 4) {
if (isset($results)) {
$allSubjects = [];
foreach ($subjectsByComb as $combo) {
    foreach ($combo['subjects'] as $subj) {
        $allSubjects[] = $subj;
    }
}
$studentResults = array_filter($results, function ($res) use ($student) {
    return $res['student_id'] == $student->id;
});
$a_level_total_points = calculateALevelPoints($allSubjects, $studentResults, $gradeBoundaries);
$a_level_division = getDivisionFromPoints($a_level_total_points, $government_level);

}}
}

?>
<td><?= round($total_marks); ?></td>
<td><?= round($average, 1); ?></td>
<td><?= $averageGrade; ?></td>
<td><?= $averageRanks[$student->id] ?? '-'; ?></td>
<?php if ($government_level==3){ ?>
    <td><?= $O_level_total_points; ?></td>
    <td><?= $O_level_division; ?></td>
    <?php
    }elseif($government_level==4){
        if (isset($a_level_total_points)&& isset($a_level_division)) {
    ?>

 <td><?= $a_level_total_points; ?></td>
    <td><?= $a_level_division; ?></td>
<?php }else{
    echo '<td>'." - " .'</td>
    <td>'." - ".'</td>';
}
} 

?>

<?php


?>
        <td>
            <a href="#" data-toggle="modal"
               data-target="<?= $student->id; ?>"
               data-year="<?= $student->academic_year; ?>"
               data-class="<?= esc($class); ?>"
               data-stream="<?= $student->stream_id; ?>"
               data-pre_stream="<?= esc($stream); ?>"
               data-combname="<?= $rowdata->comb_name; ?>"
               data-terms="<?=esc($terms);?>"
               data-postion="<?=esc($averageRanks[$student->id]);?>"
               data-examtypes="<?= esc($examtypes); ?>"
               data-government_level="<?= esc($government_level); ?>"
               data-exam_type_value="<?= esc($exam_type_value); ?>"
               data-exam_type_label="<?= esc($exam_type_label); ?>"
               data-sn="<?= $formatted_i; ?>"
               data-subject_position="<?= $subjects_position; ?>"
               class="ViewID text-light btn btn-xs btn-flat btn-primary">
               <i class="fa fa-eye"></i> View
            </a>
        </td>
    </tr>

<?php

//return;
 endforeach; ?>

</tbody>
    </table>
    
<!-- view model -->
 <div class="modal fade" id="viewModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Student Report</h5>
               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

       <div id="ViewStudentReport"></div>
       <div id="ViewStudentReportstatus"></div>
            </div>
             <div class="modal-footer">
                   <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('showLedger')"><i class="fa fa-print"></i> Print</button> -->
        </div>
        </div>
    </div>
</div>
<!-- ========================== -->
</div>
</div>
</div>
<script type="text/javascript">
        $(".ViewID").click(function () {
      var id=$(this).attr('data-target');
      var year = $(this).data("year");
      var clas = $(this).data("class");
      var stream = $(this).data("stream");
      var examtypes = $(this).data("examtypes");
      var government_level = $(this).data("government_level");
      var exam_type_value = $(this).data("exam_type_value");
      var terms = $(this).data("terms");
      var postion = $(this).data("postion");
      var combname = $(this).data("combname");
      var exam_type_label = $(this).data("exam_type_label");
      var subject_position = $(this).data("subject_position");
      var pre_stream = $(this).data("pre_stream");
      var sn = $(this).data("sn");
      
        $('#viewModal').modal('show');
        $.ajax({
            type: "POST",
            url: "<?= base_url('/view_student_report')?>",
            data: {id,year,sn,stream,clas,examtypes,terms,government_level,exam_type_value,postion,subject_position,exam_type_label,combname,pre_stream},
            beforeSend: function()
            {
                $('#ViewStudentReportstatus').html('<span class="fa fa-spinner fa-spin"></span> Retreiving student report card..');
            },
            success: function(res){
                $('#ViewStudentReport').html(res);
                $('#ViewStudentReportstatus').html('');
                 
            },
            error: function ()
            {
                    $('#ViewStudentReportstatus').html('');
         $('#ViewStudentReport').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
            }
        });
    });

</script>