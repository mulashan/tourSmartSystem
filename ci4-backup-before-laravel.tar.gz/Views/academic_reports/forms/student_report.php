
    <?php
 $bmodel = new App\Models\BillingModel();
  $smodel = new App\Models\StudentModel();
  $cmodel = new App\Models\ClassesModel();
  $outputmodel=new App\Models\AcademicOutputsModel;
?>
<?php 
  helper('age');
 $logo = $bmodel->get_table_details('company_tbl');
  $source="";
            if($logo[0]->logo_name != ""){
               $source =  base_url('public/company_photos/'.$logo[0]->logo_name);
            }
?>
<style type="text/css">
@media print {
  table {
    border-collapse: collapse;
    width: 100%;
    border: 1px solid black; 
    text-align: left;
      font-family: Arial, sans-serif;
      background-color: rgba(255, 255, 255, 0.8);
  }
          .table-container {
      position: relative;
      background-image: url('<?= $source; ?>');
      background-repeat: no-repeat;
      background-position: center;
      background-size: 80%;
      padding: 20px;
    }

  th {
    border: 1px solid black;
    padding: 8px;
    text-align: left;

  }
  td {
    border: 1px solid black;
    padding: 8px;
  }
      -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
}
th.th-no {
  width: 40px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
  
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            text-align: left;
      font-family: Arial, sans-serif;
      background-color: rgba(255, 255, 255, 0.9);
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #d3d3d3; 
            text-align: center;
        }
        td[colspan] {
            text-align: left;
            
        }
        .right {
            text-align: right;
        }
        .info{
            align-content: left;
            align-items: left;

        }
        .th_info{
            width: 10%;
            background-color: white;
              text-align: left;
        }
         .td_info{
            width: 90%;
            background-color: white;
              text-align: left;
        }
        td.centa{
            
            text-align: center;
            font-weight: bold;
        }
        table.table_info{
            width: 100%;
            font-size: 12px;
        }
          table.table_info1{
           float: right;
            width: 100%;
             font-size: 12px;
            margin: ;
        }

            .table-container {
      position: relative;
      background-image: url('<?= $source; ?>');
      background-repeat: no-repeat;
      background-position: center;
      background-size: 30%;
      padding: 20px;
    }
   .modal-backdrop {
  z-index: 1040 !important;
}
.modal-content {
  z-index: 1050 !important;
}
.avgmodal{
    background-color: #27487d;
    color: white;
}
    </style>


<div id="print-section">
            <?php
      if(isset($student_data)){
       $studentID= $student_data->id;
}
        ?>
  <center>
            <div class="container">
             <div class="img"> <img src="<?php  echo $source; ?>"  style="background: white;width: 12%;height: 10%" ></div>
            <div class="mt-2"><b><?= $logo[0]->company_name; ?> </b></div>
            <div class="modify"><?= $logo[0]->address; ?></div>
            <div class="mb-2">
                <div><span class="modify">Phone: <?= $logo[0]->phone1; ?>, Email: <?= $logo[0]->email; ?>, <?= $logo[0]->website; ?></span></div>
             
            </div>
            </div>

        </center>
                   <hr style="color:black;">
              <center>
             <div class="modify text-center" style="font-size: 12px;">
                <span><b> STUDENTS ACADEMIC REPORT</b></span><br>
                <span><b> Academic Year: </b><?=esc($year);?></span>
                <i><b>Due Date: </b><?php echo date('d/m/Y');?></i>
                <i><b>Report Type: </b><?php echo esc($exam_type_label);?></i>

            </div>
            </center>
              <hr style="color:black;">
    <!----------------------------------------------------------------->
    <div class="container"><div  class="table-responsiv">
    <div class="row" style="font-size: 12px;">
        <div class="col-md-12">
                  <?php
      if(isset($student)){


        ?>
            <span>Jina Kamili la Mwanafunzi: <b><u><?=$student->full_name;?></u></b> umri: <b><u><?= findAge($student->birth_date);?></u></b>
         Jinsi: <b><u><?=$student->gender;?> <i>(
            <?php
            if ($student->gender=='Male') {
                ?>
                <?='ME'?>
           
            
            <?php
        }
           else if($student->gender=='Female'){
            ?>
           <?='K'?>
            <?php
           }  ?> ) </i> </u></b>  Darasa: <b><u><?=$student->class_name;?></u></b> mkondo: <b><u> <?=$student->stream_name;?></u></b>  Tahasusi (combination): <b><u><?=esc($combname);?></u></b>
             </span>
            
        </div>
    
        <div class="col-md-12">
<?php
$total_subject_average = 0;
$subject_with_average = 0;
?>

<?php if (isset($classdata)):
    $i = 0;
    foreach ($classdata as $data):
        $i++;
        $total_marks = 0;
        $marks_count = 0;
        $total_points = 0;
?>

    <?php if (isset($exams)): ?>
        <?php foreach ($exams as $info): ?>
            <?php
                $marks = '-';
                $grade_name = '-';

                if (isset($results)) {
                    foreach ($results as $r) {
                        if ($r->exam_id == $info->exam_id && $r->subject_id == $data->subject_id) {
                            $marks = $r->marks_scored;
                            $grade_name = $r->grade_name;

                            foreach ($gradeBoundaries as $boundary) {
                                if ($marks >= $boundary->lower_performance && $marks <= $boundary->upper_performance) {
                                    $points = $boundary->division_point;
                                    break;
                                }
                            }

                            if ($marks !== '-') {
                                $total_marks += $marks;
                                $marks_count++;
                                $total_points += $points ?? 0;
                            }

                            break;
                        }
                    }
                }
            ?>
        <?php endforeach; ?>
    <?php endif; ?>

    <?php
        $average = $marks_count > 0 ? $total_marks / count($exams) : 0;
        if ($marks_count > 0) {
            $total_subject_average += $average;
            $subject_with_average++;
        }
        $averageGrade = '';
        $averageComment = '';
        foreach ($gradeBoundaries as $boundary) {
            if ($average >= $boundary->lower_performance && $average <= $boundary->upper_performance) {
                $averageGrade = $boundary->grade_name;
                $averageComment = $boundary->comments;
                break;
            }
        }
    ?>

<?php
     if ($average !== '') {
                    $subjectPointsMap[] = [
                        'marks' => $average,
                        'point' => getSubjectPoint($average, $gradeBoundaries)
                    ];
                }
if(isset($government_level) && !empty($government_level)){
if ($government_level == 3) {
    usort($subjectPointsMap, function ($a, $b) {
        return $b['marks'] <=> $a['marks'];
    });

   

} }
 
    endforeach;
 $best7 = array_slice($subjectPointsMap, 0, 7);
    $o_level_total_points = array_sum(array_column($best7, 'point'));
    $o_level_division = getDivisionFromPoints($o_level_total_points, 3);
endif;
?>
<?php
if ($subject_with_average > 0) {
    $overall_averageGrade='';
    $overall_average = $total_subject_average / $subject_with_average;
         foreach ($gradeBoundaries as $boundary) {
            if ($overall_average >= $boundary->lower_performance && $overall_average <= $boundary->upper_performance) {
                $overall_averageGrade = $boundary->grade_name;
              
                break;
            }
        }
        if($government_level == 4) {
$studentSubjectAverages = [];

foreach ($classdata as $data) {
    $subject_id = $data->subject_id;
    $total_marks = 0;
    $marks_count = 0;

    foreach ($exams as $exam) {
        foreach ($results as $res) {
            if ( $res->exam_id == $exam->exam_id && $res->subject_id == $data->subject_id && $res->student_id == $student->id) {
                $total_marks += $res->marks_scored;
                $marks_count++;
                break;
            }
        }
    }

    if ($marks_count > 0) {
        $average = $total_marks / count($exams);
        $studentSubjectAverages[$subject_id] = $average;
    }
}
$allSubjects = array_filter($classdata, function ($data) {
        return $data->selection == 1;
    });
$a_level_total_points = calculateAverageALevelPoints($allSubjects, $studentSubjectAverages, $gradeBoundaries);
$a_level_division = getDivisionFromPoints($a_level_total_points, $government_level);
}

}
?>

<span>Amepata alama: <b><u><?= esc(round($total_subject_average,0)); ?></u></b> Sawa na wastani wa alama: <b><u><?= esc(round($overall_average, 1)); ?></u></b> Daraja: <b><u><?= esc($overall_averageGrade); ?></u></b>  

       <?php if(isset($government_level) && !empty($government_level)){
       if($government_level==3){
       ?>
       Division: <b><u><?= $o_level_division; ?></u></b> ya point: <b><u><?= $o_level_total_points; ?></u></b>
    <?php
          }elseif($government_level==4){
       ?>
Division: <b><u><?= $a_level_division; ?></u></b> ya point: <b><u><?= $a_level_total_points; ?></u></b>
    <?php
}
elseif($government_level==5 || $government_level==6){
?>
G.P.A: <b><u><?= esc($overall_averageGrade); ?></u></b> Points: <b><u><?= $total_points ?></u></b>
<?php
}if($government_level==1 || $government_level==2){
    ?>

    <?php

}
}
    ?>
    Nafasi yake darasani: <b><u><?= esc($postion);  ?></u></b> Kati ya wanafunzi: <b><u><?= esc($TotalStudents);  ?></u></b>

</span>

        </div>
        <hr style="color:black;">
    </div>
       <div class="  table-responsive">
<!-- =============================================subject performance table======================================= -->
     <table style="width:100%">
    
<?php
}
?>
    <thead>
        <tr>
            <th colspan="2" class="text-center">Subjects Data</th>
            <th colspan="7" class="text-center term1">First Academic Term</th>
            <th colspan="7" class="text-center term2">Second Academic Term</th>
        </tr>
        <tr>
            <th>No</th>
            <th>Subject</th>

            <?php foreach ($exams_term1 as $exam1): ?>
                <th class="term1">
                                       <?php
$exam_name = $exam1->exam_name;
$words = explode(' ', $exam_name);
$first = isset($words[0]) ? substr($words[0], 0, 4) : '';
$second = isset($words[1]) ? substr($words[1], 0, 4) : '';
echo esc($first.'..'." " . $second);
                    ?>
                </th>
            <?php endforeach; ?>
            <th class="term1">AVG(%)</th>
            <th class="term1">Position</th>
            <th class="term1">Grade</th>
            <th class="term1">Comments</th>
            <?php foreach ($exams_term2 as $exam2): ?>
            <th class="term2">
                    <?php
$exam_name = $exam2->exam_name;
$words = explode(' ', $exam_name);
$first = isset($words[0]) ? substr($words[0], 0, 4) : '';
$second = isset($words[1]) ? substr($words[1], 0, 4) : '';
echo esc($first.'..'." " . $second);
                    ?>
                </th>
            <?php endforeach; ?>
            <th class="term2">AVG(%)</th>
            <th class="term2">Position</th>
            <th class="term2">Grade</th>
            <th class="term2">Comments</th>
        </tr>
    </thead>
                <?php
//return;
?>
    <tbody>


        <?php
        $allTerm1Subjects = [];
$Term1_TotalPoint = 0;
        $core_total_points = 0;
if (isset($classdata)):
       $i=0;
    foreach ($classdata as $data):
        $i++;
        $total_marks = 0;
    $marks_count = 0;
    $total_points = 0;
    $exam_number = 0;

?>
    <tr>
        <td><?= $i; ?></td>
        <td><?= $data->subject_name; ?></td>
        <?php if (isset($exams_term1)): ?>
       <?php foreach ($exams_term1 as $info): ?>
            <?php
                $marks = '-';
                $grade_name = '-';
            if(isset($Mid1subjectAverages)){
                foreach ($Mid1subjectAverages as $result) {
                    if ($result->exam_type_id == $info->exam_id && $result->subject_id == $data->subject_id && $result->student_id == $studentID) {
                        $marks = $result->avg_marks;
                        foreach ($gradeBoundaries as $boundary) {
                            if ($marks >= $boundary->lower_performance && $marks <= $boundary->upper_performance) {
                                $points = $boundary->division_point;
                                break;
                            }
                        }

                        if ($marks !== '-') {
                            $total_marks += $marks;
                            $marks_count++;
                            $total_points += $points ?? 0;
                            $exam_number++;
                        }

                        break;
                    }
                }
            }
            ?>
            <?php if($marks !== '-'){?>
            <td class="term1"><?= number_format($marks, 0); ?></td>
            <?php
               }else{
            ?>
            <td class="term1"><?= $marks; ?></td>
            <?php
        }?>
        <?php endforeach; ?>

        <?php endif; ?>
      <?php
            $average = $marks_count > 0 ? $total_marks /  $exam_number : '-';
            $averageGrade = '';
            $averageComment = '';
             $averagePoint1=0;
              $subjectsWithPoints1 = [];
            foreach ($gradeBoundaries as $boundary) {
                if ($average >= $boundary->lower_performance && $average <= $boundary->upper_performance) {
                    $averageGrade = $boundary->grade_name;
                    $averageComment = $boundary->comments;
                    break;
                }
            }
               if(isset($government_level)){
            if($government_level==4){

                //---A-level---
                  if ($data->selection == 1) {
                        foreach ($gradeBoundaries as $boundary) {
                            if ($average >= $boundary->lower_performance && $average <= $boundary->upper_performance) {
                                $averagePoint1  += $boundary->division_point;
                                break;
                            }}}
            $Term1_TotalPoint += $averagePoint1;
        }
}
$term1_division = getDivisionFromPoints($Term1_TotalPoint, $government_level);
     

     if($average != '-'){
        $term1=1;
        ?>
       <td class="term1">
<a href="javascript:void(0)" onclick="AverageModalOpen(<?=$data->subject_id;?>,<?=esc($government_level);?>,<?=esc($year)?>,<?=esc($classlevel)?>,<?=esc($class)?>,<?=esc($stream)?>,<?=$term1;?>)"><?= number_format($average, 1); ?></a>
       </td>
       <?php 
} else{
    echo '<td class="term1">-</td>';
}
       $found = false;
if(isset($subject_position_term1 )){
    foreach ($subject_position_term1 as $sp) {
        if ($sp['subject'] == $data->subject_id && $sp['student_id'] == $studentID) {
            echo '<td class="term1">' . esc($sp['position']) . '</td>';
            $found = true;
            break;
        }
    }
}
if (!$found){
     echo '<td class="term1"> - </td>';
}

?>

        <td class="term1"><?= $averageGrade; ?></td>
        <td class="term1"><?=$averageComment?></td>


<!-- ==================================Term 2=============================================== -->
    <?php
$total_marks2 = 0;
$marks_count2 = 0;
$total_points2 = 0;
$exam_number2 = 0;
?>
        <?php if (isset($exams_term2)): ?>
            <?php
            ?>
       <?php foreach ($exams_term2 as $info): ?>
            <?php
                $marks2 = '-';
                $grade_name2 = '-';
            if(isset($Mid2subjectAverages)){
                foreach ($Mid2subjectAverages as $result) {
                    if ($result->exam_type_id == $info->exam_id && $result->subject_id == $data->subject_id && $result->student_id == $studentID) {
                        $marks2 = $result->avg_marks;
                        foreach ($gradeBoundaries as $boundary) {
                            if ($marks >= $boundary->lower_performance && $marks <= $boundary->upper_performance) {
                                $points = $boundary->division_point;
                                break;
                            }
                        }
                        if ($marks2 !== '-') {
                            $total_marks2 += $marks2;
                            $marks_count2++;
                             $exam_number2++;
                        }

                        break;
                    }
                }
            }
            ?>
            <?php if($marks2 !== '-'){?>
            <td class="term2"><?= number_format($marks2, 0); ?></td>
            <?php
               }else{
            ?>
            <td class="term2"><?= $marks2; ?></td>
            <?php
        }?>
        <?php endforeach; ?>

        <?php endif; ?>
      <?php
            $average2 = $marks_count2 > 0 ? $total_marks2 /  $exam_number2 : '-';
            $averageGrade = '';
            $averageComment = '';
            $averagePoint=0;
           $Term2_TotalPoint=0;
             $subjectsWithPoints = [];
            foreach ($gradeBoundaries as $boundary) {
                if ($average2 >= $boundary->lower_performance && $average2 <= $boundary->upper_performance) {
                    $averageGrade = $boundary->grade_name;
                    $averageComment = $boundary->comments;
                    break;
                }
            }
       if(isset($government_level)){
            if($government_level==4){
                //---A-level---
                  if ($data->selection == 1) {
                        foreach ($gradeBoundaries as $boundary) {
                            if ($average2 >= $boundary->lower_performance && $average2 <= $boundary->upper_performance) {
                                $averagePoint += $boundary->division_point;
                                $Term2_TotalPoint += $averagePoint;
                                break;
                            }}}
            
        }
}


        ?>
       <?php
  if($average2 != '-'){
    $term2_division = getDivisionFromPoints($Term2_TotalPoint, $government_level);
       ?>

        <td class="term2"><?= number_format($average2, 1); ?></td>
        <?php
        }else{
            $term2_division ='-';
        ?>
        <td class="term2"> - </td>
        <?php
}
        ?>

       <?php 
       $found2 = false;
if(isset($subject_position_term2 )){
    foreach ($subject_position_term2 as $sp) {
        if ($sp['subject'] == $data->subject_id && $sp['student_id'] == $studentID) {
            echo '<td class="term2">' . esc($sp['position']) . '</td>';
            $found2 = true;
            break;
        }
    }
}
if (!$found2){
     echo '<td class="term2"> - </td>';
}

?>

        <td class="term2"><?= $averageGrade; ?></td>
        <td class="term2"><?=$averageComment?></td>
        <?php

    endforeach;
endif;
?>
 </tr>





    </tbody>
</table>
<!-- =============================================subject performance table======================================= -->

</div>
       
        <div class="row" style="display: flex; justify-content: space-between; gap: 20px;">
        <div class="col-md-6" style="flex: 1;">
               <div class="table-responsive">
         <table class="table_info" style="width:100%">
                <tr>
            <td colspan="3" class="centa">UPIMAJI TABIA, KAZI NA MWENENDO</td>
        </tr>

      <tr>
    <th>NAMBA</th>
    <th>TABIA</th>
    <th>GRADE</th>
</tr>

<?php
if (isset($characters)) {
    foreach ($characters as $chara) {
        ?>
        <tr>
                  <td><?= $chara->character_code; ?></td>
            <td><?= $chara->character_name; ?></td>
      

            <?php
            $grade_found = false;
            foreach ($char_report as $report) {
                if ($chara->character_id == $report->character_id) {
                    $grade_found = true;
                    ?>
                    <td class="text-center"><?= $report->grade_name; ?></td>
                    <?php
                    break;
                }
            }

            if (!$grade_found) {
                ?>
                <td><span class="text-danger"><b>NOT FILLED</b></span></td>
                <?php
            }
            ?>
        </tr>
        <?php
    }
}
?>

<tr>
            <td colspan="3" class="centa">A=VIZURI SANA, B=VIZURI, C=WASTANI, D=DHAIFU, E=DHAIFU SANA</td>
        </tr>

    </table>
</div>
        </div>
             <div class="col-md-6" style="flex: 1;">
                <div class="table-responsive">
              <table class="table_info" style="width: 100%;">
                <tr><th colspan="2">MAONI YA UONGOZI</th></tr>
                   <tr>
   
            <td style="width:40%;"><strong>MAONI YA MTAALUMA:</strong></td>
            <td colspan="2" style="width:60%;">VIZURI SANA, AMEFANYA VIZURI SANA</td>
        </tr>
        <tr>
      
            <td style="width:40%;"><strong>MAONI YA MKUU WA SHULE:</strong></td>
            <td colspan="2" style="width:60%;">VIZURI SANA, AMEFANYA VIZURI SANA</td>
        </tr>
         <?php if(isset($government_level) && !empty($government_level)){
       if(in_array($government_level, [1, 2, 3])){

       ?>
        
<?php
$grades=$outputmodel->GetGradeDetails('grades_tbl',1);
?>           <tr>
            <td colspan="2" >
                
                <?php
                foreach($grades as $grade){

                    echo  '<b>'.$grade->grade_name.'</b>';
                    echo ' = ';
                    echo '(';
                     echo $grade->lower_performance;
                     echo '-';
                     echo $grade->upper_performance;
                      echo ') ';
                     echo '<i> '.$grade->comments.'</i>';
                     echo ', ';

                }
                ?>
            </td>
        </tr>
        <tr>
              <td colspan="2" style="word-wrap: break-word; white-space: normal;">
                  
                  division: <b>I</b> = <i> 7 - 17</i>, <b>II</b> = <i>18 - 21</i>, <b>III</b> = <i>22 - 25</i>, <b>IV</b> = <i>26 - 30</i>, <b>0</b> = <i>31 - 35</i>
              </td>
        </tr>
        <?php
    }elseif($government_level==4){
        ?>
        <?php
$grades=$outputmodel->GetGradeDetails('grades_tbl',2);
?> 
   <tr>
            <td colspan="2"  style="word-wrap: break-word; white-space: normal;">
                
                <?php
                foreach($grades as $grade){

                    echo  '<b>'.$grade->grade_name.'</b>';
                    echo ' = ';
                    echo '(';
                     echo $grade->lower_performance;
                     echo '-';
                     echo $grade->upper_performance;
                      echo ') ';
                     echo '<i> '.$grade->comments.'</i>';
                     echo ', ';

                }
                ?>
            </td>
        </tr>
        <tr>
              <td colspan="2" style="word-wrap: break-word; white-space: normal;">
                  
                  division: <b>I</b> = <i> 3 - 9</i>, <b>II</b> = <i>10 - 12</i>, <b>III</b> = <i>13 - 17</i>, <b>IV</b> = <i>18 - 19</i>, <b>0</b> = <i>20 - 25</i>
              </td>
        </tr>

        <?php
    
}}
        ?>
    </table>
    </div>
        </div>
    </div>
    
     
      <!--   <tr>
            <td colspan="8" class="centa">MAELEKEZO</td>
        </tr>
        <tr>
            <td>1</td>
            <td colspan="6">TAREHE YA KUFUNGA SHULE</td>
            <td class="right">11/07/2024</td>
        </tr>
        <tr>
            <td>2</td>
            <td colspan="6">TAREHE YA KUFUNGUA SHULE</td>
            <td class="right">01/04/2025</td>
        </tr> -->
    </div></div>

    <hr>
     <center><div class="mt-1"><i>This is a computer generated document powered by Micro Health Initiative (MHI).</i></div></center> 
 </div>
 <button onclick="printStudentReport()" class="btn btn-primary mt-4"><i class="fa fa-print"></i> Print Report</button>
<div class="modal fade" id="average_details" tabindex="-1" aria-labelledby="averageLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header avgmodal">
        <h4 class="modal-title">Subject Positions</h4>
        <button type="button" class="btn-danger btn-close text-light" onclick="closebarcodemodal(event)">X</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body ">
            <div id="WaitingResultsMsg"></div>
            <div id="fetchresultsFail"></div>
             <div id="res_results"></div>
         </div>
      <div class="modal-footer avgmodal">
          
      </div>
</div>
</div>
</div>

 <script>
function printStudentReport() {
  var printContents = document.getElementById('print-section').innerHTML;
  var win = window.open('', '', 'height=800,width=1000');
  var watermarkUrl = "<?= $source; ?>";

  win.document.write('<html><head><title>Student Report</title>');
  win.document.write('<link rel="stylesheet" href="your-styles.css">');
  win.document.write('<style>');
  win.document.write('@media print {');
  win.document.write('  table { border-collapse: collapse; width: 100%; border: 1px solid black; }');
  win.document.write('  th, td { border: 1px solid black; padding: 8px; text-align: left; font-size: 12px; }');
  win.document.write('  .table.table_info{');
  win.document.write('  font-size: 12px');
  win.document.write('  }');
  win.document.write('  a:link { text-decoration: none;}');
  win.document.write('  a:link { color: black;}');
  win.document.write('  a:visited { text-decoration: none;}');
  win.document.write('  a:visited { color: black;}');
  win.document.write('  a:hover { text-decoration: none;}');
  win.document.write('  a:hover { color: black;}');
  win.document.write('  a:active { text-decoration: none;}');
  win.document.write('  a:active { color: black;}');
  win.document.write('  .table-container {');
  win.document.write('    position: relative;');
  win.document.write('    background-image: url("' + watermarkUrl + '");');
  win.document.write('    background-repeat: no-repeat;');
  win.document.write('    background-position: center;');
  win.document.write('    background-size: 80%;');
  win.document.write('    padding: 20px;');
  win.document.write('  }');
  win.document.write('  -webkit-print-color-adjust: exact;');
  win.document.write('  print-color-adjust: exact;');
  win.document.write('}');
  win.document.write('</style>');

  win.document.write('</head><body>');
  win.document.write(printContents);
  win.document.write('</body></html>');
  
  win.document.close();
  win.focus();
  win.print();
  win.close();
}
    

function AverageModalOpen(subject_id,government_level,year,classlevel,class_id,stream,term){
    var subject_id=subject_id;
    var class_id=class_id;
    var stream=stream;
    var classlevel=classlevel;
    var government_level=government_level;
    var year=year;
    var term=term;
    $('#average_details').modal('show');
    $('#average_details').on('shown.bs.modal', function () {
        $('.modal-backdrop').not('.modal-stack').addClass('modal-stack');
        $(this).addClass('modal-stack');
    });
            $.ajax({
             url: '<?php echo base_url() . '/get-subject_position'; ?>',
            type: 'post',
            data: {subject_id:subject_id,class_id:class_id,stream:stream,classlevel:classlevel,government_level:government_level,year:year,term:term},
                      beforeSend:function(){
            $('#WaitingResultsMsg').html('<span class="fa fa-spinner fa-spin"></span> Loading information, Please wait....');
             $('#fetchresultsFail').html('');
                 $('#res_results').html('')
            },         
            success:function(response){
                $('#fetchresultsFail').html('');
                     $('#WaitingResultsMsg').html('');
                        $('#res_results').html(response)
            },
          error: function (xhr, status, error) {
        $('#fetchresultsFail').html('<div class="alert alert-warning">Failed to fetch subject positions. (ERR:500)</div>');
        $('#WaitingResultsMsg').html('');
        $('#res_results').html('');
        console.error("AJAX Error:", status, error)
        }});

}

    function closebarcodemodal(event){
    event.preventDefault();
          $('#average_details').modal('hide');
              setTimeout(function () {
        if ($('.modal.show').length > 0) {
            $('body').addClass('modal-open');
        }
    }, 500);

}



</script>
