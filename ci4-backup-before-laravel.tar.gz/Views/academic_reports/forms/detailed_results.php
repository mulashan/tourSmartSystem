<style> 
    table {
        width: 100%;
        border-collapse: collapse;
        font-family: Arial, sans-serif;
        font-size: 14px;
        text-align: center;
    }
    th, td {
        border: 1.5px solid #000;
        padding: 5px;
        box-sizing: border-box;
    }
    th {
        background-color: #f2f2f2;
        font-weight: bold;
        vertical-align: middle;
        border: 2px solid #000;
    }
    .rotate {
        writing-mode: vertical-rl;
        transform: rotate(180deg);
        white-space: nowrap;
        min-width: 30px;
        border: 2px solid #000;
        box-sizing: border-box;
    }
    .highlight {
        background-color: #fdf1c7;
        border: 2px solid #000;
    }
</style>

<div class="table-responsive">
    <table>
        <thead>
            <tr>
                <th rowspan="3">S/N</th>
                <th rowspan="3">EXAM NO</th>
                <th rowspan="3">NAME</th>
                <th rowspan="3">SEX</th>
                <?php foreach ($subjectsByComb as $comb): ?>
                    <?php foreach ($comb['subjects'] as $subject): ?>
                        <th colspan="<?= count($exams_type) + 3 ?>"><?= strtoupper($subject['subject_name']) ?></th>
                    <?php endforeach; ?>
                <?php endforeach; ?>

                <th colspan="4" class="highlight">RESULT SUMMARY</th>

                <?php if (!empty($character)): ?>
                    <th colspan="<?= count($character) ?>">STUDENT CHARACTER</th>
                <?php endif; ?>
            </tr>

            <tr>
                <?php foreach ($subjectsByComb as $comb): ?>
                    <?php foreach ($comb['subjects'] as $subject): ?>
                        <?php foreach ($exams_type as $exam): ?>
                            <th class="rotate"><?= strtoupper($exam->exam_name) ?></th>
                        <?php endforeach; ?>
                        <th class="rotate">AVERAGE</th>
                        <th class="rotate">GRADE</th>
                        <th class="rotate">POSITION</th>
                    <?php endforeach; ?>
                <?php endforeach; ?>

                <th rowspan="2" class="rotate highlight">TOTAL MARKS</th>
                <th rowspan="2" class="rotate highlight">AVERAGE</th>
                <th rowspan="2" class="rotate highlight">GRADE</th>
                <th rowspan="2" class="rotate highlight">POSITION</th>

                <?php foreach ($character as $char): ?>
                    <th class="rotate"><?= $char->character_code ?></th>
                <?php endforeach; ?>
            </tr>
        </thead>

        <tbody>
            <?php
            $studentAverages = [];
            $studentRows = [];
            $subjectPositions = [];
            foreach ($cl as $student) {
                foreach ($subjectsByComb as $comb) {
                    foreach ($comb['subjects'] as $subject) {
                        $sid = $subject['subject_id'];
                        $subjectResults = $groupedResults[$student->id][$sid] ?? [];
                        $sum = 0;
                        $count = 0;
                        foreach ($exams_type as $exam) {
                            $examId = $exam->exam_id;
                            $sum += $subjectResults[$examId]['marks'] ?? 0;
                            $count++;
                        }
                        $average = $count > 0 ? round($sum / $count, 1) : 0;
                        $subjectPositions[$sid][$student->id] = $average;
                    }
                }
            }
            $subjectWiseRank = [];
            foreach ($subjectPositions as $sid => $averages) {
                arsort($averages);
                $prevScore = null;
                $rank = 1;
                $tieCount = 0;
                $totalRanks = 0;

                foreach ($averages as $studentId => $avg) {
                    if ($avg === $prevScore) {
                        $tieCount++;
                    } else {
                        $rank = $totalRanks + 1;
                        $tieCount = 1;
                    }
$subjectWiseRank[$sid][$studentId] = $rank;

                    $prevScore = $avg;
                    $totalRanks++;
                }
            }
            $i = 0;
            foreach ($cl as $student) {
                $i++;
                $totalMarks = 0;
                $subjectCount = 0;
                $subjectGrades = [];
                ob_start();
            ?>
                <tr>
                    <td><?= $i ?></td>
                    <td><?= $student->exam_number ?? '-' ?></td>
                    <td style="text-align: left;"><?= $student->full_name ?></td>
                    <td><?= $student->gender == 'Male' ? 'M' : 'F' ?></td>

                    <?php foreach ($subjectsByComb as $comb): ?>
                        <?php foreach ($comb['subjects'] as $subject): 
                            $sid = $subject['subject_id'];
                            $subjectResults = $groupedResults[$student->id][$sid] ?? [];
                            $sum = 0;
                            $count = 0;
                            foreach ($exams_type as $exam) {
                                $examId = $exam->exam_id;
                                $sum += $subjectResults[$examId]['marks'] ?? 0;
                                $count++;
                            }
                            $average = $count > 0 ? round($sum / $count, 1) : 0;
                            $grade = getGradeFromAvg($average, $gradeBoundaries);
                            $subjectGrades[] = $grade;
                            $totalMarks += $average;
                            $subjectCount++;
                        ?>
                            <?php foreach ($exams_type as $exam): 
                                $examId = $exam->exam_id;
                                $marks = $subjectResults[$examId]['marks'] ?? 0;
                            ?>
                                <td>&nbsp;<?= $marks ?>&nbsp;</td>
                            <?php endforeach; ?>
                            <td>&nbsp;<?= $average ?>&nbsp;</td>
                            <td>&nbsp;<?= $grade ?>&nbsp;</td>
                            <td>&nbsp;<?= $subjectWiseRank[$sid][$student->id] ?? '-' ?>&nbsp;</td>
                        <?php endforeach; ?>
                    <?php endforeach; ?>

                    <?php
                        $averageMark = $subjectCount > 0 ? round($totalMarks / $subjectCount, 1) : 0;
                        $finalGrade = getGradeFromAvg($averageMark, $gradeBoundaries);
                        $divisionInfo = getDivisionAndPoints($subjectGrades, $gradesTable);
                        $studentAverages[$student->id] = $averageMark;

                        $studentRow = ob_get_clean();
                        $studentRows[$student->id] = [
                            'row' => $studentRow,
                            'totalMarks' => $totalMarks,
                            'average' => $averageMark,
                            'grade' => $finalGrade,
                            'division' => $divisionInfo,
                            'student' => $student,
                        ];
                    ?>
                </tr>
            <?php } ?>

            <?php
          
            arsort($studentAverages);
$positions = [];
$prevScore = null;
$rank = 1;
$tiedStudents = [];
$tiedRank = null;

foreach ($studentAverages as $studentId => $avg) {
    if ($avg === $prevScore) {
        $tiedStudents[] = $studentId;
    } else {
        if (count($tiedStudents) > 1) {
            $tiePosition = $tiedRank + 0.5;
            foreach ($tiedStudents as $id) {
                $positions[$id] = $tiePosition;
            }
        } elseif (count($tiedStudents) == 1) {
            $positions[$tiedStudents[0]] = $tiedRank;
        }

        $tiedStudents = [$studentId];
        $tiedRank = $rank;
        $prevScore = $avg;
    }
    $rank++;
}
if (count($tiedStudents) > 1) {
    $tiePosition = $tiedRank + 0.5;
    foreach ($tiedStudents as $id) {
        $positions[$id] = $tiePosition;
    }
} elseif (count($tiedStudents) == 1) {
    $positions[$tiedStudents[0]] = $tiedRank;
}

            if(isset($studentRows)):
                foreach ($studentRows as $id => $info):
                    echo $info['row'];
            ?>
                <td>&nbsp;<?= $info['totalMarks'] ?>&nbsp;</td>
                <td>&nbsp;<?= $info['average'] ?>&nbsp;</td>
                <td>&nbsp;<?= $info['grade'] ?>&nbsp;</td>
                <td>&nbsp;<?= $positions[$id] ?? '-' ?>&nbsp;</td>

                <?php foreach ($character as $char): ?>
                    <td>&nbsp;<?= $characterData[$id][$char->character_id] ?? '-' ?>&nbsp;</td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
