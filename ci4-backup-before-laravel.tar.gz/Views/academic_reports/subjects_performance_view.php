          <?php  
$imodel = new App\Models\ItemsModel();
 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
 ?>
           <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Subjects Wise Performance</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Subjects Wise Performance</li>
                </ol>
            </div>
         </div><br><br>
          <!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="box box-danger">
           
            <div class="box-body">
          <div class="container mt-4">
    <form id="getReport1" class="row g-3 needs-validation" novalidate>

        <!-- Row 1 -->
        <div class="col-md-2">
            <label for="year" class="form-label">Academic Year:</label>
            <select id="year" name="year" class="form-select" required>
                <script>
                    const currentYear = new Date().getFullYear();
                    const startYear = 2023;
                    for (let year = currentYear + 1; year >= startYear; year--) {
                        if (year === currentYear) {
                            document.write(`<option value="${year}" selected>${year}</option>`);
                        } else {
                            document.write(`<option value="${year}">${year}</option>`);
                        }
                    }
                </script>
            </select>
            <div class="invalid-feedback">Academic Year is required.</div>
        </div>

        <div class="col-md-3">
            <label for="classlevel" class="form-label">Level:</label>
            <select class="form-select" name="classlevel" id="classlevel" required>
                <option value="" selected disabled>--Select Level--</option>
                <?php
                $l = $remodel->get_levels();
                foreach ($l as $le) {
                    echo '<option value="' . $le->id . '">' . $le->level_name . '</option>';
                }
                ?>
            </select>
            <div class="invalid-feedback">Class Level is required.</div>
        </div>

        <div class="col-md-3">
            <label for="class" class="form-label">Class:</label>
            <select class="form-select" name="class" id="class" required>
                <option value="" selected disabled>--Require Level first--</option>
            </select>
            <div class="invalid-feedback">Class is required.</div>
        </div>

        <!-- Row 2 -->
        <div class="col-md-2">
            <label for="stream" class="form-label">Stream:</label>
            <select class="form-select" name="stream" id="stream" required>
                <option value="" selected disabled>--Require Level first--</option>
            </select>
            <div class="invalid-feedback">Stream is required.</div>
        </div>

        <div class="col-md-2">
            <label for="status" class="form-label">Status:</label>
            <select id="status" name="status" class="form-select" required>
                <option value="0">All</option>
                <option value="1">Pending</option>
                <option value="2" selected>Admitted</option>
                <option value="4">Graduates</option>
                <option value="3">Transferred</option>
                <option value="5">Absconded</option>
            </select>
            <div class="invalid-feedback">Status is required.</div>
        </div>

        <!-- Submit Button -->
        <div class="col-12 text-center mt-3">
            <button type="submit" class="btn btn-primary px-5">Create</button>
        </div>

    </form>
</div>


                
                 <hr>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>
           
            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
</div>
</div>
<script type="text/javascript">
       $("#year").change(function(){
        var year = $(this).val();
        $.ajax({
            url: 'list_terms',
            type: 'post',
            data: {year:year},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#terms").empty();
                $("#terms").append("<option value='' disabled selected>--Choose term--</option>");
                $("#terms").append("<option value='0'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['term_name'];
                   
                   $("#terms").append("<option value='"+id+"'>"+name+"</option>");
                }
            }
        });
    });
   $("#classlevel").change(function(){
        var clvl = $(this).val(); 
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value='' selected disabled>--Choose Class--</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#class").append("<option value='"+id+"'>"+name+"</option>");
                }
            }
        });
    });

        $("#class").change(function(){
        var clvl = $(this).val(); 
        $.ajax({
             url: '<?php echo base_url() . '/index.php/StudentController/get_stream_details'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#stream").empty();
                $("#stream").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    $("#stream").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });
     $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });
   $('#getReport1').submit(function (e) {
            $(this).serialize();
       e.preventDefault();
    if (!this.checkValidity()) {
        this.classList.add("was-validated");
        return;
             }
            
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "class=" + $('#class option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&year="+$('#year option:selected').val()+ "&examtypes="+$('#examtypes option:selected').val()+ "&terms="+$('#terms option:selected').val()+ "&status="+$('#status option:selected').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/SubjectWisePerformance'; ?>',

                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
  
    function viewBalanceReport(stid,sid,yr) {
       // alert('stid= '+stid+' id= '+sid);
       var datta = "stid=" + stid+ "&sid="+sid+"&year="+yr;;
        $('#myModalview').modal('show');
      $.ajax({
            type: "POST",
           // url: "<?= base_url('/student_collection_report')?>",
             url: '<?php echo base_url() . '/index.php/ReportsController/view_student_balance'; ?>',
            data: datta,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);
               
            },
            error: function ()
            {

            }
        });
    };

function searchnamebtn(){
            var name=$('#search_name').val();
            var  year=$('#button-y').html();
            if(name.length >=3){
                $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
                var dta="name="+name+"&year="+year;
             $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/search_name'; ?>",
                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
        }else{
            if(name.length==0){
               $('#Rept1ResultViewResults').html(''); 
            }else{
               $('#Rept1ResultViewResults').html('<div class="alert alert-info">Search atleat 3 characters</div>'); 
            }
        
        }
        }
  </script>