          <?php  
$imodel = new App\Models\ItemsModel();
 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
 ?>
           <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Best Ten and Last Ten Students</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Best Ten and Last Ten Students</li>
                </ol>
            </div>
         </div><br><br>
          <!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="box box-danger">
           
            <div class="box-body">
          <div class="container mt-4">
<div class="row">
    <div class="col-md-6">
    <form id="getReport1" class="row g-3 needs-validation" novalidate>

        <!-- Row 1 -->
        <div class="row mb-4">
            <label for="year" class="col-md-4 form-label">Academic Year:</label>
            <div class="col-md-6">
            <select id="year" name="year" class="top10-select" style="width: 200px;" required>
                <script>
                    const currentYear = new Date().getFullYear();
                    const startYear = 2023;
                    for (let year = currentYear + 1; year >= startYear; year--) {
                        if (year === currentYear) {
                            document.write(`<option value="${year}" selected>${year}</option>`);
                        } else {
                            document.write(`<option value="${year}">${year}</option>`);
                        }
                    }
                </script>
            </select>
            <div class="invalid-feedback">Academic Year is required.</div>
            </div>
            </div>

<div class="row mb-4">
  <label for="reporttypes" class="col-md-4 form-label">Report Type:<span class="text-danger">*</span></label>
  <div class="col-md-6">
    <div class="input-group">
      <button type="button" class="btn btn-default form-control" id="reportrange-btn">
        <span id="selected-report-label">
  <i class="fa fa-clipboard"></i> Select Report Type
</span>

        <i class="fa fa-caret-down float-end"></i>
      </button>
    </div>
    <input type="hidden" name="exam_type_label" id="exam_type_label">
    <input type="hidden" id="exam_type_value" name="exam_type_value">
    <input type="hidden" name="start_date" id="start_date">
    <input type="hidden" name="end_date" id="end_date">
    <div class="invalid-feedback">Examination Report Type is required.</div>
  </div>
</div>
        <div class="row mb-4">
            <label for="classlevel" class="form-label col-md-4">Level:</label>
            <div class="col-md-6">
            <select class="top10-select" name="classlevel" id="classlevel" style="width: 200px;" required>
                <option value="" selected disabled>--Select Level--</option>
                <?php
                $l = $remodel->get_levels();
                foreach ($l as $le) {
                    echo '<option value="' . $le->id . '">' . $le->level_name . '</option>';
                }
                ?>
            </select>
            <div class="invalid-feedback">Class Level is required.</div>
        </div>
        </div>

        <div class="row mb-4">
            <label for="class" class="form-label col-md-4">Class:</label>
              <div class="col-md-6">
            <select class="top10-select" name="class" id="class" style="width: 200px;" required>
                <option value="" selected disabled>--Require Level first--</option>
            </select>
            <div class="invalid-feedback">Class is required.</div>
        </div>
        </div>

        <!-- Row 2 -->
        <div class="row mb-4">
            <label for="stream" class="col-md-4 form-label">Stream:</label>
            <div class="col-md-6">
            <select class="top10-select" name="stream" id="stream" style="width: 200px;" required>
                <option value="" selected disabled>--Require Level first--</option>
            </select>
            <div class="invalid-feedback">Stream is required.</div>
        </div>
        </div>

        <div class="row mb-4">
            <label for="status" class="col-md-4 form-label">Status:</label>
            <div class="col-md-6">
            <select id="status" name="status" class="top10-select" style="width: 200px;" required>
                <option value="0">All</option>
                <option value="1">Pending</option>
                <option value="2" selected>Admitted</option>
                <option value="4">Graduates</option>
                <option value="3">Transferred</option>
                <option value="5">Absconded</option>
            </select>
            <div class="invalid-feedback">Status is required.</div>
        </div>
        </div>

        <!-- Submit Button -->
        <div class="col-12 text-center mt-3">
            <button type="submit" class="btn btn-primary px-5">Create</button>
        </div>

    </form>
       </div>
</div>
</div>


                
                 <hr>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>
           
            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
</div>
</div>
<script type="text/javascript">
       $("#year").change(function(){
        var year = $(this).val();
        $.ajax({
            url: 'list_terms',
            type: 'post',
            data: {year:year},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#terms").empty();
                $("#terms").append("<option value='' disabled selected>--Choose term--</option>");
                $("#terms").append("<option value='0'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['term_name'];
                   
                   $("#terms").append("<option value='"+id+"'>"+name+"</option>");
                }
            }
        });
    });
   $("#classlevel").change(function(){
        var clvl = $(this).val(); 
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value='' selected disabled>--Choose Class--</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#class").append("<option value='"+id+"'>"+name+"</option>");
                }
            }
        });
    });

        $("#class").change(function(){
        var clvl = $(this).val(); 
        $.ajax({
             url: '<?php echo base_url() . '/index.php/StudentController/get_stream_details'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#stream").empty();
                $("#stream").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    $("#stream").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });
   $('#getReport1').submit(function (e) {
            $(this).serialize();
       e.preventDefault();
    if (!this.checkValidity()) {
        this.classList.add("was-validated");
        return;
             }
            
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var formData = $(this).serialize();
            // var dta = "class=" + $('#class option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&year="+$('#year option:selected').val()+ "&examtypes="+$('#examtypes option:selected').val()+ "&terms="+$('#terms option:selected').val()+ "&status="+$('#status option:selected').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/FetchTop10Reports'; ?>',

                data: formData,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
  
    function viewBalanceReport(stid,sid,yr) {
       // alert('stid= '+stid+' id= '+sid);
       var datta = "stid=" + stid+ "&sid="+sid+"&year="+yr;;
        $('#myModalview').modal('show');
      $.ajax({
            type: "POST",
           // url: "<?= base_url('/student_collection_report')?>",
             url: '<?php echo base_url() . '/index.php/ReportsController/view_student_balance'; ?>',
            data: datta,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);
               
            },
            error: function ()
            {

            }
        });
    };

function searchnamebtn(){
            var name=$('#search_name').val();
            var  year=$('#button-y').html();
            if(name.length >=3){
                $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
                var dta="name="+name+"&year="+year;
             $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/search_name'; ?>",
                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
        }else{
            if(name.length==0){
               $('#Rept1ResultViewResults').html(''); 
            }else{
               $('#Rept1ResultViewResults').html('<div class="alert alert-info">Search atleat 3 characters</div>'); 
            }
        
        }
        }
           function initDateRangePicker(year) {
    var start = moment(`${year}-01-01`);
    var end = moment(`${year}-12-31`);

    // Full range with exam type ID
    const fullRanges = {
        'First Midterm': [2, moment(`${year}-03-01`), moment(`${year}-03-31`)],
        'Terminal Report': [3, moment(`${year}-01-01`), moment(`${year}-06-30`)],
        'Second Midterm': [5, moment(`${year}-09-01`), moment(`${year}-09-30`)],
        'Annual Report': [4, moment(`${year}-07-01`), moment(`${year}-11-30`)],
        'Whole Year': [0, start, end]
    };

    // Create a simplified ranges object for daterangepicker
    let displayRanges = {};
    for (let label in fullRanges) {
        const [, startDate, endDate] = fullRanges[label];
        displayRanges[label] = [startDate, endDate];
    }

    function cb(start, end, label) {
        const formattedRange = `${start.format('YYYY/MM/DD')} - ${end.format('YYYY/MM/DD')}`;

        if (label && fullRanges[label]) {
            const [examType] = fullRanges[label];
             $('#selected-report-label').html(`<i class="fa fa-clipboard"></i> ${label}`);
             $('#report_title').html(` ${label}`);
            $('#reportrange-text').html(`${label} (${formattedRange})`);
            $('#exam_type_label').val(label);
            $('#exam_type_value').val(examType);
        } else {
              $('#selected-report-label').html(`<i class="fa fa-clipboard"></i> ${formattedRange}`);
               $('#report_title').html(` ${label}`);
            $('#reportrange-text').html(`${formattedRange} (Custom Range)`);
            $('#exam_type_label').val('Custom Range');
            $('#exam_type_value').val('custom');
        }

        $('#start_date').val(start.format('YYYY-MM-DD'));
        $('#end_date').val(end.format('YYYY-MM-DD'));
    }

    $('#reportrange-btn').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: displayRanges
    }, cb);

    // Initialize with default range
    cb(start, end, 'Whole Year');
}

$(function () {
    const initialYear = $('#year').val();
    initDateRangePicker(initialYear);
});

$('#year').change(function () {
    const selectedYear = $(this).val();
    initDateRangePicker(selectedYear);
});


      $(document).ready(function() {
        $(".top10-select").select2();
    });
  </script>