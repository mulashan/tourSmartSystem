          <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
 ?>
           <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Reports</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Application List Report</li>
                </ol>
            </div>
         </div><br><br>
          <!----------------------------------------------------another code here----------------->
       <div class="tab-pane active" id="inv-all">
               <div class="input-group ms-3 me-3 mb-3 d-flex justify-content-center">
                           <form id="Rept1Result2" class="form-inline">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </form>
                        </div>
                
                <div class="d-flex justify-content-center">
                <div id="messageDisplayArea"></div>
                    <form id="Rept1Result" class="form-inline">
                      
                        Level: 
                <select class="form-control form-select me-3" name="classlevel" id="classlevel">
                                <option value="0">All</option>
                                <?php
                               $l = $remodel->get_levels();
                              foreach($l as $le){
                               echo '<option value="' . $le->id . '">' . $le->level_name . '</option>'; 
                              }

                               ?>
                            </select>

                             Class: 
                        <select class="form-control form-select me-3" name="class" id="class">
                                <option value="0">All</option>
                                <?php
                               $c = $remodel->get_classes1();
                              foreach($c as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->class_name . '</option>'; 
                              }

                               ?>
                            </select>

                             Payment Status: 
                       <select class="form-control form-select" name="status" id="status">
                            <option value="2">All</option>
                            <option value="0">Paid</option>
                            <option value="1">Unpaid</option>
                          
                            </select>

                            <button type="submit" class="btn btn-primary ms-3">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                
                <center>
                    <div id="application_results"></div>
                </center>
            </div>
</div>
<!-- View Modal -->
 
<script type="text/javascript">
$(document).ready(function () {
      $('#myTable2').DataTable();
    });
    
      $("#classlevel").change(function(){
        var clvl = $(this).val(); 
        ///alert(clvl); 
         
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    $("#class").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });
     $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });
    $('#Rept1Result').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            //$('#RecptResult').html('Please specify valid date.');
                alert('Please specify valid date.');
        } else {
            $('#application_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn span').html()+'&'+ $('#Rept1Result').serialize();
           // alert(dta);
            // return;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/process_application_report' ?>',
                 data: dta,
                success: function (res) {
                    $('#application_results').html(res);
                },
                error: function () {
                    $('#application_results').html('<div class="alert alert-warning">Fail to retreive results.!!</div>');
                }
            });

}
        e.preventDefault();
    });
   
  $("#classlevel").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#class").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });
</script>