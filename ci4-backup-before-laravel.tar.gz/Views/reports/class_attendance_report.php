
<?php  

 $remodel = new App\Models\ReportsModel();
 $classList=$remodel->get_classes1();
 $schoolname=$remodel->get_schoolname();
 ?>
 <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Attendance Report</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                        <?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
                    </a></li>
                    <li class="breadcrumb-item active" aria-current="page">Class Attendance Report</li>
                </ol>
            </div>
         </div><br>
          <!----------------Class list attendance start code here----------------->
<div class="container-fluid">
    <div class="col-lg-12">
        <div class="card">
            
            <div class="card-body">
                <form id="manage-attendance">
                    <input type="hidden" name="id" value="">
                    <div class="row justify-content-center">
                        
                        <div class="col-sm-2">
                            <select name="class" id="class" class="custom-select select2 input-sm" required="required">
                                <option value="">-select class-</option>
                              <?php
                            $clist=$remodel->get_classes1();
                            foreach($clist as $list){
                               ?>
                                <option value="<?=$list->id;?>"><?=$list->class_name;?></option>
                                <?php }?>
                            </select>
                        </div>
                        <!---------------------------------------------->
                         <div class="col-sm-2">
                            <select name="stream" id="level" class="custom-select select2 input-sm" required="required">
                                <option value="">-select stream-</option>
                              
                            </select>
                        </div>
                         <!------------------------------------------------>
                        <!--  <div class="col-sm-1">
                        	Month of
						</div>
                        <div class="col-sm-2">
                        	<input type="month" name="doc" id="doc" value="<?php echo date('Y-m') ?>" class="form-control">
						</div> -->
                        <!---------------------------------------------->
                          <div class="col-sm-3" >
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                        <!---------------------------------------------->
                        <div class="col-sm-2">
                            <select name="time" id="session" class="custom-select select2 input-sm" required="required">
                                <option value="">-select session-</option>
                                <option value="0">All</option>
                                <option value="1">Morning</option>
                                <option value="2">Afternoon</option>
                                <option value="3">Night</option>
                              
                            </select>
                        </div>
                         <!------------------------------------------------>
                         <div class="col-sm-2">
							<button class="btn  btn-primary" type="button" id="filter">Filter</button>
						</div>
                        </div>                         <!------------------------------------------------>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12" id='att-list'>
                            
                        </div>
                        <div class="col-md-12"  style="display: none" id="submit-btn-field">
							<center>
								<button class="btn btn-success btn-sm col-sm-3" type="button" id="print_att"><i class="fa fa-print"></i> Print</button>
							</center>
						</div>
					</div>
                </form>
            </div>
        </div>
    </div>
</div>
<div id="table_clone" style="display: none;" >
	<center>
	<h5><?php echo $schoolname[0]->company_name; ?> ATTENDANCE REPORT</h5>
	</center>
	<table width="100%" style="margin-left:30px">
		<tr><th></th></tr>
		<tr>
			<td width="50%" style="padding-left:100px">
				<p>Class: <b class="class"></b></p>
				<p>Stream: <b class="stream"></b></p>
				<p>Total Days of Classes: <b class="noc"></b></p>
			</td>
			<td width="50%">
				
				<p>Date From: <b class="doc"></b></p>
				<p>session: <b class="session"></b></p>
			</td>
		</tr>
	</table>
	<table class='table table-bordered table-hover att-list'>
		<thead>
			<tr>
				<th class="text-center" width="5%">#</th>
				<th width="20%">First Name</th>
				<th width="20%">Middle Name</th>
				<th width="20%">Last Name</th>
				<th>Present</th>
				<th>Late</th>
				<th>Absent</th>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
</div>
<!-- <div id="chk_clone" style="display: none">
	<div class="d-flex justify-content-center chk-opts">
		<div class="form-check form-check-inline">
		  <input class="form-check-input present-inp" type="checkbox" value="1" readonly="">
		  <label class="form-check-label present-lbl">Present</label>
		</div>
		<div class="form-check form-check-inline">
		  <input class="form-check-input absent-inp" type="checkbox" value="0" readonly="">
		  <label class="form-check-label absent-lbl">Absent</label>
		</div>
		<div class="form-check form-check-inline">
		  <input class="form-check-input late-inp" type="checkbox" value="2" readonly="">
		  <label class="form-check-label late-lbl">Late</label>
		</div>
	</div>
</div> -->
<style>
	.present-inp,.absent-inp,.late-inp,.present-lbl,.absent-lbl,.late-lbl{
		cursor: pointer;
	}
</style>
<noscript>
	<style>
		table.att-list{
			width:100%;
			border-collapse:collapse
		}
		table.att-list td,table.att-list th{
			border:1px solid
		}
		.text-center{
			text-align:center
		}
	</style>
</noscript>
<script>
 $("#class").change(function(){
    $('#att-list').html('');
    $('#submit-btn-field').hide();

        var clvl = $(this).val(); 
        ///alert(clvl); 
         
        $.ajax({
            url: 'stream_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#level").empty();
                $("#level").append("<option value=''>-select stream-</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['sname'];
                    $("#level").append("<option value='"+id+"'>"+name+"</option>");
                }
            }
        });
    });
	$('#filter').click(function(){
		var cid=$('#class option:selected').val();
        var lid=$('#level option:selected').val();
        
        var sess=$('#session option:selected').val();
        var dta = $('#daterange-btn span').html();
        var dta = "thedate=" + $('#daterange-btn span').html();
        //alert(dta);
        if(cid==""){
            swal('Please! select class and stream');
        }else if(lid==""){
        
             swal('Please! select stream');   
            
        }
        else if(sess==""){
        
             swal('Please! select session');   
            
        }else{
        	$('#att-list').html('<span class="fa fa-spinner fa-spin text-center"></span> Loading...');
        //alert(cid+'/'+lid+'/'+doc+'/'+sess);
		$.ajax({
			 url: '<?php echo base_url() . '/get_attendance_report'; ?>/'+cid+'/'+lid+'/'+1+'/'+sess,
			type:'POST',
			data:dta,
			success:function(resp){
				if(resp){
					
					resp = JSON.parse(resp)
					var _table = $('#table_clone').clone()
					$('#att-list').html('')
					$('#att-list').append(_table)
					var _type = ['Absent','Present','Late'];
					var data = !!resp.data ? resp.data : [] ;
					var record = !!resp.record ? resp.record :[];
					var attendance_id = !!resp.attendance_id ? resp.attendance_id : 0;
					if(Object.keys(data).length > 0){

						var i = 1;
						Object.keys(data).map(function(k){
							var fname = data[k].first_name;
							var mname = data[k].middle_name;
							var lname = data[k].last_name;
							var id = data[k].student_id;
							var tr = $('<tr></tr>')

							// opts.find('.present-inp').attr({'name':'type['+id+']','id':'present_'+id})
							// opts.find('.absent-inp').attr({'name':'type['+id+']','id':'absent_'+id})
							// opts.find('.late-inp').attr({'name':'type['+id+']','id':'late_'+id})

							// opts.find('.present-lbl').attr({'for':'present_'+id})
							// opts.find('.absent-lbl').attr({'for':'absent_'+id})
							// opts.find('.late-lbl').attr({'for':'late_'+id})
							var present=0;
							var	late=0;
							var	absent=0;
							var noc=0;
							console.log(Object.keys(record).length)
							// record = JSON.parse(record)
								if(Object.keys(record).length > 0){
								if(record[id].length > 0){
									Object.keys(record[id]).map(i=>{
										noc=noc+1;
										if(record[id][i].type == 0)
											absent = parseInt(absent) + 1;
										if(record[id][i].type == 1)
											present = parseInt(present) + 1;
										if(record[id][i].type == 2)
											late = parseInt(late) + 1;
									})
								}  
								}  

							tr.append('<td class="text-center">'+(i++)+'</td>')
							tr.append('<td class="">'+(fname)+'</td>')
							tr.append('<td class="">'+(mname)+'</td>')
							tr.append('<td class="">'+(lname)+'</td>')
							var td = '<td class="text-center">';
								td += present;
								td += '</td>';
								td += '<td class="text-center">';
								td += late;
								td += '</td>';
								td += '<td class="text-center">';
								td += absent;
								td += '</td>';
							tr.append(td)

							_table.find('table.att-list tbody').append(tr)
						})
						$('#submit-btn-field').show()
						$('#edit_att').attr('data-id',attendance_id)
					}else{
						alert('no data available');
						$('#att-list').html('<span class=""></span>No data available...');
                         $('#submit-btn-field').hide();
						// 	var tr = $('<tr></tr>')
						// 	tr.append('<td class="text-center" colspan="5">No data.</td>')
						// 	_table.find('table.att-list tbody').append(tr)
						// $('#submit-btn-field').attr('data-id','').hide()
						// $('#edit_att').attr('data-id','')
					} 
					$('#att-list').html('')
					_table.find('.stream').text(!!resp.details.stream ? resp.details.stream : '')
					_table.find('.session').text(!!resp.details.session ? resp.details.session : '')
					_table.find('.class').text(!!resp.details.class ? resp.details.class : '')
					_table.find('.doc').text(!!resp.details.doc ? resp.details.doc : '')
					_table.find('.noc').text(!!resp.details.noc ? resp.details.noc : '')

					_table.find('.noc').text(!!resp.details.noc ? resp.details.noc : '')
					$('#att-list').append(_table.html())
					if(Object.keys(data).length > 0){
						Object.keys(data).map(k=>{
							// console.log('[name="type['+record[k].student_id+']"][value="'+record[k].type+'"]')
							$('#att-list').find('[name="type['+data[k].student_id+']"][value="'+data[k].type+'"]').prop('checked',true)
						})
					}
				}else{
					alert('no data available');
                         $('#att-list').html('<span class=""></span>No data available...');
                         $('#submit-btn-field').hide();
                        //     var tr = $('<tr></tr>')
                        //     tr.append('<td class="text-center" colspan="3">No data.</td>')
                        //     _table.find('tbody').append(tr)
                        // $('#submit-btn-field').hide()
                    } 
			},
			complete:function(){
				$("input[readonly]").on('keyup keypress change',function(e){
					e.preventDefault()
					return false;
				});
				$('#edit_att').click(function(){
					location.href = 'index.php?page=check_attendance&attendance_id='+$(this).attr('data-id')
				})
				end_load()
			}
		})
	}})
	$('#manage-attendance').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'ajax.php?action=save_attendance',
			method:'POST',
			data:$(this).serialize(),
			success:function(resp){
				if(resp==1){
					  alert_toast("Data successfully saved.",'success')
                        setTimeout(function(){
                            location.reload()
                        },1000)
				}else if(resp ==2){
					  alert_toast("Class already has an attendance record with the slected subject and date.",'danger')
					  end_load();
				}
			}
		})
	})
	$('#print_att').click(function(){
		var _c = $('#att-list').html();
		var ns = $('noscript').clone();
		var nw = window.open('','_blank','width=900,height=600')
		nw.document.write(_c)
		nw.document.write(ns.html())
		nw.document.close()
		nw.print()
		setTimeout(() => {
			nw.close()
		}, 500);
	})

	             $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });
</script>