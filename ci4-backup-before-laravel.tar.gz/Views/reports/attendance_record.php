       <?php  

 $remodel = new App\Models\ReportsModel();
 $classList=$remodel->get_classes1();
 $partial = $partial ?? false;
 ?>
 <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<?php if (!$partial) { ?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Attendance</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                        <?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
                    </a></li>
                    <li class="breadcrumb-item active" aria-current="page" id="attendance-breadcrumb">Attendance List</li>
                </ol>
            </div>
            <div id="largeScreenTab">
                <ul class="nav nav-tabs page-header-tab">
                    <li class="nav-item"><a class="nav-link js-attendance-tab active" href="<?php echo base_url('attendance_record')?>" data-url="<?php echo base_url('attendance_record?partial=1')?>" data-title="Attendance List">Attendance List</a></li>
                    <li class="nav-item"><a class="nav-link js-attendance-tab" href="<?php echo base_url('attendance')?>" data-url="<?php echo base_url('attendance?partial=1')?>" data-title="New Attendance">New Attendance</a></li>
                </ul>
            </div>
         </div><br>
         <div id="attendance-tab-content">
<?php } ?>
          <!----------------Class list attendance start code here----------------->
<div class="container-fluid">
    <div class="col-lg-12">
        <div class="card">
            
            <div class="card-body">
                <form id="edit-attendance">
                    <input type="hidden" name="id" value="">
                    <div class="row justify-content-center">
                       <!--  <label for="" class="col-sm-1">Class</label> -->
                        <div class="col-sm-2">
                            <select name="class" id="class" class="custom-select select2 input-sm" required="required">
                                <option value="">All</option>
                              <?php
                            $clist=$remodel->get_classes1();
                            foreach($clist as $list){
                               ?>
                                <option value="<?=$list->id;?>"><?=$list->class_name;?></option>
                                <?php }?>
                            </select>
                        </div>
                        <!---------------------------------------------->
                         <div class="col-sm-2">
                            <select name="stream1" id="level" class="custom-select select2 input-sm" required="required">
                                <option value="">All</option>
                              
                            </select>
                        </div>
                         <!------------------------------------------------>
                        <div class="col-sm-3">
                            <input type="date" name="doc" id="doc" value="<?php echo date('Y-m-d'); ?>" class="form-control">
                        </div>
                        <!---------------------------------------------->
                        <div class="col-sm-2">
                            <select name="time" id="session" class="custom-select select2 input-sm" required="required">
                                <option value="">All</option>
                                <option value="1">Morning</option>
                                <option value="2">Afternoon</option>
                                <option value="3">Night</option>
                              
                            </select>
                        </div>
                         <!------------------------------------------------>
                          <div class="col-sm-2">
                            <button class="btn  btn-primary" type="button" id="filter">Filter</button>
                        </div>
                         <!------------------------------------------------>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12" id='att-list'>
                            
                        </div>
                        <div class="col-md-12"  style="display: none" id="submit-btn-field">
                            <center>
                                <button class="btn btn-primary btn-sm col-sm-3" type="button" id="edit_att"><i class="fa fa-edit" data-id=''></i> Edit</button>
                                <button class="btn btn-success btn-sm col-sm-3" type="button" id="print_att"><i class="fa fa-print"></i> Print</button>
                            </center>
                        </div>
                         <div class="col-md-12"  style="display: none" id="edt-btn-field">
                            <center>
                                <button class="btn btn-primary btn-sm col-sm-3" type="submit" id="edit_save"><i class="fa fa-edit" data-id=''></i> Save</button>
                                
                            </center>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div id="summary_table_clone" style="display: none">
    <table class='table table-bordered table-hover attendance-summary-table'>
        <thead>
            <tr>
                <th>#</th>
                <th>Attendance Date</th>
                <th>Class</th>
                <th>Stream</th>
                <th>Session</th>
                <th>Present</th>
                <th>Absent</th>
                <th>Late</th>
                <th>Attendance by</th>
                <th>Trans Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
</div>
<div id="table_clone" style="display: none">
    <table width="100%" id="table_dis">
        <tr>
            <td width="50%">
                <p>Class: <b class="class_name"></b></p>
                <p>Stream: <b class="stream_name"></b></p>
                
            </td>
            <td width="50%">
                
                <p>Date of Class: <b class="doc"></b></p>
                <p>Session: <b class="session"></b></p>
            </td>
        </tr>
    </table>
    <table class='table table-bordered table-hover att-list'>
        <thead>
            <tr>
                <th class="text-center" width="5%">#</th>
                <th>NAMES</th>
                <th>AGE</th>
                <th>GENDER</th>
                <th>TYPE</th>
                <th>FOR</th>
                <th>ATTENDANCE</th>
            </tr>
        </thead>
        <tbody id="tbody">
        </tbody>
    </table>
</div>

<div id="chk_clone" style="display: none">
    <div class="d-flex justify-content-center chk-opts">
        <div class="form-check form-check-inline">
          <input class="form-check-input present-inp" type="checkbox" value="1" readonly="">
          <label class="form-check-label present-lbl">Present</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input absent-inp" type="checkbox" value="0" readonly="">
          <label class="form-check-label absent-lbl">Absent</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input late-inp" type="checkbox" value="2" readonly="">
          <label class="form-check-label late-lbl">Late</label>
        </div>
    </div>
</div>
<style>
    .present-inp,.absent-inp,.late-inp,.present-lbl,.absent-lbl,.late-lbl{
        cursor: pointer;
    }
    .attendance-summary-table,
    .att-list{
        font-size: 14px;
    }
    .att-list .attendance-options{
        white-space: nowrap;
    }
</style>
<noscript>
    <style>
        table.att-list{
            width:100%;
            border-collapse:collapse
        }
        table.att-list td,table.att-list th{
            border:1px solid;
            text-align:center
        }
        .text-center{
            text-align:center
        }
    </style>
</noscript>
          <!----------------Class list attendance end code here----------------->
<?php if (!$partial) { ?>
         </div>
<?php } ?>

<script>
    <?php if (!$partial) { ?>
    $(document).on('click', '.js-attendance-tab', function(e){
        e.preventDefault();
        var $tab = $(this);
        $('.js-attendance-tab').removeClass('active');
        $tab.addClass('active');
        $('#attendance-breadcrumb').text($tab.data('title'));
        $('#attendance-tab-content').html('<div class="text-center p-4"><span class="fa fa-spinner fa-spin"></span> Loading...</div>');
        $('#attendance-tab-content').load($tab.data('url'));
    });
    <?php } ?>
    $(document).ready(function(){

    })
 $("#class").change(function(){
    $('#att-list').html('');
    $('#submit-btn-field').hide();

        var clvl = $(this).val(); 
        ///alert(clvl); 
         
        $.ajax({
            url: 'stream_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#level").empty();
                $("#level").append("<option value=''>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['sname'];
                    $("#level").append("<option value='"+id+"'>"+name+"</option>");
                }
            }
        });
    });

    $('#filter').click(function(){
        loadAttendanceSummary();
    })

    function loadAttendanceSummary(){
        $('#submit-btn-field').hide();
        $('#edt-btn-field').hide();
        $('#att-list').html('<span class="fa fa-spinner fa-spin"></span> Loading...');
        $.ajax({
            url: '<?php echo base_url() . '/get_attendance_list_summary'; ?>',
            type:'POST',
            data: $('#edit-attendance').serialize(),
            dataType: 'json',
            success:function(resp){
                var _table = $('#summary_table_clone table').clone();
                $('#att-list').html('');
                if(resp && resp.length > 0){
                    resp.map(function(row, index){
                        var tr = $('<tr></tr>');
                        tr.append('<td class="text-center">'+(index + 1)+'</td>');
                        tr.append('<td>'+row.attendance_date+'</td>');
                        tr.append('<td>'+row.class+'</td>');
                        tr.append('<td>'+row.stream+'</td>');
                        tr.append('<td>'+row.session+'</td>');
                        tr.append('<td class="text-center">'+row.present+'</td>');
                        tr.append('<td class="text-center">'+row.absent+'</td>');
                        tr.append('<td class="text-center">'+row.late+'</td>');
                        tr.append('<td>'+row.attendance_by+'</td>');
                        tr.append('<td>'+row.trans_date+'</td>');
                        tr.append('<td><button type="button" class="btn btn-sm btn-primary edit-attendance-record" data-id="'+row.id+'">Edit</button> <button type="button" class="btn btn-sm btn-info view-attendance" data-id="'+row.id+'">View</button></td>');
                        _table.find('tbody').append(tr);
                    });
                }else{
                    _table.find('tbody').append('<tr><td colspan="11" class="text-center">No data.</td></tr>');
                }
                $('#att-list').append(_table);
            }
        });
    }

    $(document).off('click.attendanceView', '.view-attendance').on('click.attendanceView', '.view-attendance', function(){
        viewAttendance($(this).attr('data-id'));
    });

    $(document).off('click.attendanceEdit', '.edit-attendance-record').on('click.attendanceEdit', '.edit-attendance-record', function(){
        editAttendance($(this).attr('data-id'));
    });

    function studentAge(birthDate){
        if(!birthDate || birthDate === '0000-00-00'){
            return '';
        }
        var birth = new Date(birthDate);
        if(isNaN(birth.getTime())){
            return '';
        }
        var today = new Date();
        var age = today.getFullYear() - birth.getFullYear();
        var monthDiff = today.getMonth() - birth.getMonth();
        if(monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())){
            age--;
        }
        return age + ' Yrs';
    }

    function attendanceType(admissionType){
        return parseInt(admissionType, 10) === 3 ? 'B' : 'D';
    }

    function attendanceFor(admitFor){
        return parseInt(admitFor, 10) === 2 ? 'New Comer' : 'Continous';
    }
    $('#manage-attendance').submit(function(e){
        e.preventDefault()
      
        //alert($(this).serialize());
        $.ajax({
            //url:'ajax.php?action=save_attendance',
            url: '<?php echo base_url() . '/save_attendance'; ?>',
            method:'POST',
            data:$(this).serialize(),
            success:function(resp){
                if(resp==1){
                      swal("success","Data successfully saved.","success")
                        setTimeout(function(){
                            location.reload()
                        },1000)
                }else if(resp ==2){
                      swal("error","Sorry! Something went wrong.","error")
                      end_load();
                }
            }
        })
    })
       function viewAttendance(id){
           $.ajax({
            url:'<?php echo base_url() . "/attendance_edit"; ?>/'+id,
            method:'POST',
            success:function(resp){
                if(resp){
                    resp = JSON.parse(resp)
                    var _table = $('#table_clone').clone()
                    $('#att-list').html('')
                    var _type = ['Absent','Present','Late'];
                    var data = !!resp.data ? resp.data : [];
                    if(Object.keys(data).length > 0){
                        var i = 1;
                        Object.keys(data).map(function(k){
                            var name = data[k].full_name || $.trim((data[k].first_name || '')+' '+(data[k].middle_name || '')+' '+(data[k].last_name || ''));
                            var tr = $('<tr></tr>')
                            tr.append('<td class="text-center">'+(i++)+'</td>')
                            tr.append('<td class="">'+(name)+'</td>')
                            tr.append('<td class="">'+studentAge(data[k].birth_date)+'</td>')
                            tr.append('<td class="">'+(data[k].gender || '')+'</td>')
                            tr.append('<td class="">'+attendanceType(data[k].admission_type)+'</td>')
                            tr.append('<td class="">'+attendanceFor(data[k].adimit_for)+'</td>')
                            tr.append('<td>'+(_type[data[k].type] || '')+'</td>')
                            _table.find('table.att-list tbody').append(tr)
                        })
                    }else{
                        _table.find('table.att-list tbody').append('<tr><td class="text-center" colspan="7">No data.</td></tr>')
                    }
                    _table.find('.class_name').text(!!resp.details.class ? resp.details.class : '')
                    _table.find('.stream_name').text(!!resp.details.stream ? resp.details.stream : '')
                    _table.find('.session').text(!!resp.details.session ? resp.details.session : '')
                    _table.find('.doc').text(!!resp.details.doc ? resp.details.doc : '')
                    $('#att-list').append(_table.html())
                    $('#submit-btn-field').hide()
                    $('#edt-btn-field').hide()
                }
            },
            complete:function(){
                end_load()
            }
        })
    }
       function editAttendance(id){
       //------start-edit button codded here-----//
                   $.ajax({
            url:'<?php echo base_url() . "/attendance_edit"; ?>/'+id,
            method:'POST',
           
            success:function(resp){
                if(resp){
                    resp = JSON.parse(resp)
                    var _table = $('#table_clone table').clone()
                    $('#att-list').html('')
                    $('#table_dis').hide()
                    $('#att-list').append(_table)
                    var _type = ['Absent','Present','Late'];
                    var data = resp.data;
                    var record = resp.record;
                    var attendance_id = !!resp.attendance_id ? resp.attendance_id : '';

                     // ---------------------------------------------------------------
                  
                    //----------------------------------------------------------
                    if(Object.keys(data).length > 0){
                        var i = 1;
                        Object.keys(data).map(function(k){
                            var name = data[k].full_name || $.trim((data[k].first_name || '')+' '+(data[k].middle_name || '')+' '+(data[k].last_name || ''));
                            var id = data[k].student_id;
                            var tr = $('<tr></tr>')
                            var opts = $('#chk_clone').clone()
                            opts.find('.chk-opts').addClass('attendance-options')

                            opts.find('.present-inp').attr({'name':'type['+id+']','id':'present_'+id})
                            opts.find('.absent-inp').attr({'name':'type['+id+']','id':'absent_'+id})
                            opts.find('.late-inp').attr({'name':'type['+id+']','id':'late_'+id})

                            opts.find('.present-lbl').attr({'for':'present_'+id})
                            opts.find('.absent-lbl').attr({'for':'absent_'+id})
                            opts.find('.late-lbl').attr({'for':'late_'+id})

                            tr.append('<td class="text-center">'+(i++)+'</td>')
                            tr.append('<td class="">'+(name)+'</td>')
                            tr.append('<td class="">'+studentAge(data[k].birth_date)+'</td>')
                            tr.append('<td class="">'+(data[k].gender || '')+'</td>')
                            tr.append('<td class="">'+attendanceType(data[k].admission_type)+'</td>')
                            tr.append('<td class="">'+attendanceFor(data[k].adimit_for)+'</td>')
                            var td = '<td>';
                                td += '<input type="hidden" name="student_id['+id+']" value="'+id+'">';
                                td += '<input type="hidden" name="attendance_id" value="'+attendance_id+'">';
                                td += opts.html();
                                td += '</td>';
                            tr.append(td)

                            _table.find('#tbody').append(tr)
                        })
                        $('#table_dis').hide()
                        $('#save-btn-field').hide()
                        $('#edit_att').attr('data-id',attendance_id).hide()
                        $('#print_att').attr('data-id',attendance_id).hide()
                        $('#edt-btn-field').show()
                        //$('#edit_save').attr('data-id',attendance_id)
                    }else{
                            var tr = $('<tr></tr>')
                            tr.append('<td class="text-center" colspan="7">No data.</td>')
                            _table.find('tbody').append(tr)
                        $('#submit-btn-field').attr('data-id','').hide()
                        $('#edit_att').attr('data-id','')
                    } 
                  
                    if(Object.keys(data).length > 0){
                        Object.keys(data).map(k=>{
                            // console.log('[name="type['+record[k].student_id+']"][value="'+record[k].type+'"]')
                            $('#att-list').find('[name="type['+data[k].student_id+']"][value="'+data[k].type+'"]').prop('checked',true)
                        })
                    }
                }
            },
            complete:function(){
                $("input:checkbox").on('keyup keypress change',function(){
                    var group = "input:checkbox[name='"+$(this).attr("name")+"']";
                    $(group).prop("checked",false);
                    $(this).prop("checked",true);
                });
                // $('#edit_att').click(function(){
                //     location.href = 'index.php?page=check_attendance&attendance_id='+$(this).attr('data-id')
                // })
                end_load()
            }
        })
                    //-----end edit code button
    }
     $('#edit-attendance').submit(function(e){
          e.preventDefault()      
        //alert($(this).serialize()); 
         $.ajax({
           url: '<?php echo base_url() . '/edit_attendance'; ?>',
            type:'POST',
            data:$(this).serialize(),
            success:function(resp){
                if(resp==1){
                      swal("success","Data successfully Updated.","success")
                        setTimeout(function(){
                            location.reload()
                        },1000)
                }else if(resp ==2){
                      swal("error","Sorry! Something went wrong.","error")
                      end_load();
                }else if(resp ==3){
                      swal("warning","Please! check all students.","warning")
                      end_load();
                }
            }
        })          
                })
    $('#print_att').click(function(){
        var _c = $('#att-list').html();
        var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=800,height=600')
        nw.document.write(_c)
        nw.document.write(ns.html())
        //nw.document.close()
        nw.print()
        // setTimeout(() => {
        //     nw.close()
        // }, 500);
    })
</script>
