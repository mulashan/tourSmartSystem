       <?php  

 $remodel = new App\Models\ReportsModel();
 $classList=$remodel->get_classes1();
 $partial = $partial ?? false;
 ?>
 <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<?php if (!$partial) { ?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Attendance</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                        <?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
                    </a></li>
                    <li class="breadcrumb-item active" aria-current="page" id="attendance-breadcrumb">New Attendance</li>
                </ol>
            </div>
            <div id="largeScreenTab">
                <ul class="nav nav-tabs page-header-tab">
                    <li class="nav-item"><a class="nav-link js-attendance-tab" href="<?php echo base_url('attendance_record')?>" data-url="<?php echo base_url('attendance_record?partial=1')?>" data-title="Attendance List">Attendance List</a></li>
                    <li class="nav-item"><a class="nav-link js-attendance-tab active" href="<?php echo base_url('attendance')?>" data-url="<?php echo base_url('attendance?partial=1')?>" data-title="New Attendance">New Attendance</a></li>
                </ul>
            </div>
         </div><br>
         <div id="attendance-tab-content">
<?php } ?>
          <!----------------Class list attendance start code here----------------->
<div class="container-fluid">
    <div class="col-lg-12">
        <div class="card">
            
            <div class="card-body">
                <form id="manage-attendance">
                    <input type="hidden" name="id" value="">
                    <div class="row justify-content-center">
                        
                        <div class="col-sm-2">
                            <select name="class" id="class" class="custom-select select2 input-sm" required="required">
                                <option value="">-select class-</option>
                              <?php
                            $clist=$remodel->get_classes1();
                            foreach($clist as $list){
                               ?>
                                <option value="<?=$list->id;?>"><?=$list->class_name;?></option>
                                <?php }?>
                            </select>
                        </div>
                        <!---------------------------------------------->
                         <div class="col-sm-2">
                            <select name="stream" id="level" class="custom-select select2 input-sm" required="required">
                                <option value="">-select stream-</option>
                              
                            </select>
                        </div>
                         <!------------------------------------------------>
                        <div class="col-sm-3">
                            <input type="date" name="doc" value="<?php echo date('Y-m-d'); ?>" class="form-control">
                        </div>
                        <!---------------------------------------------->
                         <div class="col-sm-2">
                            <?php 
                             //$time=date('H');
                             if(time() >= strtotime("12:00 AM")&& time() <= strtotime("11:59 AM")){
                                $ses=1;
                              $session="Morning session";
                             }elseif(time() >= strtotime("12:00 PM") && time() <= strtotime("05:59 PM")){
                                $ses=2;
                              $session="Afternoon session";
                             }elseif(time() >= strtotime("06:00 PM")&& time() <= strtotime("11:59 PM")){
                                $ses=3;
                              $session="Night session";
                             }else{
                                $ses=0;
                              $session="Unknown session";  
                             }
                            ?>
                            <input type="hidden" id="time" name="time"
                            value="<?php echo $ses; ?>" required>
                           <input type="text" id="ttime" name="ttime"
                            value="<?php echo $session; ?>" class="col-sm-12 form-control" readonly>
                        </div>                         <!------------------------------------------------>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12" id='att-list'>
                            
                        </div>
                        <div class="col-md-12"  style="display: none" id="submit-btn-field">
                            <center>
                                <button class="btn btn-primary btn-sm col-sm-3">Save</button>
                                <input type="reset" value="Reset" class="btn btn-success btn-sm col-sm-3">
                            </center>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div id="table_clone" style="display: none">
    <table class='table table-bordered table-hover attendance-student-table'>
        <thead>
            <tr>
                <th>#</th>
                <th>NAMES</th>
                <th>AGE</th>
                <th>GENDER</th>
                <th>TYPE</th>
                <th>FOR</th>
                <th>Attendance</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
<div id="chk_clone" style="display: none">
    <div class="d-flex justify-content-center chk-opts">
        <div class="form-check form-check-inline">
          <input class="form-check-input present-inp" type="checkbox" value="1">
          <label class="form-check-label present-lbl">Present</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input absent-inp" type="checkbox" value="0">
          <label class="form-check-label absent-lbl">Absent</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input late-inp" type="checkbox" value="2">
          <label class="form-check-label late-lbl">Late</label>
        </div>
    </div>
</div>
<style>
    .present-inp,.absent-inp,.late-inp,.present-lbl,.absent-lbl,.late-lbl{
        cursor: pointer;
    }
    .attendance-student-table{
        font-size: 14px;
    }
    .attendance-student-table th,
    .attendance-student-table td{
        vertical-align: middle;
    }
    .attendance-student-table .attendance-options{
        white-space: nowrap;
    }
    .attendance-student-table tr.attendance-missing{
        background: #fff3cd !important;
        box-shadow: inset 4px 0 0 #f59e0b;
    }
    .attendance-student-table tr.attendance-missing td{
        border-top-color: #f59e0b;
        border-bottom-color: #f59e0b;
    }
</style>
<?php if (!$partial) { ?>
         </div>
<?php } ?>
          
<script>
    <?php if (!$partial) { ?>
    $(document).on('click', '.js-attendance-tab', function(e){
        e.preventDefault();
        var $tab = $(this);
        $('.js-attendance-tab').removeClass('active');
        $tab.addClass('active');
        $('#attendance-breadcrumb').text($tab.data('title'));
        $('#attendance-tab-content').html('<div class="text-center p-4"><span class="fa fa-spinner fa-spin"></span> Loading...</div>');
        $('#attendance-tab-content').load($tab.data('url'));
    });
    <?php } ?>
    $(document).ready(function(){

    })
 $("#class").change(function(){
    $('#att-list').html('');
    $('#submit-btn-field').hide();
        var clvl = $(this).val(); 
        ///alert(clvl); 
         
        $.ajax({
            url: 'stream_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#level").empty();
                $("#level").append("<option value=''>-select stream-</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['sname'];
                    $("#level").append("<option value='"+id+"'>"+name+"</option>");
                }
            }
        });
    });

    $('#level').change(function(){
        get_data($(this).val())
    })
    window.get_data = function(id){
        var cdata=$('#class option:selected').val();
        //alert(id+'/'+cdata);
        $('#att-list').html('<span class="fa fa-spinner fa-spin"></span> Loading...');       
         $.ajax({
            url: '<?php echo base_url() . '/get_student_list'; ?>/'+id+'/'+cdata,
            //url:'get_student_list/'+id,
            type:'GET',
           success:function(resp){
                
                if(resp){
                    resp = JSON.parse(resp)
                    var _table = $('#table_clone table').clone()
                    $('#att-list').html('')
                    $('#att-list').append(_table)
                    if(Object.keys(resp).length > 0){
                        
                        var len=resp.length;
                        for(var i = 0; i < len;){
                            var name = resp[i]['name'];
                            var age = resp[i]['age'];
                            var gender = resp[i]['gender'];
                            var type = resp[i]['type'];
                            var studentFor = resp[i]['for'];
                            var id = resp[i]['id'];
                          //alert("name="+name);
                           
                            var tr = $('<tr></tr>')
                            var opts = $('#chk_clone').clone()
                            opts.find('.chk-opts').addClass('attendance-options')
                            opts.find('.present-inp').attr({'name':'type['+id+']','id':'present_'+id})
                            opts.find('.absent-inp').attr({'name':'type['+id+']','id':'absent_'+id})
                            opts.find('.late-inp').attr({'name':'type['+id+']','id':'late_'+id})

                            opts.find('.present-lbl').attr({'for':'present_'+id})
                            opts.find('.absent-lbl').attr({'for':'absent_'+id})
                            opts.find('.late-lbl').attr({'for':'late_'+id})
                             i++;
                            tr.append('<td class="text-center">'+(i)+'</td>')
                            tr.append('<td class="">'+(name)+'</td>')
                            tr.append('<td class="">'+(age)+'</td>')
                            tr.append('<td class="">'+(gender)+'</td>')
                            tr.append('<td class="">'+(type)+'</td>')
                            tr.append('<td class="">'+(studentFor)+'</td>')
                            var td = '<td>';
                                td += '<input type="hidden" name="student_id['+id+']" value="'+id+'">';
                                td += opts.html();
                                td += '</td>';
                            tr.append(td)

                            _table.find('tbody').append(tr)
                        }
                        $('#submit-btn-field').show()
                    }else{
                          
                            var tr = $('<tr></tr>')
                            tr.append('<td class="text-center" colspan="7">No data.</td>')
                            _table.find('tbody').append(tr)
                        $('#submit-btn-field').hide()
                    } 
                    
                }else{
                         $('#att-list').html('<span class=""></span>No data available...');
                         $('#submit-btn-field').hide();
                            var tr = $('<tr></tr>')
                            tr.append('<td class="text-center" colspan="7">No data.</td>')
                            _table.find('tbody').append(tr)
                        $('#submit-btn-field').hide()
                    }
                    $('#att-list').html('')
                    $('#att-list').append(_table) 
            },
            error:function(){
               alert("Something went wrong");
            },
            complete:function(){
                $("input:checkbox").on('keyup keypress change',function(){
                    // console.log(test)
                    var group = "input:checkbox[name='"+$(this).attr("name")+"']";
                    $(group).prop("checked",false);
                    $(this).prop("checked",true);
                    $(this).closest('tr').removeClass('attendance-missing');
                });
                end_load()
            }
        })
    }
    $('#manage-attendance').submit(function(e){
        e.preventDefault()
        $('.attendance-student-table tr').removeClass('attendance-missing');
        var missingRows = [];
        $('.attendance-student-table tbody tr').each(function(){
            var $row = $(this);
            var checked = $row.find('input[type="checkbox"]:checked').length;
            if(checked === 0 && $row.find('input[name^="student_id"]').length > 0){
                $row.addClass('attendance-missing');
                missingRows.push($row);
            }
        });
        if(missingRows.length > 0){
            swal("warning","Please! check all students.","warning").then(function(){
                $('html, body').animate({
                    scrollTop: missingRows[0].offset().top - 120
                }, 300);
            });
            return false;
        }
      
        //alert($(this).serialize());
        $.ajax({
            
            url: '<?php echo base_url() . '/save_attendance'; ?>',
            method:'POST',
            data:$(this).serialize(),
            success:function(resp){
                if(resp==1){
                      swal("success","Data successfully saved.","success")
                        setTimeout(function(){
                            location.reload()
                        },1000)
                }else if(resp ==2){
                      swal("error","Class already has an attendance record with the selected subject and date.","error")
                      end_load();
                }else if(resp ==3){
                      swal("warning","Please! check all students.","warning")
                      end_load();
                }else if(resp ==4){
                      swal("error","Class already has an attendance record with the selected date and session.","error")
                      end_load();
                }
            }
        })
    })
</script>
