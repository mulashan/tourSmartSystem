<?php
$remodel = new App\Models\ReportsModel();
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center">
            <div class="header-action">
                <h1 class="page-title">Reports</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php
                    $login = new App\Models\LoginModel();
                    if (session()->get('logged_in') == true) {
                        $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                        echo $shule[0]->instituition;
                    }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">School Fees Schedule</li>
                </ol>
            </div>
        </div><br><br>

        <div class="content-wrapper">
            <section class="content">
                <div class="box box-danger">
                    <div class="box-body">
                        <div class="d-flex justify-content-center">
                            <form id="SchoolFeesScheduleForm" class="form-inline">
                                <div class="me-3">
                                    Darasa:
                                    <select class="form-control form-select" name="class" id="class">
                                        <option value="0">All</option>
                                        <?php
                                        $classes = $remodel->get_classes1();
                                        foreach ($classes as $class) {
                                            echo '<option value="' . $class->id . '">' . $class->class_name . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>

                                <div class="me-3">
                                    Admission type:
                                    <select class="form-control form-select" name="admission_type" id="admission_type">
                                        <option value="all">All</option>
                                        <option value="0">Day</option>
                                        <option value="3">Boarding</option>
                                    </select>
                                </div>

                                <div class="me-3">
                                    Admission for:
                                    <select class="form-control form-select" name="admission_for" id="admission_for">
                                        <option value="all">All</option>
                                        <option value="0">Continuing</option>
                                        <option value="2">New Comer</option>
                                    </select>
                                </div>

                                <button type="submit" class="btn btn-primary">Create</button>
                                <button type="button" class="btn btn-secondary ms-2" onclick="printable_rept('SchoolFeesScheduleResults')"><i class="fa fa-print"></i> Print</button>
                            </form>
                        </div>

                        <hr>
                        <center>
                            <div id="SchoolFeesScheduleResults"></div>
                        </center>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<script type="text/javascript">
    function loadSchoolFeesSchedule() {
        $('#SchoolFeesScheduleResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
        var dta = "class=" + $('#class option:selected').val() + "&admission_type=" + $('#admission_type option:selected').val() + "&admission_for=" + $('#admission_for option:selected').val();

        $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/index.php/ReportsController/load_school_fees_schedule'; ?>',
            data: dta,
            success: function (res) {
                $('#SchoolFeesScheduleResults').html(res);
            },
            error: function () {
                $('#SchoolFeesScheduleResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
            }
        });
    }

    $('#SchoolFeesScheduleForm').submit(function (e) {
        e.preventDefault();
        loadSchoolFeesSchedule();
    });

    $(function () {
        loadSchoolFeesSchedule();
    });

    if (typeof printable_rept !== 'function') {
        function printable_rept(area) {
            var content_vlue = document.getElementById(area).innerHTML;
            var docprint = window.open("", "", "toolbar=yes,location=no,directories=yes,menubar=yes,scrollbars=yes,width=900,height=650,left=100,top=25");
            docprint.document.open();
            docprint.document.write('<html><head><title>School Fees Schedule</title>');
            docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:12px;">');
            docprint.document.write(content_vlue);
            docprint.document.write('</body></html>');
            docprint.document.close();
            docprint.focus();
        }
    }
</script>
