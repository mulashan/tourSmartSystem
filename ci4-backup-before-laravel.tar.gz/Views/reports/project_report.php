          <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
   $hostels = $amodel->get_item_name('hostel_tbl', $where = array('status' => 1));
 ?>
           <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Reports</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Project Report</li>
                </ol>
            </div>
         </div><br><br>
          <!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="box box-danger">
           
            <div class="card">
          
               <div class="d-flex justify-content-center mt-3">
                <div id="messageDisplayArea"></div>
                    <form id="Rept1Result" class="form-inline">
                         Project date:
                         <div class="input-group ms-3 me-3">
                            <button type="button" class="btn btn-default pull-right daterange-all" id="daterange-all">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                      
                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="project_report"></div>
                </center>
  
            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
</div>
</div>
<!-- View Modal -->
  <!-- <div id="myModalview" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" > -->
    <div class="modal fade" id="myModalview" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="z-index: 1600;">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content" style="width: 120%">
        <div class="modal-content">
        <div class="modal-header">
         
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
       <div class="modal-body">
          <div id="showLedger"></div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('showLedger')"><i class="fa fa-print"></i> Print</button>
      </div>
      </div>
      
    </div>
  </div>
  </div>

<script type="text/javascript">
   //   resetReceiptData();
   // function resetReceiptData(){
   //      $('#classlevel').val('');
   //        $('#class').val('');
   //        $('#stream').val('');
   // }

      

    $('#Rept1Result').submit(function (e) {
             if (!$('#daterange-all span').html()) {
            $('#project_report').html('Please specify valid date.');
        } else {
            $('#project_report').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-all span').html();
            //alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/CompanyController/fetch_project_report'; ?>',

                data: dta,
                success: function (res) {
                    $('#project_report').html(res);
                },
                error: function () {
                    $('#project_report').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });
     
  
   
    function viewBalanceReport(stid,sid,yr) {
       // alert('stid= '+stid+' id= '+sid);
       var datta = "stid=" + stid+ "&sid="+sid+"&year="+yr;
       //alert(datta);
        $('#myModalview').modal('show');
      $.ajax({
            type: "POST",
           // url: "<?= base_url('/student_collection_report')?>",
             url: '<?php echo base_url() . '/index.php/ReportsController/view_student_balance'; ?>',
            data: datta,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);
               
            },
            error: function ()
            {

            }
        });
    };

   
</script>
