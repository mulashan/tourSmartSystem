 <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Reports</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Cash And Bank</li>
                </ol>
            </div>
         </div><br><br>
          <!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="form-group row">
      <div class="col-md-4"></div>
      <div class="col-md-4">
                    <form id="Rept1Result" class="form-inline">
                        
                         <div class="input-group">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        
                        <button type="submit" class="btn btn-primary">Create</button> 
                        
                    </form>
                </div>

             <div class="col-md-4"></div>
              </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>

          
       
   

<script>
    //loadincome();
        $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                                        'This Year': [moment().startOf('year'), moment().endOf('year')],
                                        'Last Year': [moment().subtract(1, 'year').startOf('year'), moment().subtract(1, 'year').endOf('year')],
                                    }
                                }, cb);
                                cb(start, end);

                            });
   $('#Rept1Result').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "thedate=" + $('#daterange-btn span').html();
            //alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/cash_bank_list'; ?>',

                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });
   // function printable(area) {
   //      var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
   //      disp_setting += "scrollbars=yes,width=700, height=600, left=100, top=25";
   //      var content_vlue = document.getElementById(area).innerHTML;

   //      var docprint = window.open("", "", disp_setting);
   //      docprint.document.open();
   //      docprint.document.write('<html><head><title>MHI</title>');
   //      docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
   //      docprint.document.write(content_vlue);
   //      docprint.document.write('</body></html>');
   //      docprint.document.close();
   //      docprint.focus();
   //  }
</script>