<?php
 $bmodel = new App\Models\BillingModel();
   $trans= $bmodel->get_table_details('transaction_types_tbl');
?>
 <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Reports</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Account Receivable Report</li>
                </ol>
            </div>

            <!-- <ul class="nav nav-tabs page-header-tab">-->
            <!--    <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#rcvb-tab">Acount Receivable</a></li>-->
            <!--    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#check-tab">Incorrect Trans</a></li>-->
            <!--</ul>-->
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#rcvb-tab">Acount Receivable</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#check-tab">Incorrect Trans</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#rcvb-tab">Acount Receivable</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#check-tab">Incorrect Trans</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
         </div><br><br>
          <!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="tab-content">
            <div class="tab-pane active" id="rcvb-tab">
        <div class="form-group row">
      <div class="col-md-4"></div>
      <div class="col-md-4">
                    <form id="Rept1Result" class="form-inline">
                        
                         <div class="input-group">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        
                        <button type="submit" class="btn btn-primary">Create</button> 
                        
                    </form>
                </div>

             <div class="col-md-4"></div>
              </div>
              
              
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>
            </div>

    <div class="tab-pane" id="check-tab">
          <div class="card">
       <div class="d-flex justify-content-center  mt-3 mb-3">
     <div id="messageDisplayArea"></div>
    <form id="notbalance" class="form-inline">
            Trans Type: 
    <select class="form-control form-select ms-3" name="transType" id="transType">
        <option value="">-choose-</option>
        <?php 
       foreach ($trans as $t) {
       ?>
       <option value="<?= $t->type_id?>"><?= $t->type_name?></option>
       <?php
       }
        ?>
        
    </select>
           &nbsp;&nbsp;&nbsp;&nbsp;
                        
     <button type="submit" class="btn btn-primary">Create</button> 
   </form>
  </div>
    </div>

    <center>
    <div class="table-responsive">
   <table class="table table-hover table-vcenter mb-0 text-nowrap">
            <thead>
                <tr>
                <th>#</th>
                <th class="">Trans No</th>
                <th class="text-right">Trans Date</th>
                <th class="">Trans Name</th>
                <th class="">name Type</th>
                <th class="text-right">Credit Amount</th>
                <th class="text-right">Debit Amount</th>
                <th class="text-right">Difference</th>
                
               </tr>
             </thead>
            <tbody id="Results">

            </tbody>
        </table>
    </div>
     </center>
    </div>
          </div>
          </section>
      </div>
       
   

<script>
    //loadincome();
        $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                                        'This Year': [moment().startOf('year'), moment().endOf('year')],
                                        'Last Year': [moment().subtract(1, 'year').startOf('year'), moment().subtract(1, 'year').endOf('year')],
                                    }
                                }, cb);
                                cb(start, end);

                            });
   $('#Rept1Result').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "thedate=" + $('#daterange-btn span').html();
            //alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/account_receivable_list'; ?>',

                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });
   
   $('#notbalance').submit(function (e) {
        $('#Results').empty();
             if ($('#transType').val()=="") {
            $('#Results').append('Please choose trans type.');
        } else {
            $('#Results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "type=" + $('#transType').val();
           // alert(dta);
            $.ajax({
                type: "POST",
                 url: '<?php echo base_url() . '/index.php/ReportsController/check_unbalanced_trans'; ?>',

                data: dta,
                success: function (res) {
                      $('#Results').html('');
                    $('#Results').append(res);
                },
                error: function () {
                  
                    $('#Results').append('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });
</script>