          <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
 ?>
           <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Reports</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">Eden Garden</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Collection by Classes</li>
                </ol>
            </div>
         </div><br><br>
          <!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="box box-danger">
           
            <div class="box-body">
          
                <center style="margin-left: 200px;">
                    <form id="hamimu" class="form-inline">
                    <div class="d-flex justify-content-center">
                    <form id="hamimu" class="form-inline">
                     <div class="me-3">
                             Academic year: 
                           <select id="year" name="year" class="form-select form-control">
                      <!-- JavaScript loop to generate year options -->
                      <script>
                        const currentYear = new Date().getFullYear();
                        const startYear = 2023; // Change this to set a different start year
                        for (let year = currentYear+1; year >= startYear; year--) {
                            if(year==currentYear){
                            document.write(`<option value="${year}" selected>${year}</option>`);
                            }else{
                            document.write(`<option value="${year}">${year}</option>`);    
                            }
                        
                        }
                      </script>
                    </select>
                        </div>
                        <div class="me-3">
                             Level: 
                            <select class="form-control form-select" name="classlevel" id="classlevel">
                                <option value="0">All</option>
                                <?php
                               $l = $remodel->get_levels();
                              foreach($l as $le){
                               echo '<option value="' . $le->id . '">' . $le->level_name . '</option>'; 
                              }

                               ?>
                            </select>
                        </div>
                         &nbsp;&nbsp;&nbsp;&nbsp;
                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </center>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>
         <center>
 <button class="btn btn-primary btn-sm" id="printbtn" style="display:none;" onclick="printable_area('Rept1ResultViewResults')"><span class="fa fa-print"></span> Print</button>
</center>
            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
</div>
</div>
<!-- View Modal -->
  <div id="myModalview" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content" style="width: 120%">
        <div class="modal-content">
        <div class="modal-header">
         
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
       <div class="modal-body">
          <div id="showLedger"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
  </div>
  <noscript>
    <style>
        h5,p{
            padding: 0px;
          text-align:center  
        }
        table.att-list{
            width:100%;
            border-collapse:collapse
        }
        table.att-list td,table.att-list th{
            border:1px solid
        }
        .text-center,.text-c{
            text-align:center
        }
        #viewbtn{
            display: none;
        }
    </style>
</noscript>

    <script type="text/javascript">
   
    // $('#hamimu').submit(function (e) {
            
    //         $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
    //         var dta = "year=" + $('#year option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val();
    //        alert(dta);
    //         $.ajax({
    //             type: "POST",
    //             url: '<?php echo base_url() . '/collection_by_classes1'; ?>',

    //             data: dta,
    //             success: function (res) {
    //                 $('#Rept1ResultViewResults').html(res);
    //             },
    //             error: function () {
    //                 $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
    //             }
    //         });


    //     e.preventDefault();
    // });
    $('#hamimu').submit(function (e) {
    e.preventDefault(); // Prevent default form submission
    $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retrieving report..');
    var dta = "year=" + $('#year option:selected').val() + "&classlevel=" + $('#classlevel option:selected').val();
           //alert(dta);
    
    $.ajax({
        type: "POST",
        url: '<?php echo base_url() . '/collection_by_classes1'; ?>', // Ensure this URL is correct
        data: dta,
        success: function (res) {
            $('#Rept1ResultViewResults').html(res);
        },
        error: function () {
            $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Failed to retrieve report.!!</div>');
        }
    });
});
     $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });
   $('#Rept1Result').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "thedate=" + $('#daterange-btn span').html()+ "&class=" + $('#pm option:selected').val()+ "&res=" + $('#res option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/collection_by_classes1'; ?>',

                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                    $('#printbtn').show();
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });
   function printable_area(area) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=900, height=700, left=100, top=25";
        var content_vlue = document.getElementById(area).innerHTML;
        var ns = $('noscript').clone();
        
        var docprint = window.open("", "", disp_setting);
        docprint.document.open();
        docprint.document.write('<html><head><title>MHI</title>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
        docprint.document.write(content_vlue);
        docprint.document.write(ns.html())
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    function viewClasses(stid,thedate) {
        var datta = "stid=" + stid+ "&thedate="+thedate;
        $('#myModalview').modal('show');
      $.ajax({
            type: "GET",
            url: "<?= base_url('/student_collection_report')?>",
            data: datta,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);
                 
            },
            error: function ()
            {

            }
        });
    };
    function viewClassListSummary(id,year) {
        // var dta = "year=" + $('#year option:selected').val() + "&classlevel=" + $('#classlevel option:selected').val();
   
        var perdata = "id=" + id + "&year=" + year;
        //alert(perdata);
    $('#myModalview').modal('show');
    //alert(perdata);
    $.ajax({
        type: "GET",
        url: "<?= base_url('/class_list_Summary')?>",
        data: perdata,
        beforeSend: function () {
            $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
        },
        success: function(res) {
            $('#showLedger').html(res);
        },
        error: function() {
            // Optionally you could handle the error here
            alert('Error fetching the data. Please try again later.');
        }
    });
};
   
</script>