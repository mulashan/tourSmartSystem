<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>School Fees Schedule</title>
    <link rel="stylesheet" href="<?= base_url('public/assets/plugins/bootstrap/css/bootstrap.min.css'); ?>">
    <style>
        body {
            background: #fff;
            color: #24364b;
            font-family: Arial, sans-serif;
            padding: 24px;
        }
        .public-schedule {
            max-width: 1200px;
            margin: 0 auto;
        }
        @media print {
            body {
                padding: 0;
            }
        }
    </style>
</head>
<body>
    <div class="public-schedule">
        <?= view('reports/forms/school_fees_schedule_list', [
            'rows' => $rows,
            'schoolname' => $schoolname,
            'company' => $company,
            'qrUrl' => $qrUrl,
            'qrImage' => $qrImage,
            'filters' => $filters,
        ]); ?>
    </div>
</body>
</html>
