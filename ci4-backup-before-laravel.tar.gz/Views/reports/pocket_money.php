          <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
   $hostels = $amodel->get_item_name('hostel_tbl', $where = array('status' => 1));
 ?>
           <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Reports</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Pocket Money List</li>
                </ol>
            </div>
         </div><br><br>
          <!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="box box-danger">
           
            <div class="box-body">
          
                <div class="d-flex justify-content-center">
                    <form id="Rept1Result" class="form-inline">
                     <div class="me-3">
                             Academic year: 
                           <select id="year" name="year" class="form-select form-control">
                      <!-- JavaScript loop to generate year options -->
                      <script>
                        const currentYear = new Date().getFullYear();
                        const startYear = 2023; // Change this to set a different start year
                        for (let year = currentYear+1; year >= startYear; year--) {
                            if(year==currentYear){
                            document.write(`<option value="${year}" selected>${year}</option>`);
                            }else{
                            document.write(`<option value="${year}">${year}</option>`);    
                            }
                        
                        }
                      </script>
                    </select>
                        </div>
                        
                        <div class="me-3">
                             Level: 
                            <select class="form-control form-select" name="classlevel" id="classlevel">
                                <option value="0">All</option>
                                <?php
                               $l = $remodel->get_levels();
                              foreach($l as $le){
                               echo '<option value="' . $le->id . '">' . $le->level_name . '</option>'; 
                              }

                               ?>
                            </select>
                        </div>

                         <div class="me-3">
                             Class: 
                            <select class="form-control form-select" name="class" id="class">
                                <option value="0">All</option>
                                <?php
                               $c = $remodel->get_classes1();
                              foreach($c as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->class_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                      
                         <div class="me-3">
                             Stream: 
                            <select class="form-control form-select" name="stream" id="stream">
                                <option value="0">All</option>
                                <?php
                               $s = $remodel->get_stream1();
                              foreach($s as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->stream_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                         <div class="me-3">
                             Hostel: 
                             <select class="form-control form-select" name="hostel" id="hostel">
                                <option value="0">All</option>
                              <?php
                              foreach($hostels as $h){
                               echo '<option value="' . $h->id . '">' . $h->hostel_name . '</option>'; 
                              }

                               ?>   
                             </select>

                         </div>

                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>
            <!--   <center>
 <button class="btn btn-primary btn-sm" onclick="printable('Rept1ResultViewResults')"><span class="fa fa-print"></span> Print</button>
</center> -->
            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
</div>
</div>
<!-- View Modal -->
  <!-- <div id="myModalview" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" > -->
    <div class="modal fade" id="myModalview" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="z-index: 1600;">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content" style="width: 120%">
        <div class="modal-content">
        <div class="modal-header">
         
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
       <div class="modal-body">
          <div id="showLedger"></div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('showLedger')"><i class="fa fa-print"></i> Print</button>
      </div>
      </div>
      
    </div>
  </div>
  </div>


  <div class="modal fade" id="paymentsModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="view_payments">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="close_rept()">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept2('view_payments')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
   //   resetReceiptData();
   // function resetReceiptData(){
   //      $('#classlevel').val('');
   //        $('#class').val('');
   //        $('#stream').val('');
   // }

      $("#classlevel").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#class").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });

        $("#class").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            //url: 'class_list',
             url: '<?php echo base_url() . '/index.php/StudentController/get_stream_details'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#stream").empty();
                $("#stream").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    $("#stream").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });
     
   $('#Rept1Result').submit(function (e) {
            
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "class=" + $('#class option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&year="+$('#year option:selected').val()+"&hostel="+$('#hostel option:selected').val();
           // alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/get_pocket_money'; ?>',

                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
   
    function viewBalanceReport(stid,sid,yr) {
       // alert('stid= '+stid+' id= '+sid);
       var datta = "stid=" + stid+ "&sid="+sid+"&year="+yr;
       //alert(datta);
        $('#myModalview').modal('show');
      $.ajax({
            type: "POST",
           // url: "<?= base_url('/student_collection_report')?>",
             url: '<?php echo base_url() . '/index.php/ReportsController/view_student_balance'; ?>',
            data: datta,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);
               
            },
            error: function ()
            {

            }
        });
    };

//   function view_pocketMoney(student_id){
//   //  alert(sdate+'/'+enddate);
//     $('#viewinvoice').modal('show'); 
//       $('#viewinvoice_content').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
//  $('#viewinvoice_content').load("<?php echo base_url() . '/index.php/ReportsController/view_pocket_money'; ?>/"+student_id);
// }

function view_payments(student_id,trans_no){
 $('#paymentsModal').modal('show'); 
      $('#view_payments').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
 $('#view_payments').load("<?php echo base_url() . '/index.php/ReportsController/view_pocket_money_payments'; ?>/"+student_id+'/'+trans_no);
}
</script>
