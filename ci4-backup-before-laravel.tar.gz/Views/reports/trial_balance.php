<style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Reports</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Trial Balance</li>
                </ol>
            </div>
         </div><br><br>
          <!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="box box-danger">
           
            <div class="box-body">
          
                <center style="margin-left: 300px;">
                    <form id="Rept1Result" class="form-inline">
                         <div class="input-group">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        
                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </center>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>

            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
 
 <div class="box box-default" style="">
      <div class="box-body" style="" id="sales"></div>
 <div id="line1"></div>
</div>
    </div>
</div>
  <!-- View Modal -->
  <div id="myModalview" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content" style="width: 120%">
        <div class="modal-content">
        <div class="modal-header">
         <center> <h5 class="modal-title" id="staticBackdropLabel"></h5></center>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
       <div class="modal-body">
          <div id="showLedger"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
<script>
    //loadincome();
function loadincome() {
     $('#sales').html('<center><i class="fa fa-spinner fa-spin"></i> Loading report..</center>');
$('#sales').load('<?php echo base_url() . '/income_info'; ?>');
   
    
 }
$(".passingData").click(function () {
        var data = 'ids=' + $(this).attr('data-id');

        $('#myModalview').modal('show');
        $.ajax({
            type: "GET",
            url: "<?= base_url('/getSingle_data2')?>",
            data: data,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });

    function viewLedger(ledgerId,type,thedate) {
        var perdata = "ledgerId=" + ledgerId + "&ledgertype="+type+ "&thedate="+thedate;
        $('#myModalview').modal('show');
      $.ajax({
            type: "GET",
            url: "<?= base_url('/getSingle_ledger')?>",
            data: perdata,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);
                 
            },
            error: function ()
            {

            }
        });
    };

             $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {               
                     // $('#daterange-btn span').html(start.format('YYYY/M/D H:mm') + ' - ' + end.format('YYYY/M/D H:mm'));
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                                        'This Year': [moment().startOf('year'), moment().endOf('year')],
                                        'Last Year': [moment().subtract(1, 'year').startOf('year'), moment().subtract(1, 'year').endOf('year')]
                                    }
                                }, cb);
                                cb(start, end);

                            });
   $('#Rept1Result').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "thedate=" + $('#daterange-btn span').html();
        //alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/get_trial_balance'; ?>',

                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });
   function printable(area) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=700, height=600, left=100, top=25";
        var content_vlue = document.getElementById(area).innerHTML;

        var docprint = window.open("", "", disp_setting);
        docprint.document.open();
        docprint.document.write('<html><head><title>MHI</title>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    
    function detail_view(id,thedate) {
        var data = "ids=" + id + "&thedate="+thedate;
        // alert(data);
        $('#myModalview').modal('show');
      $.ajax({
            type: "GET",
            url: "<?= base_url('/view_trial_balance')?>",
            data: data,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);
                 
            },
            error: function ()
            {
                toastr.error("Sory! Something went wrong!");

            }
        });
    };
</script>