          <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
 ?>
           <style type="text/css">
     a{
        text-decoration: none;
     }
     .class-list-column-toggle{
        display:flex;
        flex-wrap:wrap;
        justify-content:center;
        gap:12px;
     }
     .class-list-column-toggle label{
        display:flex;
        align-items:center;
        gap:6px;
        margin-bottom:0;
        padding:8px 14px;
        border:1px solid #d9dee7;
        border-radius:999px;
        background:#f8fafc;
        cursor:pointer;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Reports</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Class List</li>
                </ol>
            </div>
         </div><br><br>
          <!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="box box-danger">
           
            <div class="box-body">
          
                <div class="d-flex justify-content-center">
                    <form id="Rept1Result" class="form-inline">
                     <div class="me-3">
                             Academic year: 
                           <select id="year" name="year" class="form-select form-control">
                      <!-- JavaScript loop to generate year options -->
                      <script>
                        const currentYear = new Date().getFullYear();
                        const startYear = 2023; // Change this to set a different start year
                        for (let year = currentYear+1; year >= startYear; year--) {
                            if(year==currentYear){
                            document.write(`<option value="${year}" selected>${year}</option>`);
                            }else{
                            document.write(`<option value="${year}">${year}</option>`);    
                            }
                        
                        }
                      </script>
                    </select>
                        </div>
                        
                        <div class="me-3">
                             Level: 
                            <select class="form-control form-select" name="classlevel" id="classlevel">
                                <option value="0">All</option>
                                <?php
                               $l = $remodel->get_levels();
                              foreach($l as $le){
                               echo '<option value="' . $le->id . '">' . $le->level_name . '</option>'; 
                              }

                               ?>
                            </select>
                        </div>

                         <div class="me-3">
                             Class: 
                            <select class="form-control form-select" name="class" id="class">
                                <option value="0">All</option>
                                <?php
                               $c = $remodel->get_classes1();
                              foreach($c as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->class_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                      
                         <div class="me-3">
                             Stream: 
                            <select class="form-control form-select" name="stream" id="stream">
                                <option value="0">All</option>
                                <?php
                               $s = $remodel->get_stream1();
                              foreach($s as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->stream_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                         <div class="me-3">
                             Status: 
                            <select id="status" name="status" class="form-select form-control">
                        <option value="0">All</option>
                        <option value="1">Pending</option>
                        <option value="2" selected>Admitted</option>
                        <option value="4">Graduates</option>
                        <option value="3">Transfered</option>
                        <option value="5">Absconded</option>
                        <option value="6">No Show</option>
                     
                    </select>
                         </div>

                        <button type="submit" class="btn btn-primary">Create</button>
                     </form>

                </div>
                <center>
                 <div class="input-group col-md-4 mt-3">
                                                    
                    <input type="text" class="form-control" name="payer_name" id="search_name"   placeholder="Search Student Name" aria-label="Student Name" aria-describedby="button-st">
                    <button class="btn btn-outline-success" type="button" id="button-y">
                        <span>
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                        </span></button>
                    <button class="btn btn-outline-primary" type="button" id="button-st" onclick="searchnamebtn()"><i class="fa fa-search" aria-hidden="true"></i></button>
                </div>
                </center>
                 
                 <hr>
                 <div class="mb-3">
                    <div class="class-list-column-toggle">
                        <label for="toggleAcdmcColumn">
                            <input type="checkbox" id="toggleAcdmcColumn">
                            ACDMC
                        </label>
                        <label for="toggleAdmNoColumn">
                            <input type="checkbox" id="toggleAdmNoColumn">
                            ADM NO
                        </label>
                        <label for="toggleAdmDateColumn">
                            <input type="checkbox" id="toggleAdmDateColumn">
                            ADM DATE
                        </label>
                        <label for="toggleBirthDateColumn">
                            <input type="checkbox" id="toggleBirthDateColumn">
                            Birth Date
                        </label>
                        <label for="toggleBalBfColumn">
                            <input type="checkbox" id="toggleBalBfColumn">
                            Bal B/F
                        </label>
                        <label for="toggleAnnualFeeColumn">
                            <input type="checkbox" id="toggleAnnualFeeColumn">
                            Annual Fee
                        </label>
                        <label for="toggleTermFeeColumn">
                            <input type="checkbox" id="toggleTermFeeColumn">
                            Term Fee
                        </label>
                        <label for="togglePaidColumn">
                            <input type="checkbox" id="togglePaidColumn">
                            Paid
                        </label>
                    </div>
                 </div>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>
           
            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
</div>
</div>
<!-- View Modal -->
  <!-- <div id="myModalview" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" > -->
    <div class="modal fade" id="myModalview" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="z-index: 1600;">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content" style="width: 120%">
        <div class="modal-content">
        <div class="modal-header">
         
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
       <div class="modal-body">
          <div id="showLedger"></div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('showLedger')"><i class="fa fa-print"></i> Print</button>
      </div>
      </div>
      
    </div>
  </div>
  </div>

  

<script type="text/javascript">
   function getClassListOptionalColumns() {
        return {
            acdmc: $('#toggleAcdmcColumn').is(':checked'),
            adm_no: $('#toggleAdmNoColumn').is(':checked'),
            adm_date: $('#toggleAdmDateColumn').is(':checked'),
            birth_date: $('#toggleBirthDateColumn').is(':checked'),
            bal_bf: $('#toggleBalBfColumn').is(':checked'),
            annual_fee: $('#toggleAnnualFeeColumn').is(':checked'),
            term_fee: $('#toggleTermFeeColumn').is(':checked'),
            paid: $('#togglePaidColumn').is(':checked')
        };
   }

   function storeClassListOptionalColumns() {
        window.localStorage.setItem('class_list_optional_columns', JSON.stringify(getClassListOptionalColumns()));
   }

   function restoreClassListOptionalColumns() {
        var savedColumns = window.localStorage.getItem('class_list_optional_columns');
        if (!savedColumns) {
            return;
        }

        try {
            var parsedColumns = JSON.parse(savedColumns);
            $('#toggleAcdmcColumn').prop('checked', !!parsedColumns.acdmc);
            $('#toggleAdmNoColumn').prop('checked', !!parsedColumns.adm_no);
            $('#toggleAdmDateColumn').prop('checked', !!parsedColumns.adm_date);
            $('#toggleBirthDateColumn').prop('checked', !!parsedColumns.birth_date);
            $('#toggleBalBfColumn').prop('checked', !!parsedColumns.bal_bf);
            $('#toggleAnnualFeeColumn').prop('checked', !!parsedColumns.annual_fee);
            $('#toggleTermFeeColumn').prop('checked', !!parsedColumns.term_fee);
            $('#togglePaidColumn').prop('checked', !!parsedColumns.paid);
        } catch (error) {
            window.localStorage.removeItem('class_list_optional_columns');
        }
   }

   function applyClassListOptionalColumns() {
        var selectedColumns = getClassListOptionalColumns();
        $.each(selectedColumns, function (columnKey, isVisible) {
            $('#Rept1ResultViewResults').find('[data-optional-column=\"' + columnKey + '\"]').css('display', isVisible ? '' : 'none');
        });

        if (window.classListTable) {
            window.classListTable.columns.adjust();
        }
   }

   window.applyClassListOptionalColumns = applyClassListOptionalColumns;

   $(document).ready(function () {
        restoreClassListOptionalColumns();
        $('.class-list-column-toggle input[type=\"checkbox\"]').on('change', function () {
            storeClassListOptionalColumns();
            applyClassListOptionalColumns();
        });
   });

   $("#classlevel").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#class").append("<option value='"+id+"'>"+name+"</option>");
                }
            }
        });
    });

        $("#class").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            //url: 'class_list',
             url: '<?php echo base_url() . '/index.php/StudentController/get_stream_details'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#stream").empty();
                $("#stream").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    $("#stream").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });
     $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });
   $('#Rept1Result').submit(function (e) {
            
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "class=" + $('#class option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&year="+$('#year option:selected').val()+ "&status="+$('#status option:selected').val();
           // alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/class_list2'; ?>',

                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                    applyClassListOptionalColumns();
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
  
    function viewBalanceReport(stid,sid,yr) {
       // alert('stid= '+stid+' id= '+sid);
       var datta = "stid=" + stid+ "&sid="+sid+"&year="+yr;
       //alert(datta);
        $('#myModalview').modal('show');
      $.ajax({
            type: "POST",
           // url: "<?= base_url('/student_collection_report')?>",
             url: '<?php echo base_url() . '/index.php/ReportsController/view_student_balance'; ?>',
            data: datta,
            timeout: 30000,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);
               
            },
            error: function (xhr, status)
            {
                var message = 'Failed to load report.';
                if (status === 'timeout') {
                    message = 'Report is taking too long to load.';
                } else if (xhr && xhr.responseText) {
                    message = xhr.responseText;
                }
                $('#showLedger').html('<div class="alert alert-warning">'+message+'</div>');
            }
        });
    };

function searchnamebtn(){
            var name=$('#search_name').val();
            var  year=$('#button-y').html();
            // alert(year);
            if(name.length >=3){
                $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
                var dta="name="+name+"&year="+year;
           // toastr.success(name.length);
             $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/index.php/ReportsController/fetch_class_list_byname'; ?>",
                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                    applyClassListOptionalColumns();
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
        }else{
            if(name.length==0){
               $('#Rept1ResultViewResults').html(''); 
            }else{
               $('#Rept1ResultViewResults').html('<div class="alert alert-info">Search atleat 3 characters</div>'); 
            }
        
        }
        }
  </script>
