          <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
 ?>
 <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Reports</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Vehicle Sales</li>
                </ol>
            </div>
         </div><br><br>
          <!----------------------------------------------------another code here----------------->
       <div class="tab-pane active" id="inv-all">

         <div class="input-group ms-3 me-3 mb-3 d-flex justify-content-center">
                           <form id="vehicleReport" class="form-inline">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                              <button type="submit" class="btn btn-primary ms-3">Create</button>
                        </form>
                        </div>
                <hr>
                
                <center>
                    <div id="vehicle_results"></div>
                </center>
            </div>

        
        
            </div>
</div>
<!-- View Modal -->
 
<script type="text/javascript">

  $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                                        'This Year': [moment().startOf('year'), moment().endOf('year')]
                                    }
                                }, cb);
                                cb(start, end);

                            });
  $('#vehicleReport').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#vehicle_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn span').html()+'&'+ $('#vehicleReport').serialize();
           // alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/load_vehicle_reports' ?>',
                 data: dta,
                success: function (res) {
                    $('#vehicle_results').html(res);
                },
                error: function () {
                    $('#vehicle_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });
</script>