<!DOCTYPE html>
<?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
    $cname = $remodel->getonlycname($cid);
 foreach($cname as $nm){
    $name=$nm->class_name;
 }
 ?>

<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>
<body>
<div>
<div id="printcashdtls">
    <center><h4>
       
        <?php 
        $strtdate=$start;
        $enddate=$end;
        echo "EDEN GARDEN  ";echo '<br>Sales by class name: '. $name; ?>
        <?php echo '<br>'; ?> 
        Report Date <?php echo date('d/m/Y H:i', $strtdate) ?> - <?php echo date('d/m/Y H:i', $enddate) ?>
    </h4>
    </center><br>

                           
                     <div class="card">
                      
                    <div class="table-responsive mt-3">
                        <table class="table table-bordered table-vcenter mb-0 text-nowrap" id="myTable2">
                            <thead style="border:1px solid silver;">
                               
                                <tr>

                                    <th style="text-align: center;">Trans Type</th>
                                     <th style="text-align: center;">Trans Date</th>
                                    <th style="text-align: center;">Trans No</th>
                                    <th style="text-align: center;">Student Name</th>
                                   
                                    <th style="text-align: center;">Total Amount</th>
                                    
                                
                                </tr>
                            </thead>
                           <tbody style="border:1px solid silver;">
                         <?php
                         if (count($class)> 0) {
                            $totalAmount=0;
                           foreach($class as $ledge){
                             $result=$remodel->groupedby2($ledge->trans_no,date('Y-m-d H:i', $strtdate), date('Y-m-d H:i', $enddate));
                           $totals=0;
                              foreach($result as $res){
                              $totals=$totals+ $res->amount;
                                }
                              $totalAmount=$totalAmount+$totals;
                              $trans_date=$remodel->select_date($ledge->trans_no);
                              foreach($trans_date as $trans){
                                $tdate=$trans->trans_date;
                              }
                            ?>
                          <tr>
                           
                              <td style="text-align: center;"><?= $ledge->type_name;?></td>
                              <td style="text-align: center;"><?= $tdate;?></td>
                              <td style="text-align: center;"><?= $ledge->trans_no;?></td>
                              <td style="text-align: center;"><?= $ledge->full_name;?></td>
                              <td style="text-align: center;"><?= number_format($totals);?></td>
                              
                                                        
                          </tr>
                          <?php }?>
                          <tr>

                              
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td style="text-align: center;"><b>Total</b></td>
                              <td style="text-align: center;"><b><?php echo number_format($totalAmount); ?></b></td>
                              
                          </tr>
            <?php                       
          }else {
            echo '<tr>';
            echo '<td colspan="6"><i>Currently there is no history.</i></td>';
            echo '</tr>';
        }
        ?>                 
    </tbody>
</table>

   
</div>
</div>
</div>
<center>
 <button class="btn btn-primary btn-sm" onclick="printable_area('printcashdtls')"><span class="fa fa-print"></span> Print</button>
</center>
</div>
 

</body>
</html>
<script type="text/javascript">
    function printable_area(area) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=700, height=600, left=300, top=25";
        var content_vlue = document.getElementById(area).innerHTML;

        var docprint = window.open("", "", disp_setting);
        docprint.document.open();
        docprint.document.write('<html><head><title>MHI</title>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
//      function printable_area(printcashdtls) {
//      var printContents = document.getElementById(printcashdtls).innerHTML;
//      var originalContents = document.body.innerHTML;

//      document.body.innerHTML = printContents;

//      window.print();

//      document.body.innerHTML = originalContents;
// }
</script>