<?php
             $bmodel = new App\Models\BillingModel();
             $report = new App\Models\ReportsModel();
             $smodel = new App\Models\StudentModel();
             $dbname=session()->get('db_name');
             $db = \Config\Database::connect($dbname);
            $route=$report->get_specific_route($rtid);
              //echo count($list);
             $logo = $bmodel->get_table_details('company_tbl');
            if($logo[0]->logo_name != ""){
               $source =  base_url('public/company_photos/'.$logo[0]->logo_name);
            }

            if($route[0]->route_session==1){
                                    $sess='Morning';
                                }
                                elseif($route[0]->route_session==2){
                                    $sess='Afternoon';
                                }
                                elseif($route[0]->route_session==3){
                                    $sess='Evening';
                                }
                ?>
               <style type="text/css">
                   .custom-width {
               width: 3.5%; /* 1/12 = 8.33% */
                 }

                .bend-text {
                  transform: rotate(-45deg); /* Rotate the text 90 degrees counter-clockwise */
                  white-space: nowrap; /* Prevent text from wrapping */
                  height: 100px; /* Set the height of the rotated text */
                  vertical-align: middle; /* Vertically center the rotated text */
                }
               </style>
            <div id="tobeprinted">
            <center>
             <p> <img src="<?php  echo $source; ?>" style="width: 20%;height: 20%" ></p>
            <!-- <h3><b>INVOICE</b></h3> -->
            <!-- <div class="mt-3"><img src="<?php //echo $source; ?>" width="180" height="130"></div></br> -->
            <span class="mt-4"><b><?= $logo[0]->company_name; ?> </b></span><br>
            <span class="modify"><?= $logo[0]->address; ?>, Moshi, Tanzania</span>
            <div class="mb-3">
                <div><span class="modify">Phone: +<?= $logo[0]->phone1; ?></span></div>
                <div><span class="modify">Email: <?= $logo[0]->email; ?></span></div>
                <div><span class="modify"> <?= $logo[0]->website; ?></span></div>
             
            </div>
           <hr style="color:black;">

             <div class="modify mb-3"><span class="modify"><b> SCHOOL BUS ROUTE SCHEDULE</b></span></div>
        </center>
        <div class="row">
    <div class="col-md-1 custom-width"></div>
    <div class="col-md-8" id=''>
    <table class="mt-4">
        <tr>
                <td><b>DATE:</b></td><td style="padding-left:30px"></td><td><b><?php echo date('d/m/Y');?></b></td>
            </tr>
             <tr>
                <td><b>ROUTE NAME:</b></td><td style="padding-left:30px"></td><td><b><?php echo $route[0]->route_name;?></b></td>
            </tr>
            <tr>
                <td><b>VEHICLE NO:</b></td><td style="padding-left:30px"></td><td><b><?php echo $route[0]->vehicle_number;?></b></td>
            </tr>
             <tr>
                <td><b>VEHICLE CAPACITY:</b></td><td style="padding-left:30px"></td><td><b><?php echo $route[0]->capacity;?></b></td>
            </tr>
            <tr>
                <td><b>DRIVER NAME:</b></td><td style="padding-left:30px"></td><td><b><?php echo $route[0]->first_name.' '.$route[0]->last_name;?></b></td>
            </tr>
            <tr>
                <td><b>DRIVER'S NUMBER:</b></td><td style="padding-left:30px"></td><td><b><?php echo $route[0]->phone_no;?></b></td>
            </tr>
            <tr>
                <td><b>STARTING POINT :</b></td><td style="padding-left:30px"></td><td><b><?php echo $route[0]->station;?></b></td>
            </tr>
            <tr>
                <td><b>STARTING TIME:</b></td><td style="padding-left:30px"></td><td><b><?php echo $route[0]->start_time.' ('.$sess.')';?></b></td>
            </tr>
        </table>
    </div>
</div>

     <!----------------------------------------------------below students list by route date----------------->
 <div class="content-wrapper mt-3">
    <section class="content justify-content-center">
        <div class="box box-danger">
           
            <div class="box-body">
          
<div class="d-flex justify-content-center mt-3" id="pickdate">
  <form id="Rept1Result" class="d-flex align-items-center flex-wrap gap-2">
    <div class="d-flex align-items-center">
      <label for="class_id" class="form-label mb-0 me-2" style="color:black; font-weight:normal;">
        Class:
      </label>
      <select id="class_id" name="class_id" class="clss-select form-select form-select-sm w-auto" required>
        <option value="0">All</option>
        <?php
        if (isset($classes)) {
          foreach ($classes as $info) {
            echo '<option value="' . $info->id . '">' . $info->class_name . '</option>';
          }
        }
        ?>
      </select>
    </div>
    <button type="button" class="btn btn-outline-secondary btn-sm d-flex align-items-center" id="daterange-btn">
      <span>Please Select Date</span>
      <i class="fa fa-caret-down ms-1"></i>
    </button>
    <button type="submit" class="btn btn-primary btn-sm text-white">Create</button>

  </form>
</div>

                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>

            </div>
        </div>
    </section>
</div>
<footer class="mt-5"></footer>

</div>
   
<!----------------------------------------------------another code here----------------->
 

<noscript>
    <style>
        table.table{
            border-collapse:collapse;
            border: 1px solid black;
            width:100%;
          
            margin-left: auto;
            margin-right: auto;
/*            page-break-inside: avoid;*/
           
        }
         table.table td{
         border:1px solid black;
           font-size: 12px;
         }
          span,table{
         font-size: 12px;
         }
        #myTable2 td,#myTable2 th{
            border:1px solid black;
           font-size: 12px;
           }
        h6{
            text-align: center;
        }
        #pickdate{
           display: none;
        }
     .mt-5{
        padding-top: 80px;
     }
  @font-face {
  font-family: "Font Awesome 5 Free";
  font-display: auto;
} 
@media print {
  .fa-check::before {
    content: "\2713"; /* Unicode for checkmark symbol */
  }
   footer::after {
    content: "Powered by ELCO by Micro Health Initiative";
    display: block;
    text-align: center;
    font-size: 12px;
    color: #000;
    font-style: italic;
   
  }
}

    </style>

</noscript>

  <script>
      $('.clss-select').select2();
       $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                         'Today': [moment(), moment()],
                                        'This Week': [moment().startOf('week'), moment().endOf('week')],
                                        'Next 7 Days ': [moment(), moment().add(6, 'days')],
                                        'Next 30 Days': [moment(), moment().add(29, 'days')],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Next Month': [moment().add(1, 'month').startOf('month'), moment().add(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });
   $('#Rept1Result').submit(function (e) {
      e.preventDefault();
             if (!$('#daterange-btn span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "thedate=" + $('#daterange-btn span').html() +"&class_id=" + $('#class_id').val() + "&routeid="+<?php echo $rtid; ?>;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/view_route_shedule'; ?>',
                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
      
    });
   $('#print_att').click(function(){
   
       window.onbeforeprint = function() {
    // Hide search box and entries option
    table.search('').draw();
    table.page.len(-1).draw();
  };
  
  
        var _c = $('#tobeprinted').html();
        var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=800,height=600')
        /////////////////////////////////////
          // Adding custom styles for printing
nw.document.write('<style>');

nw.document.write('@media print {');


nw.document.write('body {');
nw.document.write('font-family: "Times New Roman", sans-serif;');
nw.document.write('font-size: 13px;');
nw.document.write('}');

nw.document.write('table {');
nw.document.write(' margin: 0 auto;');
nw.document.write('border-collapse: collapse;');
nw.document.write('font-size: 12px;');
nw.document.write('width: 70%;');
nw.document.write('margin-right: 20px;');
nw.document.write('}');
nw.document.write('th, td {');
nw.document.write('border: 1px solid black;'); // Define border properties for table cells
nw.document.write('padding: 5px;');

nw.document.write('}');
nw.document.write('}');
nw.document.write('</style>');
     ////////////////////////////////
        nw.document.write(_c)
        nw.document.write('<html><head><title>MHI</title><link rel="stylesheet" href="<?php echo base_url() . 'syst_assets/'; ?>bootstrap/css/bootstrap.css" media="all">')
        nw.document.write(ns.html())
        //nw.document.close()
        nw.print()
  
     });
  </script>
