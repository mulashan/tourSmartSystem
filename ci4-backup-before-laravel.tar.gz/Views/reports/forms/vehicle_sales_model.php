  <?php  
$imodel = new App\Models\ItemsModel();
helper('age');
 //$age = findAge($student_dtl[0]->birth_date);
 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
 list($startingdate, $endingdate) = explode('-', $thedate);
 $vhc=$amodel->get_item_name('vehicles_list_tbl', $where = array('id' => $vid));
 $dr=$amodel->get_item_name('users', $where = array('user_id' => $vhc[0]->driver_name));
 ?>
 <div class="section-body mt-4">
    <div class="container-fluid">
        <center>
            <h5>VEHICLE SALES</h5>   
            <h5>FROM: <?php echo date('d/m/Y',strtotime($startingdate));?> TO 
                 <?php echo date('d/m/Y',strtotime($endingdate));?>
            </h5>
        </center>
          <table class="mb-3 mt-3 pull-left">
              <thead>
                <tr><th>VEHICLE NO:</th><th><?php echo $vhc[0]->vehicle_number;?></th> </tr>
                <tr><th>VEHICLE CAPACITY:</th><th><?php echo $vhc[0]->capacity;?></th> </tr>
                <tr><th>DRIVER NAME:</th><th><?php echo $dr[0]->first_name.' '.$dr[0]->last_name;?></th> </tr>
                <tr><th>DRIVER'S NUMBER:</th><th><?php echo $dr[0]->phone_no;?></th> </tr>
             
              </thead>
          </table>
          <!-- <div class="card row mb-3 col-md-12">
         
                            <div class="form-check">
                                <label class="form-check-label me-4" for="all">
                                Permit Status:
                                </label>
                                 
                                 <input type="checkbox" name="type" value="1" onclick="checkbox1(1)" id="opt1">
                                 <label class="form-check-label me-3" for="all">
                                    Active
                                </label>
                               <input type="checkbox" name="type" value="4" onclick="checkbox1(4)" id="opt4">
                                 <label class="form-check-label me-3" for="all">
                                    Paid
                                </label>
                                <input type="checkbox" name="type" value="3" onclick="checkbox1(3)" id="opt3">
                                 <label class="form-check-label me-3" for="all">
                                    Pending
                                </label>
                                <input type="checkbox" name="type" value="2" onclick="checkbox1(2)" id="opt2">
                                 <label class="form-check-label me-3" for="all">
                                    Expired
                                </label>
                            </div>
                         </div> -->
                     
                             
                         
                <div class="card">
                <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable2" style="width: 100%;">
                            <thead>
                                <tr>
                                     
                                    <th>P No</th>
                                    <th>P DATE</th>
                                    <th>STUDENT NAMES</th>
                                    <th>CLASS</th>
                                    <th>AGE</th>
                                    <th>STATIONS</th>
                                    <th>P START</th>
                                    <th>P END</th>
                                    <th class="text-right">AMOUNT</th>
                                    <th>P STATUS</th>
                                   
                                    
                                </tr>
                            </thead>
                            <?php
                           for($i=1;$i<=4;$i++) {
                               // code...
                           
                            ?>
                            <tbody id="load_results<?php echo $i;?>">
                            <tbody id="load_total<?php echo $i;?>"></tbody>
                             <?php
                              }
                             ?>   
                            <tbody id="sum_total"></tbody>
                      </table>
                  
                    </div>
                </div>
        <!---------------------------------------------------->       
            </div>
          
        </div>
 
        <script type="text/javascript">
       var totalsum=0;
$(document).ready(function () {
     checkbox1(1);
      checkbox1(2);
      checkbox1(3);
     checkbox1(4);
    
    });

function checkbox1(type){

     var rows = '';
     var row = '';
     if(type==1){
        var st="Active";
     }else if(type==2){
        var st="Expired";
     }else if(type==3){
        var st="Pending";
     }else if(type==4){
        var st="Paid";
     }

     // const checkbox0 = document.getElementById('opt0');
     // const checkbox1 = document.getElementById('opt1');
     //    const checkbox2 = document.getElementById('opt2');
     //    const checkbox3 = document.getElementById('opt3');
     //    const checkbox4 = document.getElementById('opt4');
      //var type= id;
     // if(type==0){
         
         //  $('#load_results1').html('');
         //  $('#load_results2').html('');
         //  $('#load_results3').html('');
         //  $('#load_results4').html('');
         // checkbox0.checked = true;
         // checkbox1.checked = false;
         //    checkbox2.checked = false;
         //    checkbox3.checked = false;
         //    checkbox4.checked = false;
           
      //}else{
        //const checkbox = document.getElementById('opt'+type);
        // checkbox0.checked = false;
       // $('#results').hide(); 
        //  if (checkbox.checked){ 
       $('#load_results'+4).html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
     var data = 'type=' + type+'&thedate=' + '<?php echo $thedate;?>'+'&vid=' + '<?php echo $vid;?>';
     
     $.ajax({
            type: 'POST',
            data: data,
            url: '<?php echo base_url() . '/index.php/ReportsController/load_status_report'; ?>',
             //dataType: "json",
            success: function(res){
                $('#load_results'+type).html('');
                 // alert(res);
                const jsonData = res.replace(/<!--[\s\S]*?-->/g, '').trim();
               const dataArray = JSON.parse(jsonData);
               console.log(dataArray);
                  var len  = dataArray.length;
                    //alert(len);
                  var total=0;
                  if(len>0){
                       for (var i = 0; i <len; i++ ){
                       total=total+parseInt(dataArray[i]['amount']);
                            rows += '<tr>';

                           rows+='<td>'+dataArray[i]['pid']+'</td>';
                             rows+='<td>'+dataArray[i]['date_created']+'</td>';
                            rows+='<td>'+dataArray[i]['full_name']+'</td>';
                             rows+='<td>'+dataArray[i]['class']+'</td>';
                           rows+='<td>'+dataArray[i]['age']+'</td>';
                             rows+='<td>'+dataArray[i]['station']+'</td>';
                             rows+='<td>'+dataArray[i]['start_date']+'</td>';
                             rows+='<td>'+dataArray[i]['end_date']+'</td>';
                             rows+='<td class="text-right">'+dataArray[i]['amount'].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>';
                             rows+='<td style="color:'+dataArray[i]['color']+'">'+dataArray[i]['status']+'</td>';

                            rows += '</tr>';
                           
                            
                        }}
                        row += '<tr>';
                        row+='<td colspan="7"></td><td>Total '+st+'</td>';
                        row+='<td class="text-right"><b>'+total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</b></td>';
                        row += '</tr>';
                        if(total>0){
                         $('#load_results'+type).append(rows);
                         $('#load_total'+type).append(row);
                         totalsum=totalsum+total;
                          appendTotal(totalsum);
                         //alert(totalsum);
                          console.log(totalsum);
                          return totalsum;
                     }
                      
            },
              error:function(res){
              alert('something went wrong');
              }
            }); 
      // }else{
      //   $('#load_results'+type).hide();
      // }
      //}
    };
    function appendTotal(sum){
      //  alert(totalsum);
         $('#sum_total').html('');
        var rowt='';
       rowt += '<tr>';
    rowt+='<td colspan="7"></td><td><b>Total</b></td>';
    rowt+='<td class="text-right"><b>'+sum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</b></td>';
    rowt += '</tr>';
    $('#sum_total').append(rowt);
    }

     function printable_report(area) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=700, height=600, left=100, top=25";
        var content_vlue = document.getElementById(area).innerHTML;

        var docprint = window.open("", "", disp_setting);
        docprint.document.open();
        docprint.document.write('<html><head><title>Econnect</title>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }   
</script>