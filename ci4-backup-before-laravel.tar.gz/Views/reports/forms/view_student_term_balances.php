<?php if (count($cl) > 0): ?>
<div id="tobeprinted">
    <?php if ($schoolname !== ''): ?>
        <h6><b><?= esc($schoolname); ?></b></h6>
    <?php endif; ?>
    <h6><?= esc($reportTitle); ?></h6>

    <table class="table table-condensed table-centre">
        <thead>
            <tr>
                <th class="text-left">Term</th>
                <th class="text-right">Open Bal</th>
                <th class="text-right">Installments</th>
                <th class="text-right">Due Date</th>
                <th class="text-right">Paid</th>
                <th class="text-right">Balance</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($termBalanceRows as $row): ?>
                <tr>
                    <th><?= esc($row['term_name']); ?></th>
                    <th style="text-align:right;"><?= number_format($row['open']); ?></th>
                    <th style="text-align:right;"><?= number_format((float) $row['ment'], 2); ?></th>
                    <th style="text-align:right;"><?= date('d-M-Y', strtotime($row['due_date'])); ?></th>
                    <th style="text-align:right;"><?= number_format($row['paid']); ?></th>
                    <th style="text-align:right;"><?= number_format($row['balance']); ?></th>
                </tr>
            <?php endforeach; ?>

            <tr>
                <td><b>Total</b></td>
                <td align="right"><b><?= number_format($termBalanceTotals['open']); ?></b></td>
                <td align="right"><b><?= number_format((float) $termBalanceTotals['installments'], 2); ?></b></td>
                <td align="right"><b></b></td>
                <td align="right"><b><?= number_format($termBalanceTotals['paid']); ?></b></td>
                <td align="right"><b></b></td>
            </tr>
        </tbody>
    </table>
</div>
<?php endif; ?>
