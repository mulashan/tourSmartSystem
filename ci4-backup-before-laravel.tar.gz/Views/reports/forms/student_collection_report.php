<style media="print">
@media print{
table{
display:table!important
}
}
</style> 
<!DOCTYPE html>
<?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
    $cname = $remodel->getonlycname($cid);
 foreach($cname as $nm){
    $name=$nm->class_name;
 }
 $stname=$remodel->studentname($stid);
 ?>

<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>
<body>
<div>
<div id="printcashdtls">
    <center>
        <?php
 $schoolname=$remodel->get_schoolname();
            
            echo "<h5><b>".$schoolname[0]->company_name."</h5>";
            echo "<p><span style='padding-right:80px'>".$schoolname[0]->address."</span> ".$schoolname[0]->email."</p>";
            echo "<h5>OUTSTADING BALANCE STATEMENT</h5>";
            echo "<h5>From ".$start." to ".$end."</h5>";
            echo "<h6>Student name: ".$stname[0]->full_name."</b></h6>";
        ?>
       
    
    </center>

                           
                     <div class="card">
                      
                    <div class="table-responsive mt-3">
                        <table class="table table-bordered table-vcenter att-list" id="myTable2">
                            <thead style="border:1px solid silver;">
                               
                                <tr>
                                     <th style="text-align: center;">TOTAL DEBIT</th>
                                    <th style="text-align: center;">TRANS TYPE</th>
                                    <th style="text-align: center;">ACCOUNT NAME</th>
                                    
                                     <th style="text-align: center;">TRANS DATE</th>

                                    
                                   <th>TRANS NO</th>
                                   <th style="text-align: center;">CREDIT</th>
                                    <th style="text-align: center;">DEBIT REMAIN</th>
                                   
                                    
                                    
                                
                                </tr>
                            </thead>
                           <tbody style="border: 1px solid silver;">
                         <?php
                                $tinvoice=0;
                              $invoiced=$remodel->class_invoice($stid,$start,$end);
                              
                              foreach($invoiced as $inv){
                                $tinvoice=$tinvoice+$inv->amount;
                              }
                            ?>
                          <tr id="printHeader2">
                           
                              <!-- <td style="text-align: center;"><?= $stname[0]->full_name;?></td> -->
                              <td style="text-align: center;"><?= number_format($tinvoice);?></td>
                              <?php 
                              $treceipt=0;
                              $i=0;
                              if(count($class)>0){
                               foreach($class as $stu){
                                $i++;
                                $treceipt=$treceipt+$stu->amount;
                                $outstand=$tinvoice-$treceipt;
                                if($i>1){
                                    echo "<td></td>";
                                    // echo "<td></td>";
                                }
                               ?>
                               <td style="text-align: center;"><?= $stu->type_name;?></td>
                               <td style="text-align: center;"><?= $stu->account_name;?></td>
                               <td style="text-align: center;"><?= $stu->trans_date;?></td>
                              <td style="text-align: center;"><?= $stu->trans_number;?></td>
                             
                            <td style="text-align: center;"><?= number_format($stu->amount);?></td>
                              
                               <td style="text-align: center;"><?= number_format($outstand);?></td>
                              </tr>
                              <?php 
                              }
                          }else{
                                echo "<td>There is no any payment</td>";
                              }
                              ?>
                                                        
                          
                          
                                  
    </tbody>
</table>

   
</div>
</div>
</div>
<center>
 <button class="btn btn-primary btn-sm" onclick="printable_area('printcashdtls')"><span class="fa fa-print"></span> Print</button>
</center>
</div>
 

</body>
</html>
<noscript>
    <style>
        table.att-list{
            width:100%;
            border-collapse:collapse
        }
        table.att-list td,table.att-list th{
            border:1px solid
        }
        .text-center,.text-c{
            text-align:center
        }
        #cont{
            display: none;
        }
    </style>
</noscript>
<script type="text/javascript">
 
function printable_area(printcashdtls) {
       var TableToPrint = document.getElementById('myTable2');
       var ns = $('noscript').clone();
       var htmlToPrint = '' +
           '<style type="text/css">' +
               'table th, table td {' +
               'padding: 5px; ' +'color: black; ' +

               '}' +
               ' #printHeader2{border-left: none!important; border-right: none!important;}' +
               ' #myTable2{padding: 4px; border-collapse:collapse; font; font-size:12pt;}' +
               ' #printHeader2 td{ border-bottom: solid black 1px; border-right: solid black 1px!important; }' +
               ' td{ border-bottom: solid black 1px; border-right: solid black 1px!important; border-left: solid black 1px!important; }' +
           '</style>';
       htmlToPrint += TableToPrint.outerHTML;
       newWin = window.open("");
       newWin.document.write('<head><title>MHI</title></head>');
       newWin.document.write("<h3><center><?= $schoolname[0]->company_name;?></center></h3>");
        newWin.document.write("<h3><center><span style='padding-right:80px'><?= $schoolname[0]->address;?></span><?= $schoolname[0]->email;?></center></h3>");
       newWin.document.write("<h3><center>OUTSTANDING BALANCE STATEMENT</center></h3>");
       newWin.document.write("<h3><center>Student name:<?= $stname[0]->full_name;?></center></h3>");
       newWin.document.write(ns.html())
       newWin.document.write(htmlToPrint);
       newWin.print();
       newWin.close();
   }
        
</script>