<?php
             $bmodel = new App\Models\BillingModel();
             $report = new App\Models\ReportsModel();
             $smodel = new App\Models\StudentModel();
                  $dbname=session()->get('db_name');
                    $db = \Config\Database::connect($dbname);
           // $hname=$this->report->get_hostelname($hostel);
              //echo count($list);
                ?>
               
                 <!----------------------------------------------------below students list by route date----------------->

           
              <div class="card">
               <div class="table-responsive mt-3">
                <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                           <thead>
                            <tr>
                                 
                                 <th>#</th>
                                 <th>Names</th>
                                 <th>Age</th>
                                 <th>Gender</th>
                                 <th>Class</th>
                                 <th>parent</th>
                                 <th>Phone</th>
                                 <th>Route</th>
                                 <th>Vehicle Name</th>
                                 <th>Vehicle Number</th>
                                 <th>Driver</th>
                                 <th>Phone</th>
                                </tr>
                                <thead>
                                    <tbody>
                                        <?php
                                        $n=0;
                             foreach($list as $st){
                                $n++;
                               $pr=$smodel->gettable_parent($st->student_id);
                                $vh = $smodel->gettable_data('vehicles_list_tbl', $where = array('id' => $st->vehicle));
                                  $drv = $smodel->gettable_data('users', $where = array('user_id' => $vh[0]->driver_name));
                                        ?>
                                <tr>
                                  <td><?php echo $n; ?></td>
                                  <td><?php echo $st->full_name; ?></td>
                                  <td><?php echo (date('Y') - date('Y',strtotime($st->birth_date))); ?></td>
                                  <td><?php echo $st->gender; ?></td>
                                  <td><?php echo $st->class_name; ?></td>
                                  <td><?php echo $pr[0]->first_name.' '.$pr[0]->last_name; ?></td>
                                  <td><?php echo $pr[0]->phone1; ?></td>
                                   <td><?php echo $st->route_name; ?></td>
                                   <td><?php echo $vh[0]->driver_contact; ?></td>
                                   <td><?php echo $vh[0]->vehicle_number; ?></td>
                                   <td><?php echo $drv[0]->first_name.' '.$drv[0]->last_name; ?></td>
                                   <td><?php echo $drv[0]->phone_no; ?></td>
                                </tr>
                                <?php
                                     }
                                        ?>
                                  </tbody>
                                   </table>

      </div>
      </div>
 
<noscript>
    <style>
        .table-condensed{
            padding-bottom: 20px; 

        }
        table.table{
            border-collapse:collapse;
            border: 1px solid black;
            width:80%;
          
            margin-left: auto;
            margin-right: auto;
/*            page-break-inside: avoid;*/
           
        }
         table.table td{
         border:1px solid black;
           font-size: 12px;
         }
        #myTable td,#myTable th{
            border:1px solid black;
           font-size: 12px;
           }
        h6{
            text-align: center;
        }
        .btnp,.viewbtn{
           display: none;
        }
        #myTable_wrapper .dataTables_filter,
        #myTable_wrapper .dataTables_paginate,
        #myTable_wrapper .dataTables_length {
         display: none;
}
 @media print {
      .table {
        border-collapse: collapse !important;
        border: 1px solid black !important;
      }
      }
      table.toba td{
        font-size: 12px;
      }
        
    </style>
</noscript>
  <script>
   $(document).ready(function() {
  var table = $("#myTable").DataTable({
    dom: 'f', // Show only the search input
    paging: false, // Disable pagination
    lengthChange: false, // Disable entries select
  });
});
 
  </script>
