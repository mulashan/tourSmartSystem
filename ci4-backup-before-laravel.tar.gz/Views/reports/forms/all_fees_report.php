<style type="text/css">
    @media print {
    hr {
        display: block;
      border: none;
      border-top: 1px solid black;
      margin: 10px 0;
    }
  }
</style>

<?php
$dbname=session()->get('db_name');   
$db = \Config\Database::connect($dbname);
 helper('calc');
  $bmodel = new App\Models\BillingModel();
  $smodel = new App\Models\StudentModel();
  $cmodel = new App\Models\ClassesModel();
  $appItems = $cmodel->get_applications_items();
 $logo = $bmodel->get_table_details('company_tbl');
            if($logo[0]->logo_name != ""){
               $source =  base_url('public/company_photos/'.$logo[0]->logo_name);
            }
//echo $student_id;
            $admn = $bmodel->get_item_name('students', $where = array('id'=>$student_id));
            $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name;

            $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $admn[0]->id, 'status' => 1,'academic_year'=>$year));
            $hst=0;
            if(count($admissn) > 0){
                $adm_id = $admissn[0]->class_id;
                $hst = $admissn[0]->admission_type;
                $trns = $admissn[0]->vehicle_id;
                $for = $admissn[0]->adimit_for;
                $lvid = $admissn[0]->level_id;
                //echo $hst;
            }else{
                // $data=array(
                //     'student'=>$student_id,
                //     'year'=>$year
                //     );
                // return $data;
            }
            if($hst >0){
                $hostel="Boarding";
            }else{
               $hostel="Day"; 
            }
            $class = $bmodel->get_item_name('classes_tbl', $where = array('id' => $adm_id)); 
            $lvtbl = $bmodel->get_item_name('class_level_tbl', $where = array('id' => $lvid)); 
            $student_id=$admn[0]->id;
            $debt=0;
            $credit=0;
            $ref="";
            $balance= $bmodel->get_item_name('student_balance_tbl',$where=array('year'=>$year-1,'student_id'=>$student_id));
                     if(count($balance)>0){
                        $debt=$balance[0]->present_debit;
                        $credit=$balance[0]->balance;
                      if($debt >0){
                        
                          $referece =$bmodel->get_item_name('payment_request',$where=array('student_id'=>$student_id,'trans_no'=>$balance[0]->debted_inv_no,'inv_type'=>0,'trans_type'=>1));
                          if(count($referece)>0){
                            $ref=$referece[0]->reference_no;
                          }
                      }
                     }
                     
       $phone = $db->query('SELECT phone1 FROM parents_tbl,parents_students_tbl WHERE parents_tbl.id = parents_students_tbl.parent_id AND'
               . ' parents_tbl.bill_account = 1  AND parents_students_tbl.student_id ='.$student_id.'');
             $pn = $phone->getResult(); 
               if(count($pn)>0){
                $phone=$pn[0]->phone1;
               }else{
                 $phone="---";
               }
?>
<div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8" id=''>
        <center>
            <div class="img"> <img src="<?php  echo $source; ?>"  style="background: white;width: 40%;height: 25%" ></div>
            <!-- <h3><b>INVOICE</b></h3> -->
            <!-- <div class="mt-3"><img src="<?php //echo $source; ?>" width="180" height="130"></div></br> -->
            <span class="mt-4"><b><?= $logo[0]->company_name; ?> (EGET)</b></span><br>
            <span class="modify"><?= $logo[0]->address; ?>, Moshi, Tanzania</span>
            <div class="mb-3">
                <div><span class="modify">Phone: +<?= $logo[0]->phone1; ?></span></div>
                <div><span class="modify">Email: <?= $logo[0]->email; ?></span></div>
                <?php
                if($logo[0]->website=='0'){
                    $website='';
                }else{
                  $website=$logo[0]->website;
                }
                ?>
                <div><span class="modify"> <?= $website; ?></span></div>
             
            </div>
           <hr style="color:black;">

              <div class="modify">
                  <span><b> RATIBA YA MALIPO YA ADA YA MWANAFUNZI</b></span>
                <i style="float:right;margin-right: 80px;">
                <b>Tarehe: <?php echo date('d/m/Y');?></i></b>
            </div>
        </center>
    <?php if($debt>0){?>  
   <div class="mt-4 space1" style="text-align: justify;">
    <span>Baki ya <?php echo $year-1; ?>: TZS <?php echo number_format($debt); ?> (Tumia Namba ya Malipo <b><?= $ref;?></b>)</span>
   </div>
 <?php }?>
  <?php if($credit<0){?>  
   <div class="mt-4 space1">
    <span>Baki ya <?php echo $year-1; ?>: TZS <?php echo number_format($credit); ?> </span>
   </div>
 <?php }?>
   <div class="mt-4 space1">
       <span><b>Mwaka wa Masomo:</b> <?= $year;?></span>
   <span style="float:right;margin-right: 80px;"><b>Darasa:</b> <?= $class[0]->class_name.', '.$hostel;?></span></div>

    <div class="mt-2 space1"><span><b>Jina la mwanafunzi:</b> <?= $student_name;?></span></div>
     <div class="mt-3 space1"><span><b>Ujumbe uliotumwa namba +<?=$phone;?></b> </span></div>

    <div id="message2" class="col-md-12 mt-1 space2" style="border: 1px solid black;width: 95%;"></div>

    <div class="mt-3 mb space1" style="text-align: justify;"><span>Chini ni ratiba ya ada ya shule kwa mwanafunzi aliye tajwa hapo juu:</span></div>
    <!----------------------------------------------------------------->
     <table class="table table-condensed table-centre">
      
            <thead>
                <tr>
                     

                    <th class="text-left">Muhula</th>
                    <th class="text-right">Salio la Mwanzo</th>
                    <th class="text-right">Malipo ya Awamu</th>
                    <th class="text-right">Tarehe ya Mwisho</th>
                    <th class="text-right">Kilicholipwa</th>
                    <th class="text-right">Baki</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                
                $ctrNum="";
                 
                    //echo $year;
             $results=findCalc($student_id,$dbname,$year);
          
                 $tinvoice = $bmodel->get_total_invoice_amount($student_id,$year);
                 if(count($tinvoice)>0){
                    foreach($tinvoice as $ti){
                    $adms =$bmodel->get_item_name('invoice_type_transaction',$where=array('trans_no'=>$ti->trans_no,'invoice_type_id'=>2));
                    if(count($adms)>0){
                     $ctr_num =$bmodel->get_item_name('payment_request',$where=array('student_id'=>$student_id,'trans_no'=>$ti->trans_no,'inv_type'=>0,'trans_type'=>1));
                 if(count($ctr_num)>0){
                    $ctrNum=$ctr_num[0]->reference_no;
                     
                 }   
                    }
                 }
                 }

                   $installments =$bmodel->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$lvtbl[0]->academic_type));
                   $joined_date =$bmodel->get_item_name('admission_tbl',$where=array('academic_year'=>$year,'student_id'=>$student_id));
                   // $k=0;
                   // $m=0;
                  
                      $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                    $todaybalance=0;
                       foreach ($installments as $r) {
                         $openingbalance=0;
                        // $paid_amount=0;
                      $i++;
                     
                     if($i==1){
                    
                      $openingbalance=$results[0]['openingbalance'];
                      $open=$openingbalance;
                       $ment=$results[0]['ment'];
                        $ment1=$results[0]['ment'];
                        $mbalance=$results[0]['mbalance'];
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                    if($results[$i-1]['today']==1){
                       $todaybalance=$results[$i-1]['todaybalance']; 
                       
                     }
                  
                     }
                      if($i==2){
                
                       $ment=$results[1]['ment'];
                        $mbalance=$results[1]['mbalance'];
                        $paid_amount=$results[1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                  
                     if($results[$i-1]['today']==1){
                       $todaybalance=$results[$i-1]['todaybalance']; 
                       
                     }
                     }
                   if($i==3){
        
                     $ment=$results[2]['ment'];
                        $mbalance=$results[2]['mbalance'];
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                    if($results[$i-1]['today']==1){
                       $todaybalance=$results[$i-1]['todaybalance']; 
                       
                     }
                     }
                     
                      if($i==4){
                       $ment=$results[$i-1]['ment'];
                        $mbalance=$results[$i-1]['mbalance'];
                        $paid_amount=$results[$i-1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[$i-1]['today']==1){
                       $todaybalance=$results[$i-1]['todaybalance']; 
                     }
                     }

                       $name = $bmodel->get_item_name('students',$where = array('id' => $student_id));
                      if($tments - $tpaid >0){
                        $usumbufu="Kamilisha malipo kuondoa usumbufu";
                      }else{
                        $usumbufu="";
                      }

                      if($todaybalance <0){
                        $todaybal=0;
                     }else{
                      $todaybal=$todaybalance;  
                     }
                     if(session()->get('db_id')==4){ 

                      $message="Mzazi wa ".$name[0]->first_name.";  Kristo! Baki ya Muhula TZS ".number_format($todaybal)." Baki ya mwaka TZS ".number_format($tments+$open - $tpaid).". Kamilisha malipo na Mungu akubariki.";
                      }else {
                      $message="Mzazi wa ".$name[0]->first_name."; Baki ya Muhula TZS ".number_format($todaybalance)." Baki ya mwaka TZS ".number_format($tments+$open - $tpaid).". ".$usumbufu."";     
                      }
                    
                ?>  
                <tr>
                    <td><?= $r->term_name; ?></td>
                     <td style="text-align:right;"><?= number_format($openingbalance); ?></td>
                    <td style="text-align:right;"><?= number_format($ment); ?></td>
                    <td style="text-align:right;"><?= date('d-M-Y',strtotime($r->due_date)); ?></td>
                    <td style="text-align:right;"><?= number_format($paid_amount); ?></td>
                    <td align="right"><?= number_format($mbalance); ?></td>
                </tr>
                <?php  }?>  
                <tr>
                    <td><b>Total</b></td>
                      <td align="right"><b><?= number_format($open); ?></b></td>
                    <td align="right"><b><?= number_format($tments); ?></b></td>                    
                    <td align="right"><b><?//= number_format($tments); ?></b></td>
                     <td align="right"><b><?= number_format($tpaid); ?></b></td>  
                    
                    <td align="right"><b></b></td>
                    
                </tr>      
            </tbody>
        </table>
    
    <!--------------------------------------------------------------------->
    <?php //if($ctrNum==""){}else{?>
     <div class="mt-4 kindly" style="text-align: justify;">
         <span>Tafadhali lipa ada ya shule kwa kutumia namba ya malipo <b><?php echo $ctrNum;?></b> kupitia njia zifuatazo za CRDB:</span></div>

        <div class="mt-4"  style="text-align: justify;"><span>Wakala, SimBanking, Tawi la Benki, Internet Bankig, SIMUSSD, MPESA </span></div>
        <!--<div class="mt-4"><span></span></div>-->
        <!--<div class="mt-4"><span></span></div>-->
    <div class="mt-4"  style="text-align: justify;">
        <span style="font-size:16px"><b><u>NB:</u></b><br></span>
        <span> <b>>></b>Ikiwa mwanafunzi anadaiwa ela ya nyuma siku ya kufungua shule hataruhusiwa kuingia shuleni. </span><br>
    <span> <b>>></b>Pia mwanafunzi  ambaye atalipa ada ya muhula wa kwanza chini ya <b><?php echo number_format($ment1);?> </b> hatopokelewa shuleni siku ya kufungua shule. </span>
    </div>
    
      <div class="mt-4"  style="text-align: justify;"><span>Ikiwa una swali lolote, tafadhali wasiliana nasi kupitia <b><?= $logo[0]->phone2; ?></b></span></div>
      <div class="mt-4 line"><span class="">Asante.</span></div>
      
      <div class="mt-4 line" style="border-bottom: 1px solid black; width: 120px;"></div>
     
      <div class="mt-1" style="text-align: justify;"><span>Ofisi ya Hesabu</span></div>

<center><div class="mt-4">Tafadhali kumbuka, ada zote za shule hazirudishwi.</div></center>
<center><div class="mt-1"><i>Hati hii imetengenezwa na mfumo wa kompyuta unaoendeshwa na Micro Health Initiative.</i></div></center>
    </div>
     <div class="col-md-2"></div>
</div>
 <noscript>
    <style>
        .table-condensed{
            padding-bottom: 20px; 
        }
        table.table{
            width:80%;
            border-collapse:collapse;
            margin-left: auto;
            margin-right: auto;
           
        }
        table.table td,table.table th{
            border:1px solid;
           
        }
        .mt-1,.mt-4,.mt-2,.modify,.mb{
            font-size: 15px;
            padding-bottom: 20px;
        }
        .line{
            padding-bottom: 80px;
          border-bottom: 1px solid black; 
          width: 120px;  
        }
        .kindly{
            padding-top: 20px;
        padding-bottom: 0px;
        }
  
    /*.print-line {
      border-top: 10px solid black;
      margin: 10px 0;
    }
  */
    </style>
</noscript>
<script type="text/javascript">
    var msg='<?php echo $message;?>';
    $('#message2').html(msg);
    </script>
