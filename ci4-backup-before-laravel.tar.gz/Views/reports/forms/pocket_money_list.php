  <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
  $bmodel = new App\Models\BillingModel();
    $admodel = new App\Models\AdmissionModel();

  helper('age');

 ?>
 <div class="section-body mt-4">
    <div class="container-fluid">
             
                <div class="card">
               <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable2">
                            <thead>
                                <tr>
                                     
                                    <th>#</th>
                                    <th>Permit No</th>
                                    <th>Permit Date</th>
                                    <th>Student Name</th>
                                    <th>DOB</th>
                                    <th>Age</th>
                                    <th>Level</th>
                                    <th>Class</th>
                                    <th>Stream</th>
                                    <th>Hostel</th>
                                    <th>Collected</th>
                                      <th>Used</th>
                                    <th>P/money Bal</th>
                                  
                                    <th></th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                              <?php
                          echo count($bd_val);
                               $tbamount=0;
                                $tcamount=0;
                          if(count($bd_val)>0){
                            $i=0;
                            foreach ($bd_val as $value) {
                                // $checkIfPocket = $bmodel->get_item_name('item_transation_tbl',$where = array('trans_number' =>$value->trans_no,'trans_type'=>3,'item_id'=>65));
                                // if(count($checkIfPocket)==0){
                                //  continue;
                                // }
                       
                           $sid = $bmodel->get_item_name('students',$where = array('id' =>$value->student_id));
                           $value->student_id=$sid[0]->id;
                           // if($sid[0]->status !=2){
                           //    continue;
                           //    }
                          // echo $value->full_name.'/'.$value->student_id.'-';
                            
                         $dbal = $remodel->refund_pocket_money($value->student_id);
                        
                         //print_r($dbal);
                        
                        //print_r($dbal);
                          $bamount=0;
                          $camount=0;
                          $usedAmount=0;
                        foreach($dbal as $val){
                         //continue;     
                            $check_y=$admodel->get_student_details_byYear('transaction_numbers_tbl', $where = array('trans_number' => $val->trans_no,'trans_type_id'=>3,'status'=>1), $year);
                            if(count($check_y)>0){
                                    $camount+=$val->amount;
                                 }

                            }
                        //  echo $value->student_id.'/'.$year;
                         $check_used = $amodel->gettable_data('pocket_money_transaction_tbl', $where = array('student_id' => $value->student_id,'academic_year'=>$year));
                              //  echo $value->student_id;
                                if(count($check_used)>0){
                                  foreach($check_used as $used){
                                       // echo $used->amount_given."</br>";
                                 $usedAmount+=$used->amount_given;    
                                
                                  }
                                 }
                               
                              $bamount=$camount-$usedAmount;
                              $tbamount+=$bamount;  
                              $tcamount+=$camount;
                            
                             $i++;
                              ?>
                                <tr>
                            <td><?php echo $i;?></td>
                            <td><?php echo $value->permit_id;?></td>
                            <td><?php echo $value->created_date;?></td>
                            <td><?php echo $value->full_name;?></td>
                            <td><?php echo $value->birth_date;?></td>
                            <td><?php echo findAge($value->birth_date);?></td>
                            <td><?php echo $value->level_name;?></td>
                            <td><?php echo $value->class_name;?></td>
                            <td><?php echo $value->stream_name;?></td>
                            <td><?php echo $value->hostel_name;?></td>
                             <td class="text-right"><?php echo number_format($camount);?></td>
                             <td class="text-right"><?php echo number_format($usedAmount);?></td>
                            <td class="text-right"><?php echo number_format(($bamount));?></td>
                             
                            <td>
                                <a href="javascript:void(0)"  class="btn btn-primary btn-sm invoiceprint" onclick="view_pocketMoney('<?php echo $value->student_id;?>')"><i class="fa fa-eye"></i> View</a>
                            </td>
                                 </tr>
                                <?php
                               // return;
                            }
                            }else{
                               ?>
                               <tr><td colspan="4"></td>
                                <td>No data available</td></tr>
                                <?php
                            }
                             ?>
                             <tr>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td>Total</td>
                                 <td class="text-right"><?php echo number_format($tcamount)?></td>
                                 <td class="text-right"><?php echo number_format($tcamount-$tbamount)?></td>
                                 <td class="text-right"><?php echo number_format($tbamount)?></td>
                             </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
          
        </div>
       <!-- ------View vehicle modal------- -->
<!-- ------manage invoice modal------- -->
<div class="modal fade" id="viewinvoice" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"  style="z-index: 1400;">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <!-- <h5>Pocket money Details</h5> -->
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewinvoice_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        
        <button type="button" class="btn btn-primary"  data-toggle="modal" onclick="invoice_print()"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>


        <script type="text/javascript">
// $(document).ready(function () {
//       $('#myTable2').DataTable();
//     });
function view_pocketMoney(student_id){
    //alert(student_id);
     $('#viewinvoice').modal('show'); 
       $('#viewinvoice_content').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
  $('#viewinvoice_content').load("<?php echo base_url() . '/index.php/ReportsController/view_pocket_money'; ?>/"+student_id);
}

</script>