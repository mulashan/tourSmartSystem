<?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\AdmissionModel();
 $remodel = new App\Models\ReportsModel();
 $billmodel = new App\Models\BillModel();
 //echo $thedate;
  $bank = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));
                          
 ?>

<div class="table-responsive">
   <table class="table table-hover table-vcenter mb-0 text-nowrap">
            <thead>
                <th>Account Name</th>
                <th class="text-right">Bal b/f</th>
                <th class="text-right">Amount in</th>
                <th class="text-right">Amount out</th>
                <th class="text-right">Current Bal</th>
                <th colspan="4"></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
               
            </thead>
            <tbody>
        <?php
        if(count($bank)>0){
            
            list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate);
            $sdate = strtotime($startingdate);

            $tbalance=0;
            $tbf=0;
            $tendbal=0;
            $tin=0;
            $tout=0;
            $treconciled=0;
         foreach($bank as $acc){
           
           // $rec=$billmodel->check_reconcilitoion($acc->id);
           // if(count($rec)>0){
           //  $last_date=date('Y-m-d',strtotime($rec[0]->end_date));
           //  $end_balance=$rec[0]->end_balance;
           // }else{
           //  $last_date="";
           //  $end_balance=0;
           // }
         //$treconciled=$treconciled+$end_balance;
             //calculating balance before the date----
            $s='01-01-2020';
            $end = strtotime('-1 day',strtotime($startingdate));
            $std = strtotime($s);
             
            // echo date('Y-m-d',$end);
            $before = $imodel->getSingle_view3($acc->id,date('Y-m-d', $std),date('Y-m-d', $end));
            //print_r($before);
            $balanceb=0;
            foreach($before as $bf){
           
           //check aproval status
                if($bf->trans_type==4 || $bf->trans_type==5){
                $approval_status1 = $amodel->get_student_details('approval_numbers', $where = array('trans_no' =>  $bf->trans_no,'trans_type'=>$bf->trans_type));
                 if(count($approval_status1)==0){
                 continue;
                }
          
                  $approval_status = $amodel->get_student_details('approval_history', $where = array('app_no' =>  $approval_status1[0]->app_id,'hstatus'=>1));
                if(count($approval_status)==0){
                 continue;
                }
              }

              if($bf->ledger_id==10 && $bf->trans_type==3){
                $check_status = $amodel->get_student_details('transaction_numbers_tbl', $where = array('status' => 1,'trans_type_id'=>$bf->trans_type,'trans_number'=>$bf->trans_no,'trans_desc !='=>""));
                if(count($check_status)==0){
                  continue;
                }
               }else if($bf->ledger_id==10 && $bf->trans_type!=3 && $bf->transation_nature==1){
                continue;
               }
         //end check aproval status

              if($bf->transation_nature==2){
                $balanceb=$balanceb+$bf->amount;
              }else{
              //  echo $balanceb;
               $balanceb=$balanceb-$bf->amount;
              }
             }
           //-------end calculation----------

            $ttl1=0; 
             $ttl2=0;
            $balance=0; 
              $data = $imodel->getSingle_view3($acc->id,date('Y-m-d H:i', $sdate),date('Y-m-d H:i', $enddate));
               foreach($data as $ledge){

                //check aproval status
                if($ledge->trans_type==4 || $ledge->trans_type==5){
                $approval_status1 = $amodel->get_student_details('approval_numbers', $where = array('trans_no' =>  $ledge->trans_no,'trans_type'=>$ledge->trans_type));
                 if(count($approval_status1)==0){
                 continue;
                }
          
                  $approval_status = $amodel->get_student_details('approval_history', $where = array('app_no' =>  $approval_status1[0]->app_id,'hstatus'=>1));
                if(count($approval_status)==0){
                 continue;
                }
              }

              if($ledge->ledger_id==10 && $ledge->trans_type==3){
                $check_status = $amodel->get_student_details('transaction_numbers_tbl', $where = array('status' => 1,'trans_type_id'=>$ledge->trans_type,'trans_number'=>$ledge->trans_no,'trans_desc !='=>""));
                if(count($check_status)==0){
                  continue;
                }
               }else if($ledge->ledger_id==10 && $ledge->trans_type!=3 && $ledge->transation_nature==1){
                continue;
               }
         //end check aproval status

              if(($ledge->transation_nature==2 && $ledge->ledger_id!=21) || ($ledge->ledger_id==21 && $ledge->transation_nature==2 && $ledge->trans_item ==0)){

                                if($ledge->ledger_id==22){
                               $ttl2=$ttl2+$ledge->balance;
                                $balance=$balance+$ledge->balance;
                                // echo number_format($ledge->balance);
                                }else{
                               $ttl2=$ttl2+$ledge->amount;
                                $balance=$balance+$ledge->amount;
                                // echo number_format($ledge->amount);
                                }
                                
                              }else{ 
                               // echo 0;
                            }

                            if(($ledge->transation_nature==1 && $ledge->ledger_id!=21) || ($ledge->ledger_id==21 && $ledge->transation_nature==1 && $ledge->trans_item>0)){

                              if($ledge->ledger_id==22){
                              $ttl1=$ttl1+$ledge->balance;
                                $balance=$balance-$ledge->balance;
                               // echo number_format($ledge->balance);
                              }else{
                              $ttl1=$ttl1+$ledge->amount;
                                $balance=$balance-$ledge->amount;
                               // echo number_format($ledge->amount);
                              }
                               
                              }else{ 
                               // echo 0;
                            }
                        }
                   


                        $tin=$tin+$ttl2;
                        $tout=$tout+$ttl1;
                        $tbalance=$tbalance+$balance;
                        $tbf=$tbf+$balanceb;

            ?>
        
            <tr>
                <td><?= $acc->account_name;?></td>
                <td class="text-right"><?=number_format($balanceb);?></td>
                <td class="text-right"><?=number_format($ttl2);?></td>
                <td class="text-right"><?=number_format($ttl1);?></td>
                <td class="text-right"><?=number_format($balance +$balanceb);?></td>
                 <td class="text-centre">
                                 <button type="button" class="btn btn-primary btn-sm " data-id="<?= $acc->id;?>" onclick="detail_view('<?php echo $acc->id;?>')"><i class="fa fa-eye"></i> View</button>
                             </td>
                <td colspan="4"></td>
                <td></td>
                <td></td>
                <td></td>
                
            </tr>
            <?php
         }
         ?>
           <tr style="border-top: 2px solid black;">
                <td><b>TOTAL</b></td>
               
             <td class="text-right"><b><?=number_format($tbf);?></b></td>
            <td class="text-right"><b><?=number_format($tin);?></b></td>
            <td class="text-right"><b><?=number_format($tout);?></b></td>
         <td class="text-right"><b><?=number_format($tbf +$tbalance);?></b></td>
         <td></td>
         <!-- <td class="text-right"><b><?=number_format($treconciled);?></b></td> -->
                 

               <!-- <td class="text-centre">
                 <button type="button" class="btn btn-primary btn-sm " onclick="detail_view(9)"><i class="fa fa-eye"></i> View</button>
                             </td> -->
                <td colspan="4"></td>
                <td></td>
                <td></td>
                <td></td>
                
            </tr>
         <?php
     }
        ?>
            </tbody>
        </table>
        
    <br>

</div>
<div id="myModalview" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content" style="">
        <div class="modal-content">
        <div class="modal-header">
         <!--  <h5 class="modal-title" id="staticBackdropLabel">Income Ledger Transaction Details</h5> -->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
       <div class="modal-body">
          <div id="showLedger"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
  </div>
<script>
    toastr.options.closeButton=true;
    toastr.options.progressBar=true;
   // toastr.options.positionClass="toast-top-right";
    function detail_view(id){
       if(id==9){
         toastr.info("On development!");
         return;
       }
        //return;
        var data = 'ids=' + id+'&thedate='+'<?php echo $thedate;?>';
         //alert(data);
        $('#myModalview').modal('show');
        $.ajax({
            type: "GET",
            url: "<?= base_url('/index.php/ReportsController/view_cash_bank')?>",
            data: data,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);
                 
            },
            error: function ()
            {
             toastr.error("Sory! Something went wrong!");
            }
        });
    }
</script>