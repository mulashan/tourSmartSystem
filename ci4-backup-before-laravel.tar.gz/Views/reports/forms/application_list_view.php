
<?php
   $bmodel = new App\Models\BillingModel();
   $ctype= $bmodel->get_table_details('name_type_tbl');
   helper('age');
?>

<div class="section-body mt-4">
    <div class="container-fluid" id="printable_area">
             <div class="card mt-3">
                 <center class="mt-3">
                     <h5>APPLICATION LIST REPORT</h5>
                     <h5>FROM <?php echo date('d/m/Y', $sdate);?> TO <?php echo date('d/m/Y', $enddate);?></h5>
                 </center>
             </div>
             
                <div class="card">
               <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable2">
                            <thead>
                                <tr>
                                     
                                    <th>App No</th>
                                    <th>App Date</th>
                                    <th>Applicant Names</th>
                                    <th>Gender</th>
                                    <th>Dob</th>
                                    <th>Age</th>
                                    <th>Level</th>
                                    <th>Class</th>
                                    <th>Fee</th>
                                    <th>Pay Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                  $total=0;
                                  $male=0;
                                  $female=0;
                                  $nusery=0;$pre1=0;$pre2=0;$pre3=0;
                            $primary=0;$p1=0;$p2=0;$p3=0;$p4=0;$p5=0;$p6=0;$p7=0;
                                  $paid=0;
                                  $unpaid=0;
                                 if(count($appl)>0){
                                  
                            foreach($appl as $s){
                                 
                            $age = findAge($s->date_of_birth);
                                 if($s->class_lvl==1){
                                  $fee=10000;
                                 }else{
                                    $fee=15000;
                                 }

                                
                              $total=$total+$fee;
                                 if($s->application_status==1){
                                    $unpaid=$unpaid+$fee;
                                  $st="<b><span class='text-danger'>Unpaid</span></b>";
                                 }else{
                                    $paid=$paid+$fee;
                                    $st="<b><span class='text-success'>Paid</span></b>";
                                 }
                                 /////summary//gender///
                                  if ($s->gender=='Male') {
                                      $male=$male+1;
                                  }else{
                                    $female=$female+1;
                                  }
                                /////summary//level///
                                  if ($s->level_name=='Primary') {
                                      $primary=$primary+1;
                                  }else{
                                    $nusery=$nusery+1;
                                  }
                                  /////summary//classes///
                                    if ($s->class_name=='Pre 1')
                                      $pre1=$pre1+1;
                                   if ($s->class_name=='Pre 2')
                                      $pre2=$pre2+1;
                                  if ($s->class_name=='Pre 3')
                                      $pre3=$pre3+1;
                                   if ($s->class_name=='P1')
                                      $p1=$p1+1;
                                   if ($s->class_name=='P2')
                                      $p2=$p2+1;
                                    if ($s->class_name=='P3')
                                      $p3=$p3+1;
                                    if ($s->class_name=='P4')
                                      $p4=$p4+1;
                                    if ($s->class_name=='P5')
                                      $p5=$p5+1;
                                    if ($s->class_name=='P6')
                                      $p6=$p6+1;
                                    if ($s->class_name=='P7')
                                      $p7=$p7+1;
                                ?>
                                <tr>
                                    
                                    <td><?php echo $s->id;?></td>
                                     <td><?php echo date('Y-m-d H:i',strtotime($s->date_created));?></td>
                                     <td><?php echo $s->full_name;?></td>
                                      <td><?php echo $s->gender;?></td>
                                     
                                   <td><?= $s->date_of_birth; ?></td>
                                   <td><?php echo $age;?></td>
                                     <td><?php echo $s->level_name;?></td>
                                     <td><?php echo $s->class_name;?></td>
                                     <td><?php echo number_format($fee);?></td>
                                    <td><?php echo $st;?></td> 
                                   
                                    
                                </tr>

                            <?php }}else{
                                echo "<tr><td>Currently there is no record</td></tr>";
                            } ?>
                            <tr><td colspan="8"><b>Total</b></td><td><b><?php echo number_format($total);?></b></td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
               <div class="card">
                <table>
                    <tr>
                        <label class="mt-3"><b>Summary</b></label>
                        <label class="">Male=<?php echo " ".$male;?>,
                        <span class="ms-1">Female=<?php echo " ".$female;?></span>,
                        <span class="ms-1">Primary=<?php echo " ".$primary;?></span>,
                        <span class="ms-1">Nusery=<?php echo " ".$nusery;?></span>,
                        <span class="ms-1">Pre 1=<?php echo " ".$pre1;?></span>,
                        <span class="ms-1">Pre 2=<?php echo " ".$pre2;?></span>,
                        <span class="ms-1">Pre 3=<?php echo " ".$pre3;?></span>,
                        <span class="ms-1">P1=<?php echo " ".$p1;?></span>,
                        <span class="ms-1">P2=<?php echo " ".$p2;?></span>,
                        <span class="ms-1">P3=<?php echo " ".$p3;?></span>,
                        <span class="ms-1">P4=<?php echo " ".$p4;?></span>,
                        <span class="ms-1">P5=<?php echo " ".$p5;?></span>,
                        <span class="ms-1">P6=<?php echo " ".$p6;?></span>,
                        <span class="ms-1">P7=<?php echo " ".$p7;?></span>,
                       </label>
                       <label>
                        <span class="ms-1">Paid=<?php echo " ".number_format($paid);?></span>,
                        <span class="ms-1">Pending=<?php echo " ".number_format($unpaid);?></span>
                        </label>
                        <label class="ms-1"></label>
                       
                    </tr>
                </table>
               </div>

            </div>
        <button type="button" class="btn btn-primary pull-right mb-3" data-bs-dismiss="modal" onclick="printable_report('printable_area')"><i class="fa fa-print"></i> Print</button>
        </div>
   

<script>

    $(document).ready(function () {
      $('#myTable2').DataTable();
    });
    
    function printable_report(area) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=700, height=600, left=100, top=25";
        var content_vlue = document.getElementById(area).innerHTML;

        var docprint = window.open("", "", disp_setting);
        docprint.document.open();
        docprint.document.write('<html><head><title>Econnect</title>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }    
  </script>