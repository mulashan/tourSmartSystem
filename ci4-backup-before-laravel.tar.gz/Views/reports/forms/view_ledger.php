<?php  
$imodel = new App\Models\ItemsModel();
$amodel = new App\Models\StudentModel();
$remodel = new App\Models\ReportsModel();
?>

<?php 
$cname = $imodel->get_account($id);

foreach ($cname as $le) {
    $nama = $le->account_name;
}
?>
<div class="col-12" style="max-width: 100%;">
<div id="printcashdtls">
    <div class="card">
        <div class="table-responsive mt-3">
            <table class='table table-bordered table-vcenter mb-0 text-nowrap' style="border: 1px solid silver;" id="myTable2">
                <thead>
                    <tr>
                        <th>Trans Type</th>
                        <th>Trans Date</th>
                        <th>Trans No</th>
                        <th>Trans Name</th>
                        <th>Description</th>
                        <th>Debit</th>
                        <th>Credit</th>
                        <th>Balance</th>
                    </tr>
                </thead>
                <tbody>
                  <?php
                  $ttl1 = 0; // Total Credits
                  $ttl2 = 0; // Total Debits
                  $balance = 0;

                  // Grouping the data by trans_no
                  $dataGroupedByTransNo = []; 

                  foreach ($ledger as $ledge) {
                      // Create a unique key from trans_no
                      $transNo = $ledge->trans_no;
                      
                      // Initialize if not already set
                      if (!isset($dataGroupedByTransNo[$transNo])) {
                          $dataGroupedByTransNo[$transNo] = [
                              'type_name' => $ledge->type_name,
                              'trans_date' => $ledge->trans_date,
                              'trans_no' => $ledge->trans_no,
                              'name' => '', // Will be populated below
                              'description' => $ledge->description,
                              'debit' => 0,
                              'credit' => 0,
                              // Assuming you want to maintain a balance, you may adjust this logic
                              'balance' => 0,
                          ];
                      }
                      
                      // Sum amounts based on transaction nature
                      $totals = isset($ledge->amount) ? $ledge->amount : "";    
                      if ($ledge->transation_nature == 2) { // Debit
                          $dataGroupedByTransNo[$transNo]['debit'] += $totals;
                      } elseif ($ledge->transation_nature == 1) { // Credit
                          $dataGroupedByTransNo[$transNo]['credit'] += $totals;
                      }
                      
                      // Retrieve the name based on name_type_id
                      if ($ledge->name_type_id == 1) {
                          $studename = $remodel->get_name('students', ['id' => $ledge->name_id]);
                          $dataGroupedByTransNo[$transNo]['name'] = $studename[0]->full_name;
                      } else if ($ledge->name_type_id == 2) {
                          $suppliername = $remodel->get_name('supplier_tbl', ['supplier_id' => $ledge->name_id]);
                          $dataGroupedByTransNo[$transNo]['name'] = $suppliername[0]->supplier_name;
                      } else if ($ledge->name_type_id == 4) {
                          $applicant = $remodel->get_name('students_application_tbl', ['id' => $ledge->name_id]);
                          $dataGroupedByTransNo[$transNo]['name'] = $applicant[0]->full_name;
                      } else if ($ledge->name_type_id == 5) {
                          $parent = $remodel->get_name('parents_tbl', ['id' => $ledge->name_id]);
                          $dataGroupedByTransNo[$transNo]['name'] = $parent[0]->full_name;
                      } else if ($ledge->name_type_id == 6) {
                          $aliens = $remodel->get_name('other_students_tbl', ['id' => $ledge->name_id]);
                          $dataGroupedByTransNo[$transNo]['name'] = $aliens[0]->full_name;
                      } else if ($ledge->name_type_id == 7) {
                          $staff = $remodel->get_name('users', ['user_id' => $ledge->name_id]);
                          $dataGroupedByTransNo[$transNo]['name'] = $staff[0]->first_name . ' ' . $staff[0]->lastname;
                      } else {
                          $dataGroupedByTransNo[$transNo]['name'] = 'Unknown'; 
                      }
                  }

                  // Sort data by transaction date
                  usort($dataGroupedByTransNo, function($a, $b) {
                      return strtotime($a['trans_date']) - strtotime($b['trans_date']);
                  });

                  // Reset total amount for balance calculations
                  foreach ($dataGroupedByTransNo as $item) {
                      // Update balance based on the transaction nature
                      $balance +=$item['debit']-$item['credit'];


                      echo "<tr>
                          <td>" . $item['type_name'] . "</td>
                          <td>" . date('Y-m-d', strtotime($item['trans_date'])) . "</td>
                          <td>" . $item['trans_no'] . "</td>
                          <td>" . $item['name'] . "</td>
                          <td>" . $item['description'] . "</td>
                          <td>" . ($item['debit'] > 0 ? number_format($item['debit']) : '') . "</td>  <!-- Display only if greater than 0 -->
                          <td>" . ($item['credit'] > 0 ? number_format($item['credit']) : '') . "</td> <!-- Display only if greater than 0 -->
                          <td>" . number_format($balance) . "</td>
                      </tr>";

                      // Update totals
                      $ttl1 += $item['credit'];
                      $ttl2 += $item['debit'];
                  }

                  // After the loop, display total row
                  echo "<tr>";
                   echo   "<td colspan='5' style='text-align: right;'><b>Total</b></td>";
                     echo  "<td><b>" . number_format($ttl2) . "</b></td>";
                      echo "<td><b>" . number_format($ttl1) . "</b></td>";
                    //  echo "<td><b> </b></td>";
                    //  echo "<td><b> </b></td>";
                     echo "<td><b>" . number_format($balance) . "</b></td>";
                     echo "<td></td>";
                 echo "</tr>";
                  ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<center>
    <button class="btn btn-primary btn-sm" onclick="printable_area('printcashdtls')">
        <span class="fa fa-print"></span> Print
    </button>
</center>
<script type="text/javascript">
// Include your JavaScript functions here, such as `printable_area`.
</script>
<script type="text/javascript">

function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");

  filter = input.value.toUpperCase();
  table = document.getElementById("myTable2");
  tr = table.getElementsByTagName("tr");
  for (var i = 1; i < tr.length; i++) {
    var tds = tr[i].getElementsByTagName("td");
    var flag = false;
    for(var j = 0; j < tds.length; j++){
      var td = tds[j];
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        flag = true;
      } 
    }
    if(flag){
        tr[i].style.display = "";
    }
    else {
        tr[i].style.display = "none";
    }
  }
}

function printable_area(area) {
    var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
    disp_setting += "scrollbars=yes,width=700, height=600, left=300, top=25";
    var content_vlue = document.getElementById(area).innerHTML;

    var docprint = window.open("", "", disp_setting);
    docprint.document.open();
    docprint.document.write('<html><head><title>MHI</title>');
    docprint.document.write('</head><body onLoad="self.print()" style="width:120%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
    docprint.document.write(content_vlue);
    docprint.document.write('</body></html>');
    docprint.document.close();
    docprint.focus();
}

</script>