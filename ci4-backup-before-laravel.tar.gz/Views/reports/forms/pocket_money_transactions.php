  <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
  $bmodel = new App\Models\BillingModel();

  helper('age');

 $sid = $bmodel->get_item_name('students',$where = array('id' =>$student_id));
 $full_name=$sid[0]->full_name;
 
 ?>
 <h6 class="text-center"><?php echo $full_name;?></h6>
<table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable2">
                            <thead>
                                <tr>
                                     
                                    <th>#</th>
                                    <th>voucher No</th>
                                    <th>Trans Date</th>
                                  <th class="text-right">Paid</th>
                                    <th>Trans By</th>
                                    
                                    
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                   $all = $bmodel->get_item_name('voucher_relation_tbl',$where = array('trans_no' =>$trans_no,'trans_type'=>3));
                   if(count($all)>0){
                        $i=0;
                        $total=0;
                   foreach ($all as $p) {
                          $i++; 
                   $pay = $bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$p->payment_no,'trans_type_id'=>5));  
                   $pay_amount = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$p->payment_no,'trans_type'=>5,'transation_nature'=>1));  
                 $user = $bmodel->get_item_name('users',$where = array('user_id' =>$pay[0]->updated_by));
                 $full_name=$user[0]->first_name.' '.$user[0]->last_name;
                   $total=$total+$pay_amount[0]->amount;
                            ?>
                            <tr>
                            <td><?php echo $i;?>.</td>
                            <td><?php echo $p->payment_no;?></td>
                            <td><?php echo date('Y-m-d',strtotime($pay[0]->trans_date));?></td>
                            <td><?php echo number_format($pay_amount[0]->amount);?></td>
                            <td><?php echo $full_name;?></td>
                      </tr>

                      <?php
                       }
                       ?>
                     <tr>
                         <td colspan="2"></td>
                           <td><b>Total</b></td>
                           <td><b><?php echo number_format($total);?></b></td>
                     </tr>
                       <?php
                      }else{
                        ?>
                       <tr>
                             <td colspan="2">No any payment</td>
                       </tr>
                        <?php
                      }
                      ?>
                            </tbody>
                      </table>

<button class="btn btn-warning pull-right mt-3" onclick="cancelbtn()" >Cancel</button>



<script type="text/javascript">
      function cancelbtn(){
            //alert('yes');
      $('#other_rec_popup').hide();  
     // $('#cashInv').hide(); 
    }


</script>