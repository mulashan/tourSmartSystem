<?php
             $bmodel = new App\Models\BillingModel();
             $report = new App\Models\ReportsModel();
             $smodel = new App\Models\StudentModel();
              $dbname=session()->get('db_name');
            $db = \Config\Database::connect($dbname);
            $school_route=$report->get_school_route();
             // echo $thedate;
                ?>
           
    
    <!----------------------------------------------------below students list by route date----------------->
 
    <div class="section-body mt-4">
    <div class="container-fluid">
              <div class="card">
               <div class="table-responsive mt-3">
                <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                           <thead>
                            <tr>
                                 
                                 <th>#</th>
                                 <th>Route Name</th>
                             
                                 <th>Vehicle Name</th>
                                
                                 <th>Driver Name</th>
                                 <th>S Point</th>
                                 <th>Session</th>
                                 <th>S time</th>
                                 <th>Capacity</th>
                                 <th>students</th>
                                 <th>Action</th>
                                 
                                </tr>
                                <thead>
                                    <tbody>
                                 <?php
                          list($startingdate, $endingdate) = explode('-', $thedate);
                                 $enddate = strtotime($endingdate);
                                $sdate = strtotime($startingdate);
                                $n=0;
                              foreach($school_route as $st){
                                $n++;
                                 if($st->route_session==1){
                                    $sess='Morning';
                                }
                                elseif($st->route_session==2){
                                    $sess='Afternoon';
                                }
                                elseif($st->route_session==3){
                                    $sess='Evening';
                                }
                                $sta=$report->get_school_station($st->id);
                                $count=0;
                                foreach($sta as $ts){
                                    if($st->route_session == 1){
                                       $stno = $report->noOfStudentsInRoute2('pickup_station','pickup_session',$ts->station_id,$ts->session_name,date('Y-m-d', $sdate), date('Y-m-d', $enddate));
                                    }else{
                                    $stno = $report->noOfStudentsInRoute2('drop_station','drop_session',$ts->station_id,$ts->session_name,date('Y-m-d', $sdate), date('Y-m-d', $enddate));
                                    }
                                    
                                   if(count($stno)>0){
                                   // echo count($stno);
                                   // echo $ts->station_id;
                                   // echo '</br>';
                                    }
                                   $count=$count+ count($stno);
                                }

                                if($count==0){
                                    continue;
                                   }
                             //      $drv = $smodel->gettable_data('users', $where = array('user_id' => $vh[0]->driver_name));
                                        ?>
                                <tr>
                                  <td><?php echo $n; ?></td>
                                  <td><?php echo $st->route_name; ?></td>
                                  <td><?php echo $st->driver_contact; ?></td>
                                 
                                <td><?php echo $st->first_name." ".$st->last_name; ?></td>
                                  <td><?php echo $st->station; ?></td>
                                   <td><?php echo $sess; ?></td>
                                  <td><?php echo $st->start_time; ?></td>
                                  <td><?php echo $st->capacity; ?></td>
                                  <td><?php echo $count; ?></td>
                                  <td><a href="javascript:void(0)" onclick="view_route(<?php echo $st->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a></td>
                                </tr>
                                <?php
                                     }

                                        ?>
                                  </tbody>
                                   </table>

      </div>
      </div>
      </div>
      </div>
 



  <script>
   $(document).ready(function() {
  var table = $("#myTable").DataTable({
    dom: 'f', // Show only the search input
    paging: false, // Disable pagination
    lengthChange: false, // Disable entries select
  });
});


     function view_route(id) {
            $('#viewDetails').modal('show'); 
            $('#view_content').html('<span class="fa fa-spinner fa-spin"></span> Loading route details...');
           var id='id='+id;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/view_route_students'; ?>',
                data:id,
                success: function (res) {
                    $('#view_content').html(res);
                },
                error: function () {
                    $('#view_content').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


    };

  </script>
