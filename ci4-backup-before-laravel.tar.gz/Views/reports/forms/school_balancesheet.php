<!DOCTYPE html>
<?php  
$imodel = new App\Models\ItemsModel();
$bmodel =  new App\Models\BillingModel();
$report =  new App\Models\ReportsModel();
//     use App\Models\ReportsModel;


 $amodel = new App\Models\AdmissionModel();
 $remodel = new App\Models\ReportsModel();
 ?>

<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>
<body>
<div>
<div id="printcashdtls">
    <center><h4>
       Statement Of Financial Position<br>
    
    As at <?php echo date('d/m/Y H:i', $thedate);?>
       
    </h4>
    </center><br>

                           
                     <div class="card">
                      
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable2">
                           <thead>
                            <tr>
                               <th>Assets</th>
                               <!-- <th></th> -->
                               <th class="text-right" style="padding-right:100px">Amount</th>
                               <th></th>
                           </tr>
                           <tr>
                            <th>Fixed Assets</th>
                            <th></th>
                            <th></th>
                           </tr>
                           <tr>
                            <th>Account Receivable</th>
                             <th></th> 
                             <th></th>
                           </tr>
                           <?php
                            $account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));
                              $totalasset=0;
                              $balanced=0;
                              $balanced2=0;

                               $s='01-01-2020';
                               
                                $std = strtotime($s);
                              foreach($account as $acc){
    //$accountget = $amodel->Account_Receivable($acc->id, date('Y-m-d H:i', $thedate));
    // $accountget = $imodel->getSingle_view($acc->id);
     $accountget = $imodel->getSingle_view3($acc->id, date('Y-m-d H:i', $std),date('Y-m-d', $thedate));

// print_r($accountget);
    $debit = 0;
    $credit = 0;
    $appstatus = 0;
    $ttl1 = 0; // initialize total credits
    $ttl2 = 0; // initialize total debits
    $balance = 0; // initialize balance
    if (!empty($accountget)) {
        foreach ($accountget as $transaction) {
            
            if($transaction->trans_type==4 || $transaction->trans_type==5){
                $approval_status1 = $amodel->get_student_details('approval_numbers', $where = array('trans_no' =>  $transaction->trans_no,'trans_type'=>$transaction->trans_type));
                 if(count($approval_status1)==0){
                 continue;
                }
    
                  $approval_status = $amodel->get_student_details('approval_history', $where = array('app_no' =>  $approval_status1[0]->app_id,'hstatus'=>1));
                if(count($approval_status)==0){
                 continue;
                }
                
              }
              if($transaction->ledger_id==10 && $transaction->trans_type==3){
                $check_status = $amodel->get_student_details('transaction_numbers_tbl', $where = array('status' => 1,'trans_type_id'=>$transaction->trans_type,'trans_number'=>$transaction->trans_no,'trans_desc !='=>""));
                if(count($check_status)==0){
                  continue;
                }
               }else if($transaction->ledger_id==10 && $transaction->trans_type!=3 && $transaction->transation_nature==1){
                continue;
               }
            $totals = isset($transaction->amount) ? $transaction->amount : 0; // Ensure there's a default value
            if ($transaction->transation_nature == 2) { // Debit
                if ($transaction->ledger_id != 21 || ($transaction->ledger_id == 21 && $transaction->trans_item == 0)) {
                    if ($transaction->ledger_id == 22) {
                        $ttl2 += $totals;
                    }
                    $debit += $totals; // Update the total debit
                    $balance += $totals; // Update the balance accordingly
                    // if($transaction->ledger_id == 21){
                    //     print_r($totals);
                    //     echo "->".$transaction->trans_no."<br>";
                    // } 
                }
                elseif ($transaction->ledger_id == 21 && $transaction->trans_item == 2) {
                //    print_r($totals); 
                //          echo "->".$transaction->trans_no."<br>";

                   // In case of specific conditions relating to ledger_id 21 and trans_item == 2
                    $ttl2 += $totals;
                    $debit += $totals;
                    $balance += $totals;
                }else{
                    $ttl2 += $totals;
                    $debit += $totals;
                    $balance += $totals;
                    // $ttl2=$ttl2+$transaction->amount;
                    //    $balance=$balance+$transaction->amount;
                    //  echo number_format($ledge->amount);
                     }
                

                
            } 
            // Credit transactions
            elseif ($transaction->transation_nature == 1) { // Credit
                if ($transaction->ledger_id != 21 || ($transaction->ledger_id == 21 && $transaction->trans_item > 0)) {
                    if ($transaction->ledger_id == 22) {
                        $ttl1 += $totals;
                    }
                    $credit += $totals; // Update the total credit
                    $balance -= $totals; // Update the balance accordingly
                    // if($transaction->ledger_id == 21){
                    //     print_r($totals);
                    //     echo "->".$transaction->trans_no."<br>";


                    // } 
                }
            }
        }
    }
    $balance =$debit - $credit ; // Subtract total debits from total credits
    echo '<tr>';
    echo '<td class="" style="padding-left: 40px">' . htmlspecialchars($acc->account_name) . '</td>';
    echo '<td class="text-right" style="padding-right: 100px">' . number_format($balance) . '</td>';
    echo '<td class="text-right">
            <button type="button" class="btn btn-primary btn-sm" data-id="' . intval($acc->id) . '" onclick="detail_view(' . intval($acc->id) . ', 2)">
                <i class="fa fa-eye"></i> View
            </button>
          </td>'; 
    echo '<td></td>'; 
    echo '</tr>';
    $balanced +=$balance;
                           ?>
                        
                       <?php }?>
                       <tr>
                            <th>total</th>
                             <!-- <th></th>  -->
                             <th class="text-right" style="padding-right: 100px"><b><?php echo number_format($balanced); ?></b></th>
                             <th></th>
                           </tr>
                             
                           <tr>
                            <th>Current Assets</th>
                             <th></th> 
                             <th></th>
                           </tr>
                          
                           <?php
$current = $amodel->get_student_details('accounts_tbl', array('account_type_id' => 2));
$balancedo = 0; // Initialize outside the loop to retain total across iterations

foreach ($current as $acc) {
    $currentall = $amodel->Account_Receivable($acc->id, date('Y-m-d H:i', $thedate));

    $debit = 0;
    $credit = 0;

    if (!empty($currentall)) {
        foreach ($currentall as $transaction) {
            if ($transaction->trans_type == 4 || $transaction->trans_type == 5) {
                $approval_status1 = $amodel->get_student_details('approval_numbers', $where = array('trans_no' => $transaction->trans_no, 'trans_type' => $transaction->trans_type));
                if (count($approval_status1) == 0) {
                    continue;
                }

                $approval_status = $amodel->get_student_details('approval_history', $where = array('app_no' => $approval_status1[0]->app_id, 'hstatus' => 1));
                if (count($approval_status) == 0) {
                    continue;
                }
            }
            if ($transaction->ledger_id == 10 && $transaction->trans_type == 3) {
                $check_status = $amodel->get_student_details('transaction_numbers_tbl', $where = array('status' => 1, 'trans_type_id' => $transaction->trans_type, 'trans_number' => $transaction->trans_no, 'trans_desc !=' => ""));
                if (count($check_status) == 0) {
                    continue;
                }
            } else if ($transaction->ledger_id == 10 && $transaction->trans_type != 3 && $transaction->transation_nature == 1) {
                continue;
            }

            $totals = isset($transaction->amount) ? $transaction->amount : 0; // Ensure there's a default value

            // Check the transaction nature
            if ($transaction->transation_nature == 2) { // Debit
                $debit += $totals;
            } elseif ($transaction->transation_nature == 1) { // Credit
                $credit += $totals;
            }
        }
    }
    
    // Calculate the balance for the current account
    $balance = $debit - $credit; // Subtract total debits from total credits
    
    // Add the balance to the overall balance
    $balancedo += $balance; // Accumulate total balance here

    // Output the row for the current account
    echo '<tr>';
    echo '<td class="" style="padding-left: 40px">' . htmlspecialchars($acc->account_name) . '</td>';
    echo '<td class="text-right" style="padding-right: 100px">' . number_format($balance) . '</td>';
    echo '<td class="text-right">
            <button type="button" class="btn btn-primary btn-sm" data-id="' . intval($acc->id) . '" onclick="detail_view(' . intval($acc->id) . ', 2)">
                <i class="fa fa-eye"></i> View
            </button>
          </td>'; 
    echo '<td></td>'; 
    echo '</tr>';
}

// After the loop, add the total row for the balance
echo '<tr>';
echo '<th>Total</th>';
// echo '<th></th>'; 
echo '<th class="text-right" style="padding-right:100px"><b>' . number_format($balancedo) . '</b></th>';
echo '<th></th>';
echo '</tr>';
?>
                             
                           <tr>                
                            <th>Cash and Bank</th>
                             <th></th> 
                             <th></th>
                           </tr>
                            <?php
                            $account2 = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 9));
                            foreach($account2 as $acc){
                            
             //calculating balance before the date----
            $s='01-01-2020';
            $end = $thedate;
            $std = strtotime($s);
             
             //echo date('Y-m-d',$thedate);
            $before = $imodel->getSingle_view3($acc->id,date('Y-m-d', $std),date('Y-m-d', $thedate));
            // print_r($end);
            $balance2=0;
            foreach($before as $bf){
              if($bf->transation_nature==2){
                $balance2=$balance2+$bf->amount;
              }else{
              //  echo $balanceb;
               $balance2=$balance2-$bf->amount;
              }
             }
           //-------end calculation----------
                                // $balance2=$totalrct2-$totalinv2;
                                 $totalasset=$totalasset+$balance2;
                                 $balanced2=$balanced2+$balance2;
                           ?>
                        <tr>
                            <td class="" style="padding-left: 40px"><?php echo ''.$acc->account_name;?></td>
                             
                             <td class="text-right" style="padding-right:100px"><?php echo number_format($balance2); ?></td>
                           <td class="text-right">
                                 <button type="button" class="btn btn-primary btn-sm " data-id="<?= $acc->id;?>" onclick="detail_view('<?php echo $acc->id;?>',2)"><i class="fa fa-eye"></i> View</button>
                             </td> 
                           </tr>
                       <?php }?>
                       <tr>
                            <th>total</th>
                             <!-- <th></th>  -->
                             <th class="text-right" style="padding-right: 100px"><b><?php echo number_format($balanced2); ?></b></th>
                             <th></th>
                           </tr>
                           </thead>
                           <tr style="border-bottom: 1px solid black;">
                               <th><b>total assets</b></th>
                               <!-- <th></th> -->
                               <?php
                               $totalass=$balanced + $balancedo +$balanced2;
                               ?>
                               <th class="text-right" style="padding-right: 100px"><b><?php echo number_format($totalass); ?></b></th>
                           </tr>
                           <thead>
                           <tr>
                               <th></th>
                               <th></th>
                               <th></th>
                           </tr>
                           <tr> <th></th> <th></th> <th></th></tr>
                            <tr>
                               <th>financed by</th>
                               <th></th>
                               <th></th>
                           </tr>
                            <tr>
                               <th>liabilities</th>
                               <th></th>
                               <th></th>
                           </tr>
                           <?php
// Retrieve student details for accounts with account_type_id 6
$account2 = $amodel->get_student_details('accounts_tbl', array('account_type_id' => 6));
$totalasset = 0;
$balanced2 = 0;
$startDate = '01-01-2020';
$std = strtotime($startDate);
foreach ($account2 as $acc) {
    
    // $before = $imodel->getSingle_view($acc->id);
// print_r($acc->id);
    $before = $imodel->getSingle_view4($acc->id, date('Y-m-d', $std), date('Y-m-d', $thedate));
    $balance2 = 0;
foreach ($before as $bf) {
    if($bf->trans_type==4 || $bf->trans_type==5){
        $approval_status1 = $amodel->get_student_details('approval_numbers', $where = array('trans_no' =>  $bf->trans_no,'trans_type'=>$bf->trans_type));
         if(count($approval_status1)==0){
         continue;
        }

          $approval_status = $amodel->get_student_details('approval_history', $where = array('app_no' =>  $approval_status1[0]->app_id,'hstatus'=>1));
        if(count($approval_status)==0){
         continue;
        }
        
      }
      if($bf->ledger_id==10 && $bf->trans_type==3){
        $check_status = $amodel->get_student_details('transaction_numbers_tbl', $where = array('status' => 1,'trans_type_id'=>$bf->trans_type,'trans_number'=>$bf->trans_no,'trans_desc !='=>""));
        if(count($check_status)==0){
          continue;
        }
       }else if($bf->ledger_id==10 && $bf->trans_type!=3 && $bf->transation_nature==1){
        continue;
       }
  if ($bf->transation_nature == 2) {
      $balance2 += $bf->amount;  // Credit
  } else if ($bf->transation_nature == 1) {
      $balance2 -= $bf->amount;  // Debit
  }
}
    $totalasset += $balance2;
    $balanced2 += $balance2;
?>
    <tr>
        <td class="" style="padding-left: 40px"><?php echo htmlspecialchars($acc->account_name); ?></td>
        <td class="text-right" style="padding-right: 100px"><?php echo number_format($balance2); ?></td>
        <td class="text-right">
            <button type="button" class="btn btn-primary btn-sm" data-id="<?= intval($acc->id); ?>" onclick="detail_view('<?= intval($acc->id); ?>', 2)">
                <i class="fa fa-eye"></i> View
            </button>
        </td> 
    </tr>
<?php
}

// Retrieve student details for accounts with account_type_id 13
$account13 = $amodel->get_student_details('accounts_tbl', array('account_type_id' => 13));
foreach ($account13 as $acc) {
    $before = $imodel->getSingle_view3($acc->id, date('Y-m-d', $std), date('Y-m-d', $thedate));
    $balance2 = 0;
    foreach ($before as $bf) {
      if ($bf->transation_nature == 2) {
          $balance2 += $bf->amount;  // Credited amount
      } else if ($bf->transation_nature == 1) {
          $balance2 -= $bf->amount;  // Debited amount
      }
  }
    $totalasset += $balance2;
    $balanced2 += $balance2;
?>
    <tr>
        <td class="" style="padding-left: 40px"><?php echo htmlspecialchars($acc->account_name); ?></td>
        <td class="text-right" style="padding-right: 100px"><?php echo number_format($balance2); ?></td>
        <td class="text-right">
            <button type="button" class="btn btn-primary btn-sm" data-id="<?= intval($acc->id); ?>" onclick="detail_view('<?= intval($acc->id); ?>', 2)">
                <i class="fa fa-eye"></i> View
            </button>
        </td> 
    </tr>
<?php
}
?>
                       
                       <tr>
                            <th>total</th>
                             <!-- <th></th>  -->
                             <th class="text-right" style="padding-right:100px"><b><?php echo number_format($balanced2); ?></b></th>
                             <th></th>
                           </tr>
                           </thead>





                           <tr>
                               <th>Equity</th>
                               <th></th>
                               <th></th>
                           </tr>

                           <?php
                  
                  // Retrieve student details for accounts with account_type_id 6
$account2 = $amodel->get_student_details('accounts_tbl', array('account_type_id' => 8));
$totalasset = 0;
$balanced3 = 0;
$startDate = '01-01-2020';
$std = strtotime($startDate);
foreach ($account2 as $acc) {
    $before = $imodel->getSingle_view3($acc->id, date('Y-m-d', $std), date('Y-m-d', $thedate));
    $balance2 = 0;
foreach ($before as $bf) {
  if ($bf->transation_nature == 2) {
      $balance2 += $bf->amount;  // Credit
  } else if ($bf->transation_nature == 1) {
      $balance2 -= $bf->amount;  // Debit
  }
}
    $totalasset += $balance2;
    $balanced3 += $balance2;
?>
    <tr>
        <td class="" style="padding-left: 40px"><?php echo htmlspecialchars($acc->account_name); ?></td>
        <td class="text-right" style="padding-right: 100px"><?php echo number_format($balance2); ?></td>
        <td class="text-right">
            <button type="button" class="btn btn-primary btn-sm" data-id="<?= intval($acc->id); ?>" onclick="detail_view('<?= intval($acc->id); ?>', 2)">
                <i class="fa fa-eye"></i> View
            </button>
        </td> 
    </tr>
<?php
}


// Retrieve student details for accounts with account_type_id 13
$account13 = $amodel->get_student_details('accounts_tbl', array('account_type_id' => 11));
foreach ($account13 as $acc) {
    $before = $imodel->getSingle_view3($acc->id, date('Y-m-d', $std), date('Y-m-d', $thedate));
    $balance2 = 0;
    foreach ($before as $bf) {
      if ($bf->transation_nature == 2) {
          $balance2 += $bf->amount;  // Credited amount
      } else if ($bf->transation_nature == 1) {
          $balance2 -= $bf->amount;  // Debited amount
      }
  }
    $totalasset += $balance2;
    $balanced3 += $balance2;
?>
    <tr>
        <td class="" style="padding-left: 40px"><?php echo htmlspecialchars($acc->account_name); ?></td>
        <td class="text-right" style="padding-right: 100px"><?php echo number_format($balance2); ?></td>
        <td class="text-right">
            <button type="button" class="btn btn-primary btn-sm" data-id="<?= intval($acc->id); ?>" onclick="detail_view('<?= intval($acc->id); ?>', 2)">
                <i class="fa fa-eye"></i> View
            </button>
        </td> 
    </tr>
<?php
}
?>
                       
                      <!--  <tr>
                            <th>total</th>
                           
                             <th class="text-right" style=""><b><?php echo number_format($balanced3); ?></b></th>
                           </tr> -->
                           </thead>
                           <tr>
                               <td class="" style="padding-left: 40px">Opening Balance</td>
                               <td></td>
                               <td></td>
                           </tr>
<?php
// Fetch company name
// Your start date
$thedate = date('Y-m-d', $thedate);
$dateRange = "2020/1/1 - $thedate";

$thisYear=date('Y', strtotime($thedate));
$startYear=date('Y-m-d', strtotime($thisYear.'/01/01'));
$endYear=date('Y-m-d', strtotime($thisYear.'/12/31'));
 list($startingdate, $endingdate) = explode('-', trim($dateRange));

$startingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($startingdate))));
$endingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($endingdate))));

// Set timestamps for the start and end of the date period
// $sdate = strtotime($startYear . ' 00:00');
// $enddate = strtotime($endYear. ' 23:59');

$sdate = strtotime($startingdate . ' 00:00');
$enddate = strtotime($startYear. ' 23:59');

$name = "Sales";
$sold = "Cost of Goods Sold";
$other = "Other Income";

// Get sales data
$sales = $remodel->sales($name);
$cgs = $remodel->solid($sold);
$oth = $remodel->other($other);

// Calculate total sales
$totalsales = 0;
if (!empty($sales)) {
    foreach ($sales as $sale) {
        $saleid = $sale->id;
    }

    $all = $remodel->all_sales($saleid, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));

    foreach ($all as $fo) {
        $ledger = $fo->ledger_id;
        $type = $fo->ledger_type;
        $result = $remodel->allofthem($ledger, $type, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        $totalDebits = $totalCredits = 0;

        // Calculate total debits and credits
        foreach ($result as $pes) {
            if ($pes->transation_nature == 2) {
                $totalDebits += $pes->amount;
            } elseif ($pes->transation_nature == 1) {
                $totalCredits += $pes->amount;
            }
        }

        // Calculate totals
        $totals = abs($totalDebits - $totalCredits);
        $totalsales += $totals;
    }
}

// Calculate cost of goods sold
$totalSold = 0;
if (!empty($cgs)) {
    foreach ($cgs as $cgsItem) {
        $cgid = $cgsItem->id;
    }

    $goods_sold = $remodel->cost_sold($cgid, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
    
    foreach ($goods_sold as $fo1) {
        $ledger1 = $fo1->ledger_id;
        $type = $fo1->ledger_type;
        $result = $remodel->allofthem1($ledger1, $type, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        $totalDebits = $totalCredits = 0;

        // Calculate total debits and credits for cost of goods sold
        foreach ($result as $pes) {
            if ($pes->transation_nature == 2) {
                $totalDebits += $pes->amount;
            } elseif ($pes->transation_nature == 1) {
                $totalCredits += $pes->amount;
            }
        }

        $totals = abs($totalDebits - $totalCredits);
        $totalSold += $totals;
    }
}

// Gross profit calculation
$gross = $totalsales - $totalSold;

// Calculate other income
$totalIncome = 0;
if (!empty($oth)) {
    foreach ($oth as $ot) {
        $othersid = $ot->id;
    }

    $other_income = $remodel->other_income($othersid, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
    
    foreach ($other_income as $fo2) {
        $ledger1 = $fo2->ledger_id;
        $type = $fo2->ledger_type;
        $result = $remodel->allofthem1($ledger1, $type, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        $totalDebits = $totalCredits = 0;

        // Calculate total debits and credits for other income
        if(count($result)>0){
        foreach ($result as $pes) {
            if ($pes->transation_nature == 2) {
                $totalDebits += $pes->amount;
            } elseif ($pes->transation_nature == 1) {
                $totalCredits += $pes->amount;
            }
        }
    }

        $totals = abs($totalDebits - $totalCredits);
        $totalIncome += $totals;
    }
}

// Total calculations
$totaly = $gross + $totalIncome;

// Find total expenses
$id = 10; // Assuming this is some static ID
$thy = $remodel->expense($id);
$totalexpense = 0;

foreach ($thy as $coder) {
    $expensname = $coder->type_name; // Get the type_name
    $getexp = $remodel->all_expence($expensname, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
    
    foreach ($getexp as $kepns) {
        $ledgerexp = $kepns->ledger_id; // Use this property
        $typek = $kepns->ledger_type;

        // Get detailed expense for the current ledger and type
        $resulte = $remodel->allofthemexpe($ledgerexp, $typek, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        if (!empty($resulte)) {
            $totalDebits = $totalCredits = 0;

            // Calculate total debits and credits for expenses
            foreach ($resulte as $pes) {
                if ($pes->transation_nature == 2) {
                    $totalDebits += $pes->amount;
                } elseif ($pes->transation_nature == 1) {
                    $totalCredits += $pes->amount;
                }
            }

            $totals = abs($totalDebits - $totalCredits);
            $totalexpense += $totals;
        }
    }
}

// Final profit/loss calculation
$tota2 = $totaly - $totalexpense;
?>
                   
                     

                                <?php
 // Retained Earnings calculations
$sdate = $enddate;
$enddate = strtotime($thedate. ' 23:59');

$name = "Sales";
$sold = "Cost of Goods Sold";
$other = "Other Income";

// Get sales data
$sales = $remodel->sales($name);
$cgs = $remodel->solid($sold);
$oth = $remodel->other($other);

// Calculate total sales
$totalsales = 0;
if (!empty($sales)) {
    foreach ($sales as $sale) {
        $saleid = $sale->id;
    }

    $all = $remodel->all_sales($saleid, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));

    foreach ($all as $fo) {
        $ledger = $fo->ledger_id;
        $type = $fo->ledger_type;
        $result = $remodel->allofthem($ledger, $type, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        $totalDebits = $totalCredits = 0;

        // Calculate total debits and credits
        foreach ($result as $pes) {
            if ($pes->transation_nature == 2) {
                $totalDebits += $pes->amount;
            } elseif ($pes->transation_nature == 1) {
                $totalCredits += $pes->amount;
            }
        }

        // Calculate totals
        $totals = abs($totalDebits - $totalCredits);
        $totalsales += $totals;
    }
}

// Calculate cost of goods sold
$totalSold = 0;
if (!empty($cgs)) {
    foreach ($cgs as $cgsItem) {
        $cgid = $cgsItem->id;
    }

    $goods_sold = $remodel->cost_sold($cgid, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
    
    foreach ($goods_sold as $fo1) {
        $ledger1 = $fo1->ledger_id;
        $type = $fo1->ledger_type;
        $result = $remodel->allofthem1($ledger1, $type, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        $totalDebits = $totalCredits = 0;

        // Calculate total debits and credits for cost of goods sold
        foreach ($result as $pes) {
            if ($pes->transation_nature == 2) {
                $totalDebits += $pes->amount;
            } elseif ($pes->transation_nature == 1) {
                $totalCredits += $pes->amount;
            }
        }

        $totals = abs($totalDebits - $totalCredits);
        $totalSold += $totals;
    }
}

// Gross profit calculation
$gross = $totalsales - $totalSold;

// Calculate other income
$totalIncome = 0;
if (!empty($oth)) {
    foreach ($oth as $ot) {
        $othersid = $ot->id;
    }

    $other_income = $remodel->other_income($othersid, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
    
    foreach ($other_income as $fo2) {
        $ledger1 = $fo2->ledger_id;
        $type = $fo2->ledger_type;
        $result = $remodel->allofthem1($ledger1, $type, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        $totalDebits = $totalCredits = 0;

        // Calculate total debits and credits for other income
        foreach ($result as $pes) {
            if ($pes->transation_nature == 2) {
                $totalDebits += $pes->amount;
            } elseif ($pes->transation_nature == 1) {
                $totalCredits += $pes->amount;
            }
        }

        $totals = abs($totalDebits - $totalCredits);
        $totalIncome += $totals;
    }
}

// Total calculations
$totaly = $gross + $totalIncome;

// Find total expenses
$id = 10; // Assuming this is some static ID
$thy = $remodel->expense($id);
$totalexpense = 0;

foreach ($thy as $coder) {
    $expensname = $coder->type_name; // Get the type_name
    $getexp = $remodel->all_expence($expensname, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
    
    foreach ($getexp as $kepns) {
        $ledgerexp = $kepns->ledger_id; // Use this property
        $typek = $kepns->ledger_type;

        // Get detailed expense for the current ledger and type
        $resulte = $remodel->allofthemexpe($ledgerexp, $typek, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        if (!empty($resulte)) {
            $totalDebits = $totalCredits = 0;

            // Calculate total debits and credits for expenses
            foreach ($resulte as $pes) {
                if ($pes->transation_nature == 2) {
                    $totalDebits += $pes->amount;
                } elseif ($pes->transation_nature == 1) {
                    $totalCredits += $pes->amount;
                }
            }

            $totals = abs($totalDebits - $totalCredits);
            $totalexpense += $totals;
        }
    }
}

// Final profit/loss calculation
$tota = $totaly - $totalexpense;

                                ?>
                                <tr>
                            <td class="" style="padding-left: 40px">Profit/Loss</td>
                            <!-- <td></td> -->
                             <td class="text-right" style="padding-right: 100px" ><b><?php echo number_format($tota); ?></b></td>
                           </tr>
                            <tr>
                            <td class="" style="padding-left: 40px">Retained Earnings</td>
                            <!-- <td></td> -->
                             <td class="text-right" style="padding-right: 100px" ><b><?php echo number_format($tota2); ?></b></td>
                           </tr>


                       </thead>
                       
                    <thead>
                           <tr style="border: 1px solid black;">
                            <th ><b>Total Financed By</b></th>
                             <!-- <th></th> -->
                               <?php         
                              //$totalFinancedBy = $balanced2 + $balanced3 + $tota;
                            $totalFinancedBy = $tota -($balanced2 + $balanced3);
                             $diff=$totalass-$totalFinancedBy;
                               ?>
                           <th class="text-right" style="padding-right: 100px;font-weight: bold; ">
                              <b><?php echo number_format($totalFinancedBy); ?></b>
                           </th>
                           <th></th>
                             </tr>
                       <thead>
                        <tr >
                            <th ><b>Defference</b></th>
                             <!-- <th></th> -->
                               <?php         
                            
                             $diff=$totalass-$totalFinancedBy;
                               ?>
                           <th class="text-right" style="padding-right: 100px;font-weight: bold; ">
                              <b><?php echo number_format($diff); ?></b>
                           </th>
                             </tr>
           </table>

   
</div>
</div>
</div>
 <!-- <button class="btn btn-primary btn-sm" onclick="printable_area('printcashdtls')"><span class="fa fa-print"></span> Print</button> -->

</div>
 

</body>
</html>

<div id="myModalview" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content" style="">
        <div class="modal-content">
        <div class="modal-header">
         <!--  <h5 class="modal-title" id="staticBackdropLabel">Income Ledger Transaction Details</h5> -->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
       <div class="modal-body">
          <div id="showLedger"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
  </div>
<script type="text/javascript">
    function printable_area(area) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=700, height=600, left=100, top=25";
        var content_vlue = document.getElementById(area).innerHTML;

        var docprint = window.open("", "", disp_setting);
        docprint.document.open();
        docprint.document.write('<html><head><title>MHI</title>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }

    function detail_view(id,sn){
       
        //return;
        var data = 'ids=' + id+'&thedate='+'<?php echo $thedate;?>'+'&sn='+sn;
         //alert(data);
        $('#myModalview').modal('show');
        $.ajax({
            type: "GET",
            url: "<?= base_url('/index.php/itemsController/view_balanceSheet')?>",
            data: data,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);
                 
            },
            error: function ()
            {
             toastr.error("Sory! Something went wrong!");
            }
        });
    }
</script>
