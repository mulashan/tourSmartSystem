<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<?php
            helper('calc');
            helper('age');
        //print_r($cl);
        //return;
             $pmodel = new App\Models\PaymentsModel();
             $smodel = new App\Models\StudentModel();
             $report = new App\Models\ReportsModel();
             $dbname=session()->get('db_name');
            $db = \Config\Database::connect($dbname);
           // $hname=$this->report->get_hostelname($hostel);
            $clname="";
            if($time==1){
             if($classlevel==0){
                $clname="All Level,";
            }else{
                if(count($cl)>0)
              $clname=$cl[0]->level_name;  
            }
            if($class==0){
                $cname="All Classes";
            }else{
                if(count($cl)>0)
              $cname=$cl[0]->class_name;  
            }
            if($stream==0){
                $str="All Stream";
            }else{
                if(count($cl)>0)
              $str=$cl[0]->stream_name;  
            }
            }else{
          
          if(count($cl)>0){
            $classlevel=$cl[0]->level_id;
              $clname=$cl[0]->level_name;  
           $cname=$cl[0]->class_name; 
          $str=$cl[0]->stream_name;
      }else{
       return; 
      }
            
            }
            
            
          $schoolname=$report->get_schoolname();
          if(count($schoolname)==0){
              echo 'Please fill company details';
                    return ;
                }
                
                $install = $pmodel->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year),$dbname);
                if(count($install)==0){
                  echo 'Please set school terms for '.$year;
                  return;
                }
                
             $term_name="All Term";
             $termLevelId = (int) $classlevel;
             if($termLevelId === 0 && count($cl) > 0 && isset($cl[0]->level_id)){
                $termLevelId = (int) $cl[0]->level_id;
             }

             if($termLevelId > 0){
                $period = $pmodel->get_item_name('class_level_tbl', $where = array('id' => $termLevelId),$dbname);
                if(count($period) > 0){
                    $dateterm = $report->checkTerm_date(date('Y-m-d'),$year,$period[0]->academic_type);
                    if (is_countable($dateterm) && count($dateterm) > 0) {
                        $term_name=$dateterm[0]->term_name;
                    }else{
                        $dateterm = $report->checkTerm_date2(date('Y-m-d'),$year,$period[0]->academic_type);
                        if (is_countable($dateterm) && count($dateterm) > 0) {
                            $term_name=$dateterm[0]->term_name;
                        }
                    }
                }
             }
                ?>
               
            <div id="tobeprinted">
                <?php
                
                if(count($cl)>0){
            echo "<h6><b>".$schoolname[0]->company_name." </h6>";
             echo "<h6>".$clname." ".$cname. " ".$str." Student List for ".$term_name." ".$year."</h6>";
                }
               ?>
              <div class="card">
                 
               <div class="table-responsive mt-3">
                    <div style="float:left;margin-left: 10px;" id="overpayment">
                </div>
                <button type="button" class="btn btn-primary mb-3 btnp" style="float:right;" onclick="student_print()"><i class="fa fa-print"></i> Print</button>
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                           <thead>
                            <tr>
                                <th data-optional-column="acdmc" style="display:none;">ACDMC</th>
                                 <th data-optional-column="adm_no" style="display:none;">Adm No</th>
                                 <th data-optional-column="adm_date" style="display:none;">Adm Date</th>
                                 <th>Names</th>
                                 <th data-optional-column="birth_date" style="display:none;">Birth date</th>
                                 <th>Age</th>
                                 <th>Gender</th>
                                 <th>Class</th>
                                 <th>Stream</th>
                                 <th>Type</th>
                                 <th>For</th>
                                 <th>Status</th>
                                 <th data-optional-column="bal_bf" style="display:none;">Bal B/F</th>
                                 <th data-optional-column="annual_fee" style="display:none;">Annual Fee</th>
                                 <th data-optional-column="term_fee" style="display:none;">Term Fee</th>
                                 <th data-optional-column="paid" style="display:none;">Paid</th>
                                 <th>Balance</th>
                                 <th class="viewbtn">Action</th>
                                </tr>
                                <thead>
                                    <tbody>
                                <?php
                            $n=0;
                            $female=0;
                               $male=0;
                               $day=0;
                               $board=0;
                               $streamA=0;
                               $streamB=0;
                               $ne=0;
                               $c=0;
                               $holid_student=array();
                               $totalOverpayment=0;
                                 $totalUnderpayment=0;
                                 $invoiceCache = array();
                                 $levelCache = array();
                                 $termNameCache = array();
                                 $installmentsCache = array();
                                 $prevBalanceCache = array();
                                 $currentBalanceCache = array();
                                 //print_r($cl);
                            if(count($cl)>0){
                               
                                foreach($cl as $le){
                                    $n++;
                                    $student_id=$le->id;
                                    $invoiceCacheKey = $year.'_'.$student_id;
                                    if(!isset($invoiceCache[$invoiceCacheKey])){
                                        $invoiceCache[$invoiceCacheKey] = $pmodel->get_total_invoice_amount_type2($student_id,$year,$dbname);
                                    }
                                  $tinvoice = $invoiceCache[$invoiceCacheKey];
                                  if(count($tinvoice)==0){
                                     continue;
                                   }
                                  $results=findCalc($student_id,$dbname,$year);
                                  
                                  
                                  $type=$le->admission_type;
                                  $hst=$le->admission_type;
                                   $adm_id = $le->class_id;
                                   $lvid=$le->level_id;
                                   if(!isset($levelCache[$lvid])){
                                       $levelCache[$lvid] = $pmodel->get_item_name('class_level_tbl', $where = array('id' => $lvid),$dbname);
                                   }
                                   $lvtbl = $levelCache[$lvid];
                                  if($type==3){
                                    $tp='B';
                                    $board++;
                                  }else{
                                     $tp='D';
                                     $day++;
                                  }

                                  if($le->stream_name=='A'){
                                    $streamA=$streamA+1;
                                  }else{
                                     $streamB=$streamB+1;
                                  }
                                  if($le->adimit_for==2){
                                    $new="New Comer";
                                    $ne++;
                                  }else{
                                     $new="Continous";
                                     $c++;
                                  }

                                  $debt=0;
                                  $credit=0;
                            $prevBalanceKey = ($year-1).'_'.$student_id;
                            if(!isset($prevBalanceCache[$prevBalanceKey])){
                                $prevBalanceCache[$prevBalanceKey] = $pmodel->get_item_name('student_balance_tbl',$where=array('year'=>$year-1,'student_id'=>$student_id),$dbname);
                            }
                            $balance= $prevBalanceCache[$prevBalanceKey];
                            if(count($balance)>0){
                                $check_inv_balance= $pmodel->get_item_name('ledger_transaction_tbl',$where=array('trans_type'=>1,'trans_no'=>$balance[0]->debted_inv_no,'transation_nature'=>2,'ledger_type'=>7),$dbname);
                      if(count($check_inv_balance)>0){
                        $bal= $check_inv_balance[0]->balance;
                        $data=array(
                            'present_debit'=>$bal
                        );
                      }
                        $debt=$balance[0]->present_debit;
                        $credit=$balance[0]->balance;
                             }
                 if(count($tinvoice)==0){
                     continue;
                 }
                 $termCacheKey = $year.'_'.$lvtbl[0]->academic_type;
                 if(!isset($termNameCache[$termCacheKey])){
                     $dateterm = $report->checkTerm_date(date('Y-m-d'),$year,$lvtbl[0]->academic_type);
                     if (is_countable($dateterm) && count($dateterm) > 0) {
                        $termNameCache[$termCacheKey] = $dateterm[0]->term_name;
                     }else{
                        $dateterm = $report->checkTerm_date2(date('Y-m-d'),$year,$lvtbl[0]->academic_type);
                        $termNameCache[$termCacheKey] = $dateterm[0]->term_name;
                     }
                 }
                 $term_name=$termNameCache[$termCacheKey];
                 if(!isset($installmentsCache[$termCacheKey])){
                    $installmentsCache[$termCacheKey] = $pmodel->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$lvtbl[0]->academic_type),$dbname);
                 }
                 $installments = $installmentsCache[$termCacheKey];
                    
                    if($le->gender=='Female'){
                  $female=$female+1;
                                  }
                      if($le->gender=='Male'){
                  $male=$male+1;
                                  }
                      
                      $i=0;
                     $tments=0;
                     $tpaid=0;
                     $openingbalance=0;
                     $todaybalance=0;
                     $currentTermFeeAmount=0;
                      $paid_amount=0;
                    foreach ($installments as $r) {
                       
                     $i++;
                    
                     if($i==1){

                        $openingbalance=$results[0]['openingbalance'];
                       $ment=$results[0]['ment'];
                        $mbalance=$results[0]['mbalance'];
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[0]['today']==1){
                       $todaybalance=$results[0]['todaybalance'];
                       $currentTermFeeAmount=$ment; 
                     }
                  
                     }
                      if($i==2){
         
                        $ment=$results[1]['ment'];
                        $mbalance=$results[1]['mbalance'];
                        $paid_amount=$results[1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[1]['today']==1){
                       $todaybalance=$results[1]['todaybalance'];
                       $currentTermFeeAmount=$ment; 
                     } 
                     }
                   if($i==3){
                       $ment=$results[2]['ment'];
                        $mbalance=$results[2]['mbalance'];
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[2]['today']==1){
                       $todaybalance=$results[2]['todaybalance'];
                       $currentTermFeeAmount=$ment; 
                     }
                     }
                     
                     if($i==4){
                       $ment=$results[$i-1]['ment'];
                        $mbalance=$results[$i-1]['mbalance'];
                        $paid_amount=$results[$i-1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[$i-1]['today']==1){
                       $todaybalance=$results[$i-1]['todaybalance'];
                       $currentTermFeeAmount=$ment; 
                     }
                     }
                     
                     
                      }   
                    $openingBalanceAmount = $openingbalance;
                    $annualFeeAmount = $tments;
                    $paidTotalAmount = $tpaid;

                                    if($le->status==1){
                                        $status="Admitted";
                                    }elseif($le->status==2){
                                        $status="Admitted";
                                    }elseif($le->status==3){
                                        $status="Transfered";
                                    }elseif($le->status==4){
                                        $status="Graduates";
                                    }elseif($le->status==5){
                                        $status="Absconded";
                                    }elseif($le->status==6){
                                        $status="No Show";
                                    }
                                    else{
                                        $status="";
                                    }

                                    if($todaybalance>0){
                                        $totalOverpayment+=$todaybalance;
                                        $data=array(
                                                    'year'=>$le->academic_year,
                                                    'student_id'=>$le->id,
                                                    'balance'=>0,
                                                    'present_debit'=>$todaybalance,
                                                    'debted_inv_no'=>$tinvoice[0]->trans_no,
                                                );
                                        $currentBalanceKey = $le->academic_year.'_'.$le->id;
                                        if(!isset($currentBalanceCache[$currentBalanceKey])){
                                            $currentBalanceCache[$currentBalanceKey]=$pmodel->get_item_name('student_balance_tbl',$where=array('year'=>$le->academic_year,'student_id'=>$le->id),$dbname);
                                        }
                                        $check_bal=$currentBalanceCache[$currentBalanceKey];
                                        $needsWrite = true;
                                        if(count($check_bal)>0){
                                            $current = $check_bal[0];
                                            $needsWrite = ((string)$current->balance !== (string)$data['balance'])
                                                || ((string)$current->present_debit !== (string)$data['present_debit'])
                                                || ((string)$current->debted_inv_no !== (string)$data['debted_inv_no']);
                                            if($needsWrite){
                                                $pmodel->update_table_details('student_balance_tbl', array('student_id'=>$le->id,'year'=>$le->academic_year), $data, $dbname);
                                                $currentBalanceCache[$currentBalanceKey] = array((object)$data);
                                            }
                                        }else{
                                            $pmodel->SaveData('student_balance_tbl', $data, $dbname);   
                                            $currentBalanceCache[$currentBalanceKey] = array((object)$data);
                                        }
                                        $holid_student[]=array($le->id);
                            ?>   
                                    <tr>
                                  
                                     <td data-optional-column="acdmc" style="color:red;display:none;"><?=$le->academic_year;?></td>
                                    <td data-optional-column="adm_no" style="color:red;display:none;"><?=$student_id?></td>
                                    <td data-optional-column="adm_date" style="color:red;display:none;"><?=$le->date_joined?></td>
                                    <td style="color:red"><?=$le->full_name?></td>
                                    <td data-optional-column="birth_date" style="color:red;display:none;"><?=$le->birth_date?></td>
                                    <td style="color:red"><?=findAge($le->birth_date)?></td>
                                    <td style="color:red"><?=$le->gender?></td>
                                    <td style="color:red"><?=$le->class_name?></td>
                                    <td style="color:red"><?=$le->stream_name?></td>
                                    <td style="color:red"><?=$tp?></td>
                                    <td style="color:red"><?=$new?></td>
                                      <td style="color:red"><?=$status?></td>
                                    <td class="text-right" data-optional-column="bal_bf" style="color:red;display:none;"><?=number_format($openingBalanceAmount)?></td>
                                    <td class="text-right" data-optional-column="annual_fee" style="color:red;display:none;"><?=number_format($annualFeeAmount)?></td>
                                    <td class="text-right" data-optional-column="term_fee" style="color:red;display:none;"><?=number_format($currentTermFeeAmount)?></td>
                                    <td class="text-right" data-optional-column="paid" style="color:red;display:none;"><?=number_format($paidTotalAmount)?></td>
                                   <td class="text-right" style="color:red"><?=number_format($todaybalance)?></span></td>
                                    
                                    <td class="viewbtn"><a href="javascript:void(0)" onclick="viewBalanceReport(<?php echo  $le->student_id;?>,<?php echo  $le->id;?>,<?php echo  $year;?>)"  class="btn btn-primary btn-sm">View</a>
                                         <a href="javascript:void(0)" onclick="viewTransactions(<?php echo  $le->student_id;?>,<?php echo  $le->id;?>,<?php echo  $year;?>)"  class="btn btn-primary btn-sm">View Transactions</a>
                                       
                                    </td>
                                   </tr>
                                  
                                   <?php
                                  } else{
                                       $totalUnderpayment+=$todaybalance;
                                       $data=array(
                                            'year'=>$le->academic_year,
                                            'student_id'=>$le->id,
                                            'balance'=>$todaybalance,
                                             'present_debit'=>0,
                                            'debted_inv_no'=>$tinvoice[0]->trans_no,
                                        );
                                        if($todaybalance<=0){
                                         $currentBalanceKey = $le->academic_year.'_'.$le->id;
                                         if(!isset($currentBalanceCache[$currentBalanceKey])){
                                             $currentBalanceCache[$currentBalanceKey]=$pmodel->get_item_name('student_balance_tbl',$where=array('year'=>$le->academic_year,'student_id'=>$le->id),$dbname);
                                         }
                                         $check_bal=$currentBalanceCache[$currentBalanceKey];
                                         $needsWrite = true;
                                         if(count($check_bal)>0){
                                             $current = $check_bal[0];
                                             $needsWrite = ((string)$current->balance !== (string)$data['balance'])
                                                 || ((string)$current->present_debit !== (string)$data['present_debit'])
                                                 || ((string)$current->debted_inv_no !== (string)$data['debted_inv_no']);
                                             if($needsWrite){
                                                 $pmodel->update_table_details('student_balance_tbl', array('student_id'=>$le->id,'year'=>$le->academic_year), $data, $dbname);
                                                 $currentBalanceCache[$currentBalanceKey] = array((object)$data);
                                             }
                                         }else{
                                             $pmodel->SaveData('student_balance_tbl', $data, $dbname);   
                                             $currentBalanceCache[$currentBalanceKey] = array((object)$data);
                                         }
                                        }
                                    ?>
                                  
                                     <tr>
                                  
                                     <td data-optional-column="acdmc" style="display:none;"><?=$le->academic_year;?></td>
                                    <td data-optional-column="adm_no" style="display:none;"><?=$student_id?></td>
                                    <td data-optional-column="adm_date" style="display:none;"><?=$le->date_joined?></td>
                                    <td><?=$le->full_name?></td>
                                    <td data-optional-column="birth_date" style="display:none;"><?=$le->birth_date?></td>
                                    <td><?=findAge($le->birth_date)?></td>
                                    <td><?=$le->gender?></td>
                                    <td><?=$le->class_name?></td>
                                    <td><?=$le->stream_name?></td>
                                    <td><?=$tp?></td>
                                    <td><?=$new?></td>
                                    <td><?=$status?></td>
                                    <td class="text-right" data-optional-column="bal_bf" style="display:none;"><?=number_format($openingBalanceAmount)?></td>
                                    <td class="text-right" data-optional-column="annual_fee" style="display:none;"><?=number_format($annualFeeAmount)?></td>
                                    <td class="text-right" data-optional-column="term_fee" style="display:none;"><?=number_format($currentTermFeeAmount)?></td>
                                    <td class="text-right" data-optional-column="paid" style="display:none;"><?=number_format($paidTotalAmount)?></td>
                                   <td class="text-right"><?=number_format($todaybalance)?></span></td>
                                  
                                    <td class="viewbtn">
                                        <a href="javascript:void(0)" onclick="viewBalanceReport(<?php echo  $le->student_id;?>,<?php echo  $le->id;?>,<?php echo  $year;?>)"  class="btn btn-primary btn-sm">View</a>
                                        <a href="javascript:void(0)" onclick="viewTransactions(<?php echo  $le->student_id;?>,<?php echo  $le->id;?>,<?php echo  $year;?>)"  class="btn btn-primary btn-sm">View Transactions</a>
                                   
                                    </td>
                                   </tr>
                                    
                                   <?php
                                   //}
                                  } 
                                }
                        }else{
                             echo '<tr>';
                                  
                                    echo '<td colspan="18"> Currently there is no any history.</td>';
                            echo '<tr>';   
                            }
      
          ?>
          </tbody>
           </table>

          <?php
          echo '<h6 style="">Summary,</h6>';
          // echo '<h6 style="">Male = '.$male.'</h6>';
          // echo '<h6 style="">Female = '.$female.'</h6>';
          // echo '<h6 style="">Total = '.($female+$male).'</h6>';
          
          ?>
          <table class="toba">
              <tr>
                  <td style="padding-left:10px">Male: <?=$male?>,</td> 
                  <td style="padding-left:10px">Female: <?=$female?>,</td>
                  <td style="padding-left:10px">Boarding: <?=$board?>,</td> 
                  <td style="padding-left:10px">Day: <?=$day?>,</td>
                  <td style="padding-left:10px">Stream A: <?=$streamA?>,</td>
                 <td style="padding-left:10px">Stream B: <?=$streamB?>,</td>
                <td style="padding-left:10px">Continous: <?=$c?>,</td>
                <td style="padding-left:10px">New Comer: <?=$ne?>,</td>
                <td style="padding-left:10px">Total: <?=$male+$female?></td>
              </tr>
          </table>
          
      </div>
  </div>
  </div>

  
  <div id="student_details" style="display: none;"></div>
 <div id="allReportsContent" style="display: none;"></div>
  <button type="button" id="Print-button" class="btn btn-primary mb-3 btnp" style="float:right;" onclick="student_printAll()"><i class="fa fa-print"></i> Print All Reports</button>
<noscript>
    <style>
        .table-condensed{
            padding-bottom: 20px; 

        }
        table.table{
            border-collapse:collapse;
            border: 1px solid black;
            width:80%;
          
            margin-left: auto;
            margin-right: auto;
/*            page-break-inside: avoid;*/
           
        }
         table.table td{
         border:1px solid black;
           font-size: 12px;
         }
        #myTable td,#myTable th{
            border:1px solid black;
           font-size: 12px;
           }
        h6{
            text-align: center;
        }
        .btnp,.viewbtn{
           display: none;
        }
        #myTable_wrapper .dataTables_filter,
        #myTable_wrapper .dataTables_paginate,
        #myTable_wrapper .dataTables_length {
         display: none;
}
 @media print {
      .table {
        border-collapse: collapse !important;
        border: 1px solid black !important;
      }
      }
      table.toba td{
        font-size: 12px;
      }
        
    </style>
</noscript>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
  <script>
   $(document).ready(function() {
  if ($.fn.DataTable.isDataTable("#myTable")) {
    $("#myTable").DataTable().destroy();
  }

  window.classListTable = $("#myTable").DataTable({
    dom: 'f', // Show only the search input
    paging: false, // Disable pagination
    lengthChange: false, // Disable entries select
  });

  if (typeof window.applyClassListOptionalColumns === 'function') {
    window.applyClassListOptionalColumns();
  }
});

var totalUnderpayment="<?php echo number_format($totalUnderpayment);?>";
var totalOverpayment="<?php echo number_format($totalOverpayment);?>";
//alert(totalOverpayment);
$('#overpayment').html("<h6><span class='text-danger'>Underpayment= "+totalOverpayment +" </span><span class='text-black'>And Overpayment= "+totalUnderpayment+"</span></h6>");
     function student_print(){
       var table = window.classListTable;
   
       window.onbeforeprint = function() {
    // Hide search box and entries option
    if (table) {
        table.search('').draw();
        table.page.len(-1).draw();
    }
  };
  
  
        var _c = $('#tobeprinted').html();
        var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=800,height=600')
        nw.document.write(_c)
        nw.document.write('<html><head><title>MHI</title><link rel="stylesheet" href="<?php echo base_url() . 'syst_assets/'; ?>bootstrap/css/bootstrap.css">')
        nw.document.write(ns.html())
        //nw.document.close()
        nw.print()
  
     }
     function generateCTR(trans,student_id,due){
   var data = 'trans=' + trans + '&sID=' + student_id+ '&due=' + due;
         // alert(data);
        $.ajax({
            type: 'POST',
          //  url: '<?php echo base_url() . '/index.php/AdmissionController/generate_invoice_controlnumber'; ?>',
            data: data,
            success: function (res) {
                var data = JSON.parse(res);

                if(data['status'] == 1){
                    Swal.fire({
                    title: "successful", 
                    html: data['statusDesc'], 
                    icon: "success"
                  }).then((result) => {
                  if (result.isConfirmed) {
                    $('#ctrbtn'+trans).hide();
                    //location.reload();
                  }
                });
                }else{
                 Swal.fire({
                    title: "error", 
                    html: "control number not created", 
                    icon: "error"
                  }).then((result) => {
                  if (result.isConfirmed) {
                    //location.reload();
                     
                  }
                });
                }
            }
        });
   }
 function student_printAll() {
     $('#Print-button').prop("disabled", true);
     Swal.fire({
              title: 'Please wait...',
              html: '<span class="text-danger">Loading Pages</span>',
              icon: 'info',
              allowOutsideClick: false,
              showConfirmButton: false,
              timerProgressBar: true,
              onBeforeOpen: () => {
                Swal.showLoading();
              }
            });
  var values = <?php echo json_encode($holid_student);?>;
  var combinedContent = ''; // To store all reports content
function printReportContent(content) {
    var nw = window.open('', '_blank', 'width=800,height=600');

    if (nw === null) {
      // Handle if new window is blocked or failed to open
      console.error('Failed to open new window');
      return;
    }

   nw.document.write('<html><head><title>MHI</title></head><body>');

  // Adding custom styles for printing
nw.document.write('<style>');

nw.document.write('@media print {');
// nw.document.write('.container { height: 50%; display: block;}');
 nw.document.write('.img { width: 100%;display: block;}');
 // nw.document.write('.img { height: 60%;}');
nw.document.write('.space1 { margin-top: 10px; }'); 
nw.document.write('.space2 { margin-top: 10px;padding: 10px; }');
nw.document.write('.mt-4 { margin-top: 10px; }');

nw.document.write('span { padding: 10px; }'); // Add padding to the spans
nw.document.write('body {');
nw.document.write('font-family: "Times New Roman", sans-serif;');
nw.document.write('font-size: 13px;');
nw.document.write('}');

nw.document.write('table {');
nw.document.write(' margin: 0 auto;');
nw.document.write('border-collapse: collapse;');
nw.document.write('font-size: 12px;');
nw.document.write('width: 70%;');
nw.document.write('margin-top: 7px;');
nw.document.write('margin-bottom: 7px;');
nw.document.write('}');
nw.document.write('th, td {');
nw.document.write('border: 1px solid black;'); // Define border properties for table cells
nw.document.write('padding: 5px;');

nw.document.write('}');
nw.document.write('}');
nw.document.write('</style>');


    nw.document.write(content); // Print the report content
    nw.document.write('</body></html>');
    nw.print();
  }
  function loadReportAndAppendContent(id) {
      let year='<?=$year;?>';
        //alert(id);
    $('#student_details').load('<?php echo base_url() . '/index.php/ReportsController/load_reports/'; ?>' + id + '/' + year, function(response, status, xhr) {
      if (status === 'success') {
        var reportContent = $('#student_details').html();
        combinedContent += '<div style="page-break-after: always;">' + reportContent + '</div>'; // Separate reports by page break
        if (values.length > 0) {
          loadReportAndAppendContent(values.shift()); // Load the next report if there are more
        } else {
          // When all reports are loaded

          //$('#allReportsContent').html(combinedContent);
             Swal.close();
          setTimeout(function() {
           printReportContent(combinedContent); // Trigger printing
          }, 10); // Add a delay to ensure content is fully loaded
        }
      }
    });
  }

  if (values.length > 0) {
    loadReportAndAppendContent(values.shift()); // Start loading and appending reports
  }
}

function viewTransactions(stid,sid,yr){

       var datta = "stid=" + stid+ "&ids="+sid+"&year="+yr;
       //alert(datta);
        $('#myModalview').modal('show');
      $.ajax({
            type: "GET",
             url: "view_student",
              //url: '<?php echo base_url() . '/index.php/ReportsController/view_student_trans'; ?>',
            data: datta,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);
               
            },
            error: function ()
            {

            }
        });
    };

  </script>
