<?php
             $bmodel = new App\Models\BillingModel();
             $report = new App\Models\ReportsModel();
             $smodel = new App\Models\StudentModel();
             $dbname=session()->get('db_name');
          $db = \Config\Database::connect($dbname);
           // $school_route=$report->get_school_route();
              //echo count($list);
                ?>
               
           <div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Transport</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Transport Attendance</li>
                </ol>
            </div>
           
        </div>
    </div>
</div>
    
       <!----------------------------------------------------below students list by route date----------------->
  <div class="content-wrapper mt-3">
    <section class="content justify-content-center">
        <div class="box box-danger">
           
            <div class="box-body">
          
                 <div class="d-flex justify-content-center" id="">
                    <form id="Result" class="form-inline">
                         <div class="input-group">
                            <button type="button" class="btn btn-default pull-right" id="daterange">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        
                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1"></div>
                </center>

            </div>
        </div>
    </section>
</div> 
    
 

<div class="modal fade" id="viewDetails" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl" style="">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="view_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="print_att"><span class="fa fa-print"></span>Print</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         
      </div>
    </div>
  </div>
</div>

  <script>
   
 $(function () {
    var start = moment();
    var end = moment();
    function cb(start, end) {
        $('#daterange span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
    }
    $('#daterange').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
             'Today': [moment(), moment()],
            'This Week': [moment().startOf('week'), moment().endOf('week')],
            'Next 7 Days ': [moment(), moment().add(6, 'days')],
            'Next 30 Days': [moment(), moment().add(29, 'days')],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Next Month': [moment().add(1, 'month').startOf('month'), moment().add(1, 'month').endOf('month')]
        }
    }, cb);
    cb(start, end);

});

   
   //    function view_route(id){
   // // alert(id);
   //  $('#viewDetails').modal('show'); 
   //    $('#view_content').load('index.php/ReportsController/view_route_students/'+id);
   // }
     function view_route(id) {
            $('#viewDetails').modal('show'); 
            $('#view_content').html('<span class="fa fa-spinner fa-spin"></span> ...');
           var id='id='+id;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/view_route_students'; ?>',
                data:id,
                success: function (res) {
                    $('#view_content').html(res);
                },
                error: function () {
                    $('#view_content').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    };

   $('#Result').submit(function (e) {
         if (!$('#daterange span').html()) {
            $('#Rept1').html('Please specify valid date.');
        } else {
            $('#Rept1').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "thedate=" + $('#daterange span').html() + "&routeid="+1;
          //  alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/school_routes_list2'; ?>',
                data: dta,
                success: function (res) {
                    $('#Rept1').html(res);
                },
                error: function () {
                $('#Rept1').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

           }
        e.preventDefault();
    });
  </script>
