<style type="text/css">
    .school-fees-schedule {
        text-align: left;
        width: 100%;
    }
    .school-fees-schedule .schedule-card {
        border: 1px solid #d9e2ec;
        margin-bottom: 18px;
        padding: 12px;
        background: #fff;
    }
    .school-fees-schedule table th,
    .school-fees-schedule table td {
        vertical-align: middle;
    }
    .school-fees-schedule .amount-cell {
        text-align: right;
        white-space: nowrap;
    }
    .school-fees-schedule .group-head {
        text-align: center;
        font-weight: 700;
    }
    .school-fees-schedule .schedule-header {
        display: flex;
        justify-content: space-between;
        gap: 20px;
        align-items: flex-start;
        margin-bottom: 14px;
    }
    .school-fees-schedule .school-print-header {
        flex: 1;
        text-align: center;
        color: #111;
    }
    .school-fees-schedule .school-print-logo {
        max-width: 150px;
        max-height: 95px;
        object-fit: contain;
        display: block;
        margin: 0 auto 8px;
    }
    .school-fees-schedule .school-print-name {
        font-size: 17px;
        font-weight: 700;
        text-transform: uppercase;
        margin-bottom: 4px;
    }
    .school-fees-schedule .school-print-meta {
        font-size: 12px;
        line-height: 1.45;
    }
    .school-fees-schedule .report-title {
        font-size: 16px;
        font-weight: 700;
        margin-top: 10px;
    }
    .school-fees-schedule .schedule-qr {
        text-align: center;
        font-size: 11px;
        color: #4a5568;
        min-width: 130px;
    }
    .school-fees-schedule .schedule-qr img {
        width: 120px;
        height: 120px;
        display: block;
        margin: 0 auto 4px;
    }
    @media print {
        .school-fees-schedule .schedule-card {
            page-break-inside: avoid;
        }
    }
</style>

<div class="school-fees-schedule" id="tobeprinted">
    <div class="schedule-header">
        <div class="school-print-header">
            <?php if (! empty($company) && ! empty($company->logo_name)): ?>
                <img class="school-print-logo" src="<?= base_url('public/company_photos/' . $company->logo_name); ?>" alt="<?= esc($schoolname); ?> Logo">
            <?php endif; ?>

            <?php if ($schoolname !== ''): ?>
                <div class="school-print-name"><?= esc($schoolname); ?></div>
            <?php endif; ?>

            <?php if (! empty($company)): ?>
                <div class="school-print-meta">
                    <?php if (! empty($company->address)): ?>
                        <div><?= esc($company->address); ?></div>
                    <?php endif; ?>
                    <div>
                        <?php if (! empty($company->phone1)): ?>Phone: <?= esc($company->phone1); ?><?php endif; ?>
                        <?php if (! empty($company->email)): ?><?= ! empty($company->phone1) ? ' | ' : ''; ?>Email: <?= esc($company->email); ?><?php endif; ?>
                    </div>
                    <?php if (! empty($company->website) && $company->website !== '0'): ?>
                        <div><?= esc($company->website); ?></div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="report-title">School Fees Schedule</div>
            <p>
                Darasa: <?= $filters['class'] == 0 ? 'All' : 'Selected'; ?> |
                Admission type: <?= esc(ucfirst((string) $filters['admission_type'])); ?> |
                Admission for: <?= esc(ucfirst((string) $filters['admission_for'])); ?>
            </p>
        </div>
        <?php if (! empty($qrImage)): ?>
            <div class="schedule-qr">
                <img src="<?= esc($qrImage); ?>" alt="School Fees Schedule QR Code">
                <div>Scan to view schedule</div>
            </div>
        <?php endif; ?>
    </div>

    <?php if (count($rows) === 0): ?>
        <div class="alert alert-info">No fees found for selected options.</div>
    <?php endif; ?>

    <?php
    $admissionForColumns = $filters['admission_for'] === 'all'
        ? ['Continuing', 'New Comer']
        : [(string) ((int) $filters['admission_for'] === 2 ? 'New Comer' : 'Continuing')];
    $admissionTypeColumns = $filters['admission_type'] === 'all'
        ? ['Day', 'Boarding']
        : [(string) ((int) $filters['admission_type'] === 3 ? 'Boarding' : 'Day')];

    $classRows = [];
    foreach ($rows as $row) {
        $classKey = $row['class_id'];
        if (! isset($classRows[$classKey])) {
            $classRows[$classKey] = [
                'class_name' => $row['class_name'],
                'level_name' => $row['level_name'],
                'items' => [],
                'totals' => [],
            ];
        }

        $comboKey = $row['admission_for'] . '|' . $row['admission_type'];
        $classRows[$classKey]['totals'][$comboKey] = $row['total'];

        foreach ($row['items'] as $item) {
            $description = trim($item['item_name'] . ' ' . $item['item_attribute'] . ' ' . $item['item_size']);
            if (! isset($classRows[$classKey]['items'][$description])) {
                $classRows[$classKey]['items'][$description] = [];
            }
            $classRows[$classKey]['items'][$description][$comboKey] = ($classRows[$classKey]['items'][$description][$comboKey] ?? 0) + $item['amount'];
        }
    }
    ?>

    <?php foreach ($classRows as $classRow): ?>
        <div class="schedule-card">
            <h6><b><?= esc($classRow['class_name']); ?></b> <span class="text-muted">(<?= esc($classRow['level_name']); ?>)</span></h6>

            <table class="table table-bordered table-condensed">
                <thead>
                    <tr>
                        <th rowspan="2" style="width: 50px;">#</th>
                        <th rowspan="2">Fee Item</th>
                        <?php foreach ($admissionForColumns as $admissionFor): ?>
                            <th class="group-head" colspan="<?= count($admissionTypeColumns); ?>"><?= esc($admissionFor); ?></th>
                        <?php endforeach; ?>
                    </tr>
                    <tr>
                        <?php foreach ($admissionForColumns as $admissionFor): ?>
                            <?php foreach ($admissionTypeColumns as $admissionType): ?>
                                <th class="amount-cell"><?= esc($admissionType); ?></th>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($classRow['items']) === 0): ?>
                        <tr>
                            <td colspan="<?= 2 + (count($admissionForColumns) * count($admissionTypeColumns)); ?>">No fee items configured.</td>
                        </tr>
                    <?php endif; ?>

                    <?php $index = 0; ?>
                    <?php foreach ($classRow['items'] as $description => $amounts): ?>
                        <tr>
                            <td><?= ++$index; ?></td>
                            <td><?= esc($description); ?></td>
                            <?php foreach ($admissionForColumns as $admissionFor): ?>
                                <?php foreach ($admissionTypeColumns as $admissionType): ?>
                                    <?php $comboKey = $admissionFor . '|' . $admissionType; ?>
                                    <td class="amount-cell"><?= isset($amounts[$comboKey]) ? number_format($amounts[$comboKey]) : '-'; ?></td>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>

                    <tr>
                        <td colspan="2"><b>Total</b></td>
                        <?php foreach ($admissionForColumns as $admissionFor): ?>
                            <?php foreach ($admissionTypeColumns as $admissionType): ?>
                                <?php $comboKey = $admissionFor . '|' . $admissionType; ?>
                                <td class="amount-cell"><b><?= isset($classRow['totals'][$comboKey]) ? number_format($classRow['totals'][$comboKey]) : '-'; ?></b></td>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </tr>
                </tbody>
            </table>
        </div>
    <?php endforeach; ?>
</div>
