  <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
  $bmodel = new App\Models\BillingModel();

  helper('age');

 $sid = $bmodel->get_item_name('students',$where = array('id' =>$student_id));
 $full_name=$sid[0]->full_name;
 // echo $full_name;
 list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate);
            $sdate = strtotime($startingdate);

            $sdate=date('Y-m-d H:i', $sdate);
            $enddate=date('Y-m-d H:i', $enddate);
 ?>
 <div class="section-body mt-4">
     <!------------------------------------->
<div  class="cust_popup" id="other_rec_popup" style="display: none;margin-left: 200px;">
<div id="display_payments">
      
  </div>
  </div>
     <!------------------------------------>
    <div class="container-fluid">
             
                <div class="card">
               <div class="table-responsive mt-3">
               
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable2">
                            <thead>
                                <tr>
                                     
                                    <!-- <th>#</th> -->
                                    <th class="text-center">Trans Type</th>
                                    <th class="text-center">Trans No</th>
                                    <th class="text-center">Trans Date</th>
                                    <th class="text-right">In</th>
                                     <th class="text-right">Out</th>
                                    <th class="text-right">Bal</th> 
                                    <th class="text-center">Paid To</th> 
                                    <th>Trans By</th>
                                    <th>Bank</th>
                                    <th></th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                        $dbal = $remodel->refund_pocket_money2($student_id,$year=0,$sdate,$enddate);
                        $pkm_used = $remodel->pocket_money_transaction_used2($student_id,$sdate,$enddate);
                        $mergedArray = array_merge($dbal, $pkm_used);

                    // Sorting by trans_date
                 usort($mergedArray, function($a, $b) {
                 return strtotime($a->trans_date) - strtotime($b->trans_date);
                    });
                    //print_r($mergedArray);
                    //return;
                          $i=0;
                          $totalBalance=0;
                          $totalCollected=0;
                          $usedAmount=0;
                          $balance=0;
                        foreach($mergedArray as $val){
                         //continue; 
                            $i++; 
                            if($val->trans_type_id==5){
                                $type_name="Payments";
                                
                              $user = $bmodel->get_item_name('users',$where = array('user_id' =>$val->name_id));
                                   $paid_name=$user[0]->first_name.' '.$user[0]->last_name;
                                $fn = $bmodel->get_item_name('users',$where = array('user_id' =>$val->updated_by));
                              $full_name=$fn[0]->first_name.' '.$fn[0]->last_name;
                              $bank = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$val->trans_number,'trans_type'=>5,'ledger_type'=>9));
                                  $account = $bmodel->get_item_name('accounts_tbl',$where = array('id' =>$bank[0]->ledger_id));

                                $trans_amount2=$val->amount_given;
                                $trans_amount1="";
                                $balance=$balance -$val->amount_given;
                              
                                $bank_name=$account[0]->account_name;
                                $color="text-black";

                            } else{ 
                                $color="text-green";
                            $type_name="Deposit"; 
                            $check_y=$amodel->gettable_data('transaction_numbers_tbl', $where = array('trans_number' => $val->trans_no,'trans_type_id'=>3,'status'=>1));

                             $check_balance = $amodel->gettable_data('ledger_transaction_tbl', $where = array('trans_no' => $val->trans_no,'transation_nature'=>1,'trans_type'=>3,'ledger_id'=>10));
   
                             if(count($check_y)>0 && count($check_balance)>0){
                                $trans_amount1=$check_balance[0]->amount;
                                $trans_amount2="";
                                 $bank = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$val->trans_no,'trans_type'=>3,'ledger_type'=>9));
                                  $account = $bmodel->get_item_name('accounts_tbl',$where = array('id' =>$bank[0]->ledger_id));
                                  $transBy = $bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$val->trans_no,'trans_type_id'=>3));
                                  $user = $bmodel->get_item_name('users',$where = array('user_id' =>$transBy[0]->updated_by));
                                   $full_name=$user[0]->first_name.' '.$user[0]->last_name;
                                   $paid_name="";
                                   $bank_name=$account[0]->account_name;
                                   $date_time=$transBy[0]->updated_date;

                                  //  $totalBalance+=$check_balance[0]->balance;  
                                    $totalCollected+=$check_balance[0]->amount;
                                    $balance=$balance+$check_balance[0]->amount;
                                }else{
                                    continue;
                                }
                            }
                                 ?>         
                                
                             <tr class="<?php echo $color;?>">
                            <td class="text-center"><?php echo $type_name;?></td>
                            <td class="text-center"><?php echo $val->trans_number;?></td>
                             <td><?php echo $val->trans_date;?></td>
                            
                            <td class="text-right"><?php if($trans_amount1 !=""){ echo number_format($trans_amount1);}?></td>
                            
                            <td class="text-right"><?php if($trans_amount2 !=""){ echo number_format($trans_amount2);} ?></td>
                             <td class="text-right"><?php echo number_format($balance);?></td>
                           <td><?php echo $paid_name;?></td>
                           
                            <td>
                                <?php echo $full_name;?>
                            </td>
                            <td class="text-green">
                                <?php echo $bank_name;?><br>
                           

                            </td>
                            
                            </tr>  
                            <?php
                             
                            }
                             ?>
                             
                          
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
          
        </div>
   

 <script type="text/javascript">

function view_payments_now(student_id,trno){
   // alert(3);
     $('#other_rec_popup').toggle(100);
     $('#display_payments').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
     $('#display_payments').load("<?php echo base_url() . '/index.php/ReportsController/pocket_transaction'; ?>/"+student_id+'/'+trno);
}
</script>