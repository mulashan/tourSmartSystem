  <?php 
    helper('age');
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();

    //$student = $smodel->gettable_data('students', $where = array('status' => 1));
    $admission = $smodel->gettable_data('admission_tbl', $where = array('status' => 1,'academic_year'=>$year));

?>
  <div class="card">
                    <form id="closeAdmissionYearForm">
                        <div class="table-responsive mt-3">
                            <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable2">
                                <thead>
                                    <tr>
                                        <th>Acdmc yr</th>
                                        <th>Adm. No.</th>
                                        <th>Adm. Date</th>
                                        <th>Adm. Type</th>
                                        <th>Student Name</th>
                                        <th>DoB</th>
                                        <th>Age</th>
                                        <th>Level</th>
                                        <th>Class</th>
                                        <th>Stream</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $sn = 0;
                                    foreach ($admission as $adm):
                                        if($adm->admission_type >0){
                                            continue;
                                        }
                                        $sn++;
                                        $std = $amodel->get_student_details('students', $where = array('id' => $adm->student_id));
                                        $room = $amodel->get_student_details('classes_tbl', $where = array('id' => $adm->class_id));
                                        $strm = $amodel->get_student_details('streams_tbl', $where = array('id' => $adm->stream_id));
                                        $user = $amodel->get_student_details('users', $where = array('user_id' => $adm->admitted_by));
                                        $level = $amodel->get_student_details('class_level_tbl', $where = array('id' => $adm->level_id));
                                    ?>
                                        <tr>
                                            <td><?= $adm->academic_year;?></td>
                                            <td><?= $std[0]->student_id;?><input type="hidden" name="student_<?= $sn;?>" value="<?= $adm->student_id; ?>"><input type="hidden" name="admission_<?= $sn;?>" value="<?= $adm->id; ?>"></td>
                                            <td><?= $adm->date_joined;?></td>
                                            <td><?php if($adm->admission_type==0){
                                               echo 'DAY';
                                            }else{echo 'BOARDING';}?></td>
                                            <td><?= $std[0]->first_name.' '.$std[0]->middle_name.' '.$std[0]->last_name;?></td>
                                            <td><?= $std[0]->birth_date;?></td>
                                            <td><?= findAge($std[0]->birth_date);?>
                                        </td>
                                            <td><?= $level[0]->level_name;?></td>
                                            <td><?= $room[0]->class_name;?></td>
                                            <td><?= $strm[0]->stream_name;?></td>
                                            <td>
                                                <!-- <button type="button" class="btn btn-primary btn-sm AdmitID" data-id="<?php //echo $st->id;?>">View</button> -->
                                                <a href="javascript:void(0)" onclick="manage_admission(<?php echo $adm->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Manage</a>
                                            </td>
                                        </tr>
                                    <?php endforeach ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- <input type="hidden" name="total_admitted" value="<?php //$sn; ?>">
                        <button type="submit" class="btn btn-primary float-right mb-3 me-3">Close Academic Year</button> -->
                    </form>
                </div>
                <script type="text/javascript">
                  $(document).ready(function () {
                  $('#myTable2').DataTable();
                });

              function manage_admission(id) {
        
         var data = 'id=' + id;
         //alert (data);

        $('#myModal').modal('show');
        $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/index.php/SemisterController/get_adimition_manage'; ?>',
            data: data,
            beforSend: function()
            {
                $('#admission').html();
            },
            success: function(res){
                $('#admission').html(res);
                 
            },
            error: function ()
            {

            }
        });
    };
                </script>