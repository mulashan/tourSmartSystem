
<?php
 $bmodel = new App\Models\BillingModel();
 $report = new App\Models\ReportsModel();
 $smodel = new App\Models\StudentModel();
//echo $dates;
 list($frm, $too) = explode("-", $dates);
$from = strtotime(str_replace('/', '-', $frm));
$to = strtotime(str_replace('/', '-', $too));
$dates = $report->getdays($from,$to);
$year=date('Y',$from);
?>
<style type="text/css">
   
</style>
<div class="section-body mt-4">
    <div class="container-fluid">
              <div class="card">
               <div class="table-responsive mt-3">
                <table class="table table-hover table-vcenter mb-0 table-bordered"   id="myTable2">
                           <thead>
                            <tr>
                                 
                               
                                 <th>PNo</th>
                                 <th>Date</th>
                                 <th>Student Name</th>
                                 <th>Class</th>
                                 <th>Age</th>
                                 <th>Station</th>
                                 <!-- <th>Session</th> -->
                                 <th>time</th>
                                 <th>start</th>
                                 <th>end</th>
                                 <?php
                            foreach ($dates as $dt) {
                                echo '<th style="width:auto;padding:0px 2px;text-align:center;font-size:12px;">' . date('D', $dt) . '<br>' . date('d/m', $dt) . '</th>';
                                  }
                            ?>                              
                                 
                                </tr>
                                <thead>
                                    <tbody>
                                        <?php
                                        $n=0;
                              
                                $count=0;
                                foreach($list as $st){
                                  if($st->session_name == 1){
                                         $stno = $report->noOfStudentsInRoute('pickup_station','pickup_session',$st->station_id,$st->session_name,date('Y-m-d', $from), date('Y-m-d', $to),esc($year),esc($class_id));
                                       
                                        }else{
                                      $stno = $report->noOfStudentsInRoute('drop_station','drop_session',$st->station_id,$st->session_name,date('Y-m-d', $from), date('Y-m-d', $to),esc($year),esc($class_id));
                                      
                                         }

                                   if(count($stno)>0){

                                      foreach($stno as $std){
                                     if($std->pickup_station > 0){
                                    $station = $smodel->gettable_data('station_tbl', $where = array('id' => $std->pickup_station));
                                     }elseif($std->drop_station >0){
                                    $station = $smodel->gettable_data('station_tbl', $where = array('id' => $std->drop_station));
                                     }

                                    $n++;
                        
                                        ?>
                                <tr>
                                 
                                  <td><?php echo $std->permit_id.'/'.$st->station_id.'/'.$st->session_name; ?></td>
                                  <td><?php echo date('d-M-Y',strtotime($std->date_created)); ?></td>
                                <td><?php echo $std->first_name." ".$std->last_name; ?></td>
                                   <td><?php echo $std->class_name; ?></td>
                                 <td><?php echo (date('Y') - date('Y',strtotime($std->birth_date))); ?></td>
                                  <td><?php echo $station[0]->station_name; ?></td>
                                  <!-- <td><?php //echo $sess; ?></td> -->
                                  <td><?php echo $st->session_time; ?></td>
                                  <td><?php echo $std->start_date; ?></td>
                                  <td><?php echo $std->end_date; ?></td>
                                  <?php
                            foreach ($dates as $dt) {
                                $check = $report->check_date($std->permit_id,date('Y-m-d', $dt));
                                if(count($check)>0){
                                    ?>
                            <td style="width:auto;padding:0px 2px;text-align:center;font-size:12px;"><span class="fa fa-check"></span></td>
                                <?php
                            }else{
                                ?>
                               <td style="width:auto;padding:0px 2px;text-align:center;font-size:12px;"></td> 
                               <?php
                                 }
                                  }
                            ?> 
                                </tr>
                               
                                <?php
                            }
                                   }
                                   
                                     }
                                        ?>
                                  </tbody>
                                   </table>

      </div>
      </div>
      </div>
      </div>
      <script type="text/javascript">
     $(document).ready(function() {
  var table = $("#myTable2").DataTable({
    dom: '', // Show only the search input
    paging: false, // Disable pagination
    lengthChange: false, // Disable entries select
  });
});

      </script>