  <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
  $bmodel = new App\Models\BillingModel();

  helper('age');

 $sid = $bmodel->get_item_name('students',$where = array('id' =>$student_id));
 $full_name=$sid[0]->full_name;
 ?>
 <div class="section-body mt-4">
     <!------------------------------------->
                  <div  class="cust_popup" id="other_rec_popup" style="display: none;margin-left: 200px;">
                                          <div id="display_payments">
                                              
                                          </div>
                                          </div>
                <!------------------------------------>
    <div class="container-fluid">
             
                <div class="card">
                    <h6 class="mt-3 text-center"><?php echo $full_name;?> POCKET MONEY TRANSACTION REPORT</h6>
               <div class="table-responsive mt-3">
               
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable2">
                            <thead>
                               <!--  <tr>
                                    <td>COLLECTION TRANSACTIONS</td>
                                </tr> -->
                                <tr>
                                     
                                    <!-- <th>#</th> -->
                                    <th class="text-center">Trans Type</th>
                                    <th class="text-center">Trans No</th>
                                    <th class="text-center">Trans Date</th>
                                    <th class="text-right">In</th>
                                     <th class="text-right">Out</th>
                                    <th class="text-right">Bal</th> 
                                    <th class="text-center">Paid To</th> 
                                    <th>Trans By</th>
                                    <th>Bank</th>
                                    <th></th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                        $dbal = $remodel->refund_pocket_money($student_id);
                        $pkm_used = $remodel->pocket_money_transaction_used($student_id);
                        $mergedArray = array_merge($dbal, $pkm_used);
                 
                //   print_r($mergedArray);
                //   return;   
                    // Sorting by trans_date
                 usort($mergedArray, function($a, $b) {
                 return strtotime($a->trans_date) - strtotime($b->trans_date);
                    });
                   
                   
                          $i=0;
                          $totalBalance=0;
                          $totalCollected=0;
                          $usedAmount=0;
                          $balance=0;
                        foreach($mergedArray as $val){
                         //continue; 
                            $i++; 
                            if($val->trans_type_id==5){
                                  $type_name="Payments";
                                
                              $user = $bmodel->get_item_name('users',$where = array('user_id' =>$val->name_id));
                                   $paid_name=$user[0]->first_name.' '.$user[0]->last_name;
                                $fn = $bmodel->get_item_name('users',$where = array('user_id' =>$val->updated_by));
                              $full_name=$fn[0]->first_name.' '.$fn[0]->last_name;
                              $bank = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$val->trans_number,'trans_type'=>5,'ledger_type'=>9));
                                  $account = $bmodel->get_item_name('accounts_tbl',$where = array('id' =>$bank[0]->ledger_id));

                                $trans_amount2=$val->amount_given;
                                $trans_amount1="";
                                $balance=$balance -$val->amount_given;
                              
                                $bank_name=$account[0]->account_name;
                                $color="text-black";

                            } else{ 
                                $color="text-green";
                            $type_name="Deposit"; 
                            $check_y=$amodel->gettable_data('transaction_numbers_tbl', $where = array('trans_number' => $val->trans_no,'trans_type_id'=>3,'status'=>1));

                           $check_balance = $amodel->gettable_data('ledger_transaction_tbl', $where = array('trans_no' => $val->trans_no,'transation_nature'=>1,'trans_type'=>3,'ledger_id'=>10));
   
                             if(count($check_y)>0 && count($check_balance)>0){
                                $trans_amount1=$check_balance[0]->amount;
                                $trans_amount2="";
                                 $bank = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$val->trans_no,'trans_type'=>3,'ledger_type'=>9));
                                  $account = $bmodel->get_item_name('accounts_tbl',$where = array('id' =>$bank[0]->ledger_id));
                                  $transBy = $bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$val->trans_no,'trans_type_id'=>3));
                                  $user = $bmodel->get_item_name('users',$where = array('user_id' =>$transBy[0]->updated_by));
                                   $full_name=$user[0]->first_name.' '.$user[0]->last_name;
                                   $paid_name="";
                                   $bank_name=$account[0]->account_name;
                                   $date_time=$transBy[0]->updated_date;

                                  //  $totalBalance+=$check_balance[0]->balance;  
                                    $totalCollected+=$check_balance[0]->amount;
                                    $balance=$balance+$check_balance[0]->amount;
                                }else{
                                    continue;
                                }
                            }
                                 ?>         
                                
                             <tr class="<?php echo $color;?>">
                            <td class="text-center"><?php echo $type_name;?></td>
                            <td class="text-center"><?php echo $val->trans_number;?></td>
                             <td><?php echo $val->trans_date;?></td>
                            
                            <td class="text-right"><?php if($trans_amount1 !=""){ echo number_format($trans_amount1);}?></td>
                            
                            <td class="text-right"><?php if($trans_amount2 !=""){ echo number_format($trans_amount2);} ?></td>
                             <td class="text-right"><?php echo number_format($balance);?></td>
                           <td><?php echo $paid_name;?></td>
                           
                            <td>
                                <?php echo $full_name;?>
                            </td>
                            <td class="text-green">
                                <?php echo $bank_name;?><br>
                                

                            </td>
                            
                            </tr>  
                            <?php
                             
                            }
                             ?>
                             
                          
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
          
        </div>
   

 <script type="text/javascript">

function view_payments_now(student_id,trno){
   // alert(3);
     $('#other_rec_popup').toggle(100);
     $('#display_payments').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
     $('#display_payments').load("<?php echo base_url() . '/index.php/ReportsController/pocket_transaction'; ?>/"+student_id+'/'+trno);
}

$('#invoice_print').click(function(){
   
//       window.onbeforeprint = function() {

//     table.search('').draw();
//     table.page.len(-1).draw();
//   };
  
  
        var _c = $('#viewinvoice_content').html();
       // var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=800,height=600')
        /////////////////////////////////////
          // Adding custom styles for printing
nw.document.write('<style>');

nw.document.write('@media print {');


nw.document.write('body {');
nw.document.write('font-family: "Times New Roman", sans-serif;');
nw.document.write('font-size: 13px;');
nw.document.write('}');

nw.document.write('h6 {');
nw.document.write('text-align: center;');
nw.document.write('font-size: 15px;');
nw.document.write('}');

nw.document.write('table {');
nw.document.write(' margin: 0 auto;');
nw.document.write('border-collapse: collapse;');
nw.document.write('font-size: 12px;');
nw.document.write('width: 70%;');
nw.document.write('margin-right: 20px;');
nw.document.write('}');
nw.document.write('th, td {');
nw.document.write('border: 1px solid black;'); // Define border properties for table cells
nw.document.write('padding: 5px;');

nw.document.write('}');
nw.document.write('}');
nw.document.write('</style>');
     ////////////////////////////////
        nw.document.write(_c)
        nw.document.write('<html><head><title>MHI</title>')
       // nw.document.write(ns.html())
        //nw.document.close()
        nw.print()
  
     });
</script>