<!DOCTYPE html>
<?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
 ?>

<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>
<body>
<div>
<div id="printcashdtls">
    <center><h4>
       
        <?php echo "EDEN GARDEN EDUCATION TRUST";echo ' '. $pmode_name.' '.$account_name; ?>  Report<p></p>
        Report Date <?php echo date('d/m/Y H:i', $strtdate) ?> - <?php echo date('d/m/Y H:i', $enddate) ?>
    </h4>
    </center><br>

                           
                     <div class="card">
                      
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable2">
                            <thead>
                               
                                <tr>

                                    <th>Trans Type</th>
                                     <th>Trans Date</th>
                                    <th>Trans No</th>
                                    <th>Trans Name</th>
                                   
                                    <th>Description</th>
                                    <th>Debit</th>
                                    <th>Credit</th>
                                    <th>Balance</th>
                                
                                </tr>
                            </thead>
                           <tbody>
                         <?php
                         if (count($cashcollctn_data)> 0) {
                           $ttl1=0; 
                           $ttl2=0;
                           $balance=0; 
                            foreach($cashcollctn_data as $ledge){
                              $result=$remodel->groupedby($ledge->trans_no,$type,$id);
                           $totals=0;
                              foreach($result as $res){
                              $totals=$totals+ $res->amount;
                                }
                            ?>
                          <tr>
                           
                              <td><?= $ledge->type_name;?></td>
                              <td><?= $ledge->trans_date;?></td>
                              <td><?= $ledge->trans_no;?></td>
                              <td><?= $ledge->full_name;?></td>
                              <td><?= $ledge->description;?></td>
                              
                              <td><?php if($ledge->transation_nature==2){
                                $ttl2=$ttl2+$totals;
                                $balance=$balance+$totals;
                                echo number_format($ledge->amount);}else{ echo 0;}?></td>
                             <td><?php if($ledge->transation_nature==1){
                                $ttl1=$ttl1+$totals;
                                $balance=$balance-$totals;
                                echo number_format($totals);}else{ echo 0;}?></td>
                               <td><?= number_format($balance);?></td>
                          
                          </tr>
                          <?php }?>                          <tr>

                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td style=""><b>Total</b></td>
                              <td><b><?php echo number_format($ttl2); ?></b></td>
                              <td colspan="6"><b><?php echo number_format($ttl1); ?></b></td>
                          </tr>
            <?php                       
          }else {
            echo '<tr>';
            echo '<td colspan="6"><i>Currently there is no history.</i></td>';
            echo '</tr>';
        }
        ?>                 
    </tbody>
</table>

   
</div>
</div>
</div>
 <button class="btn btn-primary btn-sm" onclick="printable_area('printcashdtls')"><span class="fa fa-print"></span> Print</button>

</div>
 

</body>
</html>
<script type="text/javascript">
    function printable_area(area) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=700, height=600, left=100, top=25";
        var content_vlue = document.getElementById(area).innerHTML;

        var docprint = window.open("", "", disp_setting);
        docprint.document.open();
        docprint.document.write('<html><head><title>MHI</title>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
</script>