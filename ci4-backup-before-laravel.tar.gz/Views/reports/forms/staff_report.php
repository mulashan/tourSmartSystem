
<!DOCTYPE html>
<?php  
$smodel = new App\Models\StudentModel();
 helper('age');
 $classification = $smodel->gettable_data('classification_tbl',$where = array('id >' => 0));
 ?>

<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>
<body>
<div>
<div id="printcashdtls">
    <div class="row">
     </div>                 
                     <div class="card">
                      
                    <div class="table-responsive mt-3">
                       <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead >
                               
                                <tr>

                                    <th>#</th>
                                     <th>Photo</th>
                                     <th>Full Name</th>
                                     <th>Department</th>
                                     <th>Job Tittle</th>
                                     <?php 
                                     if(count($classification)>0){
                                        echo '<th>Classification</th>';
                                     }                                       
                                     ?>
                                     <th>Age</th>
                                     <th>Contract Expiry</th>
                                    <th>Gender</th>
                                    <th>user type</th>
                                    <th>Phone Number</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                 
                                </tr>
                            </thead>
                           <tbody style="border: 1px solid silver;">
                            <?php 
                            if(count($staf)>0){
                            $i=0;
                             foreach($staf as $st){
                                $i++;
                        $dep_name="--";
                        $job_name="--";
                        $age="";
                        $expiry="";
                         $staff = $smodel->gettable_data('staff_details_tbl',$where = array('user_id' => $st->user_id)); 
                         if(count($staff)>0){
                  $dep = $smodel->gettable_data('departments_tbl',$where = array('id' => $staff[0]->dep_id));  
                    $job = $smodel->gettable_data('job_tittle_tbl',$where = array('id' => $staff[0]->job_id));   

                       $dep_name=$dep[0]->dep_name??"--";
                        $job_name=$job[0]->job_tittle??"--";
                        $age="";
                        $expiry=$staff[0]->contract_expiry_date;     
                         }
                            ?>
                        <tr>

                                    <td><?=$i;?></td>
                                    <td>
                                        
                                  <?php
                        $user_photo=$st->user_photo;
                         if($user_photo !=''){
                        ?>
                        <img src="<?=base_url('public/users_photos').'/'.$user_photo;?>" width="50" height="50" alt="User Image" style="border:1px solid black; border-radius: 100%;">
                        <?php
                        }else{
                        ?>
                        <img src="<?=base_url('public/users_photos/default_picture.png');?>" width="50" height="50" alt="User Image" style="border:2px solid black;">
                        <?php
                    }
                        ?> 

                                    </td>
                                <td><?=$st->first_name." ".$st->last_name;?></td>
                                <td><?=$dep_name;?></td>
                                <td><?=$job_name;?></td>
                                <?php
                                if(count($classification)>0){
                            $class = $smodel->gettable_data('classification_tbl',$where = array('id' => $st->classfication_id));
                             if(isset($class)){
                                if(!empty($class)){ 
                                ?>
                                 <td><?=$class[0]->class_name;?></td>
                                <?php
                            }else{

                            echo '<td>--</td>';
                            }
                        }}
                                ?>

                                <td><?= findAge($st->birth_date);?></td>
                                 <td><?=$expiry;?></td>
                                     <td><?=$st->gender;?></td>
                                     <td><?=$st->type_name;?></td>
                                     <td><?=$st->phone_no;?></td>
                                 <?php 
$status = "<span class='badge badge-{$st->status_color}'>{$st->status_name}</span>";
?>
<td><?= $status; ?></td>

                                    
                                 <td>
                                                                                                    
                                     <a href="javascript:void(0)" onclick="edit_staff(<?php echo $st->user_id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a> 
                                      <a href="javascript:void(0)" onclick="view_staff(<?php echo $st->user_id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a>
                                      </td>
                                </tr>
                          <?php 
                      }
         }else{
            echo "<tr>";
            echo "<td></td>";
            echo "<td colspan='7'>Currently there is no history</td>";
            echo "</tr>";
         }
                          ?>        
    </tbody>
</table>

   
</div>
</div>
</div>

</div>
 

</body>
</html>

<div class="modal fade" id="editStaff" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" style="">
      <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel"><center>Edit Staff Details</center></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="editStaff_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="viewStaff" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"  style="z-index: 1400;">
  <div class="modal-dialog modal-xl">
    <div class="modal-content" style="">
      <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel"><center>Staff Information</center></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewStaff_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">


function printable_area(printcashdtls) {
       var TableToPrint = document.getElementById('myTable2');
       var htmlToPrint = '' +
           '<style type="text/css">' +
               'table th, table td {' +
               'padding: 5px; ' +'color: black; ' +

               '}' +
               ' #printHeader2{border-left: none!important; border-right: none!important;}' +
               ' #myTable2{padding: 4px; border-collapse:collapse; font; font-size:12pt;}' +
               ' #printHeader2 td{ border-bottom: solid black 1px; border-right: solid black 1px!important; }' +
               ' td{ border-bottom: solid black 1px; border-right: solid black 1px!important; border-left: solid black 1px!important; }' +
           '</style>';
       htmlToPrint += TableToPrint.outerHTML;
       newWin = window.open("");
       newWin.document.write('<head><title>MHI</title></head>');
       newWin.document.write("<h2><center>OUTSTANDING BALANCE STATEMENT</center></h2>");
       newWin.document.write(htmlToPrint);
       newWin.print();
       newWin.close();
   }

   function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");

  filter = input.value.toUpperCase();
  table = document.getElementById("myTable2");
  tr = table.getElementsByTagName("tr");
  for (var i = 1; i < tr.length; i++) {
    var tds = tr[i].getElementsByTagName("td");
    var flag = false;
    for(var j = 0; j < tds.length; j++){
      var td = tds[j];
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        flag = true;
      } 
    }
    if(flag){
        tr[i].style.display = "";
    }
    else {
        tr[i].style.display = "none";
    }
  }
}


$(document).ready(function () {
  $('#myTable').DataTable();
});

function edit_staff(id){
         $('#editStaff_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
        $('#editStaff').modal('show'); 
        $('#editStaff_content').load('index.php/StaffController/edit_staff/'+id);
       
    } 
    
    function view_staff(id){
    $('#viewStaff_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
    $('#viewStaff').modal('show'); 

    $('#viewStaff_content').load('index.php/StaffController/view_staff/' + id, function(response, status, xhr){
        if (status === "error") {
            $('#viewStaff_content').html(
                '<div class="alert alert-danger" role="alert">' +
                '<strong>Error:</strong> Unable to load staff data. ' +
                'Server says: ' + xhr.status + ' ' + xhr.statusText +
                '</div>'
            );
        }
    });
}

</script>