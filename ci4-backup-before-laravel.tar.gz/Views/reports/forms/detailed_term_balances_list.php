<?php
//print_r($data);
$bmodel = new App\Models\BillingModel();
 ?>
                                    <div id="tobeprinted">
                <form id="message_form" class="form-inline">
              <div class="card">
               <div class="table-responsive mt-3">
               <a href="#" class="btn btn-secondary ms-3" onclick="export_report()">Export</a>

                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable1">
                           <thead>
                             <tr>
                                <th>#</th>
                                
                                 <th>Acdmc yr</th>
                                 <th>Names</th>
                                 <th>Class</th>
                                 <th>Stream</th>
                                 <th>Type</th>
                                 <th>For</th>
                                 <th>Admission Date</th>
                                 <?php
                                $i=0;
                    foreach($installments as $st){
                     $i++;
                     echo "<th class='text-right'>".$i."-Term</th>";
                     }
                                 ?>

                                  <th class='text-right'>Total</th>
                                 
                                
                                </tr>
                                <thead>
              <tbody>
              	<?php 
                $i=0;
        foreach ($data as $rowIndex => $row) {
        	$i++;
        echo "<tr>";
        $k=0;
        foreach ($row as $cell) {
        	$k++;
        	if($i>1 && $k>=9 && $k<=12){
           echo $rowIndex <= 1 ? "<th class='text-right'>$cell</th>" : "<td class='text-right'>$cell</td>";
                }elseif($i>1){
               echo $rowIndex <= 1 ? "<th>$cell</th>" : "<td>$cell</td>"; 	
                }
                }
        echo "</tr>";
                 }
        	?>
                                    
						          </tbody>
						           </table>
                