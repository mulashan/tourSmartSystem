<style type="text/css">
   /* CSS for printing */
@media print {
  /* Add borders to all tables */
  table {
    border-collapse: collapse;
    width: 100%;
    border: 1px solid black; /* Define border properties */
  }

  /* Style table header */
  th {
    border: 1px solid black; /* Define border properties for table header cells */
    padding: 8px;
    text-align: left;
  }

  /* Style table cells */
  td {
    border: 1px solid black; /* Define border properties for table cells */
    padding: 8px;
  }
}

</style>

<?php
  helper('age');
  helper('calc');
  
  $dbname=session()->get('db_name');
$db = \Config\Database::connect($dbname);
  //echo findCalc(1);
  $bmodel = new App\Models\BillingModel();
  $smodel = new App\Models\StudentModel();
  $cmodel = new App\Models\ClassesModel();
  $appItems = $cmodel->get_applications_items();
 $logo = $bmodel->get_table_details('company_tbl');
 $source="";
            if($logo[0]->logo_name != ""){
               $source =  base_url('public/company_photos/'.$logo[0]->logo_name);
            }
//echo $student_id;
            $admn = $bmodel->get_item_name('students', $where = array('id'=>$student_id));
            if(count($admn) == 0){
                echo "<div class='alert alert-warning'>Student details not found.</div>";
                return;
            }
            $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name;

            $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $admn[0]->id, 'academic_year'=>$year));
            if(count($admissn) > 0){
                $adm_id = $admissn[0]->class_id;
                $hst = $admissn[0]->admission_type;
                $trns = $admissn[0]->vehicle_id;
                $for = $admissn[0]->adimit_for;
                $lvid = $admissn[0]->level_id;
               
            }else{
                echo "<div class='alert alert-warning'>Admission details not found for ".$year.".</div>";
                return;
            }
            if($hst >0){
                $hostel="Hostel";
            }else{
               $hostel="Day"; 
            }
            $class = $bmodel->get_item_name('classes_tbl', $where = array('id' => $adm_id)); 
             $lvtbl = $bmodel->get_item_name('class_level_tbl', $where = array('id' => $lvid)); 
            if(count($class) == 0 || count($lvtbl) == 0){
                echo "<div class='alert alert-warning'>Class details not found.</div>";
                return;
            }
            $student_id=$admn[0]->id;
            $debt=0;
            $credit=0;
            $ref="";
            $balance= $bmodel->get_item_name('student_balance_tbl',$where=array('year'=>$year-1,'student_id'=>$student_id));
           // print_r($balance);
                     if(count($balance)>0){
                        $debt=$balance[0]->present_debit;
                        $credit=$balance[0]->balance;
                      if($debt >0){
                        
                          $referece =$bmodel->get_item_name('payment_request',$where=array('student_id'=>$student_id,'trans_no'=>$balance[0]->debted_inv_no,'inv_type'=>0,'trans_type'=>1));
                          if(count($referece)>0){
                            $ref=$referece[0]->reference_no;
                          }
                      }
                      
                      if($credit <0){
                        
                          $checkAllReceipt =$bmodel->get_item_name('transactions_relation',$where=array('invoice_trans_no'=>$balance[0]->debted_inv_no,));
                          foreach($checkAllReceipt as $ct){
                           $checkIfused =$bmodel->get_item_name('transaction_use_relation_tbl',$where=array('used_no'=>$ct->receipt_trans_no,'trans_type'=>5));
                           if(count($checkIfused)>0) {
                            $credit=0;
                           }
                          }
                      }
                     }
                     
                    $phone = $db->query('SELECT phone1 FROM parents_tbl,parents_students_tbl WHERE parents_tbl.id = parents_students_tbl.parent_id AND'
               . ' parents_tbl.bill_account = 1  AND parents_students_tbl.student_id ='.$student_id.'');
             $pn = $phone->getResult(); 
               if(count($pn)>0){
                $phone=$pn[0]->phone1;
               }else{
                 $phone="---";
               }
?>
<div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8" id='content'>
        <center>
            <div class="container">
             <div class="img"> <img src="<?php  echo $source; ?>"  style="background: white;width: 40%;height: 25%" ></div>
            <!-- <h3><b>INVOICE</b></h3> -->
            <!-- <div class="mt-3"><img src="<?php //echo $source; ?>" width="180" height="130"></div></br> -->
            <div class="mt-1"><b><?= $logo[0]->company_name; ?> </b></div>
            <div class="modify"><?= $logo[0]->address; ?></div>
            <div class="mb-3">
                <div><span class="modify">Phone: <?= $logo[0]->phone1; ?></span></div>
                <div><span class="modify">Email: <?= $logo[0]->email; ?></span></div>
                <?php
                if($logo[0]->website=='0'){
                    $website='';
                }else{
                  $website=$logo[0]->website;
                }
                ?>
                <div><span class="modify"> <?= $website; ?></span></div>
             
            </div>
            </div>
           <hr style="color:black;">

               <div class="modify">
                  <span><b> UTARATIBU WA MALIPO YA MWANAFUNZI</b></span>
                <i style="float:right;margin-right: 80px;">
                <b>Tarehe: <?php echo date('d/m/Y');?></i></b>
            </div>
        </center>
        
     <?php if($debt>0){?>  
   <div class="mt-4 space1" style="text-align: justify;">
    <span>Baki ya <?php echo $year-1; ?>: TZS <?php echo number_format($debt); ?> (Tumia Namba ya Malipo <b><?= $ref;?></b>)</span>
   </div>
 <?php }?>
  <?php if($credit<0){?>  
   <div class="mt-4 space1">
    <span>Baki ya <?php echo $year-1; ?>: TZS <?php echo number_format($credit); ?> </span>
   </div>
 <?php }?>
   <div class="mt-4 space1">
   <span><b>Mwaka wa Masomo:</b> <?= $year;?></span>
   <span style="float:right;margin-right: 80px;"><b></b> <?= $class[0]->class_name.', '.$hostel;?></span></div>

    <div class="mt-2 space1"><span><b>Jina la mwanafunzi:</b> <?= $student_name;?></span></div>

<p class="mt-3 space1"><span><b>Ujumbe uliotumwa namba +<?=$phone;?></b> </span></p>

    <div id="message" class="col-md-12 mt-1 space2" style="border: 1px solid black;width: 95%;"></div>

    <div class="mt-3 mb space1" style="text-align: justify;"><span>Chini ni utaratibu wa malipo ya shule kwa mwanafunzi aliye tajwa hapo juu:</span></div>

     <table class="table table-condensed table-centre">
      
            <thead>
                <tr>
                    <th class="text-left">Muhula</th>
                    <th class="text-right">Deni la Nyuma</th>
                    <th class="text-right">Malipo ya <?= $year;?></th>
                    <th class="text-right">Tarehe ya Mwisho</th>
                    <th class="text-right">Kilicholipwa</th>
                    <th class="text-right">Baki</th>
                </tr>
            </thead>
            <tbody>
                <?php 
              
              
                $ctrNum="";
                $name = $admn;
                 
                    
                 $tinvoice = $bmodel->get_total_invoice_amount($student_id,$year);
                 
                    //echo $year;
             $results=findCalc($student_id,$dbname,$year);
             if(!is_array($results) || count($results) == 0){
                echo "<tr><td colspan='6' class='text-center'>No balance breakdown found.</td></tr>";
                echo "</tbody></table></div></div>";
                return;
             }
        //print_r($results[0]['mm']);
             // print_r($results[0]['tinvoice']);
            //   echo '</br>';
             //print_r($results[1]['mm']);
            //   print_r($results[1]['paid_amount']);
            //     echo '</br>';
            //
          // print_r($results[2]['mm']);
            //  
                
                 if(count($tinvoice)>0){
                    foreach($tinvoice as $ti){
                     $ctr_num =$bmodel->get_item_name('payment_request',$where=array('student_id'=>$student_id,'trans_no'=>$ti->trans_no,'inv_type'=>0,'trans_type'=>1));
                     if(count($ctr_num)>0){
                        $ctrNum=$ctr_num[0]->reference_no;
                     }
                 }
                 }
               // $total=$tinvoice[0]->amount;
               // echo  $tinvoice[0]->trans_no;

                 

                    
            $installments =$bmodel->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$lvtbl[0]->academic_type));
                   if(count($installments) == 0){
                      echo "<tr><td colspan='6' class='text-center'>No school terms found for ".$year.".</td></tr>";
                   }
                   // $k=0;
                   // $m=0;
                  
                      $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                    $todaybalance=0;
                    $nbTermName = '';
                    $nbTermBalance = 0;
                    $firstTermName = '';
                     foreach ($installments as $r) {
                          $openingbalance=0;
                        // $paid_amount=0;
                      $i++;
                     
                     if($i==1){
                     
                      $firstTermName = $r->term_name;
                       $openingbalance=$results[0]['openingbalance'];
                       $open=$openingbalance;
                        $ment=$results[0]['ment'];
                        $ment1=$results[0]['ment'];
                        $mbalance=$results[0]['mbalance'];
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[$i-1]['today']==1){
                        $todaybalance=$results[$i-1]['todaybalance']; 
                        
                      }
                   
                      }
                       if($i==2){
                        //print_r($results[1]['paid']);
                        $ment=$results[1]['ment']; 
                         $mbalance=$results[1]['mbalance'];
                         $paid_amount=$results[1]['paid_amount'];
                         $nbTermName = $r->term_name;
                         $nbTermBalance = $mbalance;
                          $tments=$tments+$ment;
                      $tpaid= $tpaid+$paid_amount;
                   
                     if($results[$i-1]['today']==1){
                       $todaybalance=$results[$i-1]['todaybalance']; 
                       
                     }
                     }
                   if($i==3){
        
                     $ment=$results[2]['ment'];
                        $mbalance=$results[2]['mbalance'];
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                    if($results[$i-1]['today']==1){
                       $todaybalance=$results[$i-1]['todaybalance']; 
                       
                     }
                     }
                     
                     if($i==4){
                       $ment=$results[$i-1]['ment'];
                        $mbalance=$results[$i-1]['mbalance'];
                        $paid_amount=$results[$i-1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[$i-1]['today']==1){
                       $todaybalance=$results[$i-1]['todaybalance']; 
                     }
                     }
                      if($tments - $tpaid >0){
                        $usumbufu="Kamilisha malipo.";
                      }else{
                        $usumbufu="";
                      }

                      if($todaybalance <0){
                        $todaybal=0;
                     }else{
                      $todaybal=$todaybalance;  
                     }
                     if(session()->get('db_id')==4){ 

                      $message="Mzazi wa ".$name[0]->first_name.";  Kristo! Baki ya Muhula TZS ".number_format($todaybal)." Baki ya mwaka TZS ".number_format($tments+$open - $tpaid).". Kamilisha malipo na Mungu akubariki.";
                      }else {
                      $message="Mzazi wa ".$name[0]->first_name."; Baki ya Muhula TZS ".number_format($todaybalance)." Baki ya mwaka TZS ".number_format($tments+$open - $tpaid).". ".$usumbufu."";     
                      }
                    
                ?>  
                 <tr>
                    <td><?= $r->term_name; ?></td>
                     <td style="text-align:right;"><?= number_format($openingbalance); ?></td>
                    <td style="text-align:right;"><?= number_format((float)$ment,2); ?></td>
                    <td style="text-align:right;"><?= date('d-M-Y',strtotime($r->due_date)); ?></td>
                    <td style="text-align:right;"><?= number_format($paid_amount); ?></td>
                     <td align="right"><?= number_format($mbalance); ?></td>
                </tr>
                <?php  }?>  
                <?php
                    if($nbTermName == ''){
                        $nbTermName = $firstTermName != '' ? $firstTermName : 'Muhula';
                        $nbTermBalance = isset($mbalance) ? $mbalance : 0;
                    }
                ?>
                <tr>
                    <td><b>Total</b></td>
                    <td align="right"><b><?= number_format($open); ?></b></td>
                    <td align="right"><b><?= number_format($tments); ?></b></td>                    
                    <td align="right"><b><?//= number_format($tments); ?></b></td>
                     <td align="right"><b><?= number_format($tpaid); ?></b></td>  
                    
                    <td align="right"><b><?= number_format($mbalance); ?></b></td>
                   
                </tr>      
            </tbody>
        </table>
    
    <!--------------------------------------------------------------------->
    <?php //if($ctrNum==""){}else{?>
     <div class="mt-4 kindly"  style="text-align: justify;">
     <span>Tafadhali lipa ada ya shule <?= $year;?> kwa kutumia namba ya malipo <b><?php echo $ctrNum;?></b> kupitia njia zifuatazo za CRDB:</span></div>

        <div class="mt-4"  style="text-align: justify;"><span>Wakala, SimBanking, Tawi la Benki, Internet Banking, MPESA </span></div>
        <!--<div class="mt-4"><span></span></div>-->
        <!--<div class="mt-4"><span></span></div>-->
    <div class="mt-4"  style="text-align: justify;">
        <span style="font-size:16px"><b><u>NB:</u></b><br></span>
        <span> <b>>></b>Ikiwa mwanafunzi anadaiwa deni la nyuma siku ya kufungua shule <?php
             if(session()->get('db_id')==14){
               echo "ataondelewa hostel na kuwa mwanafunzi wa kawaida";  
             }else{
        ?>
        hataruhusiwa kuingia shuleni. 
        <?php }?></span><br>
    <span> <b>>></b>Pia mwanafunzi ambaye atalipa ada ya <?= $nbTermName; ?> chini ya <b><?php echo number_format($nbTermBalance);?> </b> hatopokelewa shuleni siku ya kufungua shule. </span>
    </div>
    
      <div class="mt-4"  style="text-align: justify;"><span>Ikiwa una swali lolote, tafadhali wasiliana nasi kupitia No. <b><?= $logo[0]->phone1.'|'.$logo[0]->phone2; ?></b></span></div>
      <div class="mt-4 line"><span class="">Asante.</span></div>
      
      <div class="mt-4 line" style="border-bottom: 1px solid black; width: 120px;"></div>
     
      <div class="mt-1" style="text-align: justify;"><span>Ofisi ya Hesabu/Mkuu Wa shule</span></div>

<center><div class="mt-4">
    <?php
     if(session()->get('db_id')==14){
         echo "Tafadhali kumbuka malipo yote ya shule hayarudishwi";
     }else{
         ?>
    Tafadhali kumbuka, ada zote za shule hazirudishwi.
    <?php } ?></div></center>
<center><div class="mt-1"><i>Hati hii imetengenezwa na mfumo wa kompyuta unaoendeshwa na Micro Health Initiative.</i></div></center>
    </div>
     <div class="col-md-2"></div>
</div>
 <noscript>
    <style>
        .table-condensed{
            padding-bottom: 20px; 
        }
        table.table{
            width:80%;
            border-collapse:collapse;
            margin-left: auto;
            margin-right: auto;
           
        }
        table.table td,table.table th{
            border:1px solid;
           
        }
        .mt-1,.mt-4,.mt-2,.modify,.mb,{
            font-size: 15px;
            padding-bottom: 20px;
        }
        .space{
        padding-top: 40px;
        }
        .line{
            padding-bottom: 80px;
          border-bottom: 1px solid black; 
          width: 120px;  
        }
        .kindly{
            padding-top: 20px;
        padding-bottom: 0px;
        }
  
    /*.print-line {
      border-top: 10px solid black;
      margin: 10px 0;
    }
  */
    </style>
</noscript>
<script type="text/javascript">
    var msg='<?php echo $message;?>';
    $('#message').html(msg);
    function printable_rept(area) {
  var _c = $('#content').html(); // Getting content from the 'content' div
  var nw = window.open('', '_blank', 'width=900,height=600');

  nw.document.write('<html><head><title>MHI</title></head><body>');

  // Adding custom styles for printing
nw.document.write('<style>');

nw.document.write('@media print {');
// nw.document.write('.container { height: 50%; display: block;}');
 nw.document.write('.img { width: 100%;display: block;}');
 // nw.document.write('.img { height: 60%;}');
nw.document.write('.line { margin-top: 15px; }'); 
nw.document.write('.space1 { margin-top: 10px; }'); 
nw.document.write('.space2 { margin-top: 10px;padding: 10px; }'); 
nw.document.write('.mt-4 { margin-top: 10px; }');

nw.document.write('span { padding: 10px; }'); // Add padding to the spans
nw.document.write('body {');
nw.document.write('font-family: "Times New Roman", sans-serif;');
nw.document.write('font-size: 13px;');
nw.document.write('}');

nw.document.write('table {');
nw.document.write(' margin: 0 auto;');
nw.document.write('border-collapse: collapse;');
nw.document.write('font-size: 12px;');
nw.document.write('width: 70%;');
nw.document.write('margin-top: 7px;');
nw.document.write('margin-left: 20px;');
nw.document.write('margin-bottom: 7px;');
nw.document.write('}');
nw.document.write('th, td {');
nw.document.write('border: 1px solid black;'); // Define border properties for table cells
nw.document.write('padding: 5px;');

nw.document.write('}');
nw.document.write('}');
nw.document.write('</style>');


  nw.document.write(_c);
  nw.document.write('</body></html>');
  nw.print();
}

</script>
