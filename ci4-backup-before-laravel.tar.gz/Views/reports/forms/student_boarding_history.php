  <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
  $bmodel = new App\Models\BillingModel();

  helper('age');

 $sid = $bmodel->get_item_name('students',$where = array('id' =>$student_id));
 $full_name=$sid[0]->full_name;
 // echo $full_name;
 list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate);
            $sdate = strtotime($startingdate);

            $sdate=date('Y-m-d H:i', $sdate);
            $enddate=date('Y-m-d H:i', $enddate);
 ?>
 <div class="section-body mt-4">
   
    <div class="container-fluid">
             
                <div class="card">
               <div class="table-responsive mt-3">
               
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable2">
                            <thead>
                                <tr>
                                     
                                    <!-- <th>#</th> -->
                                    <th class="text-center">pno</th>
                                    <th class="text-center">acdmc Yr</th>
                                    <th class="text-center">Permit Date</th>
                                   <th class="text-center">class</th>
                                    <th class="text-center">hostel</th> 
                                    <th class="text-center">P/status</th> 
                                    <th>created By</th>
                                   
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                        $hstry = $remodel->boarding_history($student_id,$sdate,$enddate);
                    
                 
                          $i=0;
                      
                        foreach($hstry as $val){
                         //continue; 
                            $i++; 
                           
                                if($val->hostel >0){
                                    $hst = $bmodel->get_item_name('hostel_tbl',$where = array('id' =>$val->hostel));
                                   $hostel_name=$hst[0]->hostel_name;
                              
                                }else{
                                    $hostel_name="";
                                }
                              
                              $class = $bmodel->get_item_name('classes_tbl',$where = array('id' =>$val->class_id));
                              $full_name=$val->first_name.' '.$val->last_name;
                              $class_name=$class[0]->class_name;

                              $ps = getStatus($val->id);
                                           if($ps>0){
                                            $pstatus="Not Paid";
                                            $row='red';
                                           }else{
                                             $pstatus="Paid";
                                             $row="green";
                                           }
                            
                               ?>         
                                
                             <tr class="">
                            <td class="text-center"><?php echo $val->permit_id;?></td>
                            <td class="text-center"><?php echo $val->academic_year;?></td>
                             <td class="text-center"><?php echo $val->created_date;?></td>
                             <td class="text-center"><?php echo $class_name;?></td>
                           <td class="text-center"><?php echo $hostel_name;?></td>
                           <td class="text-center" style="color: <?=$row;?>"><?php echo $pstatus;?></td>
                           <td class="text-center"><?php echo $full_name;?>  </td>
                            
                            </tr>  
                            <?php
                             
                            }
                             ?>
                             
                          
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
          
        </div>
   

 <script type="text/javascript">

function view_payments_now(student_id,trno){
   // alert(3);
     $('#other_rec_popup').toggle(100);
     $('#display_payments').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
     $('#display_payments').load("<?php echo base_url() . '/index.php/ReportsController/pocket_transaction'; ?>/"+student_id+'/'+trno);
}
</script>