              <?php  
              $imodel = new App\Models\ItemsModel();

               $amodel = new App\Models\AdmissionModel();
               ?>
              <?php 
                $cname = $imodel->get_account($id);

              foreach($cname as $le){
                 $name=$le->account_name;
               }
               $cmp = $amodel->get_student_details('company_tbl', $where = array('created_by >' => 0));

               list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate);
            $sdate = strtotime($startingdate);
             
             //calculating balance before the date----
            $s='01-01-2020';
            $end = strtotime('-1 day',strtotime($startingdate));
            $std = strtotime($s);
             
            // echo date('Y-m-d',$end);
            $before = $imodel->getSingle_view3($id,date('Y-m-d', $std),date('Y-m-d', $end));
            //print_r($before);
            $balanceb=0;
            foreach($before as $bf){
              if($bf->transation_nature==2){
                $balanceb=$balanceb+$bf->amount;
              }else{
              //  echo $balanceb;
               $balanceb=$balanceb-$bf->amount;
              }
          
                          }
                       // echo $balanceb;
           //-------end calculation----------

             $ledger = $imodel->getSingle_view3($id,date('Y-m-d', $sdate),date('Y-m-d', $enddate));
             //print_r($ledger);

              ?>
                <div id="printcashdtls">
                <center>
                  <h5><?php echo $cmp[0]->company_name;?></h5>
                  <h5><?php echo $name; ?> Transaction Details</h5>
                  <h5>From: <?php echo date('d-m-Y', $sdate).' to '.date('d-m-Y', $enddate)?></h5>
                  <!-- <h5>Ledger Name: <?php echo $name; ?> </h5> -->
                </center>
                                    
                     <div class="card">
                   <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap att-list" id="myTable2">
                            <thead>
                               
                                <tr>

                                    <th>Trans Type</th>
                                     <th>Trans Date</th>
                                    <th>Trans No</th>
                                    <th>Trans Name</th>
                                   
                                    <th>Description</th>
                                    <th>Debit</th>
                                    <th>Credit</th>
                                    <th>Balance</th>
                                
                                </tr>
                            </thead>
                           <tbody>
                             <tr>

                              <td class="text-center"><b>Bal b/f</b></td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                             <td class="text-right"><b><?php echo number_format($balanceb); ?></b></td>
                          </tr>  
                         <?php
                           $ttl1=0; 
                           $ttl2=0;
                           $balance=$balanceb; 
                          // print_r($ledger);
                            foreach($ledger as $ledge){
                              if($ledge->name_type_id==1){
                            $std = $amodel->get_student_details('students', $where = array('id' => $ledge->name_id));
                             $fullname=$std[0]->full_name??"";
                              }elseif($ledge->name_type_id==5){
                                //echo $ledge->name_type_id;
                               $pad = $amodel->get_student_details('ledger_transaction_tbl', $where = array('trans_no' => $ledge->trans_no,'trans_type' => $ledge->trans_type,'name_type_id' => 1));
                              //  $pad = $amodel->get_student_details('parents_students_tbl', $where = array('parent_id' => $pad[0]->name_id));
                               if(count($pad)>0){
                               $std = $amodel->get_student_details('students', $where = array('id' => $pad[0]->name_id));
                             
                              $fullname=$std[0]->full_name??"";
                            }else{
                              //$fullname="";
                               $std = $amodel->get_student_details('students_application_tbl', $where = array('id' => $ledge->name_id));
                             $fullname=$std[0]->full_name??"";
                              }
                            }elseif($ledge->name_type_id==4){
                             $std = $amodel->get_student_details('students_application_tbl', $where = array('id' => $ledge->name_id));
                             $fullname=$std[0]->full_name??"";
                            }elseif($ledge->name_type_id==2){
                             $std = $amodel->get_student_details('supplier_tbl', $where = array('supplier_id' => $ledge->name_id));
                             $fullname=$std[0]->supplier_name??"";
                            }else if($ledge->name_type_id == 7){
                        $app = $amodel->get_student_details('users',$where = array('user_id'=>$ledge->name_id));
                        $fullname = $app[0]->first_name.' '.$app[0]->last_name; 
                        
                             }
                            ?>
                          <tr>
                           
                              <td class="text-center"><?= $ledge->type_name;?></td>
                              <td class="text-center"><?= date('d-m-Y',strtotime($ledge->trans_date));?></td>
                              <td class="text-center"><?= $ledge->trans_no;?></td>
                              <td class="text-center"><?= $fullname??"";?></td>
                              <td class="text-center"><?= $ledge->description;?></td>
                              
                              <td class="text-center"><?php if(($ledge->transation_nature==2 && $ledge->ledger_id!=21) || ($ledge->ledger_id==21 && $ledge->transation_nature==2 && $ledge->trans_item ==0)){

                                if($ledge->ledger_id==22){
                               $ttl2=$ttl2+$ledge->balance;
                                $balance=$balance+$ledge->balance;
                                echo number_format($ledge->balance);
                                }else{
                               $ttl2=$ttl2+$ledge->amount;
                                $balance=$balance+$ledge->amount;
                                echo number_format($ledge->amount);
                                }
                                
                              }else{ echo 0;}?></td>
                             <td class="text-center"><?php if(($ledge->transation_nature==1 && $ledge->ledger_id!=21) || ($ledge->ledger_id==21 && $ledge->transation_nature==1 && $ledge->trans_item>0)){

                              if($ledge->ledger_id==22){
                              $ttl1=$ttl1+$ledge->balance;
                                $balance=$balance-$ledge->balance;
                                //echo number_format($ledge->balance);
                              }else{
                              $ttl1=$ttl1+$ledge->amount;
                                $balance=$balance-$ledge->amount;
                                echo number_format($ledge->amount);
                              }
                               
                              }else{ echo 0;}?></td>
                               <td class="text-right"><?= number_format($balance);?></td>
                          
                          </tr>
                          <?php }?>          
                           <tr>

                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td style="" class="text-center"><b>Total</b></td>
                              <td class="text-center"><b><?php echo number_format($ttl2); ?></b></td>
                              <td colspan="6"><b><?php echo number_format($ttl1); ?></b></td>
                          </tr>                       
                           
    </tbody>
</table>
</div>
</div>
</div>
<center>
<!-- <button class="btn btn-primary btn-sm" 
  8,079,800
  7,919,800
  ---------
    160,000
  ---------  
  onclick="printable_area('printcashdtls')"><span class="fa fa-print"></span> Print</button> -->
<button class="btn btn-success btn-sm col-sm-3" type="button" id="print_att"><i class="fa fa-print"></i> Print</button>
</center>
<noscript>
  <style>
    table.att-list{
      width:100%;
      border-collapse:collapse
    }
    table.att-list td,table.att-list th{
      border:1px solid
    }
    .text-center,.text-c{
      text-align:center
    }
    #myInput{
      display: none;
    }
  </style>
</noscript>
<script type="text/javascript">

function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");

  filter = input.value.toUpperCase();
  table = document.getElementById("myTable2");
  tr = table.getElementsByTagName("tr");
  for (var i = 1; i < tr.length; i++) {
    var tds = tr[i].getElementsByTagName("td");
    var flag = false;
    for(var j = 0; j < tds.length; j++){
      var td = tds[j];
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        flag = true;
      } 
    }
    if(flag){
        tr[i].style.display = "";
    }
    else {
        tr[i].style.display = "none";
    }
  }
}
function myFunction1() {
var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("date");
  //alert(input);
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable2");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 1; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
  }
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");

  filter = input.value.toUpperCase();
  table = document.getElementById("myTable2");
  tr = table.getElementsByTagName("tr");
  for (var i = 1; i < tr.length; i++) {
    var tds = tr[i].getElementsByTagName("td");
    var flag = false;
    for(var j = 0; j < tds.length; j++){
      var td = tds[j];
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        flag = true;
      } 
    }
    if(flag){
        tr[i].style.display = "";
    }
    else {
        tr[i].style.display = "none";
    }
  }
}
$('#print_att').click(function(){
    var _c = $('#printcashdtls').html();
    var ns = $('noscript').clone();
    var nw = window.open('','_blank','width=1000,height=600')
    nw.document.write(_c)
    nw.document.write(ns.html())
    nw.document.close()
    nw.print()
    // setTimeout(() => {
    //  nw.close()
    // }, 500);
  })
</script>