
<?php  

 $remodel = new App\Models\ReportsModel();
 $classList=$remodel->get_classes1();
 $schoolname=$remodel->get_schoolname();
 ?>
 <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Attendance Report</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                        <?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
                    </a></li>
                    <li class="breadcrumb-item active" aria-current="page"> Attendance Summary Report</li>
                </ol>
            </div>
         </div><br>
          <!----------------Class list attendance start code here----------------->
<div class="container-fluid">
    <div class="col-lg-12">
        <div class="card">
            
            <div class="card-body">
                <form id="manage-attendance">
                    <input type="hidden" name="id" value="">
                    <div class="row justify-content-center" id="head-content">
                        
                        <!---------------------------------------------->
                        
                         <!------------------------------------------------>
                         <div class="col-sm-3" >
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                        <!---------------------------------------------->
                        <div class="col-sm-2">
                            <select name="time" id="session" class="custom-select select2 input-sm" required="required">
                                <option value="">-select session-</option>
                                <option value="0">All</option>
                                <option value="1">Morning</option>
                                <option value="2">Afternoon</option>
                                <option value="3">Night</option>
                              
                            </select>
                        </div>
                         <!------------------------------------------------>
                         <div class="col-sm-2">
							<button class="btn  btn-primary" type="button" id="filter">Filter</button>
						</div>
                        </div>                         <!------------------------------------------------>
                    </div>
                     <div id="back-button" style="display: none;" >
                     <center>
                     	<button class="btn  btn-primary" type="button" id="back">Back</button>
                      </center>
                     </div>
                    <hr id="hr">
                  
                    	<center>
                    <div id="Rept1ResultViewResults"></div>
                    <div id="Rept1Result"></div>
                </center>
                    <div class="row">
                        <div class="col-md-12" id='att-list'>
                            
                        </div>
                        <div class="col-md-12"  style="display: none" id="submit-btn-field">
							<center>
								<button class="btn btn-success btn-sm col-sm-3" type="button" id="print_att"><i class="fa fa-print"></i> Print</button>
							</center>
						</div>
					</div>
                   
                </form>
            </div>
        </div>
    </div>
</div>
<div id="table_clone" style="display: none;" >
	<center>
	<h5><?php echo $schoolname[0]->company_name; ?></h5>
	<h5>Attendance Record Summary of <span class="class"></span> <span class="stream"></span></h5>
	<h5>Date: <span class="doc"></span> <span class="session"></span></h5>
	</center>
	<!-- <table width="100%" style="margin-left:30px">
		<tr><th></th></tr>
		<tr>
			<td width="50%" style="padding-left:100px">
				<p>Class: <b class="class"></b></p>
				<p>Stream: <b class="stream"></b></p>
				<p>Total Days of Classes: <b class="noc"></b></p>
			</td>
			<td width="50%">
				
				<p>Date From: <b class="doc"></b></p>
				<p>session: <b class="session"></b></p>
			</td>
		</tr>
	</table> -->
	<table class='table table-bordered table-hover att-list'>
		<thead>
			<tr>
				<th class="text-center" width="5%">#</th>
				<th width="20%">First Name</th>
				<th width="20%">Middle Name</th>
				<th width="20%">Last Name</th>
				<th>Present</th>
				<th>Late</th>
				<th>Absent</th>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
</div>
<!-- Modal -->
  <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="">Parent contact</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="parentinfo"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
<!-----End update modal--->
<style>
	.present-inp,.absent-inp,.late-inp,.present-lbl,.absent-lbl,.late-lbl{
		cursor: pointer;
	}
</style>
<noscript>
	<style>
		table.att-list{
			width:100%;
			border-collapse:collapse
		}
		table.att-list td,table.att-list th{
			border:1px solid
		}
		.text-center,.text-c{
			text-align:center
		}
		#cont{
			display: none;
		}
	</style>
</noscript>
<script>
  $('#back').click(function(){
      //alert("back now");
      $('#att-list').hide();
      $('#submit-btn-field').hide();
      $('#back').hide();
      $('#head-content').show();
             $('#Rept1ResultViewResults').html('');
		var sess=$('#session option:selected').val();
       var dta = "thedate=" + $('#daterange-btn span').html()+"&sess=" + sess;
       // if(sess==""){
        
       //       swal('Please! select session');   
            
       //  }else{
        	$('#Rept1Result').html('<span class="fa fa-spinner fa-spin text-center"></span> Loading...');
        
		$.ajax({
			 url: '<?php echo base_url() . '/get_attendance_summary'; ?>',
			type:'POST',
			data:dta,
			success:function(res){
				$('#Rept1Result').html(res);
				   $('#Rept1ResultViewResults').html('');
				   $('#submit-btn-field').hide();
                },
                error: function () {
                    $('#Rept1Result').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
		e.preventDefault();


});
	$('#filter').click(function(){
       $('#Rept1ResultViewResults').html('');

		var sess=$('#session option:selected').val();
       var dta = "thedate=" + $('#daterange-btn span').html()+"&sess=" + sess;
       if(sess==""){
        
             swal('Please! select session');   
            
        }else{
        	$('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin text-center"></span> Loading...');
        
		$.ajax({
			 url: '<?php echo base_url() . '/get_attendance_summary'; ?>',
			type:'POST',
			data:dta,
			success:function(res){
				$('#Rept1Result').html('');
				$('#submit-btn-field').hide();
				   $('#Rept1ResultViewResults').html(res);
				   $('#Rept1ResultViewResults').show();
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
		e.preventDefault();
	}});

	$('#print_att').click(function(){
		var _c = $('#att-list').html();
		var ns = $('noscript').clone();
		var nw = window.open('','_blank','width=900,height=600')
		nw.document.write(_c)
		nw.document.write(ns.html())
		nw.document.close()
		nw.print()
		// setTimeout(() => {
		// 	nw.close()
		// }, 500);
	})

	             $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });
 function viewClasses(cid,stid,thedate,sess) {
	   	 var sess=$('#session option:selected').val();
        
        var dta = "thedate=" + thedate;
        //alert(dta);
        if(sess==""){
            swal('Please!');
        }else{
        	$('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin text-center"></span> Loading...');
       
		$.ajax({
			 url: '<?php echo base_url() . '/get_attendance_report'; ?>/'+cid+'/'+stid+'/'+1+'/'+sess,
			type:'POST',
			data:dta,
			success:function(resp){
				if(resp){
					$('#Rept1ResultViewResults').hide();
					$('#head-content').hide();
					$('#back-button').show();
					//$('#hr').hide();
					
					resp = JSON.parse(resp)
					var _table = $('#table_clone').clone()
					$('#att-list').html('')
					$('#att-list').append(_table)
					var _type = ['Absent','Present','Late'];
					var data = !!resp.data ? resp.data : [] ;
					var record = !!resp.record ? resp.record :[];
					var attendance_id = !!resp.attendance_id ? resp.attendance_id : 0;
					if(Object.keys(data).length > 0){

						var i = 1;
						Object.keys(data).map(function(k){
							var fname = data[k].first_name;
							var mname = data[k].middle_name;
							var lname = data[k].last_name;
							var id = data[k].student_id;
							var tr = $('<tr></tr>')

							var present=0;
							var	late=0;
							var	absent=0;
							var noc=0;
							console.log(Object.keys(record).length)
							// record = JSON.parse(record)
								if(Object.keys(record).length > 0){
								if(record[id].length > 0){
									Object.keys(record[id]).map(i=>{
										noc=noc+1;
										if(record[id][i].type == 0)
											absent = parseInt(absent) + 1;
										if(record[id][i].type == 1)
											present = parseInt(present) + 1;
										if(record[id][i].type == 2)
											late = parseInt(late) + 1;
									})
								}  
								}  

							tr.append('<td class="text-center">'+(i++)+'</td>')
							tr.append('<td class="text-c">'+(fname)+'</td>')
							tr.append('<td class="text-c">'+(mname)+'</td>')
							tr.append('<td class="text-c">'+(lname)+'</td>')
							var td = '<td class="text-center">';
								td += present;
								td += '</td>';
								td += '<td class="text-center">';
								td += late;
								td += '</td>';
								td += '<td class="text-center">';
								td += absent;
								td += '</td>';
								td+='<td id="cont">';
								td+=
                            '<a href="javascript:view_contact('+id+');" class="btn btn-primary btn-sm dlt">Contact</a>';
                                td+='</td>';
							tr.append(td)

							_table.find('table.att-list tbody').append(tr)
						})
						$('#Rept1Result').html('');
						$('#back').show();
						$('#att-list').show();
						$('#submit-btn-field').show();
						

						
					}else{
						alert('no data available');
						$('#att-list').html('<span class=""></span>No data available...');
                         $('#submit-btn-field').hide();
						// 	var tr = $('<tr></tr>')
						// 	tr.append('<td class="text-center" colspan="5">No data.</td>')
						// 	_table.find('table.att-list tbody').append(tr)
						// $('#submit-btn-field').attr('data-id','').hide()
						// $('#edit_att').attr('data-id','')
					} 
					$('#att-list').html('')
					_table.find('.stream').text(!!resp.details.stream ? resp.details.stream : '')
					_table.find('.session').text(!!resp.details.session ? resp.details.session : '')
					_table.find('.class').text(!!resp.details.class ? resp.details.class : '')
					_table.find('.doc').text(!!resp.details.doc ? resp.details.doc : '')
					_table.find('.noc').text(!!resp.details.noc ? resp.details.noc : '')

					_table.find('.noc').text(!!resp.details.noc ? resp.details.noc : '')
					$('#att-list').append(_table.html())
					if(Object.keys(data).length > 0){
						Object.keys(data).map(k=>{
							// console.log('[name="type['+record[k].student_id+']"][value="'+record[k].type+'"]')
							$('#att-list').find('[name="type['+data[k].student_id+']"][value="'+data[k].type+'"]').prop('checked',true)
						})
					}
				}else{
					alert('no data available');
                         $('#att-list').html('<span class=""></span>No data available...');
                         $('#submit-btn-field').hide();
                        //     var tr = $('<tr></tr>')
                        //     tr.append('<td class="text-center" colspan="3">No data.</td>')
                        //     _table.find('tbody').append(tr)
                        // $('#submit-btn-field').hide()
                    } 
			},
			complete:function(){
				$("input[readonly]").on('keyup keypress change',function(e){
					e.preventDefault()
					return false;
				});
				$('#edit_att').click(function(){
					  view_contact($(this).attr('data-id'));
				})
							
			}
		})
	}}
	function view_contact(id){
  //alert(id);
  $('#myModal').modal('show');

        $.ajax({
            type: "GET",
            url: '<?= base_url('/parent_attendance') ?>/'+id,
            
            beforSend: function()
            {
                $('#parentinfo').html('<span class="fa fa-spinner fa-spin text-center"></span> Loading...');
            },
            success: function(res){
                $('#parentinfo').html(res);
                 
            },
            error: function ()
            {

            }
        });
	}
</script>