<?php
$db=session()->get('db_id');
//print_r($data);
$barColors1=array();
$color1="orange";
$color2="brown";
$color3="blue";
$color4="pink";
$n=0;
foreach ($class_data as $c) {
  $n++;
  if($n==1){
 $color=$color1;
  }elseif($n==2){
$color=$color2;
  }elseif($n==3){
    $color=$color3;
  }elseif($n==4){
  $color=$color4;  
  }else{
    $color="red";
  }
  $limit=$c->id;
  for ($i=0; $i < $limit ; $i++) { 
   $barColors1[] = $color; 
  }
}

//print_r($data);
?>
<canvas id="admitclasses" style="height: auto;"></canvas>

<script>


$(function() {

  var result = JSON.parse('<?php echo $data;?>');
  var DeparMent = [];
  var TotalNumber = [];
  var dbid='<?php echo $db;?>';

  result.forEach(function(details) {
    DeparMent.push(details['name']);
    TotalNumber.push(details['total']); 
  });
//console.log(DeparMent);
  //global option......................
  Chart.defaults.global.defaultFontSize = 12;
  Chart.defaults.global.defaultFontFamily = 'Adobe Fan Heiti Std B';
  if(dbid==7){
 var barColors = ["brown","brown","brown","brown","brown","brown","brown","orange", "orange","orange"];
  }else{
     var barColors = <?php echo json_encode($barColors1); ?>;
          //var barColors = ["orange", "orange","orange","brown","brown","brown","brown","brown","brown","brown"];
   }
    var MyChart = document.getElementById('admitclasses').getContext("2d");
    var MassChart = new Chart(MyChart,{
      type:'bar',
      data:{
        labels:DeparMent,
        datasets:[{
          label:'Number Of students',
          data:TotalNumber,
          backgroundColor:barColors
        }]
      },
      options:{
            responsive: true,
        title:{
          display:true,
          text:'',
          FontSize:25
        },
        legend:{
          display:true,
          position:'left'
        },
            plugins:{
              labels: {
                // render 'label', 'value', 'percentage', 'image' or custom function, default is 'percentage'
                render: 'value',

                // text shadow intensity, default is 6
                shadowBlur: 10,

                // identifies whether or not labels of value 0 are displayed, default is false
                showZero: false,
         
                // font size, default is defaultFontSize
                fontSize: 13,
         
                // font color, can be color array for each data or function for dynamic color, default is defaultFontColor
                fontColor: '#000',
         
                // font style, default is defaultFontStyle
                fontStyle: 'normal',
         
                // font family, default is defaultFontFamily
                fontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
         
                // draw text shadows under labels, default is false
                textShadow: true
            
                }
                
            },    
      }
    });
    

});

    
</script>