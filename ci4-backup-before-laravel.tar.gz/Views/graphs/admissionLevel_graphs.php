
<canvas id="admitlevel" style="height: auto;"></canvas>

<script>


$(function() {

  var result = JSON.parse('<?php echo $data;?>');
  var DeparMent = [];
  var TotalNumber = [];

  result.forEach(function(details) {
    DeparMent.push(details['name']);
    TotalNumber.push(details['total']); 
  });

  //global option......................
  Chart.defaults.global.defaultFontSize = 12;
  Chart.defaults.global.defaultFontFamily = 'Adobe Fan Heiti Std B';
     var barColors = ["orange", "brown","blue","pink","brown"];
    var MyChart = document.getElementById('admitlevel').getContext("2d");
    var MassChart = new Chart(MyChart,{
      type:'bar',
      data:{
        labels:DeparMent,
        datasets:[{
          label:'Number Of students',
          data:TotalNumber,
          backgroundColor:barColors
        }]
      },
      options:{
            responsive: true,
        title:{
          display:true,
          text:'',
          FontSize:25
        },
        legend:{
          display:true,
          position:'left'
        },
            plugins:{
              labels: {
                // render 'label', 'value', 'percentage', 'image' or custom function, default is 'percentage'
                render: 'value',

                // text shadow intensity, default is 6
                shadowBlur: 10,

                // identifies whether or not labels of value 0 are displayed, default is false
                showZero: false,
         
                // font size, default is defaultFontSize
                fontSize: 13,
         
                // font color, can be color array for each data or function for dynamic color, default is defaultFontColor
                fontColor: '#000',
         
                // font style, default is defaultFontStyle
                fontStyle: 'normal',
         
                // font family, default is defaultFontFamily
                fontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
         
                // draw text shadows under labels, default is false
                textShadow: true
            
                }
                
            },    
      }
    });
    

});

    
</script>