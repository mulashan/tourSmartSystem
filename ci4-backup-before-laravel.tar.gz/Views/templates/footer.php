
	


		<!-- Start main footer -->
        <!-- <div class="section-body">
            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <strong>
                                Copyright © 2022 <a href="http://microhealthinitiative.org" target="blank">MHI</a>.
                            </strong>
                            All rights reserved.
                        </div>
                    </div>
                </div>
            </footer>
        </div> -->
<?php
$releaseConfig = new \App\Config\SystemRelease();
$releaseHistory = $releaseConfig->releases ?? [];
$currentRelease = $releaseHistory[0] ?? [
    'version' => '1.0.0',
    'released_at' => date('Y-m-d H:i'),
];
$footerDateTime = \DateTime::createFromFormat('Y-m-d H:i', $currentRelease['released_at']);
$footerReleaseDate = $footerDateTime ? $footerDateTime->format('d-m-Y H:i') : $currentRelease['released_at'];
$copyrightYear = $footerDateTime ? $footerDateTime->format('Y') : date('Y');
?>
        <style>
            .page {
                min-height: calc(100vh - 70px);
                display: flex;
                flex-direction: column;
            }

            .system-footer-wrap {
                margin-top: auto;
            }

            .system-footer {
                padding: 16px 18px;
                background: #fff;
                border-top: 1px solid #e8edf5;
            }

            .system-footer-inner {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 12px;
                flex-wrap: wrap;
                color: #4a5568;
                font-size: 14px;
            }

            .system-footer-copy strong {
                color: #2d3748;
            }

            .system-footer-copy a,
            .system-footer-version a {
                color: #0d6efd;
            }

            .system-footer-version {
                display: flex;
                align-items: center;
                gap: 14px;
                flex-wrap: wrap;
            }

            @media (max-width: 767px) {
                .system-footer-inner,
                .system-footer-version {
                    justify-content: center;
                    text-align: center;
                }
            }
        </style>

        <div class="section-body system-footer-wrap">
            <footer class="system-footer">
                <div class="container-fluid">
                    <div class="system-footer-inner">
                        <div class="system-footer-copy">
                            <strong>Copyright &copy; <?= esc($copyrightYear); ?>
                                <a href="<?= esc($releaseConfig->copyrightUrl); ?>" target="_blank"><?= esc($releaseConfig->copyrightName); ?></a>.
                            </strong>
                            All rights reserved.
                        </div>
                        <div class="system-footer-version">
                            <div><a href="#" onclick="openSystemReleaseModal(); return false;">Version <?= esc($currentRelease['version']); ?></a></div>
                            <div><?= esc($footerReleaseDate); ?></div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>    
</div>

<!-- Start Main project js, jQuery, Bootstrap -->
<!-- <script src="<?php //echo base_url('public/assets/bundles/lib.vendor.bundle.js')?>"></script> -->
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/yearPicker/yearpicker.css')?>"/>
<script src="<?php echo base_url('public/assets/plugins/yearPicker/yearpicker.js')?>"></script>
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/toastr/toastr.css')?>" />
<script src="<?php echo base_url('public/assets/plugins/toastr/toastr.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/moment/moment.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/dist/jquery.inputmask.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/daterangepicker/daterangepicker.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/bootstrap4_datepicker/js/bootstrap-datetimepicker.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script><!-- <script src="<?php// echo base_url('public/assets/plugins/dropify/js/dropify.min.js')?>"></script> -->
<script src="<?php echo base_url('public/assets/plugins/sweetalert/sweetalert.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/DataTables/datatables.min.js')?>"></script>

<!-- Printing plugins -->
<script src="<?php echo base_url('public/assets/plugins/print-js/print.min.js')?>"></script>

<!-- Start all plugin js -->
<!-- <script src="<?php //echo base_url('public/assets/bundles/counterup.bundle.js')?>"></script> -->
 <script src="<?php echo base_url('public/assets/bundles/apexcharts.bundle.js')?>"></script>
 <script src="<?php echo base_url('public/assets/bundles/echarts.bundle.js')?>"></script>
<script src="<?php echo base_url('public/assets/bundles/summernote.bundle.js')?>"></script>
<!-- <script src="<?php //echo base_url('public/assets/bundles/fullcalendar.bundle.js')?>"></script> -->

<!-- Start project main js  and page js -->
<script src="<?php echo base_url('public/assets/js/core.js')?>"></script>
<!-- <script src="<?php //echo base_url('public/school/assets/js/page/index.js')?>"></script> -->
<!--<script src="<?php // echo base_url('public/school/assets/js/page/summernote.js')?>"></script>-->
<!-- <script src="<?php //echo base_url('public/school/assets/js/form/dropify.js')?>"></script> -->
<!-- <script src="<?php //echo base_url('public/school/assets/js/page/dialogs.js')?>"></script> -->
<!-- <script src="<?php //echo base_url('public/school/assets/js/page/calendar.js')?>"></script> -->
<script src="<?php echo base_url('public/assets/select/js/select2.min.js')?>"></script>
	<?php
    if(!isset($_SESSION['logged_in'])) {
	
		echo "<script>
		swal('Please login',
		)
		window.location ='".base_url()."/login';
         </script>";
             }
		     ?>
<script>
  toastr.options.closeButton=true;
    toastr.options.progressBar=true;
$(document).ready(function () {
  $('#myTable').DataTable();
});

$(document).ready(function(){ 
    $(":input").inputmask();     
});
// $(function() {
//     "use strict";
    
//     $('.dropify').dropify();

//     var drEvent = $('#dropify-event').dropify();
//     drEvent.on('dropify.beforeClear', function(event, element) {
//         return confirm("Do you really want to delete \"" + element.file.name + "\" ?");
//     });

//     drEvent.on('dropify.afterClear', function(event, element) {
//         alert('File deleted');
//     });

//     $('.dropify-fr').dropify({
//         messages: {
//             default: 'Glissez-déposez un fichier ici ou cliquez',
//             replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
//             remove: 'Supprimer',
//             error: 'Désolé, le fichier trop volumineux'
//         }
//     });
// });
$('.collapse').on('show.bs.collapse', function () {
	$('.collapse.in').each(function(){
	$(this).collapse('hide');
});
});

$(document).on('click', '.toggle', function(event) {
  event.preventDefault();
  
  var target = $(this).data('target');
  $('#' + target).toggleClass('hide');
});


document.addEventListener("DOMContentLoaded", function(){
  document.querySelectorAll('.sidebar .nav-link').forEach(function(element){
    
    element.addEventListener('click', function (e) {

      let nextEl = element.nextElementSibling;
      let parentEl  = element.parentElement;	

        if(nextEl) {
            e.preventDefault();	
            let mycollapse = new bootstrap.Collapse(nextEl);
            
            if(nextEl.classList.contains('show')){
              mycollapse.hide();
            } else {
                mycollapse.show();
                // find other submenus with class=show
                var opened_submenu = parentEl.parentElement.querySelector('.submenu.show');
                // if it exists, then close all of them
                if(opened_submenu){
                  new bootstrap.Collapse(opened_submenu);
                }
            }
        }
    }); // addEventListener
  }) // forEach
}); 

 $(function () {
                                $('.daterange-all').each(function () {
                                    var $picker = $(this);
                                    var start = $picker.attr('data-start') ? moment($picker.attr('data-start')) : moment();
                                    var end = $picker.attr('data-end') ? moment($picker.attr('data-end')) : moment();

                                    function cb(startDate, endDate) {
                                        $picker.find('span').html(startDate.format('YYYY/M/D') + ' - ' + endDate.format('YYYY/M/D'));
                                        $picker.attr('data-start', startDate.format('YYYY-MM-DD'));
                                        $picker.attr('data-end', endDate.format('YYYY-MM-DD'));
                                    }

                                    $picker.daterangepicker({
                                        startDate: start,
                                        endDate: end,
                                        ranges: {
                                            'Today': [moment(), moment()],
                                            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                            'This Month': [moment().startOf('month'), moment().endOf('month')],
                                            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                                            'This Year': [moment().startOf('year'), moment().endOf('year')],
                                            'Last Year': [moment().subtract(1, 'year').startOf('year'), moment().subtract(1, 'year').endOf('year')],
                                        }
                                    }, cb);

                                    cb(start, end);
                                });

                            });

</script>

</body>
</html>
<script>
   window.onload = function () {
    if (localStorage.tabCount) {
        if(Number(localStorage.tabCount) <=0){
       localStorage.tabCount = 1;
        }else{
          localStorage.tabCount = Number(localStorage.tabCount) + 1;   
        }
       
    } else {
        localStorage.tabCount = 1;
    }
    console.log("Number of tabs open: " + localStorage.tabCount);
};

window.onbeforeunload = function () {
    localStorage.tabCount = Number(localStorage.tabCount) - 1;
};
    var userAgent = navigator.userAgent;

if (userAgent.match(/Android/i)) {
    $('#smallScreenTab').show();
    $('#largeScreenTab').hide();
} else if (userAgent.match(/Windows/i)) {
      $('#smallScreenTab').hide();
    $('#largeScreenTab').show();
}else{
    //alert('undefined');
    $('#smallScreenTab').show();
    $('#largeScreenTab').hide();

var customStyle = document.createElement('style');
customStyle.innerHTML = `
   /* CSS rules go here */
  
   .modal-body {
    max-height: 60vh; /* Adjust the maximum height as needed */
    overflow-y: auto;
}
.modal-xl {
        max-width: 90%; /* Adjust the width as needed */
        margin: 10% auto; /* Center the modal vertically */
    }
`;

document.head.appendChild(customStyle);
}
    
    $(document).ready(function () {
       
        var idleInterval = setInterval(CheckIdleTime, 1000);
        var CheckExpiredSession = setInterval(ExpiredSession, 1000);
        $(this).mousemove(function (e) {
            idleTime = 0;
        });
        $(this).keypress(function (e) {
            idleTime = 0;
        });
     // CheckExpiredSession();
    });   
  function CheckIdleTime() {
        if (typeof idleTime === 'undefined') {
    // Variable is undefined
     idleTime = 0;
   // console.log('Variable is undefined');
} 
        idleTime = idleTime + 1;
      // console.log(idleTime);
        if(idleTime > 900) {
             console.log('tabs='+localStorage.tabCount);
            if(localStorage.tabCount==1){
         window.location.replace('<?php echo base_url('/Logout'); ?>');
            }else{
            window.location.replace('<?php echo base_url('/Logout2'); ?>');
           }
        }
    }

    function ExpiredSession(){
         $.ajax({
             url: '<?php echo base_url() . '/index.php/LogoutController/checkSession'; ?>',
               success: function (result) {
                if(result==0){
                window.location.replace('<?php echo base_url('/Logout'); ?>');
                }  
                },
                error: function () {
                console.log("Error checking session status:");
               }
            });
    }     
     $(function () {
        const currentYear = new Date().getFullYear();  
         $('#button-y').yearpicker({
            year:currentYear,
           startYear:2022,
           endYear:currentYear+1,
      
         });
        
          });
          
  
    </script>
