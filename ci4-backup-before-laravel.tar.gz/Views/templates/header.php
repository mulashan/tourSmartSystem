
<?php
$login = new App\Models\LoginModel();
$bmodel = new App\Models\BillingModel();
use App\Models\BillModel;
$this->billmodel = new BillModel;
 $logo = $bmodel->get_table_details('company_tbl');
  $source="";
            if($logo[0]->logo_name != ""){
               $source =  base_url('public/company_photos/'.$logo[0]->logo_name);
            }
?>

<!doctype html>
<html lang="en" dir="ltr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="icon" href="<?php echo base_url('public/favicon1.ico')?>" type="image/x-icon"/>
<script src="<?php echo base_url('public/assets/plugins/jquery/jquery-3.4.1.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/charts-c3/c3.min.css')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/charts-c3/c3.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/chartjs/chart.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/sweetalert/sweetalert.min.js')?>"></script>
<!-- <script src="<?php echo base_url('public/assets/plugins/toastr/toastr.css')?>"></script> -->

<title>:: <?php
 if(session()->get('logged_in')==true){
    $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
           echo $shule[0]->instituition;
           }
?> ::</title>
<?php
    if(!isset($_SESSION['logged_in'])) {
    
        echo "<script>
        swal('Please login',
        )
        window.location ='".base_url()."/login';
         </script>";
             }else{
             ?>
<?php 

    $lmodel = new App\Models\LoginModel();

?>
<?php
$menus = $lmodel->get_allowed_menu(session()->get('user_type'), session()->get('initial_username'));
session()->set('allowed_menu', $menus);
$releaseConfig = new \App\Config\SystemRelease();
$releaseHistory = $releaseConfig->releases ?? [];
$currentRelease = $releaseHistory[0] ?? [
    'version' => '1.0.0',
    'released_at' => date('Y-m-d H:i'),
    'title' => 'System release',
    'changes' => [],
];
$releaseNotificationKey = 'system_release_' . str_replace('.', '_', $currentRelease['version']);
$releaseDateTime = \DateTime::createFromFormat('Y-m-d H:i', $currentRelease['released_at']);
$releaseDisplayDate = $releaseDateTime ? $releaseDateTime->format('d-m-Y H:i') : $currentRelease['released_at'];
?>

<!-- Bootstrap Core and vandor -->
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/bootstrap/css/bootstrap.min.css')?>" />
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/bootstrap-5.0.2-dist/css/bootstrap.min.css')?>" />

 <link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')?>">
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/daterangepicker/daterangepicker.css')?>">
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/bootstrap4_datepicker/css/bootstrap-datetimepicker.min.css')?>">
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/DataTables/datatables.min.css')?>">
 <link rel="stylesheet" href="<?php //echo base_url('public/assets/plugins/fullcalendar/fullcalendar.min.css')?>">
 <link rel="stylesheet" href="<?php //echo base_url('public/assets/plugins/dropify/css/dropify.min.css')?>" />
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/sweetalert/sweetalert.css')?>" />

<!-- Plugins css -->
<link rel="stylesheet" href="<?php // echo base_url('public/assets/plugins/summernote/dist/summernote.css')?>"/>

<link rel="stylesheet" href="<?php echo base_url('public/assets/select/css/select2.min.css')?>"/> 
<!-- Core css -->
<link rel="stylesheet" href="<?php echo base_url('public/assets/css/style.min.css')?>"/> 
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/print-js/print.min.css')?>"/>
<link rel="stylesheet" href="<?php echo base_url('public/assets/flatpickr/confirmDate.css')?>"/>
<link rel="stylesheet" href="<?php echo base_url('public/assets/flatpickr/flatpickr.min.css')?>"/>
<script src="<?php echo base_url('public/assets/flatpickr/confirmDate.js')?>"></script>
<script src="<?php echo base_url('public/assets/flatpickr/flatpickr.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/sweetalert/sweetalert.min.js')?>"></script>

<script src="<?php echo base_url('public/assets/bundles/lib.vendor.bundle.js')?>"></script>

<style>
    .elink li{
        padding:5px;
    }
    .elink li a{
        padding:3px;
        color:#fff;
    }
    .elink li a:hover{
        color:#fff;
    }
    .elink li a i{
        padding:5px;
    }
    .elink li .collapse{
        padding-left:-15px;
        color:red;
    }
    div.dataTables_filter > label {
  color: black;
}
#loader {
  position: fixed;
  z-index: 9999;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: #fff;
  display: flex;
  justify-content: center;
  align-items: center;
}

.spinner {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  border: 5px solid #333;
  border-top-color: #fff;
  animation: spin 1s ease-in-out infinite;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

 .notification-badge {
            background-color: red;
            color: white;
            border-radius: 50%;
            padding: 4px 8px;
            font-size: 12px;
            vertical-align: super;
            line-height: 1;
            right: 10px;
        }
        a{
            text-decoration: none;
        }

       .help-icon {
    display: inline-block;
    position: relative;
    font-size: 13px; /* Adjust the size as needed */
    vertical-align: super;
    line-height: 1;
}

.icon1 {
    display: inline-block;
    width: 20px;
    height: 20px;
    background-color: #00BFFF;
    color: white;
    border-radius: 50%;
    text-align: center;
    line-height: 20px;
    font-size: 14px;
    font-weight: bold;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Hover effect */
.icon1:hover {
    background-color: #2980b9;
}

  .tooltip-container {
  position: absolute;
  display: inline-block;
}

.tooltip-container::after {
  content: attr(data-tooltip);
  position: absolute;
   top: 50%;
  left: 300%; /* Position tooltip to the right of the container */
  margin-left: 100px;
  transform: translateX(-50%);
  background-color: #333;
  color: #fff;
  padding: 5px;
  border-radius: 5px;
  white-space: nowrap;
  opacity: 0;
  visibility: hidden;
  transition: opacity 0.3s;
  z-index: 1000;
  pointer-events: none; /* Prevents tooltip from interfering with mouse events */
}

.tooltip-container:hover::after {
  opacity: 1;
  visibility: visible;
}

.schoolname {
            font-size: 20px;
            font-family: Arial, sans-serif;
            color: #f39c12;
            position: relative;
            text-transform: uppercase;
            text-shadow: 
                1px 1px 0 #e74c3c, 
                2px 2px 0 #c0392b, 
                3px 3px 0 #8e44ad;
        }

.system-release-dropdown .dropdown-menu {
    min-width: 290px;
    padding: 0;
}

.system-release-trigger {
    position: relative;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 38px;
    height: 38px;
    border-radius: 50%;
    color: #4a5568;
    background: #f5f7fb;
}

.system-release-trigger:hover,
.system-release-trigger:focus {
    color: #0d6efd;
    background: #eaf2ff;
}

.system-release-count {
    position: absolute;
    top: -2px;
    right: -2px;
    min-width: 18px;
    height: 18px;
    padding: 0 5px;
    border-radius: 999px;
    background: #0ea5e9;
    color: #fff;
    font-size: 11px;
    font-weight: 700;
    line-height: 18px;
    text-align: center;
}

.system-release-header {
    padding: 12px 16px 8px;
    font-weight: 700;
    border-bottom: 1px solid #edf2f7;
}

.system-release-item {
    display: block;
    padding: 12px 16px;
    color: #2d3748;
}

.system-release-item:hover {
    background: #f8fbff;
    color: #0d6efd;
}

.system-release-item small {
    display: block;
    margin-top: 4px;
    color: #718096;
}

.system-release-empty {
    padding: 14px 16px;
    color: #718096;
}

.system-release-footer-link {
    display: block;
    padding: 12px 16px;
    text-align: center;
    border-top: 1px solid #edf2f7;
    color: #2d3748;
}

.system-release-footer-link:hover {
    background: #f8fbff;
    color: #0d6efd;
}

.system-release-meta {
    color: #718096;
    font-size: 13px;
}

.system-release-list {
    margin: 12px 0 0;
    padding-left: 18px;
}

.system-release-history {
    border-top: 1px solid #edf2f7;
    margin-top: 18px;
    padding-top: 18px;
}

.system-release-history-item + .system-release-history-item {
    margin-top: 18px;
}
</style>

</head>
<body class="font-muli theme-cyan gradient">
    <!-- Page Loader -->
<!-- <div class="page-loader-wrapper">
    <div class="loader">
    </div>
</div> -->
<div id="loader">
  <div class="spinner"></div>
</div>


<div id="main_content">
    <!-- Start Main top header -->
    <div id="header_top" class="header_top">
        <div class="container">
            <div class="hleft">
                               <?php if(session()->get('db_id')==17){?>
    <a class="nav-link d-flex justify-content-start" href="<?php echo base_url('dashboard')?>"><img src="<?php  echo $source; ?>" class="fa  brand-logo"></a>
                       <?php
                    }else{
                    ?>
                      <a class="nav-link header-brand d-flex justify-content-start" href="<?php echo base_url('dashboard')?>"><i class="fa fa-graduation-cap brand-logo"></i></a>
                          <?php
                }?>
                <div class="dropdown">
                    <a href="javascript:void(0)" class="nav-link icon menu_toggle"><i class="fa fa-bars"></i></a>
                </div>
            </div>
            <div class="hright">
               
            <a href="javascript:void(0)" class="nav-link icon settingbar"><i class="fa fa-gears"></i></a>                
            </div>
        </div>
    </div>
    <!-- Start Rightbar setting panel -->
    <div id="rightsidebar" class="right_sidebar">
        <a href="javascript:void(0)" class="p-3 settingbar float-right"><i class="fa fa-close"></i></a>
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Settings" aria-expanded="true">Settings</a></li>
        </ul>
        <div class="tab-content">
            <div role="tabpanel" class="tab-pane vivify fadeIn active" id="Settings" aria-expanded="true">
                <div class="mb-4">
                    <h6 class="font-14 font-weight-bold text-muted">Theme Color</h6>
                    <ul class="choose-skin list-unstyled mb-0">
                        <li data-theme="azure"><div class="azure"></div></li>
                        <li data-theme="indigo"><div class="indigo"></div></li>
                        <li data-theme="purple"><div class="purple"></div></li>
                        <li data-theme="orange"><div class="orange"></div></li>
                        <li data-theme="green"><div class="green"></div></li>
                        <li data-theme="cyan" class="active"><div class="cyan"></div></li>
                        <li data-theme="blush"><div class="blush"></div></li>
                        <li data-theme="white"><div class="bg-white"></div></li>
                    </ul>
                </div>
                <div class="mb-4">
                    <h6 class="font-14 font-weight-bold text-muted">Font Style</h6>
                    <div class="custom-controls-stacked font_setting">
                        <label class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="font" value="font-muli" checked="">
                            <span class="custom-control-label">Muli Google Font</span>
                        </label>
                        <label class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="font" value="font-montserrat">
                            <span class="custom-control-label">Montserrat Google Font</span>
                        </label>
                        <label class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="font" value="font-poppins">
                            <span class="custom-control-label">Poppins Google Font</span>
                        </label>
                    </div>
                </div>
                <div>
                    <h6 class="font-14 font-weight-bold mt-4 text-muted">General Settings</h6>
                    <ul class="setting-list list-unstyled mt-1 setting_switch">
                        <li>
                            <label class="custom-switch">
                                <span class="custom-switch-description">Night Mode</span>
                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-darkmode">
                                <span class="custom-switch-indicator"></span>
                            </label>
                        </li>
                        <li>
                            <label class="custom-switch">
                                <span class="custom-switch-description">Fix Navbar top</span>
                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-fixnavbar">
                                <span class="custom-switch-indicator"></span>
                            </label>
                        </li>
                        <li>
                            <label class="custom-switch">
                                <span class="custom-switch-description">Header Dark</span>
                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-pageheader">
                                <span class="custom-switch-indicator"></span>
                            </label>
                        </li>
                        <li>
                            <label class="custom-switch">
                                <span class="custom-switch-description">Min Sidebar Dark</span>
                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-min_sidebar">
                                <span class="custom-switch-indicator"></span>
                            </label>
                        </li>
                        <li>
                            <label class="custom-switch">
                                <span class="custom-switch-description">Sidebar Dark</span>
                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-sidebar">
                                <span class="custom-switch-indicator"></span>
                            </label>
                        </li>
                        <li>
                            <label class="custom-switch">
                                <span class="custom-switch-description">Icon Color</span>
                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-iconcolor">
                                <span class="custom-switch-indicator"></span>
                            </label>
                        </li>
                        <li>
                            <label class="custom-switch">
                                <span class="custom-switch-description">Gradient Color</span>
                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-gradient" checked="">
                                <span class="custom-switch-indicator"></span>
                            </label>
                        </li>
                        <li>
                            <label class="custom-switch">
                                <span class="custom-switch-description">Box Shadow</span>
                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-boxshadow">
                                <span class="custom-switch-indicator"></span>
                            </label>
                        </li>
                        <li>
                            <label class="custom-switch">
                                <span class="custom-switch-description">RTL Support</span>
                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-rtl">
                                <span class="custom-switch-indicator"></span>
                            </label>
                        </li>
                        <li>
                            <label class="custom-switch">
                                <span class="custom-switch-description">Box Layout</span>
                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-boxlayout">
                                <span class="custom-switch-indicator"></span>
                            </label>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Start Theme panel do not add in project -->
    <div class="theme_div">
        <div class="card">
            <div class="card-body">
                <ul class="list-group list-unstyled">
                    <li class="list-group-item mb-2">
                        <p>Light Version</p>
                        <a href="../university/index.html"><img src="<?php echo base_url('public/assets/images/themes/default.png')?>" class="img-fluid" alt="" /></a>
                    </li>
                    <li class="list-group-item mb-2">
                        <p>Dark Version</p>
                        <a href="../university-dark/index.html"><img src="<?php echo base_url('public/assets/images/themes/dark.png')?>" class="img-fluid" alt="" /></a>
                    </li>
                    <li class="list-group-item mb-2">
                        <p>RTL Version</p>
                        <a href="../university-rtl/index.html"><img src="<?php echo base_url('public/assets/images/themes/rtl.png')?>" class="img-fluid" alt="" /></a>
                    </li>
                </ul>
            </div>
        </div>        
    </div>
     <!-- Start Main leftbar navigation -->
    <div id="left-sidebar" class="sidebar">
        <h5 class="brand-name schoolname">
            <?php 
                
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
           
            <a href="javascript:void(0)" class="menu_option float-right">
        </a></h5>
        <ul class="nav nav-tabs">
               <?php if(session()->get('db_id')==17){?>
            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#menu-uni"> Hospital</a></li>
                <?php
                    }else{
                    ?>
                       <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#menu-uni"> School</a></li>
                         <?php
                }?>
            <!-- <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#menu-admin">Admin</a></li> -->
        </ul>
        <div class="tab-content mt-3">
            <div class="tab-pane fade show active" id="menu-uni" role="tabpanel">
                <nav class="sidebar-nav">
                
                    <ul class="nav flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start elink" id="nav_accordion">
                         <?php
                      if(isset($_SESSION['logged_in'])) {
                         $approval=0; 
                     for ($i = 0; $i < count($menus); $i++) {
                       if($menus[$i]->collapse==1){
                            
                            $sub_menus = $lmodel->get_custom_allowed_submenu(session()->get('user_type'),session()->get('initial_username'),$menus[$i]->module_id);
                                 if (count($sub_menus) == 0) {
                                  continue;
                                 }
                                ?>
                                <li class="has-submenu">
                            <a class="nav-link" href="#"  style="color:#fff"><i class="<?php echo $menus[$i]->menu_icon;?>"></i><span><?php echo $menus[$i]->label;?></span><i class="fa fa-chevron-circle-down"></i> </a>
                            <ul class="submenu collapse">
                            <?php
                            
                            if (count($sub_menus) > 0) {
                                foreach ($sub_menus as $sub_menu) {
                              ?>
                            
                                <li class="nav-item"><a class="nav-link" href="<?php echo base_url().'/'.$sub_menu->route_path;?>"><i class="<?php echo $sub_menu->menu_icon;?>"></i><span><?php echo $sub_menu->label;?></span></a>
                                 
                                </li>
                            <?php
                             }
                             ?>
                            </ul>
                            <?php
                             }
                             ?>
                        </li>
                        <?php
                             
                            }
                             else{
                         ?>
                        
                        <li class="nav-item">
                            
                            <?php if($menus[$i]->new_message>0){
                                $mn='menu'.$menus[$i]->module_id;
                              $check_seen = $lmodel->get_new_message($mn,session()->get('user_id'));
                              if(count($check_seen)>0){
                                ?>
                               <div id="">
                            <a class="nav-link" href="<?php echo base_url().'/'.$menus[$i]->route_path;?>"><i class="<?php echo $menus[$i]->menu_icon;?>"></i><span><?php echo $menus[$i]->label;?></span></a>
                            </div>
                               <?php
                              }else{
                                ?>
                                <div id="show<?php echo $mn; ?>" style="display: none;">
                            <a class="nav-link" href="<?php echo base_url().'/'.$menus[$i]->route_path;?>"><i class="<?php echo $menus[$i]->menu_icon;?>"></i><span><?php echo $menus[$i]->label;?></span></a>
                            </div>

                            <div id="fs<?php echo $mn; ?>">
                            <a class="nav-link" href="#" onclick="tg_notification('<?php echo $mn; ?>')"><i class="<?php echo $menus[$i]->menu_icon;?>"></i><span><?php echo $menus[$i]->label;?></span></a>
                            </div>
                                <div id="s<?php echo $mn; ?>">
                              <a href="#" onclick="tg_notification('<?php echo $mn; ?>')"> <span class="notification-badge">new</span></a>
                              </div>
                           <?php }}else{
                            //print_r($menus);
                            if($menus[$i]->collapse==2){
                              $approval=2;  
                              continue;
                             }
                            ?>
                     <div id="">
                            <a class="nav-link" href="<?php echo base_url().'/'.$menus[$i]->route_path;?>"><i class="<?php echo $menus[$i]->menu_icon;?>"></i><span><?php echo $menus[$i]->label;?></span></a>
                            </div>
                       <?php } ?>
                        </li>
                        <?php
                        }
                        }
                        }
                        ?>
                       
                    </ul>
                </nav>
            </div>
        </div>
    </div>
    <!-- Start project content area -->
    <div class="page">
        <!-- Start Page header -->
        <div class="section-body" id="page_top">
            <div class="container-fluid">
                <div class="page-header">
               
                  

                    <div class="left">                        
                        <div class="input-group">
                             <?php
                         $pdf=$this->billmodel->get_item_name('company_tbl',$where=array('id !=' =>0));
                    $pdf_pay = "";

                    if (!empty($pdf) && !empty($pdf[0]->how_to_pay)) {
                  $pdf_pay = $pdf[0]->how_to_pay;
                list($image1, $image2) = explode('-', $pdf_pay);

                 $source =  base_url('public/trans_logos/pay.png');
                ?>
                 <div class="notification" style="background-color:cyan; border-radius:5px; height: 5%;width: 22%;padding-left: 10px;">
                            <a href="#" onclick="load_pdf('<?=$image1?>','<?=$image2?>')" style="text-decoration: none;color: white;"><img src="<?php echo $source; ?>" width="100" height="50"></a>
                        </div>
                <?php
                    
                    }
                    ?>     
                            <!-- <input type="text" class="form-control" placeholder="">
                            <div class="input-group-append">
                                <button class="btn btn-outline-secondary" type="button">Search</button>
                            </div> -->
                             <!-- <marquee  behavior="alternate" direction="left" style="white-space: nowrap;"> <h6 class="text-danger">Samahani subiri kwa nusu saa, tunafanya update ya mfumo</h6></marquee> -->
                        </div>
                    </div>

                    <div class="right">
                        <!-- <ul class="nav nav-pills">   
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><?php echo session()->get('first_name')." ". session()->get('last_name'); ?></a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item profile" href="<?= base_url('profile_edit'); ?>/<?= session()->get('user_id');?>" data-id="">Profile</a>
                                    <a class="dropdown-item username" href="<?= base_url('/Logout'); ?>">Sign Out</a>
                                    
                                </div>
                            </li>
                        </ul> -->
                         <form id="header_form">
                            <input type="hidden" value="<?= session()->get('user_id');?>" name="header_id">
                            <input type="hidden" value="<?= session()->get('db_id');?>" name="db_id">
                        </form>

                        <div class="notification system-release-dropdown mr-3">
                            <div class="dropdown">
                                <a href="javascript:void(0)" class="system-release-trigger" data-toggle="dropdown" title="System updates">
                                    <i class="fa fa-bell"></i>
                                    <span id="systemReleaseBadge" class="system-release-count" style="display:none;">1</span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <div class="system-release-header">Change Log</div>
                                    <a href="#" class="system-release-item" id="systemReleaseCurrentLink">
                                        <span>View what's new in version <?= esc($currentRelease['version']); ?></span>
                                        <small><?= esc($releaseDisplayDate); ?></small>
                                    </a>
                                    <div class="system-release-empty" id="systemReleaseEmpty" style="display:none;">You're up to date.</div>
                                    <a href="#" class="system-release-footer-link" id="systemReleaseHistoryLink">View all</a>
                                </div>
                            </div>
                        </div>

                                   <!--////////////// Here starts the notification badge /////////////////////-->
                                   <?php 
                             if($approval==2){
                                   ?>
                        <div class="notification">
                            <a href="<?php echo base_url().'/index.php/BillController/Load_approvals_data'; ?>" style="text-decoration: none;">Approvals</a>

                            <?php 
                        
                           $i=0;
                            $approval_total = $this->billmodel->get_number_approval();
                              foreach ($approval_total as $ttl){
                                if($ttl->hstatus == '3'){
                                $checkapp = $this->billmodel->get_item_name('approval_history',$where=array('app_no'=>$ttl->app_no,'hstatus'=>1));
                                if(count($checkapp) > 0){
                                    continue;
                                }else{
                                $checkapp = $this->billmodel->get_item_name('approval_history',$where=array('app_no'=>$ttl->app_no,'hstatus'=>2));
                                if(count($checkapp) > 0){
                                    continue;
                                }
                                    $i++;
                                }
                            } 
                         }

                         ?>
                        <sup class="notification-badge"><?= $i; ?></sup>
                        </div>
                        <?php
                         }
                        ?>
                        
                          <!--///////////////how to pay ///////////-->
                           

                           <!--////////////// Here Ends the notification badge /////////////////////-->
                        
                        <div class="notification d-flex">
                            <div class="dropdown d-flex">
                                <a href="javascript:void(0)" class="chip ml-3" data-toggle="dropdown">
                                   <?php 
                                        if($_SESSION['user_photo']!= ""){
                                   ?>
                                    <span class="avatar" style="background-image: url(<?php echo base_url('public/users_photos/'.$_SESSION['user_photo']);?>)"></span>
                                    <?php } else{?>
                                       <span class="avatar fa fa-user" style="background-color: whitesmoke;"></span>
 
                                    <?php }?>
                                     
                                    <?php print_r($_SESSION['first_name'].' '.$_SESSION['last_name']); ?></a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <a class="dropdown-item profile" href="<?= base_url('profile_edit'); ?>/<?= session()->get('user_id');?>" data-id="">Profile</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="<?php echo base_url('/Logout');?>"><i class="dropdown-icon fe fe-log-out"></i> Sign out</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Start Page title and tab -->
             <?php ?>
      <!-- Modal -->
  <div id="username" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content" style="width:105%">
       <div class="modal-body">
          <div id="prof"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
<!-----End update modal--->
   
 <!-- Modal -->
  <div id="Modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content" style="width:105%">
       <div class="modal-body">
          <div id="prof"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>

  <div id="systemReleaseModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <div>
            <h5 class="modal-title mb-1">What's new in version <?= esc($currentRelease['version']); ?></h5>
            <div class="system-release-meta"><?= esc($releaseDisplayDate); ?></div>
          </div>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <?php if (! empty($currentRelease['title'])) { ?>
            <p class="mb-2"><strong><?= esc($currentRelease['title']); ?></strong></p>
          <?php } ?>

          <?php if (! empty($currentRelease['changes'])) { ?>
            <ul class="system-release-list">
              <?php foreach ($currentRelease['changes'] as $change) { ?>
                <li><?= esc($change); ?></li>
              <?php } ?>
            </ul>
          <?php } else { ?>
            <p class="mb-0">No release notes available for this version yet.</p>
          <?php } ?>

          <?php if (count($releaseHistory) > 1) { ?>
            <div class="system-release-history">
              <h6 class="mb-3">Previous updates</h6>
              <?php foreach (array_slice($releaseHistory, 1) as $releaseItem) {
                  $historyDate = \DateTime::createFromFormat('Y-m-d H:i', $releaseItem['released_at']);
                  $historyDisplayDate = $historyDate ? $historyDate->format('d-m-Y H:i') : $releaseItem['released_at'];
              ?>
                <div class="system-release-history-item">
                  <div><strong>Version <?= esc($releaseItem['version']); ?></strong></div>
                  <div class="system-release-meta"><?= esc($historyDisplayDate); ?></div>
                  <?php if (! empty($releaseItem['changes'])) { ?>
                    <ul class="system-release-list">
                      <?php foreach ($releaseItem['changes'] as $historyChange) { ?>
                        <li><?= esc($historyChange); ?></li>
                      <?php } ?>
                    </ul>
                  <?php } ?>
                </div>
              <?php } ?>
            </div>
          <?php } ?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" onclick="closeSystemReleaseModal()">Read later</button>
          <button type="button" class="btn btn-primary" onclick="markSystemReleaseSeen()">Got it!</button>
        </div>
      </div>
    </div>
  </div>
<?php }?>
<!-----End update modal--->
<?php
 if(isset($_SESSION['logged_in'])) {
 for($i = 0; $i < count($menus); $i++){ ?>
 <div class="modal fade" id="menu<?php echo $menus[$i]->module_id;?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
      </div>
      <div class="modal-body" id="notification_content<?php echo $menus[$i]->module_id;?>">
        
      
      </div>
      <div class="modal-footer">
         <button type="button" class="btn btn-secondary" onclick="read_later(<?=$menus[$i]->module_id ?>)">Read Later</button>
        <button type="button" class="btn btn-primary" onclick="gotoit(<?=$menus[$i]->module_id ?>)">Got it!</button>
          
      </div>
    </div>
  </div>
</div>
<?php }} ?>

<div class="modal fade" id="view_help" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
     <div class="modal-content">
        <div class="modal-header">
          <button type="button" onclick="closePopup()" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div id="loading_spinner">
            <center><b><span class="fa fa-spin fa-spinner"></span> Loading...</b></center>
        </div>
        <iframe id="help_frame" src="" style="height: 750px;"></iframe>
          <img id="help_frame1" src="" style="width:100%; height:auto; object-fit:contain;" />
         <img id="help_frame2" src="" style="width:100%; height:auto; object-fit:contain;" />
    </div>
  </div>
</div>
<script>
const systemReleaseKey = '<?= esc($releaseNotificationKey, 'js'); ?>';
let systemReleaseSeen = true;

$(".profile").click(function () {
        var data =$(this).attr('data-id');
        // $("#idkl").val( ids );
        //alert (data);
       // $('#Modal').modal('show');

           $.ajax({
            method: 'GET',
            
            url: "<?= base_url('profile_edit'); ?>/"+data,
            data: data,
            
            success: function(res){
                $('#prof').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
    
    window.addEventListener("load", function(){
    const loader = document.getElementById("loader");
    loader.style.display = "none";
  });

    function updateSystemReleaseState(seen) {
        systemReleaseSeen = seen;
        if (seen) {
            $('#systemReleaseBadge').hide();
            $('#systemReleaseEmpty').show();
        } else {
            $('#systemReleaseBadge').show();
            $('#systemReleaseEmpty').hide();
        }
    }

    function openSystemReleaseModal() {
        $('#systemReleaseModal').modal('show');
    }

    function closeSystemReleaseModal() {
        $('#systemReleaseModal').modal('hide');
    }

    function markSystemReleaseSeen() {
        if (systemReleaseSeen) {
            closeSystemReleaseModal();
            return;
        }

        $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/index.php/SystemController/load_seen'; ?>',
            data: 'not=' + encodeURIComponent(systemReleaseKey) + '&' + $("#header_form").serialize(),
            success: function () {
                updateSystemReleaseState(true);
                closeSystemReleaseModal();
            },
            error: function () {
                alert('Sorry! Something went wrong while saving the update status.');
            }
        });
    }

    $(document).ready(function () {
        $('#systemReleaseCurrentLink, #systemReleaseHistoryLink').on('click', function (event) {
            event.preventDefault();
            openSystemReleaseModal();
        });

        $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/index.php/SystemController/load_new'; ?>',
            data: {
                header_id: $('input[name="header_id"]').val(),
                update: [systemReleaseKey]
            },
            success: function (response) {
                let seen = false;

                try {
                    const parsed = typeof response === 'string' ? JSON.parse(response) : response;
                    seen = Array.isArray(parsed) && parsed.length > 0 && Number(parsed[0].seen) === 1;
                } catch (error) {
                    seen = false;
                }

                updateSystemReleaseState(seen);

                if (!seen) {
                    setTimeout(function () {
                        openSystemReleaseModal();
                    }, 1200);
                }
            },
            error: function () {
                updateSystemReleaseState(false);
            }
        });
    });

     //loading new updates modal contents
 $(document).ready(function () {
        // Function to update modal content
        function updateModalContent(modalIndex, newContent) {
            $('#notification_content' + modalIndex).html(newContent);

      }

        <?php 
          if(isset($_SESSION['logged_in'])) {
        for($i = 0; $i < count($menus); $i++) { ?>
        $('#menu<?=$menus[$i]->module_id ?>').on('show.bs.modal', function () {
            // Fetch content using AJAX
            $.ajax({
             url: '<?php echo base_url() . '/index.php/SystemController/load_modal_content/menu'.$menus[$i]->module_id; ?>',
               // url: 'path_to_your_controller/load_modal_content/<?=$i ?>',
                type: 'GET',
                success: function (data) {
                    updateModalContent(<?=$menus[$i]->module_id ?>, data);
                }
            });
        });
        <?php } }?>
    });

      function tg_notification(n){
        //swal(''+n);
        $('#'+n).modal('show'); 
      //$('#viewreceipt_content').load('view_receipt/'+inv);
    }
function read_later(id){
   
      $('#menu'+id).modal('hide');
}

function gotoit(id){
   
    var data ='not=menu'+id+'&'+$("#header_form").serialize();
         //alert(data);
         $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/SystemController/load_seen'; ?>',
                data: data,
                success: function (result) {
                  
                      
                         $('#smenu'+id+'').hide();
                         $('#fsmenu'+id+'').hide();
                         $('#showmenu'+id+'').show();
                          $('#menu'+id).modal('hide'); 
                },
                error: function () {
                   alert('Sorry Something went wrong');
               }
            });
}

 function tg_help() {
    $('#help_frame').attr('src', '');
    $('#loading_spinner').show(); // Show the loading spinner
    $('#view_help').modal('show');
    $('#help_frame').on('load', function() {
        $('#loading_spinner').hide(); // Hide the loading spinner once the content is loaded
    });
    $('#help_frame').attr('src', 'https://elcosupport.advaensure.co.tz/article/1-Adding-New-Route');
}
function credit_help() {
    $('#help_frame').attr('src', '');
    $('#loading_spinner').show(); // Show the loading spinner
    $('#view_help').modal('show');
    $('#help_frame').on('load', function() {
        $('#loading_spinner').hide(); // Hide the loading spinner once the content is loaded
    });
    $('#help_frame').attr('src', 'https://elcosupport.advaensure.co.tz/article/7-New-Deposit');
}
    function closePopup(){
            
            $('#help_frame').attr('src', '');
            $('#view_help').modal('hide');
        }

function load_pdf(image1,image2) {
    console.log(image1+'/'+image2);
    $("#help_frame").hide();
    let pdfUrl1 = "<?= base_url('asset') ?>/" + image1 + "#toolbar=0&navpanes=1&scrollbar=1";
      let pdfUrl2 = "<?= base_url('asset') ?>/" + image2 + "#toolbar=0&navpanes=1&scrollbar=1";

$('#help_frame1').attr('src', '');
$('#help_frame2').attr('src', '');
$('#loading_spinner').show();
$('#view_help').modal('show');

$('#help_frame1').on('load', function () {
    $('#loading_spinner').hide();
});

$('#help_frame1').attr('src', pdfUrl1);
$('#help_frame2').attr('src', pdfUrl2);

        }
        
        makeDepositToReceipt();
   function makeDepositToReceipt(){
             $.ajax({
                type: "get",
                url: '<?php echo base_url() . '/index.php/BillingController/make_deposit_to_receipt'; ?>',
               success: function (result) {
                  
                },
                error: function () {
                   console.log('Sorry Something went wrong');
               }
            });
}     
    </script>
