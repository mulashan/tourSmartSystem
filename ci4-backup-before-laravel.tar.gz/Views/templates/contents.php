<?php
    if(!isset($_SESSION['logged_in'])) {
   
      echo "<script>
      swal('Please login',
      )
      window.location ='".base_url()."/login';
         </script>";
             }else{

 

    $lmodel = new App\Models\LoginModel();
    $staffModel = new App\Models\StaffModel();
    $imodel = new App\Models\ItemsModel();

  

?>
<?php
$menus =session()->get('allowed_menu');
//echo session()->get('db_name');
?>
<style>
    /* Ensure the dropdown aligns to the left */
    .yearpicker-container {
        right: 0 !important; /* Adjust as needed */
    }

    .dashboard-side-stack {
        display: flex;
        flex-direction: column;
        gap: 18px;
    }

    .dashboard-calendar-card {
        border: 1px solid #e7ecf3;
        border-radius: 14px;
        overflow: hidden;
        box-shadow: 0 8px 24px rgba(15, 23, 42, 0.06);
        cursor: pointer;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .dashboard-calendar-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.1);
    }

    .dashboard-calendar-head {
        padding: 16px 18px 10px;
        border-bottom: 1px dashed rgba(0, 0, 0, 0.08);
    }

    .dashboard-calendar-label {
        font-size: 11px;
        letter-spacing: 1.2px;
        text-transform: uppercase;
        color: #5a677c;
        margin-bottom: 4px;
        font-weight: 700;
    }

    .dashboard-calendar-title {
        font-size: 28px;
        line-height: 1;
        font-weight: 800;
        color: #24324b;
        margin: 0;
    }

    .dashboard-calendar-year {
        font-size: 13px;
        color: #5a677c;
        margin-top: 6px;
    }

    .dashboard-calendar-body {
        padding: 14px 18px 18px;
        min-height: 220px;
    }

    .dashboard-calendar-events {
        list-style: disc;
        padding-left: 18px;
        margin: 0;
    }

    .dashboard-calendar-events li {
        margin-bottom: 9px;
        color: #374151;
    }

    .dashboard-calendar-event-link {
        border: 0;
        background: transparent;
        padding: 0;
        margin: 0;
        text-align: left;
        color: #2d3748;
        font-size: 13px;
        line-height: 1.35;
        cursor: pointer;
    }

    .dashboard-calendar-event-link:hover {
        color: #0d6efd;
        text-decoration: underline;
    }

    .dashboard-calendar-empty {
        font-size: 13px;
        color: #6b7280;
        padding-top: 6px;
    }

    .dashboard-calendar-foot {
        padding: 0 18px 16px;
        font-size: 12px;
        color: #0f766e;
        font-weight: 600;
    }

    .dashboard-month-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 14px;
    }

    .dashboard-month-tile {
        border-radius: 12px;
        padding: 14px 14px 12px;
        min-height: 170px;
        border: 1px solid transparent;
    }

    .dashboard-month-name {
        font-size: 22px;
        line-height: 1;
        font-weight: 800;
        color: #24324b;
        margin-bottom: 8px;
        text-transform: uppercase;
    }

    .dashboard-month-events {
        list-style: disc;
        padding-left: 18px;
        margin: 0;
    }

    .dashboard-month-events li {
        margin-bottom: 6px;
        color: #364152;
        font-size: 13px;
        line-height: 1.25;
    }

    .dashboard-month-events .dashboard-calendar-event-link {
        font-size: 13px;
    }

    .dashboard-month-empty {
        font-size: 12px;
        color: #6b7280;
        margin-top: 12px;
    }

    @media (max-width: 1199px) {
        .dashboard-month-grid {
            grid-template-columns: repeat(3, minmax(0, 1fr));
        }
    }

    @media (max-width: 767px) {
        .dashboard-month-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
    }
</style>

<div class="section-body">
<div class="container-fluid">
<div class="d-flex justify-content-between align-items-center">
    <div class="header-action">
        <h1 class="page-title">Dashboard</h1>
        <ol class="breadcrumb page-breadcrumb">
            <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <?php if(session()->get('db_id')==17){?>
                           <li class="breadcrumb-item"><a class="nav-link" href="#">Hospital</a></li>
                        <?php
                    }else{
                    ?>
                     <li class="breadcrumb-item"><a class="nav-link" href="#">School</a></li>
                    <?php
                }?>
            <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
        </ol>
    </div>
    <ul class="nav nav-tabs page-header-tab">
        <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#admin-Dashboard">Dashboard</a></li>
    </ul>
</div>
</div>
</div>
<div class="section-body mt-4">
<div class="container-fluid">
    
<div class="row clearfix row-deck">
                       
    <div id="load_content" class="col-md-9">
  </div> 

  <!-- <div class="col">
  </div> -->

    <div class="col-md-3 pull-right">
        <div class="dashboard-side-stack">
            <div class="card h-50 d-flex flex-column">
                <div class="card-body ribbon flex-grow-1">
                    <button class="btn btn-outline-success" type="button" id="button-year">
                        <span>
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                        </span>
                    </button>
                </div>
            </div>

            <div id="dashboardCalendarWidgetWrap">
                <?= view('templates/dashboard_school_calendar_widget', [
                    'dashboard_calendar_months' => $dashboard_calendar_months ?? [],
                    'dashboard_current_month' => $dashboard_current_month ?? null,
                    'dashboard_calendar_year' => $dashboard_calendar_year ?? (int) date('Y'),
                ]); ?>
            </div>
        </div>
    </div>

</div>

<div class="modal fade" id="dashboardCalendarEventModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">School Calendar Event Details</h5>
                <button type="button" class="close" id="closeDashboardCalendarEventModal" data-dismiss="modal" data-bs-dismiss="modal" aria-label="Close" onclick="$('#dashboardCalendarEventModal').modal('hide');">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="dashboardCalendarEventContent"><span class="fa fa-spinner fa-spin"></span> Loading...</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="closeDashboardCalendarEventModalFooter" data-dismiss="modal" data-bs-dismiss="modal" onclick="$('#dashboardCalendarEventModal').modal('hide');">Close</button>
            </div>
        </div>
    </div>
</div>



          <?php }?>

          <script type="text/javascript">
        function showDashboardCalendarEvent(eventId) {
            $('#dashboardCalendarEventContent').html('<span class="fa fa-spinner fa-spin"></span> Loading...');
            $('#dashboardCalendarEventModal').modal('show');

            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/view_school_calendar'; ?>',
                data: {id: eventId},
                success: function(res){
                    $('#dashboardCalendarEventContent').html(res);
                },
                error: function(){
                    $('#dashboardCalendarEventContent').html('<div class="alert alert-danger mb-0">Sorry! Failed to load event details.</div>');
                }
            });
        }

        function loadDashboardCalendar(year) {
            $('#dashboardCalendarWidgetWrap').html('<div class="card"><div class="card-body text-center"><span class="fa fa-spinner fa-spin"></span> Loading school calendar...</div></div>');

            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/dashboard_school_calendar_widget'; ?>',
                data: {year: year},
                success: function(res){
                    $('#dashboardCalendarWidgetWrap').html(res);
                },
                error: function(){
                    $('#dashboardCalendarWidgetWrap').html('<div class="alert alert-warning mb-0">Failed to load school calendar widget.</div>');
                }
            });
        }
              
        $(function () {
        const currentYear = new Date().getFullYear();  
         $('#button-year').yearpicker({
            year:currentYear,
           startYear:2022,
           endYear:currentYear+1,
            
         });
         $('#load_content').load('index.php/CompanyController/load_content_view/'+currentYear);
         loadDashboardCalendar(currentYear);
        
          });

         $("#button-year").change(function(){
    
         var  year=$('#button-year').html();
            // alert(year);
       $('#load_content').load('index.php/CompanyController/load_content_view/'+year);
       loadDashboardCalendar(year);
    });

    $(document).on('click', '.dashboardEventDetails', function(){
        var eventId = $(this).data('id');
        var $monthsModal = $('#dashboardCalendarMonthsModal');

        if ($monthsModal.hasClass('show')) {
            $monthsModal.modal('hide');
            setTimeout(function () {
                showDashboardCalendarEvent(eventId);
            }, 250);
            return;
        }

        showDashboardCalendarEvent(eventId);
    });

    $('#dashboardCalendarEventModal').on('hidden.bs.modal', function(){
        $('#dashboardCalendarEventContent').html('<span class="fa fa-spinner fa-spin"></span> Loading...');
    });

    $(document).on('click', '#closeDashboardCalendarEventModal, #closeDashboardCalendarEventModalFooter', function (e) {
        e.preventDefault();
        $('#dashboardCalendarEventModal').modal('hide');
    });
          </script>
