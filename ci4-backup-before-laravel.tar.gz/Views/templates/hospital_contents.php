  
<?php
$studentModel = new App\Models\studentModel();
$lmodel = new App\Models\LoginModel();
    $staffModel = new App\Models\StaffModel();
    $imodel = new App\Models\ItemsModel();
   
   //echo $year;
    $staff = $staffModel->get_total_staffs('users',$where = array('status' => 1,'staff' => 1));
    $room = $staffModel->get_total_user('classes_tbl','id',$where = array('status' => 1));
    $trans = $staffModel->get_total_user('vehicles_tbl','id',$where = array('status' => 1));
    $accnt = $imodel->get_total_accounts('accounts_tbl','id',$year);
    $app = $imodel->get_total_application('students_application_tbl','id',$year);
    $stdnt = $staffModel->get_total_students();
    $tapp = $imodel->get_total_admission('admission_tbl','id',$year);
    $tpar =$staffModel->get_total_user('parents_tbl','id',$where = array('bill_account' => 0));

$absconds = $staffModel->gettable_data_groupby('absconding_tbl',$where = array('absconded_year' => $year));
$graduats = $studentModel->gettable_data('graduation_tbl',$where = array('graduation_year' => $year));

$transfered = $staffModel->gettable_data_groupby('transfered_students_tbl',$where = array('academic_year' => $year));
$noshow = $staffModel->gettable_data_groupby('student_not_show_tbl',$where = array('academic_year' => $year));

$active= $tapp[0]->id-(count($absconds)+count($transfered)+count($noshow));
// echo $tactive.'/'.$active.'/'.$i;
?>

<style type="text/css">
   /* styles.css */
#blinking-background {
    padding: 8px;
    font-size: 15px;
    text-align: center;
    background-color: yellow;
    animation: blink-bg 1s infinite;
    position: relative;
    border: 10px solid transparent; /* Space for the zigzag border */
    background-clip: padding-box; /* Ensures background color is not affected by the border */

}

@keyframes blink-bg {
    0% {
        background-color: yellow;
    }
    50% {
        background-color: red;
    }
    100% {
        background-color: yellow;
    }
}

/* Zigzag border using SVG */
#blinking-background::before {
     content: '';
    position: absolute;
    top: -10px; /* Adjust based on border width */
    left: -10px; /* Adjust based on border width */
    right: -10px; /* Adjust based on border width */
    bottom: -10px; /* Adjust based on border width */
    background: repeating-linear-gradient(
        45deg,
        #007BFF,
        #007BFF 10px,
        transparent 10px,
        transparent 20px
    );
    z-index: -1;
}

/*
    position: relative;
    width: 30px;
    height: 30px;
    padding: 15px;
    font-size: 15px;
    text-align: center;
    background-color: yellow;
    animation: blink-bg 1s infinite;
    clip-path: polygon(
        50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 
        50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%
    );
    border: 10px solid transparent;
    background-clip: padding-box;
*/

</style>
<div class="row clearfix row-deck col-md-12">

                    
    <div class="col-6 col-md-4 col-xl-3">
        <div class="card h-80 d-flex flex-column">
            <div class="card-body ribbon">
                <div class="ribbon-box orange" data-toggle="tooltip" title="Staffs"><?= count($staff); ?></div>
                  <a href="<?php
                  if(count($staff) >0){
                 echo base_url('employee');
         }else{
            echo "#";
         }
         ?>" class="nav-link my_sort_cut text-muted">
                    <i class="fa fa-users"></i>
                    <span>Staffs</span>
                </a>
            </div>
        </div>
    </div>

    </div>