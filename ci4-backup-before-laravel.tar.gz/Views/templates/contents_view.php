  
<?php

$studentModel = new App\Models\studentModel();
$lmodel = new App\Models\LoginModel();
    $staffModel = new App\Models\StaffModel();
    $imodel = new App\Models\ItemsModel();
   
   //echo $year;
    $staff = $staffModel->get_total_user('users','user_id',$where = array('status' => 1));
    $room = $staffModel->get_total_user('classes_tbl','id',$where = array('status' => 1));
    $trans = $staffModel->get_total_user('vehicles_tbl','id',$where = array('status' => 1));
    $accnt = $imodel->get_total_accounts('accounts_tbl','id',$year);
    $app = $imodel->get_total_application('students_application_tbl','id',$year);
    $stdnt = $staffModel->get_total_students();
    $tapp = $imodel->get_total_admission('admission_tbl','id',$year);
    $tpar =$staffModel->get_total_user('parents_tbl','id',$where = array('bill_account' => 0));

$absconds = $staffModel->gettable_data_groupby('absconding_tbl',$where = array('absconded_year' => $year));
$graduats = $studentModel->gettable_data('graduation_tbl',$where = array('graduation_year' => $year));

$transfered = $staffModel->gettable_data_groupby('transfered_students_tbl',$where = array('academic_year' => $year));
$noshow = $staffModel->gettable_data_groupby('student_not_show_tbl',$where = array('academic_year' => $year));

$active= $tapp[0]->id-(count($absconds)+count($transfered)+count($noshow));
// echo $tactive.'/'.$active.'/'.$i;
?>

<style type="text/css">
   /* styles.css */
#blinking-background {
    padding: 8px;
    font-size: 15px;
    text-align: center;
    background-color: yellow;
    animation: blink-bg 1s infinite;
    position: relative;
    border: 10px solid transparent; /* Space for the zigzag border */
    background-clip: padding-box; /* Ensures background color is not affected by the border */

}

@keyframes blink-bg {
    0% {
        background-color: yellow;
    }
    50% {
        background-color: red;
    }
    100% {
        background-color: yellow;
    }
}

/* Zigzag border using SVG */
   #blinking-background::before {
     content: '';
    position: absolute;
    top: -10px; /* Adjust based on border width */
    left: -10px; /* Adjust based on border width */
    right: -10px; /* Adjust based on border width */
    bottom: -10px; /* Adjust based on border width */
    background: repeating-linear-gradient(
        45deg,
        #007BFF,
        #007BFF 10px,
        transparent 10px,
        transparent 20px
    );
    z-index: -1;
}

/*
    position: relative;
    width: 30px;
    height: 30px;
    padding: 15px;
    font-size: 15px;
    text-align: center;
    background-color: yellow;
    animation: blink-bg 1s infinite;
    clip-path: polygon(
        50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 
        50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%
    );
    border: 10px solid transparent;
    background-clip: padding-box;
*/

    .attendance-modern-card {
        border: 1px solid #e8eef7;
        border-radius: 8px;
        background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);
        box-shadow: 0 10px 24px rgba(15, 23, 42, 0.06);
        overflow: hidden;
        cursor: pointer;
        transition: transform .18s ease, box-shadow .18s ease;
    }
    .attendance-modern-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 14px 28px rgba(15, 23, 42, 0.1);
    }
    .attendance-modern-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 16px 18px 10px;
    }
    .attendance-modern-title {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: #1f2d3d;
    }
    .attendance-modern-subtitle {
        margin: 3px 0 0;
        font-size: 12px;
        color: #6b7280;
    }
    .attendance-modern-table {
        margin: 0;
        font-size: 13px;
        border-collapse: separate;
        border-spacing: 0;
    }
    .attendance-modern-table thead th {
        background: #f3f6fb;
        border-color: #e5eaf2;
        color: #475569;
        font-weight: 700;
        text-transform: uppercase;
        font-size: 11px;
        letter-spacing: .3px;
        padding: 9px 8px;
    }
    .attendance-modern-table tbody td,
    .attendance-modern-table tfoot th {
        border-color: #edf1f7;
        padding: 9px 8px;
        vertical-align: middle;
    }
    .attendance-modern-table tbody tr:hover {
        background: #f8fafc;
    }
    .attendance-modern-table tfoot th {
        background: #f8fafc;
        color: #1f2937;
    }
    .attendance-trend {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 58px;
        gap: 4px;
        border-radius: 999px;
        padding: 3px 8px;
        font-size: 12px;
        font-weight: 700;
    }
    .attendance-trend-up {
        background: #dcfce7;
        color: #15803d;
    }
    .attendance-trend-down {
        background: #fee2e2;
        color: #b91c1c;
    }
    .attendance-trend-same {
        background: #e0f2fe;
        color: #0369a1;
    }
    .attendance-flag-ok {
        background: #16a34a;
        color: #fff;
        border-radius: 999px;
        padding: 5px 10px;
        font-size: 12px;
        font-weight: 700;
    }
    .attendance-total-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
        padding: 0 18px 18px;
    }
    .attendance-total-tile {
        border-radius: 8px;
        padding: 12px 12px;
        border: 1px solid #e5eaf2;
        background: #fff;
        min-width: 0;
    }
    .attendance-total-classes {
        grid-column: 1 / -1;
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: #f8fafc;
        border-top: 4px solid #2563eb;
    }
    .attendance-total-label {
        font-size: 13px;
        letter-spacing: 0;
        color: #64748b;
        font-weight: 700;
        line-height: 1.2;
        white-space: nowrap;
    }
    .attendance-total-value {
        margin-top: 6px;
        font-size: 30px;
        line-height: 1;
        font-weight: 800;
        color: #1f2937;
        word-break: normal;
    }
    .attendance-total-classes .attendance-total-value {
        margin-top: 0;
    }
    .attendance-total-present {
        border-top: 4px solid #16a34a;
    }
    .attendance-total-absent {
        border-top: 4px solid #dc2626;
    }
    .attendance-total-late {
        border-top: 4px solid #f59e0b;
    }
    .attendance-total-total {
        border-top: 4px solid #475569;
    }
</style>
<div class="row clearfix row-deck col-md-12">
  <div class="col-6 col-md-4 col-xl-3">
       <div class="card h-80 d-flex flex-column">
            <div class="card-body ribbon">
                <div class="ribbon-box orange" data-toggle="tooltip" title="Total Application"><?= $app[0]->id; ?></div>
                <a href="<?php
                  if($app[0]->id >0){
                 echo base_url('index.php/StudentController/applications_summary/'.$year);
         }else{
            echo "#";
         }
         ?>" class="nav-link my_sort_cut text-muted">
                    <i class="fa fa-users"></i>
                    <span>Application</span>
                </a>
            </div>
        </div>
    </div>

     <div class="col-6 col-md-4 col-xl-3">
        <div class="card h-80 d-flex flex-column">
            <div class="card-body ribbon"> <div class="pull-right" id="blinking-background"><?= $active; ?><br>Active</div>
                <div class="ribbon-box orange" data-toggle="tooltip" title="Admission"><?= $tapp[0]->id; ?></div>
                <a href="<?php
                  if($tapp[0]->id >0){
                 // echo base_url('index.php/AdmissionController/admission_dash/'.$year);
                echo base_url('student_admissions_dashboard/'.$year);
         }else{
            echo "#";
         }
         ?>" class="nav-link my_sort_cut text-muted">
                    <i class="fa fa-users"></i>
                    <span>Admission</span>
                </a>

            </div>
        </div>
    </div>
                        
    <div class="col-6 col-md-4 col-xl-3">
        <div class="card h-80 d-flex flex-column">
            <div class="card-body ribbon">
                <div class="ribbon-box orange" data-toggle="tooltip" title="Absconds"><?= count($absconds); ?></div>
                  <a href="<?php
                  if(count($absconds) >0){
                 echo base_url('student_absconds/'.$year);
         }else{
            echo "#";
         }
         ?>" class="nav-link my_sort_cut text-muted">
                    <i class="fa fa-users"></i>
                    <span>Absconds</span>
                </a>
            </div>
        </div>
    </div>
     <div class="col-6 col-md-4 col-xl-3">
        <div class="card h-80 d-flex flex-column">
            <div class="card-body ribbon">
                <div class="ribbon-box orange" data-toggle="tooltip" title="Graduates"><?= count($graduats); ?></div>
                  <a href="<?php
                  if(count($graduats) >0){
                 echo base_url('student_graduants/'.$year);
         }else{
            echo "#";
         }
         ?>" class="nav-link my_sort_cut text-muted">
                    <i class="fa fa-users"></i>
                    <span>Graduates</span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card h-80 d-flex flex-column">
            <div class="card-body ribbon">
          <div class="ribbon-box orange" data-toggle="tooltip" title="Parents"><?= $tpar[0]->id; ?></div>
                <a href="<?php
                  if($tpar[0]->id >0){
                 echo base_url('parents_dashboard/'.$year);
         }else{
            echo "#";
         }
         ?>" class="nav-link my_sort_cut text-muted">
                    <i class="fa fa-book"></i>
                    <span>Parents</span>
                </a>
            </div>
        </div>
    </div>

     <div class="col-6 col-md-4 col-xl-3">
        <div class="card h-80 d-flex flex-column">
            <div class="card-body ribbon">
                <div class="ribbon-box orange" data-toggle="tooltip" title="transfered"><?= count($transfered); ?></div>
                  <a href="<?php
                  if(count($transfered) >0){
                 echo base_url('student_transfered/'.$year);
         }else{
            echo "#";
         }
         ?>" class="nav-link my_sort_cut text-muted">
                    <i class="fa fa-users"></i>
                    <span>Transfered</span>
                </a>
            </div>
        </div>
    </div>

     <div class="col-6 col-md-4 col-xl-3">
        <div class="card h-80 d-flex flex-column">
            <div class="card-body ribbon">
                <div class="ribbon-box orange" data-toggle="tooltip" title="No show"><?= count($noshow); ?></div>
                  <a href="<?php
                  if(count($noshow) >0){
                 echo base_url('student_noshow/'.$year);
         }else{
            echo "#";
         }
         ?>" class="nav-link my_sort_cut text-muted">
                    <i class="fa fa-users"></i>
                    <span>No Show</span>
                </a>
            </div>
        </div>
    </div>

<div class="col-6 col-md-4 col-xl-3">
        <div class="card h-80 d-flex flex-column">
            <div class="card-body ribbon">
                <?php
               $sms_balance = $studentModel->gettable_data('messages_balances',$where = array('balance !=' => ""));
                ?>
                <!-- <div class="ribbon-box " data-toggle="tooltip" title="sms balance"></div> -->
                <div class="text-center text-black">
                   Tsh. <?php 
                   if(count($sms_balance)>0){
                   echo number_format($sms_balance[0]->balance); 
                   }else{
                 echo 0;
                   }
                    ?>
                </div>
                
                  <a href="<?php
                 if(count($sms_balance)>0){
                 echo "#";
         }else{
            echo "#";
         }
         ?>" class="nav-link my_sort_cut text-muted">
                    <i class="fa fa-usd"></i>
                    <span>Sms Balance</span>
                </a>
            </div>
        </div>
    </div>

     <div class="col-6 col-md-4 col-xl-3">
        <div class="card h-80 d-flex flex-column">
            <div class="card-body ribbon">
                    <div class="ribbon-box orange" data-toggle="tooltip" title="Today Cash">
                        <a href="#"><span class="fa fa-refresh text-white" onclick="calculate_amount()"> </span></a>
                    </div>
               <div class="text-center text-black">
                    <div id="collected">Tsh. </div>
                    <?php //echo $ttl_collected; ?>
                </div>
                
                  <a href=" <?php echo base_url('today_collection');?>" class="nav-link my_sort_cut text-muted">
                    <i class="fa fa-usd"></i>
                    <span>Today Cash</span>
                </a>
            </div>
        </div>
    </div>

    <div class="col-6 col-md-4 col-xl-3">
        <div class="card h-80 d-flex flex-column">
            <div class="card-body ribbon">
                    <div class="ribbon-box orange" data-toggle="tooltip" title="Today Cash">
                        <a href="#"><span class="fa fa-refresh text-white" onclick="calculate_transport_overdue()"> </span></a>
                    </div>
               <div class="text-center text-black">
                    <div id="transportOverDue">Tsh. </div>
                    <?php 
                     ?>
                </div>
                
                  <a href=" <?php echo base_url('overdue_transport');?>" class="nav-link my_sort_cut text-muted">
                    <i class="fa fa-money"></i>
                    <span>Overdue Transport</span>
                </a>
            </div>
        </div>
    </div>

    <?php
        $attendanceSummary = $attendance_summary ?? [];
        $attendanceFlagCount = $attendance_flag_count ?? 0;
        $summaryTotals = ['classes' => 0, 'available' => 0, 'present' => 0, 'absent' => 0, 'late' => 0, 'total' => 0];
        foreach ($attendanceSummary as $row) {
            if ((int) $row['total'] > 0) {
                $summaryTotals['classes']++;
            }
            $summaryTotals['available'] += (int) $row['available'];
            $summaryTotals['present'] += (int) $row['present'];
            $summaryTotals['absent'] += (int) $row['absent'];
            $summaryTotals['late'] += (int) $row['late'];
            $summaryTotals['total'] += (int) $row['total'];
        }
    ?>
    <div class="col-12 col-md-4 col-xl-3">
        <div class="card h-80 d-flex flex-column attendance-modern-card" id="attendanceSummaryCard">
            <div class="attendance-modern-head">
                <div>
                    <h6 class="attendance-modern-title">Attendance Summary</h6>
                    <p class="attendance-modern-subtitle">Today totals</p>
                </div>
                <div>
                    <?php if($attendanceFlagCount > 0){ ?>
                        <button type="button" class="btn btn-sm btn-danger" id="attendanceFlagButton">
                            <?= $attendanceFlagCount; ?> Flagged
                        </button>
                    <?php } ?>
                </div>
            </div>
            <div class="attendance-total-grid">
                <div class="attendance-total-tile attendance-total-classes">
                    <div class="attendance-total-label">Number of Classes</div>
                    <div class="attendance-total-value"><?= $summaryTotals['classes']; ?></div>
                </div>
                <div class="attendance-total-tile attendance-total-present">
                    <div class="attendance-total-label">Present</div>
                    <div class="attendance-total-value"><?= $summaryTotals['present']; ?></div>
                </div>
                <div class="attendance-total-tile attendance-total-absent">
                    <div class="attendance-total-label">Absent</div>
                    <div class="attendance-total-value"><?= $summaryTotals['absent']; ?></div>
                </div>
                <div class="attendance-total-tile attendance-total-late">
                    <div class="attendance-total-label">Late</div>
                    <div class="attendance-total-value"><?= $summaryTotals['late']; ?></div>
                </div>
                <div class="attendance-total-tile attendance-total-total">
                    <div class="attendance-total-label">Total</div>
                    <div class="attendance-total-value"><?= $summaryTotals['total']; ?></div>
                </div>
            </div>
        </div>
    </div>

    </div>

    <div class="modal fade" id="attendanceFlagModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">30-Day Absent/Late Flags</h5>
                    <button type="button" class="close" data-dismiss="modal" data-bs-dismiss="modal" aria-label="Close" onclick="$('#attendanceFlagModal').modal('hide');">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="attendanceFlagModalBody">
                    <span class="fa fa-spinner fa-spin"></span> Loading...
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="attendanceSummaryModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Attendance Summary Details</h5>
                    <button type="button" class="close" data-dismiss="modal" data-bs-dismiss="modal" aria-label="Close" onclick="$('#attendanceSummaryModal').modal('hide');">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-sm mb-0 dashboard-attendance-summary attendance-modern-table">
                            <thead>
                                <tr>
                                    <th rowspan="2">CLASS</th>
                                    <th rowspan="2">AVAILABLE</th>
                                    <th colspan="4" class="text-center">ATTENDANCE</th>
                                    <th rowspan="2">TREND</th>
                                </tr>
                                <tr>
                                    <th>Present</th>
                                    <th>Absent</th>
                                    <th>Late</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($attendanceSummary as $row){ ?>
                                    <tr>
                                        <td><b><?= esc($row['class']); ?></b></td>
                                        <td class="text-center"><b><?= (int) $row['available']; ?></b></td>
                                        <td class="text-center"><?= (int) $row['present']; ?></td>
                                        <td class="text-center"><?= (int) $row['absent']; ?></td>
                                        <td class="text-center"><?= (int) $row['late']; ?></td>
                                        <td class="text-center"><b><?= (int) $row['total']; ?></b></td>
                                        <td class="text-center">
                                            <?php
                                                $trend = $row['trend'] ?? 'same';
                                                $trendValue = (int) ($row['trend_value'] ?? 0);
                                                $trendClass = $trend === 'up' ? 'attendance-trend-up' : ($trend === 'down' ? 'attendance-trend-down' : 'attendance-trend-same');
                                                $trendIcon = $trend === 'up' ? 'fa-arrow-up' : ($trend === 'down' ? 'fa-arrow-down' : 'fa-minus');
                                                $trendText = $trend === 'up' ? '+'.$trendValue : (string) $trendValue;
                                            ?>
                                            <span class="attendance-trend <?= $trendClass; ?>" title="Previous day present: <?= (int) ($row['previous_present'] ?? 0); ?>">
                                                <i class="fa <?= $trendIcon; ?>"></i> <?= $trendText; ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>TOTAL</th>
                                    <th class="text-center"><?= $summaryTotals['available']; ?></th>
                                    <th class="text-center"><?= $summaryTotals['present']; ?></th>
                                    <th class="text-center"><?= $summaryTotals['absent']; ?></th>
                                    <th class="text-center"><?= $summaryTotals['late']; ?></th>
                                    <th class="text-center"><?= $summaryTotals['total']; ?></th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        calculate_amount();
        calculate_transport_overdue();

        $('#attendanceFlagButton').on('click', function(event){
            event.stopPropagation();
            $('#attendanceFlagModalBody').html('<span class="fa fa-spinner fa-spin"></span> Loading...');
            $('#attendanceFlagModal').modal('show');
            $.ajax({
                type: "GET",
                url: "<?= base_url('/dashboard_attendance_flag_list')?>",
                success: function(res){
                    $('#attendanceFlagModalBody').html(res);
                },
                error: function(){
                    $('#attendanceFlagModalBody').html('<div class="alert alert-warning mb-0">Failed to load flagged students.</div>');
                }
            });
        });

        $('#attendanceSummaryCard').on('click', function(){
            $('#attendanceSummaryModal').modal('show');
        });

        function calculate_amount(){
            
       $.ajax({
            type: "POST",
            url: "<?= base_url('/index.php/ReportsController/total_cash_colected')?>",
            beforeSend: function () {
               $('#collected').html('<i class="fa fa-spinner fa-spin"></i>');
            },
            success: function(res){
                $('#collected').html('Tsh. '+res);
                 
            },
            error: function ()
            {
            // toastr.error("Sory! Something went wrong!");
            }
        });
        }

           function calculate_transport_overdue(){
            
       $.ajax({
            type: "POST",
            url: "<?= base_url('/index.php/TransportController/total_overdue_transport')?>",
            beforeSend: function () {
               $('#transportOverDue').html('<i class="fa fa-spinner fa-spin"></i>');
            },
            success: function(res){
                $('#transportOverDue').html('Tsh. '+res);
                 
            },
            error: function ()
            {
            // toastr.error("Sory! Something went wrong!");
            }
        });
        }
    </script>
