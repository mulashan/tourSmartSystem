<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?php echo base_url('public/favicon1.ico')?>" type="image/x-icon"/>
    <title>:: Elimu Connect ::</title>
     <link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/bootstrap-5.0.2-dist/css/bootstrap.min.css')?>" /> 
 <link rel="stylesheet" href="<?php echo base_url('public/assets/css/style.min.css')?>"/>
 <script src="<?php echo base_url('public/assets/plugins/jquery/jquery-3.4.1.min.js')?>"></script>

   
</head>

<script>
        function getRedirectValue() {
            let url = new URL(window.location.href);
            return url.searchParams.get("redirect");
        }

        window.onload = function() {
            let redirectValue = getRedirectValue();
            console.log("Redirect value:", redirectValue);

            // Example: Redirect the user if the redirect parameter is present
            if (redirectValue) {
               document.getElementById('redirect').value = redirectValue;
                //window.location.href = redirectValue;
            }
        };
    </script>
   
<body>
    <div class="login-container">
        <div class="row">
            
            <div class="col-lg 12 col-md-12 col-sm-12">
                <div class=" d-flex justify-content-center" style="width:100%;height:100%;background:#f8f8f8">
                    <div id="dialog" class="position-absolute" >
                        <div class="d-flex aligns-items-center justify-content-center card text-center w-75 position-absolute top-50 start-50 translate-middle">
                            <div class="row g-0">
                                <!--<div class="col-md-5" style="background:#17a2b8;">-->
                                <!--    <img src="<?php echo base_url('public/assets/images/xs/books.jpg');?>" class="img-fluid rounded mt-5" alt="..." width="300" height="400">-->
                                <!--</div>-->
                                <div class="col-md-5" style="background:#17a2b8;">
                                       <!--<div class="row text-light mt-3"><b>WE ARE BACK</b></div>-->
                                       <img src="<?php echo base_url('public/assets/images/xs/books.jpg');?>" class="img-fluid rounded mt-2" alt="..." width="300" height="400">
                                    
                                    
                                </div>
                                 
                                <div class="col-md-7">
                                    <div class="card-body">
                                        <div class="card-title d-flex justify-content-center">
                                            <div class="user"></div>
                                        </div>
                                        <h5 class="card-text mb-3">eCONNECT</h5>
                                       <?php if(session()->getTempdata('error')){ ?>
                                         <div class="row mb-2">
                                                <div class="col-md-1"></div>
                                                <div class="col-md-10">
                                                <div class="alert alert-warning" role="alert">
                                                  <?= session()->getTempdata('error'); ?>
                                                 </div>
                                           </div>
                                         </div>
                                       <?php }?>
                                        <form action="validate" method="post">   
                                         <input type="hidden" id="redirect" name="redirect" value="">                               
                                            <div class="row mb-3">
                                                <div class="col-md-1"></div>
                                                <div class="col-md-8 form-item">
                                                    <input type="text" class="form-control" placeholder="Username" name="username" id="username" autocomplete="off" required>
                                                    <label style="margin-left:350px" class="fa fa-user"></label>
                                                </div>
                                          </div>
                                        <!--<div class="form-group has-warning has-feedback">
                                           <div class="col-sm-10">
                                              <input type="text" class="form-control" name="username" id="inputWarning" placeholder="Username">
                                             <span class="glyphicon glyphicon-user form-control-feedback"></span>
                                            </div>
                                         </div>
                                          <br><br>
                                          <br>
                                         
                                          <div class="form-group has-warning has-feedback">
                                           <div class="col-sm-10">
                                              <input type="text" class="form-control" name="pswd" id="inputWarning" placeholder="Password">
                                             <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                                            </div>
                                         </div>-->
                                             <div class="row mb-3">
                                                <div class="col-md-1"></div>
                                                  <div class="col-md-8 form-item">
                                                    <input type="password" class="form-control" placeholder="Password" name="pswd" id="password" autocomplete="off" required>
                                                      <label style="margin-left:350px" class="fa fa-lock"></label>
                                                    <!--<label>Password</label>-->
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-5">
                                                 <a href="javascript:void(0)" onclick="check_privacy()">Privacy Policy</a>
                                                </div>
                                                <div class="col-md-4">
                                                   <button type="submit" class="btn btn-primary">Log In</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

 <!-- Modal to View All Customer Information -->

  <div class="modal fade" id="myviewModal" role="dialog">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
           <div class="card">
          <div id="content" class="card-body"></div>
        </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

<script src="<?php echo base_url('public/assets/plugins/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js')?>"></script>
<!-- <script src="<?php echo base_url('public/assets/plugins/jquery/jquery.min')?>"></script> -->
<script type="text/javascript">
    function check_privacy(){
     
        $('#myviewModal').modal('show');
        $('#content').load('load_privacy');
       
    }
</script>
