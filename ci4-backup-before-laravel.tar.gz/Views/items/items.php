
<?php 

    $itemmodel = new App\Models\ItemsModel();

    $ledger = $itemmodel->account_lists();
    $itypes = $itemmodel->getItemTypeList();
    $atype = $itemmodel->Get_Accounttypes_Listdetails();
    // $nme = $itemmodel->get_sub_account2($ityplist->sub_item_of);
     $amodel = new App\Models\AdmissionModel();
 $groups = $amodel->get_student_details('item_groups_types_tbl', $where = array('id !=' => 0));
?>

<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Items</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Items</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#items-all">Items List</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#items-add">New Item</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#items-all">Items List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#items-add">New Item</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="items-all">

                    <?php if(!empty(session()->getFlashdata('msg'))) : ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                          <strong>Saved !</strong> <?= session()->getFlashdata('msg'); ?>
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true"></span>
                          </button>
                        </div>
                    <?php endif ?>
                     <?php if(!empty(session()->getFlashdata('error'))) : ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                          <strong>error !</strong> <?= session()->getFlashdata('error'); ?>
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true"></span>
                          </button>
                        </div>
                    <?php endif ?>
                <div class="card">
                    <div class="table-responsive mt-3">
                        
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                    <th>No.#</th>
                                    <th>Item Name</th>
                                    <th>Type</th>
                                    <th>Attr</th>
                                    <th>Size</th>
                                    <th>use</th>
                                    <th>Sub Item of</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Updated By</th>
                                    <th>Updated Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $sn = 0;
                                    $sub = ""; 
                                    foreach ($ityplist as $ilist):
                                      $status= $ilist->item_status;
                                      if($status=1){
                                        $st="<span style='color:green'>Active</span>";
                                      }else{
                                        $st="<span style='color:red'>Inactive</span>";
                                      }
                                    $sn++;
                                    $group="";
                                      $sub = "-";
                                       if($ilist->sub_item_of >0){
                                    $data2 = $itemmodel->get_sub_account2($ilist->sub_item_of);
                                    
                                    if(count($data2)>0){
                                       $sub = $data2[0]->item_name; 
                                    }
                                   
                                     }

                                    $itmgrp = $itemmodel->get_selected_data('item_groups_types_tbl',$where=array('group_id'=>$ilist->item_group),$data=array('group_name'));
                                    if($ilist->item_group != ""){
                                    $group=$itmgrp[0]->group_name;
                                     }
                                   
                                ?>
                                    <tr>
                                        <td><?= $sn;?></td>
                                        <td><?= $ilist->item_name; ?></td>
                                        <td><?= $ilist->type_name; ?></td>
                                        <td><?= $ilist->item_attribute; ?></td>
                                        <td><?= $ilist->item_size; ?></td>
                                        <td><?= $group; ?></td>
                                        <td><?= $sub; ?></td>
                                        <td><?= number_format($ilist->item_price); ?></td>
                                        <td><?= $st; ?></td>
                                        <td><?= $ilist->first_name." ".$ilist->last_name; ?></td> 
                                        <td><?= $ilist->updated_date; ?></td> 
                                        <td>
                                            <button type="button" class="btn btn-primary btn-sm editBtn" data-id="<?= $ilist->id;?>"><i class="fa fa-edit"></i> Edit</button>
                                             <button type="button" class="btn btn-primary btn-sm viewBtn" data-id="<?= $ilist->id;?>"><i class="fa fa-eye"></i> View</button>
                                            <!-- <button type="button" class="btn btn-danger btn-sm remove"  data-id="<?php //echo $ilist->id;?>"><i class="fa fa-trash"></i></button> -->

                                        </td>
                                    </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="tab-pane" id="items-add">
                <div class="row clearfix">
                    <div class="card">
                        <div class="card-header" style="height:5px">
                            <h3 class="card-title">Items Information</h3>
                            <div class="card-options ">
                                <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                            </div>
                        </div>
                        <hr>
                        <div class="card-body">
                            <form action="addItem" method="post" class="card-body form-horizontal" id="ItemForm">
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Item Name <span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <input type="text" name="iname" id="iname" class="form-control form-control-sm" placeholder="Item Name" required="required">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Item Type <span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <select id="i_typ" name="i_typ" onchange="Showatypes(this)" class="form-select me-4 form-control form-control-sm" required="required">
                                            <option selected>--Choose type--</option>
                                            <?php foreach ($itypes as $type): ?>
                                                <option value="<?php echo $type->id;?>"><?php echo $type->type_name;?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Item Size</label>
                                    <div class="col-md-7">
                                        <input type="text" name="isize" id="isize" class="form-control form-control-sm" placeholder="Item Size">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Item Attribute</label>
                                    <div class="col-md-7">
                                        <input type="text" name="iattr" id="iattr" class="form-control form-control-sm" placeholder="Item Attribute">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Item Price <span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <input type="text" name="iprice" id="iprice" class="form-control form-control-sm" placeholder="Item Price" required="required">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Item Use <span class="text-danger">*</span></label>
                                  <div class="col-md-7">
                                        <select id="igroup" name="igroup" class="form-select me-4 form-control form-control-sm" required="required">
                                            <option selected>--Select item use--</option>
                                               <?php foreach ($groups as $type): ?>
                                                <option value="<?php echo $type->group_id;?>"><?php echo $type->group_name;?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Sub Item of</label>
                                    <div class="col-md-7">
                                        <select id="icateg" name="icateg" class="form-select me-4 form-control form-control-sm">
                                            <option selected>--Select Sub-Item--</option>
                                            <!-- <?php //foreach ($ledger as $lg): ?>
                                                <option value="<?php //echo $lg->id;?>"><?php //echo $lg->item_name;?></option>
                                            <?php //endforeach ?> -->
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row" id="hidDiv" style="display:none;">
                                    <label class="col-md-3 col-form-label">Current Asset Ledger<span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <select  id="casset" name="account[]" class="form-select me-4 form-control form-control-sm">
                                            <option value="">Choose Ledger</option>
                                            <?php foreach ($atype as $act): if($act->account_type_id == 2){ ?>

                                                <option value="<?php echo $act->id;?>"><?php echo $act->account_name;?></option>
                                            <?php } endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row" id="hidDiv1" style="display:none;">
                                    <label class="col-md-3 col-form-label">Sales Ledger<span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <select  id="sledger" name="account[]" class="form-select me-4 form-control form-control-sm">
                                            <option value="">Choose Ledger</option>
                                            <?php foreach ($atype as $act): if($act->account_type_id == 3){ ?>
                                                <option value="<?php echo $act->id;?>"><?php echo $act->account_name;?></option>
                                            <?php } endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row" id="hidDiv2" style="display:none;">
                                    <label class="col-md-3 col-form-label">COGS Ledger<span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <select  id="cledger" name="account[]" class="form-select me-4 form-control form-control-sm">
                                            <option value="">Choose Ledger</option>
                                            <?php foreach ($atype as $act): if($act->account_type_id == 5){ ?>
                                                <option value="<?php echo $act->id;?>"><?php echo $act->account_name;?></option>
                                            <?php } endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row" id="hidDiv3" style="display:none;">
                                    <label class="col-md-3 col-form-label">Other Income Ledger<span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <select  id="otheri" name="account[]" class="form-select me-4 form-control form-control-sm">
                                            <option value="">Choose Ledger</option>
                                            <?php foreach ($atype as $act): if($act->account_type_id == 4){ ?>
                                                <option value="<?php echo $act->id;?>"><?php echo $act->account_name;?></option>
                                            <?php } endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row" id="hidDiv4" style="display:none;">
                                    <label class="col-md-3 col-form-label">Fixed Asset Ledger<span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <select  id="fasset" name="account[]" class="form-select me-4 form-control form-control-sm">
                                            <option value="">Choose Ledger</option>
                                            <?php foreach ($atype as $act): if($act->account_type_id == 1){ ?>
                                                <option value="<?php echo $act->id;?>"><?php echo $act->account_name;?></option>
                                            <?php } endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row" id="hidDiv5" style="display:none;">
                                    <label class="col-md-3 col-form-label">Account Receivable<span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <select  id="receivable" name="account[]" class="form-select me-4 form-control form-control-sm">
                                            <option value="">Choose Ledger</option>
                                            <?php foreach ($atype as $act): if($act->account_type_id == 7){ ?>
                                                <option value="<?php echo $act->id;?>"><?php echo $act->account_name;?></option>
                                            <?php } endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                 <div class="form-group row" id="hidDiv6" style="display:none;">
                                    <label class="col-md-3 col-form-label">Other Liabilities</label>
                                    <div class="col-md-7">
                                        <select  id="receivable" name="account[]" class="form-select me-4 form-control form-control-sm">
                                            <option value="">Choose Ledger</option>
                                            <?php foreach ($atype as $act): if($act->account_type_id == 13){ ?>
                                                <option value="<?php echo $act->id;?>"><?php echo $act->account_name;?></option>
                                            <?php } endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                  <div class="form-group row" id="hidDiv7" style="display:none;">
                                    <label class="col-md-3 col-form-label">Equity Ledger<span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <select  id="receivable" name="account[]" class="form-select me-4 form-control form-control-sm">
                                            <option value="">Choose Ledger</option>
                                            <?php foreach ($atype as $act): if($act->account_type_id == 8){ ?>
                                                <option value="<?php echo $act->id;?>"><?php echo $act->account_name;?></option>
                                            <?php } endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label"></label>
                                    <div class="col-md-7">
                                        <button type="submit" class="btn btn-outline-secondary">Cancel</button>
                                        <button type="submit" class="btn btn-primary float-right">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ----edit item modal---- -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Update Item</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="UpdteItem"></div>
        </div>
      </div>
      
    </div>
</div>
<!-- ----view item modal---- -->
<div class="modal fade" id="viewModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="viewItem"></div>
        </div>
      </div>
      
    </div>
</div>

<script type="text/javascript">

    function Showatypes(id)
    {
        if(id){
            var data = id.value;
            // alert(data)
            if(data == 1){
                $("#hidDiv").show();
                $("#hidDiv1").show();
                $("#hidDiv2").show();
                $("#hidDiv3").hide();
                $("#hidDiv4").hide();
                $("#hidDiv5").hide();
                 $("#hidDiv6").hide();
            }
            else if(data == 2){
                $("#hidDiv").hide();
                $("#hidDiv1").show();
                $("#hidDiv2").hide();
                $("#hidDiv3").hide();
                $("#hidDiv4").hide();
                $("#hidDiv5").hide();
                 $("#hidDiv6").hide();
            }
            else if(data == 3){
                $("#hidDiv").hide();
                $("#hidDiv1").hide();
                $("#hidDiv2").hide();
                $("#hidDiv3").show();
                $("#hidDiv4").hide();
                $("#hidDiv5").hide();
                 $("#hidDiv6").hide();
            }
            else if(data == 4){
                $("#hidDiv").hide();
                $("#hidDiv1").show();
                $("#hidDiv2").hide();
                $("#hidDiv3").show();
                $("#hidDiv4").hide();
                $("#hidDiv5").hide();
                 $("#hidDiv6").hide();
            }
            else if(data == 5){
                $("#hidDiv").hide();
                $("#hidDiv1").hide();
                $("#hidDiv2").hide();
                $("#hidDiv3").hide();
                $("#hidDiv4").show();
                $("#hidDiv5").hide();
                 $("#hidDiv6").hide();
            }
            else if(data == 6){
                $("#hidDiv").hide();
                $("#hidDiv1").hide();
                $("#hidDiv2").hide();
                $("#hidDiv3").hide();
                $("#hidDiv4").hide();
                $("#hidDiv5").show();
                 $("#hidDiv6").hide();
            }
             else if(data == 8){
                $("#hidDiv").hide();
                $("#hidDiv1").hide();
                $("#hidDiv2").hide();
                $("#hidDiv3").hide();
                $("#hidDiv4").hide();
                 $("#hidDiv5").hide();
                $("#hidDiv6").show();
            }
            else if(data == 9){
                $("#hidDiv").hide();
                $("#hidDiv1").hide();
                $("#hidDiv2").hide();
                $("#hidDiv3").hide();
                $("#hidDiv4").hide();
                 $("#hidDiv5").hide();
                 $("#hidDiv6").hide();
                $("#hidDiv7").show();
            }
            else{
                $("#hidDiv").hide();
                $("#hidDiv1").hide();
                $("#hidDiv2").hide();
                $("#hidDiv3").hide();
                $("#hidDiv4").hide();
                $("#hidDiv5").hide();
                 $("#hidDiv6").hide();
            }
        }
        else{
            $("#hidDiv").hide();
            $("#hidDiv1").hide();
            $("#hidDiv2").hide();
            $("#hidDiv3").hide();
            $("#hidDiv4").hide();
            $("#hidDiv5").hide();
             $("#hidDiv6").hide();
        }

        get_itemsDue_toItemtypes();
    }

    function get_itemsDue_toItemtypes(){
        var selectOption = '';
        var data = 'id=' + $('#i_typ').val();
        // alert(data);

        $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/ItemsController/fetch_subitems'; ?>',
            dataType: 'json',
            success:function(response){
                console.log(response);

                var len = response.length;
                $("#icateg").empty();
                $("#icateg").append("<option value=''>-Select Sub-Item-</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var item_name = response[i]['name'];
                    var attribute = response[i]['attr'];
                    var size = response[i]['size'];

                    selectOption = "<option value='"+id+"'>"+"\xa0"+'Name:'+item_name+"\xa0\xa0\xa0\xa0"+'Attribute:'+"\xa0"+attribute+"\xa0\xa0\xa0\xa0"+'Size:'+"\xa0"+size+"</option>";
                    $("#icateg").append(selectOption);
                }
            }
        });
    }
 $(".editBtn").click(function () {
        var data = 'id=' + $(this).attr('data-id');
        $('#myModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?= base_url('/edit_item')?>",
            data: data,
            beforSend: function()
            {
                $('#UpdteItem').html();
            },
            success: function(res){
                $('#UpdteItem').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
    $(".viewBtn").click(function () {
        var data = 'id=' + $(this).attr('data-id');
        $('#viewModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?= base_url('/view_item')?>",
            data: data,
            beforSend: function()
            {
                $('#viewItem').html();
            },
            success: function(res){
                $('#viewItem').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });


    $(".remove").click(function(){

        var id = $(this).attr('data-id');


           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this Item!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/item_dlt')?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      // $("#"+id).remove();
                    swal("Deleted!", "Item has been deleted.", "success");

                    // location.reload();
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                      
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });

</script>