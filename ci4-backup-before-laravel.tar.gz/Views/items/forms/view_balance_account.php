                                    <?php  
                                    $imodel = new App\Models\ItemsModel();

                                     $amodel = new App\Models\AdmissionModel();
                                     ?>
                                    <?php 
                                      $cname = $imodel->get_account($id);

                                    foreach($cname as $le){
                                       $name=$le->account_name;
                                     }
                                     $cmp = $amodel->get_student_details('company_tbl', $where = array('created_by >' => 0));
                                    ?>
                <div id="printcashdtls">
                <center>

                  <h5><?php echo $cmp[0]->company_name;?></h5>
                  <h5><?php echo $name;?> List</h5>
                  <h5>Report Date: <?php echo date('d/m/Y',$thedate); ?> </h5>
                </center>
                                     <!--  <table>
                             <tr>
                                    
                              <th style="width: 400px;"><b>Ledger Name:<?php echo " ".$name; ?></b></th>  -
                              
                                <th colspan="12" style="padding-left: 250px;"> <input type="text" id="myInput"   onkeyup="myFunction()" class="form-control" placeholder="Search..." name="searchname">
                                  </th> 
                                </tr>
                                
                                     <th style="width:500px;">Ledger Code:<?php echo " ".$le->account_code;?></th> 
                                
                        </table><br> -->
                     <div class="card">
                      <!-- <input type="text" id="myInput"   onkeyup="myFunction()" class="form-control col-xs-5" placeholder="Search..." name="searchname" style="float:right;"> -->
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap att-list" id="myTable2">
                            <thead>
                               
                                <tr>

                                    <th>Trans Type</th>
                                     <th>Trans Date</th>
                                    <th>Trans No</th>
                                    <th>Trans Name</th>
                                   
                                    <th>Description</th>
                                    <th>Debit</th>
                                    <th>Credit</th>
                                    <th>Balance</th>
                                
                                </tr>
                            </thead>
                           <tbody>
                         <?php
                           $ttl1=0; 
                           $ttl2=0;
                           $balance=0; 
                            $students=array();
                          // print_r($ledger);
                           $i=0;
                           //echo count($ledger);
                            foreach($ledger as $ledge){
                             
                              if($ledge->name_type_id==1){
                            $std = $amodel->get_student_details('students', $where = array('id' => $ledge->name_id));
                             $fullname=$std[0]->full_name;
                             $nm=$ledge->name_id;
                              }elseif($ledge->name_type_id==5){
                                //echo $ledge->name_type_id;
                               $pad = $amodel->get_student_details('ledger_transaction_tbl', $where = array('trans_no' => $ledge->trans_no,'trans_type' => $ledge->trans_type,'name_type_id' => 1));
                              //  $stdpar = $amodel->get_student_details('parents_students_tbl', $where = array('parent_id' => $pad[0]->name_id));
                               if(count($pad)>0){
                               $std = $amodel->get_student_details('students', $where = array('id' => $pad[0]->name_id));
                             
                              
                              $fullname=$std[0]->full_name;
                              $nm=$std[0]->id;
                            }else{
                              //$fullname="";
                               $std = $amodel->get_student_details('students_application_tbl', $where = array('id' => $ledge->name_id));
                             $fullname=$std[0]->full_name;
                             $nm=$std[0]->id;
                              }
                            }elseif($ledge->name_type_id==4){
                             $std = $amodel->get_student_details('students_application_tbl', $where = array('id' => $ledge->name_id));
                             $fullname=$std[0]->full_name;
                             $nm=$std[0]->id;
                            }elseif($ledge->name_type_id==2){
                             $std = $amodel->get_student_details('supplier_tbl', $where = array('supplier_id' => $ledge->name_id));
                             $fullname=$std[0]->supplier_name;
                             $nm=$std[0]->id;
                            }elseif($ledge->name_type_id==6){
                             $std = $amodel->get_student_details('other_students_tbl', $where = array('id' => $ledge->name_id));
                             $fullname=$std[0]->full_name;
                             $nm=$std[0]->id;
                            }

                          if($i==0){
                            $t2=0;
                            $t1=0;
                          $n1=$nm;  
                          }

                          
                       if($i>0 && $n1==$nm){

                       }else{
                        if($i>0){
                          $bal=$t2-$t1;
                           $did=$n1;
                          if($bal==0){
                           
                            $students[]=array($n1);
                          }
                         $n1=$nm; 
                         ?>
                     <tr style="border-bottom: 3px solid black;" class="<?=$did?>">
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td><b>Sub Total</b></td>
                      <td class="text-center"><b><?= number_format($t2);?></b></td>
                      <td class="text-center"><b><?= number_format($t1);?></b></td>
                      <td class="text-center"><b><?= number_format($t2-$t1);?></b></td>
                      
                    </tr>
                         <?php
                       }
                        $t2=0;
                        $t1=0;
                     }
                       $i++;

                       if(($ledge->transation_nature==2 && $ledge->ledger_id!=21) || ($ledge->ledger_id==21 && $ledge->transation_nature==2 && $ledge->trans_item ==0)){
                                $ttl2=$ttl2+$ledge->amount;
                                $t2=$t2+$ledge->amount;
                                $balance=$balance+$ledge->amount;
                                $lm2= number_format($ledge->amount);
                               
                              }else{ 
                               $lm2= 0;
                              }

                                if(($ledge->transation_nature==1 && $ledge->ledger_id!=21) || ($ledge->ledger_id==21 && $ledge->transation_nature==1 && $ledge->trans_item>0)){
                                $ttl1=$ttl1+$ledge->amount;
                                $balance=$balance-$ledge->amount;
                               $lm1=  number_format($ledge->amount);
                               $t1=$t1+$ledge->amount;
                             }else{ 
                              $lm1= 0;
                            }
                            ?>
                          <tr class="<?=$n1;?>">
                           
                              <td class="text-center"><?= $ledge->type_name;?></td>
                              
                               <td class="text-center"><?= date('d-m-Y',strtotime($ledge->trans_date));?></td>
                              <td class="text-center"><?= $ledge->trans_no;?></td>
                              <td class="text-center"><?= $fullname;?></td>
                              <td class="text-center"><?= $ledge->description;?></td>
                              
                              <td class="text-center"><?php echo $lm2;?></td>
                             <td class="text-center"><?php echo $lm1;?></td>
                               <td class="text-center"><?= "";?></td>
                          
                          </tr>

                          <?php }?>
                          <?php 
                            if($i==count($ledger)){
                           $bal=$t2-$t1;
                           $did=$n1;
                          if($bal==0){
                           
                            $students[]=array($n1);
                          }
                              ?>
                      <tr style="border-bottom: 3px solid black;" class="<?=$n1;?>">
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td><b>Sub Total</b></td>
                      <td class="text-center"><b><?= number_format($t2);?></b></td>
                      <td class="text-center"><b><?= number_format($t1);?></b></td>
                      <td class="text-center"><b><?= number_format($t2-$t1);?></b></td>
                      
                    </tr>
                              <?php
                            }
                          ?>
                            <tr>

                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                               <td></td>
                              <td style="" class="text-center"><b>Total</b></td>
                              <td class="text-center"><b><?php echo number_format($ttl2); ?></b></td>
                              <td><b><?php echo number_format($ttl1); ?></b></td>
                              <td class="text-center"><b><?= number_format($balance);?></b></td>
                          </tr>                       
                           
    </tbody>
</table>
</div>
</div>
</div>
<center>
<!-- <button class="btn btn-primary btn-sm" onclick="printable_area('printcashdtls')"><span class="fa fa-print"></span> Print</button> -->
<button class="btn btn-success btn-sm col-sm-3" type="button" id="print_att"><i class="fa fa-print"></i> Print</button>
</center>
<noscript>
  <style>
    table.att-list{
      width:100%;
      border-collapse:collapse
    }
    table.att-list td,table.att-list th{
      border:1px solid
    }
    .text-center,.text-c{
      text-align:center
    }
    #myInput{
      display: none;
    }
  </style>
</noscript>
<script type="text/javascript">

$('#print_att').click(function(){
    var _c = $('#printcashdtls').html();
    var ns = $('noscript').clone();
    var nw = window.open('','_blank','width=1000,height=600')
    nw.document.write(_c)
    nw.document.write(ns.html())
    nw.document.close()
    nw.print()
    // setTimeout(() => {
    //  nw.close()
    // }, 500);
  })

var values=<?php echo json_encode($students);?>;
        //alert(values.length);
        //var rememberAll = document.getElementById("Allselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
            //alert(id);
              var rows = document.getElementsByClassName(id);
         for (var j = 0; j < rows.length; j++) {
        rows[j].style.display = 'none'; // Hide the rows with the specified class
          }
           }
</script>