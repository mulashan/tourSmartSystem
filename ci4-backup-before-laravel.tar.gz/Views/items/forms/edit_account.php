
<div id="updacc"></div>
<form id="updateAccount">
    <input type="hidden" class="form-control" name="idkl" id="idkl" value="<?= $accnts[0]->id;?>">
    <div class="form-group row">
        <label class="col-md-4 col-form-label">Ledger Name</label>
        <div class="col-md-7">
            <input type="text" name="acname" id="acname" value="<?= $accnts[0]->account_name;?>" class="form-control form-control-sm" placeholder="Ledger Name">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-4 col-form-label">Ledger Type</label>
        <div class="col-md-7">
            <select id="ac_type" name="ac_type" class="form-select me-4 form-control form-control-sm">
                <option selected>--Choose type--</option>
                <?php foreach ($atype as $act): ?>
                    <option value="<?php echo $act->id;?>" <?php if($accnts[0]->account_type_id == $act->id){ echo 'selected'; } ?>><?php echo $act->type_name;?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-4 col-form-label">Ledger Number</label>
        <div class="col-md-7">
            <input type="text" name="acno" id="acno" value="<?= $accnts[0]->account_code;?>" class="form-control form-control-sm" placeholder="Ledger Number">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-4 col-form-label">Description</label>
        <div class="col-md-7">
            <input type="text" name="descr" id="descr" value="<?= $accnts[0]->description;?>" class="form-control form-control-sm" placeholder="Description">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-4 col-form-label">Sub Ledger of</label>
        <div class="col-md-7">
            <select id="subacc" name="subacc" class="form-select me-4 form-control form-control-sm">
                <option selected>--Choose type--</option>
                <?php foreach ($accounts as $acct): ?>
                    <option value="<?php echo $acct->id;?>" <?php if($accnts[0]->sub_account == $acct->id){ echo 'selected'; } ?>><?php echo $acct->account_name;?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-4 col-form-label"></label>
        <div class="col-md-7">
            <button type="submit" class="btn btn-primary float-right">Update</button>

        </div>
    </div>
</form>

<script type="text/javascript">
    
    $('#updateAccount').submit(function (e) {
        $.ajax({
            type: 'POST',
            url: '<?= base_url('/updateData') ?>',
            data: $(this).serialize(),
            success: function (res) {
                $('#updacc').html(res);
                setTimeout(function(){
                     window.location.reload();
                },1000)
            },
            error: function () {
                $('#updacc').html('Error! Couldnt update Ledger.');            }
        });
        //alert($(this).serialize());
        e.preventDefault();
    });
</script>