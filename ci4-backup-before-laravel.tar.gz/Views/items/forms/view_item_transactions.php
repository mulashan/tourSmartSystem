<?php 
    $itemmodel = new App\Models\ItemsModel();
    $bmodel = new App\Models\BillingModel();
//print_r($item_info);
   ?>

<table class="table table-hover table-vcenter mb-0 text-nowrap">
    <thead>
        <tr>
            <th>Date</th>
            <th>Trans Type</th>
            <th>Trans No</th>
            <th>Item Name</th>
            <th>Name</th>
            <th>Type</th>
            <th>Qty</th>
            <!-- <th>Amount</th> -->
            <th>bal</th>
        </tr>
    </thead>
<tbody id="item_info">
<?php
helper("student");
$item_info = $bmodel->get_item_name('item_transation_tbl', $where = array('item_id' => $ItemsLst[0]->id));
///echo count($item_info);
$balance=0;
$itm_blc=0;
if(count($item_info)>0){
    foreach($item_info as $info){
    $item_det = $bmodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $info->trans_number,'trans_type_id' => $info->trans_type));
    $trans_type_info = $bmodel->get_item_name('transaction_types_tbl', $where = array('type_id' => $info->trans_type));
    $ledger = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_type' => $info->trans_type,'trans_no'=>$info->trans_number,'trans_item'=>$ItemsLst[0]->id));

    If(count($ledger)>0){
     $name=capture_name($ledger[0]->name_id, $ledger[0]->name_type_id,$info->trans_type,$info->trans_number);   
 }else{
    $ledger = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_type' => $info->trans_type,'trans_no'=>$info->trans_number));
    if(count($ledger)==0){
        continue;
    }
    $name=capture_name($ledger[0]->name_id, $ledger[0]->name_type_id,$info->trans_type,$info->trans_number);
 }
  $name_type = $bmodel->get_item_name('name_type_tbl', $where = array('id' => $ledger[0]->name_type_id));
    if($ledger[0]->transation_nature==1){
        $itm_blc=$itm_blc-$info->quantity;
     $balance=$balance - ($info->quantity*$info->unit_price);
    }else{
        $itm_blc=$itm_blc+$info->quantity;
    $balance=$balance + ($info->quantity*$info->unit_price);
    }

    ?>
<tr>
    <td><?=date("Y-m-d",strtotime($item_det[0]->trans_date));?></td>
    <td><?=$trans_type_info[0]->type_name;?></td>
    <td><?=$info->trans_number;?></td>
    <td><?=$ItemsLst[0]->item_name;?></td>
    <td><?=$name;?></td>
    <td><?=$name_type[0]->name_type;?></td>
    <td><?=$info->quantity;?></td>
    <!-- <td class="text-right"><?=number_format($info->unit_price);?></td> -->
    <td class="text-right"><?=number_format($itm_blc);?></td>
</tr>
    
<?php
 }
}
?>
</tbody>
</table>