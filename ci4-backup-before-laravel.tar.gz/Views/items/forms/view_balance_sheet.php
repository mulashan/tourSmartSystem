                                    <?php  
                                    $imodel = new App\Models\ItemsModel();

                                     $amodel = new App\Models\AdmissionModel();
                                     ?>
                                    <?php 
                                      $cname = $imodel->get_account($id);

                                    foreach($cname as $le){
                                       $name=$le->account_name;
                                     }
                                     $cmp = $amodel->get_student_details('company_tbl', $where = array('created_by >' => 0));
                                    ?>
                <div id="printcashdtls">
                
                  <!-- <h5><?php echo $cmp[0]->company_name;?></h5>
                  <h5>Income Ledger Transaction Details</h5>
                  <h5>Ledger Name: <?php echo $name; ?> </h5> -->
                   
                  <div class="form-group row">
                    <div class="col-md-4"></div>
                  <label class="col-md-1 col-form-label">Total By</label>
                    <div class="col-md-2">
                        <select class="form-select" id="group_by">
                          <option value="0">All</option>
                          <option value="1" selected>Names</option>
                        </select>
                </div>
                <div class="col-md-4"></div>
                </div>
                  
   <div class="card">
    <div class="mt-3" id="grouped_content"></div>                  
</div>
</div>
<center>
<!-- <button class="btn btn-primary btn-sm" onclick="printable_area('printcashdtls')"><span class="fa fa-print"></span> Print</button> -->
<button class="btn btn-success btn-sm col-sm-3" type="button" style="display: none;" onclick="print_area('grouped_content')"><i class="fa fa-print"></i> Print</button>
</center>
<noscript>
  <style>
    table.att-list{
      width:100%;
      border-collapse:collapse
    }
    table.att-list td,table.att-list th{
      border:1px solid
    }
    .text-center,.text-c{
      text-align:center
    }
    #myInput{
      display: none;
    }
  </style>
</noscript>
<script type="text/javascript">

function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");

  filter = input.value.toUpperCase();
  table = document.getElementById("myTable2");
  tr = table.getElementsByTagName("tr");
  for (var i = 1; i < tr.length; i++) {
    var tds = tr[i].getElementsByTagName("td");
    var flag = false;
    for(var j = 0; j < tds.length; j++){
      var td = tds[j];
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        flag = true;
      } 
    }
    if(flag){
        tr[i].style.display = "";
    }
    else {
        tr[i].style.display = "none";
    }
  }
}
function myFunction1() {
var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("date");
  //alert(input);
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable2");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 1; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
  }

$('#print_att').click(function(){
    var _c = $('#grouped_content').html();
    var ns = $('noscript').clone();
    var nw = window.open('','_blank','width=1000,height=600')
    nw.document.write(_c)
    nw.document.write(ns.html())
    nw.document.close()
    nw.print()
    // setTimeout(() => {
    //  nw.close()
    // }, 500);
  })

$('#group_by').change(function(){
  var group=$(this).val();
  var id='<?php echo $id;?>';
  var thedate='<?php echo $thedate;?>';
  //alert(id);
 
  $('#grouped_content').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
   $('#grouped_content').load('index.php/ItemsController/view_balance_group/'+id+'/'+thedate+'/'+group);

});

loadData();
function loadData(){
   var thedate='<?php echo $thedate;?>';
   var id='<?php echo $id;?>';
   // alert(thedate);
  $('#grouped_content').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
   $('#grouped_content').load('index.php/ItemsController/view_balance_group/'+id+'/'+thedate+'/'+1); 
}

function print_area(area) {
  //alert(area);
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=700, height=600, left=100, top=25";
        var content_vlue = document.getElementById(area).innerHTML;

        var docprint = window.open("", "", disp_setting);
        docprint.document.open();
        docprint.document.write('<html><head><title>MHI</title>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
</script>