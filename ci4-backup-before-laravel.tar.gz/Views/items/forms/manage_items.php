
<?php 
    $itemmodel = new App\Models\ItemsModel();
    $bmodel = new App\Models\BillingModel();

    // print_r($ledger);

?>
<div id="updacc"></div>
<form class="card-body form-horizontal" id="updtItem">
    <input type="hidden" class="form-control" name="id" id="id" value="<?= $ItemsLst[0]->id;?>">

    <div class="form-group row">
        <label class="col-md-3 col-form-label">Item Name <span class="text-danger">*</span></label>
        <div class="col-md-8">
            <input type="text" name="iname" id="iname" value="<?= $ItemsLst[0]->item_name;?>" class="form-control form-control-sm" placeholder="Item Name">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label">Item Type <span class="text-danger">*</span></label>
        <div class="col-md-8">
            <select id="i_typ" name="i_typ" class="form-select me-4 form-control form-control-smpreventChange" onchange="get_itemsDue_toItemtypes(this)">
                <option selected>--Choose type--</option>
                <?php foreach ($itypes as $type): ?>
                    <option value="<?php echo $type->id;?>" <?php if($ItemsLst[0]->item_type == $type->id){ echo 'selected'; } ?>><?php echo $type->type_name;?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label">Item Size</label>
        <div class="col-md-8">
            <input type="text" name="isize" id="isize" value="<?= $ItemsLst[0]->item_size;?>" class="form-control form-control-sm" placeholder="Item Size">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label">Item Attribute</label>
        <div class="col-md-8">
            <input type="text" name="iattr" id="iattr" value="<?= $ItemsLst[0]->item_attribute;?>" class="form-control form-control-sm" placeholder="Item Attribute">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label">Item Price <span class="text-danger">*</span></label>
        <div class="col-md-8">
            <input type="text" name="iprice" id="iprice" value="<?= $ItemsLst[0]->item_price;?>" class="form-control form-control-sm" placeholder="Item Price">
        </div>
    </div>    
    <div class="form-group row">
        <label class="col-md-3 col-form-label">Item use<span class="text-danger">*</span></label>
        <div class="col-md-8">
            <select id="igroup" name="igroup" class="form-select me-4 form-control form-control-sm">
                  <?php
     $groups = $bmodel->get_item_name('item_groups_types_tbl', $where = array('group_id !='=> 100));
     
     foreach($groups as $gs){

           ?>
                <option value="<?=$gs->group_id?>" <?php if($ItemsLst[0]->item_group == $gs->group_id){echo 'selected';}?>><?=$gs->group_name?></option>
                <?php
               }
                ?>
            </select>
            <?php
            //print_r($groups);
            ?>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label">Sub Item of</label>
        <div class="col-md-8">
            <select id="icategs" name="icateg" class="form-select me-4 form-control form-control-sm">
                <option selected>--Select Sub-Item--</option>
                <?php
                    $ledger = $bmodel->get_item_name('items_tbl', $where = array('item_type'=> $ItemsLst[0]->item_type));
                    foreach($ledger as $l){
                 ?>
                 <option value="<?php echo $l->id;?>" <?php if($ItemsLst[0]->sub_item_of == $l->id){echo 'selected';}?> ><?php echo $l->item_name; ?></option>
             <?php }?>
            </select>
        </div>
    </div>

    <?php
    $accountIds = array_column(array_map('get_object_vars', $llist), 'account_id');
   
    if($ItemsLst[0]->item_type == 1){
      //  foreach($llist as $l){
            $atype = $itemmodel->Load_Accounttype_List(0,$accountIds);
             
              $account_type_ids = array_column(array_map('get_object_vars', $atype), 'account_type_id');
             
        //      if (in_array(2, $account_type_ids))
        //   {
     ?>
     <div class="form-group row" id="hidDiv">
        <label class="col-md-3 col-form-label">Current Asset Ledger</label>
        <div class="col-md-8">     
            <select  id="casset" name="accounts[]" class="form-select me-4 form-control form-control-sm">
                <option value="">Choose Ledger</option>
                <?php foreach ($atypes as $act): if($act->account_type_id == 2){ ?>
                    <option value="<?php echo $act->id;?>" <?php if (in_array($act->id, $accountIds)) {echo 'selected';} ?> ><?php echo $act->account_name;?></option>
                <?php } endforeach; ?>
            </select>
            <input type="hidden" name="pidd[]" value="<?= $l->id;?>">
    
        </div>
    </div>
    <?php //}  if (in_array(3, $account_type_ids)){
    ?>
    <div class="form-group row" id="hidDiv1">
        <label class="col-md-3 col-form-label">Sales Ledger</label>
        <div class="col-md-8">
            <select  id="sledger" name="accounts[]" class="form-select me-4 form-control form-control-sm">
                <option value="">Choose Ledger</option>
                <?php foreach ($atypes as $act): if($act->account_type_id == 3){ ?>
                    <option value="<?php echo $act->id;?>" <?php if (in_array($act->id, $accountIds)){echo 'selected';} ?> ><?php echo $act->account_name;?></option>
                <?php } endforeach; ?>
            </select>
            <input type="hidden" name="pidd[]" value="<?= $l->id;?>">
        </div>
    </div>
    <?php //} if (in_array(5, $account_type_ids)){ 
    ?>
    <div class="form-group row" id="hidDiv2">
        <label class="col-md-3 col-form-label">COGS Ledger</label>
        <div class="col-md-8">
            <select  id="cledger" name="accounts[]" class="form-select me-4 form-control form-control-sm">
                <option value="">Choose Ledger</option>
                <?php foreach ($atypes as $act): if($act->account_type_id == 5){ ?>
                    <option value="<?php echo $act->id;?>" <?php if (in_array($act->id, $accountIds)){echo 'selected';} ?> ><?php echo $act->account_name;?></option>
                <?php } endforeach; ?>
            </select>
            <input type="hidden" name="pidd[]" value="<?= $l->id;?>">
        </div>
    </div>
    <?php //}}
} else if($ItemsLst[0]->item_type ==2){ 
        foreach($llist as $l){
            $atype = $itemmodel->Load_Accounttype_List($l->account_id);
            //if($atype[0]->account_type_id == 3){
    ?>
    <div class="form-group row" id="hidDiv1">
        <label class="col-md-3 col-form-label">Sales Ledger</label>
        <div class="col-md-8">
            <select  id="sledger" name="accounts[]" class="form-select me-4 form-control form-control-sm">
                <option value="">Choose Ledger</option>
                <?php foreach ($atypes as $act): if($act->account_type_id == 3){ ?>
                    <option value="<?php echo $act->id;?>" <?php if($l->account_id == $act->id){echo 'selected';} ?> ><?php echo $act->account_name;?></option>
                <?php } endforeach; ?>
            </select>
            <input type="hidden" name="pidd[]" value="<?= $l->id;?>">
        </div>
    </div>
    <?php //}
}} else if($ItemsLst[0]->item_type ==3){
        foreach($llist as $l){
            $atype = $itemmodel->Load_Accounttype_List($l->account_id);
           // if($atype[0]->account_type_id == 4){
    ?>
    <div class="form-group row" id="hidDiv3">
        <label class="col-md-3 col-form-label">Other Income Ledger</label>
        <div class="col-md-8">
            <select  id="otheri" name="accounts[]" class="form-select me-4 form-control form-control-sm">
                <option value="">Choose Ledger</option>
                <?php foreach ($atypes as $act): if($act->account_type_id == 4){ ?>
                    <option value="<?php echo $act->id;?>" <?php if($l->account_id == $act->id){echo 'selected';} ?> ><?php echo $act->account_name;?></option>
                <?php } endforeach; ?>
            </select>
            <input type="hidden" name="pidd[]" value="<?= $l->id;?>">
        </div>
    </div>
    <?php //}
}} else if($ItemsLst[0]->item_type ==4){
       // foreach($llist as $l){
           $atype = $itemmodel->Load_Accounttype_List(0,$accountIds);
             
              $account_type_ids = array_column(array_map('get_object_vars', $atype), 'account_type_id');
    ?>
    <div class="form-group row" id="hidDiv1">
        <label class="col-md-3 col-form-label">Sales Ledger</label>
        <div class="col-md-8">
            <select  id="sledger" name="accounts[]" class="form-select me-4 form-control form-control-sm">
                <option value="">Choose Ledger</option>
                <?php foreach ($atypes as $act): if($act->account_type_id == 3){ ?>
                    <option value="<?php echo $act->id;?>" <?php if (in_array($act->id, $accountIds)){echo 'selected';} ?> ><?php echo $act->account_name;?></option>
                <?php } endforeach; ?>
            </select>
            <input type="hidden" name="pidd[]" value="<?= $l->id;?>">
        </div>
    </div>
    <?php //}  if($atype[0]->account_type_id == 4){ ?>
    <div class="form-group row" id="hidDiv3">
        <label class="col-md-3 col-form-label">Other Income Ledger</label>
        <div class="col-md-8">
            <select  id="otheri" name="accounts[]" class="form-select me-4 form-control form-control-sm">
                <option value="">Choose Ledger</option>
                <?php foreach ($atypes as $act): if($act->account_type_id == 4){ ?>
                    <option value="<?php echo $act->id;?>" <?php if (in_array($act->id, $accountIds)){echo 'selected';} ?> ><?php echo $act->account_name;?></option>
                <?php } endforeach; ?>
            </select>
            <input type="hidden" name="pidd[]" value="<?= $l->id;?>">
        </div>
    </div>
    <?php //}
//}
} else if($ItemsLst[0]->item_type ==5){
        foreach($llist as $l){
            $atype = $itemmodel->Load_Accounttype_List($l->account_id);
            //if($atype[0]->account_type_id == 3){
    ?>
    <div class="form-group row" id="hidDiv4">
        <label class="col-md-3 col-form-label">Fixed Asset Ledger</label>
        <div class="col-md-8">
            <select  id="fasset" name="accounts[]" class="form-select me-4 form-control form-control-sm">
                <option value="">Choose Ledger</option>
                <?php foreach ($atypes as $act): if($act->account_type_id == 1){ ?>
                    <option value="<?php echo $act->id;?>-<?php echo $llist[0]->id;?>"  <?php if($l->account_id == $act->id){echo 'selected';} ?>><?php echo $act->account_name;?></option>
                <?php } endforeach; ?>
            </select>
            <input type="hidden" name="pidd[]" value="<?= $l->id;?>">
        </div>
    </div>
    <?php
    // }
    
}} else if($ItemsLst[0]->item_type ==6){ 
        foreach($llist as $l){
            $atype = $itemmodel->Load_Accounttype_List($l->account_id);
            //if($atype[0]->account_type_id == 7){
    ?>    
    <div class="form-group row" id="hidDiv5" >
        <label class="col-md-3 col-form-label">Account Receivable</label>
        <div class="col-md-7">
            <select  id="receivable" name="account[]" class="form-select me-4 form-control form-control-sm">
                <option value="">Choose Ledger</option>
                <?php foreach ($atypes as $act): if($act->account_type_id == 7){ ?>
                    <option value="<?php echo $act->id;?>" <?php if($l->account_id == $act->id){echo 'selected';} ?>><?php echo $act->account_name;?></option>
                <?php } endforeach; ?>
            </select>
        </div>
    </div>
<?php }}
//}?>

    <div class="form-group row">
        <label class="col-md-3 col-form-label"></label>
        <div class="col-md-8">
            <button type="submit" class="btn btn-primary float-right">Update</button>
        </div>
    </div>
</form>

<script type="text/javascript">

    function get_itemsDue_toItemtypes(id){
        var selectOption = '';
        var data = 'id=' + id.value;
        // alert(data);

        $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/ItemsController/fetch_subitems'; ?>',
            dataType: 'json',
            success:function(response){
                console.log(response);

                var len = response.length;
                $("#icategs").empty();
                $("#icategs").append("<option value=''>-Select Sub-Item-</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var item_name = response[i]['name'];
                    var attribute = response[i]['attr'];
                    var size = response[i]['size'];

                    selectOption = "<option value='"+id+"'>"+"\xa0"+'Name:'+item_name+"\xa0\xa0\xa0\xa0"+'Attribute:'+"\xa0"+attribute+"\xa0\xa0\xa0\xa0"+'Size:'+"\xa0"+size+"</option>";
                    $("#icategs").append(selectOption);
                }
            }
        });
    }

    $('#updtItem').submit(function (e) {
         //alert($(this).serialize());
        // return;
        $.ajax({
            type: 'POST',
            url: '<?= base_url('/updte_item') ?>',
            data: $(this).serialize(),
            success: function (res) {
                $('#updacc').html(res);
                setTimeout(function(){
                     window.location.reload();
                },1000)
            },
            error: function () {
                $('#updacc').html('Error! Couldnt update Item.');            }
        });
        //alert($(this).serialize());
        e.preventDefault();
    });
</script>