
<?php 
    $itemmodel = new App\Models\ItemsModel();
    $bmodel = new App\Models\BillingModel();

    // print_r($ledger);
 $cmp = $bmodel->get_item_name('company_tbl', $where = array('created_by >' => 0));
?>
 <!-- <center><h5>ITEM INFORMATION</h5></center>  -->

                  <div class="container-fluid">
                    <div class="row">
                  <div class="col-md-4"></div>
                 <div class="col-md-4" id="printable">
                        <center>
              <h5><?php //echo esc($cmp[0]->company_name??"");?></h5>    
             <h5>ITEM SETUP</h5>  
          </center>
            
                    
        <table class="table table-hover mb-0 text-nowrap att-list">
        <tr><th>Item Name</th><td><?= $ItemsLst[0]->item_name;?></td><td></td><td></td><td></td><td></td><td></td></tr>
       
        <tr><th>Item Type</th><td>
            <?php foreach ($itypes as $type): ?>
            <?php 
            if($ItemsLst[0]->item_type == $type->id){ echo $type->type_name;}?>
                <?php endforeach; ?>
            </td></td><td></td><td></td><td></td><td></td></tr>
        
            <tr><th>Item Size</th><td><?= $ItemsLst[0]->item_size;?><td></td><td></td><td></td><td></td><td></td></tr>
                <tr><th>Item Attributes</th><td><?= $ItemsLst[0]->item_attribute;?></td></td><td></td><td></td><td></td><td></td></tr>
                <tr><th>Item Price</th><td><?= $ItemsLst[0]->item_price;?></td></td><td></td><td></td><td></td><td></td></tr>
                <tr><th>Item Group</th><td>
                    <?php 

                    $itmgrp = $itemmodel->get_selected_data('item_groups_types_tbl',$where=array('group_id'=>$ItemsLst[0]->item_group),$data=array('group_name'));
                        if($ItemsLst[0]->item_group != ""){
                            echo $itmgrp[0]->group_name;
                             }else{

                                }
                    
                ?></td></td><td></td><td></td><td></td><td></td></tr>
                 <?php
                    $ledger = $bmodel->get_item_name('items_tbl', $where = array('item_type'=> $ItemsLst[0]->item_type));
                        ?>
                <tr><th>Sub Item Of</th><td><?php 
                
                 if($ItemsLst[0]->sub_item_of >0){
                $data2 = $itemmodel->get_sub_account2($ItemsLst[0]->sub_item_of);

                    foreach ($data2 as $dt) {
                        if($ItemsLst[0]->sub_item_of != 0){
                            echo $dt->account_name;
                        }else{
                            echo "-";
                        }
                    }
                }
            ?></td></td><td></td><td></td><td></td><td></td></tr>
                <?php if($ItemsLst[0]->item_type == 1){
        foreach($llist as $l){
            $atype = $itemmodel->Load_Accounttype_List($l->account_id);
           if($l->account_id==2){
               $ledger="Current Asset Ledger";
                }else if($l->account_id==5){
                  $ledger="Current Asset Ledger";
                }else if($l->account_id==7){
                  $ledger="Current Asset Ledger";   
                }
                ?>
                <tr><th>Current Assets</th><td><?php echo $atype[0]->account_name;?></td></td><td></td><td></td><td></td><td></td></tr>
                 <?php 


             }}
                 else if($ItemsLst[0]->item_type ==2){ 
        foreach($llist as $l){
            $atype = $itemmodel->Load_Accounttype_List($l->account_id);

                 ?>
                <tr><th>Sales Ledger</th><td><?php echo $atype[0]->account_name;?><td></td><td></td><td></td><td></td><td></td></tr>
                <?php }}
                else if($ItemsLst[0]->item_type ==3){
        foreach($llist as $l){
            $atype = $itemmodel->Load_Accounttype_List($l->account_id);
                ?>
                <tr><th>Other Income</th><td><?php echo $atype[0]->account_name;?></td></td><td></td><td></td><td></td><td></td></tr>
            <?php }}
                   else if($ItemsLst[0]->item_type ==4){
        foreach($llist as $l){
            $atype = $itemmodel->Load_Accounttype_List($l->account_id);
            ?>
                <tr><th>Sales Ledger</th><td><?php echo $atype[0]->account_name;?></td></td><td></td><td></td><td></td><td></td></tr>
            <?php 
        }} 
else if($ItemsLst[0]->item_type ==5){
        foreach($llist as $l){
            $atype = $itemmodel->Load_Accounttype_List($l->account_id);
            ?>
                <tr><th>Fixed Asset</th><td><?php echo $atype[0]->account_name;?></td></td><td></td><td></td><td></td><td></td></tr>
            <?php }}
else if($ItemsLst[0]->item_type ==6){
        foreach($llist as $l){
            $atype = $itemmodel->Load_Accounttype_List($l->account_id);
            ?>
                <tr><th>Account Receivable</th><td><?php echo $atype[0]->account_name;?></td></td><td></td><td></td><td></td><td></td></tr>
           <?php }}else{
            foreach($llist as $l){
            $atype = $itemmodel->Load_Accounttype_List($l->account_id);
            ?>
                <tr><th>Account </th><td><?php echo $atype[0]->account_name;?></td></td><td></td><td></td><td></td><td></td></tr>
           <?php }
           }
             ?>
           
           
    
 </table><br>
</div>
</div>

<div id="item_view"></div>
<hr><br>
<button type="button" class="btn btn-danger" id="cancel" style="padding:5px; float:right" data-bs-dismiss="modal">Cancel</button>
        <center>
            <button class="btn btn-success btn-sm col-sm-3" type="button" id="print_att"><i class="fa fa-print"></i> Print</button>
        </center>
</div>
<noscript>
    <style>
        table.att-list{
            width:100%;
            border-collapse:collapse
        }
        table.att-list td,table.att-list th{
            border:1px solid
            text-align: left;
        }
        .text-center,.text-c,.d-flex{
            text-align:center
        }
        #cancel,#print_att{
            display: none;
        }
    </style>
</noscript>

<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
     $('#print_att').click(function(){
        var _c = $('#printable').html();
        var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=900,height=600')
        nw.document.write(_c)
        nw.document.write(ns.html())
        nw.document.close()
        nw.print()
       
    })
  item_transactions(); 
function item_transactions(){
var item_type="<?=$ItemsLst[0]->item_type;?>";
var item_id="<?=$ItemsLst[0]->id;?>";
if(item_type==1 || item_type==4){
     $('#item_view').html('<center><b><span class="fa fa-spin fa-spinner"></span> Please Wait...</b></center>');
$('#item_view').load('<?php echo base_url() . '/index.php/ItemsController/load_item_transaction/'; ?>' + item_id); 
}
}
    
</script>