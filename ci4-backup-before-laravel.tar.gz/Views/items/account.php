<?php  $imodel = new App\Models\ItemsModel(); ?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Ledgers</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Ledgers</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#acc-all">Ledgers List</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#acc-add">New Ledger</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#acc-all">Ledgers List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#acc-add">New Ledger</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="acc-all">
                <div class="card">
                    <div class="table-responsive mt-3">
                        
                        <?php if (isset($msg)) : ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <?php echo $msg; ?>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            </div>
                        <?php endif; ?>
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>Ledger Code</th>
                                    <th>Ledger Name</th>
                                    <th>Ledger Type</th>
                                    <th>Description</th>
                                    <th>Updated By</th>
                                    <th>Updated Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php foreach($accounts as $ac):?>
                                    <tr>
                                        <td><?= $ac->account_code;?></td>
                                        <td><?= $ac->account_name;?></td>
                                        <td><?= $ac->type_name;?></td>
                                        <td><?= $ac->description;?></td>
                                        <td><?= $ac->first_name.' '.$ac->last_name;?></td>
                                        <td><?= $ac->updated_date;?></td>
                                        <td>
                                    
                                            <button type="button" class="btn btn-primary btn-sm passingID" data-id="<?= $ac->id;?>"><i class="fa fa-edit"></i> Edit</button>

                                            <button type="button" class="btn btn-primary btn-sm passingData" data-id="<?php echo $ac->id;?>"><i class="fa fa-eye"></i>View</button>
                                            <!-- <a href=" <?php //echo base_url("/delete/". $ac->id); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a> -->
                                            <!-- <button type="button" class="btn btn-danger btn-sm deleteID"  data-id="<?= $ac->id;?>"><i class="fa fa-trash"></i></button> -->
                                        </td>
                                    </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="tab-pane" id="acc-add">
                <div class="row clearfix">
                    <div class="card">
                        <div class="card-header" style="height:5px">
                            <h3 class="card-title">Account Information</h3>
                            <div class="card-options ">
                                <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                            </div>
                        </div>
                        <hr>
                        <div class="card-body">
                            <form class="form-horizontal" id="addAccount">
                                <div id="fdbkarea"></div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Ledger Date</label>
                                    <div class="col-md-7">
                                        <input type="date" name="date" id="date" class="form-control form-control-sm" placeholder="" value="<?php echo date('Y-m-d'); ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Ledger Name<span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <input type="text" name="acname" id="acname" class="form-control form-control-sm" placeholder="Ledger Name" required="required">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Ledger Type<span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                    <select id="ac_type" name="ac_type" onchange="subAccount(this)" class="form-select me-4 form-control form-control-sm" required="required">
                                        <option selected>--Choose type--</option>
                                        <?php foreach ($atype as $act): ?>
                                            <option value="<?php echo $act->id;?>"><?php echo $act->type_name;?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Ledger Number</label>
                                    <div class="col-md-7">
     <input type="text" name="acno" value="0" id="acno" class="form-control form-control-sm" placeholder="Ledger Number">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Description</label>
                                    <div class="col-md-7">
                                        <input type="text" name="descr" id="descr" class="form-control form-control-sm" placeholder="Description">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Sub Ledger of</label>
                                    <div class="col-md-7">
                                    <select id="subacc" name="subacc"  class="form-select me-4 form-control form-control-sm">
                                        
                                    </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label"></label>
                                    <div class="col-md-7">
                                        <button type="reset" class="btn btn-outline-secondary">Cancel</button>
                                        <button type="submit" class="btn btn-primary float-right">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<!-- ------edit modal------ -->


<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Edit Ledger</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="UpdteAccnt"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>

  <!-- View Modal -->
  <div id="myModalview" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content" style="width:130%">
        <div class="modal-content">
        <div class="modal-header">
         <!--  <h5 class="modal-title" id="staticBackdropLabel">Income Ledger Transaction Details</h5> -->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
       <div class="modal-body">
          <div id="showLedger"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
  </div>

<script type="text/javascript">

    $(".passingID").click(function () {
        var data = 'ids=' + $(this).attr('data-id');
        // $("#idkl").val( ids );
        $('#myModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?= base_url('/getSingle_data')?>",
            data: data,
            beforSend: function()
            {
                $('#UpdteAccnt').html();
            },
            success: function(res){
                $('#UpdteAccnt').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
  

    $(".passingData").click(function () {
        var data = 'ids=' + $(this).attr('data-id');

        $('#myModalview').modal('show');
        $.ajax({
            type: "GET",
            url: "<?= base_url('/getSingle_data2')?>",
            data: data,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
       $('#addAccount').submit(function(e){
      event.preventDefault();
            if (!this.checkValidity()) {
            e.preventDefault();
            e.stopPropagation();
            this.classList.add("was-validated");
            }
             else{ 
        $.ajax({
            type: "POST",
            url: "<?= base_url('/add_Account') ?>",
            data: $(this).serialize()+'&'+$("#header_form").serialize(),
            success: function (res) {
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                    
                    $("#addAccount")[0].reset();
                    $('#fdbkarea').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },3000)
                }else{
                    $('#fdbkarea').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            },
            error: function () {
                $('#fdbkarea').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button><strong>Sorry! Something went wrong!</strong> Couldnt Save Ledger.</div>');
            }
        });}
    });
    function subAccount(id)
    {
        var data = 'id=' + id.value;
        // alert (sub);

        $.ajax({

            type: 'POST',
            url: '<?= base_url('/sub_accnt') ?>',
            data: data,
            dataType: 'json',
            success: function(res){
                     var len = res.length;
                     var is_sub="";
                $("#subacc").empty();
             $("#subacc").append("<option value='0'>-Choose Ledger-</option>");
                for( var i = 0; i<len; i++){
                    var id = res[i]['id'];
                    var pname = res[i]['pname'];
                    var name = res[i]['name'];
                    var sub = res[i]['sub_acc'];

                    if(sub != ""){
                        is_sub = ":&nbsp;&nbsp;"+sub;
                    }
                    $("#subacc").append("<option value='"+id+"'>"+pname+is_sub+":&nbsp;&nbsp;"+name+"</option>");
                }
            },
            error: function(){
                alert('Error');
            }
        });
    }

    
     $(".deleteID").click(function(){

        var id = $(this).attr('data-id');


           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this ledger!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/delete')?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      // $("#"+id).remove();
                    swal("Deleted!", "Ledger deleted.", "success");

                    // location.reload();
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                      
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });

</script>