
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 

    $cmodel = new App\Models\AccomodationModel();
    $amodel = new App\Models\AdmissionModel();
    $csmodel = new App\Models\ClassesModel();
    $charged_item = $cmodel->items_chargedList();
    
    $account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));

?>


<!-- Modal -->
  <div id="myModal" class="modal fade"  role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="">Edit Accomodation</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Updtelvl"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
<!-----End update modal--->


<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Accomodation</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                        <?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
                    </a></li>
                    <li class="breadcrumb-item active" aria-current="page">Accomodation</li>
                </ol>
            </div>
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Accomodation-tab" data-toggle="tab" href="#Accomodation-all">Accomodation(s) List</a></li>
                <li class="nav-item"><a class="nav-link" id="Accomodation-tab" data-toggle="tab" href="#Accomodation-add">Add Accomodation</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Accomodation-tab" data-toggle="tab" href="#Accomodation-all">Accomodation(s) List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Accomodation-tab" data-toggle="tab" href="#Accomodation-add">Add Accomodation</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>


<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="Accomodation-all">

                <div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                    <th>No.#</th>
                                    <th>Hostel Name</th>
                                    <th>Block</th>
                                    <th>Bed Capacity</th>
                                    <th>Gender</th>
                                    <th>Age</th>
                                    <th>Status</th>
                                    <th>Modified By</th>
                                    <th>Modified Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i=0;
                                foreach($list as $acc){

                                    $update=$acc->updated_by;
                                    $modify = $cmodel->modify($update);
                                    foreach($modify as $mod){
                                        $updated=$mod->first_name.' '.$mod->last_name;
                                    }
                                    $status=$acc->status;
                                    ?>

                                    <!-----update modal--->
                                    <?php
                                    $i++;
                                     ?>
                                    <tr>
                                    <td><?=$i?></td>
                                    <td><?=$acc->hostel_name?></td>
                                    <td><?=$acc->block_name?></td>
                                    <td><?=$acc->capacity?></td>
                                    <td><?=$acc->gender?></td>
                                    <td><?=$acc->start_age." - ".$acc->end_age?></td>
                                    <?php if($status==1){ ?>
                                    <td><?= '<span class="text-success">Active</span>'?></td>
                                    <?php }else{?>
                                    <td><?= '<span class=" text-danger">InActive</span>'?></td>
                                    <?php } ?>
                                    <td><?=$updated;?></td>
                                    <td><?=$acc->updated_date;?></td>
                                    <td>

                                  <!-- <a href="accomodation/<?php echo $acc->hostel_id; ?>" class="btn btn-primary btn-sm" > 
                                <i title="Update" class="fa fa-edit"></i>
                               </a>-->
                               
                                
                          <button type="button" class="btn btn-primary btn-sm EditID1" data-id="<?=$acc->hostel_id;?>"><i class="fa fa-edit"></i> Edit</button>                              
                                    
                         <a href="#" data-toggle="modal" class="btn btn-primary btn-sm" data-target="#edit<?php echo $acc->hostel_id  ?>"> 
                                <i title="View" class="fa fa-eye"></i> View
                               </a>
                                </td>
                                 
                                    </tr>

                                    <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
            <div class="tab-pane" id="Accomodation-add">
                <div class="card">
                    <div class="card-header" style="height:5px">
                        <h3 class="card-title">New Accomodation</h3>
                        <div class="card-options ">
                            <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                        </div>
                    </div>
                    <hr>
                    <form class="card-body form-horizontal" id='saveAccomodate' >
                    <div id="accfbk" class="text-success"></div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Hostel Name</label>
                            <div class="col-md-8">
                                <input type="text" id="hostel" class="form-control" name="hostel"required="required">
                            <span id="block" class="text-danger"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Block Name</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="block" required="required">
                            <span id="block" class="text-danger"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Bed Capacity</label>
                            <div class="col-md-8">
                                <input type="number" class="form-control" name="bed" required="required">
                            </div>
                        </div>
                          <div class="form-group row">
						  <label class="col-md-3 col-form-label">Age</label>
                            <!---------------------age started---------------------->
                             <div class="col-md-2">
                                            <button type="button" class="btn btn-default pull-right age-btn" onclick="showWindow('sethour')">
                                                <span>Age Range
                                                    <i class="fa fa-calendar"></i> 
                                                </span>
                                                <i class="fa fa-caret-down"></i>
                                            </button>
                                        </div>
                                        </div>
                   <div class="cust_popup_md" id="sethour" style="display: none;">
                    <a href="javascript:void(0)" onclick="CloseWindow('sethour')" style="float: right" data-toggle="tooltip" title="Close"><i class="fa fa-times"></i></a><br/>
                    <table class="table table-condensed table-bordered">
                            <tr>
                                <th>From:</th>
                               
                                <th>To:</th>
                               </tr>
                            <tr>
                                <td>
                                    <input class="form-control" type="number" min="0" name="start" value="" onchange="FinishCheck()">
                                </td>
                                
                                </td>
                                <td>
                                    <input class="form-control" type="number" min="1" name="fnsh" value="" onchange="FinishCheck()" >
                                </td>
                                                                                               
                            </tr>
                    </table>
                    <button type="button" class="btn btn-primary pull-right" onclick="setAgeFilter()">Set</button>
                    </div>
                        
                    
                
                            <!--------------------age end----------------------------------->
                            <!-- <label class="col-md-3 col-form-label">Age Range</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="age" required="required">
                            </div>
 -->                        
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Gender</label>
                            <div class="col-md-8 mt-2">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input mt-1" type="radio" name="gender" id="female" value="Female" required="required">
                                    <label class="form-check-label" for="day">
                                    Female
                                    </label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input mt-1" type="radio" name="gender" id="male" value="Male" required="required">
                                    <label class="form-check-label" for="board">
                                    Male
                                    </label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input mt-1" type="radio" name="gender" id="both" value="Both" required="required">
                                    <label class="form-check-label" for="board">
                                    Both
                                    </label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Charged Items<span class="text-danger">*</span></label>
                            <div class="col-md-8">
                            <select class="form-select form-control" id="js-example-data-ajax" style="width:100%;height: 15px;"></select>
                               <!--- <input list="items_charged" id="items" name="items"  class="form-control" placeholder="Search Item Here"/>
                                <datalist id="items_charged">
                                    <option value=""></option>
                                </datalist>-->
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-2"></div>
                            <div class="col-md-9">
                                <div class="card">
                                    <p Class=" d-flex justify-content-center mt-3">CHARGED ITEMS</p>
                                    <table class="table table-hover table-vcenter mb-0 text-nowrap" id="table">
                                    <thead>
                                            <tr>
                                                <th>No#</th>
                                                <th>Item Name</th>
                                                <th>Attribute</th>
                                                 <th>Size</th>
                                                <th>UOM</th>
                                                 <th>Quantity</th>
                                                <th>Price</th>
                                                
                                                <th>Total</th>
                                                <th>Action</th>
                                            </tr>
                                    </thead>
                                    <tbody id="show_item">

                                    </tbody>
                                    </table>
                                    <table>
                                        <tr>
                                        <th col=4>
                                        <span id="totalp" style="margin-left:400px;"></span>
                                        </th>
                                        </tr>
                                        </table>
                                </div>
                            </div>
                        </div>
                        <!------------------------installments added here------------------------------->
                        
                        <!----------------------installments added here------------------------------->
                            <div class="form-group row">
                                <label class="col-md-2 col-form-label">Account Receivable<span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <select name="account" id="account" class="form-control" required="required">
                                        <option value="">--Select Account Receivable--</option>
                                        <?php foreach ($account as $ac): ?>
                                            <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                            </div>
                        
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-8">
                                <button type="submit" class="btn btn-outline-secondary">Cancel</button>
                                <button type="submit" class="btn btn-primary float-right">Save</button>
                            </div>
                        </div>
                    </form>
                   
                </div>

            </div>

        </div>
    </div>
</div>
<noscript>
    <style>
        table.att-list{
            width:100%;
            border-collapse:collapse
        }
        table.att-list td,table.att-list th{
            border:1px solid
            text-align: left;
        }
        .text-center,.text-c,.d-flex{
            text-align:center
        }
        #cancel,#print_att{
            display: none;
        }
    </style>
</noscript>

<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
    $('#print_att').click(function(){
        var _c = $('#printable').html();
        var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=900,height=600')
        nw.document.write(_c)
        nw.document.write(ns.html())
        nw.document.close()
        nw.print()
        // setTimeout(() => {
        //  nw.close()
        // }, 500);
    })
    var hold_selected_items = []; // hold all selected items

    $(document).ready(function(){
        fetch_data();
         $('#js-example-data-ajax').select2({
            ajax: {
                url: "<?= base_url('load_accomodation'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            },
             escapeMarkup: function (markup) {
                        return markup; // Don't escape HTML
                        },
                        templateResult: function (data) {
                        return data.text; // Render the full HTML in 'text'
                        },
        });

        $('#js-example-data-ajax').on('select2:select', function (e) {
            selectedItems();
        });
        //var prc; 
        function selectedItems(){  
            var rows = '';
           var itemData = 'item_selected='+$('#js-example-data-ajax').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Accomodationdata1')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }else{
                        var len  = data.length;
                        
                        for (var i = 0; i <len; i++ ){
                            hold_selected_items.push(data[i]['id']);// push all selected items
                            var prc = data[i]['iprice'];
                            price= prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
                            var name = data[i]['iname'];
                            var size = data[i]['isize'];
                            var attribute = data[i]['iattribute'];
                            var iid = data[i]['id'];
                            //var qty = window.prompt("Enter quantity");
                            //var tprice = qty*prc;
                           
                            
                            rows += '<tr id="table_row'+ iid +'">';

                           rows+='<td><input type="hidden" name="id[]" value="'+iid+'">'+ iid +'</td>';
                            
                            rows += '<td>'+ name +'</td>';
                            rows += '<td>'+ attribute +'</td>';
                            rows += '<td>'+ size +'</td>';
                            rows += '<td>'+ 1 +'</td>';
                            rows += '<td><input type="text" name="qty'+iid+'" id="qty'+iid+'" onchange=mult('+iid+'); style="width:45px" required="required"></td>';
                            rows += '<td id="item_price'+iid+'">'+ prc +'</td>';
                            rows += '<td id="tprice'+iid+'"></td>';
                            //rows += '<td><input type="text" name="tprice" id="tprice'+iid+'" style="width:85px; border:none; background-color:rgb(240,240,240)" readonly></td>';
                            rows += '<td><a href="javascript:RemoveSelectItemRow('+iid+','+i+');" class="btn btn-danger btn">X</a></td>';
                            
                            rows += '</tr>';
                            $('#show_item').append(rows);
                        }
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }
                
           });  
        }

    });
        
sumVal=0;   
function mult(iid){
    var totalPrice = $('#qty'+iid).val()* $('#item_price'+iid).html()        
    //document.getElementById('tprice'+iid).value =         
    //totalPrice; 
    $('#tprice' + iid).append(totalPrice);
    var table = document.getElementById("table"); 
           sumVal = sumVal + $('#qty'+iid).val()* $('#item_price'+iid).html();
            
            
            document.getElementById("totalp").innerHTML = "Total = " + sumVal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(sumVal);
            return sumVal;  
}   
$(document).ready(function(){
   
    // code to read selected table row cell data (values).
    $("#table").on('click','.btn',function(){
         
         var currentRow=$(this).closest("tr"); 
         
         var col1=currentRow.find("td:eq(7)").text(); 
          //sum=totalAmounts();
          //sum=sumval;
         var data=col1;
         //alert(data);
        sumVal=sumVal-data;
        document.getElementById("totalp").innerHTML = "Total = " + sumVal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(sumVal);
         
    });
});

    function RemoveSelectItemRow(item_id,v){
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }
       
        //alert(sumVal);
        var k=v+1;
        var table = document.getElementById("table");
        var data=parseInt(table.rows[k].cells[7].innerHTML);
        
         
         //var col1=currentRow.find("td:eq(7)").text();
        
        $('#table_row'+item_id).remove();
    }


    $('#saveAccomodate').submit(function(e){
        var Data=$(this).serialize();
        //alert(Data);
          if(remain>0){
        swal('warning','Please! assign '+remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+' to installments','warning');
       }else{
        $.ajax({
            method: 'POST',
            url: '<?= base_url('createAccomodation')?>',
            data: Data,
            // dataType: 'json',
            success:function(res){
                var data = JSON.parse(res);
                
                    $("#saveAccomodate")[0].reset();
                    $('#accfbk').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                
            },
            error:function(res){
                $('#accfbk').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Save Accomodation.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
            }
        });
        }
        e.preventDefault();
    });
    
    
    $(".deleteID").click(function(){

        var id = $(this).attr('data-id');

           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this Accomodation!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/deleteAcc')?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      // $("#"+id).remove();
                    swal("Deleted!", "Accomodation deleted.", "success");

                    location.reload();
                      
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
    
    $(".editBtn").click(function () {
        var data = 'id=' + $(this).attr('data-id');
        $('#myModal').modal('show');

        $.ajax({
            type: "GET",
            url: '<?= base_url('/accomodation') ?>/'+id,
            data: data,
            beforSend: function()
            {
                $('#UpdteItem').html();
            },
            success: function(res){
                $('#UpdteItem').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });

$(".EditID1").click(function () {
        var data = 'ids=' + $(this).attr('data-id');
        // $("#idkl").val( ids );
         //alert (data);
        $('#myModal').modal('show');


        $.ajax({
            type: "GET",
            url: "<?= base_url('/accomodation_Edit')?>",
            data: data,
            beforSend: function()
            {
                $('#Updtelvl').html();
            },
            success: function(res){
                $('#Updtelvl').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
    
    $('#temp').click(function(event){
     //totalAmounts();
     //fetch_data();
     //event.preventDefault();
       var data = 'installname=' + $('select[name=install]').val() + '&amount=' + $('input[name=amount]').val()+ '&id=' + $('input[name=ids]').val();
       var k=sumVal;
      // alert(k);
      if(k==0){
        alert("Enter charged Items first");
       }else{
       if(!remain && remain!=0){
          remain=k; 
       }
       var mount=$('input[name=amount]').val();
       var sum=remain-mount;
       //alert(sum);
       if(sum>=0){
     document.getElementById("more").innerHTML="";
       $.ajax({
            type: 'POST',
           url: 'temporaryaccomodation',
            data: data,
            success:function(data){
                 if(data==1){
                    swal("Term, Already Selected");
                    sum=remain+mount;
                }
                fetch_data();
                
            }
       });
       }else{
        document.getElementById("more").innerHTML="Enter less amount or equal to "+remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
      $('input[name=amount]').val()="";     
       }}
        event.preventDefault();
    });
    
    var remain;
       function fetch_data(){
        $('#show2').empty();
                
        var datta = 'acc_id=0';
        $.ajax({
            type: 'GET',
            data: datta,
            //url: 'fetchinstallments',
            url: 'fetchinst2',
            success:function(response){

                var temp_data = JSON.parse(response);
                var len = temp_data.length;
                //total=fetch_class_itemsCharged();
                var ttlamount=0;
                for(var i = 0; i < len; i++){
                    var amounted=parseInt(temp_data[i]['amount']);
                    ttlamount=parseInt(ttlamount+amounted);
                    $('#show2').append('<tr>'+
                        
                        '<td>'+temp_data[i]['installname']+'</td>\
                        <td>'+temp_data[i]['amount']+'</td>\
                        <td>'+temp_data[i]['due_date']+'</td>\
                        <td>\
                            <a href="javascript:RemoveSelecttemp('+temp_data[i]['id']+');" class="btn btn-danger dlt">x</a>\
                        </td>\
                    </tr>');
                }
        total=sumVal;
        //total=temp_data[0]['tamount'];
        remain=total-ttlamount;
        document.getElementById("remained").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(remain);
            }
        });
        
    }
    function RemoveSelecttemp(id)
    {
        $.ajax({
            type: 'GET',
            url: 'delete_temp/'+id,
            success: function(){
         alert('deleted successfuly');
         remain= sumVal;
         document.getElementById("remained").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(remain);
         
                 fetch_data();
                
            }
        });
    }

    function setAgeFilter(){
        var strt = $('input[name=start]').val();
        
        var fnsh = $('input[name=fnsh]').val();
        
        $('.age-btn span').html(strt + 'yrs - ' + fnsh+'yrs');
        CloseWindow('sethour');
        $('sethour').hide();
    }

        function FinishCheck(){
        var strtVal = $('input[name=start]').val();
        var fnshVal = $('input[name=fnsh]').val();
        
            $('input[name=fnsh]').attr('min',strtVal);
            if(fnshVal < strtVal){
                $('input[name=fnsh]').attr('value',strtVal);
            }
            }
        
     
    function CloseWindow(wndw){
        $('#'+wndw).hide(200);
    }
     function showWindow(wndw){
        $('#'+wndw).show(200);
    }
</script>