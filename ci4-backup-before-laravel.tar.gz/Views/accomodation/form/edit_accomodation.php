
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center ">
        <ul class="nav nav-tabs page-header-tab">
            <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#hostel">Hostel</a></li>
            <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#items">Charged Items</a></li>
            <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#ments">Installments</a></li>
        </ul>
    </div>
</div>
 


<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 
    $csmodel = new App\Models\ClassesModel();
    $cmodel = new App\Models\AccomodationModel();
    $amodel = new App\Models\AdmissionModel();

    $charged_item = $cmodel->items_chargedList();
    $account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));
?>



    <div class="container-fluid">
        <div class="tab-content">
        <div class="tab-pane active" id="hostel">
                
                    
					<?php
                   foreach($list as $acc){
	                 ?>
					 
                    <form class="card-body form-horizontal" id='updateAccomodate' >

					
                        <div class="form-group row">
						<div id="updacc1"></div>
                            <label class="col-md-3 col-form-label">Hostel Name</label>
                            <div class="col-md-8">
							<input type="hidden" class="form-control" id="hostelId" name="hostel_id" value="<?= $acc->hostel_id;?>">
                                <input type="text" class="form-control" name="hostel" value="<?= $acc->hostel_name;?>">
                            </div>
							
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Block Name</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="block" value="<?= $acc->block_name;?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Bed Capacity</label>
                            <div class="col-md-8">
                                <input type="number" class="form-control" name="bed" value="<?= $acc->capacity;?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Age Range</label>
                            <div class="col-md-3">
                                <button type="button" class="btn btn-default pull-right age-btn" onclick="showWindow('sethour')">
                                                <span><?php echo $acc->start_age."yrs - ".$acc->end_age."yrs"; ?>
                                                    <i class="fa fa-calendar"></i> 
                                                </span>
                                                <i class="fa fa-caret-down"></i>
                                            </button>
                            </div>
                        </div>
                        <!--////////////////age popup table/////////////////////--->
                         <div class="cust_popup_md" id="sethour" style="display: none;">
                    <a href="javascript:void(0)" onclick="CloseWindow('sethour')" style="float: right" data-toggle="tooltip" title="Close"><i class="fa fa-times"></i></a><br/>
                    <table class="table table-condensed table-bordered">
                            <tr>
                                <th>From:</th>
                               
                                <th>To:</th>
                               </tr>
                            <tr>
                                <td>
                                    <input class="form-control" type="number" min="0" name="start" value="<?php echo $acc->start_age; ?>" onchange="FinishCheck()">
                                </td>
                                
                                </td>
                                <td>
                                    <input class="form-control" type="number" min="1" name="fnsh" value="<?php echo $acc->end_age; ?>" onchange="FinishCheck()" >
                                </td>
                                                                                               
                            </tr>
                    </table>
                    <button type="button" class="btn btn-primary pull-right" onclick="setAgeFilter()">Set</button>
                    </div>
                        <!--/////////////////////////////////////////////////////---->
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Gender</label>
                            <div class="col-md-8 mt-2">
                              <select class="form-control bor-radius5" name="gender" id="gender">
                            <option value="<?= $acc->gender;?>"><?= $acc->gender;?></option>
							<option value="male">male</option>
                             <option value="female">female</option>
                            <option value="both">both</option>
							
                        </select>  
                            </div>
                       </div>
                        

                       
                     <div class="form-group row">
                    <label class="col-md-2 col-form-label"></label>
                    <div class="col-md-10">
                        <button type="submit" class="btn btn-primary float-right">Update</button>
                    </div>
                </div>
            </form>
			<?php
			}
	       ?>
        </div>
        
        <div id="items" class="tab-pane">
            <div id="success"></div>
            <form class="card-body form-horizontal" id='updateTable'>
			<input type="hidden" class="form-control" id="hostelId" name="hostel_id" value="<?= $acc->hostel_id;?>">
		  <div class="form-group row">

                        <div class="form-group row">

                            <label class="col-md-3 col-form-label">Charged Items<span class="text-danger">*</span></label>
                            <div class="col-md-8">
							<select class="form-select form-control" id="js-example-data-ajax" style="width:100%;height: 15px;"></select>
                           <span id="result" class="text-danger"></span>
						</div>
						
                        </div>
                        
                        <div class="row">
                            <div class="col-md-2"></div>
                            <div class="col-md-12">
                                <div class="card">
                                    <p Class=" d-flex justify-content-center mt-3">CHARGED ITEMS</p>
                                    <table class="table table-hover table-vcenter mb-0 text-nowrap">
                                    <thead>
                                            <tr>
                                                <th>No#</th>
                                                <th>Item Name</th>
                                                <th>Attribute</th>
                                                 <th>Size</th>
                                                <th>UOM</th>
                                                 <th>Quantity</th>
                                                <th>Price</th>
                                                <th>Total</th>
                                                <th>Action</th>
                                            </tr>
                                    </thead>
                                    <tbody id="show_item">
									<?php
                                   foreach($tabledata as $table){
									   $price= $table->item_price;
									   $qty= $table->quantity;
									   $tprice=number_format($price*$qty);
	                                  ?>
									  
                                      <tr id='<?= $table->id;?>'>
									  
                                                <input type="hidden" name="id[]" value="<?= $table->item_id;?>">
                                                <td>
                                                <input type="hidden" name="account" value="<?= $table->account_receivable;?>"><?= $table->item_id;?></td>
                                                <td><?= $table->item_name;?></td>
                                                <td><?= $table->item_attribute;?></td>
                                                <td><?= $table->item_size;?></td>
                                                <td><?= 1;?></td>
                                                <td><input type="text" name="qty<?= $table->item_id;?>" value="<?= $table->quantity;?>" id="qty<?= $table->item_id;?>" onkeyup=mult(<?= $table->item_id;?>); style="width:45px" required="required"></td>
                                                <td id="item_price<?= $table->item_id;?>"><?=$table->item_price;?></td>
                                                <td><input type="text" name="tprice" id="tprice<?= $table->item_id;?>" value="<?= $tprice;?>" style="width:85px; border:none; background-color:rgb(240,240,240)" readonly></td>
                                                <td><button type="button" class="btn btn-danger btn-sm deleteID"  
									data-id="<?= $table->id;?>"><i class="fa fa-trash"></i></button></td>
                                                
                                            </tr>
											<?php
								              }
	                                        ?>
                                    </tbody>
                                    </table>
                                    <table>
                                        <tr>
                                        <th col=4>
                                        <span id="totaly" style="margin-left:450px;"></span>
                                        </th>
                                        </tr>
                                </table>
                                </div>
                            </div>
                        </div>
                         <div class="form-group row">
                            <div class="col-md-8">
                                <select name="account" id="account" class="form-control" hidden>
                                    <option value="">--Select Account Receivable--</option>
                                    <?php foreach ($account as $ac): ?>
                                        <option value="<?= $ac->id; ?>" <?php if($tabledata[0]->account_receivable == $ac->id){ echo "selected";}?>><?= $ac->account_name; ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                        </div>
						<div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-8">
                               
                                <button type="submit" class="btn btn-primary float-right">Update</button>
                            </div>
                        </div>

                        </form>
        </div>
    </div>
			 <div id="ments" class="tab-pane">
            <div id="updacc2"></div>
            <form class="form-horizontal" id="read">
                
                <input type="hidden" class="form-control" name="id" id="id" value="<?= $acc->hostel_id; ?>">
                <div class="form-group row">
                              <label class="col-md-2 col-form-label">Installment term<span class="text-danger"></span></label>
                                <div class="col-md-2">
                                    <?php $terms = $csmodel->get_all_terms();?>
                                   <select name="install1" class="form-select">
                                    <option value="" selected>select</option>
                                    <?php foreach($terms as $term){?>
                                      <option value="<?php echo $term->id;?>"><?php echo $term->term_name; ?></option>
                                      <?php } ?> 
                                   </select>
                                </div>
                                
                               <label class="col-md-1 col-form-label">Amount<span class="text-danger"></span></label>
                                <div class="col-md-2">
                                    <input type="number"  class="form-control" name="amount1" id="amount" placeholder="">
									<span class="text-danger" id="morethan"></span>
                                </div>
								<!-- <label class="col-md-1 col-form-label">Duedate<span class="text-danger"></span></label>
								 <div class="col-md-2">
                                    <input type="date" class="form-control" name="duedate1" placeholder="Duedate" id="duedate">
                                </div> -->
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-primary st" id="installupdate"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>
							<div class="row">
                                <div class="col-md-2"></div>
                                <div class="col-md-12">
                                    <div class="card">
                                        <p Class=" d-flex justify-content-center mt-3">TERMS INSTALLMENT(S)</p>
                                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="">
                                        <thead>
                                                <tr>
                                                    
                                                    <th>Installment Name</th>
                                                    <th>Amount</th>
                                                    <th>Due Date</th>
                                                    
                                                    <th>Action</th>
                                                    
                                                </tr>
                                        </thead>
                                        <tbody id="showtbody">

                                    </tbody>
										
                                        </table>
										<table>
										<tr>
										<th col=4>
										<span id="rem" style="margin-left:200px;"></span>
										</th>
										</tr>
							        </table>
                                    </div>
                                </div>
                            </div>
							
                <div class="form-group row">
                    <label class="col-md-2 col-form-label"></label>
                    <div class="col-md-9">
                        <button type="button" class="btn btn-primary float-right" onclick="submitData2()">Update</button>
                    </div>
                </div>

            </form>
        </div>
	
</div>



  
<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
    var hold_selected_items = []; // hold all selected items

    $(document).ready(function(){
		fetch_installment_data();
         $('#js-example-data-ajax').select2({
            ajax: {
                url: "<?= base_url('load_accomodation'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            },
             escapeMarkup: function (markup) {
                        return markup; // Don't escape HTML
                        },
                        templateResult: function (data) {
                        return data.text; // Render the full HTML in 'text'
                        },
        });

        $('#js-example-data-ajax').on('select2:select', function (e) {
            selectedItems();
        });
        //var prc; 
        function selectedItems(){ 
           var hostelId = $('#hostelId').val();		
            var rows = '';
           var itemData = 'item_selected='+$('#js-example-data-ajax').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Accomodationdata2')?>/"+hostelId,   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
						 $('#result').html('The Item Already Selected.'); 
                        //alert('The Item Already Selected');
                    }else{
						$('#result').html(' ');
                        var len  = data.length;
                        
                        for (var i = 0; i <len; i++ ){
                            hold_selected_items.push(data[i]['id']);// push all selected items
                            var prc = data[i]['iprice'];
							price= prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
                            var name = data[i]['iname'];
                            var size = data[i]['isize'];
                            var attribute = data[i]['iattribute'];
                            var iid = data[i]['id'];
                            //var qty = window.prompt("Enter quantity");
                            //var tprice = qty*prc;
                           
                            
                            rows += '<tr id="table_row'+ iid +'">';

                           rows+='<td><input type="hidden" name="id[]" value="'+iid+'">'+ iid +'</td>';
							
                            rows += '<td>'+ name +'</td>';
                            rows += '<td>'+ attribute +'</td>';
                            rows += '<td>'+ size +'</td>';
                            rows += '<td>'+ 1 +'</td>';
                            rows += '<td><input type="text" name="qty'+iid+'" id="qty'+iid+'" onchange=mult('+iid+'); style="width:45px" required="required"></td>';
                            rows += '<td id="item_price'+iid+'">'+ prc +'</td>';
                            rows += '<td><input type="text" name="tprice" id="tprice'+iid+'" style="width:85px; border:none; background-color:rgb(240,240,240)" readonly></td>';

                            rows += '<td><a href="javascript:RemoveSelectItemRow('+iid+');" class="btn btn-danger">X</a></td>';
							
                            rows += '</tr>';
                            $('#show_item').append(rows);
                        }
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }
				
           });  
        }

    });
function mult(iid){
	var totalPrice = $('#qty'+iid).val()* $('#item_price'+iid).html()        
	document.getElementById('tprice'+iid).value = 		
	totalPrice.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 	
}		
    function RemoveSelectItemRow(item_id){
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }

        $('#table_row'+item_id).remove();
    }


    $('#updateAccomodate').submit(function(e){
		var Data=$(this).serialize();
       
           //alert(Data);

        $.ajax({
            method: 'POST',
            url: '<?= base_url('editAccomodationHostel')?>',
            data: Data,
			dataType: 'json',
            success:function(data){
			$('#updacc1').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
                setTimeout(function(){
            window.location.reload();
        },1000)
            },
            error:function(data){
				$('#updacc1').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
          setTimeout(function(){
            window.location.reload();
        },1000)
            }
        });
        
        e.preventDefault();
    });
	
	$('#updateTable').submit(function(e){
		var Data=$(this).serialize();
       
           //alert(Data);

        $.ajax({
            method: 'POST',
            url: '<?= base_url('editAccomodationItems')?>',
            data: Data,
			dataType: 'json',
             success:function(res){
			$('#success').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
                setTimeout(function(){
            window.location.reload();
        },1000)
            },
            error:function(res){
				$('#success').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
          setTimeout(function(){
            window.location.reload();
        },1000)
            }
        });
        
        e.preventDefault();
    }); 
	
	$(".deleteID").click(function(){

        var id = $(this).attr('data-id');
        //alert (id);
      
           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this item!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/deletehostelItem')?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      // $("#"+id).remove();
					 fetch_installment_data();
                    swal("Deleted!", "Item deleted.", "success");
                    //location.reload(true);
                    $("#"+id).remove();  
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
	
	$('#installupdate').click(function(event){
        var id=<?= $acc->hostel_id; ?>;
       var data = 'installname=' + $('select[name=install1]').val() + '&amount=' + $('input[name=amount1]').val()+ '&id=' + $('input[name=id]').val();
       //alert(ttl);
	   if(ttl==undefined){
		remain=10000000;
	   }
	   //alert(remain);
	   var enteredAmount=$('input[name=amount1]').val();
	   
	   var present=remain-enteredAmount;
	   //alert(present);
       if(present>=0){
		 document.getElementById("morethan").innerHTML="";  
       $.ajax({
            type: 'POST',
            url: 'addinstallments2/'+id,
            data: data,
            success:function(data){
                 if(data==1){
                alert("Term, Already Selected");
                present=remain+enteredAmount;
                }
                fetch_installment_data();
            }
       });
      }else{
		document.getElementById("morethan").innerHTML="Enter less amount or equal to "+remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
     // $('input[name=amount1]').val()="";	  
	  }
        event.preventDefault();
    });
	var ttl;
	var remain;
 function fetch_installment_data(){
        $('#showtbody').empty();
				
        var datta = 'acc_id=<?= $acc->hostel_id; ?>';
		//alert(data);
        $.ajax({
            type: 'GET',
            data: datta,
            url: 'fetchinstallments2',
            success:function(response){

                var ments_data = JSON.parse(response);
                var len = ments_data.length;
                //total=fetch_class_itemsCharged();
				var ttlamount=0;
                for(var i = 0; i < len; i++){
					total=ments_data[0]['tprice'];
					var amounted=parseInt(ments_data[i]['amount']);
					ttlamount=parseInt(ttlamount+amounted);
                    $('#showtbody').append('<tr>'+
                        
                        '<td>'+ments_data[i]['installname']+'</td>\
                        <td>'+ments_data[i]['amount']+'</td>\
                        <td>'+ments_data[i]['due_date']+'</td>\
                        <td>\
                            <a href="javascript:RemoveRow('+ments_data[i]['id']+','+total+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
		//total=window.sum;
		total=ments_data[0]['tprice'];
		remain=total-ttlamount;
		ttl=remain;
        document.getElementById("rem").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        document.getElementById("totaly").innerHTML = "Total = " + total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(total);
            }
        });
		
    }
	 function RemoveRow(id,total){

        $.ajax({
            type: 'GET',
            url: 'deleteMents/'+id,
            success: function(){
                
				alert('deleted successfuly');
		 remain= total;
         document.getElementById("rem").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(remain);
		 fetch_installment_data();
            }
        });

    }
	function submitData2(){
        $('#updacc2').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
        setTimeout(function(){
            window.location.reload();
        },1000)
    }

      function setAgeFilter(){
        var strt = $('input[name=start]').val();
        
        var fnsh = $('input[name=fnsh]').val();
        
        $('.age-btn span').html(strt + 'yrs - ' + fnsh+'yrs');
        CloseWindow('sethour');
        $('sethour').hide();
    }

        function FinishCheck(){
        var strtVal = $('input[name=start]').val();
        var fnshVal = $('input[name=fnsh]').val();
        
            $('input[name=fnsh]').attr('min',strtVal);
            if(fnshVal < strtVal){
                $('input[name=fnsh]').attr('value',strtVal);
            }
            }
        
     
    function CloseWindow(wndw){
        $('#'+wndw).hide(200);
    }
     function showWindow(wndw){
        $('#'+wndw).show(200);
    }
</script>