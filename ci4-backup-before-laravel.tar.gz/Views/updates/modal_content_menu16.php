<style type="text/css">
	.btn.btn-success:hover {
  color: yellowgreen;
  background: blue;
}
	
</style>
<p>This is the content for transport.</p>


<div class="row mt-5 mb-3">
      <div class="col"></div>
        <div class="col-md-6 text-center">
          <a href="#" onclick="tg_help()" class="btn btn-success">READ MORE </a>
        </div>
      <div class="col"></div>
    </div>