
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 

    $comodel = new App\Models\CompanyModel();
    $smodel=new App\Models\StudentModel;

    //$charged_item = $cmodel->items_chargedList();
?>



<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Job tittle</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Job tittle</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Company-tab" data-toggle="tab" href="#Company-all">Job tittle</a></li>
                <li class="nav-item"><a class="nav-link" id="Company-tab" data-toggle="tab" href="#Company-add">Add Job tittle</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Company-tab" data-toggle="tab" href="#Company-all">Job tittle</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Company-tab" data-toggle="tab" href="#Company-add">Add Job tittle</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>


<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="Company-all">

                <div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                    <th>No.#</th>
                                    <th>Job tittle</th>
                                   <th>Updated By</th>
                                    <th>Updated Date</th>
                                  <th>Action</th>
                                </tr>
                            </thead>
                            <tbody style="padding:1px;">
                                <?php 
                                 $i=0;
                                foreach($dep as $camp){ 
                                    $i++;
                                   $by = $smodel->gettable_data('users',$where = array('user_id' => $camp->created_by));
                                  
                                    ?>
                                   <tr>
                                       <td><?=$i?></td>
                                  
                                        <td><?php echo $camp->job_tittle;?></td>
                                        <td><?php echo $by[0]->first_name." ".$by[0]->last_name;?></td>
                                      
                                        <td><?php echo $camp->created_date;?></td>
                                        <td><a href="javascript:void(0)" onclick="edit_job_tittle(<?php echo $camp->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>

                                            <a href="javascript:void(0)" onclick="view_tittle(<?php echo $camp->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a>
                                          <!-- <button type="button" class="btn btn-danger btn-sm deleteID"  
                                    data-id="<?php //echo $camp->id;?>"><i class="fa fa-trash"></i></button> -->
                                        </td>
                                        
                                    </tr>
                                <?php } ?>
                            </tbody>
                            </table>
                                
            </div>
            </div>
            </div>
            <div class="tab-pane" id="Company-add">
        <div class="card">
            <div class="card-header" style="height:5px">
                <h3 class="card-title">New Job tittle</h3>
                <div class="card-options ">
                    <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                </div>
            </div>
            <hr>
            <form class="card-body form-horizontal needs-validation"  id="AddJob" method="post" enctype="multipart/form-data" novalidate>
            <div id="accfbk" class="text-success"></div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Job tittle<span class="text-danger">*</span></label>
                    <div class="col-md-5">
                        <input type="text" id="job_name" class="form-control" name="job_name" required="required">
                    <span id="company" class="text-danger"></span>
                    <div class="invalid-feedback">Job tittle Name is required.</div>
                    </div>
                </div>

                        
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-5">
                               
                                <button type="submit" id="savebtn" class="btn btn-primary float-right">Save</button>
                            </div>
                        </div>
                    </form>
                   
                </div>

            </div>

        </div>
    </div>
</div>
<div class="modal fade" id="Editjob_tittle" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content" style="width:900px;margin-left: 100px;">
      <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel"><center>Edit Job Tittle Details</center></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="EditTittle_content">
            <div id="updatemsg"></div>
        <form id="editdata" class="card-body needs-validation form-horizontal" novalidate>
            <div class="form-group row">
               <input type="hidden" id="tittle_id" name="tittle_id">
               <label class="col-md-3 col-form-label">Job tittle Name<span class="text-danger">*</span></label>
               <div class="col-md-5">
    <input type="text" id="tittle_name" name="tittle_name" class="form-control" required>
    <div class="invalid-feedback">Job tittle Name is required.</div>
    </div> 
            </div>
             <div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-5">
                             
    <input type="submit" name="submit" value="Save Changes" class="btn btn-primary float-right">
</div>
</div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
    </div>
  </div>
</div>
<div class="modal fade" id="viewjob_tittle" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content" style="width:900px;margin-left: 100px;">
      <div class="modal-header">
         <!--  <h5 class="modal-title" id="staticBackdropLabel"><center>view Company Details</center></h5> -->
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewjob_tittle_content">
      </div>
      <!-- <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save</button>--
      </div> -->
    </div>
  </div>
</div>
<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
   $('#AddJob').submit(function(e){
    e.preventDefault();
       if (!this.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
            this.classList.add("was-validated");
            }
             else{ 
        var Data=$(this).serialize();

        $.ajax({
          url: "<?= base_url().'/index.php/StaffController/add_job_tittle'; ?>",
            type: 'POST',
            data: Data,
            
            success:function(data){
                if(data==1){
                    swal("job is Already present");
                }else{
                 $("#AddJob")[0].reset();
                     $('#accfbk').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Saved successfuly.</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                    setTimeout(function(){
                        window.location.reload();
                    },2000)
                }
            },
            error:function(){
                $('#accfbk').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Save Company.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
            }
        });  
        
    }}); 

    var loadFile = function(event) {
    var output = document.getElementById('output1');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output1.src) // free memory
    }
  }; 

    var loadFile = function(event) {
    var output = document.getElementById('output1');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output1.src) // free memory
    }
  }; 

    function edit_job_tittle(id) {
    $.getJSON("<?= base_url('edit-job_tittle'); ?>/" + id, 
        function(data) {
         $('#tittle_id').val(data[0].id);
        $('#tittle_name').val(data[0].job_tittle);
        $('#Editjob_tittle').modal('show');
    });
}

 function view_tittle(id){
                $('#viewjob_tittle').modal('show'); 
        $('#viewjob_tittle_content').load('view-job_tittle/'+id);
       
    } 

     $('#editdata').submit(function(event){
         event.preventDefault();
            if (!this.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
            this.classList.add("was-validated");
            }
             else{ 
         
  $.ajax({
        type:"POST",
        url:"<?= base_url('update-job_tittle')?>",
        data:$(this).serialize(),
        dataType: 'json',
        success:function(res){
          if(res.message==1){
                $('#editdata')[0].reset();
                $('#updatemsg').html('<div class="alert alert-success alert-dismissible " role="alert"><strong>Success! </strong> Job tittle updated sucessfully.</div>')
                .stop(true, true)
                .show()
                .delay(3000)
                .fadeOut();
                     setTimeout(function(){
                    window.location.reload();
                },4000);
            }else{
            $('#updatemsg').html('<div class="alert alert-warning alert-dismissible " role="alert"><strong>Sorry! </strong> Could not Update job tittle.</div>')
              .stop(true, true)
                .show()
                .delay(3000)
                .fadeOut();   
            }
        },
        error:function(){
            $('#updatemsg').html('<div class="alert alert-danger alert-dismissible " role="alert"><strong> Denied!</strong> Something went Wrong.</div>').
            stop(true, true)
                .show()
                .delay(3000)
                .fadeOut();     
        }
  });
}});
</script>