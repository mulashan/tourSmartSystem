<?php 
$bmodel = new App\Models\BillingModel();
    $comodel = new App\Models\CompanyModel();
    $smodel=new App\Models\StudentModel;
$classification = $smodel->gettable_data('classification_tbl',$where = array('id >' => 0));
$company = $bmodel->get_table_details('company_tbl');
 helper('results_helper');
?>

<style>
table.emoluments, th.emoluments{
   
    background-color: #d9ead3;
}table.emoluments, td.emoluments{
   
    background-color: #d9ead3;
}
table.social, th.social{
  
    background-color: #d9d9d9;
}
table.social, td.social{
  
    background-color: #d9d9d9;
}
table.tax, th.tax{
    
    background-color: #f9cb9c;
}table.net_salary, th.net_salary{
    
    background-color: #fed966;
}table.net_salary, td.net_salary{
    
    background-color: #fed966;
}
td{
    border: 1px solid black;
}
th{
    border: 1px solid black;
}
table.centa, th.centa{
    text-align: center;
}
table.paysummary, th.paysummary{
    border: 1px solid black;
}
</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Payroll</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Payroll</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Payroll-tab" data-toggle="tab" href="#Payroll-all">Payroll List</a></li>
                <li class="nav-item"><a class="nav-link" id="Payroll-tab" data-toggle="tab" href="#Payroll-add">New Payroll</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Payroll-tab" data-toggle="tab" href="#Payroll-all">Payroll List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Payroll-tab" data-toggle="tab" href="#Payroll-add">New Payroll</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>


<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="Payroll-all">

                <div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                   
                                    <th>payroll no</th>
                                   <th>Payroll Date</th>
                                   <th>Payroll Year</th>
                                   <th>Pay Month</th>
                                   <th>Gross</th>
                                   <th>Status</th>
                                   <th>Updated by</th>
                                   <th>Update date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody style="padding:1px;">
                               
                       <?php
                         if(isset($payrolls)):
                                   $total_amount=0;
                            foreach($payrolls as $payroll):
                                $gross_salary=$payroll->allowances+$payroll->basic_salary;
                                $total_amount +=$gross_salary;
                       ?>
                        <tr>
                       <td><?=$payroll->payroll_id?></td>
                       <td><?=$payroll->payroll_date?></td>
                       <td><?=$payroll->payroll_year?></td>
                       <td><?=$payroll->month;?></td>
                       <td><?=format_number_with_decimals($gross_salary);?></td>
                       <?php
                       $app_status ='';
                       if(isset($payroll_status)){
                     foreach ($payroll_status as $appstatus) {
        if ($appstatus->trans_no == $payroll->transaction_id) {
           if($appstatus->hstatus==3 && $appstatus->user_role==1){
               $app_status ='<span class="text-danger fw-bold">Pending</span>';
           }else if($appstatus->hstatus==1 && $appstatus->user_role==3){
 $app_status ='<span class="text-success fw-bold">Approved</span>';
           }elseif($appstatus->hstatus==2 && $appstatus->user_role==3){
 $app_status ='<span class="text-danger fw-bold">Rejected</span>';
           }
            break;
        }
    }
}
                       ?>
                       <td><?= $app_status?></td>
                       <td><?=$payroll->first_name?>
                       <?=$payroll->last_name?></td>
                        <td><?=$payroll->create_date?></td>
                        <td>
  <a href="javascript:void(0)" onclick="view_payroll(<?php echo $payroll->payroll_id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a> 
                        </td>
                              </tr>                
                       <?php
                   endforeach;
               endif;
                       ?>
                       
                            </tbody>
                            </table>
                                
            </div>
            </div>
            </div>
            <div class="tab-pane" id="Payroll-add">
        <div class="card">
            <div class="card-header" style="height:5px">
                <h3 class="card-title">New Payroll</h3>
                <div class="card-options ">
                    <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                </div>
            </div>
            <hr>
      <div class="card-body">
    <div class="row">
        <div class="col-md-6">
         <form id="meta_data" method="post"  class="needs-validation" novalidate>  
  <div class="card">
         <div class="card-body">
            <center>
                <div id="save_status"></div>
                <div id="savemsg"></div>
               
            <div class="row mb-3">
          <label for="year" class="col-sm-4 ms-3 col-form-label col-form-label-sm">Payroll Year:<span class="text-danger">*</span></label>
                  <div class="col-sm-6">
                   <select id="year" name="year" class="payroll-select form-control form-control-sm align-items-center year-dropdown" required>
                                    <?php
                                    $initial_year=2023;
                                    $current_year=date('Y');
                                    $final_year=$current_year+1;
                                    for ($initial_year; $initial_year <=$final_year ; $initial_year++) { 
                                
                                    ?>
                        <?php if($initial_year == $current_year){?>
                                    <option value="<?=$initial_year;?>" selected><?=$initial_year;?></option>
                                    <?php
                                           }else{
                                    ?>
                                    <option value="<?=$initial_year;?>" ><?=$initial_year;?></option>
                                    <?php
                                        }
                                    ?>

                                    <?php

                                       }
                                    ?>
         
                          </select>
                           <div class="invalid-feedback">Payroll Year required.</div>
                               </div>
                                   </div>
                        <div class="row mb-3">
          <label for="month" style='color: black; font-weight: normal;' class="col-sm-4 ms-3 col-form-label col-form-label-sm">Payroll Month:<span class="text-danger">*</span></label>
                  <div class="col-sm-6">
                 <select id="month" name="month" class="payroll-select form-control form-control-sm align-items-center" required>

                         <option value="" selected disabled >--please Select--</option>
             <?php             
                                if(isset($months)){
                              foreach($months as $info){
                                if($info->is_current==1){
                                    echo '<option value="'.$info->month_id. '"selected>' . $info->month . '</option>';     
                                }
                                else{
                                   echo '<option value="'.$info->month_id. '">' . $info->month . '</option>';   
                                }
                           
                              }}
                               ?>                    
                 </select>
                  <div class="invalid-feedback">Payroll Month required.</div>
                  <input type="hidden" name="month_name" id="month_name" value="">
                                                </div>
                    
                                            </div>


               <div class="row mb-3">
                      <label for="date" class="col-sm-4 ms-3 col-form-label col-form-label-sm">Payroll Date:<span class="text-danger">*</span></label>
                                     <div class="col-sm-4">
                     <input type="date" class="form-control form-control-sm" id="date" name="date" style="width: 200px;" autocomplete="off" required>
                      <div class="invalid-feedback">Payroll Date required.</div> 
                    </div>  
                      </div>
                <label for="class" class="col-sm-2 ms-3 col-form-label col-form-label-sm"><span class="text-danger"></span></label>
   </center>
</div>
</div>
</form>
<div id="summary_status">
    
</div>

</div>
<div class="col-md-6">
     <div class="row mb-3">
          <label for="year" class="col-sm-4 ms-3 col-form-label col-form-label-sm">Total by:<span class="text-danger">*</span></label>
                 <div class="col-sm-6">
                     <form id="total_by" method="post"  class="needs-validation" novalidate>
                 <select id="group" name="group" class="payroll-select form-control form-control-sm align-items-center" required>

                         <option value="0" selected>All</option>
                         <option value="1" >Department</option>
                         <option value="2" >Job Title</option>
                         <?php
                             if($company[0]->classification==1){
                         ?>
                         <option value="3" >Classification</option>
                    <?php
                }?>
                 </select>
                  <div class="invalid-feedback">Group required.</div>
              </form>
                                                </div>
          </div> 
</div>


    </div>
</div>
  <div class="card-body">
    <div class="row">

        <div id="salaryTable">
          <div id="salaryTable_status"></div>
         <div id="error_loading"></div>
          <form id="save_details" method="post"  class="needs-validation" novalidate>
              <div class="col-md-12">
                <div class="row mb-3">
                   <div class="table-responsive">
                       <div class="mb-4">
   
        <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; font-family: Arial; font-size: 14px; text-align: right;" id="salaryTableData">
    <thead>
        <tr>
                           <?php if (isset($company) && !empty($company)) {
                    if($company[0]->classification==1){
                ?>
            <th colspan="6" class="text-center">EMPLOYEE DETAILS</th>
            <?php
        }else{

           ?>
           <th colspan="5" class="text-center">EMPLOYEE DETAILS</th>
           <?php
       }}?>
            <th colspan="4" class="emoluments text-center">EMOLUMENTS</th>
            <th colspan="3" class="social text-center">SOCIAL SECURITY DEDUCTIONS</th>
            <th class="net_salary"></th>
             <?php if(session()->get('db_id')==17){?>
            <th colspan="8" class="tax text-center">TAX & OTHER DEDUCTIONS</th>
        <?php 
    }else{
            ?>
             <th colspan="3" class="tax text-center">TAX & OTHER DEDUCTIONS</th>
            <?php
        }
        ?>
            <th class="net_salary"></th>
           
        </tr>
        <tr>
            <th>S/N</th>
            <th>DEPARTMENT</th>
            <th>JOB TITLE</th>
             <?php if (isset($company) && !empty($company)) {
                    if($company[0]->classification==1){
                ?>
            <th>CLASSFICATION</th>
            <?php
}}
            ?>
            <th>NAMES</th>
            <th>STATUS</th>
            <th class="emoluments">B.SALARY</th>
            <th class="emoluments">OVER TIME</th>
            <th class="emoluments">ALLOWANCE</th>
            <th class="emoluments">GROSS</th>
            <th class="social">PENSION 10%</th>
            <th class="social">NHIF 3%</th>
            <th class="social">TOTAL SOCIAL</th>
            <th class="net_salary">NET BEFORE TAX</th>
            <th class="tax">PAYE</th>
            <th class="tax">HESLB</th>
            <th class="tax">ADVANCES</th>
       <?php if(session()->get('db_id')==17){?>
           <th class="tax">TUCTA</th>
            <th class="tax">HOUSING</th>
            <th class="tax">OTHER LOANS</th>
            <th class="tax">MAAFA</th>
            <th class="tax">ELECTRICITY</th>
        <?php
    }
    ?>
            <th class="net_salary">NET SALARY</th>
        </tr>
    </thead>
    <tbody>
<?php
    $i=0;
$total_basic_salary = 0;
$total_allowances = 0;
$total_gross_salary = 0;
$total_nssf = 0;
$total_nhif = 0;
$ctotal_social = 0;
$cumulate_nbt=0;
$cumulate_paye=0;
$callowance=0;
$cadvances=0;
$cumulate_net_salary=0;
$wcf=0;
$total_heslb=0;
$total_overtime=0;
$total_housing=0;
$total_tucta=0;
$total_maafa=0;
$total_loans=0;
$total_electricity=0;
if(isset($all_staff) && !empty($all_staff)):
    foreach($all_staff as $staffs):
         $row_style = ($staffs->status == 4) ? 'class="text-danger"' : '';
        $i++;
        $overtime = 0;
if (isset($over_time)) {
    foreach ($over_time as $ovt) {
        if ($ovt->staff_id == $staffs->user_id) {
            $overtime = $ovt->overtime_amount;
            break;
        }
    }
}
$housing=0;
$tucta=0;
$loans=0;
$electricity = 0;
$maafa=0;
        $gross=$staffs->basic_salary + $staffs->allowances+$overtime;
  if(session()->get('db_id')==17){
$housing=$staffs->housing;

if($staffs->tucta_status==1){
$tucta=$staffs->basic_salary*(2/100);
}
$maafa=$staffs->maafa;
if (isset($electricity_charge)) {
    foreach ($electricity_charge as $echarge) {
        if ($echarge->staff_id == $staffs->user_id) {
            $electricity = $echarge->charge_amount;
            break;
        }
    }
}

if (isset($loans_dedutions)) {
    foreach ($loans_dedutions as $loan_dedu) {
        if ($loan_dedu->staff_id == $staffs->user_id) {
            $loans = $loan_dedu->loan_amount;
            break;
        }
    }
}
  }

    if($staffs->pension_pay_status==""|| $staffs->pension_pay_status==0){
  $nssf=0;
    }else{
    $nssf=$gross*(10/100);      
    }
      
        if($staffs->basic_salary<0 || $staffs->nhif_pay_status=="" || $staffs->nhif_pay_status==0){
        $nhif=0;
        }
        elseif($staffs->basic_salary<666666.67 && $staffs->basic_salary!=0){
            $nhif=20000;
        }
        else{
            $nhif=$staffs->basic_salary*(3/100);
        }
  if($staffs->heslb_pay_status==""|| $staffs->heslb_pay_status==0){
  $heslb=0;
    }else{
    $heslb=$staffs->basic_salary*(15/100);      
    }
        
$total_basic_salary += $staffs->basic_salary;
$total_allowances += $staffs->allowances;
$total_social=$nssf+$nhif;
$total_gross_salary += $gross;
$wcf = $total_gross_salary*0.005;
$total_nssf += $nssf;
$total_nhif += $nhif;
$ctotal_social += $total_social;
$total_heslb +=$heslb;
$total_housing+=$housing;
$total_tucta+=$tucta;
$total_maafa+=$maafa;
$total_loans+=$loans;
$total_electricity+=$electricity;
$salaryadvance = 0;
if (isset($salary_advances)) {
    foreach ($salary_advances as $advanc) {
        if ($advanc->staff_id == $staffs->user_id) {
            $salaryadvance = $advanc->advance_amount;
            break;
        }
    }
}

$cadvances += $salaryadvance;
$total_overtime += $overtime;
$nbt =$gross-$total_social;
$cumulate_nbt+=$nbt;
$paye=calculate_paye($nbt, $brackets);
$cumulate_paye+=$paye;
$callowance+=$staffs->allowances;
$net_salary=$nbt - ($paye + $heslb + $salaryadvance+$housing+$tucta+$loans+$maafa+$electricity);
$cumulate_net_salary+=$net_salary;
$wcf_data = $gross*0.005;
        ?>
        <tr <?= $row_style; ?>>
  
            <td><?=$i;?></td>
               <input type="hidden" name="staff_id[]" value="<?=$staffs->user_id?>">
    <input type="hidden" name="49<?=$staffs->user_id?>" value="<?=$staffs->basic_salary;?>">
    <input type="hidden" name="50<?=$staffs->user_id?>" value="<?=$staffs->allowances;?>">
    <input type="hidden" name="43<?=$staffs->user_id?>" value="<?=$nssf;?>">
    <input type="hidden" name="51<?=$staffs->user_id?>" value="<?=$nhif;?>">
       <input type="hidden" name="55<?=$staffs->user_id?>" value="<?=$heslb;?>">
    <input type="hidden" name="paye[]" value="<?=$paye;?>">
    <input type="hidden" name="48<?=$staffs->user_id?>" value="<?=$salaryadvance;?>">
    <input type="hidden" name="54<?=$staffs->user_id?>" value="<?=$net_salary;?>">
      <?php if(session()->get('db_id')==17){?>
 <input type="hidden" name="56<?=$staffs->user_id?>" value="<?=$maafa;?>">
 <input type="hidden" name="57<?=$staffs->user_id?>" value="<?=$housing;?>">
 <input type="hidden" name="58<?=$staffs->user_id?>" value="<?=$tucta;?>">
 <input type="hidden" name="59<?=$staffs->user_id?>" value="<?=$loans;?>">
 <input type="hidden" name="60<?=$staffs->user_id?>" value="<?=$electricity;?>">

         <?php } if (isset($company) && !empty($company)) {
                    if($company[0]->wcf_status==1){
                ?>
    <input type="hidden" name="53<?=$staffs->user_id?>" value="<?=$wcf_data;?>">
    <?php
}else{
    ?>
      <input type="hidden" name="53<?=$staffs->user_id?>" value="0">
<?php
}
}
    ?>
    <input type="hidden" name="classfication[]" value="<?=$staffs->classfication_id;?>">
            <td style="text-align: left;"><?=$staffs->dep_name;?></td>
            <td style="text-align: left;"><?=$staffs->job_tittle;?></td>
<?php 
if (isset($company) && !empty($company)) {
    if ($company[0]->classification == 1) {
        $matched = false;
        foreach ($classification as $class) {
            if ($class->id == $staffs->classfication_id) {
                echo "<td class='text-center'>{$class->class_name}</td>";
                $matched = true;
                break;
            }
        }
        if (!$matched) {
            echo "<td class='text-center'> - </td>";
        }
    }
}
?>

            <td style="text-align: left;"><?=$staffs->first_name;?> <?=$staffs->last_name;?></td>
           <?php $status = "<span class='badge badge-{$staffs->status_color}'>{$staffs->status_name}</span>";?>
                                     <td class="text-center"><?=$status;?></td>
            <td class="emoluments"><?=format_number_with_decimals($staffs->basic_salary);?></td>
            <td class="emoluments"><?=format_number_with_decimals($overtime);?></td>
            <td class="emoluments"><?=format_number_with_decimals($staffs->allowances);?></td>
            <td class="emoluments"><b><?=format_number_with_decimals($gross);?></b></td>
            <td class="social"><?=format_number_with_decimals($nssf);?></td>
            <td class="social"><?=format_number_with_decimals($nhif);?></td>
            <td class="social"><b><?=format_number_with_decimals($total_social);?></b></td>
            <td class="net_salary"><b><?=format_number_with_decimals($nbt);?></b></td>
            <td><?=format_number_with_decimals($paye);?></td>
            <td><?=format_number_with_decimals($heslb);?></td>
            <td ><?=format_number_with_decimals($salaryadvance);?></td>
                   <?php if(session()->get('db_id')==17){?>  
            <td><?=format_number_with_decimals($tucta);?></td>
             <td><?=format_number_with_decimals($housing);?></td>
            <td ><?=format_number_with_decimals($loans);?></td>
            <td ><?=format_number_with_decimals($maafa);?></td>
            <td ><?=format_number_with_decimals($electricity);?></td>
                    <?php
                }
                ?>
            <td class="net_salary"><b><?=format_number_with_decimals($net_salary);?></b></td>

        </tr>

        <?php
    endforeach;

endif;
        ?>

          </tbody>
          <tfoot>
        <tr style="font-weight: bold;">
                     <?php if (isset($company) && !empty($company)) {
                    if($company[0]->classification==1){
                ?>
            <td colspan="6" style="text-align: center;">TOTAL</td>
                  <?php
        }else{

           ?>
           <td colspan="5" style="text-align: center;">OVERALL TOTAL</td>
           <?php
}}
           ?>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_basic_salary);?></td>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_overtime);?></td>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_allowances);?></td>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_gross_salary);?></td>
            <td class="social text-right"><?=format_number_with_decimals($total_nssf);?></td>
            <td class="social text-right"><?=format_number_with_decimals($total_nhif);?></td>
            <td class="social text-right"><?=format_number_with_decimals($ctotal_social);?></td>
            <td class="net_salary text-right"><?=format_number_with_decimals($cumulate_nbt);?></td>
            <td class="text-right"><?=format_number_with_decimals($cumulate_paye);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_heslb);?></td>
            <td class="text-right"><?=format_number_with_decimals($cadvances);?></td>
             <?php if(session()->get('db_id')==17){?>
           <td class="text-right"><?=format_number_with_decimals($total_tucta);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_housing);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_loans);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_maafa);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_electricity);?></td>
                <?php
            }
            ?>
            <td class="net_salary text-right"><?=format_number_with_decimals($cumulate_net_salary)?></td>
            
        </tr>
</tfoot>

</table>
<!-- ==============================save payroll details======================================================= -->

 
    <input type="hidden" name="transaction_id" value="10">
    <input type="hidden" name="transaction_type_id" value="1">


</div>
<!-- ==============================save payroll details======================================================= -->
   
                        </div>



                        </div>
                        </div>
</form>
  <form id="account_data" method="post"  class="needs-validation" novalidate>
                        <div class="col-md-8">
                        <div class="card">
                        <div class="card-body">
                            <h5>LEDGER ENTRIES</h5>
                            <div class="table-responsive">
                                        <div id="ledger_status"></div>
                                        <div id="error_loading"></div>
                                <div id="ledger_entries">    
                               
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>LEDGER NAME</th>
                                        <th>LEDGER TYPE</th>
                                        <th>DR AMOUNT</th>
                                        <th>CR AMOUNT</th>
                                    </tr>
                                </thead>
                                <tbody id="ledger_entries_body">

                                 <?php
                                 $total_dr = 0;
                                   $total_cr = 0;
                               if(isset($legers)){ 
                                    foreach($legers as $leger){
                                           $amount = 0;

switch (strtolower($leger->account_name)) {
    case 'net salaries payable':
        $amount = $cumulate_net_salary;
        break;
    case 'pension scheme payable':
        $amount = $total_nssf * 2;
        break;
    case 'nhif payable':
        $amount = $total_nhif * 2;
        break;
    case 'sdl payable':
        $amount = 0;
        break;
    case 'paye payable':
        $amount = $cumulate_paye;
        break;
    case 'wcf payable':
        $amount = $wcf;
        break;
    case 'salary advances':
        $amount = $cadvances;
        break;
    case 'pension scheme':
        $amount = $total_nssf;
        break;
    case 'nhif contribution':
        $amount = $total_nhif;
        break;
    case 'staff allowances':
        $amount = $total_allowances;
        break;
    case 'basic salaries':
        $amount = $total_basic_salary;
        break;
    case 'wcf contributions':
        $amount = $wcf;
        break; 
        case 'heslb payable':
        $amount = $total_heslb;
        break;
       case 'overtime':
        $amount = $total_overtime;
        break;
        case 'maafa payable':
        $amount = $total_maafa;
        break;
        case 'other loans payable':
        $amount = $total_loans;
        break;
        case 'housing payable':
        $amount = $total_housing;
        break;
        case 'tucta payable':
        $amount = $total_tucta;
        break;
             case 'electricity payable':
        $amount = $total_electricity;
        break;
    default:
        $amount = 0;
}


        if (strtolower($leger->type_name) == 'expense') {
                  $dr_amount = $amount;
            $cr_amount = 0;
            ?>
       <input type="hidden" name="amount<?=$leger->account_id;?>" value="<?=$dr_amount;?>">
       <input type="hidden" name="nature<?=$leger->account_id;?>" value="2">
        <input type="hidden" name="type_id<?=$leger->account_id;?>" value="<?=$leger->typ_id;?>">
        <input type="hidden" name="institution<?=$leger->account_id;?>" value="<?=$leger->institution_id;?>">
    <input type="hidden" name="account_id[]" value="<?=$leger->account_id;?>">

            <?php
        } else {

             $dr_amount = 0;
            $cr_amount = $amount;
            ?>
                <input type="hidden" name="amount<?=$leger->account_id;?>" value="<?=$cr_amount;?>">
                 <input type="hidden" name="nature<?=$leger->account_id;?>" value="1">
                <input type="hidden" name="type_id<?=$leger->account_id;?>" value="<?=$leger->typ_id;?>">
                <input type="hidden" name="institution<?=$leger->account_id;?>" value="<?=$leger->institution_id;?>">
              <input type="hidden" name="account_id[]" value="<?=$leger->account_id;?>">

            <?php
        }

        $total_dr += $dr_amount;
        $total_cr += $cr_amount;
                                        ?>
                                        <tr>
                                        <td><?=$leger->account_name?></td>
                                    
                                        <td><?=$leger->type_name?></td>
                                        <td style="text-align:right;"><?= format_number_with_decimals($dr_amount) ?></td>
                                         <td style="text-align:right;"><?= format_number_with_decimals($cr_amount) ?></td>
                                        </tr>
                                        <?php
                                     }}
                                        ?>
                                      
                                   </tbody>
                                <tfoot>
            <tr style="font-weight:bold; background:#f0f0f0;">
    <td colspan="2" style="text-align:right;">TOTAL</td>
        <input type="hidden" name="total_amount" value="<?=$total_dr?>">
    <td style="text-align:right;"><?= format_number_with_decimals($total_dr) ?></td>
    <td style="text-align:right;"><?= format_number_with_decimals($total_cr) ?></td>

</tr>
                                </tfoot>
                                
                            </table>
                             </div>
                            </div>

                        </div>
                        </div>

                        </div>
          <div class="text-end">
  <button type="submit" class="btn btn-primary btn-lg">
    <i class="fa fa-save me-2"></i> Create
  </button>
</div>

                                      
</form> 
</div>
                        </div>
                        </div>
                   
                </div>

            </div>
<!-- ============================================================================================ -->
<div class="modal fade" id="view_payrolls" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
         <!--  <h5 class="modal-title" id="staticBackdropLabel"><center>view Company Details</center></h5> -->
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="view_payrolls_content">
      </div>
      <!-- <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save</button>--
      </div> -->
    </div>
  </div>
</div>
<!-- ============================================================================================ -->
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    $('.payroll-select').select2();
});


    var loadFile = function(event) {
    var output = document.getElementById('output1');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output1.src) // free memory
    }
  }; 
  function edit_depertment(id) {
    $.getJSON("<?= base_url('edit-depertment'); ?>/" + id, 
        function(data) {
         $('#department_id').val(data[0].id);
        $('#department_name').val(data[0].dep_name);
        $('#EditDepertment').modal('show');
    });
}

 function view_depertment(id){
                $('#viewDepertment').modal('show'); 
        $('#viewDepertment_content').load('view-depertment/'+id);
       
    } 
    var loadFile = function(event) {
    var output = document.getElementById('output1');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output1.src) // free memory
    }
  }; 

     $('#editdata').submit(function(event){
         event.preventDefault();
            if (!this.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
            this.classList.add("was-validated");
            }
             else{ 
         
  $.ajax({
        type:"POST",
        url:"<?= base_url('update-depertment')?>",
        data:$(this).serialize(),
        dataType: 'json',
        success:function(res){
          if(res.message==1){
                $('#editdata')[0].reset();
                $('#updatemsg').html('<div class="alert alert-success alert-dismissible " role="alert"><strong>Success!</strong>Department updated sucessfully.</div>')
                .stop(true, true)
                .show()
                .delay(3000)
                .fadeOut();
                     setTimeout(function(){
                    window.location.reload();
                },4000);
            }else{
            $('#updatemsg').html('<div class="alert alert-warning alert-dismissible " role="alert"><strong>Sorry!</strong> Could not Update Department.</div>')
              .stop(true, true)
                .show()
                .delay(3000)
                .fadeOut();   
            }
        },
        error:function(){
            $('#updatemsg').html('<div class="alert alert-danger alert-dismissible " role="alert"><strong>Denied!</strong> Something went Wrong.</div>').
            stop(true, true)
                .show()
                .delay(3000)
                .fadeOut();     
        }
  });
}});

// $(document).ready(function() {
//     $('#salaryTable').DataTable({
//         "pageLength": 10,           // Number of rows per page
//         "lengthChange": false,      // Hide page length change dropdown (optional)
//         "searching": true,          // Enable search
//         "ordering": true            // Enable column sorting
//     });
// });

// ==================================save payroll details======================
$(document).ready(function () {
    $('#account_data').submit(function (event) {
         var date=$('#date').val();
        event.preventDefault();
    if (!this.checkValidity() || date.trim() === '') {
            event.stopPropagation();
            if (date.trim() === '') {
                $('#savemsg').html('<div class="alert alert-warning" role="alert"><strong>Warning!</strong> Please select a valid date.</div>')
                    .stop(true, true)
                    .show()
                    .delay(5000)
                    .fadeOut();
            }

            this.classList.add("was-validated");
            $("html, body").animate({ scrollTop: 0 }, "slow");
            return;
        }
     //   var Data = $('#meta_data').serialize() + '&' + $('#save_details').serialize();

var data1 = $('#meta_data').serialize();
var data2 = $('#save_details').serialize();
 var data3 = $('#account_data').serialize();
var month = $('#month option:selected').text();
let selectedMonth = $('#month').val();
let selectedYear  = $('#year').val(); 
var date = $('#date').val();


           var Data = data3+'&'+data1+'&'+data2;

        $.ajax({
            url: "<?= base_url().'/add-payroll'; ?>",
            type: 'POST',
            data: Data,
               dataType: 'json',
                  beforeSend: function () {
            Swal.fire({
                title: 'Please wait...',
                html: '<span class="text-info"> Saving '+month+' '+selectedYear+ ' payroll please wait..</span>',
                icon: 'info',
                showConfirmButton: false,
                timerProgressBar: true,
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
        },
            success: function (response) {
                if(response.status===1){
       Swal.close();
            swal({
               title: "The "+month+" "+selectedYear+ " Payroll saved successfuly",
                        type: "success",
                 confirmButtonText: "OK",
        closeOnConfirm: true
            },
            function(){
           
                window.location.reload();
    }            );
                }
                else{
        Swal.close();
swal({
    title:"Failed to saved "+month+" "+selectedYear+ " payroll!",
                type: "error",
                 confirmButtonText: "OK",
        closeOnConfirm: true
    },
            function(){
           
                window.location.reload();
    }

    ); 
                }
       
            },
            error: function () {
         Swal.close();
swal({
    title: "Something went wrong!",
    type: "error",
    confirmButtonText: "OK",
    closeOnConfirm: true
}, function() {
    window.location.reload();
});

            }
        });
    });
});

$('#month').change(function() {
    var selectedMonth = $(this).val();
    var selectedYear = $('#year').val();
$('#total_by')[0].reset();
  $('#group').val("0").trigger("change");
    if (selectedMonth !== "") {
        $.ajax({
            url: "<?= base_url('fetch-payroll-staff'); ?>",
            method: "POST",
            data: {
                month: selectedMonth,
                year: selectedYear
            },
            beforeSend: function () {
    $('#salaryTable_status').html('<span class="spinner-border spinner-border-sm"></span> Loading please wait..');
    $('#summary_status').html('<span class="spinner-border spinner-border-sm"></span> Loading please wait..');
 $('#ledger_status').html('<span class="spinner-border spinner-border-sm"></span> Loading please wait..');
            $('#salaryTable').html('');
            $('#summary_table_container').html('');
            $('#ledger_entries').html('');
           $('#error_loading').html('');
           
            },
            success: function(response) {
          $('#salaryTable_status').html('');
           $('#summary_status').html('');
           $('#ledger_status').html('');
           $('#error_loading').html('');
                $('#salaryTable').html(response.tableBody);
                $('#summary_table_container').html(response.summaryHtml);
                $('#ledger_entries').html(response.ledgerentries);
            },
              error: function (xhr, status, error) {
                   $('#salaryTable_status').html('');
           $('#summary_status').html('');
           $('#ledger_status').html('');
              $('#salaryTable').html('');
            $('#summary_table_container').html('');
            $('#ledger_entries').html('');
                    $('#error_loading').html('<div class="alert alert-danger" role="alert">' +
            '<strong>Error:</strong> Unable to load staff Payroll data.<br>' +
            'Status: ' + xhr.status + ' ' + xhr.statusText + '<br>' +
            'Details: ' + error +
        '</div>');;
               }
        });
    }
});

$(document).ready(function () {
$('#group').change(function() {
    var group = $(this).val();
     var selectedMonth = $('#month').val();
    var selectedYear = $('#year').val();
      if (selectedMonth == "" && group !== "" && selectedYear== "") {
        return;
}else{
loadGrouped(group,selectedMonth,selectedYear);
}
    
});
});


function loadGrouped(group, month, year) {
  $.ajax({
    url: "<?= base_url('get_grouped_data'); ?>",
    type: "POST",
    data: { 
        group: group,
        month: month,
        year: year
     },
    dataType: "json",
    success: function(response) {
      let tbody = "";
      let groupedStaff = response.staffs;
      let taxBrackets = response.brackets;
      let ledgers = response.legers;
       let hasClass = response.hasClass;
       let hasWCF = response.hasWCF;
       let database_id = Number(response.database_id);
      $.each(groupedStaff, function(group, employees) {
        let total_gross = 0, total_basic = 0, total_allowances = 0;
        let total_nssf = 0, total_nhif = 0, total_heslb = 0;
        let total_nbt = 0, total_social = 0, total_advance = 0;
        let total_paye = 0;
        let total_tucta = 0;
        let total_housing = 0;
        let total_loans= 0;
        let total_maafa = 0;
        let total_electricity = 0;
        let total_netsalary = 0;
        if(group !=0){
            if(database_id===17){
tbody += `
  <tr class="table-light group-header">
    <td colspan="22" class="text-left font-weight-bold">
      ${group}
    </td>
  </tr>
`;
        }else{
        tbody += `
  <tr class="table-light group-header">
    <td colspan="17" class="text-left font-weight-bold">
      ${group}
    </td>
  </tr>
`;    
        }
}
        $.each(employees, function(i, emp) {
          let nssf = 0, nhif = 0, heslb = 0, social = 0, nbt = 0,tucta=0, net_salary=0;
          let raw_paye = 0, paye = 0;

          let gross = parseFloat(emp.basic_salary) + parseFloat(emp.allowances);
          let basic_salary = parseFloat(emp.basic_salary) || 0;
          let nhif_status  = parseInt(emp.nhif_pay_status) || 0;
          let heslb_status = parseInt(emp.heslb_pay_status) || 0;
          let pension_status = parseInt(emp.pension_pay_status) || 0;
          let allowances = parseFloat(emp.allowances) || 0;
          let maafa = parseFloat(emp.maafa) || 0;
          let housing = parseFloat(emp.housing) || 0;
          let tucta_status = parseFloat(emp.tucta_status) || 0;
          let electricity = parseFloat(emp.electricity_amount) || 0;
          let loans = parseFloat(emp.loan_amount) || 0;
          let wcf_data;
          if(hasWCF===1){
        wcf_data  = gross*0.005;
          }else{
              wcf_data  =0;
          }
         

          if (pension_status === 0) {
            nssf = 0;
          } else {
            nssf = gross * 0.10;      
          }

          if (basic_salary <= 0 || nhif_status === 0) {
            nhif = 0;
          } else if (basic_salary < 666666.67) {
            nhif = 20000;
          } else {
            nhif = basic_salary * 0.03;
          }

          if (heslb_status === 1) {
            heslb = basic_salary * 0.15;
          } else {
            heslb = 0;
          }
          if(tucta_status===1){
tucta=basic_salary*(2/100);
          }
       

          total_basic += basic_salary;
          total_allowances += parseFloat(emp.allowances);
          total_gross += gross;
          social = nssf + nhif;
          nbt = gross - social;
          raw_paye = scriptPaye(nbt, taxBrackets);
          paye = parseFloat(raw_paye);
          total_nssf += nssf;
          total_nhif += nhif;
          total_heslb += heslb;
          total_nbt += nbt;
          total_social += social;
          total_paye += paye;
          total_tucta += tucta;
          total_housing += housing;
          total_loans += loans;
          total_maafa += maafa;
          total_electricity += electricity;
       
          total_advance += parseFloat(emp.advance_amount);

             if(database_id===17){
      
         net_salary = nbt - (paye + heslb + parseFloat(emp.advance_amount)+maafa+housing+loans+tucta+electricity);
            }else{
     
 net_salary = nbt - (paye + heslb + parseFloat(emp.advance_amount));
            }
               total_netsalary += net_salary;
let rowStyle = (parseInt(emp.status) != 1) ? 'class="text-warning"' : '';
         let status = `<span class="badge badge-${emp.status_color}">${emp.status_name}</span>`;

          tbody += `<tr ${rowStyle}>
            <td class="text-center">${i+1}</td>
            <td class="text-center">${emp.dep_name}</td>
            <td class="text-center">${emp.job_tittle}</td>`;
            if (hasClass == 1) {
  tbody += `<td class="text-center">${emp.class_name || '-'}</td>`;
}
         tbody += `<td class="text-center">${emp.first_name} ${emp.last_name}</td>
            <td class="text-center">${status}</td>
            <td class="emoluments">${basic_salary.toLocaleString()}</td>
            <td class="emoluments">0</td>
            <td class="emoluments">${parseFloat(emp.allowances).toLocaleString()}</td>
            <td class="emoluments"><b>${gross.toLocaleString()}</b></td>
            <td class="social">${nssf.toLocaleString()}</td>
            <td class="social">${nhif.toLocaleString()}</td>
            <td class="social"><b>${social.toLocaleString()}</b></td>
            <td class="net_salary"><b>${nbt.toLocaleString()}</b></td>
            <td>${paye.toLocaleString()}</td>
            <td>${heslb.toLocaleString()}</td>
            <td>${parseFloat(emp.advance_amount).toLocaleString()}</td>
            <td>${parseFloat(tucta).toLocaleString()}</td>
            <td>${parseFloat(emp.housing).toLocaleString()}</td>
            <td>${parseFloat(emp.loan_amount).toLocaleString()}</td>
            <td>${parseFloat(emp.maafa).toLocaleString()}</td>
            <td>${parseFloat(emp.electricity_amount).toLocaleString()}</td>
            <td class="net_salary"><b>${net_salary.toLocaleString()}</b></td>
            <td style="display:none;">
    <input type="hidden" name="staff_id[]" value="${emp.user_id}">
    <input type="hidden" name="49${emp.user_id}" value="${basic_salary}">
    <input type="hidden" name="50${emp.user_id}" value="${allowances}">
    <input type="hidden" name="43${emp.user_id}" value="${nssf}">
    <input type="hidden" name="51${emp.user_id}" value="${nhif}">
    <input type="hidden" name="55${emp.user_id}" value="${heslb}">
    <input type="hidden" name="paye[]" value="${paye}">
    <input type="hidden" name="48${emp.user_id}" value="${emp.advance_amount}">
    <input type="hidden" name="54${emp.user_id}" value="${net_salary}">
    <input type="hidden" name="53${emp.user_id}" value="${wcf_data}">
    <input type="hidden" name="56${emp.user_id}" value="${maafa}">
    <input type="hidden" name="57${emp.user_id}" value="${housing}">
    <input type="hidden" name="58${emp.user_id}" value="${tucta}">
    <input type="hidden" name="59${emp.user_id}" value="${loans}">
    <input type="hidden" name="56${emp.user_id}" value="${electricity}">
    <input type="hidden" name="classfication[]" value="${emp.classfication_id}">
  </td>
          </tr>`;
        });
 if(group !=0){
        tbody += `<tr class="table-primary font-weight-bold">`;
        if (hasClass == 1) {  
    tbody += ` <td class="text-left" colspan="6">${group} TOTAL</td>`;
}else{
tbody += ` <td class="text-left" colspan="5">${group} TOTAL</td>`; 
}
       tbody += `<td>${total_basic.toLocaleString()}</td>
          <td>0</td>
          <td>${total_allowances.toLocaleString()}</td>
          <td>${total_gross.toLocaleString()}</td>
          <td>${total_nssf.toLocaleString()}</td>
          <td>${total_nhif.toLocaleString()}</td>
          <td>${total_social.toLocaleString()}</td>
          <td>${total_nbt.toLocaleString()}</td>
          <td>${total_paye.toLocaleString()}</td>
          <td>${total_heslb.toLocaleString()}</td>
          <td>${total_advance.toLocaleString()}</td>
          <td>${total_tucta.toLocaleString()}</td>
          <td>${total_housing.toLocaleString()}</td>
          <td>${total_loans.toLocaleString()}</td>
          <td>${total_maafa.toLocaleString()}</td>
          <td>${total_electricity.toLocaleString()}</td>
          <td>${total_netsalary.toLocaleString()}</td>
        </tr>`;
    }
      });

      $("#salaryTableData tbody").html(tbody);

    }
  });
}


// =============================================
function scriptPaye(taxable_income, brackets) {
  taxable_income = parseFloat(taxable_income);

  for (let i = 0; i < brackets.length; i++) {
    let b = brackets[i];

    let from_amount = parseFloat(b.from_amount);
    let to_amount = parseFloat(b.to_amount);
    let base_tax = parseFloat(b.base_tax);
    let tax_rate = parseFloat(b.tax_rate);
    let excess_above = parseFloat(b.excess_above);

    if (taxable_income >= from_amount && taxable_income <= to_amount) {
      let excess = taxable_income - excess_above;
      return base_tax + (excess * (tax_rate / 100));
    }
  }
  return 0;
}

$(document).ready(function() {
    $('#salaryTableData').DataTable({
        paging: false,
        searching: true,
        ordering: true,
        info: true,
        pageLength: 1000,
      
     
    });
    $('#salaryTableData thead th').attr('data-bs-toggle', 'tooltip')
                              .attr('title', 'Click to sort');
$('[data-bs-toggle="tooltip"]').tooltip(); 

});


 function view_payroll(payroll_id){
                $('#view_payrolls').modal('show'); 
        $('#view_payrolls_content').html('<span class="fa fa-spinner fa-spin"></span> Retreiving payroll data..');
        $('#view_payrolls_content').load('view-payroll/'+payroll_id);
       
    } 

document.addEventListener("DOMContentLoaded", function () {
    const monthSelect = document.getElementById("month");
    const monthNameInput = document.getElementById("month_name");

    function updateMonthName() {
        let selectedText = monthSelect.options[monthSelect.selectedIndex].text;
        monthNameInput.value = selectedText;
    }
    monthSelect.addEventListener("change", updateMonthName);
    updateMonthName();
});
</script>

