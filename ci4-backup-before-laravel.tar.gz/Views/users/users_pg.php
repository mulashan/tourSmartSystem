<style>
.dataTables_wrapper .dataTables_filter {
    float: none;
    text-align: center;
	color:black;
}
</style>
<div class="section-body">
<?php 
 $usermodel = new App\Models\UsersModel();
 $bmodel = new App\Models\BillingModel();
 $login = new App\Models\LoginModel();
 if(session()->get('logged_in')==true){
$shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
}
?>
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Users</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Users</li>
                </ol>
            </div>
             <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#users-all">Users List</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#users-add">New User</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#users-all">Users List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#users-add">New User</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="users-all">
                <div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>No.#</th>
                                    <th>User Id</th>
                                    <th>Photo</th>
                                    <th>Name</th>
                                    <th>Gender</th>
                                    <th>Username</th>
                                    <th>User Type</th>
									<th>Status</th>

                                    <th>Modified Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
							
							<?php 
							
							$i=0;
							foreach($users as $user){ 
							$id=$user->user_type;
							$userid = $usermodel->select_id($id);
							foreach($userid as $type){ 
							$typename=$type->type_name;
							}
                             $source = "";
                            if($user->user_photo != ""){
                              $source =  base_url('public/users_photos/'.$user->user_photo);
                          }
							$i++;
							?>
							<tr>
							<td><?= $i; ?></td>
                            <td><?= $user->user_id; ?></td>
							<td><img src="<?php echo $source; ?>" width="60" height="60"> </td>
							<td><?= $user->first_name." ".$user->last_name." ".$user->other_name; ?></td>
							<td><?= $user->gender; ?></td>
							<td><?= $user->username; ?></td>
							<td><?= $user->type_name; ?></td>
							<?php if($user->status==1){ ?>
                                    <td><?= '<b class="" style="color:green">Active</b>'?></td>
                                    <?php }else{?>
									<td><?= '<span class=" text-danger">Inactive</span>'?></td>
									<?php } ?>
							
							<td><?= $user->updated_date; ?></td>
							<td>
						<button type="button" class="btn btn-primary btn-sm EditID" data-id="<?= $user->user_id;?>/<?= $user->user_type;?>"><i class="fa fa-edit"></i> Edit</button>
                        <!-- <button type="button" class="btn btn-danger btn-sm RemoveID" data-id="<?php //echo $user->user_id;?>"><i class="fa fa-trash"></i></button> -->
							</td>
							</tr>
							<?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
            <div class="tab-pane" id="users-add">
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header" style="height:5px">
                                    <h3 class="card-title">Add New User</h3>
                                <div class="card-options">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                            <hr>
                            <div class="card-body">
                                <div id="response_message"></div>
                                <div id="danger"></div>
                               <form id="newUser" enctype="multipart/form-data" class="needs-validation" novalidate>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row mb-3">
                                                <label for="ename" class="col-sm-4 col-form-label col-form-label-sm">First Name<span class="text-danger">*</span></label>
                                                <div class="col-sm-6">
                                                    <input type="text" class="form-control form-control-sm" id="ename" name="first_name" placeholder="First Name" required>
                                                     <div class="invalid-feedback">First Name is required.</div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label for="elname" class="col-sm-4 col-form-label col-form-label-sm">Last Name<span class="text-danger">*</span></label>
                                                <div class="col-sm-6">
                                                    <input type="text" class="form-control form-control-sm" id="elname" name="last_name" placeholder="Last Name" required>
                                                     <div class="invalid-feedback">Last Name is required.</div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label for="eoname" class="col-sm-4 col-form-label col-form-label-sm">Other Name</label>
                                                <div class="col-sm-6">
                                                    <input type="text" class="form-control form-control-sm" id="eoname" name="other_name" placeholder="Other Name">
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label for="ephone" class="col-sm-4 col-form-label col-form-label-sm">Phone Number<span class="text-danger">*</span></label>
                                                <div class="col-sm-6">
                                            
                                           <input type="text" class="form-control" value="+255" name="phone" id="phone_no" placeholder="+255-xxx-xxx-xxx"  minlength="9"  maxlength="13"  required  autocomplete="off"pattern="^\+?255[0-9]{9}$" title="Phone must start with +255 and contain 12 digits total">
                                                    <div class="invalid-feedback">Please enter a valid phone number (e.g., +255712345678).</div>
                                                </div>

                                            </div>
                                            <fieldset class="row mb-3">
                                                <legend class="col-sm-4 col-form-label col-form-label-sm">Gender<span class="text-danger">*</span></legend>
                                                <div class="col-sm-6">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="gender" id="male" value="Male" required>
                                                        <label class="form-check-label" for="emale">
                                                        Male
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="gender" id="female" value="Female" required>
                                                        <label class="form-check-label" for="efemale">
                                                        Female
                                                        </label>
                                                          <div class="invalid-feedback">Gender is required.</div>
                                                    </div>
                                                </div>
                                            </fieldset>
                                            
                                            <div class="row mb-3">
                                        <label for="dob" class="col-sm-4 col-form-label col-form-label-sm">Date of Birth<span class="text-danger">*</span></label>
                                        <div class="col-sm-6">
                                      
                                        <input type='text' class="form-control form-control-sm"  name="dob" id='datetimepicker1' placeholder="2000-07-24"  min="2000-12-31"/>
                                        </div>
                                        </div>
                                        
                                 <!--institution added here-------------->
                                 <?php
                              $inst_det = $login->get_table_details('database_list_tbl');
                                 ?>
                                  <div class="row mb-3">
                                                <label for="inst" class="col-sm-4 col-form-label col-form-label-sm">Instituition<span class="text-danger">*</span></label>
                                                <div class="col-sm-6">
                                    <select id="inst" name="inst" class="form-select form-control form-control-sm">
                                                        <?php 
                                                     if(session()->get('db_id')==1){
                                         if(session()->get('user_id')==2){
                                          ?>
                                         <option value="">Choose</option>
                                        <?php foreach ($inst_det as $us): ?>
                                                            
                                        <option value="<?php echo $us->id;?>"><?php echo $us->instituition;?></option>
                                                        <?php endforeach ?>
                                                    <?php }else{
                                                    $d=session()->get('db_id')-1;
                                                    ?>
                                                    <option value="<?php echo $inst_det[$d]->id;?>" selected><?php echo $inst_det[$d]->instituition;?></option>
                                          <?php } }else{
                                        if(session()->get('logged_in')==true){
                                        $d=session()->get('db_id')-1;
                                                      
                                             ?>
                                          <option value="<?php echo $inst_det[$d]->id;?>" selected><?php echo $inst_det[$d]->instituition;?></option>
                                                <?php } }?>
                                                    </select>
                                                </div>
                                            </div>
                                            </div>
                                            <!--institution added end----------> 
                                        <div class="col-md-6">
                                            <div class="row mb-3">
                                                <label for="enid" class="col-sm-4 col-form-label col-form-label-sm">National Id</label>
                                                <div class="col-sm-6">
                                                    <input type="number" class="form-control form-control-sm" id="enid" name="national_id" placeholder="eg: xxxxxxxx-xxxxx-xxxxx-xx">
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label for="eemail" class="col-sm-4 col-form-label col-form-label-sm">Email</label>
                                                <div class="col-sm-6">
                                                    <input type="email" class="form-control form-control-sm" id="eemail" name="email" placeholder="eg: user@gmail.com">
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label for="ulevl" class="col-sm-4 col-form-label col-form-label-sm">User Type<span class="text-danger">*</span></label>
                                                <div class="col-sm-6">
                                                    <select id="ulevl" name="user_type" class="form-select form-control form-control-sm" required>
                                                        <option value="" selected>Choose</option>
                                                        <?php foreach ($usertype as $us): 
                                                        if($us->id==6){
                                                            continue;
                                                        }
                                                        ?>
                                                            <option value="<?php echo $us->id;?>"><?php echo $us->type_name;?></option>
                                                        <?php endforeach ?>
                                                    </select>
                                                              <div class="invalid-feedback">User Type is required.</div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label for="eaddrs" class="col-sm-4 col-form-label col-form-label-sm">Physical Address</label>
                                                <div class="col-sm-6">
                                                    <input type="text" class="form-control form-control-sm" id="eaddrs" name="physical_adress" placeholder="Home Address">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                            <label class="col-md-3 col-form-label">Photo</label>
                                            <div class="col-md-8">
                                               <img id="output1" style="width:84px;" alt="">
                                                  <input type="file" accept="image/*" name="photo" onchange="loadFile(event)">
                                            </div>
                                        </div>
                                        
                                        <fieldset class="row mb-3">
                                                <legend class="col-sm-4 col-form-label col-form-label-sm">Staff<span class="text-danger">*</span></legend>
                                                <div class="col-sm-6">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="staff" id="non_staff" value="0" required>
                                                        <label class="form-check-label" for="emale">
                                                        Non Staff
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="staff" id="staff" value="1" required>
                                                        <label class="form-check-label" for="efemale" >
                                                        Staff
                                                        </label>
                                                    </div>
                                                      <div class="invalid-feedback">Please specify here.</div>
                                                </div>
                                            </fieldset>
                                        </div>
                                        <div class="d-flex justify-content-end mt-2 mb-3">
                                            <button type="submit" class="btn btn-primary"><i class="fa fa-plus me-2"></i>Add User</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
  <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content" style="width:105%">
        <div class="modal-header">
          <h5 class="modal-title" id="">Update User</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
       <div class="modal-body">
          <div id="Updtelvl"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
<!-----End update modal--->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script type="text/javascript">
    $('#newUser').submit(function(e){
    e.preventDefault();
    if (!this.checkValidity()) {
        e.stopPropagation();
        this.classList.add("was-validated");
        return;
    }
    var phone_no = $('#phone_no').val().trim();
    var phonePattern = /^\+?255[0-9]{9}$/;

    if (!phonePattern.test(phone_no)) {
        Swal.fire("Invalid Phone", "Please enter a valid Tanzanian phone number (e.g., +255712345678)", "error");
        return;
    }
    var form_data = new FormData(this);

    $.ajax({
        beforeSend: function () {
            Swal.fire({
                title: 'Please wait...',
                html: '<span class="text-danger">Saving user...</span>',
                icon: 'info',
                showConfirmButton: false,
                timerProgressBar: true,
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
        },
        method: "POST",
        url: "<?= base_url('/save_newUser') ?>",
        data: form_data,
        contentType: false,
        processData: false,
        success:function(data){
            if(data.status==2){
                 Swal.close();
swal("Oops!", "User already Exists!", "error");
            }
            else if(data.status==3){
      Swal.close();
swal("Failed!", "Something went wrong!", "error");
}else{
            Swal.close();
            swal({
                title: "User saved successfully",
                text: data,
                type: "success",
                 confirmButtonText: "OK",
        closeOnConfirm: true
            },
            function(){
            $("#newUser")[0].reset();
                window.location.reload();
    }            );
        }},
        error:function(res){
            Swal.close();
            $('#response_message').html(
              '<span class="alert alert-danger">Sorry! Something went wrong!</span>'
            );
        }
    });
});

$(".RemoveID").click(function(){

        var id = $(this).attr('data-id');


           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this Accomodation!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/deleteUser')?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      // $("#"+id).remove();
                    swal("Deleted!", "User deleted.", "success");

                    location.reload();
                      
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
	$(".EditID").click(function () {
        var data = 'ids=' + $(this).attr('data-id');
        $('#myModal').modal('show');
        $.ajax({
            type: "GET",
            url: "<?= base_url('/user_Edit')?>/"+$(this).attr('data-id'),
            data: data,
            beforeSend: function()
            {
                $('#Updtelvl').html('<span class="fa fa-spinner fa-spin"></span> Loading Please wait....');
            },
            success: function(res){
                $('#Updtelvl').html(res);
                 
            },
            error: function (xhr)
            {
 $('#Updtelvl').html(
                '<div class="alert alert-warning">Failed to load data (Error code: ' + xhr.status + ')</div>'
            );
            }
        });
    });
     var loadFile = function(event) {
    var output = document.getElementById('output1');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output1.src) // free memory
    }
  }; 
  
   $(function () {
        var year = (new Date).getFullYear();
        var day = (new Date).getDate();
        var m = (new Date).getMonth();
        $('#datetimepicker1').datetimepicker({
            // format: 'Y/m/d',
            format:"YYYY-MM-DD",
            minDate: new Date(1950, 0, 1),
            maxDate: new Date(year, m, day)
        });
    });
</script>