<?php
$smodel = new App\Models\StudentModel();
$bmodel = new App\Models\BillingModel();
$department = $smodel->gettable_data('departments_tbl',$where = array('id >' => 0));
$job_title = $smodel->gettable_data('job_tittle_tbl',$where = array('id >' => 0));
$classification = $smodel->gettable_data('classification_tbl',$where = array('id >' => 0));
$company = $bmodel->get_table_details('company_tbl');
?>
<style>
  .custom-date-input {
    cursor: pointer;
  }

  .custom-date-input:focus {
    box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25); 
  }
</style>

  <form class="card-body form-horizontal" id="updateStaff" enctype="multipart/form-data">

    <?php
if(isset($det) && !empty($det)):
    $user_photo=$det[0]->user_photo;

    ?>
<input type="hidden" name="old_photo" id="old_photo" value="<?=$user_photo?>">
       <label for="profilePicInput" style="cursor: pointer;" title="Click to change photo">
        
      <img id="profileImage"
           src="<?= base_url('public/users_photos/' .$user_photo  ?: 'default_picture.png'); ?>"
                      alt="User Image" style="border:2px solid blue;" width="90" height="90">
    </label>
    <div id="uploadMessage"></div>
<?php
endif;

?>

    <input type="file" name="profile_pic" id="profilePicInput" accept="image/*" style="display:none;" />
			<div id="fbk" class="text-success"></div>
             <?php
                        if(session()->get('db_id')==17){
                             if(count($staff_details)>0){
                      ?>
               <div class="form-group row">
                     <div class="col-md-2"></div>

                    <label class="col-md-2 col-form-label">Files/Employees Number:<span class="text-danger">*</span></label>
                    
                    <div class="col-md-5">
                     <input type="text" class="form-control" name="employee_number" placeholder="XX-XX" value="<?=$staff_details[0]->employee_number;?>">
                    </div>
                </div>
                <?php
            }
            }?>
                <div class="form-group row">
                     <div class="col-md-2"></div>
                    <label class="col-md-2 col-form-label">Staff Name:<span class="text-danger">*</span></label>
                    
                    <div class="col-md-5">
                     <input type="text" class="form-control" name="bsalary" value="<?=$det[0]->first_name;?> <?=$det[0]->last_name;?>" disabled readonly>
                    </div>
                </div>
                <div class="form-group row">
                	 <div class="col-md-2"></div>
                    <label class="col-md-2 col-form-label">DOB<span class="text-danger">*</span></label>
                    <div class="col-md-5">
                        <input type="date" id="dob" class="form-control custom-date-input" value="<?=$det[0]->birth_date;?>" name="dob" required="required" max="<?= date('Y-m-d'); ?>" onclick="this.showPicker && this.showPicker()">
                        <input type="hidden" name="user_id" value="<?= $det[0]->user_id;?>">
               
                  
					</div>
                </div>
                <div class="form-group row text-left">
                	 <div class="col-md-2"></div>
                    <label class="col-md-2 col-form-label">Department<span class="text-danger">*</span></label>
                    
                    <div class="col-md-5">
                      <select class="form-control staff-select" name="dep_id" required="required">
                      	 	<option value="">-choose-</option>
                      	<?php
                       foreach ($department as $value) {
                       	?>
                         	<option value="<?=$value->id;?>"
                         		<?php if(count($staff_details)>0){ if($staff_details[0]->dep_id==$value->id){ echo "selected";} }?> ><?php echo $value->dep_name;?></option>
                       	<?php
                       }
                        ?>
                     
                      </select>
					</div>
                </div>

                <div class="form-group row text-left">
                	 <div class="col-md-2"></div>
                    <label class="col-md-2 col-form-label">Job Tittle<span class="text-danger">*</span></label>
                    <div class="col-md-5">
                      <select class="form-control staff-select" name="job_id" required="required">
                      	<option value="">-choose-</option>
                      	<?php
                        if (isset($job_title) && !empty($job_title)) {
                       foreach ($job_title as $value) {
                       	?>
                         	<option value="<?=$value->id;?>"
                          <?php if(count($staff_details)>0){ if($staff_details[0]->job_id==$value->id){ echo "selected";} }?> 
                         		><?php echo $value->job_tittle;?></option>
                       	<?php
                       }}
                        ?>
                      </select>
					</div>
                </div>
                     <div class="form-group row text-left">
                     <div class="col-md-2"></div>
                    <label class="col-md-2 col-form-label">Staff Status<span class="text-danger">*</span></label>
                    <div class="col-md-5">
                      <select class="form-control staff-select" name="staff_status" required="required">
                        <option value="">-choose-</option>
                        <?php
                        $staff_status = $smodel->gettable_data('staff_status',$where = array('status_id >' => 0));
                        if (isset($staff_status) && !empty($staff_status)) {
                       foreach ($staff_status as $value) {
                        ?>
                            <option value="<?=$value->status_id;?>"
                          <?php if(count($staff_details)>0){ if($staff_details[0]->status==$value->status_id){ echo "selected";} }?> 
                                ><?php echo $value->status_name;?></option>
                        <?php
                       }}
                        ?>
                      </select>
                    </div>
                </div>
  
                <div class="form-group row text-left">
                     <div class="col-md-2"></div>
                    <label class="col-md-2 col-form-label">Employment Type: <span class="text-danger">*</span></label>
                    <div class="col-md-5">
                      <select class="form-control staff-select" name="employment_type" id="employment_type" required="required">
                        <option value="">-choose-</option>
                        
                        
                           <?php 
                        if(count($staff_details)>0){ 
                            if ($staff_details[0]->employment_type==1) {
                                echo '<option value="1" selected>Primary</option>
                                <option value="2">Secondary</option>';
                            }elseif($staff_details[0]->employment_type==2){
                                echo '
                                <option value="1">Primary</option>
                                <option value="2" selected>Secondary</option>';
                            }else{
                                   echo '<option value="1">Primary</option>
                                  <option value="2">Secondary</option>';
                            }
                            }
                            ?> 
                      </select>
                    </div>
                </div>

                  <div class="form-group row text-left">
                     <div class="col-md-2"></div>
                    <label class="col-md-2 col-form-label">Residential Status 
: <span class="text-danger">*</span></label>
                    <div class="col-md-5">
                      <select class="form-control staff-select" name="residential_status" required="required">
                        <option value="">-choose-</option>
                        <?php 
                        if(count($staff_details)>0){ 
                            if ($staff_details[0]->residential_status==1) {
                                echo '<option value="1" selected> Resident</option>
                                 <option value="2" >Non - Resident</option>';
                            }elseif($staff_details[0]->residential_status==2){
                                echo '
                                <option value="1" >Residential</option>
                                <option value="2" selected> Non - Resident</option>';
                            }else{
                                   echo '<option value="1" >Resident</option>
                                  <option value="2" >Non - Resident</option>';
                            }
                            }
                            ?> 
                        

                      </select>
                    </div>
                </div>
                <?php if (isset($company) && !empty($company)) {
                    if($company[0]->classification==1){
                ?>
       <div class="form-group row text-left">
                     <div class="col-md-2"></div>
                    <label class="col-md-2 col-form-label">Classification<span class="text-danger">*</span></label>
                    <div class="col-md-5">
                      <select class="form-control staff-select" name="classification" required="required">
                        <option value="0">-choose-</option>
                        <?php
                        if (isset($classification) && !empty($classification)) {
                       foreach ($classification as $class) {
                        ?>
                            <option value="<?=$class->id;?>"
                          <?php if(count($staff_details)>0){ if($staff_details[0]->classfication_id==$class->id){ echo "selected";} }?> 
                                ><?php echo $class->class_name;?></option>
                        <?php
                       }}
                        ?>
                      </select>
                    </div>
                </div>

                <?php
            }}
            ?>

                <div class="form-group row">
                	 <div class="col-md-2"></div>
                    <label class="col-md-2 col-form-label">Basic Salary<span class="text-danger">*</span></label>
                    <div class="col-md-5">
                    	<?php 
                    	$bsalary=0;
                    	if(count($staff_details)>0){ 
                    		$bsalary=$staff_details[0]->basic_salary;
                    		}?> 
                        <input type="text" class="form-control" id="bsalary" name="bsalary" value="<?=number_format($bsalary);?>" required="required">
                   
                    </div>
                </div>
              
               <div class="form-group row">
               	 <div class="col-md-2"></div>
                    <label class="col-md-2 col-form-label">Allowances<span class="text-danger">*</span></label>
                    <div class="col-md-5">
                    	<?php 
                    	$allowance=0;
                    	if(count($staff_details)>0){ 
                    		$allowance=$staff_details[0]->allowances;
                    		}?> 
<input type="text" class="form-control" id="allowances"  name="allowances" value="<?= number_format($allowance); ?>"  >

                  
                    </div>
                </div>                           
                <div class="form-group row">
                	 <div class="col-md-2"></div>
                    <label class="col-md-2 col-form-label">Contract Expiry Date<span class="text-danger">*</span></label>
                    <div class="col-md-5">
                    	<?php 
                    	$expiry=date('Y-m-d');
                    	if(count($staff_details)>0){ 
                    		$expiry=date('Y-m-d',strtotime($staff_details[0]->contract_expiry_date));
                    		}?>
                        <input type="date" class="form-control custom-date-input"  name="expiry_date" value="<?php echo $expiry;?>" required="required" onclick="this.showPicker && this.showPicker()" >
                   
                    </div>
                </div>     
                  <div class="form-group row">
                  	 <div class="col-md-2"></div>
                     <label class="col-md-2 col-form-label">Bank Account Number</label>
                     <div class="col-md-5">
                     	<?php 
                    	$account="";
                    	if(count($staff_details)>0){ 
                    		$account=$staff_details[0]->account_number;
                    		}?>
                        <input type="text" class="form-control" name="account_number" value="<?=$account?>">
                   
                    </div>
                </div> 
                    <div class="form-group row text-left">
                     <div class="col-md-2"></div>
                     <label class="col-md-2 col-form-label">Bank Name</label>
                     <div class="col-md-5">
                      <select class="form-control staff-select" name="bank_name" >
                        <option value="0">-choose-</option>
                        <?php
                        if (isset($banks) && !empty($banks)) {
                       foreach ($banks as $bank) {
                        ?>
                            <option value="<?=$bank->bank_id;?>"
                          <?php if(count($staff_details)>0){ if($staff_details[0]->bank_name==$bank->bank_id){ echo "selected";} }?> 
                                ><?php echo $bank->bank_name;?></option>
                        <?php
                       }}
                        ?>
                      </select>
                    </div>
                </div> 
                    <div class="form-group row">
                     <div class="col-md-2"></div>
                     <label class="col-md-2 col-form-label">Account Name</label>
                     <div class="col-md-5">
                        <?php 
                        $account="";
                        if(count($staff_details)>0){ 
                            $account_name=$staff_details[0]->account_name;
                            }?>
                        <input type="text" class="form-control" name="account_name" value="<?=$account_name?>" >
                   
                    </div>
                </div> 
                
                
                <div class="form-group row">
                     <div class="col-md-2"></div>
                     <label class="col-md-2 col-form-label">Pension No<span class="text-danger"></span></label>
                     <div class="col-md-5">
                        <?php 
                        $pension="";
                        $paystatus="";
                        if(count($staff_details)>0){

                            $pension=$staff_details[0]->pension_no;
                            $paystatus=$staff_details[0]->pension_pay_status;
                            }?>
                        <input type="text" placeholder="NSSF number" class="form-control" id="pension_no" name="pension_no" value="<?=$pension?>" >
                        </div>
             <div class="form-check col-md-2">
                <?php
                if($paystatus=='' || $paystatus==0){
                ?>
  <input class="form-check-input" type="checkbox" id="nssf_status" name="nssf_status" value="1" >
     <?php
 }else{
                ?>
    <input class="form-check-input" type="checkbox" id="nssf_status" name="nssf_status" value="1" checked>
                <?php
            }
                ?>
  <label class="form-check-label">Pensionable</label>
</div> 
                    
                </div> 

                 <div class="form-group row">
                     <div class="col-md-2"></div>
                     <label class="col-md-2 col-form-label">TIN No<span class="text-danger"></span></label>
                     <div class="col-md-5">
                        <?php 
                        $tin="";
                        if(count($staff_details)>0){ 
                            $tin=$staff_details[0]->tin_no;
                            }?>
                        <input type="text" class="form-control" placeholder="TIN number" id="tin_no" name="tin_no" value="<?=$tin?>" >
                   
                    </div>
                </div> 

                <div class="form-group row">
                     <div class="col-md-2"></div>
                     <label class="col-md-2 col-form-label">NHIF No<span class="text-danger"></span></label>
                     <div class="col-md-5">
                        <?php 
                        $nhf="";
                        $nhfstatus="";
                        if(count($staff_details)>0){ 
                            $nhf=$staff_details[0]->nhf_no;
                            $nhfstatus=$staff_details[0]->nhif_pay_status;
                            }?>

                        <input type="text" class="form-control" id="nhf_no" placeholder="NHIF number" name="nhf_no" value="<?=$nhf?>" >
                   
                    </div>
                                 <div class="form-check col-md-2">
                                      <?php
                if($nhfstatus=='' || $nhfstatus==0){
                ?>
  <input class="form-check-input" type="checkbox" id="nhif_status" name="nhif_status" value="1">
       <?php
 }else{
         ?>
  <input class="form-check-input" type="checkbox" id="nhif_status" name="nhif_status" value="1" checked>
            <?php
            }
              ?>
  <label class="form-check-label">Covered</label>
</div> 
                </div> 
                            <div class="form-group row">
                     <div class="col-md-2"></div>
                     <label class="col-md-2 col-form-label">HESLB No<span class="text-danger"></span></label>
                     <div class="col-md-5">
                        <?php 
                        $heslb="";
                        $heslbstatus="";
                        if(count($staff_details)>0){ 
                            $heslb=$staff_details[0]->heslb_no;
                            $heslbstatus=$staff_details[0]->heslb_pay_status;
                            }?>

                        <input type="text" class="form-control" placeholder="HESLB number" id="heslb_no" name="heslb_no" value="<?=$heslb?>" >
                   
                    </div>
                                 <div class="form-check col-md-2">
                                      <?php
                if($heslbstatus=='' || $heslbstatus==0){
                ?>
  <input class="form-check-input" type="checkbox" id="heslb_status" name="heslb_status" value="1">
       <?php
 }else{
         ?>
  <input class="form-check-input" type="checkbox" id="heslb_status" name="heslb_status" value="1" checked>
            <?php
            }
              ?>
  <label class="form-check-label">Required</label>
</div> 
                </div> 

                <div class="form-group row">
                     <div class="col-md-2"></div>
                     <label class="col-md-2 col-form-label">WCF No<span class="text-danger"></span></label>
                     <div class="col-md-5">
                        <?php 
                        $wcf="";
                        if(count($staff_details)>0){ 
                            $wcf=$staff_details[0]->wcf_no;
                            }?>
                        <input type="text" placeholder="WCF number" class="form-control" name="wcf_no" value="<?=$wcf?>" >
                   
                    </div>
                </div> 
                <!-- ============================================================= -->
                <?php
                  if(session()->get('db_id')==17){
                ?>
                         <div class="form-group row">
                     <div class="col-md-2"></div>
                     <label class="col-md-2 col-form-label">TUCTA<span class="text-danger"></span></label>
                     <div class="col-md-5">
                        <?php 
                        $tucta_status="";
                        if(count($staff_details)>0){ 
                            $tucta_status=$staff_details[0]->tucta_status;
                            }?>
<input type="text" class="form-control" id="tucta" name="tucta" value="<?=$tucta_status?>" >
                   
                    </div>
                                 <div class="form-check col-md-2">
                                      <?php
                if($tucta_status=='' || $tucta_status==0){
                ?>
  <input class="form-check-input" type="checkbox" id="tucta_status" name="tucta_status" value="1">
       <?php
 }else{
         ?>
  <input class="form-check-input" type="checkbox" id="tucta_status" name="tucta_status" value="1" checked>
            <?php
            }
              ?>
  <label class="form-check-label">Covered</label>
</div> 
                </div> 
                         <div class="form-group row">
                     <div class="col-md-2"></div>
                     <label class="col-md-2 col-form-label">Housing<span class="text-danger"></span></label>
                     <div class="col-md-5">
                        <?php 
                        $housing="";
                        if(count($staff_details)>0){ 
                            $housing=$staff_details[0]->housing;
                            }?>

                        <input type="text" class="form-control" id="housing" name="housing" value="<?=number_format($housing);?>" >
                   
                    </div>
                                 <div class="form-check col-md-2">
                                      <?php
                if($housing=='' || $housing==0 || $housing==0.00){
                ?>
  <input class="form-check-input" type="checkbox" id="housing_status" name="housing_status" value="1">
       <?php
 }else{
         ?>
  <input class="form-check-input" type="checkbox" id="housing_status" name="housing_status" value="1" checked>
            <?php
            }
              ?>
  <label class="form-check-label">Covered</label>
</div> 
                </div> 

                             <div class="form-group row">
                     <div class="col-md-2"></div>
                     <label class="col-md-2 col-form-label">Maafa<span class="text-danger"></span></label>
                     <div class="col-md-5">
                        <?php 
                        $maafa="";
                        $maafastatus="";
                        if(count($staff_details)>0){ 
                            $maafa=$staff_details[0]->maafa;
                            }?>

                        <input type="text" class="form-control" id="maafa" name="maafa" value="<?=number_format($maafa);?>" >
                   
                    </div>
                                 <div class="form-check col-md-2">
                                      <?php
                if($maafa=='' || $maafa==0 || $maafa==0.00){
                ?>
  <input class="form-check-input" type="checkbox" id="maafa_status" name="maafa_status" value="1">
       <?php
 }else{
         ?>
  <input class="form-check-input" type="checkbox" id="maafa_status" name="maafa_status" value="1" checked>
            <?php
            }
              ?>
  <label class="form-check-label">Covered</label>
</div> 
                </div> 
                 <?php
             }
              
                        if(session()->get('db_id')==17){
                            if(count($staff_details)>0){ 
                      ?>
        <div class="form-group row align-items-center">

    <label class="col-md-6 col-form-label">
        Enable Electricity Deductions
    </label>

    <div class="col-md-6 d-flex align-items-center">
        <input type="checkbox"
               name="electricty_charges"
               style="transform: scale(1.5);"
               value="1"
               <?php if($staff_details[0]->electricty_status==1){ echo 'checked'; } ?>>
    </div>

</div>
  <?php }}
        ?>

<!-- ================================================================================= -->
              
                    
						
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label"></label>
                            <div class="col-md-5">
                               
                                <button type="submit" id="savebtn" class="btn btn-primary float-right">Update</button>
                            </div>
                        </div>
                    </form>

           <script type="text/javascript">
           	
 $(document).ready(function() {
  $('#profilePicInput').on('change', function() {
    let file = this.files[0];
    const maxSize = 2 * 1024 * 1024;
    if (file) {
      const validTypes = ['image/jpeg', 'image/png', 'image/gif'];
      if (!validTypes.includes(file.type)) {
        $('#uploadMessage').html('<div class="alert alert-danger">Only JPG, PNG, and GIF files are allowed.</div>')
        .stop(true, true)
                .show()
                .delay(3000)
                .fadeOut();
        return;
      }
      if (file.size > maxSize) {
        $('#uploadMessage').html('<div class="alert alert-warning">Image size should be less than 2MB.</div>')
        .stop(true, true)
                .show()
                .delay(3000)
                .fadeOut();
        return;
      }
      let reader = new FileReader();
      reader.onload = function(e) {
        $('#profileImage').attr('src', e.target.result);
        $('#saveBtn').show();
        $('#uploadMessage').html('');
      }
      reader.readAsDataURL(file);
    }
  });
 $('#updateStaff').submit(function(e){
    e.preventDefault();
    let form = $('#updateStaff')[0];
    let formData = new FormData(form);

    $.ajax({
        url: "<?= base_url('index.php/StaffController/updateStaff'); ?>",
        type: 'POST',
        data: formData,
        processData: false, 
        contentType: false,
        success: function(res) {
                 swal({
                            title: "success!",
                            text: "Staff infomation updated successfully..",
                            type: "success"
                        }, function () {
                           window.location.reload();
                        });
                   },
        error: function() {
            swal("Error", "Something went wrong!", "error");
        }
    });
});
 
});

 $('.staff-select').select2();
 document.getElementById("allowances").addEventListener("keyup", function (e) {
    let value = e.target.value.replace(/,/g, "");
    if (!isNaN(value) && value !== "") {
        e.target.value = Number(value).toLocaleString("en-US");
    }
});
 document.getElementById("bsalary").addEventListener("keyup", function (e) {
    let value = e.target.value.replace(/,/g, "");
    if (!isNaN(value) && value !== "") {
        e.target.value = Number(value).toLocaleString("en-US");
    }
});

 $(document).ready(function() {
let nhfInput = document.getElementById('nhf_no');
let nhifCheckbox = document.getElementById('nhif_status');

function updateNHFBorder() {
    if (nhifCheckbox.checked) {
        nhfInput.style.borderColor = 'green';
        nhfInput.style.borderWidth = '2px'; 
        nhfInput.style.borderStyle = 'solid';  
    } else {
        nhfInput.style.borderColor = '';   
        nhfInput.style.borderWidth = '';
        nhfInput.style.borderStyle = '';
    }
}
updateNHFBorder();
nhifCheckbox.addEventListener('change', updateNHFBorder);

const tuctaInput = document.getElementById('tucta');
const tuctaCheckbox = document.getElementById('tucta_status');

function updateTuctaUI() {
    let value = parseInt(tuctaInput.value) || 0;
    tuctaInput.value = value;
    tuctaCheckbox.checked = value !=0;
    tuctaInput.style.border = tuctaCheckbox.checked ? '2px solid green' : '';
}
tuctaInput.addEventListener('input', function () {
    //this.value = this.value.replace(/[^0-9]/g, '');
    updateTuctaUI();
});

tuctaCheckbox.addEventListener('change', function () {
    tuctaInput.value = this.checked ? '1' : '0';
    updateTuctaUI();
});
window.addEventListener('load', updateTuctaUI);


const fields = [
    { inputId: 'maafa', checkboxId: 'maafa_status' },
    { inputId: 'housing', checkboxId: 'housing_status' },
    { inputId: 'loans', checkboxId: 'loans_status' }
];


fields.forEach(field => {
    const input = document.getElementById(field.inputId);
    const checkbox = document.getElementById(field.checkboxId);

    if (!input || !checkbox) return;
    function formatInput() {
        let rawValue = input.value.replace(/,/g, '');
        let parts = rawValue.split('.');
        let integerPart = parts[0] || '0';
        let decimalPart = parts[1] || '';
        integerPart = Number(integerPart).toLocaleString("en-US");
        input.value = decimalPart ? `${integerPart}.${decimalPart}` : integerPart;
    }
    function updateUI() {
        let value = parseFloat(input.value.replace(/,/g, '')) || 0;
        checkbox.checked = value >= 1;
        input.style.border = checkbox.checked ? '2px solid green' : '';
    }

    input.addEventListener('input', function () {
        let cleaned = this.value.replace(/[^0-9.]/g, '');
        const dotCount = (cleaned.match(/\./g) || []).length;
        if (dotCount > 1) cleaned = cleaned.slice(0, cleaned.lastIndexOf('.'));
        this.value = cleaned;
        formatInput();
        updateUI();
    });
    checkbox.addEventListener('change', function () {
        input.value = this.checked ? '1' : '0';
        formatInput();
        updateUI();
    });
    window.addEventListener('load', function () {
        formatInput();
        updateUI();
    });
});

let nssfInput = document.getElementById('pension_no');
let nssfCheckbox = document.getElementById('nssf_status');
function updateNSSFBorder() {
    if (nssfCheckbox.checked) {
        nssfInput.style.borderColor = 'green';
        nssfInput.style.borderWidth = '2px';
        nssfInput.style.borderStyle = 'solid';
    } else {
        nssfInput.style.borderColor = '';
        nssfInput.style.borderWidth = '';
        nssfInput.style.borderStyle = '';
    }
}
updateNSSFBorder();
nssfCheckbox.addEventListener('change', updateNSSFBorder);

let heslbInput = document.getElementById('heslb_no');
let heslbCheckbox = document.getElementById('heslb_status');
function updateHESLBBorder() {
    if (heslbCheckbox.checked) {
        heslbInput.style.borderColor = 'green';
        heslbInput.style.borderWidth = '2px';
        heslbInput.style.borderStyle = 'solid';
    } else {
        heslbInput.style.borderColor = '';
        heslbInput.style.borderWidth = '';
        heslbInput.style.borderStyle = '';
    }
}
updateHESLBBorder();
heslbCheckbox.addEventListener('change', updateHESLBBorder);
});
document.getElementById('tin_no').addEventListener('input', function (e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 9) value = value.slice(0, 9);
    let formatted = value.match(/.{1,3}/g);
    e.target.value = formatted ? formatted.join('-') : '';
});
document.getElementById("maafa").addEventListener("input", function (e) {
    let value = e.target.value;
    value = value.replace(/[^0-9.,]/g, '');
    value = value.replace(/,/g, '');
    let parts = value.split('.');
    let integerPart = parts[0];
    let decimalPart = parts[1] ?? '';
    decimalPart = decimalPart.substring(0, 2);
    if (integerPart !== '') {
        integerPart = Number(integerPart).toLocaleString("en-US");
    }
    e.target.value = parts.length > 1
        ? `${integerPart}.${decimalPart}`
        : integerPart;
});

</script>
