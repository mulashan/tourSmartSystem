<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
        }
        h1, h5 {
            color: #333;
        }
        p, li {
            color: #555;
        }
        ul {
            padding-left: 20px;
        }
    </style>
</head>
<body>
    <h5>Privacy Policy</h5>
    <p><strong>Effective Date:</strong> 01/01/2025</p>
    <p>We value your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our app and its login dialog.</p>

    <h5>1. Information We Collect</h5>
    <ul>
        <li><strong>Personal Information:</strong> Includes your username, email address, and password.</li>
        <li><strong>Usage Data:</strong> Includes data on how you use the app, such as pages viewed, actions taken, and interactions with the login dialog.</li>
        <li><strong>Device Information:</strong> Includes data related to your device, such as the device type, operating system version, and device identifiers (e.g., IP address, device ID).</li>
    </ul>

    <h5>2. How We Use Your Information</h5>
    <ul>
        <li><strong>Authentication:</strong> To verify your identity when you log in and provide access to the app's features.</li>
        <li><strong>Personalization:</strong> To customize your experience based on your preferences and usage patterns.</li>
        <li><strong>Communication:</strong> To send you essential updates, notifications, and support-related messages regarding your account.</li>
        <li><strong>Improvement of Services:</strong> To analyze usage patterns and improve app performance, security, and user experience.</li>
    </ul>

    <h5>3. How We Protect Your Information</h5>
    <p>We implement reasonable security measures, including encryption and secure login procedures, to protect your personal data. However, no method of transmission over the internet or electronic storage is completely secure, and we cannot guarantee absolute security.</p>

    <h5>4. Sharing Your Information</h5>
    <p>We do not share your personal information with third parties, except in the following cases:</p>
    <ul>
        <li>With service providers who assist us in operating the app, providing services, or conducting business operations.</li>
        <li>For legal compliance if required by law or to protect the rights, property, or safety of our users or the app.</li>
        <li>In the case of a merger or acquisition, your information may be transferred as part of the transaction.</li>
    </ul>

    <h5>5. Your Data Rights</h5>
    <ul>
        <li><strong>Access:</strong> You may request to see what personal data we have collected about you.</li>
        <li><strong>Correction:</strong> You can update or correct your information.</li>
        <li><strong>Deletion:</strong> You may request to delete your account and personal data, subject to certain legal restrictions.</li>
        <li><strong>Opt-out:</strong> You can opt out of communications such as marketing messages.</li>
    </ul>

    <h5>6. Third-Party Services</h5>
    <p>Our app may contain links to third-party websites or services. We are not responsible for the privacy practices of these third parties, and we encourage you to review their privacy policies before interacting with them.</p>

    <h5>7. Children’s Privacy</h5>
    <p>Our app is not intended for use by children under the age of 13, and we do not knowingly collect personal information from children. If we learn that we have collected personal information from a child under 13, we will take steps to delete that information.</p>

    <h5>8. Changes to This Privacy Policy</h5>
    <p>We may update this Privacy Policy from time to time. When we do, we will post the revised policy in the app and update the "Effective Date" at the top. Please check this policy periodically for updates.</p>

    <h5>9. Contact Us</h5>
    <p>If you have any questions or concerns about this Privacy Policy or our privacy practices, please contact us at:</p>
    <p><strong>Email:</strong> info@microhealthinitiative.org</p>
</body>
</html>
