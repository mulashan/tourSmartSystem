<?php
            helper('calc');
            helper('age');
             $bmodel = new App\Models\BillingModel();
             $smodel = new App\Models\StudentModel();
             $report = new App\Models\ReportsModel();
             $classification = $smodel->gettable_data('classification_tbl',$where = array('id >' => 0));
             $dbname=session()->get('db_name');
            $db = \Config\Database::connect($dbname);
?>               
            <div id="tobeprinted">
                     <?php
                 $schoolname=$report->get_schoolname();

             if($payroll_year==0){
                $year="All Years,";
            }else{
                if(count($net_data)>0)
              $year=$net_data[0]->payroll_year;  
            }
            if($payroll_month==0){
                $month="All Months";
            }else{
                if(count($net_data)>0)
              $month=$net_data[0]->month;  
            }
            if($department==0){
                $department="All Departments";
            }else{
                if(count($net_data)>0)
              $department=$net_data[0]->dep_name;  
            }
               if($title==0){
                $titles="All Job Titles";
            }else{
                if(count($title)>0)
              $titles=$net_data[0]->job_tittle;  
            }
                if(count($net_data)>0){
           echo "<h6><b>".$schoolname[0]->company_name." </b></h6>";
             echo "<h6><b>NET Salary report for ".$month." - ".$year." Departments: ".$department." Titles: ".$titles."</b></h6>";
                }
               ?>
              <div class="card">
                 
               <div class="table-responsive mt-3">
                    <div style="float:left;margin-left: 10px;" id="overpayment">
                </div>
                <!-- <button type="button" class="btn btn-primary mb-3 btnp" style="float:right;" onclick="student_print()"><i class="fa fa-print"></i> Print</button> -->
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="NetTable">
                           <thead>
                            <tr>
                                <th>SN</th>
                                 <th>YEAR</th>
                                 <th>MONTH</th>
                                 <th>STAFF NAMES</th>
                                 <th>DEPERTMENT</th>
                                 <th>TITLE</th>
                                 <?php
                                 if(count($classification)>0){
                                 ?>
                                 <th>CLASSIFICATION</th>
                                 <?php
                             }
                                 ?>
                                 <th>NET AMOUNT</th>
                                 <th>BANK</th>
                                 <th>AC NAME</th>
                                 <th>AC NUMBER</th>
                                </tr>
                            </thead>
                         <tbody>
                            <?php
                            $total_net=0;
                             $female=0;
                               $male=0;
                               $departments=0;
                               $titles=0;
                            if(isset($net_data)){
                                if(!empty($net_data)){
                                    $i=0;
                                     $female=0;
                               $male=0;
                               $departments=0;
                               $titles=0;
                                    foreach($net_data as $data){
                                                              if($data->gender=='Female'){
                                    $female=$female+1;
                                  }
                                  if($data->gender=='Male'){
                                    $male=$male+1;
                                  }
                                  if($data->dep_name){
                                    $departments+=1;
                                  }
                                  if($data->job_tittle){
                                    $titles+=1;
                                  }
                                        $total_net+=$data->net_salaries;
                                        $i++;
                            ?>
                            <tr>
                                <td><?=$i;?></td>
                                <td><?=$data->payroll_year;?></td>
                                <td><?=$data->month;?></td>
                                <td><?=$data->first_name;?> <?=$data->first_name;?></td>
                                <td><?=$data->dep_name;?></td>
                                <td><?=$data->job_tittle;?></td>
                                 <?php
                                 if(count($classification)>0){
                                 ?>
                                <td><?=$data->class_name;?></td>
                                      <?php
                             }
                                 ?>
                                <td><?=number_format($data->net_salaries);?></td>
                                <td><?=$data->bank_name;?></td>
                                <td><?=$data->account_name;?></td>
                                <td><?=$data->account_number;?></td>
                            </tr>
                            <?php
                        }}} 
                      //   else{
                      // echo '<td>N</td>';
                      //   }
                            ?>
                        
                               
          </tbody>
          <tfoot>
              <tr>
                  <td colspan="6"><b>TOTAL NET AMOUNT</b></td>
                  <td><b><?=number_format($total_net);?></b></td>
                  <td colspan="3"></td>
              </tr>
          </tfoot>
           </table>

          <?php
          echo '<h6 style="">Summary,</h6>';
          ?>
                <table class="toba">
              <tr>
                  <td style="padding-left:10px;"><b>Male: <?=$male;?>,</b></td> 
                  <td style="padding-left:10px"><b>Female: <?=$female;?>,</b></td>
                  <td style="padding-left:10px"><b>Total of Employees: <?=$male+$female?></b></td>
           <!--        <td style="padding-left:10px"><b>Departments: <?=$departments?></b>,</td> 
                  <td style="padding-left:10px"><b>Job Title: <?=$titles?></b>,</td> -->
                  <td style="padding-left:10px"><b>Total Net salary: <?=number_format($total_net);?></b>,</td>
                
              </tr>
          </table>
          
      </div>
  </div>
  </div>

  
  <div id="student_details" style="display: none;"></div>
 <div id="allReportsContent" style="display: none;"></div>
  <div class="btn-group">
    <form id="export_excel" method="post" action="<?= base_url('NETfexport-excel') ?>">
        <input type="hidden" name="year" value="<?=esc($payroll_year);?>">
        <input type="hidden" name="month" value="<?=esc($payroll_month);?>">
        <input type="hidden" name="dep" value="<?=esc($department);?>">
        <input type="hidden" name="job" value="<?=esc($title);?>">
        <input type="hidden" name="class_status" value="<?=esc($classfication);?>">
        <input type="hidden" name="bank" value="<?=esc($bank);?>">
          <button type="submit" class="btn btn-primary mb-3" onclick="showMessagepaye()" style="float:right;"><i class="fa fa-telegram"></i> Export to Excel</button>
    </form>
  </div> <div class="btn-group"><button type="button" id="Print-button" class="btn btn-primary mb-3 btnp" style="float:right;" onclick="printTable()"><i class="fa fa-print"></i> Print All Reports</button>
 </div>
<noscript>
    <style>
        .table-condensed{
            padding-bottom: 20px; 

        }
        table.table{
            border-collapse:collapse;
            border: 1px solid black;
            width:80%;
          
            margin-left: auto;
            margin-right: auto;
/*            page-break-inside: avoid;*/
           
        }
         table.table td{
         border:1px solid black;
           font-size: 12px;
         }
        #NetTable td,#NetTable th{
            border:1px solid black;
           font-size: 12px;
           }
        h6{
            text-align: center;
        }
        .btnp,.viewbtn{
           display: none;
        }
        #NetTable_wrapper .dataTables_filter,
        #NetTable_wrapper .dataTables_paginate,
        #NetTable_wrapper .dataTables_length {
         display: none;
}
 @media print {
      .table {
        border-collapse: collapse !important;
        border: 1px solid black !important;
      }
      }
      table.toba td{
        font-size: 12px;
      }
        
    </style>
</noscript>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
  <script>
 var table;
$(document).ready(function() {
  table = $("#NetTable").DataTable({
    dom: 'f',
    paging: false,
    lengthChange: false
  });
});



function printTable() {
    $('#Print-button').prop("disabled", true);
    var tableContent = document.getElementById("tobeprinted").innerHTML;

    var nw = window.open('', '_blank', 'width=800,height=600');

    if (!nw) {
        console.error('Failed to open print window');
        return;
    }

    nw.document.write('<html><head><title>NET Salary Report</title>');

    // add styles
    nw.document.write('<style>');
    nw.document.write('body { font-family: "Times New Roman", sans-serif; font-size: 13px;}');
    nw.document.write('table { border-collapse: collapse; width: 100%; font-size: 12px; margin-top: 10px;}');
    nw.document.write('th, td { border: 1px solid black; padding: 6px; text-align: left;}');
    nw.document.write('h6 {text-align: center;}');
    nw.document.write('tfoot td { font-weight: bold;}');
    nw.document.write('@media print {.page-break { page-break-after: always; } #payeTable_filter {display: none !important;}}');
    nw.document.write('@media print {.page-break { page-break-after: always; } #NetTable_filter {display: none !important;} }');
    nw.document.write('</style>');

    nw.document.write('</head><body>');
    nw.document.write(tableContent);
    nw.document.write('</body></html>');

    nw.document.close();
    nw.print();
}

function showMessagepaye() {
    const messageDiv = document.getElementById('Export_message');
    messageDiv.innerHTML = '<div class="alert alert-success">The file is being exported, please check your downloads folder.</div>';
    setTimeout(function() {
        messageDiv.innerHTML = '';
    }, 4000);
}

  </script>
