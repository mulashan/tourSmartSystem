 <div class="row">
 <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Deductions information</h5>
            </div>
<div class="card">
	<div class="card-body">
				<table class="table table-borderless">
			  <tr>
				  		<th>Payroll Year</th>
				  	<td><?=esc($year);?></td>
				  </tr>
                       <tr>
                       	<th>Payroll Month</th>
                       <td><?=$month;?></td>
                        </tr>
				<tr>
				<th>charge date</th>
				<td><?=esc($date);?></td>
				</tr>
					<tr>
				<th>Update By</th>
				     <?php
                        $adder_name='--';
                        if(isset($saver)){
                            foreach($saver as $data){
                                if($data->user_id==$saved_charges[0]->created_by){
                               $adder_name=$data->first_name.' '.$data->last_name;     
                                    break;

                                }
                            }
                        }
                        ?>
				<td><?=esc($adder_name);?></td>
				</tr>
					<tr>
				<th>Update date</th>
				<td><?=esc($saved_charges[0]->created_on);?></td>
				</tr>
				
                      </table>
                 
              </div>
          </div>
      </div>
  </div>
  </div>
   <div class="row">
 <div class="col-md-12">
        <div class="card invoice">
            <div class="card-header">
                <h5>Deductions List</h5>
            </div>
<div class="card">
	<div class="card-body">
                     <div class="table-responsive mt-1">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                   
                                    <th>SN</th>
                                   <th>STAFF Name</th>
                                   <th>Gender</th>
                                   <th>Job tittle</th>
                                   <th>Department</th>
                                   <th>Amount</th>
                                     <th>Action</th> 
                                </tr>
                            </thead>
                            <tbody style="padding:1px;">
                               
                       <?php
                         if(isset($saved_charges)):
                                   $total_amount=0;
                                   $i=0;
                            foreach($saved_charges as $ec):
                                $i++;
                       ?>
                        <tr>
                       <td><?=$i;?></td>
                        <td><?=$ec->first_name?>
                       <?=$ec->last_name?></td>
                                 <td><?=$ec->gender;?></td>
                       <td><?=$ec->job_tittle;?></td>
                       <td><?=$ec->dep_name;?></td>
                       <td class="text-right"><?=format_number_with_decimals($ec->loan_amount);?></td>
                  <td>
  <a href="#" onclick="edit_singleLoan('<?php echo $ec->charge_id;?>','<?=esc($month_id);?>','<?=esc($year);?>')"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a> 
  <a href="#" onclick="view_singleLoan('<?php echo $ec->charge_id;?>','<?=esc($month_id);?>','<?=esc($year);?>')"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a> 
                        </td> 

                              </tr>                
                       <?php
                   endforeach;
               endif;
                       ?>
                       
                            </tbody>
                            </table>
                                
            </div>
                 
              </div>
          </div>
        <div class="d-flex justify-content-center mb-3">
           <?php 
      if(empty($payrolls)){?>
             <button type="button" class="btn btn-danger btn-sm" onclick="delete_loans('<?=esc($month_id);?>','<?=esc($year);?>')"><i class="fa fa-trash"></i> Delete</button> 
               <?php }else{?>
                 <button type="button" class="btn btn-danger btn-sm" onclick="delete_loans('<?=esc($month_id);?>','<?=esc($year);?>')" disabled><i class="fa fa-trash"></i> Delete</button>
                 <?php }?>
                 </div>
      </div>
  </div>
  </div>
      <div class="modal" id="single_loan">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Loan Deductions</h4>
        <button type="button" class="btn-close" onclick="hide_modal()"></button>
      </div>
      <div class="modal-body">
      <div id="single_data">
          
      </div>
      </div>
    
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="hide_modal()">Close</button>
      </div>

    </div>
  </div>
</div>
<script>
      function edit_singleLoan(id,month,year){
         $("#single_loan").modal('show');
              $('#single_data').html('<span class="fa fa-spinner fa-spin"></span> Loading form....');
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/edit_single_loan'; ?>',
                data: {id:id,month:month,year:year},
                       beforeSend: function()
            { 
            $('#single_data').html('<span class="fa fa-spinner fa-spin"></span> Loading form....');
            },
                success: function (res) {
                    $('#single_data').html(res);
                   
                },
                error: function () {
                    $('#single_data').html('<div class="alert alert-warning">Fail to retreive data.!!</div>');
                      
                }
            });
     }
     function hide_modal(){
              $("#single_loan").modal('hide');
     }
function delete_loans(month, year) {

  swal({
    title: "Are you sure?",
    text: "You will not be able to recover this data!",
    type: "warning",
    customClass: 'swal-wide',
    showCancelButton: true,
    confirmButtonClass: "btn-danger",
    confirmButtonText: "Yes, delete!",
    cancelButtonText: "No, cancel!",
    closeOnConfirm: false,
    closeOnCancel: false
  },

  function(isConfirm) {

    if (isConfirm) {

      $.ajax({
        url: '<?= base_url('/deleteloans')?>',
        type: 'POST',
        data: { month: month, year: year },
        dataType: 'json',
        success: function(data) {

          if (data.status == 1) {

            swal({
              title: "Deleted!",
              text: "Data deleted.",
              type: "success"
            }, function () {
              window.location.reload();
            });

          } else {

            swal({
              title: "Warning!",
              text: "Data not deleted.",
              type: "warning"
            }, function () {
              window.location.reload();
            });

          }

        },

        error: function() {

          swal({
            title: "Failed",
            text: "Something is wrong.",
            type: "error"
          }, function () {
            window.location.reload();
          });

        }

      });

    } else {

      swal("Cancelled", "Data not deleted, process canceled by user.", "info");

    }

  });

}
function view_singleLoan(id,month,year){
             $("#single_loan").modal('show');
              $('#single_data').html('<span class="fa fa-spinner fa-spin"></span> Loading form....');
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/view_single_loan'; ?>',
                data: {id:id,month:month,year:year},
                       beforeSend: function()
            { 
                              $('#single_data').html('<span class="fa fa-spinner fa-spin"></span> Loading form....');
            },
                success: function (res) {
                    $('#single_data').html(res);
                   
                },
                error: function () {
                    $('#single_data').html('<div class="alert alert-warning">Fail to retreive data.!!</div>');
                      
                }
            });
}
     
</script>