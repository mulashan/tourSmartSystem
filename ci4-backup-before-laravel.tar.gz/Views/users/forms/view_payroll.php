  <style type="text/css">

     .invoice > .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }
@media print {
  body * {
    visibility: hidden;
  }
  #printTableArea, #printTableArea * {
    visibility: visible;
  }
  #printTableArea {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
  }
  .no-print {
    display: none !important;
  }
}

 </style>
 <?php 
$bmodel = new App\Models\BillingModel();
    $comodel = new App\Models\CompanyModel();
    $smodel=new App\Models\StudentModel;
$classification = $smodel->gettable_data('classification_tbl',$where = array('id >' => 0));
$company = $bmodel->get_table_details('company_tbl');
 helper('results_helper');
?>

<style>
table.emoluments, th.emoluments{
   
    background-color: #d9ead3;
}table.emoluments, td.emoluments{
   
    background-color: #d9ead3;
}
table.social, th.social{
  
    background-color: #d9d9d9;
}
table.social, td.social{
  
    background-color: #d9d9d9;
}
table.tax, th.tax{
    
    background-color: #f9cb9c;
}table.net_salary, th.net_salary{
    
    background-color: #fed966;
}table.net_salary, td.net_salary{
    
    background-color: #fed966;
}
td{
    border: 1px solid black;
}
th{
    border: 1px solid black;
}
table.centa, th.centa{
    text-align: center;
}
table.paysummary, th.paysummary{
    border: 1px solid black;
}
@media print {
  body * {
    visibility: hidden;
  }
  #printTableArea, #printTableArea * {
    visibility: visible;
  }
  #printTableArea {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
  }
  .no-print {
    display: none !important;
  }

  /* ---- Page break handling for tables ---- */
  table {
    page-break-inside: auto;
  }
  tr {
    page-break-inside: avoid;
    page-break-after: auto;
  }
  thead {
    display: table-header-group; /* repeat headers */
  }
  tfoot {
    display: table-footer-group; /* repeat footers */
  }

  /* ---- Prevent card/grid from splitting ---- */
  .card {
    page-break-inside: avoid;
    break-inside: avoid;
    margin-bottom: 1rem; /* spacing between printed cards */
  }

  .row {
    page-break-inside: avoid;
    break-inside: avoid;
  }

  [class*="col-"] {
    page-break-inside: avoid;
    break-inside: avoid;
  }

  /* Optional: cleaner print layout */
  .card {
    box-shadow: none !important; /* shadows don’t print well */
    border: 1px solid #000 !important; /* ensure border is visible */
  }
}

</style>
 <?php
 helper('age');
  $billmodel = new App\Models\BillModel();
  $remodel =new App\Models\ReportsModel();
  $suppliermodel = new App\Models\SupplierModel();
// $v_type = $billmodel->get_item_name('voucher_types_tbl', $where = array('id' => $rlt[0]->voucher_type));
 ?>
 <div id="printTableArea">
<div class="row">
<!-------------------- Bill Information starts here  ------------------>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Payroll Information</h5>
            </div>
            <!-- </hr> -->

            <div class="card-body">
                <table class="table table-borderless">
                    <tr>
                        <th>Pay Voucher No:</th>
                        <td><?= $payroll_data[0]->trans_number; ?></td>
                    </tr>
                     <tr>
                        <th>Voucher Type:</th>
                        <td><?="Payroll";?></td>
                    </tr>
                    <tr>
                        <th>Voucher Date:</th>
                        <td><?= $payroll_data[0]->trans_date; ?></td>
                    </tr>
                     <tr>
                        <th>Payroll Year:</th>
                        <td><?= $payroll_info[0]->payroll_year; ?></td>
                    </tr>
                    <tr>
                        <th>Payroll Month:</th>
                        <td><?= $payroll_info[0]->month; ?></td>
                    </tr> 
                                      <tr>
                        <th>Created By:</th>
                        <td><?= $payroll_data[0]->first_name; ?> <?= $payroll_data[0]->last_name; ?> </td>
                    </tr>            
                </table>
            </div>
    </div>
</div>
 <!-------------------- Payment History starts here  ------------------>


</div>
<!-------------------- Charged Items starts here --------------------->
<div class="row">
    <div class="col-md-12">
        <div class="card  invoice">
            <div class="card-header">
                <h5>Payment Details</h5>
                
            </div>
            <!-- </hr> -->

            <div class="card-body">
           <div class="table-responsive">
        <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; font-family: Arial; font-size: 12px; text-align: right;" id="payroll_view_table">
    <thead>
        <tr>
                           <?php if (isset($company) && !empty($company)) {
                    if($company[0]->classification==1){
                ?>
            <th colspan="6" class="text-center">EMPLOYEE DETAILS</th>
            <?php
        }else{

           ?>
           <th colspan="5" class="text-center">EMPLOYEE DETAILS</th>
           <?php
       }}?>
            <th colspan="4" class="emoluments text-center">EMOLUMENTS</th>
            <th colspan="3" class="social text-center">SOCIAL SECURITY DEDUCTIONS</th>
            <th class="net_salary"></th>
                    <?php if(session()->get('db_id')==17){?>
            <th colspan="8" class="tax text-center">TAX & OTHER DEDUCTIONS</th>
        <?php 
    }else{
            ?>
             <th colspan="3" class="tax text-center">TAX & OTHER DEDUCTIONS</th>
            <?php
        }
        ?>
            <th class="net_salary"></th>
           
        </tr>
        <tr>
            <th>S/N</th>
            <th>DEPARTMENT</th>
            <th>JOB TITLE</th>
             <?php if (isset($company) && !empty($company)) {
                    if($company[0]->classification==1){
                ?>
            <th>CLASSFICATION</th>
            <?php
}}
            ?>
            <th>NAMES</th>
            <th>STATUS</th>
            <th class="emoluments">B.SALARY</th>
            <th class="emoluments">OVER TIME</th>
            <th class="emoluments">ALLOWANCE</th>
            <th class="emoluments">GROSS</th>
            <th class="social">PENSION 10%</th>
            <th class="social">NHIF 3%</th>
            <th class="social">TOTAL SOCIAL</th>
            <th class="net_salary">NET BEFORE TAX</th>
            <th class="tax">PAYE</th>
            <th class="tax">HESLB</th>
            <th class="tax">ADVANCES</th>
                   <?php if(session()->get('db_id')==17){?>
           <th class="tax">TUCTA</th>
            <th class="tax">HOUSING</th>
            <th class="tax">OTHER LOANS</th>
            <th class="tax">MAAFA</th>
             <th class="tax">ELECTRICITY</th>
        <?php
    }
    ?>
            <th class="net_salary">NET SALARY</th>
        </tr>
    </thead>
    <tbody>
<?php
    $i=0;
$total_basic_salary = 0;
$total_allowances = 0;
$total_gross_salary = 0;
$total_nssf = 0;
$total_nhif = 0;
$ctotal_social = 0;
$cumulate_nbt=0;
$cumulate_paye=0;
$callowance=0;
$cadvances=0;
$cumulate_net_salary=0;
$wcf=0;
$total_heslb=0;
$total_housing=0;
$total_tucta=0;
$total_maafa=0;
$total_loans=0;
$total_electricity=0;
if(isset($payroll_info) && !empty($payroll_info)):
    foreach($payroll_info as $staffs):
            $row_style = ($staffs->status == 4) ? 'class="text-danger"' : '';
        $i++;

$housing=$staffs->housing;
$tucta=$staffs->tucta;
$loans=$staffs->other_loans;
$maafa=$staffs->maafa;
$electricity=$staffs->electricity;
$gross=$staffs->basic_salary + $staffs->allowances;
$total_social=$staffs->pension+$staffs->nhif;
$nbt =$gross-$total_social;

$total_basic_salary += $staffs->basic_salary;
$total_allowances += $staffs->allowances;
$total_social=$staffs->pension+$staffs->nhif;
$total_gross_salary += $gross;
$total_nssf += $staffs->pension;
$total_nhif += $staffs->nhif;
$ctotal_social += $total_social;
$total_heslb +=$staffs->heslb;
$cadvances += $staffs->advances;
$cumulate_nbt+=$nbt;
$cumulate_paye+=$staffs->paye;
$callowance+=$staffs->allowances;
$cumulate_net_salary+=$staffs->net_salaries;
$total_housing+=$housing;
$total_tucta+=$tucta;
$total_maafa+=$maafa;
$total_loans+=$loans;
$total_electricity+=$electricity;
        ?>

        <tr <?= $row_style; ?>>
  
            <td><?=$i;?></td>
            <td style="text-align: left;"><?=$staffs->dep_name;?></td>
            <td style="text-align: left;"><?=$staffs->job_tittle;?></td>
<?php 
if (isset($company) && !empty($company)) {
    if ($company[0]->classification == 1) {
        $matched = false;
        foreach ($classification as $class) {
            if ($class->id == $staffs->classfication_id) {
                echo "<td class='text-center'>{$class->class_name}</td>";
                $matched = true;
                break;
            }
        }
        if (!$matched) {
            echo "<td class='text-center'> - </td>";
        }
    }
}
?>

            <td style="text-align: left;"><?=$staffs->first_name;?> <?=$staffs->last_name;?></td>
                <?php $status = "<span class='badge badge-{$staffs->status_color}'>{$staffs->status_name}</span>";?>
                                     <td><?=$status;?></td>
            <td class="emoluments"><?=format_number_with_decimals($staffs->basic_salary);?></td>
            <td class="emoluments"><?=format_number_with_decimals(0);?></td>
            <td class="emoluments"><?=format_number_with_decimals($staffs->allowances);?></td>
            <td class="emoluments"><b><?=format_number_with_decimals($gross);?></b></td>
            <td class="social"><?=format_number_with_decimals($staffs->pension);?></td>
            <td class="social"><?=format_number_with_decimals($staffs->nhif);?></td>
            <td class="social"><b><?=format_number_with_decimals($total_social);?></b></td>
            <td class="net_salary"><b><?=format_number_with_decimals($nbt);?></b></td>
            <td><?=format_number_with_decimals($staffs->paye);?></td>
            <td><?=format_number_with_decimals($staffs->heslb);?></td>
            <td ><?=num_format($staffs->advances);?></td>
                     <?php if(session()->get('db_id')==17){?>  
            <td><?=format_number_with_decimals($tucta);?></td>
             <td><?=format_number_with_decimals($housing);?></td>
            <td ><?=format_number_with_decimals($loans);?></td>
            <td ><?=format_number_with_decimals($maafa);?></td>
            <td ><?=format_number_with_decimals($electricity);?></td>
                    <?php
                }
                ?>
            <td class="net_salary"><b><?=format_number_with_decimals($staffs->net_salaries);?></b></td>
        </tr>

        <?php
    endforeach;
endif;
        ?>
          </tbody>
          <tfoot>
        <tr style="font-weight: bold;">
                     <?php if (isset($company) && !empty($company)) {
                    if($company[0]->classification==1){
                ?>
            <td colspan="6" style="text-align: center;">TOTAL</td>
                  <?php
        }else{

           ?>
           <td colspan="5" style="text-align: center;">OVERALL TOTAL</td>
           <?php
}}
           ?>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_basic_salary);?></td>
            <td class="emoluments text-right"><?=format_number_with_decimals(0);?></td>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_allowances);?></td>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_gross_salary);?></td>
            <td class="social text-right"><?=format_number_with_decimals($total_nssf);?></td>
            <td class="social text-right"><?=format_number_with_decimals($total_nhif);?></td>
            <td class="social text-right"><?=format_number_with_decimals($ctotal_social);?></td>
            <td class="net_salary text-right"><?=format_number_with_decimals($cumulate_nbt);?></td>
            <td class="text-right"><?=format_number_with_decimals($cumulate_paye);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_heslb);?></td>
            <td class="text-right"><?=num_format($cadvances);?></td>
                      <?php if(session()->get('db_id')==17){?>
           <td class="text-right"><?=format_number_with_decimals($total_tucta);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_housing);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_loans);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_maafa);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_electricity);?></td>
                <?php
            }
            ?>
            <td class="net_salary text-right"><?=format_number_with_decimals($cumulate_net_salary)?></td>
            
        </tr>
</tfoot>
</table>
</div>

            </div>
        </div>

        </div>
    </div>

        <!--------$name="AUGUST MARTIN NJAU";---------- here payment information 
           
starts---->
        <?php $bill = $billmodel->billdata($payroll_data[0]->trans_number,$payroll_data[0]->trans_type_id); ?>
        <?php  $Initiator= $billmodel->get_initiator_name($bill[0]->app_id); ?>
        <div class="row">
        <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Approval History</h5>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               
                <label>Approval Status:</label>
                <?php 
                $checker = 0;
               foreach($Initiator as $dat){
                if($dat->user_role =='3' && $dat->hstatus=='1')
                {
                    $checker =1;
                }
                elseif($dat->user_role =='3' && $dat->hstatus=='2'){
                    $checker =2;
                }
               }
                if($checker ==1)
                {
                     echo  '<label style="color:green;">  &nbsp;&nbsp; <strong>Approved! </strong></label>';
                 }
                 elseif($checker ==2){
                     echo  '<label style="color:red;">  &nbsp;&nbsp; Rejected! </label>';
                 }
                 else{
                echo'<label style="color:red;">  &nbsp;&nbsp; Pending! </label>';
                 }

                
                 ?>
                <div id="feedback"></div>
            </div>
            <!-- </hr> -->
        
     <?php $hist_data = $billmodel->getdatabill($bill[0]->app_id); ?>
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Entry Date:</th>
                        <th>Comment:</th>
                        <th>Name:</th>
                        <th>User Role:</th>
                        <!-- <th>Status:</th> -->
                    </tr>
                    <?php foreach($hist_data as $in): ?>
                    <tr>
                        <td><strong><?=$in->hist_date; ?></strong></td>
                        <td class="text-primary"><?= $in->comment; ?></td>
                        <td>
                            <?= $in->first_name.' '.$in->last_name; ?>
                        </td>
                        <td><?php if($in->user_role == '1'){
                            echo "Initiator";
                        }elseif($in->user_role == '2'){
                            echo "Checker";
                        }elseif($in->user_role == '3'){
                            echo "Approver";
                        }else{

                        } ?></td>
                        <td></td>
                    </tr>
                       <?php endforeach; ?>
                </table>
            </div>
        </div>
                  <!-- <div class="card  mt-3"> -->
                 <div class="card invoice mt-3  no-print">
             <div class="card-header mt-3">
                <h5>Message Information</h5>
            </div>
     
           <?php
       
            $msg_grp = $billmodel->get_item_name('message_groups_tbl',$where = array('message_type'=>17,'trans_number'=>$payroll_data[0]->trans_number));
          $msg = "";
          $status='';
          if(count($msg_grp)>0){
              $m = $billmodel->get_item_name('messages',$where = array('send_no'=>$msg_grp[0]->send_number));
                       
                         if(count($m) > 0){
                            $msg = $m[0]->message;
                            $msg= str_replace(array("\r","\n"),' ',$msg);
                          if($m[0]->sent_status == 1) {
                           $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description;
                          }elseif($m[0]->sent_status == 2){
                            $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description." <br>Delivered Date: ".$m[0]->time_delivered;
                          }
                        }
                    }
                     //print_r($bll);
             if($msg==""){
            $status="<span class='text-red'>Not Sent</span>";
            if(isset($ledger_data)){
                        $d_total=0;
                       foreach($ledger_data as $data){
                          if($data->transation_nature==1){
                        $d_total+=$data->amount; 
                    }
                }}

         $msg = "Payroll ".$payroll_data[0]->trans_number." for <b>".format_number_with_decimals($d_total)."</b> pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
                }

              // print_r($bll);
                   ?>
                
          
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Message:</th>
                        <td id="msg"><?= $msg; ?> </td>
                    </tr>
                    <tr>
                        <th>Status:</th>
                        <td id="msg"><?= $status; ?> </td>
                    </tr>
                    

                </table>
            </div>
            </div>
            
        <!-- </div> -->
        </div>
  

        <!------------------ here accounts receivable ------------------->
        <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>LEDGER ENTRIES</h5>
            </div>
            <!-- </hr> -->
           <div class="card-body">
                <table class="table" style="border:1px solid black;">
                   <tr style="border:1px solid black;">
                       <th style="border:1px solid black;">Ledger name</th>
                       <th style="border:1px solid black;">Ledger Type</th>
                       <th style="border:1px solid black;">Debit</th>
                       <th style="border:1px solid black;">Credit</th>

                   </tr>
                    <tbody style="border:1px solid black;">

                      <?php
                       if(isset($ledger_data)){
                        $dr_total=0;
                        $cr_total=0;
                       foreach($ledger_data as $data){
                        $cr_amount='';
                        $dr_amount='';
                        if($data->transation_nature==1){
                         $cr_amount=$data->amount;
                        $dr_amount=''; 

                        }else{
                             $cr_amount='';
                        $dr_amount=$data->amount; 
                        }
                        if($cr_amount !=''){
                             $cr_total +=$cr_amount;
                        }
                         if($dr_amount !=''){
                        $dr_total +=$dr_amount;
                    }
                       ?>
              
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;"><?=$data->account_name??""?></td>  
                          <td style="border:1px solid black;"><?=$data->type_name?></td>
                          <td class="text-right" style="border:1px solid black;"><?php 
                          if($dr_amount!=''){
                             echo format_number_with_decimals($dr_amount);
                          }
                         
                      ?></td>  
                          <td class="text-right" style="border:1px solid black;"><?php
                            if($cr_amount!=''){
                             echo format_number_with_decimals($cr_amount);
                          }
                          ?></td>  
                        </tr>
                                        <?php

                    }}?>
                    </tbody>
                    <tfoot>
                             <tr style="border:1px solid black;">
                          <td style="border:1px solid black;" colspan="2"><b>Total<b></td> 
                          <td class="text-right" style="border:1px solid black;"><b><?=format_number_with_decimals($dr_total)??""?></b></td>   
                          <td class="text-right" style="border:1px solid black;"><b><?=format_number_with_decimals($cr_total)??""?></b></td>  
                          
                        </tr>
                    </tfoot>
                </table>

            </div>
        </div>
</div>
</div>
<!-- </div> -->
<!----------------------------- supporting documents --------------------------->


<!-----------------for msg------------------>
<div class="col-md-6">
       
        </div>
        <div class="col-md-6">
            <?php
if(isset($advances) && !empty($advances)){
            ?>
            <div class="card">
            <div class="card invoice">
              <div class="card-header">
                <h5>Repayment Schedule</h5>
            </div>
            </div>
            <div class="card-body">
                                       <table class="table" style="border:1px solid black;">
                                        <thead>
                   <tr style="border:1px solid black;">
                       <th style="border:1px solid black;">Payroll Year</th>
                       <th style="border:1px solid black;">Payroll Month</th>
                       <th style="border:1px solid black;">Amount</th>
                   </tr>
                   </thead>
                    <tbody style="border:1px solid black;">
                        <?php 
                        $total_advance=0;
                          foreach ($advances as $data){
                               $total_advance+=$data->advance_amount;
                        ?>
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;"><?=$data->payroll_year??""?></td>  
                           <td style="border:1px solid black;"><?=$data->month??""?></td>  
                          <td class="text-right" style="border:1px solid black;"><?=format_number_with_decimals($data->advance_amount)??""?></td>  
                         
                        </tr>
       <?php
   }
       ?>

                        
                    </tbody>
                    <tfoot>
                        <tr style="border:1px solid black;">
                        <td style="border:1px solid black;" colspan="2" class="fw-bold"><b>Total</b></td>
                        <td class="text-right fw-bold" style="border:1px solid black;"><?= format_number_with_decimals($total_advance);?></td>
                        </tr>
                    </tfoot>
                </table>
                
            </div>
            <?php
        }?>
        </div>
        </div>
        </div>
<div class="row">
      <div class="col-md-12">
  <div class="card">
<div class="card-body d-flex justify-content-between no-print">
    <?php
    if(!empty($approval_status)){
    ?>
  <button id="delete_btn" class="btn btn-danger" onclick="deletePayroll('<?=esc($payroll_data[0]->trans_number);?>','<?=esc($payroll_data[0]->payroll_id);?>','<?=esc($payroll_data[0]->month);?>','<?=esc($payroll_data[0]->payroll_year);?>')" disabled>

    <i class="fa fa-trash"></i> Delete Payroll
  </button>
  <?php
}else{?>
      <button id="delete_btn" class="btn btn-danger" onclick="deletePayroll('<?=esc($payroll_data[0]->trans_number);?>','<?=esc($payroll_data[0]->payroll_id);?>','<?=esc($payroll_data[0]->month);?>','<?=esc($payroll_data[0]->payroll_year);?>')">

    <i class="fa fa-trash"></i> Delete Payroll
  </button>

    <?php
}?>
  <button class="btn btn-primary" onclick="printPayrollReport()">
    <i class="fa fa-print"></i> Print
  </button>
</div>



  </div>
    </div>
</div>

   <script type="text/javascript">
   function printPayrollReport() {
  var printContents = document.getElementById('printTableArea').innerHTML;
  var win = window.open('', '', 'height=800,width=1000');
  win.document.write('<html><head><title>Payroll Report</title>');
  win.document.write('<style>');
  win.document.write('@media print {');
  win.document.write('  body { font-size: 14px; font-family: Arial, sans-serif; }');
  win.document.write('  table { border-collapse: collapse; width: 100%; border: 1px solid black; page-break-inside:auto; }');
  win.document.write('  th, td { border: 1px solid black; padding: 8px; text-align: left; font-size: 14px; }');
  win.document.write('  thead { display: table-header-group; }');
  win.document.write('  tfoot { display: table-footer-group; }');
  win.document.write('  tr { page-break-inside: auto; page-break-after: auto; }');
  win.document.write('  .table.table_info { font-size: 14px; }');
  win.document.write('  h5 { text-align: center; }');
  win.document.write('  .table-container { position: relative; background-repeat: no-repeat; background-position: center; background-size: 80%; padding: 20px; }');
  win.document.write('  .no-print { visibility: collapse !important; }');
  win.document.write('  th[colspan], td[colspan] { border: 1px solid black; }');
  win.document.write('  .row { display: flex !important; flex-wrap: wrap !important; page-break-inside: auto; }');
  win.document.write('  [class*="col-"] { float: left !important; display: block !important; page-break-inside: auto; }');
  win.document.write('  .col-md-6 { width: 50% !important; }');
  win.document.write('  .col-md-12 { width: 100% !important; }');
  win.document.write('  .card { page-break-inside: auto; break-inside: auto; margin-bottom: 1rem; border: 1px solid #000 !important; box-shadow: none !important; }');
  win.document.write('  -webkit-print-color-adjust: exact;');
  win.document.write('  print-color-adjust: exact;');

  win.document.write('}');
  win.document.write('</style>');

  win.document.write('</head><body>');
  win.document.write(printContents);
  win.document.write('</body></html>');
  
  win.document.close();
  win.focus();
  win.print();
  win.close();
}
 

 function deletePayroll(trans_no,payroll_id,month,year){
    $('#delete_btn').prop("disabled", true);
   swal({
        title: "Are you sure?",
        text: "You will not be able to recover "+month+" "+year+" payroll details!",
        type: "warning",
        customClass: 'swal-wide',
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes, delete!",
        cancelButtonText: "No, cancel!",
        closeOnConfirm: false,
        closeOnCancel: false,
        height: '200px'
    }, function (isConfirm) {
        if (isConfirm) {
  $.ajax({
    method: 'POST',
    url: '<?php echo base_url() . '/delete-payroll'; ?>',
 data: { trans_no, payroll_id},
    dataType: 'json',
    beforeSend: function () {
         Swal.close();
            Swal.fire({
                title: 'Please wait...',
                html: '<span class="text-info"> Delete '+month+' '+year+ ' payroll please wait..</span>',
                icon: 'info',
                showConfirmButton: false,
                timerProgressBar: true,
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
        },
    success: function(data){
         Swal.close();
        if(data['status'] == "1"){ 
        $('#delete_btn').prop("disabled", false);   
      swal({
               title: "The "+month+" "+year+ " payroll deleted successfuly",
                        type: "success",
                 confirmButtonText: "OK",
        closeOnConfirm: true
            },
            function(){
           
                window.location.reload();
    }            );

        } else {
            $('#delete_btn').prop("disabled", false);
            swal("Warning", data['description'], "warning");
        }
    },
    error: function(xhr, status, error){
         Swal.close();
        $('#delete_btn').prop("disabled", false);
        swal("Error", "Something went wrong while Deleting payroll.", "error");
    }
});

 }  else {
            swal("Cancelled", "The  "+month+" "+year+" payroll is safe", "info");
            $('#delete_btn').prop("disabled", false);
        }
    });

}
   </script>

    
    

