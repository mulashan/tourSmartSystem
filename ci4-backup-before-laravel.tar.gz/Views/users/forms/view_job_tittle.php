<?php
 helper('age');
 ?>
<div class="row">
  
 <div class="col-md-6">
        <div class="card invoice">

            <div class="card-body">
               
                <table class="table table-borderless">
                    <?php
                    $smodel = new App\Models\StudentModel();
         if(isset($title) && !empty($title)):
                        ?>
  

                    <tr>
                        <th>Tittle Name:</th>
                        <td><?= $title[0]->job_tittle?></td>
                    </tr>
                    <tr>
                        <?php
           $creator = $smodel->gettable_data('users',$where = array('user_id' => $title[0]->created_by));
                        ?>
                        <th>Created by:</th>
                        <td><?= $creator[0]->first_name??""; ?> <?= $creator[0]->last_name??""; ?></td>
                    </tr>
                   
                    <tr>
                        <th>Created on:</th>
                        <td><?= $title[0]->created_date; ?></td>
                    </tr>


                </table>
            </div>
        </div>
    </div>

     <div class="col-md-6">
        <div class="card invoice">
            <div class="mt-1 mr-2 ml-4">
             <!-- <h5>List of staffs</h5>    -->
            </div>
                 <div class="card-body">
               
   
            </div>
        </div>
    </div>
    <div class="col-md-12">
                <div class="card invoice">
            <div class="mt-1 mr-2 ml-4">
             <h5>List of staffs</h5>   
            </div>
                 <div class="card-body">
               <div class="table-responsive">
                   
                               <table class="table table-bordered" id="tittle_table">
             <thead>
                <th>Sn</th>
                  <th>Photo</th>
                 <th>Full Name</th>
                 <th>Department</th>
                 <th>Age</th>
                 <th>Contract Expiry</th>
                <th>Gender</th>
                <th>Address</th>
                <th>user type</th>
                <th>Phone Number</th>
                <th>email</th>
                <th>Status</th>
             </thead>
             <tbody>
                <?php
  if(isset($staffs)):
    $i=0;
foreach ($staffs as $staff):
    $i++;
                  ?>
                  <tr>
                 <td><?=$i;?></td>
                 <td>
                           <?php
                        $user_photo=$staff->user_photo;
                         if($user_photo !=''){
                        ?>
                        <img src="<?=base_url('public/users_photos').'/'.$user_photo;?>" width="30" height="30" alt="User Image" style="border:1px solid black; border-radius: 100%;">
                        <?php
                        }else{
                        ?>
                        <img src="<?=base_url('public/users_photos/default_picture.png');?>" width="50" height="50" alt="User Image" style="border:2px solid black;">
                        <?php
                    }
                        ?>   

                 </td>
                 <td><?=$staff->first_name?>
                 <?=$staff->last_name?></td>

                 <td><?=$staff->dep_name?></td>
                 <td><?= findAge($staff->birth_date);?></td>
                 <td><?=$staff->contract_expiry_date;?></td>
                 <td><?=$staff->gender;?></td>
            <td><?=$staff->physical_adress;?></td>
                                     <td><?=$staff->type_name;?></td>
                                     <td><?=$staff->phone_no;?></td>
                                     <td><?=$staff->email;?></td>
                                     <?php if($staff->status==1){
                                        $status="<span style='color:green'>Active</span>";
                                     }else{
                                        $status="<span style='color:red'>Inactive</span>";
                                     } ?>
                                     <td><?=$status;?></td>
                 </tr>
                 <?php
             endforeach;
endif;
                 ?>
             </tbody>

                </table>
                </div>

            </div>
        </div>
    </div>
    <div class="col-md-12">
        <center>
    <button class="btn btn-danger btn-sm" data-toggle="tooltip" title="Delete <?= $title[0]->job_tittle?>" onclick="delete_item('<?= $title[0]->id?>','<?= $title[0]->job_tittle?>','<?=csrf_hash();?>')"><span class="fa fa-trash"> </span> Delete Tittle</button>
    </center>
</div>
    <?php
endif;
?>
</div>

<script>
            function delete_item(id,tittle_name,csrfToken) {
  let data = {
  id: id,
  tittle_name: tittle_name,
  '<?= csrf_token() ?>': csrfToken
};
    swal({
        title: "Are you sure?",
        text: "You will not be able to recover "+tittle_name+" details!",
        type: "warning",
        customClass: 'swal-wide',
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes, delete!",
        cancelButtonText: "No, cancel!",
        closeOnConfirm: false,
        closeOnCancel: false,
        height: '200px'
    }, function (isConfirm) {
        if (isConfirm) {
            $.ajax({
                type: "POST",
                url: 'delete-job_title',
                data: data,
                success: function (res) {
                    if (res.response == 1) {
                        swal({
                            title: "Deleted!",
                            text: " "+ res.message+" deleted successfully.",
                            type: "success"
                        }, function () {
                            location.reload();
                        });
                    }
                    else{
                        swal("Oops!", "Failed to delete "+ res.message+"!", "error");
                    }
                },
                error: function () {
                    swal("Oops!", "Something went wrong!", "error");
                }
            });
        } else {
            swal("Cancelled", "The "+tittle_name+" is safe", "info");
        }
    });
}
$(document).ready(function() {
    $('#tittle_table').DataTable({
        "pageLength": 10,           // Number of rows per page
        "lengthChange": false,      // Hide page length change dropdown (optional)
        "searching": true,          // Enable search
        "ordering": true            // Enable column sorting
    });
});

</script>