<?php
 helper('results_helper');

?>
                    <?php
if(isset($all_staff) && !empty($all_staff)):
    $i=0;
$stotal_basic_salary = 0;
$stotal_allowances = 0;
$stotal_gross_salary = 0;
$stotal_nssf = 0;
$stotal_nhif = 0;
$sctotal_social = 0;
$scumulate_nbt=0;
$scumulate_paye=0;
$snet_salary=0;
$scumulate_net_salary=0;
$sum_employee=0;
$sum_employer=0;


?>
     <div class="card">
    <div class="card-body">
    <table class="table table-bordered">
    <thead>
        <tr>
            <th> </th>
            <th>EMPLOYEES</th>
            <th>EMPLOYER</th>
            <th>TOTAL</th>
        </tr>
    </thead>
    <tbody>
        <?php
foreach($all_staff as $data):
        $sgross=$data->basic_salary + $data->allowances;
        $snssf=$sgross*(10/100);
        if($data->basic_salary<0){
        $snhif=0;
        }
        elseif($data->basic_salary<666666.67 && $data->basic_salary!=0){
            $snhif=20000;
        }
        else{
            $snhif=$data->basic_salary*(3/100);
        }

$salaryadvance = 0;
if (isset($salary_advances)) {
    foreach ($salary_advances as $advanc) {
        if ($advanc->staff_id == $data->user_id) {
            $salaryadvance = $advanc->advance_amount;
            break;
        }
    }
}
  
$stotal_basic_salary += $data->basic_salary;
$stotal_allowances += $data->allowances;
$stotal_social=$snssf+$snhif;
$stotal_gross_salary += $sgross;
$stotal_nssf += $snssf;
$stotal_nhif += $snhif;
$sctotal_social += $stotal_social;
$snbt =$sgross-$stotal_social;
$scumulate_nbt+=$snbt;
$spaye=calculate_paye($snbt, $brackets);
$scumulate_paye+=$spaye;
$wcf = $stotal_gross_salary*0.005;
$snet_salary=$snbt - ($spaye  + $salaryadvance);
$scumulate_net_salary+=$snet_salary;
$sum_employee=+($stotal_nssf+$stotal_nhif+$scumulate_paye);
$sum_employer=+($scumulate_net_salary+$stotal_nssf+$stotal_nhif+$wcf);
$sum_employer_employee=$sum_employer+$sum_employee;

        ?>
        <?php
endforeach;
?>
        <tr>
            <td style="text-align: left;">NET SALARIES</td>
            <td></td>
            <td style="text-align: right;"><?=format_number_with_decimals($scumulate_net_salary);?></td>
            <td style="text-align: right;"><b><?=format_number_with_decimals($scumulate_net_salary);?></b></td>
        </tr>
        <tr>
            <td style="text-align: left;">PENSION SCHEME</td>
            <td style="text-align: right;"><?=format_number_with_decimals($stotal_nssf);?></td>
            <td style="text-align: right;"><?=format_number_with_decimals($stotal_nssf);?></td>
            <td style="text-align: right;"><b><?=format_number_with_decimals($stotal_nssf*2);?></b></td>
        </tr>
        <tr>
            <td style="text-align: left;">NHIF</td>
            <td style="text-align: right;"><?=format_number_with_decimals($stotal_nhif);?></td>
            <td style="text-align: right;"><?=format_number_with_decimals($stotal_nhif);?></td>
            <td style="text-align: right;"><b><?=format_number_with_decimals($stotal_nhif*2);?></b></td>
        </tr>
        <tr>
            <td style="text-align: left;">PAYE</td>
            <td style="text-align: right;"><?=format_number_with_decimals($scumulate_paye);?></td>
            <td></td>
            <td style="text-align: right;"><b><?=format_number_with_decimals($scumulate_paye);?></b></td>
        </tr>
        <tr>
            <td style="text-align: left;">WCF</td>
            <td></td>
            <td style="text-align: right;"><?=format_number_with_decimals($wcf);?></td>
            <td style="text-align: right;"><b><?=format_number_with_decimals($wcf);?></b></td>
        </tr>
    </tbody>
    <tfoot>
        <tr style="font-weight: bold; background-color: #f0f0f0;">
            <td style="text-align: left;">TOTAL</td>
            <td style="text-align: right;"><?=format_number_with_decimals($sum_employee);?></td>
            <td style="text-align: right;"><?=format_number_with_decimals($sum_employer);?></td>
            <td style="text-align: right;"><?=format_number_with_decimals($sum_employer_employee);?></td>
        </tr>
    </tfoot>

</table>

                                        </div>
                                    </div>
                                    <?php
                                endif;?>