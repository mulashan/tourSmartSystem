<!-- <link rel="stylesheet" href="<?php //echo base_url('public/assets/plugins/select2/select2.css');?>"/> -->
<style>
    input.form-control {
    pointer-events: auto !important;
    background-color: white !important;
    z-index: 9999 !important;
    position: relative !important;
    width: 200px !important;
}
button, input[type="submit"], .btn {
  position: relative; 
  z-index: 9999 !important;
  pointer-events: auto !important;
}

</style>
<div class="card-body">
                    <form class="form-horizontal" id="loans_schedule" enctype="multipart/form-data">
<div class="row">
    <input type="hidden" id="staffs_id" name="staffs_id" value="<?=esc($staff_id);?>">
    <input type="hidden" id="totalloan_raw" name="total_amount">
                        <div class="col-md-12">
                        <div class="card" style="width:750px;">
                            <h5 Class=" d-flex justify-content-center mt-3">Loans Deductions Schedule</h5>

                        <div class="form-group row">
                            <div class="mr-4">
                                                <table class="table  table-borderless">
                                                  <tbody>
        <tr>
            <td>
                 <div class="text-center">
                <label class="col-form-label">Payroll Year<span class="text-danger">*</span></label>
</div>
            </td>
            <td>
 <div class="text-center">
                <label class="col-form-label">Payroll month<span class="text-danger">*</span></label>

            </div>
        </td>
            <td>
                 <div class="text-center">
                <label class="col-form-label">Amount<span class="text-danger">*</span></label>
            </div>
            </td>
            <td>+</td>
        </tr>
                                                   
                                                    
                                                        <tr>
                                                            <td>
                        <div class="text-center">
                   <select id="year" name="year" style="width:100%;" class="payroll-select form-control form-control-sm align-items-center year-dropdown form-select form-select-sm w-100" required>
                     <option value="" selected disabled >--please Select--</option>
                                    <?php
                                    $initial_year=2023;
                                    $current_year=date('Y');
                                    $final_year=$current_year+1;
                                    for ($initial_year; $initial_year <=$final_year ; $initial_year++) {          
                                        if($initial_year == $current_year){
echo '<option value="'.$initial_year. '"selected>' . $initial_year . '</option>';
                                        }else{
                                    ?>
                                   
                                    <option value="<?=$initial_year;?>" ><?=$initial_year;?></option>
                                  <?php

                                       }}
                                    ?>
         
                          </select>
                           <div class="invalid-feedback">Payroll Year required.</div>
                               </div>
                                                            </td>
                                                            <td>
                                             <div class="text-center">
               
                 <select id="month" name="month" style="width:100%;" class="payroll-select form-control form-control-sm align-items-center year-dropdown form-select form-select-sm w-100" required>

                         <option value="" selected disabled >--please Select--</option>
             <?php             
                                if(isset($months)){
                              foreach($months as $info){
                                 if($info->is_current==1){
                                    echo '<option value="'.$info->month_id. '"selected>' . $info->month . '</option>';   

                                 } else{      

                                   echo '<option value="'.$info->month_id. '">' . $info->month . '</option>';   
                                }}
                           
                              }
                               ?>                    
                 </select>
                  <div class="invalid-feedback">Payroll Month required.</div>
                                                </div>
                    
                                           
                                                            </td>
                                                            <td>
                                                               <div class="text-center"> 
        <input type="text"  class="form-control" name="advance_amount" oninput="advance_pay(this)"  id="advance_amount"  autocomplete="off">
<div class="input-error-message text-danger small"></div>

        </div>
                                                                    
                                                               </td>
                                                            <td>
                 <button type="button" id="click_schedule" class="btn btn-primary"><i class="fa fa-plus"></i></button>
                                                            </td>
                                                          
                                                        </tr>
                                                    </tbody>
                                                </table>
                                             <div class="advance_status">
                                                 
                                             </div><div class="amount_status">
                                                 
                                             </div>
                                                <hr>

                <table class="table table-hover table-vcenter mb-0 text-nowrap" style="">
                <thead>
                    <tr>
                        
                        <th>Payroll year</th>
                        <th>Payroll month</th>
                        <th class="text-right">Amount</th>                     
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody id="show_advances" style="">
                
                </tbody>
                <tfoot>
                     <tr> 
                    <td colspan="2"></td>
                    
                    <td class="text-right" style="font-size: 18px;">TOTAL = <span id="totalsum0">0</span></td>
                    <input type="hidden" id="totalsum0_input" name="totalsum0">
                    <td></td>
                 </tr>
                </tfoot>
               
                    </table>

</div>
           </div>
            </div>

                        </div><br>
                        <div class="form-group row">
                            <div class="col-md-8">
                                <button type="submit" id="create_advance" class="btn btn-primary float-right">Create</button>
                            </div>
                        </div>
                        </form>
                            </div>

 <script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
 <script type="text/javascript">

var account_ttl = 0;

$('#click_schedule').click(function (evt) {
    evt.preventDefault();
    var monthId = $('#month').val();
    var year = $('#year').val();
    var staff_id = $('#staffs_id').val();
    var ttl = parseFloat($('#advance_amount').val().replace(/,/g, '')) || 0;
    var descr = $('#description').val() || 'Advance';

    if (!monthId || !year || !ttl) {
        $('.amount_status').show();
        $('.amount_status').html('<span class="alert alert-warning">Please enter all fields correctly</span>');
        return;
    }

    $.ajax({
        type: 'POST',
        data: {payroll_month: monthId, year:year,staff_id:staff_id},
        url: '<?php echo base_url() . "/fetch_loan_month"; ?>',
        beforeSend: function () {
            $('.advance_status').html('<span class="spinner-border spinner-border-sm"></span> Loading item, please wait....');
            $('.amount_status').hide();
        },
        success: function (response) {
            let lData = JSON.parse(response);
            if (!Array.isArray(lData)) {
                lData = [lData];
            }

            for (let i = 0; i < lData.length; i++) {
                let monthName = lData[i]['month'];
                let monthID = lData[i]['month_id'];
                let savedAmount = lData[i]['loan_amount'];
                let payroll_id = lData[i]['payrolls'];
                let uniqueRowId = `${monthID}_${year}`;
                let formattedAmount = ttl.toLocaleString();

                if ($("#row_" + uniqueRowId).length) {
                    $('.advance_status').show();
                    $('.advance_status').html('<span class="alert alert-warning"><i class="fa fa-warning"></i> This payroll month and year have already been added.</span>');
                    return;
                }
                     if(savedAmount>0){
    $('.advance_status').html('<span class="alert alert-danger"><i class="fa fa-warning"></i> We found saved loan deduction schedule with this payroll month and year.</span>');
    return;
            }
                            if(payroll_id>0){
    $('.advance_status').html('<span class="alert alert-danger"><i class="fa fa-warning"></i> We found saved payroll with this details.</span>');
    return;
            }

                account_ttl += ttl;

                $('#show_advances').append(`
                    <tr id="row_${uniqueRowId}">
                        <input type="hidden" name="ttl[]" value="${ttl}">
                        <td>
                            <input type="hidden" name="payroll_year[]" value="${year}">
                            ${year}
                        </td>
                        <td>
                            <input type="hidden" name="payroll_month[]" value="${monthID}">
                            ${monthName}
                        </td>
                        <td class="text-right">
                            <input type="hidden" name="amount[]" value="${ttl}">
                            ${formattedAmount}
                        </td>
                        <td>
                            <button type="button" onclick="RemoveRow('${uniqueRowId}', ${ttl})" class="btn btn-danger btn-sm"><i class='fa fa-trash'></i></button>
                        </td>
                    </tr>
                `);
            }

            $("#totalsum0").html(account_ttl.toLocaleString());
            $("#totalsum0_input").val(account_ttl); 
            $("#thispay").html(account_ttl.toLocaleString());
            $("#totalloan_raw").val(account_ttl);
            $('.advance_status').hide();
            $('.amount_status').hide();
            $("#advance_amount").val('');
        },
        error: function () {
           $('.advance_status').show();
                    $('.advance_status').html('<span class="alert alert-danger"><i class="fa fa-warning"></i> Something went wrong.</span>');
        }
    });
});

function RemoveRow(id, amount) {
    $('#row_' + id).remove();
    account_ttl -= amount;
    $("#totalsum0").html(account_ttl.toLocaleString());
    $("#thispay").html(account_ttl.toLocaleString());
}
 
    $('.payroll-select').select2(); 

function advance_pay(elem) {
    const $errorDiv = $(elem).next(".input-error-message");
    const selectionStart = elem.selectionStart;
    const oldLength = elem.value.length;
    let rawValue = elem.value.replace(/,/g, '').replace(/[^\d.]/g, '');
    const parts = rawValue.split('.');
    if (parts.length > 2) {
        rawValue = parts[0] + '.' + parts[1];
    }
    const inputVal = parseFloat(rawValue) || 0;
    let formatted = '';
    if (rawValue !== '') {
        const [intPart, decPart] = rawValue.split('.');
        formatted = Number(intPart).toLocaleString(undefined, { maximumFractionDigits: 0 });
        if (decPart !== undefined) formatted += '.' + decPart.substring(0, 2); // limit to 2 decimals
    }
    elem.value = formatted;
    const newLength = elem.value.length;
    elem.selectionEnd = selectionStart + (newLength - oldLength);
    let total = 0;
    $('input[name="advance_amount"]').each(function () {
        const val = $(this).val().replace(/,/g, '');
        total += parseFloat(val) || 0;
    });

    $("#advance_amount").html(
        total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })
    );
}

$('#loans_schedule').submit(function(e){ 
    e.preventDefault();
    var form_data = new FormData(this); 
    var charges_date = $('#charges_date').val();
    form_data.append('charges_date', charges_date);
    $('#create_advance').prop("disabled", true);
    $.ajax({
        method: 'POST',
        url: '<?php echo base_url() . '/save_loan_info'; ?>',
        data: form_data,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function(data){
            if(data['status'] == "1"){
                         swal({
                title: 'Success',
                text: data['description'],
                type: "success",
                 confirmButtonText: "OK",
        closeOnConfirm: true
            },
            function(){
                window.location.reload();
    }            );

            } else {
                $('#create_advance').prop("disabled", false);
                swal("Warning", data['description'], "warning");
            }
        },
        error: function(xhr, status, error){
            $('#create_advance').prop("disabled", false);
            swal("Error", "Something went wrong while saving advances.", "error");
        }
    });
});


    </script>