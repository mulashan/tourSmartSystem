<div class="card">
	<div class="card-body">
			<table class="table table-borderless">
				<tr>
					<th>Staff Name:</th>
					<td><?=$ec->first_name?>
                       <?=$ec->last_name?></td>
				</tr>
				<tr>
				<th>charge date</th>
				<td><?=$ec->charge_date?></td>
				</tr>
				  <tr>
				  		<th>Payroll Year</th>
				  	<td><?=$ec->pay_year?></td>
				  </tr>
                       <tr>
                       	<th>Payroll Month</th>
                       <td><?=$ec->month;?></td>
                        </tr>
                        <tr>
                        	<th>Amount</th>
                       <td><?=format_number_with_decimals($ec->charge_amount);?></td>
                        	
                        </tr>
			</table>

		
                      <div class="d-flex justify-content-center mb-3">
                             <?php 
      if(empty($payrolls)){?>
              <button type="button" class="btn btn-danger btn-sm" onclick="delete_single(<?=esc($ec->charge_id);?>)" ><i class="fa fa-trash"></i> Delete</button>
                <?php }else{?>
                       <button type="button" class="btn btn-danger btn-sm" onclick="delete_single(<?=esc($ec->charge_id);?>)" disabled><i class="fa fa-trash"></i> Delete</button>
                     <?php }?>
          </div>
       
      
	</div>
</div>

<script>
function delete_single(id) {

  swal({
    title: "Are you sure?",
    text: "You will not be able to recover this data!",
    type: "warning",
    customClass: 'swal-wide',
    showCancelButton: true,
    confirmButtonClass: "btn-danger",
    confirmButtonText: "Yes, delete!",
    cancelButtonText: "No, cancel!",
    closeOnConfirm: false,
    closeOnCancel: false
  },

  function(isConfirm) {

    if (isConfirm) {

      $.ajax({
        url: '<?= base_url('/deletesinglecharges')?>',
        type: 'POST',
        data: { id: id},
        dataType: 'json',
        success: function(data) {

          if (data.status == 1) {

            swal({
              title: "Deleted!",
              text: "Data deleted.",
              type: "success"
            }, function () {
              window.location.reload();
            });

          } else {

            swal({
              title: "Warning!",
              text: "Data not deleted.",
              type: "warning"
            }, function () {
              window.location.reload();
            });

          }

        },

        error: function() {

          swal({
            title: "Failed",
            text: "Something is wrong.",
            type: "error"
          }, function () {
            window.location.reload();
          });

        }

      });

    } else {

      swal("Cancelled", "Data not deleted, process canceled by user.", "info");

    }

  });

}
     
</script>