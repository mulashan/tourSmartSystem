<?php
$usermodel = new App\Models\UsersModel();
?>
<style>
    #strengthMeter {
      width: 100%;
      height: 20px;
      background-color: lightgray;
    }
    #strengthBar {
      height: 100%;
      width: 0;
      background-color: red;
    }
  </style>
<div class="section-body">

    <?php
    echo session()->getFlashdata('res');
    ?>
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Profile</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                <?php 
                $login = new App\Models\LoginModel();
                $this->billmodel = new App\Models\BillModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">User Profile</li>
                </ol>
            </div>
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#pro">Profile</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#usern">Username</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#pass">Password</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="pro">
                <div class="card">
                    <form id="editingProfile" enctype="multipart/form-data" class="card-body">
                
                        <div class="row">
                           <?php if(session()->get('msg')){ ?>
                               <div id="edit"><?php echo session()->get('msg');?></div>
                           <?php }?>
                           <div class="col-md-6">
                            <div class="row mb-3">
                                
                             <?php
                             foreach($user as $user){ ?>
                                <label for="ename" class="col-sm-4 col-form-label col-form-label-sm">First Name</label>
                                <div class="col-sm-6">
                                    <input type="hidden" class="form-control form-control-sm" value="<?= $user->user_id;?>" name="user_id">
                                    <input type="hidden" class="form-control form-control-sm" value="<?= $user->status;?>" name="status">
                                    <input type="text" class="form-control form-control-sm" value="<?= $user->first_name;?>" name="first_name" placeholder="First Name" required="required">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="elname" class="col-sm-4 col-form-label col-form-label-sm">Last Name</label>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-sm" id="elname" value="<?= $user->last_name;?>" name="last_name" placeholder="Last Name" required="required">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="eoname" class="col-sm-4 col-form-label col-form-label-sm">Other Name</label>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-sm" id="eoname" value="<?= $user->other_name;?>" name="other_name" placeholder="Other Name">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="ephone" class="col-sm-4 col-form-label col-form-label-sm">Phone Number</label>
                                <div class="col-sm-6">
                                    <!-- <input type="tel" class="form-control form-control-sm" id="ephone" name="ephone" placeholder="Phone Number"> -->
                                    <input type="text" class="form-control" name="phone" value="<?= $user->phone_no;?>" placeholder="Phone Number" data-inputmask="&quot;mask&quot;: &quot;255 999 999 999&quot;" data-mask="" id="phone_no">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="ephone" class="col-sm-4 col-form-label col-form-label-sm">Gender</label>
                                <div class="col-sm-6">
                                    <select class="form-select form-control" name="gender" id="gender">
                                     <?php 
                                     $gender=$user->gender;
                                     
                                     ?>
                                     <option value="<?= $gender;?>" selected><?= $gender;?></option>

                                     <option value="Male">Male</option>
                                     <option value="Female">Female</option>
                                     
                                     <?php  ?>
                                 </select> 
                                 <!-- <input type="tel" class="form-control form-control-sm" id="ephone" name="ephone" placeholder="Phone Number"> -->
                                 
                             </div>
                         </div>
                             </div>

                             <div class="col-md-6">
                                <div class="row mb-3">
                                    <label for="enid" class="col-sm-4 col-form-label col-form-label-sm">National Id</label>
                                    <div class="col-sm-6">
                                        <input type="number" class="form-control form-control-sm" id="enid" value="<?= $user->national_id;?>" name="national_id" placeholder="eg: xxxxxxxx-xxxxx-xxxxx-xx">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="eemail" class="col-sm-4 col-form-label col-form-label-sm">Email</label>
                                    <div class="col-sm-6">
                                        <input type="email" class="form-control form-control-sm" id="eemail" value="<?= $user->email;?>" name="email" placeholder="eg: user@gmail.com">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="ulevl" class="col-sm-4 col-form-label col-form-label-sm">User Type</label>
                                    <div class="col-sm-6">
                                        

                                      <?php 
                                      $id=$user->user_type;
                                      
                                      $type=$usermodel->select_type();
                                      foreach($type as $type1){
                                       $typename=$type1->id;
                                       if($typename==$id){
                                          ?>
                                          <input type="text" class="form-control form-control-sm" id="enid" value="<?= $type1->type_name;?>"  readonly>
                                          <input type="hidden" class="form-control form-control-sm" id="enid" value="<?= $id;?>" name="user_type" readonly>
                                          <?php
                                      }
                                  } ?>
                                  
                                  
                              </div>
                          </div>
                          <div class="row mb-3">
                            <label for="eaddrs" class="col-sm-4 col-form-label col-form-label-sm">Physical Address</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control form-control-sm" value="<?= $user->physical_adress;?>" id="eaddrs" name="physical_adress" placeholder="Home Address">
                            </div>
                        </div>
                        <div class="form-group row">
                           <label class="col-md-3 col-form-label">Photo</label>
                           <div class="col-md-8">
                            <img src= "<?php echo base_url('public/users_photos/'.$user->user_photo);?> " id="output" style="width:84px;" alt="">
                            <input type="file" accept="image/*" name="photo" onchange="loadFile(event)">
                            <!-- <img id="output"/>-->
                            <input type="hidden" class="form-control" name="photo1" value="<?=$user->user_photo;?>" required="">
                        </div>
                        </div>
                        <br>
                        
                        
                        <!-- <input type="tel" class="form-control form-control-sm" id="ephone" name="ephone" placeholder="Phone Number"> -->
                        <div class="row mb-3">
                           <div class="col-sm-6">
                               <div class="d-flex justify-content-end mt-2 mb-3">
                                 <button type="submit" class="btn btn-primary save"><i class="me-2"></i>Save</button>
                             </div>   
                         </div>   
                         </div>
                        </div>

                        </div>


                        <?php 
                        $username=$user->username;
                        }?>

                    </form>
                </div>
            </div>
            <div class="tab-pane" id="usern">
                <div class="card">
                    <div class="card-body">
                        <div class="panel">
                            <div class="panel-body" style="background-color:white">
                                <form id="change" action="../username_updator" method="post">
                                    <table class="table table-striped">
                                        <tr>
                                            <th>Current Username</th>
                                            <td><input type="text" class="form-control" id="cun" placeholder="Current Username" value="<?php echo $username; ?>" readonly="readonly" required="required"></td>
                                            <th>Change to</th>
                                            <td><input type="text" name="nwusername" id="nwUn" class="form-control" placeholder="New Username" onkeyup="UsrNverifier()" autocomplete="off" maxlength="16" required="required">
                                                <div id="msg"></div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" id="ts"></td>
                                            <td>
                                                <center><input type="submit" id="ChngUsern" class="btn btn-primary" value="Change"></center>
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="pass">
                <div class="card">
                    <div class="card-body">
                        <div class="panel">
                            <div class="panel-body">
                                <form action="<?= base_url('password_change'); ?>" method="post">
                                    <table class="table table-striped">
                                        <tr>
                                            <td><input type="password" name="cpass" class="form-control" placeholder="Current Password" required="required"></td>
                                            <td><input type="password" name="newpass" id="newpass" class="form-control" placeholder="New Password" required="required" onkeyup="enter_newpass()">
                                             <div id="strengthMeter" class="mt-1">
                                            <div id="strengthBar"></div>
                                            </div>

                                            <p id="passantage">Strength: 0%</p>
                                            </td>
                                            <td><input type="password" name="renewpass" id="renewpass" class="form-control" placeholder="Confirm New Password" required="required" onkeyup="enter_renewpass()">
                                            <div id="rematch"></div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3">
                                                <input type="hidden" value="0" id="pswd_strength">
                                                <center><input type="submit" class="btn btn-primary" value="Change" id="pswdbtn"></center>
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">


    $('#editingProfile').on('submit',function (e) {
        //var Data=$(this).serialize();
     var form_data = new FormData(this);

           //alert(form_data);

           $.ajax({
            method: 'POST',
            //url: 'userEdit',
            url: "<?= base_url('profileEdit'); ?>",
            data: form_data,
            contentType: false,
            processData: false,
            success:function(data){
             $('#edit').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
             setTimeout(function(){
                window.location.reload();
            },1000)
         },
         error:function(){
            $('#edit').html('<div class="alert alert-success alert-dismissible" role="alert"><strong> Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
            setTimeout(function(){
             window.location.reload();
         },1000)
        }
    });
           
           e.preventDefault();
       });

var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
  }
};

 $('#ChngUsern').prop("disabled", true);
function UsrNverifier(){
    var username=$('#nwUn').val();
    if(username.length < 4){
   
     $('#msg').html('<div class="alert alert-warning text-red">* Write Atleast 4 characters</div>');   
    }else{
      $('#msg').html('');
     
       var dta='username='+username;
      $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/UsersController/check_username'; ?>',

                data: dta,
                success: function (res) {
                   if(res==0){
                   $('#ChngUsern').prop("disabled", false);  
                   }else{
                    $('#msg').html('<div class="alert alert-warning text-red">x Taken!</div>');
                     $('#ChngUsern').prop("disabled", true);  
                   }
                },
                error: function () {
                    $('#msg').html('<div class="alert alert-warning">Something went wrong!</div>');
                }
            });
       
    }
   
}


$('#pswdbtn').prop("disabled", true);
  function enter_newpass() {
    $('#rematch').html('');
      const password = document.getElementById('newpass').value;
      let strength = 0;

      // Check length (at least 8 characters)
      if (password.length >= 4) {
        strength += 25;
      }

      // Check for lowercase letters
      if (/[a-z]/.test(password)) {
        strength += 15;
      }

      // Check for uppercase letters
      if (/[A-Z]/.test(password)) {
        strength += 20;
      }

      // Check for numbers
      if (/\d/.test(password)) {
        strength += 20;
      }

      // Check for special characters
      if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        strength += 20;
      }

      // Update the strength bar and percentage
      const strengthBar = document.getElementById('strengthBar');
      const passantage = document.getElementById('passantage');
      
     

      // Change the bar color based on strength
      $('#pswd_strength').val(strength);
      if (strength < 50) {

         strengthBar.style.width = strength + '%';
      passantage.textContent = `Strength: ${strength}% -weak password`;
     strengthBar.style.backgroundColor = 'red';

      } else if (strength >= 50 && strength < 80) {
        
         strengthBar.style.width = strength + '%';
      passantage.textContent = `Strength: ${strength}%`;
        strengthBar.style.backgroundColor = 'orange';
      } else {
       
        strengthBar.style.width = strength + '%';
      passantage.textContent = `Strength: ${strength}%`;
        strengthBar.style.backgroundColor = 'green';
      }
    }

    function enter_renewpass() {
        var strenth =$('#pswd_strength').val();
       const password = document.getElementById('newpass').value;
      const repassword = document.getElementById('renewpass').value;
      if(password == repassword){
        
        if(strenth > 50){
           $('#rematch').html('<div class="alert alert-success text-black"><span class="fa fa-check"> password Match</span></div>');
           $('#pswdbtn').prop("disabled", false);

        }else{
        $('#rematch').html('<div class="alert alert-warning">x weak password </div>');
        $('#pswdbtn').prop("disabled", true);

        }
       
      }else{
       $('#rematch').html('<div class="alert alert-warning text-red">x Not Match</div>');
      }
    }

</script>



