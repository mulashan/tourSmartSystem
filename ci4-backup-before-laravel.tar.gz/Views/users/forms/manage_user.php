<?php
 $usermodel = new App\Models\UsersModel();
//  $id=0;
//  $username='';
?>
<div class="box box-default">
    <div class="box-header">
    </div>
    <div class="panel-body">
        <div class="nav-tabs-custom tab-primary">
		<div class="d-flex justify-content-between align-items-center ">
        <ul class="nav nav-tabs page-header-tab">
            <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#bd">Basic Information</a></li>
            <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#perms">Permissions</a></li>
            <?php if(session()->get('user_type') == 6){?>
            <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#items">Password</a></li>
        <?php }?>
        </ul>
    </div><br>
            <!--<ul class="nav nav-tabs">
                <li class="active"><a aria-expanded="true" href="#bd" data-toggle="tab">Basic Information</a></li>
                <li class=""><a aria-expanded="false" href="#perms" data-toggle="tab">Permissions</a></li>
                <li class=""><a aria-expanded="false" href="#pasw" data-toggle="tab">Password</a></li>
            </ul>-->
            <div class="tab-content" style="overflow-x: hidden">
                <div class="tab-pane active" id="bd">
                                <form id="editUser" enctype="multipart/form-data">
								
    <div class="row">
	<div id="edit"></div>
        <div class="col-md-6">
    <div class="row mb-3">
	<?php
	foreach($user as $user){ ?>
    <label for="ename" class="col-sm-4 col-form-label col-form-label-sm">First Name</label>
    <div class="col-sm-6">
        <input type="hidden" class="form-control form-control-sm" value="<?= $user->user_id;?>" name="user_id">
        <input type="text" class="form-control form-control-sm" value="<?= $user->first_name;?>" name="first_name" placeholder="First Name" required="required" <?php if($user->user_type != 6){ echo "readonly";}?>>
    </div>
</div>
<div class="row mb-3">
    <label for="elname" class="col-sm-4 col-form-label col-form-label-sm">Last Name</label>
    <div class="col-sm-6">
        <input type="text" class="form-control form-control-sm" id="elname" value="<?= $user->last_name;?>" name="last_name" placeholder="Last Name" required="required" <?php if($user->user_type != 6){ echo "readonly";}?>>
    </div>
    </div>
    <div class="row mb-3">
        <label for="eoname" class="col-sm-4 col-form-label col-form-label-sm">Other Name</label>
        <div class="col-sm-6">
            <input type="text" class="form-control form-control-sm" id="eoname" value="<?= $user->other_name;?>" name="other_name" placeholder="Other Name" <?php if($user->user_type != 6){ echo "readonly";}?>>
        </div>
    </div>
<div class="row mb-3">
<label for="ephone" class="col-sm-4 col-form-label col-form-label-sm">Phone Number</label>
<div class="col-sm-6">
    <!-- <input type="tel" class="form-control form-control-sm" id="ephone" name="ephone" placeholder="Phone Number"> -->
    <input type="text" class="form-control" name="phone" value="<?= $user->phone_no;?>" placeholder="Phone Number" data-inputmask="&quot;mask&quot;: &quot;255 999 999 999&quot;" data-mask="" id="phone_no" required="required">
</div>
</div>
<div class="row mb-3">
<label for="ephone" class="col-sm-4 col-form-label col-form-label-sm">Gender</label>
<div class="col-sm-6">
<select class="form-select form-control bor-radius5" name="gender" id="gender" required="required">
   <?php 
$gender=$user->gender;

		?>
<option value="<?= $gender;?>" selected><?= $gender;?></option>

<option value="Male">Male</option>
<option value="Female">Female</option>
  
<?php  ?>
</select> 
	<!-- <input type="tel" class="form-control form-control-sm" id="ephone" name="ephone" placeholder="Phone Number"> -->
    
</div>
</div>

 <div class="row mb-3">
<label for="dob" class="col-sm-4 col-form-label col-form-label-sm">Date of Birth<span class="text-danger">*</span></label>
<div class="col-sm-6">
<?php
if($user->birth_date!=0){
    $birth=date("Y-m-d",strtotime($user->birth_date));
}else{
      $birth=date("Y-m-d");
}
?>
<input type='date' class="form-control form-control-sm"  name="dob2" id='datetimepicker3' placeholder="2000-07-24"   max="<?=date('Y-m-d');?>" value="<?=$birth?>" />
</div>
</div>

<fieldset class="row mb-3">
<legend class="col-sm-4 col-form-label col-form-label-sm">Staff<span class="text-danger">*</span></legend>
<div class="col-sm-6">
<div class="form-check">
<input class="form-check-input" type="radio" name="staff2" id="non_staff" value="0" <?php if($user->staff==0){ echo 'checked'; }?>>
<label class="form-check-label" for="emale">
Non Staff
</label>
</div>
<div class="form-check">
<input class="form-check-input" type="radio" name="staff2" id="staff" value="1" <?php if($user->staff==1){ echo 'checked'; }?>>
<label class="form-check-label" for="efemale">
Staff
</label>
</div>
</div>
</fieldset>
</div>

        <div class="col-md-6">
            <div class="row mb-3">
                <label for="enid" class="col-sm-4 col-form-label col-form-label-sm">National Id</label>
                <div class="col-sm-6">
                    <input type="number" class="form-control form-control-sm" id="enid" value="<?= $user->national_id;?>" name="national_id" placeholder="eg: xxxxxxxx-xxxxx-xxxxx-xx">
                </div>
            </div>
            <div class="row mb-3">
                <label for="eemail" class="col-sm-4 col-form-label col-form-label-sm">Email</label>
                <div class="col-sm-6">
                    <input type="email" class="form-control form-control-sm" id="eemail" value="<?= $user->email;?>" name="email" placeholder="eg: user@gmail.com">
                </div>
            </div>
            <div class="row mb-3">
                <label for="ulevl" class="col-sm-4 col-form-label col-form-label-sm">User Type</label>
                <div class="col-sm-6">
				
                  <select class="form-select form-control bor-radius5" name="user_type" id="gender">
				  <?php 
				$id=$user->user_type;
				
				$type=$usermodel->select_type();
				foreach($type as $type1){
					$typename=$type1->id;
                    if($type1->id==6 && $id!=6){
                        continue;
                    }
					if($typename==$id){
						?>
			<option value="<?= $id;?>" selected><?= $type1->type_name;?></option>
						<?php
					}else{
				
				?>
				
                  <option value="<?= $typename;?>"><?= $type1->type_name;?></option>
                  
				<?php }} ?>

            </select>
                </div>
            </div>
            <div class="row mb-3">
                <label for="eaddrs" class="col-sm-4 col-form-label col-form-label-sm">Physical Address</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control form-control-sm" value="<?= $user->physical_adress;?>" id="eaddrs" name="physical_adress" placeholder="Home Address">
                </div>
            </div>
			<div class="row mb-3">
                <label for="ephone" class="col-sm-4 col-form-label col-form-label-sm">Status</label>
                <div class="col-sm-6">
				<select class="form-select form-control bor-radius5" name="status" id="stat">
                   <?php 
				$status=$user->status;
				if($status==1){
					$name="Active";
				}else{
					$name="Inactive";
				}
						?>
			<option value="<?= $status;?>" selected><?= $name;?></option>

				<option value="1">Active</option>
				<option value="2">Inactive</option>
                  
				<?php  ?>
				</select> 
					<!-- <input type="tel" class="form-control form-control-sm" id="ephone" name="ephone" placeholder="Phone Number"> -->
                    
                </div>
            </div>
            
   <div class="form-group row">
     <label class="col-md-3 col-form-label">Photo</label>
    <div class="col-md-8">
        <img src= "<?php echo base_url('public/users_photos/'.$user->user_photo);?> " id="output" style="width:84px;" alt="">
          <input type="file" accept="image/*" name="photo" onchange="loadFile(event)">
    <!-- <img id="output"/>-->
     <input type="hidden" class="form-control" name="photo1" value="<?=$user->user_photo;?>" required="">
</div>
</div>
        </div>
        <div class="d-flex justify-content-end mt-2 mb-3">
            <button type="submit" class="btn btn-primary"><i class="fa fa-edit me-2"></i>Update</button>
        </div>
			<?php 
			$username=$user->initial_username;
			//$userid=$user->user_id;
			}?>
    </div>
</form>
                </div>
                <div class="tab-pane" id="perms">
                    <div class="row">
                    <div class="col-md-6">
                        <div class="box box-default">
                            <div class="box-header with-border" style="border-bottom:1px solid lightblue;border-top:1px solid lightblue;">
                                <h5 class="box-title">Unassigned Modules</h5>
                            </div>
                            <div class="box-body" style="max-height: 450px;overflow-x: hidden" id="unPermssn"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="box box-default">
                            <div class="box-header with-border" style="border-bottom:1px solid lightblue;border-top:1px solid lightblue;">
                               
                                <h5 class="box-title">Special Modules assigned</h5>
                            </div>
                            <div class="box-body" style="max-height: 300px;overflow-x: hidden" id="speclPermssn">

                            </div>
                        </div>
                    
                    <hr style="color:blue;border-bottom:1px solid blue;">
                    <div class="">
                        <div class="box box-danger" style="border-top:3px solid red;">
                            <div class="box-header with-border" style="border-bottom:1px solid lightblue;border-top:1px solid lightblue;">
                                
                                <h5 class="box-title">User type Modules assigned</h5>
                            </div>
                            <div class="box-body" style="max-height: 350px;overflow-x: hidden">
                                <table class="table table-bordered">
                                    <tr>
                                        <th>S/N</th>
                                        <th>Module name</th>
                                        <th>Descriptions</th>
                                    </tr>
                                    <?php
                                    $m = 0;
                                    foreach ($setting as $prev):
                                        $m++;
                                        ?>
                                        <tr class="trow" style="height: 25px">
                                            <td><center><?php echo $m; ?></center></td>
                                        <td><?php echo $prev->label; ?></td>
                                        <td><?php echo $prev->description; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </table>
                            </div>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                <div class="tab-pane" id="items">
                    <h5>Reset Password</h5>
                    <form id="PaswdReset">
                        <table class="table table-bordered" style="width:70%">
                            <tr>
                                <th>Reset to </th>
                                <td>
                                    <input type="hidden" name="pid" value="<?//=$userid;?>" readonly="">
                                    <input type="text" class="form-control" name="nwpswd">
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2"><button type="submit" class="btn btn-primary pull-right">Update</button> </td>
                            </tr>
                        </table>

                        <span id="prfeedback"></span>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>

   loadSpecialPermission();

    function loadSpecialPermission() {
        $('#unPermssn').load('<?php echo base_url() . '/unassgnd_permissions/' . $id.'/'.$username; ?>');
        $('#speclPermssn').load('<?php echo base_url() . '/load_special_permissions/' . $username; ?>');
    }

    function AssgnSpecialModule(modId) {
        var perdata = "modl=" + modId + "&user=<?php echo $username; ?>";
        $.ajax({
            data: perdata,
            url: '<?php echo base_url() . '/add_special_permissions'; ?>',
            type: 'POST',
            success: function (rs) {
                loadSpecialPermission();
            },
            error: function () {
                alert('Sorry! Something went wrong');
            }
        });
    }

    function UnassgnSpecialModule(modId) {
        var perdata = "modl=" + modId + "&user=<?php echo $username; ?>";
        $.ajax({
            data: perdata,
            url: '<?php echo base_url() . '/remove_special_permissions'; ?>',
            type: 'POST',
            success: function (rs) {
                loadSpecialPermission();
            },
            error: function () {
                alert('Sorry! Something went wrong');
            }
        });
    }

    $('#PaswdReset').submit(function (e) {
        $.ajax({
            data: $(this).serialize(),
            url: '<?php echo base_url() . '/password_reset'; ?>',
            type: 'POST',
            success: function (rs) {
                $('#prfeedback').html(rs);
            },
            error: function () {
                alert('Sorry! Something went wrong');
            }
        });
        e.preventDefault();
    });

//validation of inputs ......................

   
	$('#editUser').submit(function(e){
		//var Data=$(this).serialize();
       var form_data = new FormData(this);
          // alert(Data);

        $.ajax({
            method: 'POST',
            //url: 'userEdit',
			url: "<?= base_url('userEdit'); ?>",
            data: form_data,
            contentType: false,
            processData: false,
			//dataType: 'json',
            success:function(data){
			$('#edit').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
                setTimeout(function(){
           window.location.reload();
        },1000)
            },
            error:function(data){
				$('#edit').html('<div class="alert alert-success alert-dismissible" role="alert"><strong> Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
          setTimeout(function(){
           //window.location.reload();
        },1000)
            }
        });
        
        e.preventDefault();
    });
var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  };
</script>
                               