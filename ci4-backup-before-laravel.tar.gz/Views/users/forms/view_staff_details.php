<?php
$smodel = new App\Models\StudentModel();
$department = $smodel->gettable_data('departments_tbl',$where = array('id >' => 0));
$job_title = $smodel->gettable_data('job_tittle_tbl',$where = array('id >' => 0));
 $classification = $smodel->gettable_data('classification_tbl',$where = array('id >' => 0));


?>
  <style type="text/css">

     .invoice > .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }
  

 </style>

<div class="row">
  
 <div class="col-md-6">
        <div class="card invoice">
 <div class="card-header">
                <h5>Staff Information</h5>
            </div>
            </hr>


            <div class="card-body">
               
                <table class="table table-borderless">
                    <?php
         if(isset($det) && !empty($det)):
         $user_photo=$det[0]->user_photo;
                        ?>
                    <tr>
                    <td>
                        <?php
                         if($user_photo !=''){
                        ?>
                        <img src="<?=base_url('public/users_photos').'/'.$user_photo;?>" width="90" height="90" alt="User Image" style="border:2px solid black;">
                        <?php
                        }else{
                        ?>
                        <img src="<?=base_url('public/users_photos/default_picture.png');?>" width="90" height="90" alt="User Image" style="border:2px solid black;">
                        <?php
                    }
                        ?> 
                    </td>
                    </tr>

                    <tr>
                        <th>Name:</th>
                        <td><?= $det[0]->first_name." ".$det[0]->last_name; ?></td>
                    </tr>
                     <tr>
                        <th>Gender:</th>
                        <td><?= $det[0]->gender; ?></td>
                    </tr>
                     <?php 
                        if(count($classification)>0){
                            if(count($staff_details)>0){
                              if($staff_details[0]->classfication_id==$classification[0]->id){  
                         ?>
                    <tr>
                        <th>Classification:</th>
                        <td><?= $classification[0]->class_name; ?></td>
                    </tr>
                    <?php
                    } }}
                     ?>
                    <tr>
                        <th>Address:</th>
                        <td><?= $det[0]->physical_adress; ?></td>
                    </tr>
                    <tr>
                        <?php
           $user_type = $smodel->gettable_data('users_type_tbl',$where = array('id' => $det[0]->user_type));
                        ?>
                        <th>user type:</th>
                        <td><?= $user_type[0]->type_name??""; ?></td>
                    </tr>
                   
                    <tr>
                        <th>Phone:</th>
                        <td><?= $det[0]->phone_no; ?></td>
                    </tr>
                     <tr>
                        <th>Email:</th>
                        <td><?= $det[0]->email; ?></td>
                    </tr>

                      <tr>
                        <th>DOB:</th>
                        <td><?= $det[0]->birth_date; ?></td>
                    </tr>
                     <tr>
                        <th>STAFF STATUS:</th>
                                                 <?php 
                                                  if(count($staff_details)>0){ 
$status = "<span class='badge badge-{$staff_details[0]->status_color}'>{$staff_details[0]->status_name}</span>";
}
?>
<td><?= $status; ?></td>
                    </tr>
<?php
endif;
?>
                </table>
            </div>
        </div>
    </div>

     <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Staff Information</h5>
            </div>
            </hr>

            <div class="card-body">
               
                <table class="table table-borderless">
                    <tr>
                        <?php 
                        $dep="--";
                        if(count($staff_details)>0){ 
                          $dep_type = $smodel->gettable_data('departments_tbl',$where = array('id' => $staff_details[0]->dep_id));
                          $dep=$dep_type[0]->dep_name??"";
                            }?> 
                        <th>Department:</th>
                        <td><?= $dep; ?></td>
                    </tr>
                    <tr>
                        <?php 
                        $jonname="--";
                        if(count($staff_details)>0){ 
                          $job = $smodel->gettable_data('job_tittle_tbl',$where = array('id' => $staff_details[0]->job_id));
                          $jonname=$job[0]->job_tittle??"";
                            }?> 
                        <th>job tittle:</th>
                        <td><?= $jonname; ?></td>
                    </tr>
                      <tr>
                        <?php 
                        $employ_type="--";
                        if(count($staff_details)>0){ 
                        if($staff_details[0]->employment_type==1){
                           $employ_type= 'Primary';

                            }elseif($staff_details[0]->employment_type==2){
                            $employ_type= 'Secondary';
                            }}

                            ?> 
                        
                        <th>Employment type:</th>
                        <td><?= $employ_type; ?></td>
                    </tr>
                      <tr>
                        <?php 
                        $resident="--";
                         if(count($staff_details)>0){ 
                        if($staff_details[0]->residential_status==1){
                           $resident= 'Resident';

                            }elseif($staff_details[0]->residential_status==2){
                            $resident= 'Non - Resident';
                            }}

                            ?> 
                        <th>Residential status:</th>
                        <td><?= $resident; ?></td>
                    </tr>
                    <tr>
                        <?php 
                        $bsalary="--";
                        if(count($staff_details)>0){ 
                            $bsalary=$staff_details[0]->basic_salary;
                            }?> 
                        <th>Basic Salary:</th>
                        <td><?= $bsalary; ?></td>
                    </tr>
                    <tr>
                        <?php 
                        $allowance="--";
                        if(count($staff_details)>0){ 
                            $allowance=$staff_details[0]->allowances;
                            }?> 
                        <th>Allowances:</th>
                        <td><?= $allowance??""; ?></td>
                    </tr>
                   
                    <tr>
                            <?php 
                        $expiry="--";
                        if(count($staff_details)>0){ 
                            $expiry=date('Y-m-d',strtotime($staff_details[0]->contract_expiry_date));
                            }?>
                        <th>Contract Expiry:</th>
                        <td><?= $expiry; ?></td>
                    </tr>
                     <tr>
                        <?php 
                        $account="--";
                        if(count($staff_details)>0){ 
                            $account=$staff_details[0]->account_number;
                            }?>
                        <th>Bank Account Number:</th>
                        <td><?= $account; ?></td>
                    </tr>
  <tr>
                        <?php 
                        $acc_name="--";
                        if(count($staff_details)>0){ 
                            $acc_name=$staff_details[0]->account_name;
                            }?>
                        <th>Bank Account Name:</th>
                        <td><?= $acc_name; ?></td>
                    </tr>
                      <tr>
                        <?php 
                        $bank_name="--";
                        if(count($staff_details)>0){ 
                            $bank_name=$staff_details[0]->bank_name;
                            }?>
                        <th>Bank name:</th>
                        <td><?= $bank_name; ?></td>
                    </tr>
                    <tr>
                        <?php 
                        $pension="--";
                        if(count($staff_details)>0){ 
                            $pension=$staff_details[0]->pension_no;
                            }?>
                        <th>pension:</th>
                        <td><?= $pension; ?></td>
                    </tr>

                    <tr>
                        <?php 
                        $tin="--";
                        if(count($staff_details)>0){ 
                            $tin=$staff_details[0]->tin_no;
                            }?>
                        <th>TIN No:</th>
                        <td><?= $tin; ?></td>
                    </tr>

                     <tr>
                         <?php 
                        $nhf="--";
                        if(count($staff_details)>0){ 
                            $nhf=$staff_details[0]->nhf_no;
                            }?>
                        <th>NHIF No:</th>
                        <td><?= $nhf; ?></td>
                    </tr>
                          <tr>
                         <?php 
                        $heslb="--";
                        if(count($staff_details)>0){ 
                            $heslb=$staff_details[0]->heslb_no;
                            }?>
                        <th>HESLB No:</th>
                        <td><?= $heslb; ?></td>
                    </tr>
                    <tr>
                          <?php 
                        $wcf="--";
                        if(count($staff_details)>0){ 
                            $wcf=$staff_details[0]->wcf_no;
                            }?>
                        <th>wcf no:</th>
                        <td><?= $wcf; ?></td>
                    </tr>
                      <?php
                  if(session()->get('db_id')==17){
                ?>
                      <tr>
                          <?php 
                        $tucta_status="--";
                        if(count($staff_details)>0){ 
                            $tucta_status=$staff_details[0]->tucta_status;
                            }?>
                        <th>TUCTA:</th>
                        <td><?php if($tucta_status==1){
echo "<span class='badge badge-success'><b>Covered</b></span>";
                        }else{
echo "<span class='badge badge-warning'> <b>Not Covered</b></span>";
                        } ?></td>
                    </tr>
                          <tr>
                          <?php 
                        $housing="--";
                        if(count($staff_details)>0){ 
                            $housing=$staff_details[0]->housing;
                            }?>
                        <th>Housing:</th>
                        <td><?= format_number_with_decimals($housing); ?></td>
                    </tr>
                          <tr>
                          <?php 
                        $other_loans="--";
                        if(count($staff_details)>0){ 
                            $other_loans=$staff_details[0]->other_loans;
                            }?>
                        <th>Other Loans:</th>
                        <td><?= format_number_with_decimals($other_loans); ?></td>
                    </tr>
                          <tr>
                          <?php 
                        $maafa="--";
                        if(count($staff_details)>0){ 
                            $maafa=$staff_details[0]->maafa;
                            }?>
                        <th>Maafa:</th>
                        <td><?= format_number_with_decimals($maafa); ?></td>
                    </tr>
                  <?php
                }
                ?>

                </table>
            </div>
        </div>
    </div>
<div class="col-md-12">
    <div class="card invoice">
        <div class="card-header"><h5>Payroll Transaction History</h5></div>
        <div class="card-body">

            <div>
                <center>
                                        <div class="row mb-3 text-center">
          <label for="year" class="col-sm-4 col-form-label">Payroll Year:<span class="text-danger">*</span></label>
                  <div class="col-sm-8 d-flex align-items-center">
                   <select id="year" name="year" style="width:300px;" class="getpayroll-select form-control form-control-sm align-items-center year-dropdown" required>
                     <option value="0" selected>-- All --</option>
                                    <?php
                                    $initial_year=2023;
                                    $current_year=date('Y');
                                    $final_year=$current_year+1;
                                    for ($initial_year; $initial_year <=$final_year ; $initial_year++) { 
                                    ?>
                                   
                                    <option value="<?=$initial_year;?>" ><?=$initial_year;?></option>
                                  <?php

                                       }
                                    ?>
         
                          </select>
                           <div class="invalid-feedback">Payroll Year required.</div>
                               </div>
                                   </div>
                        <div class="row mb-3 text-center">
          <label for="month" style='color: black; font-weight: normal;' class="col-sm-4 col-form-label">Payroll Month:<span class="text-danger">*</span></label>
                  <div class="col-sm-8 d-flex align-items-center">
                 <select id="month" name="month" style="width:300px;" class="getpayroll-select form-control" required>

                         <option value="" selected disabled >--please Select--</option>
             <?php             
                                if(isset($months)){
                                     echo '<option value="0"selected> -- All -- </option>';
                              foreach($months as $info){
                                        

                                   echo '<option value="'.$info->month_id. '">' . $info->month . '</option>';   
                                }
                           
                              }
                               ?>                    
                 </select>
                  <div class="invalid-feedback">Payroll Month required.</div>
                                                </div>
                    
                                            </div> 
                </center>
                
            </div>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>TRANS NO.</th>
                        <th>DATE</th>
                        <th>TRANS TYPE</th>
                        <th>YEAR</th>
                        <th>MONTH</th>
                        <th>AMOUNT</th>
                        <th>PAID</th>
                        <th>BALANCE</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
           if(isset($payrolls)):
            $total_amounts=0;
            $total_paid=0;
            $total_balance=0;
            foreach($payrolls as $paments):
                 $total_amounts +=$paments->net_salaries;
                 $total_paid +=$paments->paid_amount;
                 $total_balance +=$paments->net_salary_balances;
                    ?>
                    <tr>
                        <td><?=$paments->payroll_id;?></td>
                        <td><?=$paments->payroll_date;?></td>
                        <td><?=$paments->type_name;?></td>
                        <td><?=$paments->payroll_year;?></td>
                        <td><?=$paments->month?></td>
                        <td><?=number_format($paments->net_salaries);?></td>
                        <td><?=number_format($paments->paid_amount);?></td>
                        <td><?=number_format($paments->net_salary_balances);?></td>
                        <td>
                            <button class="btn btn-primary" id="payrolldata" onclick="view_payroll(<?=$paments->payroll_id;?>,<?=$paments->staff_id;?>)"><i class="fa fa-eye"></i> View</button>
                        </td>
                        
                    </tr>
                    <?php
                endforeach;
endif;
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="5">TOTAL</td>
                        <td><b><?=number_format($total_amounts);?></b></td>
                        <td><b><?=number_format($total_paid);?></b></td>
                        <td><b><?=number_format($total_balance);?></b></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
            <!-- ==========================================view modal========================================== -->
            <div class="modal fade" id="payrolldata_view">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <!-- <h4 class="modal-title">Barcode Search output</h4> -->
        <button type="button" class="text-danger btn-close" onclick="closebarcodemodal(event)"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body ">
      <div class="load_status"></div>
      <div class="load_payroll_results"></div>
      </div>
      <div class="modal-footer">
          
      </div>
</div>
</div>
</div>
<!-- =====================================view modal================================= -->
        </div>
    </div>

</div>
<div class="col-md-12">
    <div class="card invoice">
        <div class="card-header"><h5>Salary Advances History</h5></div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>TRANS NO.</th>
                        <th>DATE</th>
                        <th>TRANS TYPE</th>
                        <th>VOUCHER TYPE</th>
                        <th>AMOUNT</th>
                        <th>DEDUCTED</th>
                        <th>BALANCE</th>
                        <th>ACTION</th>
                       </tr>
                </thead>
                <tbody>
                    <?php
                     $total_advances=0;
                     $total_deduction=0;
                     $total_balance=0;
           if(isset($advances)):
           
            foreach($advances as $salary_advances):
                 $total_advances +=$salary_advances->amount;
                 $deducted=0;
                   if(isset($paid_adv)){
                    foreach($paid_adv as $paid){
                            $deducted +=$paid->advance_amount;
                    } 
                    }
                    $balance=$salary_advances->amount-$deducted;
                    $total_deduction +=$deducted;
                    $total_balance +=$balance;
                    ?>
                    <tr>
                        <td><?=$salary_advances->transaction_id;?></td>
                        <td><?=$salary_advances->trans_date;?></td>
                        <td><?=$salary_advances->type_name;?></td>
                        <td><?='Salary Advance';?></td>
                        <td><?=number_format($salary_advances->amount);?></td>
                        <td><?=number_format($deducted);?></td>
                        <td><?=number_format($balance);?></td>
                        <td>
            <button class="btn btn-primary" id="payrolldata" onclick="view_advance_transaction(<?=$salary_advances->transaction_id;?>,<?=$salary_advances->staff_id;?>)"><i class="fa fa-eye"></i> View</button>
                        </td>

                    </tr>
                    <?php
                endforeach;
                  endif;
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4"><b>TOTAL</b></td>
                        <td><b><?=number_format($total_advances);?></b></td>
                        <td><b><?=number_format($total_deduction);?></b></td>
                        <td><b><?=number_format($total_balance);?></b></td>
                        <td></td>
                        
                    </tr>
                </tfoot>
            </table>
            <!-- ==========================================view modal========================================== -->
            <div class="modal fade" id="payrolldata_view">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <!-- <h4 class="modal-title">Barcode Search output</h4> -->
        <button type="button" class="text-danger btn-close" onclick="closebarcodemodal(event)"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body ">
      <div class="load_status"></div>
      <div class="load_payroll_results"></div>
      </div>
      <div class="modal-footer">
          
      </div>
</div>
</div>
</div>


<div class="modal fade" id="advancedata_view">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <button type="button" class="text-danger btn-close" onclick="closeadvancemodal(event)"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body ">
      <div class="load_status"></div>
      <div class="load_payroll_results"></div>
      </div>
      <div class="modal-footer">
          
      </div>
</div>
</div>
</div>
<!-- =====================================view modal================================= -->
        </div>
    </div>
    <?php
    if(!empty($staff_details)){
        if(empty($payrolls)){
    ?>
    <button class="btn btn-danger" onclick="delete_staff(<?=$staff_details[0]->user_id?>)">Delete</button>
    <?php
}
else{
    echo ' <button class="btn btn-danger" onclick="delete_staff(<?=$staff_details[0]->user_id?>)" disabled>Delete</button>';
}
}
    ?>
</div>
</div>
<script>
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    $('.getpayroll-select').select2();
});


    function view_payroll(payroll_id,staff_id) {
     $('#payrolldata_view').modal('show');
      var payroll_id = payroll_id;
    var staff_id = staff_id;
     $.ajax({
        type: "POST",
        url: 'Get-Details',
        data:{staff_id:staff_id,
            payroll_id: payroll_id},
        beforeSend: function () {
              $('.load_status').html('<span class="spinner-border spinner-border-sm"></span> Loading item, please wait....');
        },
        success: function (response) {
                   if(response){
            $('.load_payroll_results').html(response);
              $('.load_status').html('');     
      }
        else{
            $('.load_item_output').html('');
        $('.load_status').html('<span class="alert alert-warning">failed to load issue type</span>');
            }
        },
 error: function (xhr, status, error) {
    $('.load_status').html(
        '<div class="alert alert-danger" role="alert">' +
            '<strong>Error:</strong> Failed to load staff data.<br>' +
            'Status code: ' + xhr.status + '<br>' +
            'Details: ' + error +
        '</div>'
    );
}

    });
    
}

        function delete_staff(staff_id) {
    swal({
        title: "Are you sure?",
        text: "You will not be able to recover details!",
        type: "warning",
        customClass: 'swal-wide',
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes, delete!",
        cancelButtonText: "No, cancel!",
        closeOnConfirm: false,
        closeOnCancel: false,
        height: '200px'
    }, function (isConfirm) {
        if (isConfirm) {
            $.ajax({
                type: "POST",
                url: 'delete_staff_details',
                data: { staff_id: staff_id },
                success: function (res) {
                    if (res.response == 1) {
                        swal({
                            title: "Deleted!",
                            text: "Staff deleted successfully.",
                            type: "success"
                        }, function () {
                            location.reload();
                        });
                    }
                    else{
                        swal("Oops!", "Failed to delete!", "error");
                    }
                },
                error: function () {
                    swal("Oops!", "Something went wrong!", "error");
                }
            });
        } else {
            swal("Cancelled", "The staff details are safe", "info");
        }
    });
}
    function view_advance_transaction(transaction_id,staff) {
     $('#advancedata_view').modal('show');
      var transaction_id = transaction_id;
      var staff = staff;
     $.ajax({
        type: "POST",
        url: 'Get-Advances',
        data:{transaction_id:transaction_id,staff:staff},
        beforeSend: function () {
              $('.load_status').html('<span class="spinner-border spinner-border-sm"></span> Loading item, please wait....');
        },
        success: function (response) {
                   if(response){
            $('.load_payroll_results').html(response);
              $('.load_status').html('');     
      }
        else{
            $('.load_item_output').html('');
        $('.load_status').html('<span class="alert alert-warning">failed to load issue type</span>');
            }
        },
 error: function (xhr, status, error) {
    $('.load_status').html(
        '<div class="alert alert-danger" role="alert">' +
            '<strong>Error:</strong> Failed to load staff data.<br>' +
            'Status code: ' + xhr.status + '<br>' +
            'Details: ' + error +
        '</div>'
    );
}

    });
    
}
function closeadvancemodal(event){
    event.preventDefault();
          $('#advancedata_view').modal('hide');
              setTimeout(function () {
        if ($('.modal.show').length > 0) {
            $('body').addClass('modal-open');
        }
    }, 500);

}
</script>