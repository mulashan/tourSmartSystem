<div class="card">
	<div class="card-body">
		<div id="edit_msg"></div>
		<form id="save_chnges">
			<table class="table table-borderless">
				<tr>
					<th>Staff Name:</th>
					<td><?=$ec->first_name?>
                       <?=$ec->last_name?></td>
				</tr>
				<tr>
				<th>charge date</th>
				<td><?=$ec->charge_date?></td>
				</tr>
				  <tr>
				  		<th>Payroll Year</th>
				  	<td><?=$ec->pay_year?></td>
				  </tr>
                       <tr>
                       	<th>Payroll Month</th>
                       <td><?=$ec->month;?></td>
                        </tr>
                        <tr>
                        	<th>Old Amount</th>
                       <td><?=format_number_with_decimals($ec->charge_amount);?></td>
                        	
                        </tr>
                         <tr>
                        	<th>New Amount</th>
                       <td> <input type="text" class="form-control" name="new_amount" value="<?=format_number_with_decimals($ec->charge_amount);?>" id="new_amount">
                       	<input type="hidden" name="charge_id" id="charge_id" value="<?=$ec->charge_id;?>"></td>
                        	
                        </tr>
			</table>

			 <div class="col-sm-2 text-start">
            <button type="submit" class="btn btn-primary btn-sm" id="editbtn">
                Update
            </button>
        </div>
		</form>

	</div>
</div>

<script>

	 document.getElementById("new_amount").addEventListener("keyup", function (e) {
    let value = e.target.value.replace(/,/g, "");
    if (!isNaN(value) && value !== "") {
        e.target.value = Number(value).toLocaleString("en-US");
    }
});
	 $(document).ready(function () {
    $('#save_chnges').submit(function (event) {

 event.preventDefault();
        $.ajax({
            url: "<?= base_url().'/upadte-charges'; ?>",
            type: 'POST',
            data: $(this).serialize(),
               dataType: 'json',
                  beforeSend: function () {
                $('#edit_msg').html('<span class="text-info"> Saving please wait..</span>');
                $('#editbtn')
                    .html('Saving...')
                    .prop('disabled', true);

        },
            success: function (response) {
                if(response.status===1){
                	$('#edit_msg').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong></div>'); 
                       $('#editbtn')
                    .html('Successfully')
                    .prop('disabled', true);
                setTimeout(function(){
           window.location.reload();
        },5000)
            }else{
            	$('#edit_msg').html('<div class="alert alert-warning alert-dismissible" role="alert"><strong>Updated Failed..</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
                setTimeout(function(){
           window.location.reload();
        },5000)
            }
     
       
            },
            error: function () {
  $('#edit_msg').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Something went wrong</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
                setTimeout(function(){
          // window.location.reload();
        },5000)

            }
        });
    });
});
</script>