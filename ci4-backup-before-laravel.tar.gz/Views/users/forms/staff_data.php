<div class="table-responsive">

<table class="table table-borderless">
	<tr>
		<th>STAFF NAME:</th><td><?=esc($staff_data->first_name);?> <?=esc($staff_data->last_name);?></td>
		<input type="hidden" name="bsalary" id="basic_salary" value="<?=esc($staff_data->basic_salary);?>">
		<input type="hidden" name="staff_id" id="staff_id" value="<?=esc($staff_data->user_id);?>">

	</tr>
	<tr>
		<th>DEPARTMENT:</th><td><?=esc($staff_data->dep_name);?></td>
	</tr>
	<tr>
		<th>JOB TITTLE:</th><td><?=esc($staff_data->job_tittle);?></td>
	</tr>
	 <tr>                          
		<th>BASIC SALARY:</th><td><b><?=number_format($staff_data->basic_salary);?></b></td>
	</tr>
	<?php $status = "<span class='badge no-print badge-{$staff_data->status_color}'>{$staff_data->status_name}</span>";?>        
	 <tr>                          
		<th>STAFF STATUS:</th><td><?=$status;?></td>
	</tr>	
	

	<tr>
		<th>PHONE:</th><td><?=esc($staff_data->phone_no);?></td>
	</tr>
</table>
	
</div>