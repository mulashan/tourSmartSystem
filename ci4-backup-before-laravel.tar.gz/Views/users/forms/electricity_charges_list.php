<style>
input.form-control {
    pointer-events: auto !important;
    background-color: white !important;
    z-index: 9999 !important;
    position: relative !important;
}
input.private {
       border-color: #808080;
}
.input-error {
    border: 3px solid red !important;
    animation: shake 0.3s ease-in-out 0s 2;
}

@keyframes shake {
    0% { transform: translateX(0); }
    25% { transform: translateX(-4px); }
    50% { transform: translateX(4px); }
    75% { transform: translateX(-4px); }
    100% { transform: translateX(0); }
}
<?php
 $bmodel = new App\Models\BillModel();
 $remodel = new App\Models\ReportsModel();
?>
.row-selected td {
    background-color: black !important;
    color: white !important;
    border: 1px solid white !important;
}


</style>
      <div id="submit_msg"></div>  
      <div id="submit_status"></div>  
      <div id="submit_error"></div>  
<form id="save_charges">
 <!-- <h6>Payroll List</h6> -->
<table class="table table-borderless">
    <thead>
    <tr>
        <th>
<!--             <div class="form-check">
<input type="checkbox" class="form-check-input" id="selectAll">
  <label class="form-check-label">All</label>
</div> -->
SN
</th>
            <th>DATE</th>
            <th>YEAR</th>
            <th>MONTH</th>
            <th>STAFF NAME</th>
            <th>GENDER</th>
            <th>DEPARTMENT</th>
            <th>JOB TITTLE</th>
            <th>AMOUNT TO PAY</th>
    </tr>
    </thead>
    <tbody>
              <?php 
        if (isset($staffs)){
            $total_salaries = 0;
            $total_balance = 0;
            $total_paye = 0; 
            $i=0;
            foreach ($staffs as  $info){
                if(isset($saved_charges) && !empty($saved_charges)){
                  foreach ($saved_charges as  $data){   
if($data->staff_id==$info->user_id){
    continue;
}}}

                
$i++;
                    ?>
            <tr>

                <td><?=$i;?></td>
            <td><?= esc($charges_date);?></td>
            <td><?= esc($charge_year);?></td>
             <td><?= esc($charge_month->month);?></td>
             <td><?= $info->first_name; ?> <?= $info->last_name; ?></td>
             <td><?= $info->gender; ?></td>
             <td><?= $info->dep_name; ?></td>
             <td><?= $info->job_tittle; ?></td>

<td>

       <input type="hidden" name="staff_id" id="staff_id[<?=$info->user_id;?>]" value="<?=$info->user_id;?>">
 <input type="text" style="width:150px;" 
       name="topay_gvm[<?=$info->user_id;?>]" 
       class="private form-control topay_gvm"
       onkeyup="formatLive(this)">
                <input type="hidden" name="month" id="month" value="<?= esc($charge_month->month_id);?>">
                <input type="hidden" name="year" id="year" value="<?= esc($charge_year);?>">
                <input type="hidden" name="date" id="date" value="<?= esc($charges_date);?>">


  <div class="input-error-message text-danger" style="display:none;"></div>
</td>

            </tr>
        <?php 
    }}
    else{
        echo '
        <tr><td colspan="7"><b>No data found!</b></td></tr>';
    }?>
    </tbody>
  
    <tfoot class="text-center bg-muted">
        <tr>
            <td colspan="8"><b>TOTAL</b></td>
            <td><b><div id="totalpay_gvm">0</div></b></td>
            <input type="hidden" name="totalpay_gvm_value" id="totalpay_gvm_value" value="0">
        </tr>
    </tfoot>

</table>

                        <!-- Here it ends the payable accounts --> 
                         <div class="form-group row">
                            <div class="col-md-12  float-right">
                                <button type="submit" id="create_bill" class="btn btn-primary">Create</button>
                            </div>
                        </div>


                        </form>


<script>
$('#save_charges').submit(function (e) {
    e.preventDefault();

    let amoun_entered = false;
    $('.topay_gvm').each(function () {
        let val = $(this).val().replace(/,/g,''); // remove commas
        if (val.trim() !== '' && parseFloat(val) > 0) {
            amoun_entered = true;
            return false; // exit each loop
        }
    })

    if (!amoun_entered) {
        swal({
            title: "Info",
            text: "Please enter at least one value in the 'Amount to Pay' field before submitting.",
            type: "warning"
        });
        return false;
    }

    var formData = $(this).serialize();
    $.ajax({
        type: "POST",
        url: '<?= base_url().'/save-charges'; ?>',
        data: formData,

        beforeSend: function () {
            swal({
                title: "Processing...",
                text: "Loading, please wait...",
                type: "info",
                showConfirmButton: false,
                allowOutsideClick: false
            });
        },

        success: function (res) {  
            if(res.status==1){
                 swal({
               title: "Completed",
                 text: "Charges saved successfully.",
                        type: "success",
                 confirmButtonText: "OK",
        closeOnConfirm: true
            },
            function(){
           
                window.location.reload();
    }            );  
             }else{
                   swal({
               title: "Failed",
                 text: "Failed to save charges.",
                        type: "warning",
                 confirmButtonText: "OK",
        closeOnConfirm: true
            },
            function(){
           
                window.location.reload();
    }            );
             }
           },

        error: function () {
            swal({
                title: "Error!",
                text: "Failed to save charges. Please try again.",
                type: "error"
            });
        }
    });
});

// ========================================================================================

function formatLive(input, maxAmount)
{
    let cursor = input.selectionStart;
    let raw = input.value.replace(/,/g, '');
    raw = raw.replace(/[^0-9.]/g, '');
    let parts = raw.split('.');
    if (parts.length > 2) {
        raw = parts[0] + '.' + parts.slice(1).join('');
    }

    if (raw === '') {
        input.value = '';
        calculateTotal();
        return;
    }

    let num = parseFloat(raw);
    if (isNaN(num)) return;
    if (parts[1]) {
        parts[1] = parts[1].substring(0, 2);
        raw = parts[0] + '.' + parts[1];
    }
    if (num > maxAmount) {
        raw = maxAmount.toString();
        num = maxAmount;
    }
    let intPart = parts[0];
    let decPart = parts[1] ? '.' + parts[1] : '';

    intPart = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    input.value = intPart + decPart;
    input.setSelectionRange(cursor, cursor);
    calculateTotal();
}


function finalFormat(input)
{
    let val = input.value.replace(/,/g, '');

    if (val === '') return;

    let num = parseFloat(val);

    if (isNaN(num)) return;

    input.value = num.toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });

    calculateTotal();
}

function calculateTotal()
{
    let total = 0;
    document.querySelectorAll('.topay_gvm').forEach(function(input){

        let val = input.value.replace(/,/g, '');

        if (val !== '' && !isNaN(val)) {
            total += parseFloat(val);
        }

    });
    document.getElementById('totalpay_gvm').innerText =
        total.toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    document.getElementById('totalpay_gvm_value').value =
        total.toFixed(2);
}
</script>


