  
    <table class="table table-bordered table-hover">
      <thead>
        <tr>
          <th>TRANS NO.</th>
          <th>TRANS TYPE</th>
          <th>PAYMENT TYPE</th>
          <th>TRANS DATE.</th>
          <th>AMOUNT PAID</th>
          <th>APPROVAL STATUS</th>
          <th>ISSUED BY</th>
        </tr>
      </thead>
      <tbody>
         <?php 
     if(isset($payrolls)):
      $total_amount=0;
      foreach($payrolls as $pay_data):
$total_amount+=$pay_data->amount_paid;
    ?>
        <tr>
          <td><?=$pay_data->payroll_payment_id?></td>
          <td><?=$pay_data->type_name?></td>
          <td><?=$pay_data->voucher_type_name?></td>
          <td><?=$pay_data->trans_date;?></td>
          <td class="text-right"><?=number_format($pay_data->amount_paid);?></td>
           <td><?php if($pay_data->hstatus == '1'){
                                echo "<span class='fw-bold text-success'>Approved</span>";
                            }elseif($pay_data->hstatus == '3'){
                          echo "<div class='fw-bold text-danger'>Pending</div>";

                            }elseif($pay_data->hstatus == '2'){
                          echo "<div class='fw-bold text-danger'>Rejected</div>";

                            }
                               ?></td>
          <td><?=$pay_data->first_name;?> <?=$pay_data->last_name;?></td>
        </tr>
        <?php
        endforeach;
        endif; 
         ?>
      </tbody>
      <tfoot>
        <tr>
          <td colspan="4"><b>TOTAL</b></td>
          <td class="text-right"><b><?=number_format($total_amount);?></b></td>
          <td></td>
        </tr>
      </tfoot>
    </table>