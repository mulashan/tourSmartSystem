  <!doctype html>
<html lang="en" dir="ltr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="icon" href="<?php echo base_url('public/favicon1.ico')?>" type="image/x-icon"/>
<script src="<?php echo base_url('public/assets/plugins/jquery/jquery-3.4.1.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/charts-c3/c3.min.css')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/charts-c3/c3.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/chartjs/chart.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/sweetalert/sweetalert.min.js')?>"></script>
<!-- <script src="<?php echo base_url('public/assets/plugins/toastr/toastr.css')?>"></script> -->
<!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" /> -->
<title>
    payslip
</title>
<link rel="stylesheet" href="<?php echo base_url('public/assets/select/css/select2.min.css')?>"/> 
<link rel="stylesheet" href="<?= base_url('public/assets/css/jquery-ui.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('public/assets/css/jquery-ui.css') ?>">


<!-- Bootstrap Core and vandor -->
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/bootstrap/css/bootstrap.min.css')?>" />
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/bootstrap-5.0.2-dist/css/bootstrap.min.css')?>" />

 <link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')?>">
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/daterangepicker/daterangepicker.css')?>">
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/bootstrap4_datepicker/css/bootstrap-datetimepicker.min.css')?>">
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/DataTables/datatables.min.css')?>">
 <link rel="stylesheet" href="<?php //echo base_url('public/assets/plugins/fullcalendar/fullcalendar.min.css')?>">
 <link rel="stylesheet" href="<?php //echo base_url('public/assets/plugins/dropify/css/dropify.min.css')?>" />
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/sweetalert/sweetalert.css')?>" />

<!-- Plugins css -->
<link rel="stylesheet" href="<?php // echo base_url('public/assets/plugins/summernote/dist/summernote.css')?>"/>


<!-- Core css -->

<link rel="stylesheet" href="<?php echo base_url('public/assets/css/style.min.css')?>"/>
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/print-js/print.min.css')?>"/>

<script src="<?php echo base_url('public/assets/plugins/sweetalert/sweetalert.min.js')?>"></script>

<script src="<?php echo base_url('public/assets/bundles/lib.vendor.bundle.js')?>"></script> 

<!-- ======================================================================================================= -->
<style>
    .earns{
        background-color:#eaeaed;
        color: black;
        font-weight: bold !important;
    }
        .deductions{
        background-color:#eaeaed;
        color: black;
        font-weight: bold !important;
    }
    .emp_details table{
        border: 1px solid black;
    }
      table {
        margin-left: 0; /* No left margin */
        margin-right: auto; /* Push table to the left */
        text-align: left;
        /*border: 1px solid black;*/
    }
</style>
<div class="container">

    <div class="row">
        <div class="col-md-12">
            <div class="card card-outline card-primary">
                <div class="card-body">
                    <?php
  $source="";
            if($company->logo_name != ""){
               $source =  base_url('public/company_photos/'.$company->logo_name);
            }
?>

            <center>
      <div> <img src="<?=$source;?>" style="background: white;width: 25%;height: 25%" ></div>
 <span class="mt-4"><b><?= $company->company_name; ?></b></span><br>
            <span class="modify" style="font-size:15px"><?= $company->address; ?></span>
            <div class="mb-3">
                <div><span class="modify" style="font-size:15px">Phone: +<?= $company->phone1; ?></span></div>
                <div><span class="modify" style="font-size:15px">Email: <?= $company->email; ?></span></div>
                <div><span class="modify" style="font-size:15px"> <?= $company->website; ?></span></div>
             
            </div> 
               <?php
        if(isset($history)){
        ?>
   <span class="mt-3"> <b style="font-size:16px; font-weight: bold !important;">SALARY SLIP</b></span>
  
</center>
    <hr>
     
        <div class="row">
            <div class="col-md-12">
        <div>
           <table>
            <thead class="earns">
                 <tr>
                <th colspan="2">PAYMENT DETAILS</th>
              
            </tr> 
            </thead>
             <tr>
                <th>Pay No:</th>
                <td><?=$history->trans_number;?></td>
            </tr>
                 <tr>
                <th>Pay Date:</th>
                <td><?=$history->trans_date;?></td>
            </tr>
              <tr>
                <th>Pay Period:</th>
                <td><?=$history->month;?> <?=$history->payroll_year;?> </td>
            </tr>
         <tr>
             <th>
                <hr>
             </th>
             <td><hr></td>
         </tr>
           
                <thead class="earns">
                    <tr>
                        <th colspan="2">EMPLOYEE DETAILS</th>
                    </tr>
                </thead>

             <tr>
                <th>Name:</th>
                <td><?=$history->first_name; ?> <?=$history->last_name; ?></td>
            </tr> 
            <?php
if($company->classification==1){
            ?>
              <tr>
                <th>Classification:</th>
                <td><?=$history->class_name?></td>
            </tr> 
            <?php
        }
            ?>

             <tr>
                <th>Depertment:</th>
                <td><?=$history->dep_name?></td>
            </tr>  <tr>
                <th>Job Title:</th>
                <td><?=$history->job_tittle;?></td>
            </tr>
               <tr>
                <th>TIN NO:</th>
                <td><?=$history->tin_no;?></td>
            </tr>    <tr>
                <th>NSSF NO:</th>
                <td><?=$history->pension_no;?></td>
            </tr>    <tr>
                <th>WCF NO:</th>
                <td><?=$history->wcf_no?></td>
            </tr>  <tr>
                <th>NHIF NO:</th>
                <td><?=$history->nhf_no;?></td>
            </tr>  
                <tr>
             <th>
                <hr>
             </th>
             <td><hr></td>
         </tr>
                   <thead class="earns">
                    <tr>
                        <th colspan="2">BANK DETAILS</th>
                    </tr>
                </thead>

             <tr>
                <th>Bank Name:</th>
                <td><?=$history->bank_name;?></td>
            </tr> 
              <tr>
                <th>Ac Name:</th>
                <td><?=$history->account_name;?></td>
            </tr>  <tr>
                <th>Ac No:</th>
                <td><?=$history->account_number;?></td>
            </tr>
            
        </table>
            </div>
            
        </div>
    </div>
<hr>

        <table class="table table-bordered" style="font-size: 40px;">
            
                <thead class="earns">
                    <tr>
                    <th style="font-weight: bold !important;">
                        Earnings
                    </th>
                      <th style="font-weight: bold !important;" class="text-right">
                        Amount
                    </th>
                    </tr>
                </thead>
                <tbody>
                        <?php
                if($history->basic_salary>0){
                ?>
                    <tr>
                        <td>Base Salary</td>
                        <td class="text-right"><?=number_format($history->basic_salary);?></td>
                    </tr>
                        <?php
                    }
                if($history->allowances>0){
                ?>
                     <tr>
                        <td>Allowance</td>
                        <td class="text-right"><?=number_format($history->allowances)?></td>
                    </tr>
    <?php
}
                if($history->over_time>0){
                ?>
                     <tr>
                        <td>Overtime pay</td>
                        <td class="text-right"><?=number_format($history->over_time)?></td>
                    </tr>
               <?php
           }
           $gross=$history->basic_salary+$history->allowances;
                if($gross>0){?>
               
                    <tr>
                        <td><b>Gross Salary</b></td>

                        <td class="text-right"><b><?=number_format($gross);?></b></td>
                    </tr>
                        <?php
}
                        ?>
                 </tbody>
            

            
                <thead class="deductions">
                    <tr>
                    <th style="font-weight: bold !important;">
                        Deductions
                    </th>
                      <th style="font-weight: bold !important;" class="text-right">
                        Amount
                    </th>
                    </tr>
                </thead>
                <tbody>
                      <?php
                if($history->paye>0){
                ?>
                    <tr>
                        <td>PAYE</td>
                        <td class="text-right"><?=number_format($history->paye);?></td>
                    </tr>
                      <?php
                  }
                if($history->pension>0){
                ?>
                     <tr>
                        <td>PENSION</td>
                        <td class="text-right"><?=number_format($history->pension);?></td>
                    </tr>
                      <?php
                  }
                if($history->nhif>0){
                ?>
                     <tr>
                        <td>NHIF</td>
                        <td class="text-right"><?=number_format($history->nhif);?></td>
                    </tr>
                      <?php
                  }
                if($history->advances>0){
                ?>
                         <tr>
                        <td>Salary advances</td>
                        <td class="text-right"><?=number_format($history->advances);?></td>
                    </tr>
                
               
                            <?php
                        }
$total_deductions=$history->advances+$history->nhif+$history->paye+$history->pension;
      if($total_deductions>0){
                        ?>
                    <tr>
                        <td class="fw-bolid"><b>Total Deductions</b></td>
                        <td class ='fw-bolid text-right'><b><?=number_format($total_deductions);?></b></td>
                    </tr>
                    <?php
                }?>
               </tbody>
            
            
   
            
                <tbody>
                    <tr>
                    <th style="font-weight: bold !important;">
                        Net Salary
                    </th>
                    <td style="font-weight: bold !important;" class ='fw-bolid text-right'><?=number_format($history->net_salaries);?></td>
                </tr>
                <?php
                if($history->net_salary_balances>0){
                ?>
                <tr>
                      <th>
                        Balance
                    </th>
                    <td class ='fw-bolid text-right'><?=number_format($history->net_salary_balances);?></td>
                </tr>
                <?php
            }?>
                 <tr>
                     <th class="earns" style=" background-color:#eaeaed;color: black;
        font-weight: bold !important;">
                        <b>
                        Amount Paid
                    </b>
                    </th>
                    
                    <td class ='fw-bolid text-right' style=" background-color:#eaeaed;color: black;
        font-weight: bold !important;"><b><?=number_format($history->amount_paid);?></b></td>
                    
                    </tr>

                  </tbody>
        <!--         <tfoot>
                    <tr>
                        
                        <td class ='fw-bolid'>0</td>
                        <td class ='fw-bolid'>0</td>
                        <td class ='fw-bolid'>0</td>
                    </tr>
                </tfoot> -->
            
            
        </table>
<?php

}
?>
               <?php
        if(isset($advances)){
        ?>
   <span class="mt-3"> <b style="font-size:16px; font-weight: bold !important;">SALARY ADVANCE SLIP</b></span>
  
</center>
    <hr>
     
        <div class="row">
            <div class="col-md-12">
                            <?php
if(isset($advances) && !empty($advances)){
            ?>
            <div class="card">
            <div class="card invoice">
              <div class="card-header">
                <h5>Repayment Schedule</h5>
            </div>
            </div>
            <div class="card-body">
                <table>
                     <tr>
                <th>Empolyee Name:</th>
                <td><?=$advances[0]->first_name; ?> <?=$advances[0]->last_name; ?></td>
            </tr>
                 <tr>
                <th>Depertment:</th>
                <td><?=$advances[0]->dep_name?></td>
            </tr>  <tr>
                <th>Job Title:</th>
                <td><?=$advances[0]->job_tittle;?></td>
            </tr>

                </table>
                 <hr>
                                       <table class="table" style="border:1px solid black;">

                                        <thead>
                   <tr style="border:1px solid black;">
                       <th style="border:1px solid black;">Payroll Year</th>
                       <th style="border:1px solid black;">Payroll Month</th>
                       <th style="border:1px solid black;">Amount</th>
                   </tr>
                   </thead>
                    <tbody style="border:1px solid black;">
                        <?php 
                        $total_advance=0;
                          foreach ($advances as $data){
                               $total_advance+=$data->advance_amount;
                        ?>
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;"><?=$data->payroll_year??""?></td>  
                           <td style="border:1px solid black;"><?=$data->month??""?></td>  
                          <td class="text-right" style="border:1px solid black;"><?=number_format($data->advance_amount)??""?></td>  
                         
                        </tr>
       <?php
   }
       ?>

                        
                    </tbody>
                    <tfoot>
                        <tr style="border:1px solid black;">
                        <td style="border:1px solid black;" colspan="2" class="fw-bolid text-center"><b>TOTAL</b></td>
                        <td class="text-right fw-bold" style="border:1px solid black;"><?= number_format($total_advance);?></td>
                        </tr>
                    </tfoot>
                </table>
                
            </div>
            <?php
        }?>
            </div>
        </div>
                </div>

                <?php
            }
                ?>
            </div>
             
        </div>
        
    </div>
</div>
    


<!-- ================================================================================================ -->
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/yearPicker/yearpicker.css')?>"/>
<script src="<?php echo base_url('public/assets/plugins/yearPicker/yearpicker.js')?>"></script>

<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/toastr/toastr.css')?>" />
<script src="<?php echo base_url('public/assets/plugins/toastr/toastr.js')?>"></script>
 <script src="<?php echo base_url('public/assets/js/preloader/main.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/moment/moment.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/dist/jquery.inputmask.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/daterangepicker/daterangepicker.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/bootstrap4_datepicker/js/bootstrap-datetimepicker.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script><!-- <script src="<?php// echo base_url('public/assets/plugins/dropify/js/dropify.min.js')?>"></script> -->
<script src="<?php echo base_url('public/assets/plugins/sweetalert/sweetalert.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/plugins/DataTables/datatables.min.js')?>"></script>

<!-- Printing plugins -->
<script src="<?php echo base_url('public/assets/plugins/print-js/print.min.js')?>"></script>

<!-- Start all plugin js -->
<!-- <script src="<?php //echo base_url('public/assets/bundles/counterup.bundle.js')?>"></script> -->
 <script src="<?php echo base_url('public/assets/bundles/apexcharts.bundle.js')?>"></script>
 <script src="<?php echo base_url('public/assets/bundles/echarts.bundle.js')?>"></script>
<script src="<?php echo base_url('public/assets/bundles/summernote.bundle.js')?>"></script>
<!-- Include jQuery -->
<!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> -->

<!-- Include Select2 CSS & JS -->
<script src="<?php echo base_url('public/assets/select/js/select2.min.js')?>"></script>
<!-- <script src="<?php //echo base_url('public/assets/bundles/fullcalendar.bundle.js')?>"></script> -->

<!-- Start project main js  and page js -->
<script src="<?php echo base_url('public/assets/js/core.js')?>"></script>
<!-- <script src="<?php //echo base_url('public/school/assets/js/page/index.js')?>"></script> -->
<!--<script src="<?php // echo base_url('public/school/assets/js/page/summernote.js')?>"></script>-->
<!-- <script src="<?php //echo base_url('public/school/assets/js/form/dropify.js')?>"></script> -->
<!-- <script src="<?php //echo base_url('public/school/assets/js/page/dialogs.js')?>"></script> -->
<!-- <script src="<?php //echo base_url('public/school/assets/js/page/calendar.js')?>"></script> -->
<script src="<?= base_url('public/assets/js/jquery-ui.js') ?>"></script>
<script src="<?= base_url('public/assets/js/jquery-ui.min.js') ?>"></script>
<script>

    </script>