<div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTablelist">
                            <thead>
                                <tr>
                                   
                                    <th>SN</th>
                                   <th>Date</th>
                                   <th>Payroll Year</th>
                                   <th>Payroll Month</th>
                                   <th>STAFF Name</th>
                                   <th>Gender</th>
                                   <th>Job tittle</th>
                                   <th>Department</th>
                                   <th>Amount</th>
                                   <th>Updated by</th>
                                   <th>Update date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody style="padding:1px;">
                               
                       <?php
                         if(isset($saved_charges)):
                                   $total_amount=0;
                                   $i=0;
                            foreach($saved_charges as $ec):
                                $i++;
                       ?>
                        <tr>
                       <td><?=$i;?></td>
                       <td><?=$ec->charge_date?></td>
                       <td><?=$ec->pay_year?></td>
                       <td><?=$ec->month;?></td>
                        <td><?=$ec->first_name?>
                       <?=$ec->last_name?></td>
                       <td><?=$ec->gender;?></td>
                       <td><?=$ec->job_tittle;?></td>
                       <td><?=$ec->dep_name;?></td>
                       <td class="text-right"><?=format_number_with_decimals($ec->charge_amount);?></td>
                        <?php
                        $adder_name='';
                        if(isset($saver)){
                            foreach($saver as $data){
                                if($data->user_id==$ec->created_by){
                               $adder_name=$data->first_name.' '.$data->last_name;     
                                    break;

                                }
                            }
                        }
                        ?>
                            
<td><?=$adder_name;?>
                        </td>
                        <td><?=$ec->created_on?></td>
                         <td>
                              <a href="#" onclick="edit_charges(<?php echo $ec->charge_id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a> 
  <!--<a href="javascript:void(0)" onclick="view_payroll(<?php echo $ec->charge_id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a>  -->
                        </td>
                              </tr>                
                       <?php
                   endforeach;
               endif;
                       ?>
                       
                            </tbody>
                            </table>
                                
            </div>
            <script>
                $('#myTablelist').DataTable();
            </script>