
<?php
 helper('results_helper');

?>
<?php 
$bmodel = new App\Models\BillingModel();
    $comodel = new App\Models\CompanyModel();
    $smodel=new App\Models\StudentModel;
$classification = $smodel->gettable_data('classification_tbl',$where = array('id >' => 0));
$company = $bmodel->get_table_details('company_tbl');
 helper('results_helper');
?>
<form id="save_month_payroll" method="post"  class="needs-validation" novalidate>
      <input type="hidden" name="month_name" id="month_name" value="">
              <div class="col-md-12">
                <div class="row mb-3">
                   <div class="table-responsive">
                       <div class="mb-4">
   
        <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; font-family: Arial; font-size: 14px; text-align: right;" id="salaryTableData">
    <thead>
        <tr>
                             <?php if (isset($company) && !empty($company)) {
                    if($company[0]->classification==1){
                ?>
            <th colspan="6" class="text-center">EMPLOYEE DETAILS</th>
            <?php
        }else{

           ?>
           <th colspan="5" class="text-center">EMPLOYEE DETAILS</th>
           <?php
       }}?>
            <th colspan="4" class="emoluments text-center">EMOLUMENTS</th>
            <th colspan="3" class="social text-center">SOCIAL SECURITY DEDUCTIONS</th>
            <th class="net_salary"></th>
                   <?php if(session()->get('db_id')==17){?>
            <th colspan="8" class="tax text-center">TAX & OTHER DEDUCTIONS</th>
        <?php 
    }else{
            ?>
             <th colspan="3" class="tax text-center">TAX & OTHER DEDUCTIONS</th>
            <?php
        }
        ?>
            <th class="net_salary"></th>
           
        </tr>
        <tr>
            <th>S/N</th>
            <th>DEPARTMENT</th>
            <th>JOB TITLE</th>
                      <?php if (isset($company) && !empty($company)) {
                    if($company[0]->classification==1){
                ?>
            <th>CLASSFICATION</th>
            <?php
}}
            ?>
            <th>NAMES</th>
            <th>STATUS</th>
            <th class="emoluments text-center">B.SALARY</th>
            <th class="emoluments">OVER TIME</th>
            <th class="emoluments text-center">ALLOWANCE</th>
            <th class="emoluments text-center">GROSS</th>
            <th class="social text-center">PENSION 10%</th>
            <th class="social text-center">NHIF 3%</th>
            <th class="social text-center">TOTAL SOCIAL</th>
            <th class="net_salary text-center">NET BEFORE TAX</th>
            <th class="tax text-center">PAYE</th>
             <th class="tax text-center">HESLB</th>
            <th class="tax text-center">ADVANCES</th>
                 <?php if(session()->get('db_id')==17){?>
           <th class="tax">TUCTA</th>
            <th class="tax">HOUSING</th>
            <th class="tax">OTHER LOANS</th>
            <th class="tax">MAAFA</th>
                  <th class="tax">ELECTRICITY</th>
        <?php
    }
    ?>
            <th class="net_salary text-center">NET SALARY</th>
        </tr>
    </thead>
    <tbody>
<?php
    $i=0;
    $total_basic_salary = 0;
$total_allowances = 0;
$total_gross_salary = 0;
$total_nssf = 0;
$total_nhif = 0;
$ctotal_social = 0;
$cumulate_nbt=0;
$cumulate_paye=0;
$callowance=0;
$cadvances=0;
$cumulate_net_salary=0;
$wcf=0;
$total_heslb=0;
$total_overtime=0;
$total_housing=0;
$total_tucta=0;
$total_maafa=0;
$total_loans=0;
$total_electricity=0;
if(isset($all_staff) && !empty($all_staff)):


    foreach($all_staff as $staffs):
        $housing=0;
$tucta=0;
$loans=0;
$maafa=0;
          $row_style = ($staffs->status == 4) ? 'class="text-danger"' : '';
        $i++;
        $gross=$staffs->basic_salary + $staffs->allowances;
       if($staffs->pension_pay_status==""|| $staffs->pension_pay_status==0){
  $nssf=0;
    }else{
    $nssf=$gross*(10/100);      
    }
      
        if($staffs->basic_salary<0 || $staffs->nhif_pay_status=="" || $staffs->nhif_pay_status==0){
        $nhif=0;
        }
        elseif($staffs->basic_salary<666666.67 && $staffs->basic_salary!=0){
            $nhif=20000;
        }
        else{
            $nhif=$staffs->basic_salary*(3/100);
        }
          if($staffs->heslb_pay_status==""|| $staffs->heslb_pay_status==0){
  $heslb=0;
    }else{
    $heslb=$staffs->basic_salary*(15/100);      
    }
  if(session()->get('db_id')==17){
$housing=$staffs->housing;

if($staffs->tucta_status==1){
$tucta=$staffs->basic_salary*(2/100);
}
$maafa=$staffs->maafa;
$electricity = 0;
if (isset($electricity_charge)) {
    foreach ($electricity_charge as $echarge) {
        if ($echarge->staff_id == $staffs->user_id) {
            $electricity = $echarge->charge_amount;
            break;
        }
    }
}
if (isset($loans_dedutions)) {
    foreach ($loans_dedutions as $loan_dedu) {
        if ($loan_dedu->staff_id == $staffs->user_id) {
            $loans = $loan_dedu->loan_amount;
            break;
        }
    }
}
  }
  
        
$total_basic_salary += $staffs->basic_salary;
$total_allowances += $staffs->allowances;
$total_social=$nssf+$nhif;
$total_gross_salary += $gross;
$wcf = $total_gross_salary*0.005;
$total_nssf += $nssf;
$total_nhif += $nhif;
$ctotal_social += $total_social;
$total_housing+=$housing;
$total_tucta+=$tucta;
$total_maafa+=$maafa;
$total_loans+=$loans;
$salaryadvance = 0;
$total_heslb +=$heslb;
$total_electricity+=$electricity;
if (isset($salary_advances)) {
    foreach ($salary_advances as $advanc) {
        if ($advanc->staff_id == $staffs->user_id) {
            $salaryadvance = $advanc->advance_amount;
            break;
        }
    }
}
$overtime = 0;
if (isset($over_time)) {
    foreach ($over_time as $ovt) {
        if ($ovt->staff_id == $staffs->user_id) {
            $overtime = $ovt->overtime_amount;
            break;
        }
    }
}
$total_overtime += $overtime;
$cadvances += $salaryadvance;
$nbt =$gross-$total_social;
$cumulate_nbt+=$nbt;
$paye=calculate_paye($nbt, $brackets);
$cumulate_paye+=$paye;
$callowance+=$staffs->allowances;
$net_salary=$nbt - ($paye + $heslb + $salaryadvance+$housing+$tucta+$loans+$maafa);
$cumulate_net_salary+=$net_salary;
$wcf_data = $gross*0.005;
        ?>
        <tr>
  
            <td><?=$i;?></td>
               <input type="hidden" name="staff_id[]" value="<?=$staffs->user_id?>">
    <input type="hidden" name="49<?=$staffs->user_id?>" value="<?=$staffs->basic_salary;?>">
    <input type="hidden" name="50<?=$staffs->user_id?>" value="<?=$staffs->allowances;?>">
    <input type="hidden" name="43<?=$staffs->user_id?>" value="<?=$nssf;?>">
             <?php if (isset($company) && !empty($company)) {
                    if($company[0]->wcf_status==1){
                ?>
    <input type="hidden" name="53<?=$staffs->user_id?>" value="<?=$wcf_data;?>">
    <?php
}else{
    ?>
      <input type="hidden" name="53<?=$staffs->user_id?>" value="0">
<?php
}
}
    ?>
    <input type="hidden" name="51<?=$staffs->user_id?>" value="<?=$nhif;?>">
    <input type="hidden" name="55<?=$staffs->user_id?>" value="<?=$heslb;?>">
    <input type="hidden" name="paye[]" value="<?=$paye;?>">
    <input type="hidden" name="48<?=$staffs->user_id?>" value="<?=$salaryadvance;?>">
    <input type="hidden" name="54<?=$staffs->user_id?>" value="<?=$net_salary;?>">
        <?php if(session()->get('db_id')==17){?>
 <input type="hidden" name="56<?=$staffs->user_id?>" value="<?=$maafa;?>">
 <input type="hidden" name="57<?=$staffs->user_id?>" value="<?=$housing;?>">
 <input type="hidden" name="58<?=$staffs->user_id?>" value="<?=$tucta;?>">
 <input type="hidden" name="59<?=$staffs->user_id?>" value="<?=$loans;?>">
 <?php
}?>
     <input type="hidden" name="classfication[]" value="<?=$staffs->classfication_id;?>">
            <td style="text-align: left;"><?=$staffs->dep_name;?></td>
            <td style="text-align: left;"><?=$staffs->job_tittle;?></td>
            <?php 
if (isset($company) && !empty($company)) {
    if ($company[0]->classification == 1) {
        $matched = false;
        foreach ($classification as $class) {
            if ($class->id == $staffs->classfication_id) {
                echo "<td class='text-center'>{$class->class_name}</td>";
                $matched = true;
                break;
            }
        }
        if (!$matched) {
            echo "<td class='text-center'> - </td>";
        }
    }
}
?>
            <td style="text-align: left;"><?=$staffs->first_name;?> <?=$staffs->last_name;?></td>
                  <?php $status = "<span class='badge badge-{$staffs->status_color}'>{$staffs->status_name}</span>";?>
                                     <td class="text-center"><?=$status;?></td>
            <td class="emoluments"><?=format_number_with_decimals($staffs->basic_salary);?></td>
            <td class="emoluments"><?=format_number_with_decimals($overtime);?></td>
            <td class="emoluments"><?=format_number_with_decimals($staffs->allowances);?></td>
            <td class="emoluments"><b><?=format_number_with_decimals($gross);?></b></td>
            <td class="social"><?=format_number_with_decimals($nssf);?></td>
            <td class="social"><?=format_number_with_decimals($nhif);?></td>
            <td class="social"><b><?=format_number_with_decimals($total_social);?></b></td>
            <td class="net_salary"><b><?=format_number_with_decimals($nbt);?></b></td>
            <td><?=format_number_with_decimals($paye);?></td>
            <td><?=format_number_with_decimals($heslb);?></td>
            <td ><?=format_number_with_decimals($salaryadvance);?></td>
                          <?php if(session()->get('db_id')==17){?>  
            <td><?=format_number_with_decimals($tucta);?></td>
             <td><?=format_number_with_decimals($housing);?></td>
            <td ><?=format_number_with_decimals($loans);?></td>
            <td ><?=format_number_with_decimals($maafa);?></td>
              <td ><?=format_number_with_decimals($electricity);?></td>
                    <?php
                }
                ?>
            <td class="net_salary"><b><?=format_number_with_decimals($net_salary);?></b></td>
        </tr>

        <?php
    endforeach;
        ?>

    </tbody>
    <tfoot>
               <tr style="font-weight: bold;">
                     <?php if (isset($company) && !empty($company)) {
                    if($company[0]->classification==1){
                ?>
            <td colspan="6" style="text-align: center;">TOTAL</td>
                  <?php
        }else{

           ?>
           <td colspan="5" style="text-align: center;">OVERALL TOTAL</td>
           <?php
}}
           ?>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_basic_salary);?></td>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_overtime);?></td>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_allowances);?></td>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_gross_salary);?></td>
            <td class="social text-right"><?=format_number_with_decimals($total_nssf);?></td>
            <td class="social text-right"><?=format_number_with_decimals($total_nhif);?></td>
            <td class="social text-right"><?=format_number_with_decimals($ctotal_social);?></td>
            <td class="net_salary text-right"><?=format_number_with_decimals($cumulate_nbt);?></td>
            <td class="text-right"><?=format_number_with_decimals($cumulate_paye);?></td>
             <td class="text-right"><?=format_number_with_decimals($total_heslb);?></td>
            <td class="text-right"><?=format_number_with_decimals($cadvances);?></td>
                    <?php if(session()->get('db_id')==17){?>
           <td class="text-right"><?=format_number_with_decimals($total_tucta);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_housing);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_loans);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_maafa);?></td>
                     <td class="text-right"><?=format_number_with_decimals($total_electricity);?></td>
                <?php
            }
            ?>
            <td class="net_salary text-right"><?=format_number_with_decimals($cumulate_net_salary)?></td>
            
        </tr>    
    </tfoot>
</table>
<!-- ==============================save payroll details======================================================= -->

 
    <input type="hidden" name="transaction_id" value="10">
    <input type="hidden" name="transaction_type_id" value="1">


</div>
<!-- ==============================save payroll details======================================================= -->
   
                        </div>



                        </div>
                        </div>
                    </form>
  <form id="account_data2" method="post"  class="needs-validation" novalidate>
                        <div class="col-md-8">
                        <div class="card">
                        <div class="card-body">
                            <h5>LEDGER ENTRIES</h5>
                            <div class="table-responsive">
                                        <div id="ledger_status"></div>
                                        <div id="error_loading"></div>
                                <div id="ledger_entries">    
                               
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>LEDGER NAME</th>
                                        <th>LEDGER TYPE</th>
                                        <th>DR AMOUNT</th>
                                        <th>CR AMOUNT</th>
                                    </tr>
                                </thead>
                                <tbody id="ledger_entries_body">
                                 <?php
                                 $total_dr = 0;
                                   $total_cr = 0;
                               if(isset($legers)){ 
                                foreach($legers as $leger){
                                           $amount = 0;

switch (strtolower($leger->account_name)) {
    case 'net salaries payable':
        $amount = $cumulate_net_salary;
        //$net_salar_id = $leger->account_id;
        break;
    case 'pension scheme payable':
        $amount = $total_nssf * 2;
        break;
    case 'nhif payable':
        $amount = $total_nhif * 2;
        break;
    case 'sdl payable':
        $amount = 0;
        break;
    case 'paye payable':
        $amount = $cumulate_paye;
        break;
    case 'wcf payable':
        $amount = $wcf;
        break;
    case 'salary advances':
        $amount = $cadvances;
        break;
    case 'pension scheme':
        $amount = $total_nssf;
        break;
    case 'nhif contribution':
        $amount = $total_nhif;
        break;
    case 'staff allowances':
        $amount = $total_allowances;
        break;
    case 'basic salaries':
        $amount = $total_basic_salary;
        break;
    case 'wcf contributions':
        $amount = $wcf;
        break;
           case 'heslb payable':
        $amount = $total_heslb;
        break;
       case 'overtime payable':
        $amount = $total_overtime;
        break;
            case 'maafa payable':
        $amount = $total_maafa;
        break;
        case 'other loans payable':
        $amount = $total_loans;
        break;
        case 'housing payable':
        $amount = $total_housing;
        break;
        case 'tucta payable':
        $amount = $total_tucta;
        break;
           case 'electricity payable':
        $amount = $total_electricity;
        break;
    default:
        $amount = 0;
}


        if (strtolower($leger->type_name) == 'expense') {
                  $dr_amount = $amount;
            $cr_amount = 0;
            ?>
       <input type="hidden" name="amount<?=$leger->account_id;?>" value="<?=$dr_amount;?>">
       <input type="hidden" name="nature<?=$leger->account_id;?>" value="2">
        <input type="hidden" name="type_id<?=$leger->account_id;?>" value="<?=$leger->typ_id;?>">
        <input type="hidden" name="institution<?=$leger->account_id;?>" value="<?=$leger->institution_id;?>">
        <input type="hidden" name="account_id[]" value="<?=$leger->account_id;?>">
            <?php
        } else {

             $dr_amount = 0;
            $cr_amount = $amount;
            ?>
                <input type="hidden" name="amount<?=$leger->account_id;?>" value="<?=$cr_amount;?>">
                 <input type="hidden" name="nature<?=$leger->account_id;?>" value="1">
                <input type="hidden" name="type_id<?=$leger->account_id;?>" value="<?=$leger->typ_id;?>">
                <input type="hidden" name="institution<?=$leger->account_id;?>" value="<?=$leger->institution_id;?>">
                <input type="hidden" name="account_id[]" value="<?=$leger->account_id;?>">
            <?php
        }

        $total_dr += $dr_amount;
        $total_cr += $cr_amount;
                                        ?>
                                        <tr>
                                        <td><?=$leger->account_name?></td>
                                    
                                        <td><?=$leger->type_name?></td>

                                        <td style="text-align:right;"><?= format_number_with_decimals($dr_amount) ?></td>
                                         <td style="text-align:right;"><?= format_number_with_decimals($cr_amount) ?></td>
                                        </tr>
                                        <?php
                                     }}
                                        ?>
                                      
                                   </tbody>
                                <tfoot>
            <tr style="font-weight:bold; background:#f0f0f0;">
    <td colspan="2" style="text-align:right;">TOTAL</td>
          <input type="hidden" name="total_amount" value="<?=$total_dr?>">
    <td style="text-align:right;"><?= format_number_with_decimals($total_dr) ?></td>
    <td style="text-align:right;"><?= format_number_with_decimals($total_cr) ?></td>
</tr>
                                </tfoot>
                                
                            </table>
                             </div>
                            </div>

                        </div>
                        </div>

                        </div>
          <div class="text-end">
  <button type="submit" class="btn btn-primary btn-lg">
    <i class="fa fa-save me-2"></i> Create
  </button>
</div>
<?php
endif;
?>
                                      
</form> 
<script>
    $(document).ready(function () {
    $('#account_data2').submit(function (event) {
         var date=$('#date').val();
        event.preventDefault();
  if (!this.checkValidity() || date.trim() === '') {
            event.stopPropagation();
            if (date.trim() === '') {
                $('#savemsg').html('<div class="alert alert-warning" role="alert"><strong>Warning!</strong> Please select a valid date.</div>')
                    .stop(true, true)
                    .show()
                    .delay(5000)
                    .fadeOut();
            }

            this.classList.add("was-validated");
            $("html, body").animate({ scrollTop: 0 }, "slow");
            return;
        }

var data1 = $('#meta_data').serialize();
var data2 = $('#save_month_payroll').serialize();
var data3 = $('#account_data2').serialize();
var month = $('#month option:selected').text(); 
var year_payroll = $('#year').val();
          var Data = data1+'&'+data3+'&'+data2;
        $.ajax({
            url: "<?= base_url().'/add-payroll'; ?>",
            type: 'POST',
            data: Data,
                  dataType: 'json',
            beforeSend: function () {
                   Swal.fire({
                title: 'Please wait...',
                html: '<span class="text-info"> Saving '+month+' '+year_payroll+ ' payroll please wait..</span>',
                icon: 'info',
                showConfirmButton: false,
                timerProgressBar: true,
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
            },
            success: function (response) {
                       if(response.status===1){
       Swal.close();
            swal({
               title: "The "+month+" "+year_payroll+ " Payroll saved successfuly",
                        type: "success",
                 confirmButtonText: "OK",
        closeOnConfirm: true
            },
            function(){
           
                window.location.reload();
    }            );
                }
                else{
        Swal.close();
swal("Failed!", "Failed to saved "+month+" "+year_payroll+ " payroll!", "error"); 
                }
            },
            error: function () {
                    Swal.close();
swal("Failed!", "Something went wrong!", "error");
            }
        });
    });
});

    $(document).ready(function() {
    $('#salaryTableData').DataTable({
        paging: false,
        searching: true,
        ordering: true,
        info: true,
        pageLength: 1000,
      
     
    });
    $('#salaryTableData thead th').attr('data-bs-toggle', 'tooltip')
                              .attr('title', 'Click to sort');
$('[data-bs-toggle="tooltip"]').tooltip(); 

});
</script>