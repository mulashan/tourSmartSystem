<?php 
$bmodel = new App\Models\BillingModel();
    $comodel = new App\Models\CompanyModel();
    $smodel=new App\Models\StudentModel;
$classification = $smodel->gettable_data('classification_tbl',$where = array('id >' => 0));
$company = $bmodel->get_table_details('company_tbl');
 helper('results_helper');
?>
<style>
input[type="datetime-local"] {
  appearance: none; /* removes native styles */
  -webkit-appearance: none;
  -moz-appearance: none;

  background-color: white;
  border: 1px solid #ccc;
  border-radius: .375rem;
  padding: .375rem .75rem;
  font-size: .875rem;
  color: #333;
  width: 100%;
}
#overtime_fromtime,
#overtime_totime {
  background-color: #fff !important;
  color: #212529;
}

input[type="datetime-local"]:focus {
  border-color: #0d6efd;
  box-shadow: 0 0 0 .2rem rgba(13, 110, 253, .25);
}
@keyframes blink {
    0%   { background-color: #f8d7da; }
    50%  { background-color: #fff; }
    100% { background-color: #f8d7da; }
}

.blink-row {
    animation: blink 1s ease-in-out 3; /* blink 3 times */
}

  </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Overtime</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Overtime</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Overtime-tab" data-toggle="tab" href="#Overtime-all">Overtime List</a></li>
                <li class="nav-item"><a class="nav-link" id="Overtime-tab" data-toggle="tab" href="#Overtime-add">New Overtime</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Overtime-tab" data-toggle="tab" href="#Overtime-all">Overtime List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Overtime-tab" data-toggle="tab" href="#Overtime-add">New Overtime</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>


<dOvertimeiv class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="Overtime-all">
                <div class="card">
          <div class="card-body">

</div>
            </div>
            </div>
            <div class="tab-pane" id="Overtime-add">
        <div class="card">
            <div class="card-header" style="height:5px">
                <h3 class="card-title">Overtime Application</h3>
                <div class="card-options ">
                    <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                </div>
            </div>
            <hr>
          <div class="card-body">
              <div class="row">
        <div class="col-md-6">
<form id="new_overtime" method="post" class="needs-validation" novalidate>
         <div class="row mb-3">
                      <label for="date" class="col-sm-4 ms-2 col-form-label col-form-label-sm">Overtime Date:<span class="text-danger">*</span></label>
                                     <div class="col-sm-4">
                     <input type="date" class="form-control form-control-sm" value="" id="overtime_date" name="overtime_date" style="width: 200px;" autocomplete="off" required>
                      <div class="invalid-feedback">Overtime Date required.</div> 
                    </div>  
                    <div id="savemsg"></div>
                      </div>
                           <div class="row mb-3">
                      <label for="date" class="col-sm-4 ms-1 col-form-label col-form-label-sm">Staff:<span class="text-danger">*</span></label>
                                     <div class="col-sm-6 d-flex align-items-center">
                    <input type="text" class="form-control" name="staff_name" id="staff_name" value=""  placeholder="Search staff name" aria-label="staff name" aria-describedby="matron-button">
                                           <button class="btn btn-outline-primary" type="button" id="matron-button" onclick="search_staff_salary()"><i class="fa fa-search" aria-hidden="true"></i></button>
                    </div> 
                    <div class="mt-4" >
                         <div id="staff_data"></div>
                    </div>
                 
              
                      </div>
                      

</form>
</div>
  <div class="col-md-6">
    <div id="search_result" class="card">
        <div class="card-body">
            <div id="customer_loaded"></div> 
        </div>
    </div>
                             
                    </div> 
                    <div class="col-md-12">
                        <div class="card" id="schedule_region">
                            <div class="card-body">
        <form class="form-horizontal" id="overtime_btn" enctype="multipart/form-data">
  <div class="card p-3">
    <h5 class="text-center mb-4">Overtime Schedule</h5>

<div class="form-row">
      <div class="form-group col-md-2">
        <label for="year">Payroll Year <span class="text-danger">*</span></label>
        <select id="year" name="year" class="form-control form-control-sm" required>
          <option value="" selected disabled>--please Select--</option>
          <?php
            $initial_year=2023;
            $current_year=date('Y');
            $final_year=$current_year+1;
            for ($initial_year; $initial_year <=$final_year ; $initial_year++) {
              if($initial_year == $current_year){
                echo '<option value="'.$initial_year.'" selected>'.$initial_year.'</option>';
              } else {
                echo '<option value="'.$initial_year.'">'.$initial_year.'</option>';
              }
            }
          ?>
        </select>
        <div class="invalid-feedback">Payroll Year required.</div>
      </div>

      <div class="form-group col-md-2">
        <label for="month">Payroll Month <span class="text-danger">*</span></label>
        <select id="month" name="month" class="form-control form-control-sm" required>
          <option value="" selected disabled>--please Select--</option>
          <?php
            if(isset($months)){
              foreach($months as $info){
                if($info->is_current==1){
                  echo '<option value="'.$info->month_id.'" selected>'.$info->month.'</option>';
                } else {
                  echo '<option value="'.$info->month_id.'">'.$info->month.'</option>';
                }
              }
            }
          ?>
        </select>
        <div class="invalid-feedback">Payroll Month required.</div>
      </div>

      <div class="form-group col-md-2">
        <label for="day_type">Day's Nature <span class="text-danger">*</span></label>
        <select id="day_type" name="day_type" class="form-control form-control-sm" required>
          <option value="" selected disabled>--please Select--</option>
          <option value="1">Normal (1.5)</option>
          <option value="2">Weekend (2)</option>
          <option value="3">Public Holiday(2)</option>
        </select>
        <div class="invalid-feedback">Day's Nature required.</div>
      </div>
      <div class="form-group col-md-2">
        <label for="overtime_fromtime">From Time <span class="text-danger">*</span></label>
        <input type="text" name="overtime_fromtime" value="<?=date('Y-m-d h:i A');?>" id="overtime_fromtime" class="form-control form-control-sm" required>
        <div class="invalid-feedback">From Time required.</div>
      </div>


      <div class="form-group col-md-2">
        <label for="overtime_totime">To Time <span class="text-danger">*</span></label>
        <input type="text" name="overtime_totime" value="<?= date('Y-m-d h:i A'); ?>" id="overtime_totime" class="form-control form-control-sm" required>
        <div class="invalid-feedback">To Time required.</div>
      </div>
  

  <div class="col-md-2 d-flex align-items-center justify-content-end">
  <button type="button" id="click_overtime" class="btn btn-primary btn-sm">
    <i class="fa fa-plus"></i>
  </button>
</div>

</div>
        <div class="amount_status"></div>

    <div class="overtime_status"></div>

    <hr>

  

    <table class="table table-hover table-vcenter table-bordered mb-3">
      <thead>
        <tr>
          <th>Payroll Year</th>
          <th>Payroll Month</th>
          <th>Day's Nature</th>
          <th>From</th>
          <th>To</th>
          <th>Total Hours</th>
          <th>Rate</th>
          <th>Total</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody id="show_overtimes"></tbody>
      <tfoot>
        <tr>
          <td class="text-center" colspan="5" style="font-size:18px;">TOTAL</td>
          <td class="text-center" style="font-size:18px;"> <span id="totalhrs">0hrs</span></td>
          <td class="text-center" style="font-size:18px;"> <span id="totalrate">0</span></td>
          <td class="text-center" style="font-size:18px;"> <span id="totalsum">0</span></td>
          <td></td>
        </tr>
      </tfoot>
    </table>

    <div class="form-row">
      <div class="form-group col-md-6">
        <label>Attach File</label>
        <input type="file" id="imageinput" name="uploadFiles[]" class="form-control form-control-sm"
          multiple accept=".pdf,.doc,.xls,.docx,.xlsx,.jpg,.jpeg,.png" onchange="previewFile(event)">
      </div>

      <div class="form-group col-md-6">
        <label>Approval Comment <span class="text-danger">*</span></label>
        <input type="text" name="bill_comment" id="bllcmt" value="Please Approve!" required class="form-control form-control-sm">
      </div>
    </div>

    <div class="preview-container" id="previewContainer"></div>

    <div class="form-group text-right mt-3">
      <button type="submit" id="create_overtime" class="btn btn-primary">Create</button>
    </div>
  </div>
</form>

                                
                            </div>
                            
                        </div>
                        

                    </div>
</div>
</div>

                   
                </div>

            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    $('.Overtime-select').select2();
});
manage_data();
function manage_data(){
    RemoveAllRows();
       $('#search_result').hide(); 
    $('#staff_data').hide();  
    $('#schedule_region').hide();  
}

function search_staff_salary(){
   var staff_name=$("#staff_name").val();
    $('#search_result').show(); 
    $('#staff_data').hide(); 
    $('#schedule_region').hide(); 
    $('#customer_loaded').html(staff_name); 

     if($('#staff_name').val() == ""){
        $('#customer_loaded').html("<span class='text-red'>Please enter staff name</span>"); 
       }else{
        var dta = staff_name;
         $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/get-search_staffs'; ?>',
                beforeSend: function () {
                   $('#customer_loaded').html('<span class="fa fa-spinner fa-spin"></span> Loading results..');
                },
                data: {data:dta},
                success: function (result) {
                    RemoveAllRows();
                  $('#customer_loaded').html(result); 
                },
                error: function (xhr, status, error) {
                    $('#customer_loaded').html('<div class="alert alert-danger" role="alert">' +
            '<strong>Error:</strong> Unable to load staff data.<br>' +
            'Status: ' + xhr.status + ' ' + xhr.statusText + '<br>' +
            'Details: ' + error +
        '</div>');;
               }
            });
       }
}
function choose_staff(user_id, staf_name, event) {
  event.preventDefault();
  $('#search_result').hide();
  $('#staff_data').show();
  $('#schedule_region').show();
         $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/get-staff_data'; ?>',
                beforeSend: function () {
                   $('#staff_data').html('<span class="fa fa-spinner fa-spin"></span> Loading results..');
                },
                data: {user_id:user_id},
                success: function (result) {

                  $('#staff_data').html(result); 
                 $('#staff_name').val('');

                },
                error: function (xhr, status, error) {
                    $('#staff_data').html('<div class="alert alert-danger" role="alert">' +
            '<strong>Error:</strong> Unable to load staff data.<br>' +
            'Status: ' + xhr.status + ' ' + xhr.statusText + '<br>' +
            'Details: ' + error +
        '</div>');;
               }
            });
}
// ===================================================================================================
var totalhrs = 0;
var totalrates = 0;
var totalamount = 0;

function parseDateTime(dt) {
    return new Date(dt.replace(" ", "T"));
}

function isOverlapping(newFrom, newTo, existingFrom, existingTo) {
    return (newFrom < existingTo && newTo > existingFrom);
}

$('#click_overtime').click(function (evt) {
    evt.preventDefault();
    var monthId = $('#month').val();
    var year = $('#year').val();
    var overtime_day = $('#overtime_day').val();
    var overtime_fromtime = $('#overtime_fromtime').val();
    var overtime_totime = $('#overtime_totime').val();
    var bsalary = $('#basic_salary').val();
    var staff_id = $('#staff_id').val();
    var day_type = parseInt($('#day_type').val(), 10);
    var descr = $('#description').val() || 'Overtime';
    var form = document.getElementById('overtime_btn');

    let dayname;
    if (day_type === 1) {
        dayname = 'Normal';
    } else if (day_type === 2) {
        dayname = 'Weekend';
    } else {
        dayname = 'Holiday';
    }

    if (!form.checkValidity()) {
        evt.stopPropagation();
        form.classList.add("was-validated");
        return;
    }

    if (overtime_fromtime === overtime_totime) {
        $('.overtime_status').html('<span class="alert alert-warning"><i class="fa fa-warning"></i> From time and To time should not be equal.</span>')
          .stop(true, true)
                    .show()
                    .delay(10000)
                    .fadeOut();
        return;
    }

    let difference = getHoursDiff(overtime_fromtime, overtime_totime);
    let hours = parseFloat(difference.toFixed(1));
    if (hours <= 0 || hours > 8) {
        $('.overtime_status').show().html(
            '<span class="alert alert-warning"><i class="fa fa-warning"></i> Overtime hours must be greater than 0 and not exceed 8.</span>'
        )
          .stop(true, true)
                    .show()
                    .delay(10000)
                    .fadeOut();
        return;
    }
    let newFrom = parseDateTime(overtime_fromtime);
    let newTo = parseDateTime(overtime_totime);
    let overlapFound = false;
    let conflictMsg = "";
    let conflictRow = null;

    $("#show_overtimes tr").each(function () {
        let existingFromStr = $(this).find("input[name='fromtime[]']").val();
        let existingToStr = $(this).find("input[name='totime[]']").val();

        let existingFrom = parseDateTime(existingFromStr);
        let existingTo = parseDateTime(existingToStr);

        if (isOverlapping(newFrom, newTo, existingFrom, existingTo)) {
            overlapFound = true;
            conflictMsg = `${existingFromStr} → ${existingToStr}`;
            conflictRow = $(this);
            return false; 
        }
    });

if (overlapFound) {
    if (conflictRow) {
        conflictRow.addClass("blink-row");
        setTimeout(() => conflictRow.removeClass("blink-row"), 4000);
        conflictRow[0].scrollIntoView({ behavior: "smooth", block: "center" });
    }

    $('.overtime_status').show().html(
        `<span class="alert alert-danger"><i class="fa fa-times"></i> This overtime entry overlaps with an existing entry (${conflictMsg}).</span>`
    )
      .stop(true, true)
                    .show()
                    .delay(10000)
                    .fadeOut();
    return;
}

    let formatted = hours % 1 === 0 ? hours + " hr" : hours + " hrs";

    $.ajax({
        type: 'POST',
        data: { payroll_month: monthId },
        url: '<?php echo base_url() . "/fetch_payroll_month"; ?>',
        beforeSend: function () {
            $('.overtime_status').html('<span class="spinner-border spinner-border-sm"></span> Loading item, please wait....');
            $('.amount_status').hide();
        },
        success: function (response) {
            let lData = JSON.parse(response);
            if (!Array.isArray(lData)) {
                lData = [lData];
            }

            for (let i = 0; i < lData.length; i++) {
                let monthName = lData[i]['month'];
                let monthID = lData[i]['month_id'];

                let safeFrom = overtime_fromtime.replace(/:/g, "_").replace(/\s/g, "_");
                let safeTo = overtime_totime.replace(/:/g, "_").replace(/\s/g, "_");
                let uniqueRowId = `${year}_${monthID}_${day_type}_${safeFrom}`;

                let row_rate;
                if (day_type === 1) {
                    row_rate = (bsalary / 195) * 1.5;
                } else {
                    row_rate = (bsalary / 195) * 2;
                }
                let rate = parseFloat(row_rate.toFixed(1));
                let row_amount = rate * hours;
                let amount = parseFloat(row_amount.toFixed(1));
                let formattedAmount = amount.toLocaleString();

                if ($("#row_" + uniqueRowId).length) {
                    $('.overtime_status').show();
                    $('.overtime_status').html('<span class="alert alert-warning"><i class="fa fa-warning"></i> This overtime entry has already been added.</span>')
                      .stop(true, true)
                    .show()
                    .delay(10000)
                    .fadeOut();
                    return;
                }

                totalamount += amount;
                totalhrs += hours;
                totalrates += row_rate;

                $('#show_overtimes').append(`
                    <tr id="row_${uniqueRowId}">
                        <td>
                            <input type="hidden" name="staff_datum" value="${staff_id}">
                            <input type="hidden" name="day_type[]" value="${day_type}">
                            <input type="hidden" name="payroll_year[]" value="${year}">
                            ${year}
                        </td>
                        <td>
                            <input type="hidden" name="payroll_month[]" value="${monthID}">
                            ${monthName}
                        </td>
                        <td class="">
                            ${dayname}
                        </td>
                        <td class="text-center">
                            <input type="hidden" name="fromtime[]" value="${overtime_fromtime}">
                            ${format12Hour(overtime_fromtime)}
                        </td>
                        <td class="text-center">
                            <input type="hidden" name="totime[]" value="${overtime_totime}">
                            ${overtime_totime}
                        </td>
                        <td class="text-center">
                            <input type="hidden" name="hours[]" value="${hours}">
                            ${formatted}
                        </td>
                        <td class="text-center">
                            <input type="hidden" name="rate[]" value="${rate}">
                            ${rate}
                        </td>
                        <td class="text-center">
                            <input type="hidden" name="amount[]" value="${amount}">
                            <input type="hidden" name="total_amount" value="${totalamount}">
                            ${formattedAmount}
                        </td>
                        <td>
                            <button type="button" onclick="RemoveRow('${uniqueRowId}',${hours}, ${row_rate}, ${amount})" class="btn btn-danger btn-sm"><i class='fa fa-trash'></i></button>
                        </td>
                    </tr>
                `);
            }

            sumhrs = parseFloat(totalhrs.toFixed(1));
            let formattedtotalhrs = sumhrs % 1 === 0 ? sumhrs + " hr" : sumhrs + " hrs";

            $("#totalhrs").html(formattedtotalhrs);
            $("#totalrate").html(parseFloat(totalrates.toFixed(1)));
            $("#totalsum").html(totalamount.toLocaleString());
            $('.overtime_status').hide();
            $('.amount_status').hide();
            $("#overtime_amount").val('');
        },
        error: function () {
            alert("Failed to fetch payroll month.");
        }
    });
});

function RemoveRow(id,hours,row_rate,amount) {
    $('#row_' + id).remove();
    totalhrs -= hours;
    totalrates -= row_rate;
    totalamount -= amount;
       sumhrs =parseFloat(totalhrs.toFixed(1));
 let formattedtotalhrs = sumhrs % 1 === 0 ? sumhrs + " hr" : sumhrs + " hrs";
            $("#totalhrs").html(formattedtotalhrs);
     $("#totalrate").html(parseFloat(totalrates.toFixed(1)));
       $("#totalsum").html(totalamount.toLocaleString());
  
}

function RemoveAllRows() {
    $("#show_overtimes").empty();
    account_ttl = 0;
    totalhrs = 0;
    totalrates = 0;
    $("#totalhrs").html("0 hr");
    $("#totalrate").html("0");
    $("#totalsum").html("0");
    $("#thispay").html("0");
    $("#totalsum_raw").val(0);
}
$('#overtime_btn').submit(function(e){ 
    e.preventDefault();
    var form_data = new FormData(this); 
             var date=$('#overtime_date').val();
        event.preventDefault();
    if (!this.checkValidity() || date.trim() === '') {
            event.stopPropagation();
            if (date.trim() === '') {
                $('#savemsg').html('<div class="alert alert-warning" role="alert"><strong>Warning!</strong> Please select a valid date.</div>')
                    .stop(true, true)
                    .show()
                    .delay(5000)
                    .fadeOut();
            }

            this.classList.add("was-validated");
            $("html, body").animate({ scrollTop: 0 }, "slow");
            return;
        }
    $('#create_overtime').prop("disabled", true);
  form_data.append('overtime_date', date);
  $.ajax({
    method: 'POST',
    url: '<?php echo base_url() . '/save-overtime'; ?>',
    data: form_data,
    contentType: false,
    processData: false,
    dataType: 'json',
    beforeSend: function () {
            Swal.fire({
                title: 'Please wait...',
                html: '<span class="text-info"> Saving Overtime data please wait..</span>',
                icon: 'info',
                showConfirmButton: false,
                timerProgressBar: true,
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
        },
    success: function(data){
         Swal.close();
        if(data['status'] == "1"){    
      swal({
               title: "The Overtime data saved successfuly",
                        type: "success",
                 confirmButtonText: "OK",
        closeOnConfirm: true
            },
            function(){ 
                window.location.reload();
    }            );

        } else {
            $('#create_overtime').prop("disabled", false);
         Swal.close();
            swal("Warning", data['description'], "warning");
        }
    },
    error: function(xhr, status, error){
         Swal.close();
        $('#create_overtime').prop("disabled", false);
        swal("Error", "Something went wrong while saving Overtime.", "error");
    }
});

});

flatpickr("#overtime_fromtime", {
  enableTime: true,
  dateFormat: "Y-m-d H:i",
  plugins: [
    new confirmDatePlugin({
      showAlways: false,
      confirmText: "OK",
      confirmIcon: "",
    })
  ],
    onReady: function(selectedDates, dateStr, instance) {
    const confirmBtn = instance.calendarContainer.querySelector(".flatpickr-confirm");
    if (confirmBtn) {
      confirmBtn.classList.add("btn", "btn-outline-primary", "btn-sm");
    }
  }
});
flatpickr("#overtime_totime", {
  enableTime: true,
  dateFormat: "Y-m-d H:i",
  plugins: [
    new confirmDatePlugin({
      showAlways: false,
      confirmText: "OK",
      confirmIcon: ""
    })
  ],
  onReady: function(selectedDates, dateStr, instance) {
    const confirmBtn = instance.calendarContainer.querySelector(".flatpickr-confirm");
    if (confirmBtn) {
      confirmBtn.classList.add("btn", "btn-outline-primary", "btn-sm");
    }
  }
});

function parseDateTime(str) {
    if (!str || typeof str !== "string") return NaN;
    let [datePart, timePart] = str.trim().split(" ");
    let [year, month, day] = datePart.split("-").map(Number);
    let [hour, minute] = timePart.split(":").map(Number);

    return new Date(year, month - 1, day, hour, minute);
}
function getHoursDiff(from, to) {
    let start = parseDateTime(from);
    let end   = parseDateTime(to);
    if (isNaN(start) || isNaN(end)) return NaN;
    let diffMs = end - start;
    return diffMs / (1000 * 60 * 60);
}
function format12Hour(dtStr) {
    let date = new Date(dtStr.replace(" ", "T"));
    let hours = date.getHours();
    let minutes = date.getMinutes();
    let ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    let minutesStr = minutes < 10 ? '0' + minutes : minutes;
    return `${date.getFullYear()}-${(date.getMonth()+1).toString().padStart(2,'0')}-${date.getDate().toString().padStart(2,'0')} ${hours}:${minutesStr} ${ampm}`;
}

</script>

