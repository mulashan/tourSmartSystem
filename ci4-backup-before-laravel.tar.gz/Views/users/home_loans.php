<?php
 $bmodel = new App\Models\BillingModel();
 $remodel = new App\Models\ReportsModel();
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Other Loans Deductions</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                $bmodel = new App\Models\BillingModel();
                   $amodel = new App\Models\AdmissionModel();
                $pj = $amodel->get_student_details('projects_tbl', $where = array('status' => 1));
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Other Loan Deductions</li>
                </ol>
            </div>
            <div id="largeScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#Loans-all">Loans Deductions List</a></li>
                 <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#Loans-add">New Loan Deductions</a></li>
            </ul>
            </div>

             <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#Loans-all">Loan Deductions List</a></li>
                <li></li><li></li>
                  <li class="nav-item d-none d-sm-block"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#Loans-add">New Loan Deductions</a></li>
            </ul>
             </div>
           
        </div>
    </div>
</div>
<?php
 $cty= $bmodel->get_table_details('voucher_types_tbl');
  ?>
<div class="section-body mt-4">
        <div class="container-fluid">
        	<div class="tab-content">
              <div class="tab-pane active" id="Loans-all">
               <div class="d-flex justify-content-center">
                <div id="messageDisplayArea"></div>

                </div>
   
                <hr>
                <center>
                    <div id="loaded_data">
                      <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                   
                                    <th>SN</th>
                                   <th>Date</th>
                                   <th>Payroll Year</th>
                                   <th>Payroll Month</th>
                                   <th>Amount</th>
                                   <th>Updated by</th>
                                   <th>Update date</th>
                                     <th>Action</th> 
                                </tr>
                            </thead>
                            <tbody style="padding:1px;">
                               
                       <?php
                         if(isset($saved_charges)):
                                   $total_amount=0;
                                   $i=0;
                            foreach($saved_charges as $ec):
                                $i++;
                       ?>
                        <tr>
                       <td><?=$i;?></td>
                       <td><?=$ec->charge_date?></td>
                       <td><?=$ec->pay_year?></td>
                       <td><?=$ec->month;?></td>
                       <td class="text-right"><?=format_number_with_decimals($ec->total_amount);?></td>                      
<td><?=$ec->first_name.' '.$ec->last_name;?>
                        </td>
                        <td><?=$ec->created_on?></td>
                  <td>
  <a href="#" onclick="view_loans('<?php echo $ec->month;?>','<?php echo $ec->pay_year;?>','<?=$ec->charge_date?>','<?=$ec->pay_month;?>')"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a> 
                     
                        </td> 

                              </tr>                
                       <?php
                   endforeach;
               endif;
                       ?>
                       
                            </tbody>
                            </table>
                                
            </div>
            </div>
<div class="modal fade" id="view_charge">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Deductions view</h4>
        <button type="button" class="btn-close" onclick="hideview_modal()"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
   <div id="view_data">
          
      </div>

      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="hideview_modal()">Close</button>
      </div>

    </div>
  </div>
</div>


                </center>
            </div>
              
              <div class="tab-pane" id="Loans-add">
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="card card-lg">
                            <div class="card-header"  style="height:5px">
                                <h3 class="card-title">Loan Deductions Application</h3>
                                <div class="card-options ">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                                <hr>
                              <div class="card-body">
    <div class="row">
<div class="col-md-6">
    <div class="row mb-3 align-items-center">
        <label for="charges_date" class="col-sm-4 col-form-label text-end">
            Deductions Date
        </label>

        <div class="col-sm-8">
            <input type="date"
                id="charges_date"
                name="charges_date"
                value="<?php echo date('Y-m-d'); ?>"
                class="form-control"
                required>
        </div>
    </div>
    <div class="row mb-3 align-items-center">
        <label for="staff_name" class="col-sm-4 col-form-label text-end">
            Staff <span class="text-danger">*</span>
        </label>

        <div class="col-sm-8">
            <div class="input-group">
                <input type="text"
                    class="form-control"
                    name="staff_name"
                    id="staff_name"
                    placeholder="Search staff name">

                <button class="btn btn-outline-primary"
                    type="button"
                    id="matron-button"
                    onclick="search_staff_info()">
                    <i class="fa fa-search"></i>
                </button>
            </div>
        </div>
    </div>

</div>

        <div class="col-md-6">
          <div id="searched_data" class="card" style="display: none;">
    <div class="card-body">
        <div id="staff_data"></div>
    </div>
</div>

        </div>
    </div>
    <div class="row">
<div class="col-md-6">
    <div id="selected_data" class="mt-4">
        <div id="selected_staff">
            
        </div>
        
    </div>
</div>
</div>
<hr>
                                  
                                            </div>

               <div class="row">
                <div class="col-md-12">
                    <div id="loan_schedule"></div>
                </div>
    
</div>

                        
                                               
                             </div>

         
      
                        </div>
                         </div>
                        
               
                </div>
<div class="modal fade" id="view_loan">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Deductions view</h4>
        <button type="button" class="btn-close" onclick="hideviewloan_modal()"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
   <div id="view_loansdata">
          
      </div>

      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="hideviewloan_modal()">Close</button>
      </div>

    </div>
  </div>
</div>
                      </div>
                    </div>
                </div>
     <script type="text/javascript">

function search_staff_info(){
$("#searched_data").show();
$("#selected_data").hide();
$("#loan_schedule").hide();
    var staff_name = $("#staff_name").val();

    if(staff_name == ""){
        $('#staff_data').html("<span class='text-danger'>Please enter staff name</span>");
        return;
    }

    $.ajax({
        type: "POST",
        url: "<?php echo base_url('/get-search_staffs'); ?>",
        beforeSend: function () {
            $('#staff_data').html('<span class="fa fa-spinner fa-spin"></span> Loading...');
        },
        data: { data: staff_name },

        success: function (result) {
            $('#staff_data').html(result);
        },

        error: function (xhr, status, error) {
            $('#staff_data').html(
                '<div class="alert alert-danger">' +
                '<strong>Error:</strong> Unable to load staff.<br>' +
                error +
                '</div>'
            );
        }
    });
}


function choose_staff(user_id, staf_name, event) {
  event.preventDefault();
  $('#searched_data').hide();
  $('#selected_data').show();
  $("#loan_schedule").show();
         $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/get-staff_data'; ?>',
                beforeSend: function () {
                   $('#selected_staff').html('<span class="fa fa-spinner fa-spin"></span> Loading infomation..');
                },
                data: {user_id:user_id},
                success: function (result) {

                  $('#selected_staff').html(result); 
                 $('#staff_name').val('');

                },
                error: function (xhr, status, error) {
                    $('#selected_staff').html('<div class="alert alert-danger" role="alert">' +
            '<strong>Error:</strong> Unable to load staff data.<br>' +
            'Status: ' + xhr.status + ' ' + xhr.statusText + '<br>' +
            'Details: ' + error +
        '</div>');;
               }
            });
                  $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/load_loans_info'; ?>',
                beforeSend: function () {
                   $('#loan_schedule').html('<span class="fa fa-spinner fa-spin"></span> Loading infomation..');
                },
                data: {user_id:user_id},
                success: function (result) {

                  $('#loan_schedule').html(result); 
                 $('#staff_name').val('');

                },
                error: function (xhr, status, error) {
                    $('#loan_schedule').html('<div class="alert alert-danger" role="alert">' +
            '<strong>Error:</strong> Unable to get loan data.<br>' +
            'Status: ' + xhr.status + ' ' + xhr.statusText + '<br>' +
            'Details: ' + error +
        '</div>');;
               }
            });
}

     function view_loans(month,year,date,month_id){
         $("#view_loan").modal('show');
              $('#view_loansdata').html('<span class="fa fa-spinner fa-spin"></span> Loading form....');
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/view_loans_deduction'; ?>',
                data: {month:month,year:year,date:date,month_id:month_id},
                       beforeSend: function()
            { 
                              $('#view_loansdata').html('<span class="fa fa-spinner fa-spin"></span> Loading form....');
            },
                success: function (res) {
                    $('#view_loansdata').html(res);
                   
                },
                error: function () {
                    $('#view_loansdata').html('<div class="alert alert-warning">Fail to retreive data.!!</div>');
                      
                }
            });
     }
     function hideviewloan_modal(){
              $("#view_loan").modal('hide');
     }
</script>


