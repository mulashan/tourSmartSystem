<?php
$smodel = new App\Models\StaffModel();
$ssmodel = new App\Models\StudentModel();
 $classification = $ssmodel->gettable_data('classification_tbl',$where = array('id >' => 0));

?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">NSSF Report</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                          <?php  $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
                    </a></li>
                    <li class="breadcrumb-item active" aria-current="page">NSSF Report</li>
                </ol>
            </div>
            
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
           
        <!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="box box-danger">
           
            <div class="box-body">
          
                <div class="d-flex justify-content-center">
                    <div class="container mt-3">
  <form id="Rept1Result" class="row g-3">
    <!-- Department -->
    <div class="col-md-3">
      <label for="dep" class="form-label">Department</label>
      <select class="form-control formdata-select" name="dep" id="dep">
        <option value="0">All</option>
        <?php
          $department = $ssmodel->gettable_data('departments_tbl',['id >' => 0]);
          foreach($department as $dp){
            echo '<option value="' . $dp->id . '">' . $dp->dep_name . '</option>'; 
          }
        ?>
      </select>
    </div>

    <!-- Job Title -->
    <div class="col-md-3">
      <label for="job" class="form-label">Job Title</label>
      <select class="form-control formdata-select" name="job" id="job">
        <option value="0">All</option>
        <?php
          $job = $ssmodel->gettable_data('job_tittle_tbl',['id >' => 0]);
          foreach($job as $jb){
            echo '<option value="' . $jb->id . '">' . $jb->job_tittle . '</option>'; 
          }
        ?>
      </select>
    </div>
<?php
       if(count($classification)>0){
       ?>
    <!-- Class -->
    <div class="col-md-3">
      <label for="class_status" class="form-label">Classification:</label>
      <select class="form-control formdata-select" name="class_status" id="class_status">
        <option value="0">All</option>
              <?php
          $class = $ssmodel->gettable_data('classification_tbl',['id >' => 0]);
          foreach($class as $class){
            echo '<option value="' . $class->id . '">' . $class->class_name . '</option>'; 
          }
        ?>
      </select>
    </div>
<?php
}?>
    <!-- Bank -->
    <div class="col-md-3">
      <label for="bank" class="form-label">Bank:</label>
      <select class="form-control formdata-select" name="bank" id="bank">
        <option value="0">All</option>
             <?php
          $bank = $ssmodel->gettable_data('bank_lists_tbl',['bank_id >' => 0]);
          foreach($bank as $bank){
            echo '<option value="' . $bank->bank_id . '">' . $bank->bank_name . '</option>'; 
          }
        ?>
      </select>
    </div>

    <!-- Year -->
    <div class="col-md-3">
      <label for="year" class="form-label">Year</label>
      <select class="form-control formdata-select" name="year" id="year">
        <option value="0">All</option>
                 <?php
                                    $initial_year=2023;
                                    $current_year=date('Y');
                                    $final_year=$current_year+1;
                                    for ($initial_year; $initial_year <=$final_year ; $initial_year++) { 
                                
                                    ?>
                        <?php if($initial_year == $current_year){?>
                                    <option value="<?=$initial_year;?>" selected><?=$initial_year;?></option>
                                    <?php
                                           }else{
                                    ?>
                                    <option value="<?=$initial_year;?>" ><?=$initial_year;?></option>
                                    <?php
                                        }
                                    ?>

                                    <?php

                                       }
                                    ?>
      </select>
    </div>

    <!-- Month -->
    <div class="col-md-3">
      <label for="month" class="form-label">Month</label>
      <select class="form-control formdata-select" name="month" id="month">
        <option value="0">All</option>
             <?php
          $months = $ssmodel->gettable_data('months',['month_id >' => 0]);
          foreach($months as $info){
              if($info->is_current==1){
                                    echo '<option value="'.$info->month_id. '"selected>' . $info->month . '</option>';     
                                }
                                else{
                                   echo '<option value="'.$info->month_id. '">' . $info->month . '</option>';   
                                }
          }
        ?>
      </select>
    </div>

    <!-- Button -->
    <div class="col-md-3 d-flex align-items-end">
      <button type="submit" class="btn btn-primary w-100">Create</button>
    </div>

  </form>
</div>


                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>
           
            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
        </div>
    </div>
</div>

<script type="text/javascript">
  $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    $('.formdata-select').select2();
});  
   $('#Rept1Result').submit(function (e) {
     e.preventDefault();     
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving NSSF report..');
            var dta = $(this).serialize();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/get-nssf-report'; ?>',

                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                 error: function (xhr, status, error) {
                          $('#Rept1ResultViewResults').html('<div class="alert alert-danger" role="alert">' +
            '<strong>Error:</strong> Unable to load Net salary report.!!.<br>' +
            'Status: ' + xhr.status + ' ' + xhr.statusText + '<br>' +
            'Details: ' + error +
        '</div>');
               }
            });       
    });
</script>