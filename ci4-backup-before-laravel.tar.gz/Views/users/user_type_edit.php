<div class="section-body mt-4">
    <div class="container-fluid">
<div class="content-wrapper">
    <section class="content">
        <center class="codrops-demos">
            <a href="<?php echo base_url(); ?>/users_type" class="btn btn-primary" title="Back to Other User Types">&Ll; User Types</a>
        </center>
        <h4><i class="fa fa-angle-right"></i> User Type [ <?php echo '<span class="text-red">'.$user_info[0]->type_name.'</span>'; ?> ]</h4>
         <div class="">
            <?php
			if(session()->getFlashdata('msg')){
            echo '<div class="alert alert-success alert-dismissible col-xs-3" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span>'.session()->get('msg').'</div> ';
			
			}
			if(session()->getFlashdata('error')){
			echo '<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span>'.session()->get('error').'</div> ';
			}
            ?>
        </div>
        <div class="row">
		
            <div class="col-md-6">
                <div class="box box-default">
                    <div class="box-header with-border">
			
                        <table>
                        <tr>
                        <th class="box-title" style="padding-right:5px;"><i class=""></i></th>
						<th style="padding-right:7px;"><h5>Unassigned Modules </h5></th>
                           <th> <input type="text" id="myInput"   onkeyup="myFunction()" class="form-control" placeholder="Search..." name="searchname">
                        </th> 
                <th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th> <th>&nbsp;</th><th>&nbsp;</th> <th>&nbsp;</th><th>&nbsp;</th>
                <th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th>
                <th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th>
                    
                        <th><button class="btn-primary btn-sm" title="Assign selected Module" onclick="Assign_selected()" id="Assign_selected_btn"><span class="fa fa-plus"></span></button></th>
                        </tr>
                     </table>						
                    </div>
					
					
                    <div class="box-body" id="modu">
                         <form id="Unassigned_module_selected">
                        <table class="table table-bordered" id="myTable">
                            <tr>
                                
                            </tr>
                            <tr>
                                <th>S/N</th>
                                <th>Module name</th>
                                <th>Descriptions</th>
                                <th>
                                    <input type="checkbox" name="" value="" onclick="Allcheckbox()" id="Allselected">
                                    All
                                </th>
                                <th>&nbsp;</th>
                            </tr>
                           
                            <input type="hidden" name="user_type_id" value="<?php echo $user_info[0]->id; ?>" id="user_type_id">
                            <?php
                            $l = 0;
                             $ls = '';
                             $holid_module=array();
                            foreach ($unassigned_priv as $ass_priv):
                                $l++;
                                 $ls = $ass_priv->label;
                                 
                                $holid_module[]=array($ass_priv->module_id);
                                ?>
                                <tr class="trow" style="height: 25px" id="<?php echo $ass_priv->module_id; ?>" onclick="selectRow('<?php echo $ass_priv->module_id; ?>',1)">
                                    <td><center><?php echo $l; ?></center></td>
                                <td><?php echo $ass_priv->label; ?></td>
                            <td><?php echo $ass_priv->description; ?></td>
                               <td class="text-center">
                                   <input type="checkbox" name="selected[]" value="<?php echo $ass_priv->module_id; ?>" onclick="checkbox('<?php echo $ass_priv->module_id; ?>',1)" id="selected<?php echo $ass_priv->module_id; ?>">
                               </td>
                                <td><center><a href="<?php echo base_url() . "/asssign_privileges/" . $ass_priv->module_id . "/" . $user_info[0]->id; ?>" title="Assign this Module" onclick="return confirm('Confirm Assignment!')"><span class="fa fa-plus"></span></a></center></th>
                                </tr>
								 
                            <?php endforeach; ?>
                        
                        </table>
                        </form>

                        <div id="modu"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="box box-default">
                    <div class="box-header with-border col-xs-2" style="padding-bottom:5px;">
					<table>
                        <tr>
                        <th class="box-title" style="padding-right:5px;"><i class=""></i></th>
						<th style="padding-right:7px;"><h5>Assigned Modules </h5></th>
                           <th><input type="text" id="myInput2"   onkeyup="myFunction2()" class="form-control" placeholder="Search..." name="searchname">
                        </th> 

                <th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th> <th>&nbsp;</th><th>&nbsp;</th> <th>&nbsp;</th><th>&nbsp;</th>
                <th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th>
                <th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th>
                <th>&nbsp;</th><th>&nbsp;</th>
                    
                 <th><button class="btn-danger btn-sm" title="Unassign selected Module" onclick="Unassign_selected()" id="Unassign_selected_btn"><span class="fa fa-remove"></span></button></th>
                        </tr>
                     </table>
           
                    </div>
                    <div class="box-body">
                         <form id="assigned_module_selected">
                            <table class="table table-bordered" id="myTable2">
                            <tr>
                                <th>S/N</th>
                                <th>Module name</th>
                                <th>Descriptions</th>
                                <th>
                                <input type="checkbox" name="" value="" onclick="Alluncheckbox()" id="Allunselected">
                                    All
                                </th>
                                <th>&nbsp;</th>
                            </tr>
                             <input type="hidden" name="user_type_id2" value="<?php echo $user_info[0]->id; ?>" id="user_type_id2">
                            <?php
                            $m = 0;
                            $holid_module2=array();
                            foreach ($setting as $prev):
                                $m++;
                                $holid_module2[]=array($prev->module_id);
                                ?>
                                <tr class="trow" style="height: 25px" id="<?php echo $prev->module_id; ?>" onclick="selectRow('<?php echo $prev->module_id; ?>',2)">
                                    <td><center><?php echo $m; ?></center></td>
                                <td><?php echo $prev->label; ?></td>
                                <td><?php echo $prev->description; ?></td>
                                <td class="text-center">
                                   <input type="checkbox" name="selected[]" value="<?php echo $prev->module_id; ?>" onclick="checkbox('<?php echo $prev->module_id; ?>',2)" id="selected<?php echo $prev->module_id; ?>">
                               </td>
                                <td><center><a href="<?php echo base_url() . "/remove_privilege/" . $prev->module_id . "/" . $user_info[0]->id; ?>" title="Remove module" onclick="return confirm('Confirm Remove this!')"><span class="fa fa-remove"></span></a></center></td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>	
</div>	
</div>	
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 1; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
function myFunction2() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput2");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable2");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 1; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}

$('#Assign_selected_btn').prop("disabled", true);
$('#Unassign_selected_btn').prop("disabled", true);
function checkForSelected(n){
    var selected =0;

    if(n ==1){
var values=<?php echo json_encode($holid_module);?>;
    }else{
 var values=<?php echo json_encode($holid_module2);?>;    
    }
    
      
 for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
             if(remember.checked){
              selected=1;
             }

        }
        //console.log(selected+'-n='+n);
        if(selected ==0){
             $('#Assign_selected_btn').prop("disabled", true);
             $('#Unassign_selected_btn').prop("disabled", true);
         }else{
            if(n==1){
               $('#Assign_selected_btn').prop("disabled", false);  
           }else{
            $('#Unassign_selected_btn').prop("disabled", false);
           }
            
        }
// console.log(selected);
}
function Allcheckbox(){
        var values=<?php echo json_encode($holid_module);?>;
        //alert(values.length);
        var rememberAll = document.getElementById("Allselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
            if(rememberAll.checked){
     remember.checked=true;  
      if (row) {
    
    row.style.backgroundColor = 'black';
    row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=false; 
       if (row) {
      row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }  
        }
        }
        checkForSelected(1);
      }

      function selectRow(id,n){
         var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false; 
      if (row) {
    row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
       if (row) {

    row.style.backgroundColor = 'black';
      row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        }
   checkForSelected(n);   
      }
      function checkbox(id,n){
        var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {

    row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
     
       if (row) {
    row.style.backgroundColor = 'black';
      row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        } 
        checkForSelected(n);
      }

      function Assign_selected(){
        var data= $("#Unassigned_module_selected").serialize();
        //alert(data);
          $.ajax({
                 beforeSend: function () {
                   Swal.fire({
              title: 'Please wait...',
              html: '<span class="text-danger">Assigning Menu</span>',
              icon: 'info',
              allowOutsideClick: false,
              showConfirmButton: false,
              timerProgressBar: true,
              onBeforeOpen: () => {
                Swal.showLoading();
              }
            });
                  
            },
                type: "POST",
              url: '<?php echo base_url() . '/index.php/UsersController/asssign_selected_privileges'; ?>',
                data: data,
                success: function (res) {
                    Swal.close();
                    if(res){
                      refresh_page(res);
                     Swal.fire({
                    title: "successful", 
                    html: "Module Assigned successful", 
                    icon: "success"
                  }).then((result) => {
                  if (result.isConfirmed) {
                   // window.location = "<?php echo base_url(); ?>/edit_user_type/" + res;
                  }
                });
                         //refresh_page(res);
                    }else{
                        swal('error','something went wrong','error'); 
                    }
                
                },
                error: function () {
                    alert('something went wrong');
                    
                }
            });
      }

      function Alluncheckbox(){
        var values=<?php echo json_encode($holid_module2);?>;
        //alert(values.length);
        var rememberAll = document.getElementById("Allunselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
            if(rememberAll.checked){
     remember.checked=true;  
      if (row) {
    
    row.style.backgroundColor = 'black';
    row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=false; 
       if (row) {
      row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }  
        }
        }
        checkForSelected(2);
      }


      function refresh_page(res){
        window.location = "<?php echo base_url(); ?>/edit_user_type/" + res;
      }

      function Unassign_selected(){
        var data= $("#assigned_module_selected").serialize();
        //alert(data);
          $.ajax({
                 beforeSend: function () {
                   Swal.fire({
              title: 'Please wait...',
              html: '<span class="text-danger">Assigning Menu</span>',
              icon: 'info',
              allowOutsideClick: false,
              showConfirmButton: false,
              timerProgressBar: true,
              onBeforeOpen: () => {
                Swal.showLoading();
              }
            });
                  
            },
                type: "POST",
              url: '<?php echo base_url() . '/index.php/UsersController/unasssign_selected_privileges'; ?>',
                data: data,
                success: function (res) {
                    Swal.close();
                    if(res){
                      refresh_page(res);
                     Swal.fire({
                    title: "successful", 
                    html: "Menu Removed successful", 
                    icon: "success"
                  }).then((result) => {
                  if (result.isConfirmed) {
                  //  window.location = "<?php echo base_url(); ?>/edit_user_type/" + res;
                  }
                });
                         //refresh_page(res);
                    }else{
                        swal('error','something went wrong','error'); 
                    }
                
                },
                error: function () {
                    alert('something went wrong');
                    
                }
            });
      }

</script>
