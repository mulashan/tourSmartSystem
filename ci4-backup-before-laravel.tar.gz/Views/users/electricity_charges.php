<?php
 $bmodel = new App\Models\BillingModel();
 $remodel = new App\Models\ReportsModel();
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Electricity Deductions</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                $bmodel = new App\Models\BillingModel();
                   $amodel = new App\Models\AdmissionModel();
                $pj = $amodel->get_student_details('projects_tbl', $where = array('status' => 1));
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Electricity Deductions</li>
                </ol>
            </div>
            <div id="largeScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#Deductions-all">Deductions List</a></li>
                 <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#Deductions-add">New Deductions</a></li>
            </ul>
            </div>

             <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#Deductions-all">Deductions List</a></li>
                <li></li><li></li>
                  <li class="nav-item d-none d-sm-block"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#Deductions-add">New Deductions</a></li>
            </ul>
             </div>
           
        </div>
    </div>
</div>
<?php
 $cty= $bmodel->get_table_details('voucher_types_tbl');
  ?>
<div class="section-body mt-4">
        <div class="container-fluid">
        	<div class="tab-content">
              <div class="tab-pane active" id="Deductions-all">
               <div class="d-flex justify-content-center">
                <div id="messageDisplayArea"></div>

                </div>
   
                <hr>
                <center>
                    <div id="loaded_data">
                      <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                   
                                    <th>SN</th>
                                   <th>Date</th>
                                   <th>Payroll Year</th>
                                   <th>Payroll Month</th>
                                   <th>Amount</th>
                                   <th>Updated by</th>
                                   <th>Update date</th>
                                     <th>Action</th> 
                                </tr>
                            </thead>
                            <tbody style="padding:1px;">
                               
                       <?php
                         if(isset($saved_charges)):
                                   $total_amount=0;
                                   $i=0;
                            foreach($saved_charges as $ec):
                                $i++;
                       ?>
                        <tr>
                       <td><?=$i;?></td>
                       <td><?=$ec->charge_date?></td>
                       <td><?=$ec->pay_year?></td>
                       <td><?=$ec->month;?></td>
                       <td class="text-right"><?=format_number_with_decimals($ec->total_amount);?></td>                      
<td><?=$ec->first_name.' '.$ec->last_name;?>
                        </td>
                        <td><?=$ec->created_on?></td>
                  <td>
  <a href="#" onclick="view_charges('<?php echo $ec->month;?>','<?php echo $ec->pay_year;?>','<?=$ec->charge_date?>','<?=$ec->pay_month;?>')"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a> 
                     
                        </td> 

                              </tr>                
                       <?php
                   endforeach;
               endif;
                       ?>
                       
                            </tbody>
                            </table>
                                
            </div>
            </div>
<div class="modal fade" id="view_charge">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Deductions view</h4>
        <button type="button" class="btn-close" onclick="hideview_modal()"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
   <div id="view_data">
          
      </div>

      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="hideview_modal()">Close</button>
      </div>

    </div>
  </div>
</div>


                </center>
            </div>
              
              <div class="tab-pane" id="Deductions-add">
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="card card-lg">
                            <div class="card-header"  style="height:5px">
                                <h3 class="card-title">Deductions Details</h3>
                                <div class="card-options ">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                                <hr>
                              <div class="card-body">
<form class="form-horizontal" id="charges_form">
    <div id="feedback"></div>

    <div class="row">
        <div class="col-md-8">

            <!-- Payroll Year -->
            <div class="row mb-3">
                <label for="charge_year" class="col-sm-4 col-form-label text-end">
                    Payroll Year: <span class="text-danger">*</span>
                </label>

                <div class="col-sm-6">
                    <select id="charge_year" name="charge_year"
                        class="payroll-select form-control form-control-sm"
                        required>

                    <?php
                        $initial_year = 2023;
                        $current_year = date('Y');
                        $final_year = $current_year + 1;

                        for ($initial_year; $initial_year <= $final_year; $initial_year++) {
                            if ($initial_year == $current_year) {
                                echo "<option value='$initial_year' selected>$initial_year</option>";
                            } else {
                                echo "<option value='$initial_year'>$initial_year</option>";
                            }
                        }
                        ?>
                    </select>

                    <div class="invalid-feedback">
                        Payroll Year required.
                    </div>
                </div>
            </div>

            <!-- Payroll Month -->
            <div class="row mb-3 ">
                <label for="charge_month" class="col-sm-4 col-form-label text-end">
                    Payroll Month: <span class="text-danger">*</span>
                </label>

                <div class="col-sm-6">
                    <select id="charge_month" name="charge_month"
                        class="payroll-select form-control"
                        required>

                        <option value="" disabled selected>-- Please Select --</option>

                        <?php
                        if (isset($months)) {
                                   foreach ($months as $info) {

                                if ($info->is_current == 1) {
                                    echo '<option value="'.$info->month_id.'" selected>'.$info->month.'</option>';
                                } else {
                                    echo '<option value="'.$info->month_id.'">'.$info->month.'</option>';
                                }
                            }
                        }
                        ?>
                    </select>

                    <div class="invalid-feedback">
                        Payroll Month required.
                    </div>
                </div>
            </div>

            <!-- Charges Date -->
            <div class="row mb-3">
                <label for="charges_date" class="col-sm-4 col-form-label text-end">
                    Deductions Date
                </label>

                <div class="col-sm-6">
                    <input type="date"
                        id="charges_date"
                        name="charges_date"
                        value="<?php echo date('Y-m-d'); ?>"
                        class="form-control"
                        required>
                </div>
            </div>
            <div class="row mb-3">
                                   <div class="col-sm-12">
                                                        <div class="d-flex justify-content-end mt-2 mb-3">

                    <button type="submit" class="btn btn-primary btn btn-lg">Create <i class="me-2"></i></button>
                    </div>                 </div>
            </div>

        </div>
    </div>
</form>

          
                                            <div id="WaitingChargeMsg"></div>
                        <div id="NewCharge"></div>
                                              
                                            </div>

               

                        
                                               
                             </div>
                           
                           <!-- <div class="col-md-1">another side</div> -->
         
      
                        </div>
                         </div>
                        
               
                </div>

                      </div>
                    </div>
                </div>
       
        <script type="text/javascript">
    $(document).ready(function () {     
$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    $('.payroll-select').select2();
   
});
         $('#charges_form').submit(function (e) {
            e.preventDefault();
                 $('#NewCharge').html('');
         
                 if (!this.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
            this.classList.add("was-validated");
             }
             else{
        $('#WaitingChargeMsg').html('<span class="fa fa-spinner fa-spin"></span> Loading form....');
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/electricity_charges_list'; ?>',
                data: $(this).serialize(),
                       beforeSend: function()
            { 
                  $('#NewCharge').html('');
                $('#WaitingChargeMsg').html('<span class="fa fa-spinner fa-spin"></span> Loading form....');
            },
                success: function (res) {
                    $('#NewCharge').html(res);
                     $('#WaitingChargeMsg').html('');
                },
                error: function () {
                    $('#WaitingChargeMsg').html('<div class="alert alert-warning">Fail to retreive data.!!</div>');
                        $('#NewCharge').html('');
                }
            });
        
    }}
    );
            $('#load_saved').submit(function (e) {
            e.preventDefault(); 
                 if (!this.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
            this.classList.add("was-validated");
             }
             else{
        $('#loaded_data').html('<span class="fa fa-spinner fa-spin"></span> Loading saved data....');
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/load_electricity_data'; ?>',
                data: $(this).serialize(),
                       beforeSend: function()
            { 
                $('#loaded_data').html('<span class="fa fa-spinner fa-spin"></span> Loading saved data....');
            },
                success: function (res) {
                    $('#loaded_data').html(res);
                },
                error: function () {
                    $('#loaded_data').html('<div class="alert alert-warning">Fail to retreive data.!!</div>');
                }
            });
        
    }}
    );
});

     $('.load-select').select2();
     function view_charges(month,year,date,month_id){
         $("#view_charge").modal('show');
              $('#view_data').html('<span class="fa fa-spinner fa-spin"></span> Loading form....');
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/view_deductions'; ?>',
                data: {month:month,year:year,date:date,month_id:month_id},
                       beforeSend: function()
            { 
                              $('#view_data').html('<span class="fa fa-spinner fa-spin"></span> Loading form....');
            },
                success: function (res) {
                    $('#view_data').html(res);
                   
                },
                error: function () {
                    $('#view_data').html('<div class="alert alert-warning">Fail to retreive data.!!</div>');
                      
                }
            });
     }
     function hideview_modal(){
              $("#view_charge").modal('hide');
     }
        </script>

