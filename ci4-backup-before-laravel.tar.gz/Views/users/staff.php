<?php
$smodel = new App\Models\StaffModel();
$ssmodel = new App\Models\StudentModel();

?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Staff</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                                <?php  $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
                    </a></li>
                    <li class="breadcrumb-item active" aria-current="page">Staff</li>
                </ol>
            </div>
            
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
           
        <!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="box box-danger">
           
            <div class="box-body">
          
     <div class="d-flex">
    <form id="Rept1Result" class="d-flex align-items-center flex-nowrap w-100">

        <label for="staff" class="me-2">Staff:</label>
        <select class="form-control form-select me-3" name="staff" id="staff">
            <option value="0">All</option>
            <?php
            $c = $smodel->get_staff();
            foreach($c as $cc){
                echo '<option value="' . $cc->id . '">' . $cc->type_name . '</option>'; 
            }
            ?>
        </select>

        <label for="dep" class="me-2">Department:</label>
        <select class="form-control form-select me-3" name="dep" id="dep">
            <option value="0">All</option>
            <?php
            $department = $ssmodel->gettable_data('departments_tbl',['id >' => 0]);
            foreach($department as $dp){
                echo '<option value="' . $dp->id . '">' . $dp->dep_name . '</option>'; 
            }
            ?>
        </select>

        <label for="job" class="me-2">Job Title:</label>
        <select class="form-control form-select me-3" name="job" id="job">
            <option value="0">All</option>
            <?php
            $job = $ssmodel->gettable_data('job_tittle_tbl',['id >' => 0]);
            foreach($job as $jb){
                echo '<option value="' . $jb->id . '">' . $jb->job_tittle . '</option>'; 
            }
            ?>
        </select>

        <label for="status" class="me-2">Status:</label>
        <select class="form-control form-select me-3" name="status" id="status">
            <option value="0">All</option>
            <?php
            $status = $ssmodel->gettable_data('staff_status',['status_id >' => 0]);
            foreach($status as $sts){
                echo '<option value="' . $sts->status_id . '">' . $sts->status_name . '</option>'; 
            }
            ?>
        </select>

        <button type="submit" class="btn btn-primary ms-auto">Create</button>

    </form>
</div>

                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>
           
            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
        </div>
    </div>
</div>

<script type="text/javascript">
                
   $('#Rept1Result').submit(function (e) {
            
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = $(this).serialize();
           // alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/staff_report'; ?>',

                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to load staffs.!!</div>');
                }
            });


        e.preventDefault();
    });
</script>