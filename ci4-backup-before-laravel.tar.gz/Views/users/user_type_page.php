<style>
.modal-dialog1 {
          max-width: 900px; /* New width for default modal */
		   background: #ccc;
		   max-height: 500px;
		   
        }
		
modal-content {
    background: #ccc;
  }
font-family: 'Varela Round', sans-serif;
}
.modal-confirm {		
	color: #636363;
	width: 600px;
}
input{
	width:14px:
}
.modal-confirm .modal-content {
	padding: 20px;
	border-radius: 5px;
	border: none;
	text-align: center;
	font-size: 14px;
}
.modal-confirm .modal-header {
	border-bottom: none;   
	position: relative;
}
.modal-confirm h4 {
	text-align: center;
	font-size: 26px;
	margin: 30px 0 -10px;
}
.modal-confirm .close {
	position: absolute;
	top: -5px;
	right: -2px;
}
.modal-confirm .modal-body {
	color: #999;
}
.modal-confirm .modal-footer {
	border: none;
	text-align: center;		
	border-radius: 5px;
	font-size: 13px;
	padding: 10px 15px 25px;
}
.modal-confirm .modal-footer a {
	color: #999;
}		
.modal-confirm .icon-box {
	width: 80px;
	height: 80px;
	margin: 0 auto;
	border-radius: 50%;
	z-index: 9;
	text-align: center;
	border: 3px solid #f15e5e;
}
.modal-confirm .icon-box i {
	color: #f15e5e;
	font-size: 46px;
	display: inline-block;
	margin-top: 13px;
}
.modal-confirm .btn, .modal-confirm .btn:active {
	color: #fff;
	border-radius: 4px;
	background: #60c7c1;
	text-decoration: none;
	transition: all 0.4s;
	line-height: normal;
	min-width: 120px;
	border: none;
	min-height: 40px;
	border-radius: 3px;
	margin: 0 5px;
}
.modal-confirm .btn-secondary {
	background: #c1c1c1;
}
.modal-confirm .btn-secondary:hover, .modal-confirm .btn-secondary:focus {
	background: #a8a8a8;
}
.modal-confirm .btn-danger {
	background: #f15e5e;
}
.modal-confirm .btn-danger:hover, .modal-confirm .btn-danger:focus {
	background: #ee3535;
}
.trigger-btn {
	display: inline-block;
	margin: 100px auto;
}
p{
	text-weight:20px;
	font-size:16pt;
}
</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Users Types</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Users Types</li>
                </ol>
            </div>
           <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#users-all">Users Types List</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#users-add">New User Type</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#users-all">Users Types List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#users-add">New User Type</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="users-all">
                <div class="card">
		   <p class="">
            <?php
			if(session()->getFlashdata('msg')){
            echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span>'.session()->get('msg').'</div> ';
			
			}
			if(session()->getFlashdata('error')){
			echo '<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span>'.session()->get('error').'</div> ';
			}
            ?>
        </p>
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>No.#</th>
                                    <th>User Type</th>
                                    <th>Description</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
							<tbody>
							<?php
							$i=1;
							foreach($users as $user){
								?>
								  <!--MODAL FOR DELETING THE VEHICLES-->



  <!-- END OF DELETING THE VEHICLES-->
								
								<tr>
								<td> <?php echo $i;?></td>
								<td> <?php echo $user->type_name;?></td>
								<td> <?php echo $user->description;?></td>
								<td>
								<a href="<?php echo base_url() . "/edit_user_type/" . $user->id; ?>" class="btn btn-primary btn-sm editBtn" title="View & Edit Privileges"><span class="fa fa-edit"> Edit</span></a>
								
                                      <?php
                               if($user->id!=3){
                                       ?>									  
										 <!--<button type="button" class="btn btn-danger btn-sm RemoveID" data-id="<?= $user->id;?>"><i class="fa fa-trash"></i> Delete</button>  -->
										   
                                   <?php
                                     }
                                       ?>
								   </td>         
								</tr>
                           
							<?php
							$i++;
							}
							
							?>
							 </tbody>
                            
                        </table>
                    </div>
                </div>
             
            </div>
            <div class="tab-pane" id="users-add">
                <div class="row clearfix">
				<div id="Semester"></div>
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header" style="height:5px">
                                    <h3 class="card-title">Add New User Type</h3>
                                <div class="card-options">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                            <hr>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-12">
                                       <!--  <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                            <strong>Holy guacamole!</strong> You should check in on some of those fields below.
                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div> -->
                                        <form  id="saveUser">
                                            <div class="row mb-3">
                                                <label for="utype" class="col-sm-2 col-form-label col-form-label-sm">User Type Name<span class="text-danger">*</span></label>
                                                <div class="col-sm-3">
                                                    <input type="text" class="form-control form-control-sm" id="utype" name="utype" placeholder="eg: Teacher">
                                                </div>
                                                <label for="udesc" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Description<span class="text-danger">*</span></label>
                                                <div class="col-sm-3">
                                                    <input type="text" class="form-control form-control-sm" id="udesc" name="udesc" placeholder="Description">
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-end mt-2 mb-3">
                                                <button type="submit" class="btn btn-primary"><i class="fa fa-plus me-2"></i>Create</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">

    $('#saveUser').submit(function(e){
         // alert($(this).serialize());
        $.ajax({
            type: "POST",
            url: "<?= base_url('/saveUserType') ?>",
            data: $(this).serialize(),
            success: function (data) {
                $('#Semester').html(data);
                $('#saveUser')[0].reset();
                setTimeout(function(){
                    window.location.reload();
                },1000);
            },
            error: function () {
                $('#fdbkarea').html('Sorry! Something went wrong.');
            }
        });


        e.preventDefault();
    });
 $(".RemoveID").click(function(){

        var id = $(this).attr('data-id');

           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this user type!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/remove_usertype')?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
             success: function(data) {
				 if(data==1){
                swal("Can not be deleted. First remove the assigned user");
			 }else{
				swal("Deleted successfuly"); 
			 }    
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
</script>
