

                    <div class="container-fluid"><br>
                 <div class="" id="printable">
                        <center>
             <!--<h5>EDEN GARDEN EDUCATION TRUST</h5>  -->
             <h5>COMPANY SETUP</h5>  
          </center>
            
                    
        <table class="table table-hover mb-0 text-nowrap att-list">
        <tr><th>Campany Name</th><td><?= $camp[0]->company_name; ?></td><td></td><td></td><td></td><td></td><td></td></tr>
       
        <tr><th>Address name</th><td><?= $camp[0]->address; ?></td></td><td></td><td></td><td></td><td></td></tr>
            <tr><th>Phone 1</th><td><?= $camp[0]->phone1; ?></td></td><td></td><td></td><td></td><td></td></tr>
                <tr><th>Phone 2</th><td><?= $camp[0]->phone2; ?></td></td><td></td><td></td><td></td><td></td></tr>
                <tr><th>Website</th><td><?= $camp[0]->website; ?></td></td><td></td><td></td><td></td><td></td></tr>
                <tr><th>Email</th><td><?= $camp[0]->email; ?></td></td><td></td><td></td><td></td><td></td></tr>
                <tr><th>Tin</th><td><?= $camp[0]->tin; ?></td></td><td></td><td></td><td></td><td></td></tr>
                <tr><th>vat</th><td><?= $camp[0]->vat; ?></td></td><td></td><td></td><td></td><td></td></tr>
                <tr><th>Logo</th><td><img src= "<?php echo base_url('public/company_photos/'.$camp[0]->logo_name);?> " id="output" style="width:84px;" alt="No logo"></td></td><td></td><td></td><td></td><td></td></tr>
        <?php
         
        ?>
     
 </table><br>
</div>
<button type="button" class="btn btn-danger" id="cancel" style="padding:5px; float:right" data-bs-dismiss="modal">Cancel</button>
        <center>
            <button class="btn btn-success btn-sm col-sm-3" type="button" id="print_att"><i class="fa fa-print"></i> Print</button>
        </center>
</div>
<noscript>
    <style>
        table.att-list{
            width:100%;
            border-collapse:collapse
        }
        table.att-list td,table.att-list th{
            border:1px solid
            text-align: left;
        }
        .text-center,.text-c,.d-flex{
            text-align:center
        }
        #cancel,#print_att{
            display: none;
        }
    </style>
</noscript>

<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
     $('#print_att').click(function(){
        var _c = $('#printable').html();
        var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=900,height=600')
        nw.document.write(_c)
        nw.document.write(ns.html())
        nw.document.close()
        nw.print()
       
    })
   
</script>