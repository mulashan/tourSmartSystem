            
                <?php
                 foreach($camp as $list){

                 ?>
                <form class="card-body form-horizontal"  id="editCompany" method="post" enctype="multipart/form-data">
			<div id="fbk" class="text-success"></div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Company Name<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="text" id="company" class="form-control" value="<?=$list->company_name;?>" name="company_name"required="required">
                        <input type="hidden" id="company" class="form-control" value="<?=$list->id;?>" name="company_id"required="required">
                    <span id="company" class="text-danger"></span>
					</div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Address Name<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="address" value="<?=$list->address;?>"required="required">
                    <span id="block" class="text-danger"></span>
					</div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Phone 1<span class="text-danger">*</span></label>
                    <div class="col-md-3">
                        
                        <input type="text" class="form-control" name="phone1" value="<?=$list->phone1;?>" required="required">
                    </div>
                    <label class="col-md-2 col-form-label">Phone 2</label>

                    <div class="col-md-3">
                    <input type="text" class="form-control" value="<?=$list->phone2;?>" name="phone2" >
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Website<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="website" value="<?=$list->website;?>" required="required">
                    <span id="block" class="text-danger"></span>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Email<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="email" class="form-control" name="email" value="<?=$list->email;?>" required="required">
                    <span id="block" class="text-danger"></span>
                    </div>
                </div>   
               <div class="form-group row">
                    <label class="col-md-3 col-form-label">Tin<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="number" class="form-control" name="tin" value="<?=$list->tin;?>" required="required">
                    <span id="block" class="text-danger"></span>
                    </div>
                </div>                           
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">VAT<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="number" class="form-control" name="vat" value="<?=$list->vat;?>" required="required">
                    <span id="block" class="text-danger"></span>
                    </div>
                </div> 

                  <div class="form-group row">
                    <label class="col-md-3 col-form-label">Enable Business Classification <span class="text-danger"></span></label>
                    <div class="col-md-8">
                <input type="checkbox"  name="classification" style="margin-top: 10px;transform: scale(1.5);" value="1" <?php if($list->classification==1){ echo 'checked';}?>>
                   
                    </div>
                </div>
                    <div class="form-group row">
                    <label class="col-md-3 col-form-label">Enable WCF Payments <span class="text-danger"></span></label>
                    <div class="col-md-8">
                <input type="checkbox"  name="wcf_status" style="margin-top: 10px;transform: scale(1.5);" value="1" <?php if($list->wcf_status==1){ echo 'checked';}?>>
                   
                    </div>
                </div>

    
                  <div class="form-group row">
                     <label class="col-md-3 col-form-label">Logo</label>
                    <div class="col-md-8">
                        <img src= "<?php echo base_url('public/company_photos/'.$list->logo_name);?> " id="output" style="width:84px;" alt="select logo">
                          <input type="file" accept="image/*" name="logo" onchange="loadFile(event)">
                    <!-- <img id="output"/>-->
                     <input type="hidden" class="form-control" name="logo1" value="<?=$list->logo_name;?>" required="">
                </div>
                </div> 
              
                    
						
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-8">
                               
                                <button type="submit" id="savebtn" class="btn btn-primary float-right">update</button>
                            </div>
                        </div>
                    </form>
                <?php }?>
                   
<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
   $('#editCompany').submit(function(e){
     
        var form_data = new FormData(this);
         //alert(form_data);
        $.ajax({
          url: "<?= base_url('editCompany'); ?>",
            type: 'POST',
            data: form_data,
            contentType: false,
            processData: false,
            // dataType: 'json',
            success:function(res){
                
                 $("#editCompany")[0].reset();
                     $('#fbk').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated successfuly.</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                
            },
            error:function(){
                $('#fbk').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Update Company.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
            }
        });
        
        e.preventDefault();
    }); 
    var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  };  
</script>