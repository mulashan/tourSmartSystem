  <div class="card">
            <div class="card-header" style="height:5px">
                <h3 class="card-title">Edit Classification</h3>
                <div class="card-options ">
                    <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                </div>
            </div>
            <hr>
            <form class="card-body form-horizontal"  id="EditClassification" method="post" enctype="multipart/form-data">
            
             <div class="form-group row">
                    <label class="col-md-3 col-form-label">Class Name<span class="text-danger">*</span></label>
                    <div class="col-md-5">
                        <input type="hidden" id="id" value="<?php echo $cid[0]->id;?>" class="form-control" name="id">
                        <input type="text" id="class_name" class="form-control" name="class_name" required="required" value="<?php echo $cid[0]->class_name;?>">
                    <span id="class_name" class="text-danger"></span>
                    </div>
                </div>

                   <div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-5">
                               
                                <button type="submit" id="updatebtn" class="btn btn-primary float-right">Update</button>
                            </div>
                        </div>
                    </form>
                   
                </div>

                <script type="text/javascript">
      $('#EditClassification').submit(function(e){
        var Data=$(this).serialize();
         // alert(Data);
          $.ajax({
            url: '<?php echo base_url() . '/index.php/CompanyController/edit_classification'; ?>',

            type: 'POST',
            data: Data,
           success:function(data){
            
                if(data==1){
                    
           swal('success','Saved successfully','success');
                    setTimeout(function(){
                        window.location.reload();
                    },1500)
                }
            },
            error:function(){
               swal('error','Sorry!, Something went wrong','error');
            }
        });
        
        e.preventDefault();
    }); 
                </script>