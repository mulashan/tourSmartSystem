<?php
helper('age');
   $bmodel = new App\Models\BillingModel();
      $prj = $bmodel->get_item_name('project_transaction_tbl', $where = array('project_id' => $pid));
      $prjtbl = $bmodel->get_item_name('projects_tbl', $where = array('id' => $pid));
//print_r($prj);
?>
 <div class="table-responsive mt-3" id="tobeprinted">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable3">
                            <thead>
                                <tr>
                                    <!-- <th>No.#</th> -->
                                    <th>No.#</th>
                                    <th>Trans Type</th>
                                    <th>Trans No</th>
                                    <th>Trans Date</th>
                                    <th>Student Name</th>
                                    <th>DOB</th>
                                    <th>Age</th>
                                    <th> Level</th>
                                    <th>Class</th>
                                    <th>Stream</th>
                                    <th>Amount</th>
                                    <th>Received</th>
                                    
                                    <th class="text-center">Bank</th>
                                    <th>Received BY</th>
                                    <th></th>
                                   
                                </tr>
                            </thead>
                            <tbody>
                           <?php
                           $y=date('Y',strtotime($prjtbl[0]->project_date));
                           $i=0;
                           $totalR=0;
                           $totalI=0;
                                 if(count($prj)>0){
                                    //  print_r($prj);
                                foreach($prj as $s){
                                    $i++;
                                $trans_name = $bmodel->get_item_name('transaction_types_tbl', $where = array('type_id' => $s->trans_type));
                              $student = $bmodel->get_item_name('students', $where = array('id' => $s->student_id));
                             $admtbl = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $s->student_id,'academic_year'=>$y));
                             if(count($admtbl)>0){

                            $lvl = $bmodel->get_item_name('class_level_tbl', $where = array('id' => $admtbl[0]->level_id));
                             $cls = $bmodel->get_item_name('classes_tbl', $where = array('id' => $admtbl[0]->class_id));
                             $strm = $bmodel->get_item_name('streams_tbl', $where = array('id' => $admtbl[0]->stream_id));
                             }else{
                                $y=2023;
                                 $admtbl = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $s->student_id));
                                $lvl = $bmodel->get_item_name('class_level_tbl', $where = array('id' => $admtbl[0]->level_id));
                             $cls = $bmodel->get_item_name('classes_tbl', $where = array('id' => $admtbl[0]->class_id));
                             $strm = $bmodel->get_item_name('streams_tbl', $where = array('id' => $admtbl[0]->stream_id));
                             }
                                   $tRecepted=0;
                                   $bank="";
                                   $time="";
                                     if($s->trans_type==3){
                                         $recRel = $bmodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $s->trans_numba,'trans_type_id'=>3,'status'=>1));
                                      
                                       $used = $bmodel->get_item_name('transaction_use_relation_tbl', $where = array('used_no' => $s->trans_numba,'trans_type'=>3,));
                                       $mytrans_no=$s->trans_numba;
                                       //print_r($recRel);
                                      if(count($recRel)>0 && count($used)==0){
                                         $recAm = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' =>$s->trans_numba,'trans_type'=>3,'ledger_type'=>9));
                                      $tRecepted+=$recAm[0]->amount;
                                              }

                                              $fledger = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' =>$s->trans_numba,'trans_type'=>3,'ledger_type'=>9));
                                              if(count($fledger)==0 ||count($recRel)==0 ||count($used) >0){
                                                $bank="";
                                                $time="";
                                            }else{
                                         $fbank = $bmodel->get_item_name('accounts_tbl', $where = array('id' => $fledger[0]->ledger_id));
                                         $bank=$fbank[0]->account_name;
                                      $ftime = $bmodel->get_item_name('transaction_numbers_tbl', $where = array('trans_type_id' => 3,'trans_number'=>$s->trans_numba));
                                      $time=$ftime[0]->trans_date;
                                      } 
 

                                     }else{
                                     $recRel = $bmodel->get_item_name('transactions_relation', $where = array('invoice_trans_no' => $s->trans_numba));

                                     if(count($recRel)>0){
                                        foreach($recRel as $v){

                                          $checkreversal = $bmodel->get_item_name('receipt_transfer_tbl', $where = array('old_receipt_number' => $v->receipt_trans_no,'trans_type'=>2));
                                          $revesedAmount=0;
                                          if(count($checkreversal)>0){

                                            foreach($checkreversal as $rev){
                                             $revesedAmount=+$rev->amount_transfered;
                                            }
                                          }

                                        $recAm = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $v->receipt_trans_no,'trans_type'=>2,'transation_nature'=>1,'ledger_type'=>7));
                                        $mytrans_no=$v->receipt_trans_no;
                                        $tRecepted+=$recAm[0]->amount-$revesedAmount;
                                       ////find bank and time
                                         $fledger = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $v->receipt_trans_no,'trans_type'=>2,'ledger_type'=>9));
                                          if(count($fledger)==0){
                                                $bank="";
                                                $time="";
                                            }else{
                                         $fbank = $bmodel->get_item_name('accounts_tbl', $where = array('id' => $fledger[0]->ledger_id));
                                         $bank=$fbank[0]->account_name;
                                      $ftime = $bmodel->get_item_name('transaction_numbers_tbl', $where = array('trans_type_id' => 2,'trans_number'=>$v->receipt_trans_no));
                                      $time=$ftime[0]->trans_date; 
                                      }  
                                         }
                                        }
                                    }


                                      ////reeceived by
                                    $ch="";
                                 $control_no = $bmodel->get_item_name('payment_request',$where = array('student_id' =>$s->student_id,'trans_no'=>$s->trans_numba));
                                        if(count($control_no) > 0){
                                     $control_number = $control_no[0]->reference_no;
                                
                                $channel = $bmodel->get_item_name('payment_response',$where = array('reference_no' => $control_number,));

                                if(count($channel)>0){
                                 $chann=$control_no[0]->payment_channel;
                                 $channel_name=$channel[0]->transaction_channel;
                                 // $cus_name=$channel[0]->customer_name;
                                 if($chann==2){
                                    $ch="NMB-".$channel_name;
                                 }else{
                                    $ch="CRDB-".$channel_name;
                                 }
                             }
                             }
                             if($ch=="" && $tRecepted >0){
                     $leg = $bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$mytrans_no,'trans_type_id' =>$s->trans_type));
                     if(count($leg)>0){
                      $recv = $bmodel->get_item_name('users',$where = array('user_id' =>$leg[0]->updated_by));
                      $ch=$recv[0]->first_name." ".$recv[0]->last_name;
                            }
                             }
                                      ////end  
                                      if($pstatus==1 && $tRecepted==0){
                                        continue;
                                      }
                                      if($pstatus==2 && $tRecepted >0){
                                        continue;
                                      }
                                      $totalI+=$s->amount;
                                      $totalR+=$tRecepted;
                                      
                                        $transDesc = $bmodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $s->trans_numba,'trans_type_id'=>$s->trans_type));
                                    
                              
                                      ?>
                                 <tr>
                                    <td><?php echo $i;?></td>
                                     <td><?php echo $trans_name[0]->type_name;?></td>
                                      <td><?php echo $transDesc[0]->trans_number;?></td>
                                    <td><?php echo date('Y-m-d',strtotime($transDesc[0]->trans_date));?></td>
                                    <td><?php echo $student[0]->full_name;?></td>
                                    <td><?php echo  $student[0]->birth_date;?></td>
                                    <td><?= findAge($student[0]->birth_date);?></td>
                                    <td><?php echo $lvl[0]->level_name;?></td>
                                    <td><?php echo $cls[0]->class_name;?></td>
                                    <td><?php echo $strm[0]->stream_name; ?></td>
                                 <td class="text-right"><?php echo number_format($s->amount); ?></td>
                                 <td class="text-right"><?php echo number_format($tRecepted); ?></td>
                                 <td class="text-center text-green"><?php echo $bank;?><br>
                                     <?php echo $time;?>
                                 </td>
                                 <td class="text-green"><?= $ch;?></td>
                                   <td class="view-btn">
                                     
                                   </td>
                                </tr>
                                      <?php
                                      }
                                  }
                                        ?>
                                        <tr>
                                            <td colspan="9"></td>
                                            <td><b>Total</b></td>
                                            <td class="text-right"><b><?php echo number_format($totalI);?></b></td>
                                            <td class="text-right"><b><?php echo number_format($totalR);?></b></td>
                                        </tr>
                            </tbody>
                        </table>
                    </div>
                    <noscript>
                <style type="text/css">
                .notPrinted,.view-btn{
              display: none;
           }
           h6{
            font-size: 14px;
           }
           </style>
                    </noscript>
          <!-- <div class="modal fade" id="viewprojects" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"  style="z-index: 1400;">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="project_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary"  data-toggle="modal" onclick="printable_rept('project_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div> -->


                        <script type="text/javascript">
                        //     $(document).ready(function () {
                        //   $('#myTable3').DataTable();
                        // });
        function view_invoice(pid){
                  
        $('#viewprojects').modal('show'); 
       $('#project_content').load('index.php/CompanyController/view_project_report/'+pid);
    
                }

     function printable_rept(area) {
 var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
  disp_setting += "scrollbars=yes,width=750, height=600, left=80, top=25";
  var content_value = document.getElementById(area).innerHTML;
  var ns = $('noscript').clone();
  var docprint = window.open("", "", disp_setting);
  docprint.document.open();
  docprint.document.write('<html><head><title>MHI</title>');

  // Add a <style> block to set the font family and other print-specific styles
  docprint.document.write('<style>');
  docprint.document.write('@media print {');
  docprint.document.write('  body {');
  docprint.document.write('    font-family: "Times New Roman", sans-serif;');
  docprint.document.write('    font-size: 15px;');
  docprint.document.write('  }');
  docprint.document.write('</style>');

  docprint.document.write('</head><body onLoad="self.print()" style="width:100%;">');

  // Modify content_value to include the colspan attribute
  var modifiedContent = content_value.replace('<td class="colspan-cell">', '<td colspan="2" class="colspan-cell">');
  docprint.document.write(modifiedContent);

  docprint.document.write('</body></html>');
   docprint.document.write(ns.html())
  docprint.document.close();
  docprint.focus();
}
                        </script>