 <?php
   $bmodel = new App\Models\BillingModel();
    $company_reg = $bmodel->get_table_details('company_tbl');
    $prj = $bmodel->get_item_name('projects_tbl', $where = array('id' => $pid));
?>
 <div class="content-wrapper">
    <section class="content">
        <div class="box box-danger">
           
            <div class="card">
                 <center>
      <div> <img src="<?php  echo base_url('public/company_photos/'.$company_reg[0]->logo_name) ?>" style="background: white;width: 20%;height: 20%" ></div>
 <span class="mt-4"><b><?= $company_reg[0]->company_name; ?></b></span><br>
            <span class="modify" style="font-size:15px"><?= $company_reg[0]->address; ?></span>
            <div class="mb-3">
                <div><span class="modify" style="font-size:15px">Phone: +<?= $company_reg[0]->phone1; ?></span></div>
                <div><span class="modify" style="font-size:15px">Email: <?= $company_reg[0]->email; ?></span></div>
                <div><span class="modify" style="font-size:15px"> <?= $company_reg[0]->website; ?></span></div>
             
            </div>
   <span class="mt-3"> <b style="font-size:14px"><u>PROJECT REPORT</u></b></span>
    </b>
</center>
                <div class="text-left mt-3">
          <h6>Project Name: <?php echo $prj[0]->project_name;?></h6>
          <h6>Project Date: <?php echo $prj[0]->project_date;?></h6>
      </div>
               <div class="d-flex justify-content-center mt-3 notPrinted" id="notPrinted">
                
                    <form id="filter_project" class="form-inline">
                        <input type="hidden" name="pid" value="<?php echo $pid;?>">
                         <div class="me-3">Payment Status:</div>
                         <select class="form-control form-select me-3" name="pstatus">
                             <option value="0">All</option>
                             <option value="1">Paid</option>
                             <option value="2">Unpaid</option>
                         </select>
                      
                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="project_report_filtered"></div>
                </center>
  
            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
</div>

<script type="text/javascript">
     $('#filter_project').submit(function (e) {
            
            $('#project_report_filtered').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = $('#filter_project').serialize();
            //alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/CompanyController/filter_project_report'; ?>',

                data: dta,
                success: function (res) {
                    $('#project_report_filtered').html(res);
                },
                error: function () {
                    $('#project_report_filtered').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
</script>