<?php
   $bmodel = new App\Models\BillingModel();
   $imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
  
    $prj = $bmodel->get_item_name('projects_tbl', $where = array('id' => $pid));
   $inv_type = $bmodel->get_item_name('invoice_types_tbl', $where = array('id' => 7));
   $trans_type = $bmodel->get_item_name('transaction_types_tbl', $where = array('type_id!=' => 2));

?>
<form class="card-body form-horizontal" id="pDetails">
   <div id="fbk" class="text-success"></div>
    <div class="form-group row">
       <?php
                             $cls= $bmodel->get_item_name('company_tbl', $where = array('classification' => 1));
                             if(count($cls)>0){
                                ?>
                       <div class="form-group row">
                    <label for="inputpaidBy" class="col-sm-2 col-form-label">Class Name</label>
                    <div class="col-sm-4">
                      <?php
                         $clss= $bmodel->get_table_details('classification_tbl');
                          ?>
                        <select class="form-control" name="class_id" id="class_id">
                            <option value="0">-Choose-</option>
                            <?php foreach($clss as $type): ?>
                            <option value="<?= $type->id ?>"><?= $type->class_name; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6"></div>
                  </div>
                                <?php

                                  }
                                ?>

   </div>

   <div class="form-group row">
                    <label class="col-md-2 col-form-label">Trans Type<span class="text-danger">*</span></label>
                    <div class="col-md-4">
                      <select class="form-control form-select" name="transtype" id="transtype">
                               
                                <?php
                             
                              foreach($trans_type as $le){
                               echo '<option value="' . $le->type_id . '">' . $le->type_name . '</option>'; 
                              }

                               ?>
                            </select>
                   </div>
                    <div class="col-md-6"></div>
                </div>
          <div class="form-group row">
                    <label class="col-md-2 col-form-label">Invoice Type<span class="text-danger">*</span></label>
                    <div class="col-md-4">
                     <input type="hidden" id="inv_type" class="form-control" value="<?=$inv_type[0]->id;?>" name="inv_type">
                        <input type="text" id="invname" class="form-control" value="<?=$inv_type[0]->type_name;?>" required="required">
                   </div>
                    <div class="col-md-6"></div>
                </div>
                 <div class="form-group row">
                    <label class="col-md-2 col-form-label">Project Name<span class="text-danger">*</span></label>
                    <div class="col-md-4">
                     <input type="hidden" id="project_id" class="form-control" value="<?=$prj[0]->id;?>" name="project_id">
                        <input type="text" id="project_name" name="project_name" class="form-control" value="<?=$prj[0]->project_name;?>" required="required">
                   </div>
                    <div class="col-md-6"></div>
                </div>
                <div class="form-group row">
                    <label class="col-md-2 col-form-label">Invoice Date<span class="text-danger">*</span></label>
                    <div class="col-md-4">
                        <input type="date" id="inv_date" class="form-control" value="<?=date('Y-m-d');?>" name="inv_date" required="required">
                   </div>
                    <div class="col-md-6"></div>
                </div>
               
                 <div class="form-group row">
                    <label class="col-md-2 col-form-label">Customer Type<span class="text-danger">*</span></label>
                    <div class="col-md-4">
                     <input type="hidden" id="customer_Type" class="form-control" value="1" >
                        <input type="text"  class="form-control" value="Students"  readonly required="required">
                   </div>
                    <div class="col-md-6"></div>
                </div>


   </form>

   <form id="cDetails" class="card form-inline">

                  <div class="d-flex justify-content-center mt-3 mb-3" style="">
                        
                         <div class="me-3">
                             Academic year: 
                           <select id="year" name="year" class="form-select form-control">
                              <?php
                             $currentYear=date('Y');
                             $startYear=2023;
                             for($year=$currentYear+1;$year>=$startYear;$year--){
                            if($year==$currentYear){
                              echo "<option value='".$year."' selected>".$year."</option>";
                            }else{
                             echo "<option value='".$year."'>".$year."</option>"; 
                            }
                             }
                              ?>
                             
                      <!-- JavaScript loop to generate year options -->
                     
                    </select>
                        </div>

                        <div class="me-3">
                             Level: 
                            <select class="form-control form-select" name="classlevel" id="classlevel">
                                <option value="0">All</option>
                                <?php
                               $l = $remodel->get_levels();
                              foreach($l as $le){
                               echo '<option value="' . $le->id . '">' . $le->level_name . '</option>'; 
                              }

                               ?>
                            </select>
                        </div>

                         <div class="me-3">
                             Class: 
                            <select class="form-control form-select" name="class" id="class">
                                <option value="0">All</option>
                                <?php
                                 $c = $remodel->get_classes1();
                              foreach($c as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->class_name . '</option>'; 
                              }
                                ?>
                            </select>
                         </div>
                      
                         <div class="me-3">
                             Stream: 
                            <select class="form-control form-select" name="stream" id="stream">
                                <option value="0">All</option>
                               
                            </select>
                         </div>
                         <div class="me-3">
                             Adm Type: 
                            <select class="form-control form-select" name="admType" id="admType">
                                <option value="1">All</option>
                                <option value="0">Day</option>
                                <option value="3">Boarding</option>
                                
                            </select>
                         </div>
                       
                          
                         <button type="submit" class="btn btn-primary">Create</button>
                           </div> 
                    </form>

                    <hr>
                &nbsp;<p></p>
                <form id="studentsDetails">
                <center>
                    <div id="StudentsResults"></div>
                </center>
                 <button type="submit"  class="btn btn-primary pull-right" id="submitBtn">Create</button>
              </form>
              <!-- onclick="createProjectInvoice()" -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
  <script type="text/javascript">
     $("#classlevel").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#class").append("<option value='"+id+"'>"+name+"</option>");
                }
            }
        });
    });

        $("#class").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            //url: 'class_list',
             url: '<?php echo base_url() . '/index.php/StudentController/get_stream_details'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#stream").empty();
                $("#stream").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    $("#stream").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });

         $('#cDetails').submit(function (e) {
            $('#submitBtn').prop("disabled", false);
            $('#StudentsResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "class=" + $('#class option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&year="+$('#year option:selected').val()+ "&status="+2+ "&admType="+$('#admType option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/select_students'; ?>',

                data: dta,
                success: function (res) {
                    $('#StudentsResults').html(res);
                },
                error: function () {
                    $('#StudentsResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });

         $('#studentsDetails').submit(function (e) {
            const selectElement = document.getElementById('account');
             var dta=$("#studentsDetails").serialize()+'&'+$("#pDetails").serialize()+'&'+$("#header_form").serialize();
               var account=$('#account').val();
               if(account==""){
             selectElement.style.borderColor = 'red';
               return;
            
         }else{
            // alert(dta);
            $.ajax({
                type: "POST",
             url: '<?php echo base_url() . '/index.php/AdmissionController/save_newinvoice_projects'; ?>',
               beforeSend: function () {
                  $('#submitBtn').prop("disabled", true);
                 
               Swal.fire({
                 title: 'Please wait...',
                 html: '<span class="text-danger">Please wait...</span>',
                 icon: 'info',
                 allowOutsideClick: false,
                 showConfirmButton: false,
                 timerProgressBar: true,
                 onBeforeOpen: () => {
                   Swal.showLoading();
                 }
               });
            },
                data: dta,
                success: function (res) {
                  // alert(result);
                   Swal.close();
                    var data = JSON.parse(res);
                   if(data['status'] == "1"){
                          Swal.fire({
                          title: "successful", 
                          html: data['statusDesc'], 
                          icon: "success"
                        }).then((result) => {
                        if (result.isConfirmed) {
                         //$('#addStudents').modal('hide'); 
                        }
                      });
                  }else{
               
               swal({
                    title: "error", 
                    text: 'Sorry!, Something went wrong!', 
                    type: "error"
                  }).then((result) => {
                  if (result.isConfirmed) {
                  //$('#addStudents').modal('hide'); 
                  }
                });   
            }

                 
                },
                error: function () {
                   alert('Sorry!, Something went wrong!');
               }
            });
         }
            e.preventDefault();
          });

         function createProjectInvoice2(){
           
           const selectElement = document.getElementById('account');
         var dta=$("#studentsDetails").serialize()+'&'+$("#pDetails").serialize()+'&'+$("#header_form").serialize();
         var account=$('#account').val();
         if(account==""){
             selectElement.style.borderColor = 'red';
               return;
            
         }else{
        
         alert(dta);
         $.ajax({
            //  beforeSend: function () {
            //       $('#submitBtn').prop("disabled", true);
                 
            // Swal({
            //        title: "info", 
            //         text: 'Please, Wait...', 
            //         type: "info"
            // });
            // },
                type: "POST",
                url: '<?php echo base_url() . '/index.php/AdmissionController/save_newinvoice_projects'; ?>',

                data: dta,
                success: function (res) {
                      
                var data = JSON.parse(res);
                alert(data);
            if(data['status'] == "1"){
               alert("inserted successfully");
                // Swal.fire({
                //     title: "successful", 
                //     html: data['statusDesc'], 
                //     icon: "success"
                //   }).then((result) => {
                //   if (result.isConfirmed) {
                //    $('#addStudents').modal('hide'); 
                //   }
                // });
            }else{
               alert("something went wrong");
               // swal({
               //      title: "error", 
               //      text: 'Sorry!, Something went wrong!', 
               //      type: "error"
               //    }).then((result) => {
               //    if (result.isConfirmed) {
               //    $('#addStudents').modal('hide'); 
               //    }
               //  });   
            }
                },
                error: function () {
                //    swal({
                //     title: "error", 
                //     text: 'Sorry!, Something went wrong!', 
                //     type: "error"
                //   }).then((result) => {
                //   if (result.isConfirmed) {
                //   $('#addStudents').modal('hide'); 
                //   }
                // }); 
                }
            });
         
      }
      }
  </script>
