<?php
   $bmodel = new App\Models\BillingModel();
  
?>
 <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <!-- <th>No.#</th> -->
                                    <th>No.#</th>
                                    <th>Pjc Date</th>
                                    <th>Pjc Name</th>
                                    <th>Pjc Desc</th>
                                    <th> Status</th>
                                    <th>Created Date</th>
                                    <th>created By</th>
                                   
                                </tr>
                            </thead>
                            <tbody>
                           <?php
                           $i=0;
                                 if(count($prj)>0){
                                    foreach($prj as $s){
                                        $i++;
                                        $user = $bmodel->get_item_name('users', $where = array('user_id' => $s->created_by));

                                        if($s->status==1){
                                            $status="<span style='color:green'>Active</span>";
                                        }else{
                                            $status="<span style='color:red'>Inactive</span>"; 
                                        }
                                      ?>
                                 <tr>
                                    <td><?php echo $i;?></td>
                                    <td><?php echo $s->project_date;?></td>
                                    <td><?php echo $s->project_name;?></td>
                                    <td><?php echo $s->description;?></td>
                                    <td><?php echo $status;?></td>
                                    <td><?php echo $s->date_created;?></td>
                                    <td><?php echo $user[0]->first_name.' '.$user[0]->last_name; ?></td>

                                    <td>
                                         <a href="javascript:void(0)" onclick="manage_projects('<?php echo $s->id;?>')"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>
                                         <a href="javascript:void(0)" onclick="add_newStudents('<?php echo $s->id;?>')"  class="btn btn-primary btn-sm"><i class="fa fa-users"></i> Manage</a>
                                    </td>
                                </tr>
                                      <?php
                                      }
                                  }
                                        ?>
                            </tbody>
                        </table>

        <div class="modal fade" id="projModel" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h5>Edit project</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="project_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('project_content')"><i class="fa fa-print"></i> Print</button> -->
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="addStudents" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5>Manage project</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="manage_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
  $('#myTable').DataTable();
});

function manage_projects(id){
$('#projModel').modal('show'); 
$('#project_content').load('<?php echo base_url() . '/index.php/CompanyController/manage_projects'; ?>/'+id);
      }

function add_newStudents(id){
$('#addStudents').modal('show'); 
 $('#manage_content').load('<?php echo base_url() . '/index.php/CompanyController/students_invoice_projects'; ?>/'+id);
      }
</script> 
