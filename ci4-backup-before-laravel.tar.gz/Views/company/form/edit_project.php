 <?php
   $bmodel = new App\Models\BillingModel();
  
    $prj = $bmodel->get_item_name('projects_tbl', $where = array('id' => $pid));
?>
 <form class="card-body form-horizontal"  id="editProject">
      <div id="fbk" class="text-success"></div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Project Name<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="text" id="pname" class="form-control" value="<?=$prj[0]->project_name;?>" name="pname"required="required">
                        <input type="hidden" id="pid" class="form-control" value="<?=$prj[0]->id;?>" name="pid"required="required">
                    <span id="" class="text-danger"></span>
          </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Project Date<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="date" class="form-control" name="pdate" value="<?=$prj[0]->project_date;?>"required="required">
                    <span id="block" class="text-danger"></span>
          </div>
                </div>

                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Project Description<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <textarea class="form-control" name="pdesc" value="<?=$prj[0]->description;?>"><?=$prj[0]->description;?>
                          
                        </textarea>
                    
          </div>
          </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Status<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                     
                        <select class="form-control form-select" name="pstatus">
                         <option value="1" <?php if($prj[0]->status==1){ echo "selected";}?>>Active</option>
                         <option value="2" <?php if($prj[0]->status!=1){ echo "selected";}?>>InActive</option>
                        </select>
          </div>
                </div>

                <div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-8">
                               
                                <button type="submit" id="savebtn" class="btn btn-primary float-right">update</button>
                            </div>
                        </div>
              </form>

              <script type="text/javascript">
                
                 $('#editProject').submit(function(e){
                  var data=$('#editProject').serialize();
               //  alert(data);
                  $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/CompanyController/save_project_update'; ?>",
            data:data,
            beforeSend: function () {
                $('#fbk').html('<div class="alert alert-info alert-dismissible" role="alert"><strong><span class="fa fa-spin fa-spinner"></span>Updating data.</strong></div>');
            },
            success: function (result) {
               if(result==1){
                $('#fbk').html('<div class="alert alert-success alert-dismissible" role="alert"><strong></span>Updated successfuly.</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
              }else{
                 $('#fbk').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong></span>Sorry!, something went wrong.</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
              }
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
                    e.preventDefault();
                 })

              </script>
