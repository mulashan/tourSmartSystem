<?php
   $bmodel = new App\Models\BillingModel();
  
?>
 <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable2">
                            <thead>
                                <tr>
                                    <!-- <th>No.#</th> -->
                                    <th>No.#</th>
                                    <th>Pjc Date</th>
                                    <th>Pjc Name</th>
                                    <th>Pjc Desc</th>
                                    <th> Status</th>
                                    <th>Created Date</th>
                                    <th>created By</th>
                                    <th>Amount</th>
                                    <th>Received</th>
                                    <th></th>
                                   
                                </tr>
                            </thead>
                            <tbody>
                           <?php
                           $i=0;
                                 if(count($prj)>0){
                                    foreach($prj as $s){
                                        $i++;
                                        $user = $bmodel->get_item_name('users', $where = array('user_id' => $s->created_by));

                                        if($s->status==1){
                                            $status="<span style='color:green'>Active</span>";
                                        }else{
                                            $status="<span style='color:red'>Inactive</span>"; 
                                        }

                                         $prjInv = $bmodel->get_item_name('project_transaction_tbl', $where = array('project_id' => $s->id));

                                         $tInvoiced=0;
                                         $tRecepted=0;
                                     if(count($prjInv)>0){
                                         foreach($prjInv as $inv){
                                    
                                     $tInvoiced+=$inv->amount;
                                     
                                     if($inv->trans_type==3){

                                     $recRel = $bmodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $inv->trans_numba,'trans_type_id'=>3,'status'=>1));
                                       //print_r($recRel);
                                      $used = $bmodel->get_item_name('transaction_use_relation_tbl', $where = array('used_no' => $inv->trans_numba,'trans_type'=>3,));
                                       //print_r($recRel);
                                      if(count($recRel)>0 && count($used)==0){
                                        $recAm = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' =>$inv->trans_numba,'trans_type'=>3,'ledger_type'=>9));
                                      $tRecepted+=$recAm[0]->amount;
                                              }

                                     }else{
                                     $recRel = $bmodel->get_item_name('transactions_relation', $where = array('invoice_trans_no' => $inv->trans_numba));

                                     if(count($recRel)>0){
                                       foreach($recRel as $v){

                                         $checkreversal = $bmodel->get_item_name('receipt_transfer_tbl', $where = array('old_receipt_number' => $v->receipt_trans_no,'trans_type'=>2));
                                          $revesedAmount=0;
                                          if(count($checkreversal)>0){

                                            foreach($checkreversal as $rev){
                                             $revesedAmount=+$rev->amount_transfered;
                                            }
                                          }
                                        $recAm = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $v->receipt_trans_no,'trans_type'=>2,'transation_nature'=>1,'ledger_type'=>7));
                                        $tRecepted+=$recAm[0]->amount-$revesedAmount;
                                         }
                                         }
                                     }

                                     }
                                     }
                                      ?>
                                 <tr>
                                    <td><?php echo $i;?></td>
                                    <td><?php echo $s->project_date;?></td>
                                    <td><?php echo $s->project_name;?></td>
                                    <td><?php echo $s->description;?></td>
                                    <td><?php echo $status;?></td>
                                    <td><?php echo $s->date_created;?></td>
                                    <td><?php echo $user[0]->first_name.' '.$user[0]->last_name; ?></td>
                                 <td><?php echo number_format($tInvoiced); ?></td>
                                 <td><?php echo number_format($tRecepted); ?></td>
                                   <td>
                                       <a href="javascript:void(0)"  class="btn btn-primary btn-sm invoiceprint" data-bs-toggle="modal" data-bs-target="#viewinvoice" onclick="view_project(<?php echo $s->id;?>)"><i class="fa fa-eye"></i> View</a>
                                   </td>
                                </tr>
                                      <?php
                                      }
                                  }
                                        ?>
                            </tbody>
                        </table>
          <div class="modal fade" id="viewprojects" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"  style="z-index: 1400;">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="project_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary"  data-toggle="modal" onclick="printable_rept('project_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>


                        <script type="text/javascript">
                            $(document).ready(function () {
                          $('#myTable2').DataTable();
                        });
        function view_project(pid){
                  
        $('#viewprojects').modal('show'); 
       $('#project_content').load('index.php/CompanyController/view_project_report/'+pid);
    
                }
                        </script>