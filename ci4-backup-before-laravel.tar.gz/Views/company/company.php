
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 

    $comodel = new App\Models\CompanyModel();

    //$charged_item = $cmodel->items_chargedList();
?>



<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Company</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Company</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Company-tab" data-toggle="tab" href="#Company-all">Company</a></li>
                <li class="nav-item"><a class="nav-link" id="Company-tab" data-toggle="tab" href="#Company-add">Add Company</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Company-tab" data-toggle="tab" href="#Company-all">Company</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Company-tab" data-toggle="tab" href="#Company-add">Add Company</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>


<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="Company-all">

                <div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                    <th>No.#</th>
                                    <th>Logo</th>

                                    <th>Company Name</th>
                                    <th>Address Name</th>
                                    <th>Phone Number</th>
                                    <th>Website</th>
                                    <th>Email</th>
                                    <th>Tin</th>
                                    <th>VAT</th>
                                    <th>Modified By</th>
                                    <th>Updated Date</th>
                                  <th>Action</th>
                                </tr>
                            </thead>
                            <tbody style="padding:1px;">
                                <?php 
                                 $i=0;
                                foreach($comp as $camp){ 
                                    $i++;
                                    $source = "";
                                    if($camp->logo_name != ""){
                                      $source =  base_url('public/company_photos/'.$camp->logo_name);
                                    }
                                    ?>
                                   <tr>
                                       <td><?=$i?></td>
                                        <td><img src="<?php echo $source; ?>" width="50" height="50"> </td>
                                        <td><?php echo $camp->company_name;?></td>
                                        <td><?php echo $camp->address ;?></td>
                                        <td><?php echo '+'.$camp->phone1.'</br>+ '.$camp->phone2;?></td>
                                        <td><?php echo $camp->website;?></td>
                                        <td><?php echo $camp->email;?></td>
                                        <td><?php echo $camp->tin;?></td>
                                        <td><?php echo $camp->vat;?></td>
                                        <td><?php 
                                        $user= $comodel->created_by($camp->created_by);
                                        foreach($user as $us){
                                        echo $us->first_name.''.$us->last_name;}?></td>
                                        <td><?php echo $camp->date_created;?></td>
                                        <td><a href="javascript:void(0)" onclick="edit_company(<?php echo $camp->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>

                                            <a href="javascript:void(0)" onclick="view_company(<?php echo $camp->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a>
                                          <!-- <button type="button" class="btn btn-danger btn-sm deleteID"  
                                    data-id="<?php //echo $camp->id;?>"><i class="fa fa-trash"></i></button> -->
                                        </td>
                                        
                                    </tr>
                                <?php } ?>
                            </tbody>
							</table>
                                
            </div>
            </div>
            </div>
            <div class="tab-pane" id="Company-add">
        <div class="card">
            <div class="card-header" style="height:5px">
                <h3 class="card-title">New Company</h3>
                <div class="card-options ">
                    <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                </div>
            </div>
            <hr>
            <form class="card-body form-horizontal"  id="AddCompany" method="post" enctype="multipart/form-data">
			<div id="accfbk" class="text-success"></div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Company Name<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="text" id="company" class="form-control" name="company_name"required="required">
                    <span id="company" class="text-danger"></span>
					</div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Address Name<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="address" required="required">
                    <span id="block" class="text-danger"></span>
					</div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Phone 1<span class="text-danger">*</span></label>
                    <div class="col-md-3">
                        
                        <input type="number" class="form-control" name="phone1" required="required">
                    </div>
                    <label class="col-md-2 col-form-label">Phone 2</label>

                    <div class="col-md-3">
                    <input type="number" class="form-control" name="phone2" >
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Website<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="website" required="required">
                    <span id="block" class="text-danger"></span>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Email<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="email" class="form-control" name="email" required="required">
                    <span id="block" class="text-danger"></span>
                    </div>
                </div>   
               <div class="form-group row">
                    <label class="col-md-3 col-form-label">Tin<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="number" class="form-control" name="tin" required="required">
                    <span id="block" class="text-danger"></span>
                    </div>
                </div>                           
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">VAT<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="number" class="form-control" name="vat" required="required">
                    <span id="block" class="text-danger"></span>
                    </div>
                </div> 
                 
                  <div class="form-group row">
                    <label class="col-md-3 col-form-label">Enable Business Classification <span class="text-danger"></span></label>
                    <div class="col-md-8">
                <input type="checkbox"  name="classification" style="margin-top: 10px;transform: scale(1.5);" value="1">
                   
                    </div>
                </div>
                    <div class="form-group row">
                    <label class="col-md-3 col-form-label">Enable WCF Payments <span class="text-danger"></span></label>
                    <div class="col-md-8">
                <input type="checkbox"  name="wcf_status" style="margin-top: 10px;transform: scale(1.5);" value="1">
                   
                    </div>
                </div>

                  <div class="form-group row">
                    <label class="col-md-3 col-form-label">Logo</label>
                    <div class="col-md-8">
                       <img id="output1" style="width:84px;">
                          <input type="file" accept="image/*" name="logo" onchange="loadFile(event)">
                    </div>
                </div>      
						
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-8">
                               
                                <button type="submit" id="savebtn" class="btn btn-primary float-right">Save</button>
                            </div>
                        </div>
                    </form>
                   
                </div>

            </div>

        </div>
    </div>
</div>
<div class="modal fade" id="EditCompany" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content" style="width:900px;margin-left: 100px;">
      <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel"><center>Edit Company Details</center></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="EditCompany_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="viewCompany" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content" style="width:900px;margin-left: 100px;">
      <div class="modal-header">
         <!--  <h5 class="modal-title" id="staticBackdropLabel"><center>view Company Details</center></h5> -->
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewCompany_content">
      </div>
      <!-- <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save</button>--
      </div> -->
    </div>
  </div>
</div>
<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
   $('#AddCompany').submit(function(e){
        var Data=$(this).serialize();
        
        var form_data = new FormData(this);
    //alert(form_data);
        $.ajax({
          url: "<?= base_url('createCompany'); ?>",
            type: 'POST',
            data: form_data,
            contentType: false,
            processData: false,
            // dataType: 'json',
            success:function(data){
                if(data==1){
                    swal("Company is Already present");
                }else{
                 $("#AddCompany")[0].reset();
                     $('#accfbk').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Saved successfuly.</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }
            },
            error:function(){
                $('#accfbk').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Save Company.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
            }
        });
        
        e.preventDefault();
    }); 
    function edit_company(id){
        
        $('#EditCompany').modal('show'); 
        $('#EditCompany_content').load('edit_company/'+id);
       
    } 
    var loadFile = function(event) {
    var output = document.getElementById('output1');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output1.src) // free memory
    }
  }; 

 function view_company(id){
        
        $('#viewCompany').modal('show'); 
        $('#viewCompany_content').load('view_company/'+id);
       
    } 
    var loadFile = function(event) {
    var output = document.getElementById('output1');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output1.src) // free memory
    }
  }; 
  $(".deleteID").click(function(){

        var id = $(this).attr('data-id');
        //alert (id);
      
           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this item!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/deleteCompany')?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      // $("#"+id).remove();
                     
                    swal("Deleted!", "Item deleted.", "success");
                    location.reload(true);
                      
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
</script>