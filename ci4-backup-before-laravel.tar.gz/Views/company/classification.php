
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 

    $comodel = new App\Models\CompanyModel();
       $bmodel = new App\Models\BillingModel();

    //$charged_item = $cmodel->items_chargedList();
?>



<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Classification</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Classification</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Company-tab" data-toggle="tab" href="#Company-all">Classification List</a></li>
                <li class="nav-item"><a class="nav-link" id="Company-tab" data-toggle="tab" href="#Company-add">New Classification</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Company-tab" data-toggle="tab" href="#Company-all">Classification List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Company-tab" data-toggle="tab" href="#Company-add">New Classification</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>


<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="Company-all">

                <div class="card">
                 <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <!-- <th>No.#</th> -->
                                    <th>No.#</th>
                                    
                                    <th>Class Name</th>
                                    <th>Created Date</th>
                                    <th>created By</th>
                                    <th>Action</th>
                                   
                                </tr>
                            </thead>
                            <tbody>
                           <?php
                           $i=0;
                                 if(count($cid)>0){
                                    foreach($cid as $s){
                                        $i++;
                                        $user = $bmodel->get_item_name('users', $where = array('user_id' => $s->created_by));

                                      ?>
                                 <tr>
                                    <td><?php echo $i;?></td>
                                   
                                    <td><?php echo $s->class_name;?></td>
                                    <td><?php echo $s->date_created;?></td>
                                    <td><?php echo $user[0]->first_name.' '.$user[0]->last_name; ?></td>

                                    <td>
                                         <a href="javascript:void(0)" onclick="manage_projects('<?php echo $s->id;?>')"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>
                                         <!-- <a href="javascript:void(0)" onclick="add_newStudents('<?php echo $s->id;?>')"  class="btn btn-primary btn-sm"><i class="fa fa-users"></i> Manage</a> -->
                                    </td>
                                </tr>
                                      <?php
                                      }
                                  }
                                        ?>
                            </tbody>
                        </table>
                
                 
            </div>
            </div>
            <div class="tab-pane" id="Company-add">
        <div class="card">
            <div class="card-header" style="height:5px">
                <h3 class="card-title">New Classification</h3>
                <div class="card-options ">
                    <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                </div>
            </div>
            <hr>
            <form class="card-body form-horizontal"  id="AddProjects" method="post" enctype="multipart/form-data">
			
             <div class="form-group row">
                    <label class="col-md-3 col-form-label">Class Name<span class="text-danger">*</span></label>
                    <div class="col-md-5">
                        <input type="text" id="class_name" class="form-control" name="class_name"required="required">
                    <span id="class_name" class="text-danger"></span>
                    </div>
                </div>

                   <div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-5">
                               
                                <button type="submit" id="savebtn" class="btn btn-primary float-right">Save</button>
                            </div>
                        </div>
                    </form>
                   
                </div>

            </div>

        </div>
    </div>
</div>
<div class="modal fade" id="EditCompany" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content" style="width:900px;margin-left: 100px;">
      <div class="modal-header">
          <!-- <h5 class="modal-title" id="staticBackdropLabel"><center>Edit Company Details</center></h5> -->
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="EditCompany_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="viewCompany" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content" style="width:900px;margin-left: 100px;">
      <div class="modal-header">
         <!--  <h5 class="modal-title" id="staticBackdropLabel"><center>view Company Details</center></h5> -->
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewCompany_content">
      </div>
      <!-- <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save</button>--
      </div> -->
    </div>
  </div>
</div>
<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
   $('#AddProjects').submit(function(e){
        var Data=$(this).serialize();
     
    
    //return;
        $.ajax({
            url: '<?php echo base_url() . '/index.php/CompanyController/save_classification'; ?>',
            type: 'POST',
            data: Data,
           success:function(data){
            
                if(data==1){
                    swal("Already registred");
                }else{
                 $("#AddProjects")[0].reset();
                     swal('success','Saved successfully','success');
                    setTimeout(function(){
                        window.location.reload();
                    },1200)
                }
            },
            error:function(){
                $('#accfbk').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Save Projects.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
            }
        });
        
        e.preventDefault();
    }); 
    function manage_projects(id){
        
        $('#EditCompany').modal('show'); 
        $('#EditCompany_content').load('<?php echo base_url() .'/index.php/CompanyController/classification_data/'?>'+id);
       
    } 
   

 function view_company(id){
        
        $('#viewCompany').modal('show'); 
        $('#viewCompany_content').load('view_company/'+id);
       
    } 
    var loadFile = function(event) {
    var output = document.getElementById('output1');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output1.src) // free memory
    }
  }; 
  $(".deleteID").click(function(){

        var id = $(this).attr('data-id');
        //alert (id);
      
           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this item!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/deleteCompany')?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      // $("#"+id).remove();
                     
                    swal("Deleted!", "Item deleted.", "success");
                    location.reload(true);
                      
                 }
              });

            } else {
               swal("Cancelled");
            }

          });
  });

    

    $('#Rept1Result').submit(function (e) {
             if (!$('#daterange-all span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#Projects').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-all span').html();
            //alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/CompanyController/fetch_projects'; ?>',

                data: dta,
                success: function (res) {
                    $('#Projects').html(res);
                },
                error: function () {
                    $('#Projects').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });

</script>