       <div class="table-responsive mt-3">
           <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>No.#</th>
                                    <th>Combination Name</th>
                                    <th>Class Level</th>
                                    <th>Subjects</th>
                                    <th>Status</th>
                                    <th>Created By</th>
                                    <th>Created Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
							<tbody>
							<?php
							$i=1;
							foreach($combs
                             as $comb){
								?>
								  <!--MODAL FOR DELETING THE subject-->
								
								<tr>
								<td> <?php echo $i;?></td>
								<td>
                                 <?php echo $comb->comb_name;?></td>
                                 <td>
                                 <?php echo $comb->level_name;?></td>

                             <td > 

                    <ul>
                    <?php 
                        $subjects = explode(", ", $comb->subjects);
                        foreach ($subjects as $subject): 
                    ?>
                        <li><?= $subject; ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php
                ?>

                                 </td>                

                      <td >          
                   <?php if($comb->comb_status==1):?>
                   <strong> <span class="text-success"> Active</span></strong>
                    
                    <?php else:?>
                   
                    <strong> <span class="text-danger"> Inactive</span>  </strong>
                    <?php
                  endif;
                  ?>  
              </td>
               <td> 

                <?php echo $comb->first_name;?> <?php 
                echo $comb->last_name;?>   
               </td>
               <td> <?php echo $comb->created_on;?></td>

                               
								<td>
			 	
                 <a href="#" data-toggle="modal"  data-target="<?=$comb->comb_id;?>" class="EditComb text-light btn btn-xs btn-flat btn-primary"><i class="fa fa-edit"></i> Edit</a>	
                                  <a href="#" data-toggle="modal"  data-target="<?=$comb->comb_id;?>" class="CombView text-light btn btn-xs btn-flat btn-primary"><i class="fa fa-eye"></i> View</a>
						       </td>
								</tr>
                           
          <!-- =================edit modal============ -->
            <!-- Modal -->
  <div class="modal fade" id="EditCombView" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formEditPelanggan" aria-hidden="true">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Edit Combination</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

        </div>
        <div class="modal-body">
         
  <div id="CombupdateStatus"></div>
      <div id="CombupdateMsg"></div>
      <div id="Combupdateform"></div>
      <div id="emptysubjects"></div>
        </div>
        <div class="modal-footer">
        </div>
      </div>
      
    </div>
  </div>
<!-- =====================end of edit modal==== -->
<!-- =====================comb view modal==== -->
<div class="modal fade" id="CombViewModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formEditPelanggan" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel"> Combination Details</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
      <div id="CombViewMsg"></div>
      <div id="CombViewform"></div>
   

        </div>
        
      </div>
      
    </div>
  </div>
  <!-- ==============end of combination view model==== -->


							<?php
							$i++;
							}
							
							?>
							 </tbody>
                            
                        </table>
                    </div>
                    <script>


      $('.EditComb').click(function (e) {
               $('#EditCombView').modal('show');
            $('#CombViewMsg').html('<span class="fa fa-spinner fa-spin"></span> Loading combination data....');
            var data = $(this).attr('data-target');
    //alert(data);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/view_comb_updateform'; ?>',
                data: {data:data},
                success: function (res) {
                    $('#Combupdateform').html(res);
                     $('#CombViewMsg').html('');
                },
                error: function () {
                    $('#CombViewMsg').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });

      $('.CombView').click(function (e) {
               $('#CombViewModal').modal('show');
            $('#CombViewform').html('<span class="fa fa-spinner fa-spin"></span> Loading combination data....');
            var data = $(this).attr('data-target');
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/view_comb_details'; ?>',
                data: {comb_id:data},
                success: function (res) {
                    $('#CombViewform').html(res);
                 
                },
                error: function () {
                    $('#CombViewform').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

        e.preventDefault();
    });


$(document).on('submit', '.EditComb-form', function(e) {
    e.preventDefault();

    let subjectCount = $('input[name="sub_select[]"]:checked').length;

    if (!this.checkValidity() || subjectCount < 2) {
        this.classList.add("was-validated");

        if (subjectCount < 2) {
            $('#emptysubjects').html(
                '<span class="text-danger">Please select at least two subjects!</span>'
            );
        } else {
            $('#emptysubjects').html('');
        }

        return;
    }

    $('#emptysubjects').html('');

    $.ajax({
        type: "POST",
        url: "<?= base_url('/update_comb') ?>",
        data: $(this).serialize(),
        success: function (data) {
            if(data.status==1){
              $('#CombupdateStatus').html('<div class="alert alert-success"><strong>Success!</strong> Combination updated Successfully.</div>')
                .stop(true, true)
                .show()
                .delay(3000)
                .fadeOut();
            $("html, body").animate({ scrollTop: 0 }, "slow");

            setTimeout(function () {
                window.location.reload();
            }, 4000);  
        }else{
               $('#CombupdateStatus').html('<div class="alert alert-warning"><strong>Warning!</strong> Failed to update Combination.</div>')
        }
            
        },
        error: function () {
            $('#CombupdateStatus').html('<div class="alert alert-danger"><strong>Failed!</strong> Failed to update a grade.</div>')
                .stop(true, true)
                .show()
                .delay(3000)
                .fadeOut();
            $("html, body").animate({ scrollTop: 0 }, "slow");

            $('#emptysubjects').html('');
        }
    });
});

                    </script>