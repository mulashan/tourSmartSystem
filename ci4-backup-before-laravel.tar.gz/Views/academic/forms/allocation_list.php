<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
   <style>

    </style>
<?php
            helper('calc');
             $bmodel = new App\Models\BillingModel();
             $smodel = new App\Models\StudentModel();
             $report = new App\Models\ReportsModel();
             $dbname=session()->get('db_name');
            $db = \Config\Database::connect($dbname);
           // $hname=$this->report->get_hostelname($hostel);
            $clname="";
            if($time==1){
             if($classlevel==0){
                $clname="All Level,";
            }else{
                if(count($cl_allocation)>0)
              $clname=$cl_allocation[0]->level_name;  
            }
            if($class==0){
                $cname="All Classes";
            }else{
                if(count($cl_allocation)>0)
              $cname=$cl_allocation[0]->class_name;  
            }
            if($stream==0){
                $str="All Stream";
            }else{
                 if(count($cl_allocation)>0)
               $str=$cl_allocation[0]->stream_name;  
            }
            }else{
          
          if(count($cl_allocation)>0)
            $classlevel=$cl_allocation[0]->level_id;
              $clname=$cl_allocation[0]->level_name;  
          if(count($cl_allocation)>0)
              $cname=$cl_allocation[0]->class_name; 
          if(count($cl_allocation)>0)
              $str=$cl_allocation[0]->stream_name;
            
            }
            
            
          $schoolname=$report->get_schoolname();
             if($classlevel >0 || session()->get('db_id')==1){
                if(session()->get('db_id')==1 && $classlevel==0){
                $classlevel=1;
                }
            $period = $bmodel->get_item_name('class_level_tbl', $where = array('id' => $classlevel));

                
            //print_r($schoolname);
                 $dateterm = $report->checkTerm_date(date('Y-m-d'),$year,$period[0]->academic_type);
                 
                  // print_r($dateterm);
                  // return;
                 if (is_countable($dateterm) && count($dateterm) > 0) {
                   // $term_name=$dateterm[0]->term_name;
                   }else{
                    $dateterm = $report->checkTerm_date2(date('Y-m-d'),$year,$period[0]->academic_type);
                     
                   //  $term_name=$dateterm[0]->term_name;
                   }
               }else{
             // $term_name="All Term";
               }
                ?>
               
            <div id="tobeprinted">
                <?php
                if(count($cl_allocation)>0){
                    $str=$cl_allocation[0]->stream_name;
                    $cname=$cl_allocation[0]->class_name;
                    $clname=$period[0]->level_name;

            echo "<h6><b>".$schoolname[0]->company_name." </h6>";
             echo "<h6>Allocation Details for"." ". $clname." ".$cname." "."(".$str.")" ."</h6>";
                }
               ?>
              <div class="card">
               <div class="table-responsive mt-3">
                <button type="button" class="btn btn-primary mb-3 btnp" style="float:right;" onclick="student_print()"><i class="fa fa-print"></i> Print</button>
    <table class="table table-hover table-vcenter table-bordered mb-0 text-nowrap" id="myTable">

     <thead>
        <tr>
            <th>S/N</th>
            <th>CLASS</th>
            <th>STREAM</th>
            <th>COMBINATION</th>
            <th>SUBJECTS</th>
            <th>Allocated by</th>
            <th>Allocated on</th>
            <th>ACTION</th>
        </tr>
    </thead>
    <tbody>
         <?php
       
            if(count($cl_allocation)>0){
               $i=0; 
            foreach($cl_allocation as $all){
                $i++;
            ?>
        <tr>
            <?php if(empty($all->comb_name)) {
            ?>
            <td><?=$i?></td>
            <td><?=$all->class_name?></td>
             <td><?=$all->stream_name?></td>
              <td class="text-danger">No combination for <?=$all->class_name?> (<?=$all->stream_name?>)</td>
            <td class="text-danger">No subject found</td>
            <td class="text-danger">No Data</td>
            <td class="text-danger">No data</td>
            <td>
               <button type="button" class="btn btn-primary btn-sm AllocationID" data-id=""disabled><i class="fa fa-edit"></i> Edit</button>     

                  <button class="btn btn-primary ViewID"  data-ids="" disabled re>
                    <i class="fa fa-eye"></i> View
                </button>   

            </td>
            <?php 
        }
       else{
        ?>
          <td><?=$i?></td>
            <td><?=$all->class_name?></td>
             <td><?=$all->stream_name?></td>
              <td><?=$all->comb_name?></td>
            <td>
                  <ul>
                    <?php 
                        $subjects = explode(", ", $all->subjects);
                        foreach ($subjects as $subject): 
                    ?>
                        <li><?= $subject; ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php
                ?>  
            </td>
            <td><?=$all->first_name?>  <?=$all->last_name?></td>
            <td><?=$all->created_on?></td>
            <td>
               <button type="button" class="btn btn-primary btn-sm AllocationID " data-id="<?= $all->st_id;?>"><i class="fa fa-edit"></i> Edit</button>     

                  <button class="btn btn-primary ReadID"  data-ids="<?php echo $all->st_id;?>" >
                    <i class="fa fa-eye"></i> View
                </button>   

            </td>
        <?php
       }

        ?>
</tr>
<?php 
}}
?>
    </tbody>

           </table>

<!-- Modal update -->
  <div id="UpdateAllocation" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content" style="width:105%">
        <div class="modal-header">
          <h5 class="modal-title" id="">Update Class Stream Allocation</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
       <div class="modal-body">
          <div id="UpdtAllocation"></div>
        </div>
        <div class="modal-footer">
        </div>
      </div>
      
    </div>
  </div>
         <!-- =======================modal view================================== -->
<!-- View Modal -->
<div class="modal fade" id="ReadModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Stream Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="btn btn-danger">&times;</span>
                </button>
            </div>
            <div class="modal-body">
       <div id="ReadAllocation"></div>
            </div>
             <div class="modal-footer">
        </div>
        </div>
    </div>
</div>
 
      </div>
  </div>
  </div>

  
<noscript>
    <style>
        .table-condensed{
            padding-bottom: 20px; 

        }
        table.table{
            border: 1px solid black;
            width:80%;
          
            margin-left: auto;
            margin-right: auto;
/*            page-break-inside: avoid;*/
           
        }
         table.table td{
         border:1px solid black;
           font-size: 12px;
         }
        #myTable td,#myTable th{
            border:1px solid black;
           font-size: 12px;
           }
        h6{
            text-align: center;
        }
        .btnp,.viewbtn{
           display: none;
        }
        #myTable_wrapper .dataTables_filter,
        #myTable_wrapper .dataTables_paginate,
        #myTable_wrapper .dataTables_length {
         display: none;
}
 @media print {
      .table {
        border-collapse: collapse !important;
        border: 1px solid black !important;
      }
      }
      table.toba td{
        font-size: 12px;
      }
        
    </style> 
</noscript>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
  <script>
   $(document).ready(function() {
  var table = $("#myTable").DataTable({
    dom: 'f',
    paging: false, 
    lengthChange: false,
  });
});


       $(".AllocationID").click(function () {
      var data= 'ids=' + $(this).attr('data-id');
        $('#UpdateAllocation').modal('show');
        $.ajax({
            type: "get",
            url: "<?= base_url('/stream_Edit')?>",
            data: data,
            beforSend: function()
            {
                $('#UpdtAllocation').html('<div class="text-center"><div class="spinner-border text-primary" role="status"><span class="sr-only">Loading...</span></div></div>');
            },
            success: function(res){
                $('#UpdtAllocation').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
   // end allocation update
     $(".ReadID").click(function () {
      var data= 'ids=' + $(this).attr('data-ids');
        $('#ReadModal').modal('show');
        $.ajax({
            type: "get",
            url: "<?= base_url('/ViewStreamAllocation')?>",
            data: data,
            beforSend: function()
            {
                $('#ViewAllocation').html('<div class="text-center"><div class="spinner-border text-primary" role="status"><span class="sr-only">Loading...</span></div></div>');
            },
            success: function(res){
                $('#ReadAllocation').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
            $(".close").click(function() {
        $("#ReadModal").modal("hide");
    });
       $(document).on("click", function(event) {
        if (!$(event.target).closest(".modal-content, .ViewID").length) {
            $("#ReadModal").modal("hide");
        }
    });
  </script>
