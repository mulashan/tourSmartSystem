
<div class="box box-default">
    <div class="box-header">
    </div>
    <div class="panel-body">
        <div class="nav-tabs-custom tab-primary">
        <div class="d-flex justify-content-between align-items-center ">

    </div><br>
            <div class="tab-content" style="overflow-x: hidden">
                <div class="tab-pane active" id="bd">
                          <form id="edit_Alocation" method="POST" enctype="multipart/form-data" action="<?= base_url('save_changes'); ?>">
                                    <div class="row">
                                    <div id="edit"></div>
                                        <div class="col-md-6">
                                            <div class="row mb-3">
                                    <?php foreach($update_all as $allocate){ ?>
                                     <label for="name_teacher" class="col-sm-4 col-form-label col-form-label-sm">Teacher</label>
                                        <div class="col-sm-6">
                                   <input type="hidden" class="form-control form-control-sm" value="<?= $allocate->allocation_id;?>" name="allocate_id">
                                     <select name="name_teacher" id="name_teacher" class="form-control"  >
                                  <?php     
                                  if(isset($teacher)){
                                   foreach ($teacher as $teach){            
                                if($teach->user_id==$allocate->teacher_id)
                                {
                                  print "<option value='".$allocate->teacher_id."' selected>". $teach->first_name.'  '.$teach->last_name."</option>";
                                }
                               else{ 
                  print "<option value='
                                     ".$teach->user_id."'>".
                                                    $teach->first_name.' '. $teach->last_name.
                                                 "</option>";
                                                 }
                                             }}
                                                 
                                             ?>
                                        
                                                    </select> 
                                                
                                                </div>
                                                <?php       }?>
                                            </div>


                                    <div class="row mb-3">
                                            <?php foreach($update_all as $allocate){ ?>
                                     <label for="name_subject" class="col-sm-4 col-form-label col-form-label-sm">Subject</label>
                                        <div class="col-sm-6">
                                     <select name="name_subject" id="name_subject" class="form-control"  >
                                  <?php     
                                  if(isset($teach_sub)){
                                   foreach ($teach_sub as $sub){            
                                if($sub->subject_id==$allocate->teacher_subject)
                                {
                                  print "<option value='".$allocate->teacher_subject."' selected>". $sub->subject_name."</option>";
                                }
                               else{ 
                  print "<option value='
                                     ".$sub->subject_id."'>". $sub->subject_name."</option>";
                                                 }
                                             }}
                                                 
                                             ?>
                                        
                                                    </select> 
                                                
                                                </div>
                                                <?php       }?>
                                            </div>
                                        </div>             
                   <div class="col-md-6">
                               <div class="row mb-3">
                                            <?php foreach($update_all as $allocate){ ?>
                                     <label for="classlevel" class="col-sm-4 col-form-label col-form-label-sm">Class Level</label>
                                        <div class="col-sm-6">
                                     <select name="classlevel" id="classlevel" class="form-control"  >
                                  <?php     
                                  if(isset($clevel)){
                                   foreach ($clevel as $level){            
                                if($level->id==$allocate->classlevel)
                                {
                                  print "<option value='".$allocate->classlevel."' selected>". $level->level_name."</option>";
                                }
                               else{ 
                  print "<option value='".$level->id."'>". $level->level_name."</option>";
                                                 }
                                             }}
                                                 
                                             ?>
                                        
                                                    </select> 
                                                
                                                </div>
                                                <?php       }?>
                                            </div>
                                               <div class="row mb-3">
                                            <?php foreach($update_all as $allocate){ ?>
                                     <label for="class" class="col-sm-4 col-form-label col-form-label-sm">Class</label>
                                        <div class="col-sm-6">
                                     <select name="class" id="class" class="form-control"  >
                                  <?php     
                               if(isset($classname)){
                                  foreach ($classname as $clas){            
                             if($clas->id==$allocate->class)
                                {
                                 print "<option value='".$allocate->class."' selected>". $clas->class_name."</option>";
                                     }
                                       }}
                                                 
                                             ?>
                                        
                                                    </select> 
              

                                                
                                                </div>
             <marquee> <span class="text-danger">To change the class, Select class level first</span></marquee>         
                                                <?php       }?>

                                            </div>
                                    </div>
                                        </div>
                                        <div class="d-flex justify-content-end mt-2 mb-3">
                                            <button type="submit" class="btn btn-primary"><i class="fa fa-edit me-2"></i>Update</button>
                                        </div>

                                </form>
                                 </div>
                </div>
                  
            </div>
        </div>
    </div>
<script>

   loadSpecialPermission();
    function loadSpecialPermission() {
        $('#unPermssn').load('<?php echo base_url() . '/unassgnd_permissions/' . $id.'/'.$username; ?>');
        $('#speclPermssn').load('<?php echo base_url() . '/load_special_permissions/' . $username; ?>');
    }

    function AssgnSpecialModule(modId) {
        var perdata = "modl=" + modId + "&user=<?php echo $username; ?>";
        $.ajax({
            data: perdata,
            url: '<?php echo base_url() . '/add_special_permissions'; ?>',
            type: 'POST',
            success: function (rs) {
                loadSpecialPermission();
            },
            error: function () {
                alert('Sorry! Something went wrong');
            }
        });
    }

    function UnassgnSpecialModule(modId) {
        var perdata = "modl=" + modId + "&user=<?php echo $username; ?>";
        $.ajax({
            data: perdata,
            url: '<?php echo base_url() . '/remove_special_permissions'; ?>',
            type: 'POST',
            success: function (rs) {
                loadSpecialPermission();
            },
            error: function () {
                alert('Sorry! Something went wrong');
            }
        });
    }

    $('#PaswdReset').submit(function (e) {
        $.ajax({
            data: $(this).serialize(),
            url: '<?php echo base_url() . '/password_reset'; ?>',
            type: 'POST',
            success: function (rs) {
                $('#prfeedback').html(rs);
            },
            error: function () {
                alert('Sorry! Something went wrong');
            }
        });
        e.preventDefault();
    });

//validation of inputs ......................

   
    $('#edit_Allocation').submit(function(e){
        var data=$(this).serialize();
       //var form_data = new FormData(this);
       alert(data);
        $.ajax({
            method: 'POST',
            url: "<?= base_url('save_changes'); ?>",
            data: data,
            contentType: false,
            processData: false,
            //dataType: 'json',
            success:function(data){
            $('#edit').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
                setTimeout(function(){
            window.location.reload();
        },1000)
            },
            error:function(data){
                $('#edit').html('<div class="alert alert-success alert-dismissible" role="alert"><strong> Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
          setTimeout(function(){
           window.location.reload();
        },1000)
            }
        });
        
        e.preventDefault();
    });
  // ==================class level=====================
  $("#classlevel").change(function(){
        var InputOption = '';
        var clvl = $(this).val();   
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value=''>-Choose Class-</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    var total = response[i]['total'];
                    // if(total <= 0){
                    //     InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Room for New Student'+"</option>";
                    // }else{
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+''+"\xa0"+''+"</option>";
                    //}

                    $("#class").append(InputOption);;
                }
            }
        });
    });
</script>
                               