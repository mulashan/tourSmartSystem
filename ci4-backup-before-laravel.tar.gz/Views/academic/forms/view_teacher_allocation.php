
<div class="box box-default">
    <div class="box-header">
    </div>
    <div class="panel-body">
        <div class="nav-tabs-custom tab-primary">
        <div class="d-flex justify-content-between align-items-center ">

    </div><br>
                <div class="row">
                  
                    <!-- ==modal row start==-->
                    <div class="col-md-6">
                        <!-- ==Taecher info== -->
                        <div class="card shadow-sm">
                            <div class="card-header bg-light p-3">
                                <h5> Allocation Details</h5>
                            </div>
                            <div class="card-body">

       <table class="table table-borderless">
                    <?php   
                    if(isset($teacher)){
                        ?>

                    <tr>
                        <th>Teacher Name</th>
                        <td > <?php echo $teacher->first_name;?>
                                     
                                      <?php echo $teacher->last_name;?></td>
                    </tr>
           
                                       <tr>
                        <th>Number of Subjects</th>
                        <td> <?=esc($subject_count);?></td>
                    </tr>
                                           <tr>
                        <th>Number of Streams</th>
                        <td> <?=count($view_all);?></td>
                    </tr>
                              <tr>
                        <th>Gender:</th>
                        <td><?=$teacher->gender;?></td>
                    </tr>
                    <tr>
                        <th>Contact:
                        </th>
                        <td> <?php echo $teacher->phone_no;?></td>
                    </tr>
                         <tr>
                        <th>Role (User type):
                        </th>
                        <td> <?php echo $teacher->type_name;?></td>
                    </tr>
                    
                <?php
            }
                ?>
                </table>
                               </div>
                           </div>
                           <!-- ==Taecher info== -->
                       </div>
                        <!-- ==modal row End==-->
                                    <div class="col-md-6">
                        <!-- ==Taecher info== -->
                        <div class="card shadow-sm">
                            <div class="card-header bg-light p-3">
                                <h5> Allocation Details</h5>
                            </div>
                            <div class="card-body">

       <table class="table table-bordered">
        <thead>
          <tr>
                    <th>S/N</th>
                    <th>Subject</th>
                    <th>Class</th>
                    <th>Stream</th>
                    <th>Allocated By</th>
                    <th>Allocated On</th>
                                     </tr>
                     </thead>
                <tbody>
                    <?php
                    $sn=0;
                    if (isset($view_all)) {
                    foreach ($view_all as $item) {
                         $sn++;
                           ?>
                    <tr>
                    <td><?=$sn;?></td>
                    <td><?=$item->subject_name;?></td>
                    <td><?=$item->class_name;?></td>
                    <td><?=$item->stream_name;?></td>
                    <td><?=$item->first_name.' '.$item->last_name;?></td>
                    <td><?=$item->allocation_date;?></td>
                </tr>
                <?php
             }
         }
                ?>
                                  </tbody>
           
                </table>
                               </div>
                           </div>
                           <!-- ==Taecher info== -->
                       </div>
                    
                   </div>
</div>
</div>
  <div class="panel-footer d-flex justify-content-center">
    <div class="align-items-center">
         </div>
</div> 
</div>
<script>
    
 $(".Removeallocation").click(function(){
        var id = $(this).attr('data-allocation_id');
           swal({
            title: "You are about to delete this allocation?",
            text: "You will not be able to recover this Subject!",
             type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
           confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'20px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/delete_allocation')?>/'+id,
                 error: function() {
                    swal('Something went wrong!!');
                 },
               success: function(data) {
            
                swal("Deleted successfuly"); 
                setTimeout(function(){
                    window.location.reload();
                },1000);
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
 // delete ends here
</script>