
<div class="box box-default">
    <div class="box-header">
    </div>
    <div class="panel-body">
        <div class="nav-tabs-custom tab-primary">
        <div class="d-flex justify-content-between align-items-center ">
    </div><br>  
            <div class="tab-content" style="overflow-x: hidden">
                <div class="tab-pane active" id="bd">
                        <form  id="edit_Alocation">
                                    <div class="row">
                                    <div id="edit"></div>
                                     <div id="showmsg"></div>
                                      <div class="col-md-6">
                               <div class="row mb-3">
                                            <?php foreach($update_all as $allocate){ ?>
                          <input type="hidden" id="update_id" name="update_id" class="form-control form-control-sm" value="<?= $allocate->st_id;?>">
                                     <label for="classlevel" class="col-sm-4 col-form-label col-form-label-sm">Class Level:</label>
                                        <div class="col-sm-6">
                                     <select name="classlevel" id="classlevel" class="form-control"  disabled>
                                    <option value=""><?=$allocate->level_name;?></option> 
                               
                                                    </select> 
                                                
                                                </div>
                                              <?php
                                          }?>
                                            </div>
                                              <div class="row mb-3">
                                    <?php foreach($update_all as $allocate){ ?>
                                     <label for="stream" class="col-sm-4 col-form-label col-form-label-sm">Stream: </label>
                                        <div class="col-sm-6">
                                  
                                     <select name="stream" id="stream" class="form-control"  >
                                          <option value="<?=$allocate->id;?>"><?=$allocate->stream_name;?></option>
                                                    </select> 
                                                
                                                </div>
                                                <?php       }?>
                                            </div>
                                               
                                    </div>
                                        <div class="col-md-6">
                                
                                       <div class="row mb-3">
                                            <?php foreach($update_all as $allocate){ ?>
                                     <label for="class" class="col-sm-4 col-form-label col-form-label-sm">Class:</label>
                                        <div class="col-sm-6">
                                     <select name="class" id="class" class="form-control"  >
                                         <option value="<?=$allocate->class_id;?>"><?=$allocate->class_name;?></option>
                                                    </select>     
                                                
                                                </div>  
                                                <?php       }?>

                                            </div>

                                    <div class="row mb-3">
                                            <?php foreach($update_all as $allocate){ ?>
                                     <label for="comb" class="col-sm-4 col-form-label col-form-label-sm">Combination: </label>
                                        <div class="col-sm-6">
                                     <select name="comb" id="comb" class="me-4 subject-select form-control form-control-sm combselect" style="width: 150px;" >
                                  <?php     
                                  if(isset($comb1)){
                                   foreach ($comb1 as $combs){            
                                if($combs->comb_id==$allocate->comb)
                                {
                                  print "<option value='".$allocate->comb_id."' selected>".$allocate->comb_name."</option>";
                                }
                               else{ 
                  print "<option value='".$combs->comb_id."'>".$combs->comb_name."</option>";
                                                 }
                                             }}
                                                 
                                             ?>
                                        
                                                    </select> 
                                                
                                                </div>
                                                <?php       }?>
                                            </div>

                                        </div>             
                 
                                        </div>
                                        <div class="d-flex justify-content-end mt-2 mb-3">
                                            <button type="submit" class="btn btn-primary"><i class="fa fa-edit me-2"></i>Update</button>
                                        </div>

                            </form>
                         </div>
                </div>
                  
            </div>
        </div>
    </div>
<script>
   
    $('#edit_Alocation').submit(function(e){
        var data=$(this).serialize();
        $.ajax({
            method: 'POST',
            url: "<?= base_url('/savestream_Edit'); ?>",
            data: data,
            success:function(response){
             $('#showmsg').html(response); 
                setTimeout(function(){
            window.location.reload();
        },1000)
            },
            error:function(response){
                $('#edit').html('<div class="alert alert-success alert-dismissible" role="alert"><strong> Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
          setTimeout(function(){
           window.location.reload();
        },1000)
            }
        });
        
        e.preventDefault();
    });
    $(document).ready(function() {
        $(".combselect").select2();
    });
</script>
                               