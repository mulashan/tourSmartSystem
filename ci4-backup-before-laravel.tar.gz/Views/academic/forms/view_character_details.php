<div class="box box-default">
    <div class="box-header">
    </div>
<?php
if (isset($character) && !empty($character)){
    foreach($character as $character){
?>
    <div class="panel-body">
        <div class="nav-tabs-custom tab-primary">
            <div class="d-flex justify-content-between align-items-center"></div>
            <br>

            <div class="row">
                <!-- CHARACTER Info -->
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-header bg-light p-3">
                            <h5>Character Information</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-borderless">
                                <tr>
                                    <th>CHARACTER NAME:</th>
                                    <td><?= $character->character_name; ?></td>
                                </tr>
                                  <tr>
                                    <th>CHARACTER CODE:</th>
                                    <td><?= $character->character_code; ?></td>
                                </tr>
                                <tr>
                                    <th>CHARACTER STATUS:</th>
                                    <td>
                                        <?php if ($character->character_status == 1): ?>
                                            <strong><span class="text-success">Active</span></strong>
                                        <?php else: ?>
                                            <strong><span class="text-danger">Inactive</span></strong>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>CREATED BY:</th>
                                    <td><?= $character->first_name . ' ' . $character->last_name; ?></td>
                                </tr>
                                <tr>
                                    <th>CREATED ON:</th>
                                    <td><?= $character->create_date; ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Subjects Info -->
                <div class="col-md-6">
          
 
                    <div class="card shadow-sm">
                      
                        <div class="card-header bg-light p-3">
                            <h5>Other Details</h5>
                        </div>

                        <div class="card-body">
            
                    </div>
                    </div>
            
            </div>
            </div>
        </div>
        <hr>
        <div class="panel-footer d-flex justify-content-center">
            <div class="align-items-center">
                <button type="button" class="btn btn-danger btn-sm Removecharacter" data-character_id="<?= $character->character_id ?>">
                    <i class="fa fa-trash"></i> Delete
                </button>
            </div>
        </div>
    </div>
    <?php
}}else{?>
    <center>
        
        <span class="alert alert-warning">Data not found!</span>
    </center>
<?php }?>
</div>

<script>
                          $(".Removecharacter").click(function(){
        var id = $(this).attr('data-character_id');
           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this Character details!",
            customClass: 'swal-wide',
            showCancelButton: true,
           confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/remove_character')?>/'+id,
                 error: function() {
                    swal('Something went wrong!!');
                 },
               success: function(data) {
            
                swal({  title: "Deleted",
            text: "The character delete successfuly!",
              icon: "success",
            customClass: 'swal-wide',
        height:'200px'}

                    ); 

                setTimeout(function(){
                    window.location.reload();
                },1000);
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
    //                        $(".RemoveCharacter").click(function(){
    //     var id = $(this).attr('data-character_id');
    //        swal({
    //         title: "Are you sure?",
    //         text: "You will not be able to recover this Subject!",
    //         // type: "warning",
    //         customClass: 'swal-wide',
    //         showCancelButton: true,
    //        confirmButtonClass: "btn-danger",
    //         confirmButtonText: "Yes, delete!",
    //         cancelButtonText: "No, cancel!",
    //         closeOnConfirm: false,
    //         closeOnCancel: false,
    //         height:'200px'
    //       },

    //       function(isConfirm) {
    //         if (isConfirm) {
    //           $.ajax({
    //              url: '<?= base_url('/remove_character')?>/'+id,
    //              error: function() {
    //                 swal('Something went wrong!!');
    //              },
    //            success: function(data) {
            
    //             swal("Deleted successfuly"); 
    //             setTimeout(function(){
    //                 window.location.reload();
    //             },1000);
    //              }
    //           });

    //         } else {
    //            swal("Cancelled");
    //         }

    //       });

    // });
</script>
