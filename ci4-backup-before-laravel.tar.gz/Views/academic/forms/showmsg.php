
<div class="container mt-3">
  <div class="card">
    <?php if ($status == 'success'): ?>
      <div class="alert alert-success alert-dismissible fade show">
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        <strong>Success!</strong> <?= $message ?>
      </div>
    <?php elseif ($status == 'error'): ?>
      <div class="alert alert-danger alert-dismissible fade show">
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        <strong>Error!</strong> <?= $message ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<script type="text/javascript">
  <?php if ($status == 'success'): ?>
    Swal.fire({
        title: "Success!",
        text: "<?= $message ?>",
        icon: "success",
        confirmButtonText: "OK"
    });
  <?php elseif ($status == 'error'): ?>
    Swal.fire({
        title: "Error!",
        text: "<?= $message ?>",
        icon: "error",
        confirmButtonText: "OK"
    });
  <?php endif; ?>
</script>
