  
<form id="Combupdateform" class="EditComb-form">
                           
    <input type="hidden" name="comb_id" value="<?= $comb->comb_id; ?>">

    <label>Combination Name:</label>
    <input type="text" name="combname" value="<?= $comb->comb_name; ?>" class="form-control mb-2">
    <label>Class Level:</label>
 <select name="classlevel" id="classlevel" class="form-control form-control-sm teacher-select" required>
    <option value="" disabled>-- Select Class Level --</option>
    <?php if (isset($classlevel)): ?>
        <?php foreach ($classlevel as $level): ?>
            <option value="<?= $level->id ?>" <?= (isset($comb) && $comb->classlevel == $level->id) ? 'selected' : '' ?>>
                <?= $level->level_name ?>
            </option>
        <?php endforeach; ?>
    <?php endif; ?>
</select>
                                  
                             <div class="row mb-3">                   
            <div class="col-sm-12 ms-3 col-form-label col-form-label-sm">
     <div class="d-flex align-items-start">

    <label for="combname" class="me-3">Select Subjects</label>
    <div class="col-sm-8">
      <?php foreach ($sub1 as $sub): ?>
            <?php $checked = in_array($sub->subject_id, $assigned_subjects) ? 'checked' : ''; ?>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="sub_select[]" value="<?= $sub->subject_id ?>" <?= $checked ?>>
                <label class="form-check-label"><?= $sub->subject_name ?></label>
            </div>
        <?php endforeach; ?>
    
    </div>
</div>       
</div>

</div>

    <label>Combination Status:</label>
    <select name="combstatus" class="form-control">
        <option value="1" <?= $comb->comb_status == 1 ? 'selected' : ''; ?>>Active</option>
        <option value="2" <?= $comb->comb_status == 2 ? 'selected' : ''; ?>>Inactive</option>
    </select>

    <button type="submit" class="btn btn-success mt-3">Update</button>
</form>
 