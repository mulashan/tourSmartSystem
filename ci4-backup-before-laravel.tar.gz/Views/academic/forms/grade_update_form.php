

 <form id="editgrade" class="editgrade-form" class="needs-validation" novalidate>
 <?php 
 foreach($grades as $grade){
                                ?>
    <input type="hidden" name="grade_id" value="<?= $grade->grade_id; ?>">

    <label>Grade Name:</label>
    <input type="text" name="gradename"style="text-transform: uppercase;" maxlength="1" value="<?= $grade->grade_name; ?>" class="form-control">
    <label>Class Level:</label>
 <select name="classlevel" id="classlevel" class="form-control form-control-sm teacher-select" required>
    <option value="">-- Select Class Level --</option>
    <?php if (isset($classlevel)): ?>
        <?php foreach ($classlevel as $level): ?>
            <option value="<?= $level->id ?>" <?= (isset($grade) && $grade->id == $level->id) ? 'selected' : '' ?>>
                <?= $level->level_name ?>
            </option>
        <?php endforeach; ?>
    <?php endif; ?>
</select>

    <label>Grade Highest Mark</label>
   <input type="number" step="any" class="form-control form-control-sm" id="highgrade" name="highgrade" min="0" max="100" value="<?= $grade->upper_performance; ?>" placeholder="eg: 100" required>
       <div class="invalid-feedback">Grade Highest Mark required.</div>
    <label>Grade Lowest Mark</label>
     <input type="number" step="any" class="form-control form-control-sm" id="lowgrade" name="lowgrade" min="0" max="100" value="<?= $grade->lower_performance; ?>" placeholder="eg: 20" required>
     <div class="invalid-feedback">Grade Lowest Mark required.</div>
      <label >Comments</label>
      <input type="text" class="form-control form-control-sm" id="gradecomment" name="gradecomment"value="<?= $grade->comments; ?>" placeholder="eg: Excellent" required>
       <div class="invalid-feedback">Grade Comments required.</div>
      <label >Grade points</label>
      <input type="number" class="form-control form-control-sm" id="divisionpoints" value="<?= $grade->division_point;?>" name="divisionpoints"  placeholder="eg: 1" required>
       <div class="invalid-feedback">Grade points required.</div>
    <button type="submit" class="btn btn-success mt-3">Update</button>
    <?php
}?>
</form>
