       <!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap JS (required for modals) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- SweetAlert (if you're using it) -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

       <div class="table-responsive mt-3">
           <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>No.#</th>
                                    <th>Grade</th>
                                    <th>Class Level</th>
                                    <th>performance</th>
                                    <th>Comments</th>
                                    <th>Division Points</th>
                                    <th>Created By</th>
                                    <th>Created Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
							<tbody>
							<?php
							$i=1;
							foreach($grades
                             as $grade){
								?>
								  <!--MODAL FOR DELETING THE subject-->
								
								<tr>
								<td> <?php echo $i;?></td>
								<td> <?php echo $grade->grade_name;?></td>
                                <td> <?php echo $grade->level_name;?></td>
                             <td >          
                            <?php echo $grade->lower_performance;?>
                            <span> - </span>
                            <?php echo $grade->upper_performance;?>
                                 </td>                
                          <td> <?php echo $grade->comments;?></td>
                          <td> <?php echo $grade->division_point;?></td>
               <td> <?php echo $grade->first_name; ?>
               <?php echo $grade->last_name;?>   
               </td>
               <td> <?php echo $grade->created_on;?></td>

                               
								<td>
			 <a href="#" data-toggle="modal"  data-target="<?=$grade->grade_id;?>" class="EditGrade text-light btn btn-xs btn-flat btn-primary"><i class="fa fa-edit"></i> Edit</a>		
              <a href="#" data-toggle="modal"  data-target="#view_grade<?=$grade->grade_id;?>" class="text-light btn btn-xs btn-flat btn-primary"><i class="fa fa-eye"></i> View</a>
								  
						       </td>
								</tr>
                           
          <!-- =================edit modal============ -->
            <!-- Modal -->
  <div class="modal fade" id="EditGradeView" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formEditPelanggan" aria-hidden="true">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Edit Grade</h5>
          <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
      <div id="GradeValueError"></div>
      <div id="updatedstatus"></div>
      <div id="gradeupdateMsg"></div>
      <div id="gradeupdateform"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
  <!-- =====================end of edit modal==== -->
  <!-- =====================grade view modal==== -->
<div class="modal fade" id="view_grade<?=$grade->grade_id;?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formEditPelanggan" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel"> Grade Details</h5>
          <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
                         <div class="row">
                    <!-- combination information-->
                    <div class="col-md-6">
                        <div class="card shadow-sm">
                            <div class="card-header bg-light p-3">
                                <h5>Grade Information</h5>
                            </div>
                            <div class="card-body">
                                <hr>

 <strong>GRADE NAME:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="p-5"> <?php echo $grade->grade_name;  ?></span>
   <br>
   <br>
  
  <strong>PERFORMANCE LEVEL:</strong>&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span class="p-5">
     <?php echo $grade->lower_performance;?>
                            <span> - </span>
                            <?php echo $grade->upper_performance;?>
              </span>
       <br>
       <br>
  <strong>GRADE COMMENT:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="p-5"> <?php echo $grade->comments;?></span>
    <br>
    <br>
  <strong>CTEATED BY:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span class="p-5"> <?php echo $grade->first_name;?> <?php echo $grade->last_name;?></span><br>
              <br>
         
                  <strong>CTEATED ON:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="p-5"> <?php echo $grade->created_on; ?></span>
            
                <hr>

                                                      
                            </div>
                        </div>
                    </div>
              <!--       <div class="col-md-6">
                        <div class="card shadow-sm">
                            <div class="card-header bg-light p-3">
                                <h5>Subjects Information</h5>
                            </div>
                            <div class="card-body">
                      <?php //echo $comb->comb_id;  ?>
                      <?php //echo $comb->comb_name;  ?>          
                            </div>
                        </div></div> -->
        </div>
    

                 <!-- ================= -->
                 </div>
         <div class="modal-footer d-flex justify-content-center">
            <div class="align-items-center">
           <button type="button" class="btn btn-danger btn-sm Removegrade" data-grade_id="<?=$grade->grade_id;?>"><i class="fa fa-trash"></i> Delete</button>
            </div> 
        </div>
      </div>
      
    </div>
  </div>
  <!-- ==============end of combination view model==== -->
            

							<?php
							$i++;
							}
							
							?>
							 </tbody>
                            
                        </table>
                    </div>
                    <script>

  $(document).ready(function () {
    $('.EditGrade').click(function (e) {
        e.preventDefault();
        
        if (typeof $('#EditGradeView').modal === 'function') {
            $('#EditGradeView').modal('show');
        } else {
            console.error("Modal function not found!");
            return;
        }

        $('#gradeupdateMsg').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
        var data = $(this).attr('data-target');

        $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/view_grade_updateform'; ?>',
            data: { data: data },
            success: function (res) {
                $('#gradeupdateform').html(res);
                $('#gradeupdateMsg').html('');
            },
            error: function () {
                $('#gradeupdateMsg').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
            }
        });
    });
});


$(document).on('submit', '.editgrade-form', function(e) {
    e.preventDefault();

    const form = this;
    if (!form.checkValidity()) {
        form.classList.add("was-validated");
        return;
    }

        var uppergrade = $('#highgrade').val();
        var lowergrade = $('#lowgrade').val();
 if(uppergrade==lowergrade || uppergrade<lowergrade){
  $('#GradeValueError').html('<span class="text-danger">Grade Highest Mark must be not less than or equal to Grade Lowest Mark!</span>');
    $('#highgrade').css('border', '1px solid red');
    $('#lowgrade').css('border', '1px solid red');
 }else{
    $.ajax({
        type: "POST",
        url: "<?= base_url('/update_grade') ?>",
        data: $(form).serialize(),
        success: function (data) {
              $('#GradeValueError').html('');
          $('#updatedstatus').html('<div class="alert alert-success"><strong>Success!</strong> Grade updated Successfully.</div>')
                .stop(true, true)
                .show()
                .delay(3000)
                .fadeOut();
                $("html, body").animate({ scrollTop: 0 }, "slow");
               
                setTimeout(function () {
                    window.location.reload();
                }, 4000);
           
      
        },
        error: function () {
            $('#GradeValueError').html('');
            $('#updatedstatus').html('<div class="alert alert-danger"><strong>Failed!</strong> Failed to update a grade.</div>')
                .stop(true, true)
                .show()
                .delay(3000)
                .fadeOut();
                $("html, body").animate({ scrollTop: 0 }, "slow");
        }
    });
}
});

                         $(".Removegrade").click(function(){
        var id = $(this).attr('data-grade_id');
           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this Subject!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
           confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/remove_grade')?>/'+id,
                 error: function() {
                    swal('Something went wrong!!');
                 },
               success: function(data) {
            
                swal("Deleted successfuly"); 
                setTimeout(function(){
                    window.location.reload();
                },1000);
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
                    </script>