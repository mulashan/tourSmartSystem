<div class="box box-default">
    <div class="box-header">
    </div>

    <div class="panel-body">
        <div class="nav-tabs-custom tab-primary">
            <div class="d-flex justify-content-between align-items-center"></div>
            <br>

            <div class="row">
                <!-- Combination Info -->
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-header bg-light p-3">
                            <h5>Combination Information</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-borderless">
                                <tr>
                                    <th>COMBINATION NAME:</th>
                                    <td><?= $comb->comb_name; ?></td>
                                </tr>
                                <tr>
                                    <th>COMBINATION STATUS:</th>
                                    <td>
                                        <?php if ($comb->comb_status == 1): ?>
                                            <strong><span class="text-success">Active</span></strong>
                                        <?php else: ?>
                                            <strong><span class="text-danger">Inactive</span></strong>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>NUMBER OF SUBJECTS:</th>
                                    <td><?= count(explode(',', $comb->subjects)) ?></td>
                                </tr>
                                <tr>
                                    <th>CREATED BY:</th>
                                    <td><?= $comb->first_name . ' ' . $comb->last_name; ?></td>
                                </tr>
                                <tr>
                                    <th>CREATED ON:</th>
                                    <td><?= $comb->created_on; ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Subjects Info -->
                <div class="col-md-6">
          
 
                    <div class="card shadow-sm">
                      
                        <div class="card-header bg-light p-3">
                            <h5>Other Details</h5>
                        </div>

                        <div class="card-body">
                             <div class="row">
                              <div class="col-md-6">
                            <?php if (!empty($comb->subjects)): ?>
                                <ol class="list-group">
                                    <li class="list-group-item list-group-item-dark">Subjects</li>
                                    <?php foreach (explode(',', $comb->subjects) as $subj): ?>
                                        <li class="list-group-item"><i class="fa fa-square text-success"></i> <?= trim($subj); ?></li>
                                    <?php endforeach; ?>
                                </ol>
                            <?php else: ?>
                                   <ul class="list-group">
                                <li class="list-group-item">No subjects found for this combination.</li>
                            </ul>/
                            <?php endif; ?>
                    </div>
                      <div class="col-md-6">
                            <?php if(!empty($comb_allocation)):?>
                                  <ol class="list-group">
                                    <li class="list-group-item list-group-item-dark">Allocation Status</li>
                                    <?php foreach ($comb_allocation as $allocation): ?>
                                        <li class="list-group-item"><i class="fa fa-check text-success"></i> <?= $allocation->class_name;?> (<?= $allocation->stream_name;?>)</li>
                                    <?php endforeach; ?>
                                </ol>
                            <?php else: ?>
                                 <ul class="list-group">
                                    <li class="list-group-item list-group-item-dark text-center">Allocation Status</li>
                                <li class="list-group-item">This combination is not allocated to any class.</li>
                            </ul>
                            <?php endif; ?>
                        </div>
                        </div>
                    </div>
                    </div>
            
            </div>
            </div>
        </div>
        <hr>
        <div class="panel-footer d-flex justify-content-center">
            <div class="align-items-center">
                <button type="button" class="btn btn-danger btn-sm Removecomb" data-comb_id="<?= $comb->comb_id ?>">
                    <i class="fa fa-trash"></i> Delete
                </button>
            </div>
        </div>
    </div>
</div>

<script>
                          $(".Removecomb").click(function(){
        var id = $(this).attr('data-comb_id');
           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this Combination details!",
            customClass: 'swal-wide',
            showCancelButton: true,
           confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/remove_comb')?>/'+id,
                 error: function() {
                    swal('Something went wrong!!');
                 },
               success: function(data) {
            
                swal({  title: "Deleted",
            text: "The Combination delete successfuly!",
            customClass: 'swal-wide',
        height:'200px'}
                    ); 
                setTimeout(function(){
                    window.location.reload();
                },1000);
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
</script>
