
<div class="box box-default">
    <div class="box-header">
    </div>
    <div class="panel-body">
        <div class="nav-tabs-custom tab-primary">
        <div class="d-flex justify-content-between align-items-center ">

    </div><br>
                <div class="row">
                  <?php   foreach($read_all as $all){?>
                    <!-- ==modal row start==-->
                    <div class="col-md-6">
                        <!-- ==Taecher info== -->
                        <div class="card shadow-sm">
                            <div class="card-header bg-light p-3">
                                <h5>Stream General Details</h5>
                            </div>
                            <div class="card-body">

       <table class="table table-borderless">
                    
                    <tr>
                        <th>Class Level:</th>
                        <td > <?php echo $all->level_name;?>
                                     </td>
                    </tr>
              
  
                    <tr>
                        <th>Class Name:</th>
                        <td> <?php echo $all->class_name; 
                                     ?></td>
                    </tr>
                        <tr>
                        <th>Stream Name:</th>
                        <td> <?php echo $all->stream_name; 
                                     ?></td>
                    </tr>
                        <tr>
                        <th>Allocated Combination:</th>
                        <td> <?php echo $all->comb_name; 
                                     ?></td>
                    </tr>
                    <tr>
                        <th>Allocated By:</th>
                        <td>
            <?php echo $all->first_name;?>
                                     
             <?php echo $all->last_name;?>

                        </td>
                    </tr>
                    <tr>
                        <th>Allocated On:
                        </th>
                        <td> <?php echo $all->created_on;?></td>
                    </tr>
                </table>
                               </div>
                           </div>
                           <!-- ==Taecher info== -->
                       </div>
                        <!-- ==modal row End==-->
                        <?php
                    }?>
                   </div>
</div>
</div>
  <div class="panel-footer d-flex justify-content-center">
    <div class="align-items-center">
   <button type="button" class="btn btn-danger btn-sm Deleteallocation" data-allocation_id="<?=$all->st_id?>"><i class="fa fa-trash"></i> Delete</button>
         </div>
</div> 
</div>
<script type="text/javascript">
$(document).ready(function() {
    $(".Deleteallocation").click(function() {
        var id = $(this).attr('data-allocation_id');
        Swal.fire({
            title: "You are about to delete this allocation?",
            text: "You will not be able to recover this Subject!",
            icon: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!"
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '<?= base_url('/delete_stream_allocation')?>/' + id,
                    type: "GET",
                    error: function(xhr) {
                        console.log(xhr.responseText);
                        Swal.fire('Something went wrong!!');
                    },
                    success: function(data) {
                        Swal.fire("Deleted successfully");
                        setTimeout(function() {
                            window.location.reload();
                        }, 1000);
                    }
                });
            } else {
                Swal.fire("Cancelled");
            }
        });
    });
});

</script>