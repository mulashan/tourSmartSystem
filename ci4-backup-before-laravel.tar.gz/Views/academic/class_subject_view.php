          <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
 ?>
           <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Subjects Allocations</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Subjects Allocation</li>
                </ol>
            </div>
                        <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#sub_details"> Class Subjects List</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#results"> New Class Subjects</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#sub_details"></a>
                Class Subjects List</li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#results">New Class Subjects</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
         </div>
         
          <!----------------------------------------------------another code here----------------->
          <!-- ========================================New Format starts========================== -->

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active">
                <div class="card">
                  <div class="card-body">

        
        <!-- ==========================results start =================-->
     <div class="tab-content mt-3">
                    <div class="tab-pane fade show active" id="sub_details">
                 
                            <div class="">
                              
                             
            <!-- ===================================filter=============== -->
             <div class="content-wrapper">
    <section class="content">
    
                      <h6 class="card-title"> Class Subjects List</h6>
            <hr>
          
                <div class="d-flex justify-content-center">
                    <form id="Rept1Result" class="form-inline" novalidate>
                   
                        
                        <div class="me-3">
                            Class Level: 
                            <select class="form-control subject-select" name="classlevel" id="classlevel"style="width: 150px;" required>
                                <option value="">--Select Level--</option>
                                <?php
                               $l = $remodel->get_levels();
                              foreach($l as $le){
                               echo '<option value="' . $le->id . '">' . $le->level_name . '</option>'; 
                              }

                               ?>
                            </select>
                             <div class="invalid-feedback">Class Level is required.</div>
                        </div>

                         <div class="me-3">
                             Class: 
                            <select class="form-control subject-select" name="class" id="class" style="width: 150px;" required>
                                <option value="" class="">--Require Level--</option>
                           
                            </select>
                            <div class="invalid-feedback">Class is required.</div>
                            <div id="allocatedclass"></div>
                         </div>
                         <div class="me-3">
                        Stream:
                                
                                    <select id="stream" name="stream" class="subject-select form-control" style="width: 150px;"  required>
                                        <option value="">--Select Class first--</option>
                                       
                                    </select>
                                     <div class="invalid-feedback">Stream is required.</div>
                                     
                                     <div id="allocatedstream"></div>
                                </div>
                      
                         
   <div class="row mt-3">
    <div class="col-12 text-center">
        <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Create</button>  
    </div>
</div>

                          
                      
                     </form>

                </div>
           
               
                &nbsp;<p></p>
                <center>
                    <div id="waitingallocation"></div>
                    <div id="Rept1ResultViewResults"></div>
                </center>
           
        
       
   
<!----------------------------------------------------another code here----------------->
</div>
            <!-- ===================================filter=============== -->
                    
                               
                            </div>
                      
                    </div>

                    <div class="tab-pane fade" id="results">
                        <div class="row justify-content-center">
                                      <h6 class="card-title">New Class Subjects</h6>
                            <hr>
                           <div class="">
                     
                                 
                                    <div id="AllocationAdd"></div>
                                    
                          
                                <form id="allocate" class="needs-validation" method="POST" novalidate>
                         <div class="form-group row mb-3">
                                <label class="col-md-2 col-form-label">Class Level<span class="text-danger">*</span></label>
                                        <div class="col-md-4">
                                    <select name="classlev" id="classlev" class="form-control subject-select" style="width: 200px;" required >
                                        <option value="" selected disabled>--Select Level--</option>
                                        <?php foreach ($clevel as $c): 
                                        ?>
                                        <option value="<?= $c->id ?>"><?= $c->level_name.' ' ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="invalid-feedback">Class level is required.</div>
                                </div>
                                   <label for="class1" class="col-md-2 col-form-label">Class<span class="text-danger">*</span></label>
                                <div class="col-md-4">
                                    <select id="class1" name="class1" class="form-select me-4 subject-select form-control form-control-sm" style="width: 200px;"  required>
                                        <option value="">--Select Class Level first--</option>
                                       
                                    </select>
                                    <div id="allocateclass"></div>
                                     <div class="invalid-feedback">Class is required.</div>
                                </div>
                            </div>
                             <div class="form-group row mb-3">
                               <label for="stream1" class="col-md-2 col-form-label">Stream<span class="text-danger">*</span></label>
                                <div class="col-md-4">
                                    <select id="stream1" name="stream1" class="form-select me-4 subject-select form-control form-control-sm" style="width: 200px;"  required>
                                        <option value="">--Select Class first--</option>
                                       
                                    </select>
                                     <div class="invalid-feedback">Stream is required.</div>
                                     <div id="allocatestream"></div>
                                     <div class="mt-4" id="StatusMsg"></div>
                                     <div class="mt-4" id="StreamStatus"></div>
                                     <div class="mt-4" id="StreamStatusAbsent"></div>
                                </div>
                                 <label for="comb" class="col-md-2 col-form-label">Combination<span class="text-danger">*</span></label>
                                    <div class="col-md-4">
                                    <select id="comb" name="comb" class="form-select me-4 subject-select form-control form-control-sm" style="width: 200px;"  required>
                                        <option value="">--Select Combination--</option>
                                     <?php
                                     if (isset($combs)) {       
                                    foreach($combs as $comb){
                                                 ?>
                                       <option value="<?=$comb->comb_id;?>"><?=$comb->comb_name;?></option>          
                                       <?php
                                   }
                               }
                                       ?>
                                    </select>
                                     <div class="invalid-feedback">Comb is required.</div>
                                     <div class="mt-2" id="ViewSubjects"></div>
                                </div>
                            </div>
                          
                   <div class="d-flex justify-content-end mt-2 mb-3">
                      <button type="submit" name="submit" id="allocatetbn" class="btn btn-primary"><i class="fa fa-plus me-2"></i>Create</button>
                  </div>

                        </form>
                            
                            
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
               
        <!-- =========================results end================== -->
  </div>

    
   
                </div>
             
            </div>
  
          
            <!-- =====================end of edit modal==== -->
        </div>
    </div>
</div>
          <!-- ========================================New Format Ends========================== -->

</div>

  

<script type="text/javascript">
   $("#classlevel").change(function(){
        var clvl = $(this).val(); 
   
                $('#allocatedclass').html('<span class="fa fa-spinner fa-spin"></span> Loading.....');
         
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
                beforeSend: function()
               {
           $('#allocatedclass').html('<span class="fa fa-spinner fa-spin"></span> Loading.....');
                 },
            success:function(response){
                  $('#allocatedclass').html('');
                var len = response.length;
                  $("#stream").empty();
                  $("#stream").append('<option value="">--Select Class first--</option>');
                $("#class").empty();
                $("#class").append("<option value=''>--Choose Class--</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#class").append("<option value='"+id+"'>"+name+"</option>");
                }
                 $('#allocatedclass').html('');
            }
        });
    });

        $("#class").change(function(){
        var clvl = $(this).val(); 
         $('#allocatedstream').html('<span class="fa fa-spinner fa-spin"></span> Loading.....');
        $.ajax({
             url: '<?php echo base_url() . '/Get_stream_list'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
                beforeSend: function()
               {
          $('#allocatedstream').html('<span class="fa fa-spinner fa-spin"></span> Loading.....');
                 },
            success:function(response){
                 $('#allocatedstream').html('');
                var len = response.length;
                $("#stream").empty();
                $("#stream").append("<option value=''>--Choose Stream--</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['sname'];
                    $("#stream").append("<option value='"+id+"'>"+name+"</option>");;
                }
                 $('#allocatedstream').html('');
            }
        });
    });
     $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });
   $('#Rept1Result').submit(function (e) {
            $(this).serialize();
       e.preventDefault();
    if (!this.checkValidity()) {
        this.classList.add("was-validated");
        return;
             }
            
            $('#waitingallocation').html('<span class="fa fa-spinner fa-spin"></span> Allocation is Loading.....');
            var dta = "class=" + $('#class option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&year="+$('#year option:selected').val()+ "&status="+$('#status option:selected').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/allocation_details'; ?>',
                data: dta,
                beforeSend: function()
               {
                $('#waitingallocation').html('<span class="fa fa-spinner fa-spin"></span> Allocation is Loading.....');
                 },
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                     $('#waitingallocation').html('');
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
   // ==================class level=====================
  $("#classlev").change(function(){
        var InputOption = '';
          $('#allocateclass').html('<span class="fa fa-spinner fa-spin"></span> Loading.....');
        var clvl = $(this).val();   
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
                  beforeSend: function()
            {
               $('#allocateclass').html('<span class="fa fa-spinner fa-spin"></span> Loading.....');
            },
            success:function(response){
                  $('#allocateclass').html('');
                var len = response.length;
                  $("#stream1").empty();
                $("#stream1").append(' <option value="">--Select Class first--</option>');
                $("#class1").empty();
                $("#class1").append("<option value=''>-Choose Class-</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    var total = response[i]['total'];
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+''+"\xa0"+''+"</option>";
                    $("#class1").append(InputOption);;
                }
                  $('#allocateclass').html('');
            }
        });
    });
   $("#class1").change(function(){
        var InputOption = '';
        var clvl = $(this).val(); 
          $('#allocatestream').html('<span class="fa fa-spinner fa-spin"></span> Loading.....');  
        $.ajax({
            url: '<?php echo base_url() . '/Get_stream_list'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
                beforeSend: function()
            {
              $('#allocatestream').html('<span class="fa fa-spinner fa-spin"></span> Loading.....');  
            },
            success:function(response){
                 $('#allocatestream').html('');  
                $('#StreamStatus').html('');
                  $('#StreamStatusAbsent').html('');
                var len = response.length;
                $("#stream1").empty('');
                $("#stream1").append("<option value=''>-Choose Stream-</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['sname'];
                    var total = response[i]['total'];
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+''+"\xa0"+''+"</option>";
                    $("#stream1").append(InputOption);
                    
                }
               $('#allocatestream').html('');  
            }
        });
    });


   $(document).ready(function() {
        $(".subject-select").select2();
    });

       $("#comb").change(function() {
      var data= 'ids=' + $('#comb option:selected').val();
      //alert(data);
        $.ajax({
            type: "get",
            url: "<?= base_url('/ViewCombSubjects')?>",
            data: data,
            beforeSend: function()
            {
                $('#ViewSubjects').html('<span class="fa fa-spinner fa-spin"></span> Subjects Loading.....');
            },
            success: function(res){
                $('#ViewSubjects').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
         $('#allocate').submit(function(e){
     $(this).serialize();
       e.preventDefault();
    if (!this.checkValidity()) {
        this.classList.add("was-validated");
        return;
             }
        $.ajax({
            type: "POST",
            url: "<?= base_url('/Save_class_allocation') ?>",
            data: $(this).serialize(),
            success: function (data) {
                $('#AllocationAdd').html(data);
                $('#allocate')[0].reset();
                setTimeout(function(){
                   window.location.reload();
                 },1500);
            },
            error: function () {
                $('#fdbkarea').html('Sorry! Something went wrong.');
            }
        });
        e.preventDefault();
    });


            $("#stream1").change(function(){
     $('#StatusMsg').html('<span class="fa fa-spinner fa-spin"></span> Checking stream allocation status..');
            var data1 = "class=" + $('#class1 option:selected').val()+ "&classlevel="+$('#classlev option:selected').val()+ "&stream="+$('#stream1 option:selected').val();
       
        $.ajax({
            url: '<?php echo base_url() . '/Check_stream_alocation_status'; ?>',
            type: 'post',
            data:data1,
            dataType: 'json',
                beforeSend: function()
            { $('#StreamStatus').html('');
                  $('#StreamStatusAbsent').html('');
                $('#StatusMsg').html('<span class="fa fa-spinner fa-spin"></span> Checking stream allocation status..');
            },
            success:function(response){
                var exists = response.AllocationStatus;
                if(exists==1){
                     var combName = response.CombinationName;
           $('#StatusMsg').html('');
           $('#StreamStatusAbsent').html('');
            $('#StreamStatus').html('<div class="alert alert-warning text-center"><b><i class="fa fa-warning fa-2x text-danger"></i><br></b>The selected stream is already allocated to ' +combName+'  combinantion.!!</div>');
         $('#allocatetbn').prop('disabled', true);
                }else{
         $('#StatusMsg').html('');
          $('#StreamStatus').html('');
          $('#StreamStatusAbsent').html('<div class="alert alert-success text-center"><b><i class="fa fa-check fa-2x"></i>The selected stream not allocated to any combination <br></b> Now you can select a combination</div>');
           $('#allocatetbn').prop('disabled', false); 
                }

            
            }
        });
    });

   
  </script>