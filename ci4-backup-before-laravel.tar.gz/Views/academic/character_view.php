<!-- By chanangwa E, -->
<style>
.modal-dialog1 {
          max-width: 900px; /* New width for default modal */
		   background: #ccc;
		   max-height: 500px;
		   
        }
		
.modal-content {
    background: white;
  }
font-family: 'Varela Round', sans-serif;
}
.modal-confirm {		
	color: #636363;
	width: 600px;
}
input{
	width:14px:
}
.modal-confirm .modal-content {
	padding: 20px;
	border-radius: 5px;
	border: none;
	text-align: center;
	font-size: 14px;
}
.modal-confirm .modal-header {
	border-bottom: none;   
	position: relative;
}
.modal-confirm h4 {
	text-align: center;
	font-size: 26px;
	margin: 30px 0 -10px;
}
.modal-confirm .close {
	position: absolute;
	top: -5px;
	right: -2px;
}
.modal-confirm .modal-body {
	color: #999;
}
.modal-confirm .modal-footer {
	border: none;
	text-align: center;		
	border-radius: 5px;
	font-size: 13px;
	padding: 10px 15px 25px;
}
.modal-confirm .modal-footer a {
	color: #999;
}		
.modal-confirm .icon-box {
	width: 80px;
	height: 80px;
	margin: 0 auto;
	border-radius: 50%;
	z-index: 9;
	text-align: center;
	border: 3px solid #f15e5e;
}
.modal-confirm .icon-box i {
	color: #f15e5e;
	font-size: 46px;
	display: inline-block;
	margin-top: 13px;
}
.modal-confirm .btn, .modal-confirm .btn:active {
	color: #fff;
	border-radius: 4px;
	background: #60c7c1;
	text-decoration: none;
	transition: all 0.4s;
	line-height: normal;
	min-width: 120px;
	border: none;
	min-height: 40px;
	border-radius: 3px;
	margin: 0 5px;
}
.modal-confirm .btn-secondary {
	background: #c1c1c1;
}
.modal-confirm .btn-secondary:hover, .modal-confirm .btn-secondary:focus {
	background: #a8a8a8;
}
.modal-confirm .btn-danger {
	background: #f15e5e;
}
.modal-confirm .btn-danger:hover, .modal-confirm .btn-danger:focus {
	background: #ee3535;
}
.trigger-btn {
	display: inline-block;
	margin: 100px auto;
}
p{
	text-weight:20px;
	font-size:16pt;
}
</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Student Characters</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Student Characters</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#charact-all"> Characters List</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#chara-add"> New Character</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#charact-all"></a>
                Subjects List</li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#users-add">New character</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="charact-all">
                <div class="card">
		   <p class="">
            <?php
			if(session()->getFlashdata('msg')){
            echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span>'.session()->get('msg').'</div> ';
			
			}
			if(session()->getFlashdata('error')){
			echo '<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span>'.session()->get('error').'</div> ';
			}
            ?>
        </p>
       <div class="table-responsive mt-3">
           <table class="table table-hover table-vcenter  mb-0 text-nowrap"   id="myTable">

                            <thead>
                                <tr>
                                    <th>No.#</th>
                                    <th>Character Name</th>
                                    <th>character code</th>
                                    <th>Status</th>
                                    <th>Created By</th>
                                    <th>Created Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
							<tbody>
							<?php
							$i=1;
							foreach($characters
                             as $chara){
								?>
								  <!--MODAL FOR DELETING THE subject-->
								
								<tr>
								<td> <?php echo $i;?></td>
								<td > <?php echo $chara->character_name;?></td>
                             <td >          
                            <?php echo$chara->character_code;?>
                                 </td>                

                      <td >          
                   <?php if($chara->character_status==1):?>
                   <strong> <span class="text-success"> Active</span></strong>
                    
                    <?php else:?>
                   
                    <strong> <span class="text-danger"> Inactive</span>  </strong>
                    <?php
                  endif;
                  ?>  
              </td>
               <td> <?php echo $chara->first_name; ?>
                <?php echo $chara->last_name;?>   
               </td>
               <td> <?php echo $chara->create_date;?></td>

                               
								<td>
			 <a href="#" data-toggle="modal"  data-target="#iedit<?=$chara->character_id;?>" class="text-light btn btn-xs btn-flat btn-primary"><i class="fa fa-edit"></i> Edit</a>
                 <a href="#" data-toggle="modal"  data-target="<?=$chara->character_id;?>" class="CharacterView text-light btn btn-xs btn-flat btn-primary"><i class="fa fa-eye"></i> View</a>		
								 
						       </td>
								</tr>
                           
          <!-- =================edit modal============ -->
            <!-- Modal -->
  <div class="modal fade" id="iedit<?php echo $chara->character_id;?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formEditPelanggan" aria-hidden="true">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Edit Character</h5>
          <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
         <form name="" action="<?= base_url('/update_character') ?>" method="post">
    <input type="hidden" name="character_id" value="<?= $chara->character_id; ?>">

    <label>Character Name:</label>
    <input type="text" name="charactername" value="<?= $chara->character_name; ?>" class="form-control">
<label>Character Code:</label>
    <input type="text"name="charactercode" id="charactercode" value="<?= $chara->character_code; ?>" class="form-control">
        
    <label>Character Status:</label>
    <select name="characterstatus" class="form-control">
        <option value="1" <?= $chara->character_status == 1 ? 'selected' : ''; ?>>Active</option>
        <option value="2" <?= $chara->character_status == 2 ? 'selected' : ''; ?>>Inactive</option>
    </select>

    <button type="submit" class="btn btn-success mt-3">Update</button>
</form>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
            <!-- =====================end of edit modal==== -->

  <!-- ==============end of character view model==== -->

							<?php
							$i++;
							}
							
							?>
							 </tbody>
                            
                        </table>
                    </div>
                </div>
             <!-- =====================Character view modal==== -->
<div class="modal fade" id="CharacterViewModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formEditPelanggan" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel"> Character Details</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
      <div id="CharacterViewMsg"></div>
      <div id="CharacterViewform"></div>
   

        </div>
        
      </div>
      
    </div>
  </div>
  <!-- ==============end of Characterination view model==== -->
            </div>
  <div class="tab-pane" id="chara-add">
       <div class="row clearfix">
		<div id="CharactAdd"></div>
             <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header" style="height:5px">
                               <h3 class="card-title">Add New Character</h3>
                                <div class="card-options">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                            <hr>
<div class="card-body">
    <div class="row">
      <div class="col-md-12">
        <form id="saveCharact">
            <div class="row mb-3">
             <label for="charactername" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Character Name<span class="text-danger">*</span></label>
                  <div class="col-sm-3">
                    <input type="text" class="form-control form-control-sm" id="charactername" name="charactername" placeholder="eg: Displine">
                                                </div>
                    
                                            </div>
   <div class="row mb-3">
             <label for="charactercode" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Character Code<span class="text-danger">*</span></label>
                         <div class="col-sm-3">
         <input type="text" class="form-control form-control-sm" id="charactercode" name="charactercode" placeholder="eg: 109">               </div> 
                            
                                            </div>
                             <div class="d-flex justify-content-end mt-2 mb-3">
                                                <button type="submit" class="btn btn-primary"><i class="fa fa-plus me-2"></i>Create</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
          
            <!-- =====================end of edit modal==== -->
        </div>
    </div>
</div>
<script type="text/javascript">
    $('#saveCharact').submit(function(e){
      // alert($(this).serialize());
        $.ajax({
            type: "POST",
            url: "<?= base_url('/save_character') ?>",
            data: $(this).serialize(),
            success: function (data) {
                $('#CharactAdd').html(data);
                $('#saveCharact')[0].reset();
                setTimeout(function(){
                    window.location.reload();
                },2000);
            },
            error: function () {
                $('#fdbkarea').html('Sorry! Something went wrong.');

            }
        });
        e.preventDefault();
    });

       $('.CharacterView').click(function (e) {
        e.preventDefault();
               $('#CharacterViewModal').modal('show');
            $('#CharacterViewform').html('<span class="fa fa-spinner fa-spin"></span> Loading Characterination data....');
            var data = $(this).attr('data-target');
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/view_Character_details'; ?>',
                data: {Character_id:data},
                success: function (res) {
                    $('#CharacterViewform').html(res);
                 
                },
                error: function () {
                    $('#CharacterViewform').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

        
    });
</script>
