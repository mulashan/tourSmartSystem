<!-- By chanangwa E, -->
<style>
.modal-dialog1 {
          max-width: 900px; /* New width for default modal */
		   background: #ccc;
		   max-height: 500px;
		   
        }
		
.modal-content {
    background: white;
  }
font-family: 'Varela Round', sans-serif;
}
.modal-confirm {		
	color: #636363;
	width: 600px;
}
input{
	width:14px:
}
.modal-confirm .modal-content {
	padding: 20px;
	border-radius: 5px;
	border: none;
	text-align: center;
	font-size: 14px;
}
.modal-confirm .modal-header {
	border-bottom: none;   
	position: relative;
}
.modal-confirm h4 {
	text-align: center;
	font-size: 26px;
	margin: 30px 0 -10px;
}
.modal-confirm .close {
	position: absolute;
	top: -5px;
	right: -2px;
}
.modal-confirm .modal-body {
	color: #999;
}
.modal-confirm .modal-footer {
	border: none;
	text-align: center;		
	border-radius: 5px;
	font-size: 13px;
	padding: 10px 15px 25px;
}
.modal-confirm .modal-footer a {
	color: #999;
}		
.modal-confirm .icon-box {
	width: 80px;
	height: 80px;
	margin: 0 auto;
	border-radius: 50%;
	z-index: 9;
	text-align: center;
	border: 3px solid #f15e5e;
}
.modal-confirm .icon-box i {
	color: #f15e5e;
	font-size: 46px;
	display: inline-block;
	margin-top: 13px;
}
.modal-confirm .btn, .modal-confirm .btn:active {
	color: #fff;
	border-radius: 4px;
	background: #60c7c1;
	text-decoration: none;
	transition: all 0.4s;
	line-height: normal;
	min-width: 120px;
	border: none;
	min-height: 40px;
	border-radius: 3px;
	margin: 0 5px;
}
.modal-confirm .btn-secondary {
	background: #c1c1c1;
}
.modal-confirm .btn-secondary:hover, .modal-confirm .btn-secondary:focus {
	background: #a8a8a8;
}
.modal-confirm .btn-danger {
	background: #f15e5e;
}
.modal-confirm .btn-danger:hover, .modal-confirm .btn-danger:focus {
	background: #ee3535;
}
.trigger-btn {
	display: inline-block;
	margin: 100px auto;
}
p{
	text-weight:20px;
	font-size:16pt;
}
</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Combinations</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Combinations</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#comb-all">Combinations List</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#comb-add">New Combination</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#comb-all">Combinations List</a>
               </li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#comb-add">New combination</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="comb-all">
                <div class="card">
		   <p class="">
            <?php
			if(session()->getFlashdata('msg')){
            echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="fa fa-check"></span>'.session()->get('msg').'</div> ';
			
			}
			if(session()->getFlashdata('error')){
			echo '<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="fa fa-cross"></span>'.session()->get('error').'</div> ';
			}
            ?>
        </p>
          <div class="tab-pane active" id="adm-add">
               <div class="d-flex justify-content-center">
                    <form id="getCombTable" class="form-inline" class="needs-validation" novalidate>
                     <div class="me-3">
                            Class Level: 
                        <select name="Clevel" id="Clevel" class="form-control form-control-lg teacher-select" required >
                                        <option value="0">All</option>
                                        <?php if(isset($classlevel)):?>
                                        <?php foreach ($classlevel as $level):
                                        ?>
                                        <option value="<?= $level->id ?>"><?= $level->level_name.' ' ?></option>
                                        <?php endforeach; 
                                    endif;
                                        ?>
                                    </select>
                                        <div class="invalid-feedback">Please Select Class Level.</div>
                        </div>
                     <button type="submit" class="btn btn-primary"> Create</button>
                        </form>
                        </div>
                        <hr>
                &nbsp;  
            </div>
<div class="me-4" id="WaitingMsg"></div>
<div class="me-4" id="combtable"></div>
                </div>
             
            </div>
  <div class="tab-pane" id="comb-add">
       <div class="row clearfix">
		<div id="Combadd"></div>
             <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header" style="height:5px">
                               <h3 class="card-title"> New Combination</h3>
                                <div class="card-options">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                            <hr>
<div class="card-body">
    <div class="row">
      <div class="col-md-12">
        <form id="saveComb" class="needs-validation" novalidate>
            <div class="row mb-3">
             <label for="combname" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Combination Name<span class="text-danger">*</span></label>
                  <div class="col-sm-3">
                    <input type="text" class="form-control form-control-sm" id="combname" name="combname" placeholder="eg: Science" required>
                      <div class="invalid-feedback">Comination Name required.</div>
                                                </div>
                    
                                            </div>
   <div class="row mb-3">
            <label for="classlevel" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Class Level<span class="text-danger">*</span></label>
            <div class="col-sm-3">
                     <select name="classlevel" id="classlevel" class="form-control form-control-sm teacher-select" required >
                                        <option value="" selected disabled>---Select Level---</option>
                                        <?php if(isset($classlevel)):?>
                                        <?php foreach ($classlevel as $level):
                                        ?>
                                        <option value="<?= $level->id ?>"><?= $level->level_name.' ' ?></option>
                                        <?php endforeach; 
                                    endif;
                                        ?>
                                    </select>
                      <div class="invalid-feedback">Class Level is required.</div>
                                                </div>
</div>
                         <div class="row mb-3 mt-3">                   
            <!-- <div class="col-sm-6 ms-3 col-form-label col-form-label-sm"> -->


    <label for="combname" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Select Subjects <span class="text-danger">*</span></label>
    <div class="col-sm-3">
        <?php 
        if (isset($sub1)) {
            foreach ($sub1 as $sub) {
                echo '<div class="form-check">';
                echo '<input type="checkbox" class="form-check-input" name="sub_select[]" id="sub_rt" value="'.$sub->subject_id.'">';
                echo '<label class="form-check-label ms-2" for="sub_rt">'.$sub->subject_name.'</label>';
                echo '</div>';
            }
        }
        ?>
        <div id="emptysubjects"></div>
        
    </div>

       
</div>

                             <div class="d-flex justify-content-end mt-2 mb-3">
                                                <button type="submit" class="btn btn-primary"><i class="fa fa-plus me-2"></i>Create</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>



    
                         

      <!-- Modal to View All combination Information -->


<!-- =============view modal end======== -->

                        </div>
                    </div>
                </div>
            </div>
          
            <!-- =====================end of edit modal==== -->
        </div>
    </div>
</div>


<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>

<script type="text/javascript">


$('#saveComb').submit(function (e) {
    e.preventDefault();

    let subjectCount = $('input[name="sub_select[]"]:checked').length;

    if (!this.checkValidity() || subjectCount < 2) {
        this.classList.add("was-validated");

        if (subjectCount < 2) {
            $('#emptysubjects').html(
                '<span class="text-danger">Please select at least two subjects!</span>'
            );
        } else {
            $('#emptysubjects').html('');
        }

        return;
    }
    $('#emptysubjects').html('');
    $.ajax({
        type: "POST",
        url: "<?= base_url('/save_comb') ?>",
        data: $(this).serialize(),
        success: function (data) {
            if (data.status == 1) {
                $('#Combadd').html('<div class="alert alert-success"><strong>Success!</strong> New Combination added Successfully.</div>')
                   .stop(true, true)
                .show()
                .delay(3000)
                .fadeOut();
                $("html, body").animate({ scrollTop: 0 }, "slow");
                $('#saveComb')[0].reset();
                setTimeout(function () {
                    window.location.reload();
                }, 4000);
            } else if (data.status == 2) {
                $('#emptysubjects').html(
                    '<span class="text-danger">Please select at least one subject!</span>'
                );
            }else if(data.status == 3){
                   $('#Combadd').html('<div class="alert alert-danger"><strong>Failed!</strong> The combination you are trying to add to the selected class level already exists..</div>'); 
                    $("html, body").animate({ scrollTop: 0 }, "slow");
            }
        },
        error: function () {
            $('#fdbkarea').html('Sorry! Something went wrong.');
        }
    });
});


   
</script>
<script>
$(document).ready(function() {
    $('#sub1').select2({
        placeholder: "Select candidates",
        allowClear: true
    });
});
        $('#getCombTable').submit(function (e) {
            
            var dta = "Clevel=" + $('#Clevel option:selected').val();
                 if (!this.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
            this.classList.add("was-validated");
             }
             else{
        $('#WaitingMsg').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/GetCombTable'; ?>',

                data: dta,
                success: function (res) {
                    $('#combtable').html(res);
                     $('#WaitingMsg').html('');
                },
                error: function () {
                    $('#combtable').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                     $('#WaitingMsg').html('');
                }
            });


        e.preventDefault();
    }});
</script>

