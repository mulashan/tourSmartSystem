<style>
    .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }
</style>
<?php
    $student_model = new App\Models\StudentModel();
    $amodel = new App\Models\AdmissionModel();
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Teacher's Subject Allocation</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Teacher's Subject Allocation</li>
                </ol>
            </div>

            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="application-tab" data-toggle="tab" href="#list_allocation">Teacher's subject List</a></li>
                <li class="nav-item"><a class="nav-link" id="application-tab" data-toggle="tab" href="#add_allocation">New Teacher's Subjects</a></li>
                
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="application-tab" data-toggle="tab" href="#list_allocation">Teacher's subject List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="application-tab" data-toggle="tab" href="#add_allocation">New Teacher's Subjects</a></li>
                
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="list_allocation">

   <!--===================View Allocation=====================-->

              <div class="d-flex justify-content-center">
                 <div class="table-responsive mt-3">
           <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>No.#</th>
                                    <th>Name</th>
                                    <th>User Type</th>
                                    <th>Phone No.</th>
                                    <th>No. of Subjects</th>
                                    <th>Updated by</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                       if (isset($allocate)) {
                             $i=1;
                            foreach($allocate as $all){
                                ?>
                                <tr>
                                <td> <?php echo $i;?></td>
                                <td> <?php echo $all->first_name;?> <?=" "?><?php echo$all->last_name;?></td>
                                <td ><?php echo $all->type_name;?></td>  
                                <td ><?php echo $all->phone_no;?></td>  
                                <td class="text-center" ><b><?=$all->subject_count;?></b></td>  
                                  
                                                 <td>                  <?php
                 foreach($staffs as $staf){
                $cr=$all->allocated_by; 
                 $stf=$staf->user_id;
                if($cr==$stf){
                 echo $staf->first_name;?>
                    
                    <?php
                     echo $staf->last_name;
                 }
              
            }?></td> 
            <td ><?=$all->allocation_date;?></td>
                                  
                                <td> 
           <button type="button" class="btn btn-primary btn-sm AllocationID" data-id="<?= $all->allocation_id;?>"><i class="fa fa-edit"></i> Edit</button>     

                  <button class="btn btn-primary ViewID"  data-ids="<?php echo $all->teacher_id;?>" data-subjects="<?php echo $all->subject_count;?>" >
                    <i class="fa fa-eye"></i> View
                </button>
                               </td>
                                <?php
                            $i++;
                            }
                       }
                            ?>
                                </tr></tbody></table></div>
          
<!-- ============================================================================= -->
                </div>
                
                <hr>
               
         <!--------------------------------------------->
            </div>
            <div class="tab-pane" id="add_allocation">
                <div class="card">
                 <section class="wizard-section">
                    <div class="card-header" style="height:5px">
                        <h3 class="card-title">New Subject Allocation</h3>
                        <div class="card-options ">
                            <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                        </div>
                    </div>
                    <hr>
                    <div class="card-body">
                        <div id="applcnFDCK"></div>
                          <form id="allocate_teacher" class="needs-validation"  novalidate>
               <div class="row mb-2 col-md-5 ms-5 ms-5" id="name_loaded">

               </div>

  <!-- =============== class level========== -->
  <div class="row">
      <div class="col-md-6">
  <div class="row mb-4">
       <label class="col-md-2 col-form-label">Teacher<span class="text-danger">*</span></label>
                          <div class="col-md-4">
                       <select name="name_teacher" id="name_teacher" class="form-control teacher-select" style="width: 200px;"  required>
                         <option value="" selected disabled>--Select Teacher--</option>
                                        <?php foreach ($teacher as $teach): 
                                        ?>
                                    <option value="<?= $teach->user_id ?>"><?= $teach->first_name.' '." ".$teach->last_name.' '?></option>
                                        <?php endforeach; ?>
                                    </select>
                                     <div class="invalid-feedback">Teacher is required.</div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-md-2 col-form-label">Level<span class="text-danger">*</span></label>
                                <div class="col-md-4">
                                    <select name="classlevel" id="classlevel" class="form-control teacher-select" style="width: 200px;" required >
                                        <option value="" selected disabled>--Select Level--</option>
                                        <?php foreach ($clevel as $c): 
                                            $getRemainTotal = $amodel->remain_classLevel_capacity($c->id);
                                    
                                        ?>
                                        <option value="<?= $c->id ?>"><?= $c->level_name.' ' ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="invalid-feedback">Class level is required.</div>
                                </div>
                            </div>
                            <div class="row mb-4">

                                <label class="col-md-2 col-form-label">Class<span class="text-danger">*</span></label>
                                <div class="col-md-4">
                                    <select id="class" name="class" class="form-select me-4 teacher-select form-control form-control-sm" style="width: 200px;"  required>
                                        <option value="">--Select Class Level first--</option>
                                       
                                    </select>
                                     <div class="invalid-feedback">Class is required.</div>
                                </div>
                            </div>
                            <div class="row mb-4">

                                       <label for="streamoption" class="col-md-2 col-form-label">Stream<span class="text-danger">*</span></label>
                                <div class="col-md-4">
                                    <select id="streamoption" name="streamoption" class="teacher-select me-4 subject-select form-control form-control-sm" style="width: 200px;"  required>
                                        <option value="">--Select Class first--</option>
                                       
                                    </select>
                                     <div class="invalid-feedback">Stream is required.</div>
                                   
                                </div>
                            </div>
                         <div class="col-md-12">  <div id="emptysubjects"></div></div>
                            </div>
  
  </div>
</form>
   <hr>
    <div class="AllocationStatus">
        

        
    </div>
                            </div>
                          
                            <hr>
  <!-- =============== Teacher section========== -->
          </section>
                    
                  </div>
                    
                    </div>
                 </div>

<!-- =======================modal view================================== -->
<!-- View Modal -->
<div class="modal fade" id="viewModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Teacher Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="btn btn-danger">&times;</span>
                </button>
            </div>
            <div class="modal-body">
       <div id="ViewAllocation"></div>
            </div>
             <div class="modal-footer">
        </div>
        </div>
    </div>
</div>

<!-- Modal update -->
  <div id="UpdateModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content" style="width:105%">
        <div class="modal-header">
          <h5 class="modal-title" id="">Update Subject Allocation</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
       <div class="modal-body">
          <div id="UpdtAllocation"></div>
        </div>
        <div class="modal-footer">
        </div>
      </div>
      
    </div>
  </div>
<!-----End update modal--->
</div>
</div>
<div class="modal fade" id="EditApp" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel"><center>Edit Student Details</center></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="EditApp_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>
<!-----------------------pay aplication model------------------------------------------------>
<div class="modal fade" id="payApp" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <div class=" d-flex justify-content-center"><h5 class="modal-title" id="staticBackdropLabel"> Application form Payments</h5></div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="payApp_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>
<!----------------------print receipt model------------------->
<div class="modal fade" id="viewreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content">
      </div>
      <div class="modal-footer">

        <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('viewreceipt_content')">Print</button>

        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    // datePickerId.max = new Date().toISOString().split("T")[0];
    $(function () {
        var year = (new Date).getFullYear();
        var day = (new Date).getDate();
        var m = (new Date).getMonth();
        $('#datetimepicker1').datetimepicker({
            // format: 'Y/m/d',
            format:"YYYY-MM-DD",
            minDate: new Date(2007, 0, 1),
            maxDate: new Date(year, m, day)
        });
    });
    $(document).ready(function(){ 
    $(":input").inputmask();     
        // $("#bphone").inputmask({"mask": "(999) 999-9999"});
    });



  function allocate_teacher(){
    $.ajax({
        beforeSend: function () {
              //$('#add_application').prop("disabled", true);
              $('#applcnFDCK').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
        },
        url: 'allocate_teacher',
        type: 'POST',
        data: $('#allocate_teacher').serialize(),
        success: function (res) {
            var data = JSON.parse(res);
               $('#applcnFDCK').html('');
                Swal.fire({
                    title: data['status'], 
                    html: data['statusDesc'], 
                    icon: data['status']
                  }).then((result) => {
                  if (result.isConfirmed) {
                    if(data['status']=='error'){

                    }else{
                        location.reload();  
                    }
                  }
                });
                  setTimeout(function() {
    location.reload();
}, 1000)
              },     
        error: function () {
             $('#add_application').prop("disabled", false);
             $('#applcnFDCK').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
        }
    });
  }
  // ==================class level=====================
  $("#classlevel").change(function(){
        var InputOption = '';
        var clvl = $(this).val();   
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value=''>-Choose Class-</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    var total = response[i]['total'];
                    // if(total <= 0){
                    //     InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Room for New Student'+"</option>";
                    // }else{
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+''+"\xa0"+''+"</option>";
                    //}

                    $("#class").append(InputOption);;
                }
            }
        });
    });
          $("#class").change(function(){
        var clvl = $(this).val(); 
        $.ajax({
             url: '<?php echo base_url() . '/GetCombstreamDetails'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
                beforeSend: function()
               {
         
                $('#waitingClass').html('');
                 },
            success:function(response){
                var len = response.length;
                if(len==0){
  $("#streamoption").empty();
   $('.AllocationStatus').html('');
     $('#emptysubjects').html('<div class="alert alert-warning"><b class="text-danger">No Subject allocated to this class. </b> Please allocate subjects to this class then try again!!</div>');
                }else{
                $("#streamoption").empty();
                 $('#emptysubjects').html('');
                $("#streamoption").append("<option value=''>--Choose Stream--</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    var comb = response[i]['comb'];
                    $("#streamoption").append("<option value='"+id+"'>"+name+" ("+comb+") "+"</option>");;
                }
                 $('#waiting').html('');

            }}
        });
    });
  // =====================teacher to subject===================
    $("#teach_sub").change(function(){
        var InputOption = '';
        var clvl = $(this).val();   
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value=''>-Choose Class-</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    var total = response[i]['total'];
                    // if(total <= 0){
                    //     InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Room for New Student'+"</option>";
                    // }else{
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+''+"\xa0"+''+"</option>";
                    //}

                    $("#class").append(InputOption);;
                }
            }
        });
    });
// =======================teacher-subject======================
    function edit_application(id){
        
        $('#EditApp').modal('show'); 
        $('#EditApp_content').load('edit_application/'+id);
       
    }
       function pay_application(id){
        
        $('#payApp').modal('show'); 
         $('#payApp_content').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
        $('#payApp_content').load('pay_application/'+id);
       
    }
   function invoice_request(id,lvl){
       var data = 'id='+ id +'&lvl=' + lvl+'&'+$("#header_form").serialize();
       //alert(data);
        $.ajax({
            beforeSend: function () {
              $('#applcnFDCK').append('<div class="alert alert-primary alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button><i class="fa fa-spinner fa-spin"></i>Preparing Control Number Please wait..</div>');
            },
            type: "POST",
            url: 'request_control_number',
            data: data,
              success: function (res) {
               $('#applcnFDCK').html('');
               swal({
                    title: "successful", 
                    text: res, 
                    type: "success"
                  },
                function(){ 
                    location.reload();
                }
             );
            },
            error: function () {
                $('#applcnFDCK').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
            }
        });
    }

    function print_receipt(inv){
      $('#viewreceipt').modal('show');
      $('#viewreceipt_content').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>'); 
      $('#viewreceipt_content').load('print_receipt/'+inv);
    }

    function printable_rept(area) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=700, height=600, left=100, top=25";
        var content_vlue = document.getElementById(area).innerHTML;

        var docprint = window.open("", "", disp_setting);
        docprint.document.open();
        docprint.document.write('<html><head><title>MHI</title><link rel="stylesheet" href="<?php echo base_url() . 'syst_assets/'; ?>bootstrap/css/bootstrap.css">');
        $('#ReptHeader').load('<?php echo base_url() . 'index.php/Gp_ctrl/load_printable_header'; ?>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }

     $('#Rept1Result').submit(function (e) {
            
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Loading..');
            var dta = "class=" + $('#cls option:selected').val()+ "&status=" + $('#status option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
                //url: '<?php echo base_url() . '/staff_report'; ?>',
                url: '<?php echo base_url() . '../index.php/StudentController/selection_report'; ?>',
                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
     function check_sms(msgid){
                //alert(msgid);
            var data = "id=" + msgid;
              $.ajax({
            type: 'POST',
          url: '<?php echo base_url() . '/index.php/SystemController/check_sms/'; ?>'+msgid,
            data: data,
            success: function (res) {
            
              
            },
            error: function (){
                alert('error encounted');
            }
        });
            }
            $('#Rept1Result_app').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#Rept1Result_app').html('Please specify valid date.');
        } else {
            $('#application_area').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn span').html();
            //alert(dta);
            $.ajax({
                type: "POST",
                //url: '<?php echo base_url() . '/receipt2'; ?>',
             url: "<?php echo base_url() . '/index.php/StudentController/fetch_application'; ?>",
                data: dta,
                success: function (res) {
                    $('#application_area').html(res);
                },
                error: function () {
                    $('#application_area').html('<div class="alert alert-warning">Fail to retreive applications.!!</div>');
                }
            });

}
        e.preventDefault();
    });

             $(function () {
            var start = moment();
            var end = moment();
            function cb(start, end) {
                $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
            }
            $('#daterange-btn').daterangepicker({
                startDate: start,
                endDate: end,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                     'This Year': [moment().startOf('year'), moment().endOf('year')]
                }
            }, cb);
            cb(start, end);

     });
  function search_student(){
  var mydat = 'appname='+ $('#appname').val();
      // alert(mydat);
      // return;
  $.ajax({
    type: "POST",
    url: '<?php echo base_url() . '/index.php/SystemController/search_application'; ?>',
    data: mydat,
    success: function (res) {
        $('#name_loaded').html(res); 
},
error: function () {
   alert('Something went wrong');           
}
});

}
  function select_name(id,fullname){
  var mydat = 'id='+ id;
      // alert(mydat);
      // return;
  $.ajax({
    type: "POST",
    url: '<?php echo base_url() . '/index.php/SystemController/get_application_name'; ?>',
    data: mydat,
    success: function (res) {
          $('#name_loaded').html(''); 
       var data = JSON.parse(res);
       // alert(data.student[0]['first_name']);
       //   return; 
        //alert(data[0]['first_name']);  
       $('input[name=fname]').val(data.student[0]['first_name']);
       $('input[name=mname]').val(data.student[0]['middle_name']);
       $('input[name=lname]').val(data.student[0]['last_name']);
       $('input[name=dob]').val(data.student[0]['birth_date']);
        $('input[name=pfname]').val(data.parent[0]['first_name']);
        $('input[name=plname]').val(data.parent[0]['last_name']);
        $('input[name=bphone]').val(data.parent[0]['phone1']);
       if(data.student[0]['gender']=='Female'){
         document.getElementById("female").setAttribute("checked","true");
     }else{
        document.getElementById("male").setAttribute("checked","true");
    }
    var data ='<input type="hidden" name="student_id" value="'+ data.student[0]['student_id'] +'"><input type="hidden" name="classlevel2" value="'+ data.student[0]['level_id'] +'"><input type="hidden" name="class2" value="'+ data.student[0]['class_id'] +'" >';
            $('#name_loaded').append(data);
},
error: function () {
    alert('Sorry!, Something went wrong');
}
});

}
   $(".AllocationID").click(function () {
      var data= 'ids=' + $(this).attr('data-id');
        $('#UpdateModal').modal('show');
        $.ajax({
            type: "get",
            url: "<?= base_url('/allocation_Edit')?>",
            data: data,
            beforeSend: function()
            {
                $('#UpdtAllocation').html('<div class="text-center"><div class="spinner-border text-primary" role="status"><span class="sr-only">Loading...</span></div></div>');
            },
            success: function(res){
                $('#UpdtAllocation').html(res);
                 
            },
            error: function ()
            {
//alert('no data found');
            }
        });
    });
   // end allocation update
      $(".ViewID").click(function () {
      var id= $(this).data('ids');
      var subjects=  $(this).data('subjects');
        $('#viewModal').modal('show');
        $.ajax({
            type: "post",
            url: "<?= base_url('/ViewAllocation')?>",
            data: {teacher_id:id,subjects:subjects},
            beforeSend: function()
            {
                $('#ViewAllocation').html('<div class="text-center"><span class="spinner-border spinner-border-lg text-primary"> </span> Loading...</div>');
            },
            success: function(res){
                $('#ViewAllocation').html(res);
                 
            },
            error: function ()
            {
$('#ViewAllocation').html('<div class="text-center"><span class="alert alert-danger"> Failed to load allocation (ERR:500)</span></div>');
            }
        });
    });
           $(".close").click(function() {
        $("#viewModal").modal("hide");
    });
       $(document).on("click", function(event) {
        if (!$(event.target).closest(".modal-content, .ViewID").length) {
            $("#viewModal").modal("hide");
        }
    });
   //end view update
        var loadFile = function(event) {
    var output = document.getElementById('output1');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output1.src) // free memory
    }
  }; 
   $(document).ready(function() {
        $(".teacher-select").select2();
    });

   let loadingInterval;

$("#streamoption").change(function () {
    const streamId = $('#streamoption').val();
    const teacherId = $('#name_teacher').val();
    const classId = $('#class').val();
    const classLevelId = $('#classlevel').val();
    $('.form-control').removeClass('is-invalid');

    let hasError = false;

    if (!teacherId) {
        $('#name_teacher').addClass('is-invalid');
        hasError = true;
    }
    if (!classLevelId) {
        $('#classlevel').addClass('is-invalid');
        hasError = true;
    }
    if (!classId) {
        $('#class').addClass('is-invalid');
        hasError = true;
    }
    if (!streamId) {
        $('#streamoption').addClass('is-invalid');
        hasError = true;
    }

    if (hasError) {
        return;
    }

    const data = {
        stream_id: streamId,
        teacher_id: teacherId,
        class_id: classId,
        classlevel_id: classLevelId
    };

    $.ajax({
        type: "post",
        url: "<?= base_url('/ViewStreamSubjects') ?>",
        data: data,
        beforeSend: function () {
            $('.AllocationStatus').html(`
                <div class="text-primary fw-bold" id="textLoader">Loading</div>
            `);
            $('.allocatedSubjectsList').html(`
                <div class="text-primary fw-bold" id="textLoader">Loading</div>
            `);

            let dotCount = 0;
            loadingInterval = setInterval(() => {
                dotCount = (dotCount + 1) % 6;
                let dots = '.'.repeat(dotCount);
                $('#textLoader').html(`
                    <div class="d-flex align-items-center gap-2">
                        <div class="spinner-grow spinner-grow-sm text-primary" role="status"></div>
                        <span>Loading${dots}</span>
                    </div>
                `);
            }, 500);
        },
        success: function (res) {
    clearInterval(loadingInterval);
    $('.AllocationStatus').html(res);
    loadAllocationDetails(teacherId, classLevelId, classId, streamId);
},
        error: function () {
            clearInterval(loadingInterval);
            $('.AllocationStatus').html('<div class="alert alert-danger">Something went wrong.!!</div>');
        }
    });
});


</script>
 
