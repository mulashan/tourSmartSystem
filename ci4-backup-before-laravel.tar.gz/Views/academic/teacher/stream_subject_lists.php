<div class="row">
<div class="col-md-6">
        <div class="table-responsive">
             <div class="BulkAllocationStatus"></div>
                     <form id="Unallocated_subjects_selected">
                       
                             <div class="box-header with-border col-xs-2" style="padding-bottom:5px;">
                                <div class="subjectallocationStatus"></div>
                    <table>
                        <tr>
                        <th style="padding-right:5px;"><i class=""></i></th>
                        <th style="padding-right:7px;"><h6 class="text-center">Unallocated Subjects</h6></th>
                           <th><input type="text" id="searchUnallocated" onkeyup="filterTable('unallocated_subjects', 'searchUnallocated')" class="form-control" placeholder="Search..." name="searchname">


                        </th> 
               <th>&nbsp;</th>
               <th>&nbsp;</th>
               <th>&nbsp;</th>
               <th>&nbsp;</th>
               <th>&nbsp;</th>
              <th>&nbsp;</th>
         
                    
           <th><button type="button" class="btn-primary btn-sm" onclick="Assign_selected()" id="Assign_selected_btn">
    <span class="fa fa-plus"></span>
</button></th>
                        </tr>
                     </table>
            <div id="unallocated_subjects">
      
    </div>
                    </div>

                        </form>
        </div>
    </div>
    <div class="col-md-6">
        <div class="table-responsive">
            <div class="BulkUnallocationStatus"></div>
     <form id="allocated_subjects_selected">
         
                   <div class="box-header with-border col-xs-2" style="padding-bottom:5px;">
                    <table>
                        <tr>
                        <th style="padding-right:5px;"><i class=""></i></th>
                        <th style="padding-right:7px;"><h6 class="text-center">Allocated Subjects</h6></th>
                           <th>
<input type="text" id="searchAllocated" onkeyup="filterTable('allocated_subjects', 'searchAllocated')" class="form-control" placeholder="Search..." name="searchname">
                        </th> 
               <th>&nbsp;</th>
               <th>&nbsp;</th>
               <th>&nbsp;</th>
               <th>&nbsp;</th>
               <th>&nbsp;</th>
               <th>&nbsp;</th>
               <th>&nbsp;</th>
               <th>&nbsp;</th>
               <th>&nbsp;</th>
                    
                 <th class="text-end"><button type="button" class="btn-danger btn-sm" onclick="Unassign_selected()" id="Unassign_selected_btn">
    <span class="fa fa-remove"></span>
</button></th>
                        </tr>
                     </table>
           
                    </div>
                   <div id="allocated_subjects">
      
    </div>
                    </form> 
        </div>
    </div>

    
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>


    function loadAllocationDetails(teacherId, classLevelId, classId, streamId) {
    const postData = {
        teacher_id: teacherId,
        classlevel_id: classLevelId,
        class_id: classId,
        stream_id: streamId
    };

    $.post("<?= base_url('/load_unassigned_stream_subject') ?>", postData, function (response) {
        $('#unallocated_subjects').html(response);
    });

    $.post("<?= base_url('/load_assigned_stream_subjects') ?>", postData, function (response) {
        $('#allocated_subjects').html(response);
    });
}

function AssignSubjects(subjectId, teacherId, classLevelId, classId, streamId) {
    $.ajax({
        url: "<?= base_url('/allocate_teacher') ?>",
        type: "GET",
        data: {
            modl: subjectId,
            user: teacherId,
            classlevel_id: classLevelId,
            class_id: classId,
            stream_id: streamId
        },
        success: function(response) {
              if (response.status === 'error') {
        $('.BulkAllocationStatus').html('<div class="alert alert-danger"><b>Something went wrong </b> Assignment failed.</div>')
            .stop(true, true)
            .show()
            .delay(4000)
            .fadeOut();
    } else {
        loadAllocationDetails(teacherId, classLevelId, classId, streamId);
    }
        },
        error: function() {
              $('.BulkAllocationStatus').html('<div class="alert alert-danger">Something went wrong.!!</div>')
              .stop(true, true)
                .show()
                .delay(4000)
                .fadeOut();
        }
    });
}

function UnassignSubjects(subjectId, teacherId, classLevelId, classId, streamId){
        $.ajax({
        url: "<?= base_url('/unallocate_teacher') ?>",
        type: "GET",
        data: {
            modl: subjectId,
            user: teacherId,
            classlevel_id: classLevelId,
            class_id: classId,
            stream_id: streamId
        },
        success: function(response) {
                 if (response.status === 'error') {
        $('.BulkUnallocationStatus').html('<div class="alert alert-danger"><b>Something went wrong </b> Assignment failed.</div>')
            .stop(true, true)
            .show()
            .delay(4000)
            .fadeOut();
    } else {
        loadAllocationDetails(teacherId, classLevelId, classId, streamId);
    }
        },
        error: function() {
             $('.BulkUnallocationStatus').html('<div class="alert alert-danger">Something went wrong.!!</div>')
              .stop(true, true)
                .show()
                .delay(4000)
                .fadeOut();
        }
    });
}

function selectAllUnassigned() {
    const allChecked = $('#checkAllUnassigned').prop('checked');
    $('.unassigned-checkbox').prop('checked', allChecked);
}

function selectAllAssigned() {
    const allChecked = $('#checkAllAssigned').prop('checked');
    $('.assigned-checkbox').prop('checked', allChecked);
}
function Assign_selected() {
    const selectedSubjects = [];
    $('.unassigned-checkbox:checked').each(function () {
        selectedSubjects.push($(this).val());
    });

    if (selectedSubjects.length === 0) {
         $('.BulkAllocationStatus').html('<span class="text-danger">Please select atleast one subject!!.</span>')
              .stop(true, true)
                .show()
                .delay(5000)
                .fadeOut();
        return;
    }

    const teacherId = $('#name_teacher').val();
    const classLevelId = $('#classlevel').val();
    const classId = $('#class').val();
    const streamId = $('#streamoption').val();

    $.ajax({
        url: "<?= base_url('/allocate_all_teacher') ?>",
        type: "POST",
        data: {
            subjects: selectedSubjects,
            teacher_id: teacherId,
            classlevel_id: classLevelId,
            class_id: classId,
            stream_id: streamId
        },
        success: function () {

            loadAllocationDetails(teacherId, classLevelId, classId, streamId);
        },
        error: function () {
          $('.BulkAllocationStatus').html('<div class="alert alert-danger">Something went wrong.!!</div>')
              .stop(true, true)
                .show()
                .delay(4000)
                .fadeOut();
        }
    });
}

function Unassign_selected() {
    const selectedSubjects = [];
    $('.assigned-checkbox:checked').each(function () {
        selectedSubjects.push($(this).val());
    });

    if (selectedSubjects.length === 0) {
       $('.BulkUnallocationStatus').html('<span class="text-danger">Please select atleast one subject</span>')
              .stop(true, true)
                .show()
                .delay(5000)
                .fadeOut();
        return;
    }

    const teacherId = $('#name_teacher').val();
    const classLevelId = $('#classlevel').val();
    const classId = $('#class').val();
    const streamId = $('#streamoption').val();

    $.ajax({
        url: "<?= base_url('/unallocate_all_teacher') ?>",
        type: "POST",
        data: {
            subjects: selectedSubjects,
            teacher_id: teacherId,
            classlevel_id: classLevelId,
            class_id: classId,
            stream_id: streamId
        },
        success: function () {
            loadAllocationDetails(teacherId, classLevelId, classId, streamId);
        },
        error: function () {
            $('.BulkUnallocationStatus').html('<div class="alert alert-danger">Something went wrong.!!</div>')
                .stop(true, true)
                .show()
                .delay(4000)
                .fadeOut();

        }
    });
}
function filterTable(tableContainerId, inputId) {
    const input = document.getElementById(inputId);
    const filter = input.value.toLowerCase();
    const tableDiv = document.getElementById(tableContainerId);
    const table = tableDiv.querySelector("table");
    const rows = table.querySelectorAll("tr");
    let matchCount = 0;
    const oldMessage = tableDiv.querySelector('.no-results-message');
    if (oldMessage) {
        oldMessage.remove();
    }
    rows.forEach((row, index) => {
        if (index === 0) return;
        const rowText = row.textContent.toLowerCase();
        if (rowText.includes(filter)) {
            row.style.display = "";
            matchCount++;
        } else {
            row.style.display = "none";
        }
    });
    if (matchCount === 0) {
        const messageRow = document.createElement("tr");
        messageRow.className = "no-results-message";
        messageRow.innerHTML = `<td colspan="${rows[0].cells.length}" class="text-center text-danger"><em>No matching data found.</em></td>`;
        table.appendChild(messageRow);
    }
}
</script>

