<!-- By chanangwa E, -->
<style>
.modal-dialog1 {
          max-width: 900px; /* New width for default modal */
		   background: #ccc;
		   max-height: 500px;
		   
        }
		
.modal-content {
    background: white;
  }
font-family: 'Varela Round', sans-serif;
}
.modal-confirm {		
	color: #636363;
	width: 600px;
}
input{
	width:14px:
}
.modal-confirm .modal-content {
	padding: 20px;
	border-radius: 5px;
	border: none;
	text-align: center;
	font-size: 14px;
}
.modal-confirm .modal-header {
	border-bottom: none;   
	position: relative;
}
.modal-confirm h4 {
	text-align: center;
	font-size: 26px;
	margin: 30px 0 -10px;
}
.modal-confirm .close {
	position: absolute;
	top: -5px;
	right: -2px;
}
.modal-confirm .modal-body {
	color: #999;
}
.modal-confirm .modal-footer {
	border: none;
	text-align: center;		
	border-radius: 5px;
	font-size: 13px;
	padding: 10px 15px 25px;
}
.modal-confirm .modal-footer a {
	color: #999;
}		
.modal-confirm .icon-box {
	width: 80px;
	height: 80px;
	margin: 0 auto;
	border-radius: 50%;
	z-index: 9;
	text-align: center;
	border: 3px solid #f15e5e;
}
.modal-confirm .icon-box i {
	color: #f15e5e;
	font-size: 46px;
	display: inline-block;
	margin-top: 13px;
}
.modal-confirm .btn, .modal-confirm .btn:active {
	color: #fff;
	border-radius: 4px;
	background: #60c7c1;
	text-decoration: none;
	transition: all 0.4s;
	line-height: normal;
	min-width: 120px;
	border: none;
	min-height: 40px;
	border-radius: 3px;
	margin: 0 5px;
}
.modal-confirm .btn-secondary {
	background: #c1c1c1;
}
.modal-confirm .btn-secondary:hover, .modal-confirm .btn-secondary:focus {
	background: #a8a8a8;
}
.modal-confirm .btn-danger {
	background: #f15e5e;
}
.modal-confirm .btn-danger:hover, .modal-confirm .btn-danger:focus {
	background: #ee3535;
}
.trigger-btn {
	display: inline-block;
	margin: 100px auto;
}
p{
	text-weight:20px;
	font-size:16pt;
}
.nav{
    margin: 10 20 10 30;
}

</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">My Allocations</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">My Allocations</li>
                </ol>
            </div>
            <!-- =========================================================================== -->
            
            <!-- =========================================================================== -->

        </div>
        <!-- =======================000000000000000000============================== -->

        <!-- =====================0000000000000000000000============================= -->
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active">
                <div class="card">
                  <div class="card-body">
                  <div class="d-flex flex-nowrap justify-content-end overflow-auto scrollable-tabs">
                    <ul class="nav nav-tabs flex-row">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#sub_details">Subject Details</a>
                        </li>
                    
                    </ul>
                </div>

        
        <!-- ==========================results start =================-->
     <div class="tab-content mt-3">
                    <div class="tab-pane fade show active" id="sub_details">
                        <div class="row justify-content-center">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h6 class="card-title">My Allocation Details</h6>
                                    </div>
                                    <hr>
                                    <div class="card-body text-wrap">
                                         <div class="table-responsive mt-3">
                                       <table class="table table-bordered table-hover" id="myTable">
                    <thead>
                    <tr>
                        <th>Sn</th>
                        <th>Subject</th>
                        <th>Class</th>
                        <th>Number of students</th>
                        <th>Allocated</th>
                        <th> Allocated On</th>
                            </tr>
                            </thead>
                            <tbody>
                            
                    <?php  
                         $i=1;
                        foreach($my_allocation as $all)
                        {
                        ?><tr>
                            <td><?php echo $i;?></td>
                           
                           <td><?php echo $all->subject_name; ?></td>
                           <td><?php echo $all->class_name;?></td>
                           <td></td>
                           <td>                  <?php
                 foreach($staffs as $staf){
                $cr=$all->allocated_by; 
                 $stf=$staf->user_id;
                if($cr==$stf){
                 echo $staf->first_name;?>
                    
                    <?php
                     echo $staf->last_name;
                 }
              
            }?></td>
              <td> <?php echo $all->allocation_date;?></td>
                  
  
                    </tr>
                              <?php
                              $i++;
                }?>  
                </tbody>
                </table>
            </div>
                     </div>
                                </div>
                            </div>
                        </div>
                    </div>

               
                </div>
               
        <!-- =========================results end================== -->
  </div>

    
   
                </div>
             
            </div>
  
          
            <!-- =====================end of edit modal==== -->
        </div>
    </div>
</div>
<script type="text/javascript">
    $('#saveSubject').submit(function(e){
        //alert($(this).serialize());
        $.ajax({
            type: "POST",
            url: "<?= base_url('/save_Subject') ?>",
            data: $(this).serialize(),
            success: function (data) {
                $('#SubjectAdd').html(data);
                $('#saveSubject')[0].reset();
                setTimeout(function(){
                    window.location.reload();
                },2000);
            },
            error: function () {
                $('#fdbkarea').html('Sorry! Something went wrong.');

            }
        });
        e.preventDefault();
    });

 $(".RemoveSubject").click(function(){
        var id = $(this).attr('data-subject_id');
           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this Subject!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
           confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/remove_subject')?>/'+id,
                 error: function() {
                    swal('Something went wrong!!');
                 },
               success: function(data) {
			
				swal("Deleted successfuly"); 
			    setTimeout(function(){
                    window.location.reload();
                },1000);
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
</script>
