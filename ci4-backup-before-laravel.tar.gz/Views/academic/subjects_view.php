<!-- By chanangwa E, -->
<style>
.modal-dialog1 {
          max-width: 900px; /* New width for default modal */
		   background: #ccc;
		   max-height: 500px;
		   
        }
		
.modal-content {
    background: white;
  }
font-family: 'Varela Round', sans-serif;
}
.modal-confirm {		
	color: #636363;
	width: 600px;
}
input{
	width:14px:
}
.modal-confirm .modal-content {
	padding: 20px;
	border-radius: 5px;
	border: none;
	text-align: center;
	font-size: 14px;
}
.modal-confirm .modal-header {
	border-bottom: none;   
	position: relative;
}
.modal-confirm h4 {
	text-align: center;
	font-size: 26px;
	margin: 30px 0 -10px;
}
.modal-confirm .close {
	position: absolute;
	top: -5px;
	right: -2px;
}
.modal-confirm .modal-body {
	color: #999;
}
.modal-confirm .modal-footer {
	border: none;
	text-align: center;		
	border-radius: 5px;
	font-size: 13px;
	padding: 10px 15px 25px;
}
.modal-confirm .modal-footer a {
	color: #999;
}		
.modal-confirm .icon-box {
	width: 80px;
	height: 80px;
	margin: 0 auto;
	border-radius: 50%;
	z-index: 9;
	text-align: center;
	border: 3px solid #f15e5e;
}
.modal-confirm .icon-box i {
	color: #f15e5e;
	font-size: 46px;
	display: inline-block;
	margin-top: 13px;
}
.modal-confirm .btn, .modal-confirm .btn:active {
	color: #fff;
	border-radius: 4px;
	background: #60c7c1;
	text-decoration: none;
	transition: all 0.4s;
	line-height: normal;
	min-width: 120px;
	border: none;
	min-height: 40px;
	border-radius: 3px;
	margin: 0 5px;
}
.modal-confirm .btn-secondary {
	background: #c1c1c1;
}
.modal-confirm .btn-secondary:hover, .modal-confirm .btn-secondary:focus {
	background: #a8a8a8;
}
.modal-confirm .btn-danger {
	background: #f15e5e;
}
.modal-confirm .btn-danger:hover, .modal-confirm .btn-danger:focus {
	background: #ee3535;
}
.trigger-btn {
	display: inline-block;
	margin: 100px auto;
}
p{
	text-weight:20px;
	font-size:16pt;
}
</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Subjects</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Subjects</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#users-all">Subjects List</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#subject-add">New Subject</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#users-all"></a>
                Subjects List</li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#users-add">New Subject</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="users-all">
                <div class="card">
		   <p class="">
            <?php
			if(session()->getFlashdata('msg')){
            echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span>'.session()->get('msg').'</div> ';
			
			}
			if(session()->getFlashdata('error')){
			echo '<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span>'.session()->get('error').'</div> ';
			}
            ?>
        </p>
       <div class="table-responsive mt-3">
           <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>No.#</th>
                                    <th>Subject</th>
                                    <th>Selection</th>
                                    <th>Status</th>
                                    <th>Created By</th>
                                    <th>Created Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
							<tbody>
							<?php
							$i=1;
							foreach($subjects
                             as $subject){
								?>
								  <!--MODAL FOR DELETING THE subject-->
								
								<tr>
								<td> <?php echo $i;?></td>
								<td> <?php echo $subject->subject_name;?></td>
                 <td >          
                   <?php if($subject->selection==1):?>
                    <span> Compulsory</span>
                    <?php else:?>
                     <span> Subsidiary</span>  
                    <?php
                  endif;
                  ?>  
              </td>                

                      <td >          
                   <?php if($subject->status==1):?>
                   <strong> <span class="text-success"> Active</span></strong>
                    
                    <?php else:?>
                   
                    <strong> <span class="text-danger"> Inactive</span>  </strong>
                    <?php
                  endif;
                  ?>  
              </td>
               <td> <?php echo $subject->first_name; ?>
               <?php
                echo $subject->last_name;?>   
               </td>
               <td> <?php echo $subject->create_date;?></td>

                               
								<td>
			 <a href="#" data-toggle="modal"  data-target="#iedit<?=$subject->subject_id;?>" class="text-light btn btn-xs btn-flat btn-primary"><i class="fa fa-edit"></i> Edit</a>
                 <a href="#" data-toggle="modal"  data-target="#view_subjec<?=$subject->subject_id;?>" class="text-light btn btn-xs btn-flat btn-primary"><i class="fa fa-eye"></i> View</a>		
							
						       </td>
								</tr>
                           
          <!-- =================edit modal============ -->
            <!-- Modal -->
  <div class="modal fade" id="iedit<?php echo $subject->subject_id;?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formEditPelanggan" aria-hidden="true">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Edit Subject</h5>
          <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
         <form name="" action="<?= base_url('/update_Subject') ?>" method="post">
    <input type="hidden" name="subject_id" value="<?= $subject->subject_id; ?>">

    <label>Subject Name:</label>
    <input type="text" name="subjectname" value="<?= $subject->subject_name; ?>" class="form-control">
<label>Selection:</label>
    <select name="selection" class="form-control">
        <option value="1" <?= $subject->selection == 1 ? 'selected' : ''; ?>>Compulsory</option>
        <option value="2" <?= $subject->selection == 2 ? 'selected' : ''; ?>>Subsidiary</option>
    </select>

    <label>Status:</label>
    <select name="subjectstatus" class="form-control">
        <option value="1" <?= $subject->status == 1 ? 'selected' : ''; ?>>Active</option>
        <option value="2" <?= $subject->status == 2 ? 'selected' : ''; ?>>Inactive</option>
    </select>

    <button type="submit" class="btn btn-success mt-3">Update</button>
</form>
        </div>
        <div class="modal-footer">
        </div>
      </div>
      
    </div>
  </div>
            <!-- =====================end of edit modal==== -->
<!-- =====================subject view modal==== -->
<div class="modal fade" id="view_subjec<?=$subject->subject_id;?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formEditPelanggan" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel"> Subject Details</h5>
          <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
                         <div class="row">
                    <!-- combination information-->
                    <div class="col-md-6">
                        <div class="card shadow-sm">
                            <div class="card-header bg-light p-3">
                                <h5>Subject Information</h5>
                            </div>
                            <div class="card-body">
                                <hr>

 <strong>SUBJECT NAME:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="p-5"> <?php echo $subject->subject_name;  ?></span>
   <br>
   <br>
  
  <strong>SUBJECT STATUS:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span class="p-5"> <?php if($subject->status==1):?>
                   <strong> <span class="text-success"> Active</span></strong>
                    
                    <?php else:?>
                   
                    <strong> <span class="text-danger"> Inactive</span>  </strong>
                    <?php
                  endif;
                  ?> 
              </span>
       <br>
       <br>
  <strong>SELECTION STATUS:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="p-5">   <?php if($subject->selection==1):?>
                    <span> Core</span>
                    <?php else:?>
                     <span> Optional</span>  
                    <?php
                  endif;
                  ?>  </span> 
    <br>
    <br>
  <strong>CTEATED BY:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span class="p-5"> <?php echo $subject->first_name;?> <?php echo $subject->last_name;?></span><br>
              <br>
         
                  <strong>CTEATED ON:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="p-5"> <?php echo $subject->create_date; ?></span>
            
                <hr>

                                                      
                            </div>
                        </div>
                    </div>
              <!--       <div class="col-md-6">
                        <div class="card shadow-sm">
                            <div class="card-header bg-light p-3">
                                <h5>Subjects Information</h5>
                            </div>
                            <div class="card-body">
                      <?php //echo $comb->comb_id;  ?>
                      <?php //echo $comb->comb_name;  ?>          
                            </div>
                        </div></div> -->
        </div>

                 <!-- ================= -->

        </div>
         <div class="modal-footer d-flex justify-content-center">
            <div class="align-items-center">
        <button type="button" class="btn btn-danger btn-sm RemoveSubject" data-subject_id="<?=$subject->subject_id;?>"><i class="fa fa-trash"></i> Delete</button>
            </div> 
        </div>
      </div>
      
    </div>
  </div>
  <!-- ==============end of combination view model==== -->


							<?php
							$i++;
							}
							
							?>
							 </tbody>
                            
                        </table>
                    </div>
                </div>
             
            </div>
  <div class="tab-pane" id="subject-add">
       <div class="row clearfix">
		<div id="SubjectAdd"></div>
             <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header" style="height:5px">
                               <h3 class="card-title">Add New Subject</h3>
                                <div class="card-options">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                            <hr>
<div class="card-body">
    <div class="row">
      <div class="col-md-12">
        <form id="saveSubject" class="needs-validation" novalidate>
                                               <div class="row mb-3">
             <label for="subjectname" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Subject Name<span class="text-danger">*</span></label>
                  <div class="col-sm-3">
                    <input type="text" class="form-control form-control-sm" id="subjectname" name="subjectname" placeholder="eg: History" required>
                      <div class="invalid-feedback">Subject Name is required.</div>
                                                </div>
                                            </div>         
   <div class="row mb-3">
             <label for="selection" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Subject Selection<span class="text-danger">*</span></label>
                         <div class="col-sm-3">
        <select class="form-control form-control-sm" id="selection" name="selection" required>
    <option value="" disabled selected>--Please Select--</option>
    <option value="1">Compulsory</option>
    <option value="2">Subsidiary</option>
  </select>  <div class="invalid-feedback">Subject Selection is required.</div>
                            </div> 
                                            </div>

                             <div class="d-flex justify-content-end mt-2 mb-3">
                                                <button type="submit" class="btn btn-primary"><i class="fa fa-plus me-2"></i>Create</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
          
            <!-- =====================end of edit modal==== -->
        </div>
    </div>
</div>
<script type="text/javascript">
    $('#saveSubject').submit(function(e){
            e.preventDefault();
    if (!this.checkValidity()) {
        this.classList.add("was-validated");
        return;
             }
        $.ajax({
            type: "POST",
            url: "<?= base_url('/save_Subject') ?>",
            data: $(this).serialize(),
            success: function (data) {
                $('#SubjectAdd').html(data);
                $('#saveSubject')[0].reset();
                setTimeout(function(){
                    window.location.reload();
                },2000);
            },
            error: function () {
                $('#fdbkarea').html('Sorry! Something went wrong.');

            }
        });
    
    });

 $(".RemoveSubject").click(function(){
        var id = $(this).attr('data-subject_id');
           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this Subject!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
           confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/remove_subject')?>/'+id,
                 error: function() {
                    swal('Something went wrong!!');
                 },
               success: function(data) {
			
				swal("Deleted successfuly"); 
			    setTimeout(function(){
                    window.location.reload();
                },1000);
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
</script>
