<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
   <style>
    table {
            width: 100%;
            border-collapse: collapse;
            white-space: nowrap;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }
        th {
            /*background-color: #f2f2f2;*/

              background-color: #ddd;
        }
        .main-header {
            text-align: center;
            font-weight: bold;
        }
     .rotate {
    writing-mode: vertical-rl;
    transform: rotate(90deg);
    text-align: center;
    white-space: nowrap;
}
        .highlight {
               border: 1px solid black;
            background-color: #fdf1c7;
              text-align: center;
        }
     th.sub_design {
    writing-mode: vertical-rl;
    transform: rotate(180deg);
    text-orientation: mixed;
    vertical-align: middle;
    white-space: nowrap;
    padding: 1px;
    font-weight: bold;
}
input[type=number]::-webkit-inner-spin-button, 
input[type=number]::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
input[type=number] {
  -moz-appearance: textfield;
}
    </style>
<?php
            helper('calc');
             $bmodel = new App\Models\BillingModel();
             $smodel = new App\Models\StudentModel();
             $report = new App\Models\ReportsModel();
             $dbname=session()->get('db_name');
            $db = \Config\Database::connect($dbname);
          ?>
                            <?php
            if(!empty($exists)) {
            ?>
            <center id="update-status">
          <form id="UpdateExamResults" class="mt-3">
     <input type="hidden" name="year" value="<?= esc($year) ?>">
    <input type="hidden" name="term" value="<?= esc($term) ?>">
    <input type="hidden" name="examtype" value="<?= esc($examtype) ?>">
    <?php foreach ($details as $st): ?>
        <input type="hidden" name="student_ids[]" value="<?= $st->id ?>">
    <?php endforeach; ?>
     <?php foreach ($subjects as $subject): ?>
          <input type="hidden" name="subject_ids[]" value="<?= $subject->subject_id ?>">
          <?php endforeach; ?>
            

    <span class="alert alert-success"><b>Data already Saved</b> <button class="btn btn-success"> click to Allow update</button> </span>


            </form>
            </center> 
            <?php
          }
            ?>
            <hr>

              <div class="card">

        <div class="table-responsive mt-3">
    <div id="autosave-status"></div>
    <table id="myTable">
        <thead>
            <tr>
                <th rowspan="3">S/N</th>
                <th rowspan="3">EXAM NO</th>
                <th rowspan="3">COMB</th>
                <th rowspan="3">FULL NAME</th>
                <th rowspan="3">SEX</th>
                <?php 
                if (isset($subjects)) {
                    $colspan = count($subjects) * 2;
                    echo "<th colspan='{$colspan}'>SUBJECTS</th>";
                }
                ?>
            </tr>
            <tr>
                <?php 
                if (isset($subjects)) {
                    foreach ($subjects as $subject) {
                        echo "<th colspan='2' class='sub_design'>" . strtoupper($subject->subject_name) . "</th>";
                    }
                }
                ?>
            </tr>
            <tr>
                <?php 
                if (isset($subjects)) {
                    foreach ($subjects as $subject) {
                        echo "<th>MARK</th><th>GRADE</th>";
                    }
                }
                ?>
            </tr>
        </thead>

        <tbody>
            <?php
            if(count($details) > 0) {
                $i = 0; 
                foreach($details as $st) {
                    $i++;
            ?>
            <tr>
                <td><?= $i ?></td>
                <td>-</td>
                <td><?= $st->comb_name;?></td>
                <td style="text-align: left; "><?= $st->full_name;?></td>
                <?php
                    if ($st->gender == 'Male') {
                        echo '<td>M</td>';
                    } elseif($st->gender == 'Female') {
                        echo '<td>F</td>';
                    }
                ?>

                <?php
                foreach ($subjects as $subject) {
                    $result = null;
                    $grade_name = '';
                    $marks = ''; 
                    foreach ($results as $r) {
                        if ($r->student_id == $st->id && $r->subject_id == $subject->subject_id) {
                            $result = $r;
                            $marks = $r->marks_scored;
                            $grade_name = $r->grade_name;
                            break;
                        }
                    }
                    ?>
                    <td>
                                         <?php
            if ($exists==true) {
            ?>
                        <input type="number" name="marks" min="0" max="100" class="marksave" style="width: 50px;"
                               value="<?= esc($marks) ?>" 
                               data-student-id="<?= $st->id ?>" 
                               data-subject-id="<?= $subject->subject_id ?>"
                               data-term-id="<?= esc($term) ?>"
                               data-year-id="<?= esc($year) ?>"
                               data-examtype-id="<?= esc($examtype) ?>"
                               data-class-id="<?= esc($class) ?>"
                               data-date-id="<?= esc($date) ?>" disabled>
                               <?php
                          }else{
                               ?>
                                <input type="number" name="marks" min="0" max="100" class="marksave" style="width: 50px;" 
                               value="<?= esc($marks) ?>" 
                               data-student-id="<?= $st->id ?>" 
                               data-subject-id="<?= $subject->subject_id ?>"
                               data-term-id="<?= esc($term) ?>"
                               data-year-id="<?= esc($year) ?>"
                               data-examtype-id="<?= esc($examtype) ?>"
                               data-class-id="<?= esc($class) ?>"
                               data-date-id="<?= esc($date) ?>">
                               <?php
                           }
                               ?>
                          
                    </td>
                    <td><?= esc($grade_name)?></td>
                    <?php
                }
                ?>
            </tr>
            <?php 
                }
            }
            ?>
            <?php if (empty($exists)) { ?>
<!--   <button id="refreshGradesBtn" class="btn btn-info mb-2">
    <i class="fa fa-sync"></i> Refresh Results Marks
  </button> -->
<?php } ?>
        </tbody>
    </table>
</div>

            <?php
              if(empty($exists)){

            ?>
<form id="SubmitExamResults" class="mt-3">
    <input type="hidden" name="year" value="<?= esc($year) ?>">
    <input type="hidden" name="term" value="<?= esc($term) ?>">
    <input type="hidden" name="examtype" value="<?= esc($examtype) ?>">

    <?php foreach ($details as $st): ?>
        <input type="hidden" name="student_ids[]" value="<?= $st->id ?>">
    <?php endforeach; ?>
     <?php foreach ($subjects as $subject): ?>
          <input type="hidden" name="subject_ids[]" value="<?= $subject->subject_id ?>">
          <?php endforeach; ?>

    <div id="btnstatus"></div>
    <button type="submit" id="createResultBtn" class="btn btn-primary float-right" disabled data-bs-toggle="tooltip" data-bs-placement="top" title="Please fill all fields first!">
        <i class="fa fa-save"></i> Create Result
    </button>
    <span id="btnMessage" class="alert bg-danger text-white">
        <b>Please fill all fields before saving!</b>
    </span>
</form>

           
            <?php
                }
            ?>
          
             <div id="showmsg"></div>
  </div>

<noscript>
    <style>
        .table-condensed{
            padding-bottom: 20px; 

        }
        table.table{
            border: 1px solid black;
            width:80%;
          
            margin-left: auto;
            margin-right: auto;
/*            page-break-inside: avoid;*/
           
        }
         table.table td{
         border:1px solid black;
           font-size: 12px;
         }
        #myTable td,#myTable th{
            border:1px solid black;
           font-size: 12px;
           }
        h6{
            text-align: center;
        }
        .btnp,.viewbtn{
           display: none;
        }
        #myTable_wrapper .dataTables_filter,
        #myTable_wrapper .dataTables_paginate,
        #myTable_wrapper .dataTables_length {
         display: none;
}
 @media print {
      .table {
        border-collapse: collapse !important;
        border: 1px solid black !important;
      }
      }
      table.toba td{
        font-size: 12px;
      }
        
    </style> 
</noscript>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
  <script>
$(document).off("blur", ".marksave").on("blur", ".marksave", function() {
    var input = $(this);
    var student_id = input.data("student-id");
    var subject_id = input.data("subject-id");
    var term_id = input.data("term-id");
    var year_id = input.data("year-id");
    var date_id = input.data("date-id");
    var examtype_id = input.data("examtype-id");
    var grade_id = input.data("grade-id");
    var class_id = input.data("class-id");
    var marks = input.val();

    if (marks === "" || marks < 0 || marks > 100) {
           input.removeClass('border-success bg-light text-success')
             .addClass('is-invalid border-danger bg-light text-danger');
        return;
    } else {
             input.removeClass('is-invalid border-danger text-danger')
             .addClass('border-success bg-light text-success');
    }

    $.ajax({
        url: "<?= base_url('SaveExam') ?>",
        type: "POST",
        data: {
            student_id: student_id,
            subject_id: subject_id,
            marks: marks,
            term_id: term_id,
            year_id: year_id,
            examtype_id: examtype_id,
            class_id: class_id,
            grade_id: grade_id,
            date_id: date_id
        },
        success: function(response) {
            if(response.status==1){
 $("#autosave-status")
                .stop(true, true)
                .html("<span class='text-success'>Saved successfully!</span>")
                .show()
                .delay(6000)
                .fadeOut();
              if (response.grade_name && response.grade_id) {
        input.closest('td').next().html(response.grade_name);
        input.attr('data-grade-id', response.grade_id);
            }}
           
    else if(response.status==3){
         $("#autosave-status")
                .stop(true, true)
                .html("<span class='text-danger'>Saved Failed! Please check if marks fall within valid grade range or try again.</span>")
                .show()
                .delay(6000)
                .fadeOut();
         input.closest('td').next().html("<span class='text-danger'>Marks not in grades range!</span>");
    }else{
         $("#autosave-status")
                .stop(true, true)
                .html("<span class='text-danger'>Saved Failed! Please check if marks fall within valid grade range or try again.</span>")
                .show()
                .delay(6000)
                .fadeOut(); 
    }
        },
        error: function() {
            $("#autosave-status")
                .stop(true, true)
                .html("<span class='text-danger'>Error saving data!</span>")
                .show();
        }
    });
});


  $('#SubmitExamResults').submit(function (e) {
     e.preventDefault();
   var formData = $(this).serialize();
    $.ajax({
        url: "<?= base_url('SubmitExamResults') ?>",
        type: "POST",
        data:formData,
         beforeSend: function(){
    Swal.fire({
         icon: 'info',
        title: "Please wait.....",
        text: "Submiting examination results! ",
            allowOutsideClick: false,
    didOpen: () => {
        Swal.showLoading();
    }
       
    });
         },
      success:function(response){
             $('#showmsg').html(response); 
                setTimeout(function(){
            window.location.reload();
        },3000)
            },
        error: function() {
            $("#autosave-status")
                .stop(true, true)
                .html("<span class='text-danger'>Error saving data!</span>")
                .show();
        }
    });
});

    $('#UpdateExamResults').submit(function (e) {
     e.preventDefault();
   var formData = $(this).serialize();
    $.ajax({
        url: "<?= base_url('update_Exam_results') ?>",
        type: "POST",
        data:formData,
           beforeSend: function(){
    Swal.fire({
         icon: 'info',
        title: "Please wait.....",
        text: "System allowing you update examination results! ",
            allowOutsideClick: false,
    didOpen: () => {
        Swal.showLoading();
    }
       
    });
         },
      success:function(response){
        Swal.fire({
    icon: 'success',
    title: 'Done!',
    text: 'Results edit allowed successfully.'
});

    $("#update-status")
                .stop(true, true)
                .html("<span class='alert alert-success'><b>Update allowed successfully!</b> click <b>Load</b> button above to refresh data</span>")
                .show()
                .delay(10000)
                .fadeOut();
                $("html, body").animate({ scrollTop: 0 }, "slow");
            },
        error: function() {
            $("#update-status")
                .stop(true, true)
                .html("<span class='text-danger'>Failed to allow update!</span>")
                .show();
        }
    });
});

$(document).ready(function () {
    $(".GradeSave").on("change", function () {
        if ($(this).val()) {
            $(this).removeClass("border-danger bg-danger").addClass("border-success");
        } else {
            $(this).removeClass("border-success").addClass("border-danger bg-light");
        }
    });
    $(".GradeSave").each(function () {
        if ($(this).val()) {
            $(this).addClass("border-success");
        } else {
            $(this).addClass("border-danger bg-light");
        }
    });
});



$(document).ready(function () {
    function checkDropdowns() {
        let allFilled = true;
        $(".marksave").each(function () {
            if (!$(this).val()) {
                allFilled = false;
                return false;
            }
        });

        if (allFilled) {
            $("#createResultBtn").prop("disabled", false).attr("title", "Click to create results!").removeClass("btn-primary").addClass("btn-success");
             $("#btnMessage").hide();
        } else {
            $("#createResultBtn").prop("disabled", true).attr("title", "Please select all grades first!").removeClass("btn-success").addClass("btn-secondary");
              $("#btnMessage").show();

        }
    }

    $(".marksave").on("change", checkDropdowns);
    checkDropdowns();
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

$('#refreshGradesBtn').on('click', function () {
    Swal.fire({
        title: 'Are you sure?',
        text: 'This will refresh results without changing the marks.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, refresh',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            $.post("<?= base_url('RefreshExamGrades') ?>", {
                class: "<?= $class ?>",
                stream: "<?= $stream ?>",
                year: "<?= $year ?>",
                term: "<?= $term ?>",
                examtype: "<?= $examtype ?>",
                date: "<?= $date ?>"
            }, function (res) {
                if (res.status == 1) {
                    Swal.fire("Success", res.message, "success");
                } else {
                    Swal.fire("Error", res.message, "error");
                }
            });
        }
    });
});


  </script>
