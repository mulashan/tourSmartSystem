<!-- By chanangwa E, -->
<style>
.modal-dialog1 {
          max-width: 900px; /* New width for default modal */
		   background: #ccc;
		   max-height: 500px;
		   
        }
		
.modal-content {
    background: white;
  }
font-family: 'Varela Round', sans-serif;
}
.modal-confirm {		
	color: #636363;
	width: 600px;
}
input{
	width:14px:
}
.modal-confirm .modal-content {
	padding: 20px;
	border-radius: 5px;
	border: none;
	text-align: center;
	font-size: 14px;
}
.modal-confirm .modal-header {
	border-bottom: none;   
	position: relative;
}
.modal-confirm h4 {
	text-align: center;
	font-size: 26px;
	margin: 30px 0 -10px;
}
.modal-confirm .close {
	position: absolute;
	top: -5px;
	right: -2px;
}
.modal-confirm .modal-body {
	color: #999;
}
.modal-confirm .modal-footer {
	border: none;
	text-align: center;		
	border-radius: 5px;
	font-size: 13px;
	padding: 10px 15px 25px;
}
.modal-confirm .modal-footer a {
	color: #999;
}		
.modal-confirm .icon-box {
	width: 80px;
	height: 80px;
	margin: 0 auto;
	border-radius: 50%;
	z-index: 9;
	text-align: center;
	border: 3px solid #f15e5e;
}
.modal-confirm .icon-box i {
	color: #f15e5e;
	font-size: 46px;
	display: inline-block;
	margin-top: 13px;
}
.modal-confirm .btn, .modal-confirm .btn:active {
	color: #fff;
	border-radius: 4px;
	background: #60c7c1;
	text-decoration: none;
	transition: all 0.4s;
	line-height: normal;
	min-width: 120px;
	border: none;
	min-height: 40px;
	border-radius: 3px;
	margin: 0 5px;
}
.modal-confirm .btn-secondary {
	background: #c1c1c1;
}
.modal-confirm .btn-secondary:hover, .modal-confirm .btn-secondary:focus {
	background: #a8a8a8;
}
.modal-confirm .btn-danger {
	background: #f15e5e;
}
.modal-confirm .btn-danger:hover, .modal-confirm .btn-danger:focus {
	background: #ee3535;
}
.trigger-btn {
	display: inline-block;
	margin: 100px auto;
}
p{
	text-weight:20px;
	font-size:16pt;
}

    .year-dropdown {
        text-align: center;
        text-align-last: center;
        display: block;
        width: 200px;
    }
</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Examination Results</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Examination Results</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Exam_input_list">Examination Results List</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#new_exam_list"> New Examination Results</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Exam_input_list">Examination Results List</a>
                </li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#new_exam_list">New Examination Results</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="Exam_input_list">
                <div class="card">
		   <p class="">
            <?php
			if(session()->getFlashdata('msg')){
            echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span>'.session()->get('msg').'</div> ';
			
			}
			if(session()->getFlashdata('error')){
			echo '<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span>'.session()->get('error').'</div> ';
			}
            ?>
        </p>
          <div class="tab-pane active" id="adm-add">
               <div class="d-flex justify-content-center">
                    <form id="ListExamResults" class="form-inline">
                     <div class="me-3">
                            Academic year: 
                           <select id="year2" name="year2" class="class-select form-control" style="width: 100px;">
                    </select>
                        </div>
                     <button type="submit" class="btn btn-primary"><i class="fa fa-search"> </i> Create</button>
                        </form>
                        </div>
                        <hr>
                &nbsp;  
            </div>
                 <div id="ExamResultsList" class="mt-4"></div>

                </div>
             
            </div>
          
  <div class="tab-pane" id="new_exam_list">
       <div class="row clearfix">
		<div id="CharactAdd"></div>
             <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header" style="height:5px">
                               <h3 class="card-title"> New Examination Results</h3>
                                <div class="card-options">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                            <hr>
<div class="card-body">
    <div class="row">
      <div class="col-md-12">
          <?php
                 if(isset($myclass) && !empty($myclass)){
                 ?>
        <form id="FetchStudentsResult"  class="needs-validation" novalidate>
            <div class="row mb-3">
          <label for="year" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Academic Year:<span class="text-danger">*</span></label>
                  <div class="col-sm-3">
                    <select for="year" id="year" name="year"class="class-select form-control form-control-sm align-items-center year-dropdown" required>
         
                          </select>
                           <div class="invalid-feedback">Academic required.</div>
                               </div>
                                   </div>
                        <div class="row mb-3">
          <label for="term" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Term:<span class="text-danger">*</span></label>
                  <div class="col-sm-3">
                 <select for="class1" id="term" name="term"class="class-select form-control form-control-sm align-items-center year-dropdown" required>
                            <?php             
                                if(isset($term)){
                              foreach($term as $info){
                            echo '<option value="'.$info->id. '">' . $info->term_name . '</option>'; 
                              }}

                               ?> 
                 </select>
                  <div class="invalid-feedback">School Term required.</div>
                                                </div>
                    
                                            </div>
                                                     <div class="row mb-3">
          <label for="examtype" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Exam Type:<span class="text-danger">*</span></label>
                  <div class="col-sm-3">
                 <select for="examtype" id="examtype" name="examtype"class="class-select form-control form-control-sm align-items-center year-dropdown" required>
                    <option value="" selected disabled >--please Select--</option>
                            <?php             
                                if(isset($exams)){
                              foreach($exams as $info){
                            echo '<option value="'.$info->exam_id. '">' . $info->exam_name . '</option>'; 
                              }}
                               ?> 
                 </select>
                  <div class="invalid-feedback">Examination Type required.</div>
                                                </div>
                    
                                            </div>

               <div class="row mb-3">
                      <label for="date" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Exam Date:<span class="text-danger">*</span></label>
                                     <div class="col-sm-3">
                     <input type="date" class="form-control form-control-sm" id="date" name="date" style="width: 200px;" required>
                      <div class="invalid-feedback">Date required.</div> 
                    </div>  
                      </div>
                 <div class="row mb-3">
          <label for="class1" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Class:<span class="text-danger">*</span></label>
                  <div class="col-sm-3">
                    <select for="class1" id="class1" name="class1"class="class-select form-control form-control-sm align-items-center year-dropdown" required>
                        <option value="" selected disabled >--please Select--</option>
                                 <?php             
                                if(isset($myclass) && !empty($myclass)){
                              foreach($myclass as $info){
                            echo '<option value="'.$info->id. '">' . $info->class_name . '</option>'; 
                              }
                                }
                               ?>        
                               </select>

                                <div class="invalid-feedback">Class required.</div>
                   
                                                </div>
                                            </div>
           <div class="row mb-3">
          <label for="stream" class="col-sm-2 ms-3 col-form-label col-form-label-sm">Stream:<span class="text-danger">*</span></label>
                  <div class="col-sm-3">
                    <select for="stream" id="stream" name="stream"class="class-select form-control form-control-sm align-items-center year-dropdown" required>
                         <option value="" disabled readonly selected>--please Select class first--</option>
                    </select>
                    <div id="StatusMsg"></div>
                      <div class="invalid-feedback">Stream (Combination) required.</div>
                      <div id="StreamStatus"></div>
                                   </div>
                                      </div>

                                              <div class="row mb-3">

                      <label for="class" class="col-sm-2 ms-3 col-form-label col-form-label-sm"><span class="text-danger"></span></label>
                                                     <div class="col-sm-3">
                                                        <div class="d-flex justify-content-end mt-2 mb-3">

                    <button type="submit" class="btn btn-primary btn btn-lg">Load <i class="fa fa-arrow-right me-2"></i></button>
                    </div>                 </div>
                    
                                            </div>
                                        </form>
                                                <?php
        }else{
            echo '<div class="alert alert-warning text-center"> No class allocated for you</div>';
        }             
                       
        ?>
                                      
                                        <div id="NewExamResult">
                                            
                                        </div>
                                         <div id="fetchresultsFail">
                                            
                                        </div>
                                        <div id="WaitingResultsMsg">
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
    
        </div>
    </div>
</div>
<script type="text/javascript">
     $(document).ready(function() {
        $(".class-select").select2();
    });
</script>

<script>
    function populateYearDropdown(selectId) {
        let select = document.getElementById(selectId);
        if (!select) {
            console.error(`Dropdown with ID '${selectId}' not found.`);
            return;
        }

        let currentYear = new Date().getFullYear();
        let startYear = 2023;
        select.innerHTML = ""; // Clear previous options

        for (let year = currentYear + 1; year >= startYear; year--) {
            let option = document.createElement("option");
            option.value = year;
            option.textContent = year;
            if (year === currentYear) {
                option.selected = true;
            }
            select.appendChild(option);
        }
    }
    document.addEventListener("DOMContentLoaded", function () {
        populateYearDropdown("year");
        populateYearDropdown("year2");
    });
</script>

<script type="text/javascript">
   $("#year").change(function(){
     $('#fetchresultsFail').html('');
                     $('#NewExamResult').html('');
                     $('#WaitingResultsMsg').html('');
        var year = $(this).val();
        $.ajax({
            url: 'list_terms',
            type: 'post',
            data: {year:year},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#term").empty();
                $("#term").append("<option value=''>--Choose term--</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['term_name'];
                   $("#term").append("<option value='"+id+"'>"+name+"</option>");
                }

            }
        });
    });
      $("#term").change(function(){
     $('#fetchresultsFail').html('');
                     $('#NewExamResult').html('');
                     $('#WaitingResultsMsg').html('');

    });
           $("#examtype").change(function(){
     $('#fetchresultsFail').html('');
                     $('#NewExamResult').html('');
                     $('#WaitingResultsMsg').html('');

    });

        $("#class1").change(function(){
             $('#fetchresultsFail').html('');
                     $('#NewExamResult').html('');
                     $('#WaitingResultsMsg').html('');
        var clvl = $(this).val();
        $.ajax({
             url: 'list_stream',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
                   beforeSend: function()
            { $('#StreamStatus').html('');
                  $('#StreamStatusAbsent').html('');
                $('#StatusMsg').html('<span class="fa fa-spinner fa-spin"></span> Checking stream allocation status..');
            },
            success:function(response){
                     $('#StreamStatusAbsent').html('');
                     $('#StatusMsg').html('');
                var len = response.length;
                 if(len>0){
                $("#stream").empty();
                $("#stream").append("<option value='' disabled selected>Choose stream</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['stream_name'];
                     var comb = response[i]['comb_name'];
                    $("#stream").append("<option value='"+id+"'>"+name+" ("+comb+") "+"</option>");
                       
                }
             $("#StreamStatus").html("");
             }else{
                $("#stream").empty();
                $("#stream").append("<option value='' disabled selected>No subject</option>");
                $("#StreamStatus").html("<span class='text-danger'>No subject allocated to the selected class!</span>");
                 $('#fetchresultsFail').html('');
                     $('#NewExamResult').html('');
                     $('#WaitingResultsMsg').html('');
            }
             $('#fetchresultsFail').html('');
                     $('#NewExamResult').html('');
                     $('#WaitingResultsMsg').html('');
        }
        });
    });
          $('#FetchStudentsResult').submit(function (e) {
              $("#StreamStatus").html("");
            var dta = "class=" + $('#class1 option:selected').val()+ "&term="+$('#term option:selected').val()+ "&examtype="+$('#examtype option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&year="+$('#year option:selected').val()+ "&date="+$('#date').val();
                 if (!this.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
            this.classList.add("was-validated");
             }
             else{
        $('#WaitingResultsMsg').html('<span class="fa fa-spinner fa-spin"></span> Loading results fill form....');
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/fetch_my_students_Results'; ?>',
                data: dta,
                       beforeSend: function()
            { $('#StreamStatus').html('');
                  $('#StreamStatusAbsent').html('');
                $('#WaitingResultsMsg').html('<span class="fa fa-spinner fa-spin"></span> Loading results fill form....');
            },
                success: function (res) {
                    $('#NewExamResult').html(res);
                     $('#WaitingResultsMsg').html('');
                },
                error: function () {
                    $('#fetchresultsFail').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                     $('#WaitingResultsMsg').html('');
                        $('#NewExamResult').html('');
                }
            });
        e.preventDefault();
    }});

$('#date').change(function() {
    console.log("Updated Date: ", $(this).val());
});
      $('#ListExamResults').submit(function (e) {
            $('#ExamResultsList').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "year=" + $('#year2 option:selected').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/View_ExamResult_List'; ?>',
                data: dta,
                success: function (res) {
                     $('#NewExamResult').html('');
                    $('#ExamResultsList').html(res);
                },
                error: function () {
                    $('#ExamResultsList').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                     $('#NewExamResult').html('');
                }
            });
        e.preventDefault();
    });
    window.onload = function () {
        populateYearDropdown("year2");
        populateYearDropdown("year");
    };
</script>
