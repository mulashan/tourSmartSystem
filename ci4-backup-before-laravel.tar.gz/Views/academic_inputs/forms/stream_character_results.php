      <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
    <?php
 $bmodel = new App\Models\BillingModel();
  $smodel = new App\Models\StudentModel();
  $cmodel = new App\Models\ClassesModel();
?>
<?php 
 $logo = $bmodel->get_table_details('company_tbl');
  $source="";
            if($logo[0]->logo_name != ""){
               $source =  base_url('public/company_photos/'.$logo[0]->logo_name);
            }
?>
  <center>
            <div class="container">
             <div class="img"> <img src="<?php  echo $source; ?>"  style="background: white;width: 15%;height: 15%" ></div>
            <div class="mt-4"><b><?= $logo[0]->company_name; ?> </b></div>
            <div class="modify"><?= $logo[0]->address; ?></div>
            <div class="mb-3">
                <div><span class="modify">Phone: <?= $logo[0]->phone1; ?></span></div>
                <div><span class="modify">Email: <?= $logo[0]->email; ?></span></div>
                <div><span class="modify"> <?= $logo[0]->website; ?></span></div>
             
            </div>
            </div>

        </center>
                           <hr style="color:black;">

             <div class="modify text-center">
                <span><b> <?=esc($classname);?> (<?=esc($streamname);?>-<i class="text-primary"><?=esc($combname);?></i>) CHARACTER REPORT</b></span><i  style="float:right;margin-right: 80px;"><b>Date: <?php echo date('d/m/Y');?></b></i>
            </div>
              <hr style="color:black;">
    <!----------------------------------------------------------------->
    <div class="container">
      <div  class="table-responsive">
    <?php $col=count($character);?>
<table>
    <thead>
        <tr>
            <th rowspan="3">S/N</th>
            <th rowspan="3">EXAM NO.</th>
            <th rowspan="3">NAME</th>
            <th rowspan="3">SEX</th>
            <th colspan="<?=$col;?>">CHARACTER</th>
        </tr>
        <tr>
              <tr>
                     <?php
            if(isset($character)){
            foreach($character as $characters){
            ?>
                <th><?=$characters->character_code;?></th>
                <?php
                }}
            ?>
            </tr>
          
        </tr>
    </thead>
    <tbody>
    
     <?php
            if(count($students)>0){
               $i=0; 
            foreach($students as $st){
                $i++;
            ?>
        <tr>

            <td><?= $i?></td>
            <td>-</td>
            <td style="text-align: left;"><?= $st->full_name;?></td>
                <?php
            if ($st->gender=='Male') {?>
                <td> <?='M'?></td>
           <?php
            }
           elseif($st->gender=='Female'){
            ?>
             <td> <?='F'?></td>
            <?php
             
           }

                ?>
                          <?php
            if(isset($stream_record)){
                foreach ($character as $characters){
            foreach($stream_record as $records){
                if($records->student_id==$st->std_ids  && $records->character_id==$characters->character_id){
            ?>
                <td><?=$records->grade_name;?></td>
                <?php
                }}}}
            ?>

        </tr>
        <?php
     }}
        ?>
       
    </tbody>
</table>
    </div>
  </div>

