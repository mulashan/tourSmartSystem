      <style>
        table {
            width: 100%;
            border-collapse: collapse;
            white-space: nowrap;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }
   
        th {
            background-color: #ddd;
              border: 1px solid black;
             text-align: center;
         
        }
        .highlight {
               border: 1px solid black;
            background-color: #fdf1c7;
              text-align: center;
        }
     th.sub_design {
    writing-mode: vertical-rl;
    text-orientation: mixed;
    text-align: center;
     transform: rotate(180deg);
    vertical-align: middle;
    white-space: nowrap;
    padding: 1px;
    font-weight: bold;
}
    </style>
    <?php
 $bmodel = new App\Models\BillingModel();
  $smodel = new App\Models\StudentModel();
  $cmodel = new App\Models\ClassesModel();
?>
<?php 
 $logo = $bmodel->get_table_details('company_tbl');
  $source="";
            if($logo[0]->logo_name != ""){
               $source =  base_url('public/company_photos/'.$logo[0]->logo_name);
            }
?>
  <center>
            <div class="container">
             <div class="img"> <img src="<?php  echo $source; ?>"  style="background: white;width: 15%;height: 15%" ></div>
            <div class="mt-4"><b><?= $logo[0]->company_name; ?> </b></div>
            <div class="modify"><?= $logo[0]->address; ?></div>
            <div class="mb-3">
                <div><span class="modify">Phone: <?= $logo[0]->phone1; ?></span></div>
                <div><span class="modify">Email: <?= $logo[0]->email; ?></span></div>
                <div><span class="modify"> <?= $logo[0]->website; ?></span></div>
             
            </div>
            </div>

        </center>
                           <hr style="color:black;">

             <div class="modify text-center">
                <span><b> <?=esc($classname);?> (<?=esc($streamname);?>-<?=esc($combname);?>) <?=strtoupper(esc($examname));?> REPORT</b></span><i  style="float:right;margin-right: 80px;"><b>Date: <?php echo date('d/m/Y');?></b></i>
            </div>
              <hr style="color:black;">
    <!----------------------------------------------------------------->
    <div class="container">
      <div  class="table-responsive">
    <?php $col=count($subjects)*2;?>
<table>
    <thead>
        <tr>
            <th rowspan="3">S/N</th>
            <th rowspan="3">EXAM NO.</th>
            <th rowspan="3">NAME</th>
            <th rowspan="3">SEX</th>
            <th colspan="<?=$col;?>">SUBJECTS</th>
        </tr>
        <tr>
             
                     <?php
            if(isset($subjects)){
            foreach($subjects as $subject){
            ?>
                <th colspan='2' class="sub_design"><?=strtoupper($subject->subject_name);?></th>
                <?php
                }}
            ?>
           
          
        </tr>
           <tr>
                <?php 
                if (isset($subjects)) {
                    foreach ($subjects as $subject) {
                        echo "<th>MARK</th><th>GRADE</th>";
                    }
                }
                ?>
            </tr>
    </thead>
    <tbody>
    <?php
     $i = 0;
     if(isset($students)){


            foreach ($students as $student) {
                $i++;
             
            ?>
                <tr>
                    <td class="highlight"><?= $i ?></td>
                    <td class="highlight"><?= $student->exam_number ?? '-' ?></td>
                    <td class="highlight" style="text-align: left;"><?= $student->full_name ?></td>
                    <td class="highlight"><?= $student->gender == 'Male' ? 'M' : 'F' ?></td>
                  <?php foreach ($subjects as $subject): ?>
    <?php
        $found = false;
        foreach ($results as $result) {
            if ($result->student_id == $student->std_ids && $result->subject_id == $subject->subject_id) {
                $found = true;
                ?>
                <td class="highlight">&nbsp;<?= !empty($result->marks_scored) || $result->marks_scored === "0" ? $result->marks_scored : '-' ?>&nbsp;</td>
                <td class="highlight">&nbsp;<?= !empty($result->grade_name) ? $result->grade_name : '-' ?>&nbsp;</td>
                <?php
                break; // stop checking once we find the match
            }
        }
        if (!$found):
            ?>
            <td class="highlight">&nbsp;-&nbsp;</td>
            <td class="highlight">&nbsp;-&nbsp;</td>
    <?php endif; ?>
<?php endforeach; ?>


        <?php
      }}
        ?>
       
    </tbody>
</table>
    </div>
  </div>

