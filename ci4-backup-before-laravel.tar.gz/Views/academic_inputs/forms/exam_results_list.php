     <div class="table-responsive mt-3">
           <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>SN</th>
                                    <th>Exam Date</th>
                                    <th>Academic Year</th>
                                    <th>Exam Type</th>
                                    <th>Term</th>
                                    <th>Class</th>
                                     <th>Stream/Comb</th>
                                 <th>Created By</th>
                                 <th>Updated On</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
							<tbody>
							<?php
							$i=1;
							 foreach($record as $records){
								?>
								  <!--MODAL FOR DELETING THE subject-->
														<tr>
								<td> <?php echo $i;?></td>
								<td> <?php echo $records->exam_date;?></td>
                             <td >          
                            <?php echo $records->academic_year;?>
                        </td>
                         <td>
                            <?php echo$records->exam_name;?>
                                 </td> 
                        <td>
                            <?php echo$records->term_name;?>
                                 </td>                
               <td> <?php echo $records->class_name; ?>
               </td>
               <td> <?php echo $records->stream_name;?> (<?php echo $records->comb_name;?>)</td>
               <td> 
               	<?php echo $records->first_name;?> 
               	<?php echo $records->last_name;?>
               	
               </td>
               <td> <?php echo $records->updated_date;?></td>

                               
								<td>
               <a href="#" class="StremData text-light btn btn-xs btn-flat btn-primary"
    data-stream-id="<?=$records->id;?>"
    data-record-id="<?=$records->result_record_id;?>"
    data-term-id="<?=$records->term;?>"
    data-class-name="<?=$records->class_name;?>"
    data-stream-name="<?=$records->stream_name;?>"
    data-exam-name="<?=$records->exam_name;?>"
    data-comb-name="<?=$records->comb_name;?>"
    data-year-id="<?= $records->academic_year;?>"
    data-class-id="<?=$records->class;?>"><i class="fa fa-eye"></i> View</a>		
								 
						       </td>
								</tr> 
                           

							<?php
							$i++;
							}
							
							?>
							 </tbody>
                            
                        </table>
 <div class="modal fade" id="ExamListviewModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Examination Report</h5>
               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
  <div id="viewexamlist_status"></div>
                        <div id="viewexamlist"></div>
            </div>
             <div class="modal-footer">
                   <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          
        </div>
        </div>
    </div>
</div>
                      
                    </div>
                    <script>
          $('.StremData').click(function () {
             $('#ExamListviewModal').modal('show');
    var stream_id = $(this).data("stream-id");
    var term_id = $(this).data("term-id");
    var year_id = $(this).data("year-id");
    var class_id = $(this).data("class-id");
    var classname = $(this).data("class-name");
    var streamname = $(this).data("stream-name");
    var combname = $(this).data("comb-name");
    var examname = $(this).data("exam-name");
    var record_id = $(this).data("record-id");
        $('#viewexamlist_status').html(' <div class="text-primary fw-bold" id="textLoader">Loading</div>');
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/View_Exam_Result_List'; ?>',

                data: {stream_id: stream_id, term_id: term_id, year_id: year_id, class_id: class_id, classname:classname,streamname:streamname,examname:examname,record_id:record_id,combname:combname},
                     beforeSend: function () {
            $('.viewexamlist_status').html(`
                <div class="text-primary fw-bold" id="textLoader">Loading</div>
            `);
            $('.viewexamlist_status').html(`
                <div class="text-primary fw-bold" id="textLoader">Loading</div>
            `);

            let dotCount = 0;
            loadingInterval = setInterval(() => {
                dotCount = (dotCount + 1) % 6;
                let dots = '.'.repeat(dotCount);
                $('#textLoader').html(`
                    <div class="d-flex align-items-center gap-2">
                        <div class="spinner-grow spinner-grow-sm text-primary" role="status"></div>
                        <span>Loading${dots}</span>
                    </div>
                `);
            }, 500);
        },
                success: function (res) {

                    $('#viewexamlist').html(res);
                    $('#viewexamlist_status').html('');
                    
                },
                error: function () {
                    $('#viewexamlist').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                     $('#viewexamlist_status').html('');
                    
                }
            });


        e.preventDefault();
    });

                    </script>