<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
   <style>
    table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        .main-header {
            text-align: center;
            font-weight: bold;
        }

    </style>
<?php
            helper('calc');
             $bmodel = new App\Models\BillingModel();
             $smodel = new App\Models\StudentModel();
             $report = new App\Models\ReportsModel();
             $dbname=session()->get('db_name');
            $db = \Config\Database::connect($dbname);
          ?>
                    <?php
            if(!empty($exists)) {
            ?>
            <center id="update-status">
          <form id="DeleteCharacterResults" class="mt-3">
            <input type="hidden" name="class" value="<?= esc($class) ?>">
            <input type="hidden" name="stream" value="<?= esc($stream) ?>">
            <input type="hidden" name="year" value="<?= esc($year) ?>">
            <input type="hidden" name="date" value="<?= esc($date) ?>">
            <input type="hidden" name="term" value="<?= esc($term) ?>">
            

    <span class="alert alert-success"><b>Data already Saved</b> <button class="btn btn-success"> click to Allow update</button> </span>


            </form>
            </center>
            <?php
          }
            ?>
          <hr>
              <div class="card">

               <div class="table-responsive mt-3">
<div id="autosave-status"></div>
    <table id="myTable">
<?php $col=count($character);?>
     <thead>
          <tr>
                <th rowspan="3">S/N</th>
                <th rowspan="3">EXAM NO.</th>
                <th rowspan="3">COMB</th>
                <th rowspan="3">NAME OF STUDENTS</th>
                <th rowspan="3">SEX</th>
                <th colspan="<?=$col?>">CHARACTER </th>
            </tr>
            
          
            <tr>
                     <?php
            if(isset($character)){
            foreach($character as $characters){
            ?>
                <th><?=$characters->character_code;?></th>
                <?php
                }}
            ?>
            </tr>
            <tr>
                     <?php
            if(isset($character)){
            foreach($character as $characters){
            ?>
                <th><?=$characters->character_name;?></th>
                <?php
                }}
            ?>
            </tr>
            
    </thead>
    <tbody>
         <?php
            if(count($details)>0){
               $i=0; 
            foreach($details as $st){
                $i++;
            ?>
        <tr>

            <td><?= $i?></td>
            <td>-</td>
            <td><?= $st->comb_name;?></td>
            <td style="text-align: left;"><?= $st->full_name;?></td>
                <?php
            if ($st->gender=='Male') {?>
                <td> <?='M'?></td>
           <?php
            }
           elseif($st->gender=='Female'){
            ?>
             <td> <?='F'?></td>
            <?php

           }

                ?>
      
            <?php

           foreach ($character as $characters) {
            ?>

            <td>   
                         <?php
            if ($exists==true) {
            ?>

                 <select name="grade" class="GradeSave class-select form-control form-control-sm align-items-center year-dropdown" style="width: 140px;"  required
    data-student-id="<?= $st->id ?>"
    data-character-id="<?= $characters->character_id; ?>"
    data-term-id="<?= esc($term) ?>"
    data-year-id="<?= esc($year) ?>"
    data-date-id="<?= esc($date) ?>" disabled>

    
    <option value="" disabled selected>Select grade</option>

    <?php
    if (isset($grades)) {
        $saved_grade_id = null;
        foreach ($selected_char as $selected) {
            if (
                $selected->character_id == $characters->character_id &&
                $selected->academic_yr == esc($year) &&
                $selected->term == esc($term) &&
                $selected->student_id == $st->id
            ) {
                $saved_grade_id = $selected->grade_id;
                break;
            }
        }
        foreach ($grades as $grade) {
            $selected_attr = ($saved_grade_id == $grade->grade_id) ? 'selected' : '';
            echo '<option value="'.$grade->grade_id.'" '.$selected_attr.'>' . $grade->grade_name.' - ('.$grade->comments.')</option>';
        }
    }
    ?>
</select>
 <?php
                 }else{
            ?>
                         <select name="grade" class="GradeSave class-select form-control form-control-sm align-items-center year-dropdown" style="width: 140px;"  required
    data-student-id="<?= $st->id ?>"
    data-character-id="<?= $characters->character_id; ?>"
    data-term-id="<?= esc($term) ?>"
    data-year-id="<?= esc($year) ?>"
    data-date-id="<?= esc($date) ?>">

    
    <option value="" disabled selected>Select grade</option> <!-- Move this outside the loop -->

    <?php
    if (isset($grades)) {
        $saved_grade_id = null;
        foreach ($selected_char as $selected) {
            if (
                $selected->character_id == $characters->character_id &&
                $selected->academic_yr == esc($year) &&
                $selected->term == esc($term) &&
                $selected->student_id == $st->id
            ) {
                $saved_grade_id = $selected->grade_id;
                break;
            }
        }
        foreach ($grades as $grade) {
            $selected_attr = ($saved_grade_id == $grade->grade_id) ? 'selected' : '';
            echo '<option value="'.$grade->grade_id.'" '.$selected_attr.'>' . $grade->grade_name.' - ('.$grade->comments.')</option>';
        }
    }
    ?>
</select>

            <?php
          }
            ?>

             </td>
            
          <?php } ?>
        </tr>
        <?php }} ?>
    </tbody>

          </table>
      </div>
       
            <?php
              if(empty($exists)){
            ?>
              <form id="SaveCharacterResults" class="mt-3">
            <input type="hidden" name="class" value="<?= esc($class) ?>">
            <input type="hidden" name="stream" value="<?= esc($stream) ?>">
            <input type="hidden" name="year" value="<?= esc($year) ?>">
            <input type="hidden" name="date" value="<?= esc($date) ?>">
            <input type="hidden" name="term" value="<?= esc($term) ?>">
         <div id="btnstatus"></div> <button type="submit" id="createResultBtn" class="btn btn-primary float-right" disabled data-bs-toggle="tooltip" data-bs-placement="top" title="Please select all grades first!">
    <i class="fa fa-save"></i> Create Result
</button>
<span id="btnMessage" class="alert bg-danger text-white">
    <b>Please select all fields before saving!</b>
</span>


            </form>
           
            <?php
                }
            ?>
          
             <div id="showmsg"></div>
  </div>

<noscript>
    <style>
        .table-condensed{
            padding-bottom: 20px; 

        }
        table.table{
            border: 1px solid black;
            width:80%;
          
            margin-left: auto;
            margin-right: auto;
/*            page-break-inside: avoid;*/
           
        }
         table.table td{
         border:1px solid black;
           font-size: 12px;
         }
        #myTable td,#myTable th{
            border:1px solid black;
           font-size: 12px;
           }
        h6{
            text-align: center;
        }
        .btnp,.viewbtn{
           display: none;
        }
        #myTable_wrapper .dataTables_filter,
        #myTable_wrapper .dataTables_paginate,
        #myTable_wrapper .dataTables_length {
         display: none;
}
 @media print {
      .table {
        border-collapse: collapse !important;
        border: 1px solid black !important;
      }
      }
      table.toba td{
        font-size: 12px;
      }
        
    </style> 
</noscript>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
  <script>
//    $(document).ready(function() {
//   var table = $("#myTable").DataTable({
//     dom: 'f', // Show only the search input
//     paging: false, // Disable pagination
//     lengthChange: false, // Disable entries select
//   });
// });


$(document).off("blur", ".GradeSave").on("blur", ".GradeSave", function() { 
    var student_id = $(this).data("student-id");
    var character_id = $(this).data("character-id");
    var term_id = $(this).data("term-id");
    var year_id = $(this).data("year-id");
    var date_id = $(this).data("date-id");
    var grade_id = $(this).val();

    $.ajax({
        url: "<?= base_url('SaveCharacter') ?>",
        type: "POST",
        data: {student_id: student_id, character_id: character_id, grade_id: grade_id, term_id: term_id, year_id: year_id, date_id: date_id},
        success: function(response) {
            $("#autosave-status")
                .stop(true, true)
                .html("<span class='text-success'>Saved successfully!</span>")
                .show()
                .delay(6000)
                .fadeOut();
        },
        error: function() {
            $("#autosave-status")
                .stop(true, true)
                .html("<span class='text-danger'>Error saving data!</span>")
                .show();
        }
    });
});



  $('#SaveCharacterResults').submit(function (e) {
     e.preventDefault();
   var formData = $(this).serialize();
    $.ajax({
        url: "<?= base_url('save_character_record') ?>",
        type: "POST",
        data:formData,
      success:function(response){
             $('#showmsg').html(response); 
                setTimeout(function(){
            window.location.reload();
        },1000)
            },
        error: function() {
            $("#autosave-status")
                .stop(true, true)
                .html("<span class='text-danger'>Error saving data!</span>")
                .show();
        }
    });
});

    $('#DeleteCharacterResults').submit(function (e) {
     e.preventDefault();
   var formData = $(this).serialize();
    $.ajax({
        url: "<?= base_url('delete_character_record') ?>",
        type: "POST",
        data:formData,
      success:function(response){
    $("#update-status")
                .stop(true, true)
                .html("<span class='alert alert-success'><b>Update allowed successfully!</b> click <b>Load</b> button above to refresh data</span>")
                .show()
                .delay(10000)
                .fadeOut();
                $("html, body").animate({ scrollTop: 0 }, "slow");
            },
        error: function() {
            $("#update-status")
                .stop(true, true)
                .html("<span class='text-danger'>Error saving data!</span>")
                .show();
        }
    });
});

$(document).ready(function () {
    $(".GradeSave").on("change", function () {
        if ($(this).val()) {
            $(this).removeClass("border-danger bg-danger").addClass("border-success");
        } else {
            $(this).removeClass("border-success").addClass("border-danger bg-light");
        }
    });
    $(".GradeSave").each(function () {
        if ($(this).val()) {
            $(this).addClass("border-success");
        } else {
            $(this).addClass("border-danger bg-light");
        }
    });
});



$(document).ready(function () {
    function checkDropdowns() {
        let allFilled = true;
        $(".GradeSave").each(function () {
            if (!$(this).val()) {
                allFilled = false;
                return false;
            }
        });

        if (allFilled) {
            $("#createResultBtn").prop("disabled", false).attr("title", "Click to create results!").removeClass("btn-primary").addClass("btn-success");
             $("#btnMessage").hide();
        } else {
            $("#createResultBtn").prop("disabled", true).attr("title", "Please select all grades first!").removeClass("btn-success").addClass("btn-secondary");
              $("#btnMessage").show();

        }
    }

    $(".GradeSave").on("change", checkDropdowns);
    checkDropdowns();
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});


  </script>
