<?php 
	helper('age');
	$pmodel = new App\Models\ParentModel();
?>
<table class="table table-hover table-vcenter mb-0 text-nowrap">
	<thead>
		<tr>
			<th>Reg No:</th>
			<th>Student Name</th>
			<th>Gender</th>
			<th>Birth Date</th>
			<th>Age</th>
			<th>Class</th>
		</tr>
	</thead>
	<tbody>
		<?php 
			foreach($parentInfo as $st){
			$student = $pmodel->get_parent_information('students', $where = array('id' => $st->student_id));
			$adm = $pmodel->get_parent_information('admission_tbl', $where = array('student_id' => $student[0]->id));
			$classid ="";
			if(count($adm) > 0){
				$classid = $adm[0]->class_id;
			}
			$class = $pmodel->get_parent_information('classes_tbl', $where = array('id' => $classid));
		?>
		<tr>
			<td><?= $st->student_id; ?></td>
			<td><?= $student[0]->full_name; ?></td>
			<td><?= $student[0]->gender; ?></td>
			<td><?= $student[0]->birth_date; ?></td>
			<td><?= findAge($student[0]->birth_date); ?></td>
			<td><?= count($class)>0?$class[0]->class_name:'Not Assigned';?></td>
		</tr>
		<?php } ?>
	</tbody>
</table>