<?php 
    $bmodel = new App\Models\BillingModel();
    $pmodel = new App\Models\ParentModel();

    $parentDtls = $pmodel->get_parentstable_details();
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Parents</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                        <?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
                    </a></li>
                    <li class="breadcrumb-item active" aria-current="page">Parents</li>
                </ol>
            </div>
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#parent-all">Parents List</a></li>
            </ul>
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="parent-all">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                    <th>No#</th>
                                    <th>Parent Name</th>
                                    <th>Address</th>
                                    <th>Phone No.</th>
                                    <th>No of Student</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $sn = 1;
                                     foreach ($parentDtls as $p): 
                                    $student_total = $pmodel->get_totalNumberof_student($p->id);
                                ?>
                                    <tr>
                                        <td><?= $sn++; ?></td>
                                        <td><?= $p->full_name; ?></td>
                                        <td><?= $p->address; ?></td>
                                        <td><?= $p->phone1; ?></td>
                                        <td><?= $student_total[0]->student_id; ?></td>
                                        <td>
                                            <a href="javascript:void(0)"  class="btn btn-primary btn-sm invoiceprint" data-bs-toggle="modal" data-bs-target="#viewParent" onclick="manage_parent(<?= $p->id;?>)"><i class="fa fa-eye"></i> View</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- --------------VIEW PARENT DETAILS------------- -->
<div class="modal fade" id="viewParent" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5>Parent Student Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewParent_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
    function manage_parent(pID){        
        $('#viewParent_content').load('view_parent/'+pID);
    }
</script>
