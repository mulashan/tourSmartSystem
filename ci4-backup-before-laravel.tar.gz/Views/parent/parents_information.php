<?php 
 $dbname=session()->get('db_name');
    $db = \Config\Database::connect($dbname);
    $names= $db->query('SELECT * FROM parents_tbl WHERE `first_name`LIKE \'%'.$search.'%\' OR`last_name`LIKE \'%'.$search.'%\' OR`full_name`LIKE \'%'.$search.'%\'');
    $result = $names->getResult();

    if(count($result) > 0){
    	// if($result[0]->bill_account == 0){
?>
<table class="table table-hover table striped">
    <thead>
        <tr>
            <!-- <th>No#</th> -->
            <th>Name</th>
            <th>Phone No</th>
            <th>Email</th>
            <th>Occupation</th>
            <th>Address</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody id="selectParent">
       <?php foreach($result as$r){ if($r->bill_account == 0){ ?>
       	<tr>
       		<td><?= $r->full_name; ?></td>
       		<td><?= $r->phone1; ?></td>
       		<td><?= $r->email; ?></td>
       		<td><?= $r->occupation; ?></td>
       		<td><?= $r->address;?></td>
       		<td><button class="btn btn-primary" type="button" onclick="saveParentInfo('<?= $r->id;?>','<?= $studentID;?>')"><i class="fa fa-plus"></i> Select</button></td>
       	</tr>
       <?php }} ?>
    </tbody>
</table>
<?php }else{ echo '<b class="d-flex justify-content-center">No Data Found</b>';} ?>