<form id="parent_dtls">
        <div class="row">
            <div class="col-md-6">
                <div class="row mb-3">
                    <label for="pname" class="col-sm-4 col-form-label col-form-label-sm">First Name<span class="text-danger">*</span></label>
                    <div class="col-sm-6">
                        <input type="hidden" class="form-control" id="parentId" name="parentid" value="" >
                        <input type="hidden" class="form-control" id="studentid" name="studentid"  value="<?= $id; ?>">
                        <input type="text" class="form-control form-control-sm" id="pname" name="pname" placeholder="First Name" required="">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="plname" class="col-sm-4 col-form-label col-form-label-sm">Last Name<span class="text-danger">*</span></label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control form-control-sm" id="plname" name="plname" placeholder="Last Name" required="">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="rltn" class="col-sm-4 col-form-label col-form-label-sm">Relation<span class="text-danger">*</span></label>
                    <div class="col-sm-6">
                        <select id="rltn" name="rltn" class="form-select form-control form-control-sm" required="">
                            <option value="">Choose</option>
                            <option value="1">Mother</option>
                            <option value="2">Father</option>
                            <option value="3">Guardian</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="email" class="col-sm-4 col-form-label col-form-label-sm">Email</label>
                    <div class="col-sm-6">
                        <input type="email" class="form-control form-control-sm" id="email" name="email" placeholder="eg: example@gmail.com" required="">
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row mb-3">
                    <label for="addrs" class="col-sm-4 col-form-label col-form-label-sm">Address<span class="text-danger">*</span></label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control form-control-sm" id="addrs" name="addrs" placeholder="Home Address" required="">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="occp" class="col-sm-4 col-form-label col-form-label-sm">Occupation<span class="text-danger">*</span></label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control form-control-sm" id="occp" name="occp" placeholder="Occupation" required="">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="phone1" class="col-sm-4 col-form-label col-form-label-sm">Phone Number 1<span class="text-danger">*</span></label>
                    <div class="col-sm-6">
                        <input type="tel" class="form-control form-control-sm" id="phone1" name="phone1" placeholder="+255-xxx-xxx-xxx" value="255" size="20" minlength="9" maxlength="13" required autocomplete="off" data-inputmask="'mask': '999-999999999'">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="phone2" class="col-sm-4 col-form-label col-form-label-sm">Phone Number 2</label>
                    <div class="col-sm-6">
                        <input type="tel" class="form-control form-control-sm" id="phone2" name="phone2" placeholder="+255-xxx-xxx-xxx" value="255" size="20" minlength="9" maxlength="13" required autocomplete="off" data-inputmask="'mask': '999-999999999'">
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-end mt-2 mb-3">
                <button type="button" class="btn btn-primary" onclick="register_parent()" id="submitparent"><i class="fa fa-plus me-2"></i>Add</button>
                <button type="button" class="btn btn-primary" onclick="update_parent_dts()" id="Updateparent"><i class="fa fa-edit" ></i> Update</button>
            </div>
        </div>
</form>
<script type="text/javascript">
        $(document).ready(function(){ 
    $(":input").inputmask();     
});
        $('#Updateparent').hide();
        
         function register_parent(){
      alert($('#parent_dtls').serialize());
    $.ajax({
        beforeSend: function () {
            $('#submitparent').prop("disabled", false);
        },
        type: "POST",
        url: 'save_parent',
        data: $('#parent_dtls').serialize(),
        success: function (res) {
            $('#submitparent').prop("disabled", false);
            var data = JSON.parse(res);
            if(data['status'] == "0"){
             $('#parent_dtls')[0].reset();
             $('#show_parent').load('show_parent1/'+  $('#studentid').val()); 
         }
         else{
          $('#RegFedbck').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
      }             
  },
  error: function () {
    $('#submitparent').prop("disabled", false);
    $('#errorshow_parent').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
}
});  
}
</script>