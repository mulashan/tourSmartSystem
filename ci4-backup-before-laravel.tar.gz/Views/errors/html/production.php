<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="robots" content="noindex">

    <title>Whoops!</title>

    <style type="text/css">
        <?= preg_replace('#[\r\n\t ]+#', ' ', file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . 'debug.css')) ?>
    </style>
</head>
<body>

    <div class="container text-center">

        <h1 class="headline">Something went wrong!</h1>

        <p class="lead">econnect is experiencing a problem that is preventing this request from being successful. Rest assured that we are aware and are working to fix it as quickly as possible. Alternatively, you're welcome to raise an issue with our support team at https://www.microhealthinitiative.org/.</p>

    </div>

</body>

</html>
