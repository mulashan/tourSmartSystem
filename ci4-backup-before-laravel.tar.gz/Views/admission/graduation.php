<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 
    helper('age');
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();

   // $student = $smodel->gettable_data('students', $where = array('status' => 1));
    $classes = $smodel->gettable_data('classes_tbl', $where = array('status' => 1));

?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Admission</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Student Graduation</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
            <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#adm-add"> Graduation List</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#Admsn-all">New Graduation</a></li>
                
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                  <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#adm-add">Graduations List</a></li>
                 <li></li><li></li>
               <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#Admsn-all">New Graduation</a></li>
            </ul>
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
             <div class="tab-pane active" id="adm-add">
               <div class="d-flex justify-content-center">
                    <form id="graduated" class="form-inline">
                     <div class="me-3">
                            Academic year: 
                           <select id="year2" name="year2" class="form-select form-control">
                      <!-- JavaScript loop to generate year options -->
                      <script>
                        const currentYear = new Date().getFullYear();
                        const startYear = 2023; // Change this to set a different start year
                        for (let year = currentYear+1; year >= startYear; year--) {
                            if(year==currentYear){
                            document.write(`<option value="${year}" selected>${year}</option>`);
                            }else{
                            document.write(`<option value="${year}">${year}</option>`);    
                            }
                        
                        }
                      </script>
                    </select>
                        </div>

                         <div class="me-3">
                            Class:  
                    <select id="class1" class="form-select form-control">
                        <option value="0" selected>All</option>
                     <?php foreach ($classes as $value) {
                        ?>
                    <option value="<?php echo $value->id;?>"><?php echo $value->class_name;?></option>
                    <?php  }?>
                    </select>
                </div>
                     <button type="submit" class="btn btn-primary">Create</button>
                        </form>
                        </div>
                        <hr>
                &nbsp; 
                     <center>
                    <div id="graduation_results" class="mt-4"></div>
                </center> 
            </div>
            <div class="tab-pane" id="Admsn-all">
               
                <div class="d-flex justify-content-center">
                 <div id="continous" style="">
                    <form id="continue" class="form-inline">
                     <div class="me-3">
                            From Academic year: 
                           <select id="cyear" name="cyear" class="form-select form-control">
                      <!-- JavaScript loop to generate year options -->
                      <script>
                     
                        for (let year = currentYear+1; year >= startYear; year--) {
                            if(year==currentYear){
                            document.write(`<option value="${year}" selected>${year}</option>`);
                            }else{
                            document.write(`<option value="${year}">${year}</option>`);    
                            }
                        
                        }
                      </script>
                    </select>
                       </div>

                      <div class="me-3">
                           From  Class:  
                    <select id="class_list" class="form-select form-control">
                        <option value="" selected>-select-</option>
                        <?php foreach ($classes as $value) {
                        ?>
                        <option value="<?php echo $value->id;?>"><?php echo $value->class_name;?></option>
                    <?php  }?>
                    </select>
                </div>
                        
                     <!-- <button type="submit" class="btn btn-primary">Load</button> -->
                        </form>
                        </div>
                        </div>
                        <hr>
                &nbsp; 
                     <center>
                    <div id="pending_results" class="mt-1"></div>
                </center> 
            </div>

           
        </div>
    </div>
</div>

<!-- ------Admit modal------ -->
<div id="myModal" class="modal fade"  role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <!-- <h5 class="modal-title" id="staticBackdropLabel">Student Admission Details</h5> -->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div id="admission"></div>
        </div>
      </div>
      
    </div>
</div>


<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
   
$("#closeAdmissionYearForm").submit(function(e) {
        var data = $(this).serialize();
        swal({
            title: "Are you sure?",
            text: "You are about to Close This Academic Year.",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, Close!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
        },
        function(isConfirm) {
            if (isConfirm) {
                $.ajax({
                    method: 'POST',
                    url: 'close_academic_year',
                    data: data,
                    error: function() {
                    alert('Something is wrong');
                    },
                    success: function(data) {
                        if(data == 1){
                            swal("Academic Year Closed!", "success");
                        }else{
                            alert('Something is wrong');
                        }    
                        setTimeout(function(){
                            window.location.reload();
                        },1000)
                    }
                });

            } else {
                swal("Cancelled");
            }
        });
        e.preventDefault();
    });

    function manage_admission(adm){
        $('#viewadmission').modal('show'); 
        $('#viewadmission_content').load('view_admissions/'+adm);
    }
    $('#pending').submit(function (e) {
            
            $('#pending_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "year=" + $('#year option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_pending'; ?>',
                data: dta,
                success: function (res) {
                    $('#pending_results').html(res);
                },
                error: function () {
                    $('#pending_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
      $('#graduated').submit(function (e) {
            
            $('#graduation_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "year=" + $('#year2 option:selected').val()+"&class=" + $('#class1 option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_graduations'; ?>',
                data: dta,
                success: function (res) {
                    $('#graduation_results').html(res);
                },
                error: function () {
                    $('#graduation_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });

  $('#pendType').change(function(){
    var val= $('#pendType').val();
     if(val==1){
    $('#newComer').hide();
    $('#pending_results').html('');
    $('#continous').show();
     }else if(val==2){
        $('#continue')[0].reset();
           $('#continous').hide();
           $('#pending_results').html('');
        $('#newComer').show();
     }else{
            $('#continue')[0].reset();
           $('#continous').hide();
           $('#pending_results').html('');
        $('#newComer').hide(); 
     }
      });

  $('#class_list').change(function (e) {
         if($('#class_list option:selected').val()==""){
           swal('warning','please select class','warning');
           //return;
         }else{
            
            $('#pending_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "year=" + $('#cyear option:selected').val()+'&class='+ $('#class_list option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_class_graduators'; ?>',
                data: dta,
                success: function (res) {
                    $('#pending_results').html(res);
                },
                error: function () {
                    $('#pending_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    
    });
   $('#cyear').change(function (e) {
         if($('#class_list option:selected').val()==""){
         
           //return;
         }else{
            
            $('#pending_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "year=" + $('#cyear option:selected').val()+'&class='+ $('#class_list option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_class_graduators'; ?>',
                data: dta,
                success: function (res) {
                    $('#pending_results').html(res);
                },
                error: function () {
                    $('#pending_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    
    });
</script>