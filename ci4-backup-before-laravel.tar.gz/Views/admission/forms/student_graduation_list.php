  <?php 
    helper('age');
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();

    $cls = $smodel->gettable_data('classes_tbl', $where = array('status' => 1));
     //print_r($admission);

?>
                <div class="card">
                    <form id="">
                        <div class="table-responsive mt-3">
                            <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable2">
                                <thead>
                                    <tr>
                                        <th>Batch no</th>
                                        <th>Grad date</th>
                                        <th>Acdmc yr</th>
                                       <th>Level</th>
                                        <th>Class</th>
                                        <th>grdts No</th>
                                        <th>Created by</th>
                                        <th>Created date</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $j=1;
                                    foreach ($cls as $key) {
                                        if($j==0){
                                            break;
                                        }
                                        if($class==0){
                                     $graduates = $smodel->gettable_data('graduation_tbl', $where = array('class' => $key->id,'graduation_year'=>$year));  
                                     }else{
                                       $graduates = $smodel->gettable_data('graduation_tbl', $where = array('class' => $class,'graduation_year'=>$year));
                                       $j=0;      
                                     }   
                                    
                                   if(count($graduates)>0) {
                                    $adm = $smodel->gettable_data('admission_tbl', $where = array('class_id' => $graduates[0]->class,'academic_year'=>$year));
                                   
                                    $level = $smodel->gettable_data('class_level_tbl', $where = array('id' => $adm[0]->level_id));
                                   $cl = $smodel->gettable_data('classes_tbl', $where = array('id' =>  $graduates[0]->class));
                                    $tby = $smodel->gettable_data('users', $where = array('user_id' => $graduates[0]->created_by));
                                        ?>
                                      <tr>
                                 <td><?php echo $graduates[0]->graduation_number;?></td>   
                                 <td><?php echo $graduates[0]->graduation_date;?></td>   
                                  <td><?php echo $year;?></td>   
                                 <td><?php echo $level[0]->level_name;?></td>   
                                 <td><?php echo $cl[0]->class_name;?></td>   
                                 <td><?php echo count($graduates);?></td>   
                                 <td><?php echo  $tby[0]->first_name;?></td>   
                                 <td><?php echo  $graduates[0]->date_created;?></td> <td> 
                                    <a href="javascript:void(0)" onclick="editGraduation(<?php echo $year;?>,<?php echo $graduates[0]->class;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a> 
                                    <a href="javascript:void(0)" onclick="viewGraduation(<?php echo $year;?>,<?php echo $graduates[0]->class;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a> </td>
                                     </tr>
                                        <?php
                                    } 
                                }
                                    ?>
                                       
                                    <?php ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- <input type="hidden" name="total_admitted" value="<?php //$sn; ?>">
                        <button type="submit" class="btn btn-primary float-right mb-3 me-3">Close Academic Year</button> -->
                    </form>
                </div>

    <div class="modal fade" id="viewGradu" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="graduation_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('graduation_content')"><i class="fa fa-print"></i> Print</button> -->
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="editGradu" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="editGradu_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         
      </div>
    </div>
  </div>
</div>
                <script type="text/javascript">
                  $(document).ready(function () {
                  $('#myTable2').DataTable();
                });

   function viewGraduation(yr,clas){
// alert(yr+'/'+clas);
  $('#viewGradu').modal('show');
   $('#graduation_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>'); 
      $('#graduation_content').load('index.php/SemisterController/view_graduation/'+yr+'/'+clas);
   }
   function editGraduation(yr,clas){
    $('#editGradu').modal('show');
   $('#editGradu_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>'); 
      $('#editGradu_content').load('index.php/SemisterController/edit_graduation/'+yr+'/'+clas);
   }
                </script>