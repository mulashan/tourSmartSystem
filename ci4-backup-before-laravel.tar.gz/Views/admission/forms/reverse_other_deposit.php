<form id="popup_form">
  <div class="form-group row">
<label for="" class="col-sm-4 col-form-label">Deposit No<span class="text-danger">*</span></label>
<div class="col-sm-8">
<div class="input-group mb-3">
    
    <input type="text" class="form-control" name="receipt_name" id="receipt_name"   placeholder="Search Deposit Number" aria-label="Customer Name" aria-describedby="button-addon7">
    <button class="btn btn-outline-primary" type="button" id="button-addon7" onclick="search_receipt()"><i class="fa fa-search" aria-hidden="true"></i></button>
</div>
   </div>
   </div>
    <div id="rct_details"></div>
    </form>
     <button class="btn btn-warning pull-left" onclick="closePopup_transfer()">Cancel</button>
         <button type="button" class="btn btn-primary pull-right"  onclick="save_amount3('event')" style="display: none;" id="sv_amt3">
             Save
        </button>
   <script type="text/javascript">
        function search_receipt(){
        if($('#receipt_name').val() == ""){
          swal("warning","Please Enter Receipt Number","warning"); 
       }else{
            var paydata ="payer_name=" + $('#receipt_name').val();
          // alert(paydata);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/SemisterController/search_transaction3'; ?>',
                beforeSend: function () {
                    $('#rct_details').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#rct_details').html(result); 
                 //  $('#other_invoice').show(); 
                 // $('#invoice_row').show();
                 // $('#div_row').show();
                },
                error: function () {
                    $('#rct_details').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
      }
      function enter_amount() {
        var am=parseInt($('#i_amount').val());
        var rc=parseInt($('#deposit_amount').val());

        if(am >0){
         if(am > rc){
      var numberAsString = am.toString();

    // Remove the last character
    var resultAsString = numberAsString.slice(0, -1);

    // Convert the result back to a number
    var resultAsNumber = parseInt(resultAsString, 10);
           
            $('input[name=amount]').val(resultAsNumber);
           // alert(resultAsNumber+'>'+rc);
         swal('warning','Enter amount less or equal to '+rc+'','warning');
        }else{
           $('#sv_amt3').show();
       }
        } else{
   
       $('#sv_amt3').hide();
    }
}

   </script>
