  <?php 
    helper('age');
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();

    $cls = $smodel->gettable_data('classes_tbl', $where = array('status' => 1));
     //print_r($admission);

?>
                <div class="card">
                    <form id="">
                        <div class="table-responsive mt-3">
                            <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable2">
                                <thead>
                                    <tr>
                                        <th>batch no</th>
                                        <!-- <th>Abscond date</th> -->
                                        <th>Acdmc yr</th>
                                       <th>Level</th>
                                        <th>Class</th>
                                        <th>total</th>
                                        <th>Created by</th>
                                        <th>Created date</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $j=1;
                                    foreach ($cls as $key) {
                                        if($j==0){
                                            break;
                                        }
                                        if($class==0){
                                     $abs = $smodel->gettable_data_groupBy('transfered_students_tbl', $where = array('class' => $key->id,'academic_year'=>$year),'batch_no');  
                                     }else{
                                       $abs = $smodel->gettable_data_groupBy('transfered_students_tbl', $where = array('class' => $class,'academic_year'=>$year),'batch_no');
                                      // print_r($abs);
                                       $j=0;      
                                     }   
                                    
                                   if(count($abs)>0) {
                                    foreach($abs as $ab){
                                     $ttl = $smodel->gettable_data('transfered_students_tbl', $where = array('class' => $ab->class,'academic_year'=>$year,'batch_no'=>$ab->batch_no));
                                    $adm = $smodel->gettable_data('admission_tbl', $where = array('class_id' => $ab->class,'academic_year'=>$year));
                                   
                                    $level = $smodel->gettable_data('class_level_tbl', $where = array('id' => $adm[0]->level_id));
                                   $cl = $smodel->gettable_data('classes_tbl', $where = array('id' =>  $ab->class));
                                    $tby = $smodel->gettable_data('users', $where = array('user_id' => $ab->created_by));
                                        ?>
                                      <tr>
                                 <td><?php echo $ab->batch_no;?></td>   
                               
                                  <td><?php echo $year;?></td>   
                                 <td><?php echo $level[0]->level_name;?></td>   
                                 <td><?php echo $cl[0]->class_name;?></td>   
                                 <td><?php echo count($ttl);?></td>   
                                 <td><?php echo  $tby[0]->first_name;?></td>   
                                 <td><?php echo  $ab->date_created;?></td> <td> 
                                    <a href="javascript:void(0)" onclick="editAbsconded(<?php echo $year;?>,<?php echo $ab->class;?>,<?php echo $ab->batch_no;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a> 
                                    <a href="javascript:void(0)" onclick="view_notShow(<?php echo $year;?>,<?php echo $ab->class;?>,<?php echo $ab->batch_no;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a> </td>
                                     </tr>
                                        <?php
                                    }
                                    } 
                                }
                                    ?>
                                       
                                    <?php ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- <input type="hidden" name="total_admitted" value="<?php //$sn; ?>">
                        <button type="submit" class="btn btn-primary float-right mb-3 me-3">Close Academic Year</button> -->
                    </form>
                </div>

    <div class="modal fade" id="viewAbscond" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="abscond_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('graduation_content')"><i class="fa fa-print"></i> Print</button> -->
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="editAbscond" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="editabscond_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         
      </div>
    </div>
  </div>
</div>
                <script type="text/javascript">
                  $(document).ready(function () {
                  $('#myTable2').DataTable();
                });

   function view_notShow(yr,clas,ent){
// alert(yr+'/'+clas);
  $('#viewAbscond').modal('show');
   $('#abscond_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>'); 
      $('#abscond_content').load('index.php/SemisterController/view_transfered/'+yr+'/'+clas+'/'+ent);
   }
   function editAbsconded(yr,clas,ent){
    $('#editAbscond').modal('show');
   $('#editabscond_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>'); 
      $('#editabscond_content').load('index.php/SemisterController/edit_transfered/'+yr+'/'+clas+'/'+ent);
   }
                </script>