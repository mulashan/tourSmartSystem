 <?php 
    helper('age');
      helper('calc');
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();

 
    // $sadm = $amodel->get_student_details('admission_tbl', $where = array('academic_year'=>$year,'class_id'=>$classId));
    //    $student = $smodel->gettable_data('students', $where = array('status' => 2));
    // $clas = $smodel->gettable_data('classes_tbl', $where = array('id'=>$classId,'status' => 1));
    $date='10/10/'.$year;
 $date=date("Y-m-d",strtotime($date));
 //echo $classId;
?>
           <form id="absconding_details" class="form-inline">
 <div class="card">
          <div class="d-flex justify-content-center mt-3 mb-3">
                  
                         Academic year: <?php echo $year; ?>
                         <div class="input-group ms-3 me-5">
                             <input type="hidden" name="Academic_year" value="<?php echo $year;?>">
                        </div>
                        Absconded date:
                        <div class="input-group ms-3 me-3">
                        <input type="date" name="admission_date" value="<?php echo $date; ?>" class="form-control">
                        </div>
                        <div class="input-group ms-3 me-5">
                        </div>
                      Absconded class: <?php echo $clas[0]->class_name;?>
                        <input type="hidden" name="class" value="<?php echo $clas[0]->id;?>">
                        <input type="hidden" name="class_level" value="<?php echo $clas[0]->class_level;?>">
                 
                        <div class="input-group ms-3 me-5">
                        </div>
            
                 <?php 
                        ?>
                      <button type="button" id="saveAdmission" onclick="save_absconding()" class="btn btn-primary btn-lg pull-right "><i class=""> </i> Create</button>
                        <?php
                      
                    
                     ?>
                            </div>
                            <!--------------------------------------------------->
  
                              </div>
                              <?php
                                
                              ?>
 
                    <div class="card">
                         
                    <div class="table-responsive mt-1">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                     <td> <input type="checkbox" name="" value="" onclick="Allcheckbox()" id="Allselected"> All</td>
                                    <th>Acdmc Yr</th>
                                    <th>Names</th>
                                    <th>Level</th>
                                    <th>Class</th>
                                    <th>Stream/Comb</th>
                                    <th>Gender</th>
                                    <th>Type</th>
                                    <th>For</th>
                                    <th>Balance</th>
                                   
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $class = "";
                                $row ="";
                                $i=0;
                                //$lastYr=$year-1;
                                $holid_student=array();
                            // print_r($sadm);
                            foreach ($sadm as $st){
                                $details= $smodel->gettable_data('students', $where = array('id' => $st->student_id,'status'=>2));
                               //print_r($details);
                                $y=date('Y');
                                $dbname=session()->get('db_name');

                                try {
                               $results=findCalc($st->student_id,$dbname,$year);
                            
                            if(empty($results)){
                                continue;
                            }
                            $todaybalance=0;
                            foreach ($results as $k) {
                            
                             if($k['today']==1){
                       $todaybalance=$k['todaybalance']; 
                               }
                           }
                           }catch (Exception $e) {
                         $todaybalance="0-0";
                           }

                                if(count($details)>0){
                                 foreach ($details as $dt){

                                    //getting streams
                               // $stream_res= $smodel->gettable_data('streams_tbl', $where = array('id' => $st->stream_id));
                                $stream_results= $smodel->gettable_data('streams_tbl', $where = array('id' => $st->stream_id));
                                  $comb= $amodel->get_stream_comb_allocatiion($st->stream_id);
                                    if($st->admission_type==0){
                                        $adType='Day';
                                    }else{
                                     $adType='Boarding';   
                                    }

                                    if($st->adimit_for==0){
                                        $admFor='Continous';
                                    }else{
                                     $admFor='New Comer';   
                                    }
                                
                                
                                     $i++;
                                        $row = 'color:#27af50';
                                    $level = $smodel->gettable_data('class_level_tbl', $where = array('id'=>$st->level_id,'status' => 1));
                                     $className = $smodel->gettable_data('classes_tbl', $where = array('id'=>$st->class_id,'status' => 1));  
                                      $stream = $smodel->gettable_data('streams_tbl', $where = array('id'=>$st->stream_id,'status' => 1)); 
                                      
                                ///////end///////////////
                      
                                    $holid_student[]=array($st->id);
                                  
                         
                                 ?>
                      <?php
                     // }else{?>
                        <input type="hidden" name="sid<?php echo $st->id; ?>" value="<?php echo $dt->id;?>">
                    
                                     <tr style="<?php echo $row;?>" onclick="selectRow('<?php echo $st->id; ?>')" id="<?php echo $st->id; ?>">
                                         <td><?= $i;?></td>
                                        <td>  <input type="checkbox" name="selected[]" value="<?php echo $st->id; ?>" onclick="checkbox('<?php echo $st->id; ?>')" id="selected<?php echo $st->id; ?>"></td>
                                       
                                       <td><?= $st->academic_year;?></td>
                                        <td><?= $dt->first_name.' '. $dt->middle_name.' '.$dt->last_name;?></td>
                                        <td><?= $level[0]->level_name;?></td>
                                         <td><?= $className[0]->class_name;?></td>
                                         <td><?= $stream[0]->stream_name;?>
                                         <?php if (isset($comb[0])): ?>
                                            (<?= $comb[0]->comb_name; ?>)
                                            <?php else: ?>
                                            (no comb)
                                            <?php endif; ?></td>
                                         <td><?= $dt->gender;?></td>
                                         <td><?= $adType;?></td>
                                         <td><?= $admFor;?></td>
                                         <td><?= number_format($todaybalance);?></td>
                                     </tr> 
                                <?php 
                                    }
                                    }
                                }
                           // }
                                 ?>
                            </tbody>
                        </table>
                    </div>
                    </form>
         <div class="row mb-12 me-3 mt-3">
    <div class="col-sm-4"></div>
    <div class="col-sm-2 offset-sm-6">
        
         
                </div>
                </div>
                <script type="text/javascript">
    // $(document).ready(function () {
    //   $('#myTable').DataTable();
    // });
   
    function save_absconding() {
          var data=$('#absconding_details').serialize()+'&'+$('#header_form').serialize();
             // alert(data);
             // return;
            $.ajax({
                type: "POST",
              url: '<?php echo base_url() . '/index.php/SemisterController/save_absconding_class'; ?>',
                data: data,
                success: function (res) {
                    refreshPage();
                    if(res){
                      
                         swal('success','Students saved successfuly','success');
                         
                    }else{
                        swal('error','something went wrong','error'); 
                    }
                
                },
                error: function () {
                    alert('something went wrong');
                }
            });
        };
      function refreshPage(){
        $('#pending_results').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
        var dta = "year=" + $('#cyear option:selected').val()+'&class='+ $('#class_list option:selected').val();
         // alert(dta);
         $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_class_absconding'; ?>',
                data: dta,
                success: function (res) {
                    $('#pending_results').html(res);
                },
                error: function () {
                    $('#pending_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
      }

      function selectRow(id){
         var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {
    row.style.backgroundColor = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {

    row.style.backgroundColor = 'black';
  } else {
    console.error("Invalid row ID");
  }  
        }
      
      }
      function checkbox(id){
        var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {

    row.style.backgroundColor = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {
    row.style.backgroundColor = 'black';
  } else {
    console.error("Invalid row ID");
  }  
        } 
      }
      function Allcheckbox(){
        var values=<?php echo json_encode($holid_student);?>;
        //alert(values.length);
        var rememberAll = document.getElementById("Allselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
            if(rememberAll.checked){
     remember.checked=true;  
      if (row) {
    
    row.style.backgroundColor = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=false; 
      
       if (row) {
      row.style.backgroundColor = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        }
        }
      }
</script>