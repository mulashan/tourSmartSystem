  <?php 
    helper('age');
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();

    //$student = $smodel->gettable_data('students', $where = array('status' => 1));
    $abs = $smodel->gettable_data('student_not_show_tbl', $where = array('class' => $class,'academic_year'=>$year,'batch_no'=>$ent));
    // $adms = $smodel->gettable_data('admission_tbl', $where = array('id' => $vl->adm_id));
 $cls = $smodel->gettable_data('classes_tbl', $where = array('id' => $class));
    //print_r($admission);

  $company_reg = $smodel->gettable_data('company_tbl',$where = array('created_by !=' => 0));
?>
  <div class="card">
    <center>
      <div> <img src="<?php  echo base_url('public/company_photos/'.$company_reg[0]->logo_name) ?>" style="width: 20%;height: 20%; background: white;" ></div>
 <span class="mt-4"><b><?= $company_reg[0]->company_name; ?></b></span><br>
            <span class="modify" style="font-size:15px"><?= $company_reg[0]->address; ?></span>
            <div class="mb-3">
                <div><span class="modify" style="font-size:15px">Phone: +<?= $company_reg[0]->phone1; ?></span></div>
                <div><span class="modify" style="font-size:15px">Email: <?= $company_reg[0]->email; ?></span></div>
                <div><span class="modify" style="font-size:15px"> <?= $company_reg[0]->website; ?></span></div>
             
            </div>
   <span class="mt-3" style="font-size:18px"><u> Student Not Show List for academic year <?php echo $year;?> class <?php echo $cls[0]->class_name;?> batch no <?php echo $abs[0]->batch_no;?></u></span>
    </b>
</center>
   
                    <form id="closeAdmissionYearForm">
                        <div class="table-responsive mt-3">
                            <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable3">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th> Id</th>
                                        <th>Adm Id</th>
                                        <th>Adm date</th>
                                        <th>Student Name</th>
                                       <th>Gender</th>
                                       <th>Birth Date</th>
                                        <th>Age</th>
                                        <th>Stream/Comb</th>
                                        <!-- <th>sms status</th> -->
                                         <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $i=0;
                                   if(count($abs)>0) {
                                    foreach ($abs as $vl) {
                                    $i++;
                                    
                                     $update=array(
                                     'status'=>6
                                    );
                                    $sorry = $smodel->update_table_details('admission_tbl',$where = array('id' => $vl->adm_id),$update);
                                        
                                    $adm = $smodel->gettable_data('admission_tbl', $where = array('id' => $vl->adm_id));
                                    $std = $smodel->gettable_data('students', $where = array('id' => $adm[0]->student_id));
                                    $level = $smodel->gettable_data('class_level_tbl', $where = array('id' => $adm[0]->level_id));
                                   $cl = $smodel->gettable_data('classes_tbl', $where = array('id' => $adm[0]->class_id));
                                   $stream= $smodel->gettable_data('streams_tbl', $where = array('id' => $adm[0]->stream_id));
                                      $comb= $amodel->get_stream_comb_allocatiion($adm[0]->stream_id);
                                    $tby = $smodel->gettable_data('users', $where = array('user_id' => $abs[0]->created_by));

                                    //manage sms
                                    $msg_status = $smodel->gettable_data('message_groups_tbl', $where = array('trans_number' => $adm[0]->student_id,'message_type'=>12));
                                     if(count($msg_status)>0){
                                         $msg_st = $smodel->gettable_data('messages', $where = array('send_no' => $msg_status[0]->send_number));
                                         if(count($msg_st)>0){
                                             if($msg_st[0]->time_sent==null && $msg_st[0]->message_id !=""){
                                            ?>
                                         <script type="text/javascript">
                                        
                                             $(function() {
                                         check_sms('<?php echo $msg_st[0]->message_id;?>');
                                              });
                                         </script>
                                         <?php
                                             }
                                          $msg_st = $smodel->gettable_data('messages', $where = array('message_id' => $msg_st[0]->message_id));
                                         $del=$msg_st[0]->status_description;
                                         $time=$msg_st[0]->time_delivered;
                                         $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                                     }else{
                                         $stata='<span style="color:red">Not Sent'; 
                                     }
                                     }else{
                                       $stata='<span style="color:red">Not Sent';  
                                     }
                                        ?>
                                      <tr>
                                    
                                 <td><?php echo $i;?>.</td>
                                 <td><?php echo $vl->id;?></td>
                                 <td><?php echo $vl->adm_id;?></td>
                                 <td><?php echo $adm[0]->date_joined;?></td>
                                 <td><?php echo $std[0]->full_name;?></td>
                                 <td><?php echo $std[0]->gender;?></td>
                                <td><?php echo $std[0]->birth_date;?></td>
                                <td><?= findAge($std[0]->birth_date);?> </td>  
                                <td><?= $stream[0]->stream_name;?> 
                                 <?php if (isset($comb[0])): ?>
                                            (<?= $comb[0]->comb_name; ?>)
                                            <?php else: ?>
                                            (no comb)
                                            <?php endif; ?></td>  
                                <!-- <td><?= $stata;?> </td>   -->
                                 
                                     </tr>
                                        <?php
                                    } 
                                  }
                                    ?>
                                       
                                    <?php ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- <input type="hidden" name="total_admitted" value="<?php //$sn; ?>">
                        <button type="submit" class="btn btn-primary float-right mb-3 me-3">Close Academic Year</button> -->
                    </form>
                </div>

 
                <script type="text/javascript">
                //   $(document).ready(function () {
                //   $('#myTable2').DataTable();
                // });

         function check_sms(msgid){
               // alert(msgid);
       var data = "id=" + msgid;
              $.ajax({
            type: 'POST',
           url: '<?php echo base_url() . '/index.php/SystemController/check_sms/'; ?>'+msgid,
            
            success: function (res) {
            
              
            },
            error: function (){
                alert('error encounted');
            }
        });
            }
                </script>