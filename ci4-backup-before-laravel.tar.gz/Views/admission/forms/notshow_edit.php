  <?php 
    helper('age');
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();

    //$student = $smodel->gettable_data('students', $where = array('status' => 1));
    $abs = $smodel->gettable_data('student_not_show_tbl', $where = array('class' => $class,'academic_year'=>$year,'batch_no'=>$ent));
    // $adms = $smodel->gettable_data('admission_tbl', $where = array('id' => $vl->adm_id));
 $cls = $smodel->gettable_data('classes_tbl', $where = array('id' => $class));
    //print_r($admission);

?>
<h4>Edit Notshow List</h4>
  <div class="card">
    
   
                    <form id="closeAdmissionYearForm">
                        <div class="table-responsive mt-3">
                            <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable3">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th> Id</th>
                                        <th>Adm Id</th>
                                        <th>Adm date</th>
                                        <th>Student Name</th>
                                       <th>Gender</th>
                                       <th>Birth Date</th>
                                        <th>Age</th>
                                        <th>Stream/Comb</th>
                                         <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $i=0;
                                   if(count($abs)>0) {
                                    foreach ($abs as $vl) {
                                    $i++;
                                    $adm = $smodel->gettable_data('admission_tbl', $where = array('id' => $vl->adm_id));
                                    $std = $smodel->gettable_data('students', $where = array('id' => $adm[0]->student_id));
                                    $level = $smodel->gettable_data('class_level_tbl', $where = array('id' => $adm[0]->level_id));
                                   $cl = $smodel->gettable_data('classes_tbl', $where = array('id' => $adm[0]->class_id));
                                   $stream= $smodel->gettable_data('streams_tbl', $where = array('id' => $adm[0]->stream_id));
                        $comb= $amodel->get_stream_comb_allocatiion($adm[0]->stream_id);
                                    $tby = $smodel->gettable_data('users', $where = array('user_id' => $abs[0]->created_by));
                                        ?>
                                        
                                      <tr>
                                    
                                 <td><?php echo $i;?>.</td>
                                 <td><?php echo $vl->id;?></td>
                                 <td><?php echo $vl->adm_id;?></td>
                                 <td><?php echo $adm[0]->date_joined;?></td>
                                 <td><?php echo $std[0]->full_name;?></td>
                                 <td><?php echo $std[0]->gender;?></td>
                                <td><?php echo $std[0]->birth_date;?></td>
                                <td><?= findAge($std[0]->birth_date);?> </td>  
                                <td><?= $stream[0]->stream_name;?> 
                                 <?php if (isset($comb[0])): ?>
                                            (<?= $comb[0]->comb_name; ?>)
                                            <?php else: ?>
                                            (no comb)
                                            <?php endif; ?></td>  
                                 <td> <a href="javascript:void(0)" onclick="deleteAbsconds(<?php echo $year;?>,<?php echo $vl->class;?>,<?php echo $vl->id;?>,<?php echo $ent;?>)"  class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> </a></td>
                                     </tr>
                                        <?php
                                    } 
                                  }
                                    ?>
                                       
                                    <?php ?>
                                </tbody>
                            </table>
                        </div>
                       
                    </form>
                </div>

 
                <script type="text/javascript">
     function deleteAbsconds(yr,clas,iid,ent){
     $('#editabscond_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>'); 
      $('#editabscond_content').load('index.php/SemisterController/delete_notshow/'+yr+'/'+clas+'/'+iid+'/'+ent);
                }
   
                </script>