  <?php 
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();
    $bmodel = new App\Models\BillingModel();

    $cls = $smodel->gettable_data('classes_tbl', $where = array('status' => 1));
    $bd = $smodel->gettable_data('hostel_tbl', $where = array('status' => 1));
   
?>
  <div class="d-flex justify-content-center">
                    <form id="load_students">
                        <div class="form-inline mb-3">
                        <div class="me-3">
                            Admission Date:
                   <input type="date" name="admission_date" id="admission_date" value="<?php echo date('Y-m-d')?>" class="form-control">
                        </div>
                     <div class="me-3">
                        Initial Class: 
                           <select id="iclass" name="iclass" class="form-select form-control">
                            <option value="">-choose-</option>
                            <?php
                            foreach ($cls as $value) {
                               ?>
                           <option value="<?php echo $value->id;?>"><?php echo $value->class_name;?></option>
                               <?php 
                                  }
                                ?>
                     </select>
                        </div>
                        <div class="me-3">
                        Stream: 
                           <select id="istream" name="istream" class="form-select form-control">
                            <option value="">-choose-</option> 
                     </select>
                        </div>
                </div>
                 <div class="form-inline">
                         <div class="me-3">
                        Admission For: 
                           <select id="adfor" name="adfor" class="form-select form-control">
                            <option value="0">Continous</option>
                            <option value="2">New Comer</option>
                            
                     </select>
                        </div>
                        <div class="me-3">
                         Type: 
                           <select id="bod" name="bod" class="form-select form-control">
                            <option value="0">Day</option>
                            <option value="3">Boarding</option>
                            
                     </select>
                        </div>
                        <div class="me-3" id="hstl" style="display: none;">
                         Hostel: 
                           <select id="hostel" name="hostel" class="form-select form-control">
                            <option value="">-choose-</option>
                            <?php
                            foreach ($bd as $vl) {
                               ?>
                           <option value="<?php echo $vl->id;?>"><?php echo $vl->hostel_name;?></option>
                               <?php 
                            }
                            ?>
                            
                     </select>
                        </div>
                          
                          <?php
                             $cls= $amodel->get_student_details('company_tbl', $where = array('classification' => 1));
                             if(count($cls)>0){
                                ?>
                        <div class="me-3" id="class_iddiv">
                         Class Name: 
                           <?php
                         $clss= $bmodel->get_table_details('classification_tbl');
                          ?>
                        <select class="form-control" name="classification_id" id="classification_id">
                            <option value="0">-Choose-</option>
                            <?php foreach($clss as $type): ?>
                            <option value="<?= $type->id ?>"><?= $type->class_name; ?></option>
                            <?php endforeach; ?>
                        </select>
                        </div>
                    <?php } ?>

                           
                     <button type="submit" class="btn btn-primary">Load</button>
                        </div>
                        </form>
                        </div>
                    <hr>
                     &nbsp; 
                     <center>
                    <div id="student_results" class="mt-1"></div>
                </center> 
                        <script type="text/javascript">
                             $('#bod').change(function(){
                            var val= $('#bod').val();
                            if(val==3){
                                 $('#hstl').show(); 
                             }else{
                             $('#hstl').hide(); 
                             }
                          
                          
                             });

        $('#load_students').submit(function (e) {
         if($('#iclass option:selected').val()==""){
           swal('warning','please select initial class','warning');
           //return;
         }else if($('#istream option:selected').val()==""){
          swal('warning','please select stream','warning');
         }else{
            
            $('#student_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = $('#load_students').serialize();
           // alert(dta);
            //return;
            $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_pending'; ?>',
                data: dta,
                success: function (res) {
                    $('#student_results').html(res);
                },
                error: function () {
                    $('#student_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
    e.preventDefault();
    
    });

$('#iclass').change(function(){
         var InputOption = '';
        var data = 'id=' + $('#iclass').val();
        
         $.ajax({
            type:'POST',
            url:'getStreamdta',
            data: data,
            dataType: 'json',
            success:function(data){

                // console.log(data);
                // return;
                var len = data.length;
                $("#istream").empty();
                $("#istream").append("<option value=''>-Choose-</option>");

                // $('#stream').html(data);

                for( var i = 0; i<len; i++){
                 var id = data[i]['id'];
                    var name = data[i]['name'];
                    var stream = data[i]['stream'];
                   
                    if(i == 0){
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+''+"\xa0"+''+"</option>";
                    }else{
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+''+"\xa0"+''+"</option>";
                    }
                    $("#istream").append(InputOption);
                }
               
            }
        });
    });

    </script>