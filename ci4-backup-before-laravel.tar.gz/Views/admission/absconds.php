<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 
    helper('age');
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();

   // $student = $smodel->gettable_data('students', $where = array('status' => 1));
    $classes = $smodel->gettable_data('classes_tbl', $where = array('status' => 1));

?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Admission</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Student Absconds</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
            <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#adm-add"> Absconds List</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#newAbscond">New Absconds</a></li>
                
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                  <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#adm-add">Absconds List</a></li>
                 <li></li><li></li>
               <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#newAbscond">New Absconds</a></li>
            </ul>
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
             <div class="tab-pane active" id="adm-add">
               <div class="d-flex justify-content-center">
                    <form id="absconded" class="form-inline">
                     <div class="me-3">
                            Academic year: 
                           <select id="year2" name="year2" class="form-select form-control">
                      <!-- JavaScript loop to generate year options -->
                      <script>
                        const currentYear = new Date().getFullYear();
                        const startYear = 2023; // Change this to set a different start year
                        for (let year = currentYear+1; year >= startYear; year--) {
                            if(year==currentYear){
                            document.write(`<option value="${year}" selected>${year}</option>`);
                            }else{
                            document.write(`<option value="${year}">${year}</option>`);    
                            }
                        
                        }
                      </script>
                    </select>
                        </div>
                         <div class="me-3">
                            Class:  
                    <select id="class1" class="form-select form-control">
                        <option value="0" selected>All</option>
                     <?php foreach ($classes as $value) {
                        ?>
                    <option value="<?php echo $value->id;?>"><?php echo $value->class_name;?></option>
                    <?php  }?>
                    </select>
                </div>
                     <button type="submit" class="btn btn-primary">Create</button>
                        </form>
                        </div>
                        <hr>
                &nbsp; 
                     <center>
                    <div id="abscond_results" class="mt-4"></div>
                </center> 
            </div>

            <div class="tab-pane" id="newAbscond">
               
                <div class="d-flex justify-content-center">
                 <div id="continous" style="">
                    <form id="continue" class="form-inline">
                     <div class="me-3">
                            From Academic year: 
                           <select id="cyear" name="cyear" class="form-select form-control">
                      <!-- JavaScript loop to generate year options -->
                      <script>
                     
                        for (let year = currentYear+1; year >= startYear; year--) {
                            if(year==currentYear){
                            document.write(`<option value="${year}" selected>${year}</option>`);
                            }else{
                            document.write(`<option value="${year}">${year}</option>`);    
                            }
                        
                        }
                      </script>
                    </select>
                       </div>

                      <div class="me-3">
                           From  Class:  
                    <select id="class_list" class="form-select form-control">
                        <option value="" selected>-select-</option>
                        <?php foreach ($classes as $value) {
                        ?>
                        <option value="<?php echo $value->id;?>"><?php echo $value->class_name;?></option>
                    <?php  }?>
                    </select>
                </div>
                        
                        <div class="input-group ms-3">
                
                <input type="text" class="form-control" name="payer_name" id="search_name"   placeholder="Search Student Name" aria-label="Student Name" aria-describedby="button-st">
                <button class="btn btn-outline-success" type="button" id="button-y">
                    <span>
                        <i class="fa fa-calendar" aria-hidden="true"></i>
                    </span></button>
                <button class="btn btn-outline-primary" type="button" id="button-st" onclick="searchnamebtn()"><i class="fa fa-search" aria-hidden="true"></i></button>
            </div>
                     <!-- <button type="submit" class="btn btn-primary">Load</button> -->
                        </form>
                        </div>
                        </div>
                        <hr>
                &nbsp; 
                     <center>
                    <div id="pending_results" class="mt-4"></div>
                </center> 
            </div>

           
        </div>
    </div>
</div>

<!-- ------Admit modal------ -->
<div id="myModal" class="modal fade"  role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <!-- <h5 class="modal-title" id="staticBackdropLabel">Student Admission Details</h5> -->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div id="admission"></div>
        </div>
      </div>
      
    </div>
</div>

<!-- Modal -->
<!--   <div id="myModal" class="modal fade" data-bs-backdrop="static" data-bs-keyboard="false"  aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" >
    
       Modal content-
      <div class="modal-content" style="">
        <div class="modal-header">
          <h5 class="modal-title" id="">Student Admission Details</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body"  >
          <div id="admission"></div>
        </div>
         <div class="modal-footer">
          <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button>
        </div> 
      </div>
      
    </div>
  </div> -->

<!-- ------View Admission modal------ -->
<!-- <div class="modal fade" id="viewadmission" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
           <h5 class="modal-title" id="">Transfer Student</h5> -
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewadmission_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save</button>
      </div> --
    </div>
  </div>
</div> -->
<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
   $('#cyear').change(function (e) {
         if($('#class_list option:selected').val()==""){
         
           //return;
         }else{
            
            $('#pending_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "year=" + $('#cyear option:selected').val()+'&class='+ $('#class_list option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
               url: '<?php echo base_url() . '/index.php/SemisterController/get_class_absconding'; ?>',
                data: dta,
                success: function (res) {
                    $('#pending_results').html(res);
                },
                error: function () {
                    $('#pending_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    
    });

  $('#class_list').change(function (e) {
         if($('#class_list option:selected').val()==""){
           swal('warning','please select class','warning');
           //return;
         }else{
            
            $('#pending_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "year=" + $('#cyear option:selected').val()+'&class='+ $('#class_list option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_class_absconding'; ?>',
                data: dta,
                success: function (res) {
                    $('#pending_results').html(res);
                },
                error: function () {
                    $('#pending_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    
    });
   function manage_admission(adm){
        $('#viewadmission').modal('show'); 
        $('#viewadmission_content').load('view_admissions/'+adm);
    }
    $('#pending').submit(function (e) {
            
            $('#pending_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "year=" + $('#year option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_pending'; ?>',
                data: dta,
                success: function (res) {
                    $('#pending_results').html(res);
                },
                error: function () {
                    $('#pending_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
      $('#absconded').submit(function (e) {
            
            $('#abscond_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "year=" + $('#year2 option:selected').val()+"&class=" + $('#class1 option:selected').val();;
           // alert(dta);
            $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_absconded_students'; ?>',
                data: dta,
                success: function (res) {
                    $('#abscond_results').html(res);
                },
                error: function () {
                    $('#abscond_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });

  $('#pendType').change(function(){
    var val= $('#pendType').val();
     if(val==1){
    $('#newComer').hide();
    $('#pending_results').html('');
    $('#continous').show();
     }else if(val==2){
        $('#continue')[0].reset();
           $('#continous').hide();
           $('#pending_results').html('');
        $('#newComer').show();
     }else{
            $('#continue')[0].reset();
           $('#continous').hide();
           $('#pending_results').html('');
        $('#newComer').hide(); 
     }
      });
  $('#continue').submit(function (e) {
         if($('#class option:selected').val()==""){
           swal('warning','please select class','warning');
           //return;
         }else{
            
            $('#pending_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "year=" + $('#cyear option:selected').val()+'&class='+ $('#class option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_pending_continous'; ?>',
                data: dta,
                success: function (res) {
                    $('#pending_results').html(res);
                },
                error: function () {
                    $('#pending_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    
    });

  function searchnamebtn(){
            var name=$('#search_name').val();
            var  year=$('#button-y').html();
            // alert(year);
            if(name.length >=3){
                $('#pending_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
                var dta="name="+name+"&year="+year+"&search="+1;
                //alert(dta);
           // toastr.success(name.length);
             $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/index.php/SemisterController/get_class_absconding'; ?>",
                data: dta,
                success: function (res) {
                    $('#pending_results').html(res);
                },
                error: function () {
                    $('#pending_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
        }else{
            if(name.length==0){
               $('#pending_results').html(''); 
            }else{
               $('#pending_results').html('<div class="alert alert-info">Search atleat 3 characters</div>'); 
            }
        
        }
        }
</script>