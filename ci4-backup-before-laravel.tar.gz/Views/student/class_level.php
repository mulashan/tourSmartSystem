<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 

    $cmodel = new App\Models\ClassesModel();
    $amodel = new App\Models\AdmissionModel();

    $charged_item = $cmodel->items_chargedList();

    $levelist = $cmodel->load_allSaved_Level();

    $appItems = $cmodel->get_applications_items();
    $account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));
     $smodel = new App\Models\StudentModel();

    $clvl = $smodel->gettable_data('academic_types_tbl', $where = array('status' => 1));

?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Class Level</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Class Level</li>
                </ol>
            </div>
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#rcpt-all">Level List</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#rcpt-add">New Level</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#rcpt-all">Level List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#rcpt-add">New Level</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="rcpt-all">
                <div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable">
                            <thead>
                                <tr>
                                    <th>No.#</th>
                                    <!-- <th>Level</th> -->
                                    <th>Name</th>
                                    <th>GOVERNMENT LEVEL</th>
                                    <th>Course Period</th>
                                    <th>Status</th>
                                    <th>Updated By</th>
                                    <th>Modified Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $sn="0"; $status=""; foreach ($levelist as $list) : $sn++; if($list->status == 1){ $status = "<b style='color:green;'>Active</b>";}else{$status = "<b style='color:red;'>Inative</b>";} 
                                $per = $smodel->gettable_data('academic_types_tbl', $where = array('id' => $list->academic_type));
                                if(count($per)>0){
                                    $period=$per[0]->academic_type;
                                }else{
                                  $period="";  
                                }
                                ?>
                                    <tr>
                                        <td><?= $sn; ?></td>
                                        <!-- <td><?= $list->id; ?></td> -->
                                        <td><?= $list->level_name; ?></td>
                                        <td><?= $list->g_level; ?></td>
                                        <td><?= $period; ?></td>
                                        <td><?= $status; ?></td>
                                        <td><?= $list->first_name." ".$list->last_name; ?></td>
                                        <td><?= $list->updated_date; ?></td>
                                        <td>
                                            <button type="button" class="btn btn-primary btn-sm EditID" data-id="<?= $list->id;?>"><i class="fa fa-edit"></i> Edit</button>
                                            <!-- <button type="button" class="btn btn-danger btn-sm RemoveID" data-id="<?php //echo $list->id;?>"><i class="fa fa-trash"></i></button> -->
                                        <a href="#" data-toggle="modal" class="btn btn-primary btn-sm level" cl_id="<?php echo $list->id;?>"><i class="fa fa-eye"></i> View</a>
                                        </td>
                                    </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="tab-pane" id="rcpt-add">
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header"  style="height:5px">
                                <h3 class="card-title">Class Details</h3>
                                
                                <div class="card-options ">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                            <div class="card-body">
                                <form id="SaveLevel" class="form-horizontal needs-validation" novalidate>
                                    <div id="fdbkarea"></div>
                                    <div class="form-group row">
                                        <label class="col-md-2 col-form-label">Level Name <span class="text-danger">*</span></label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="level" required="required">
                                            <div class="invalid-feedback">Level Name is required.</div>
                                        <span id="level_error" class="text-danger"></span>
                                        </div>
                                    </div>
                             <div class="form-group row">
                                        <label class="col-md-2 col-form-label">Government Level<span class="text-danger">*</span></label>
                                        <div class="col-md-8">
                                               <select name="government_level" id="government_level" class="form-control" required="required">
                                                <option value="">--Choose--</option>
                                                <?php foreach ($gvmt_level as $gv_level): ?>
                                                    <option value="<?= $gv_level->level_id; ?>"><?= $gv_level->level_name; ?></option>
                                                <?php endforeach ?>
                                            </select>
                                             <div class="invalid-feedback">Government Level is required.</div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2 col-form-label">Applications Fee Charged <span class="text-danger">*</span></label>
                                        <div class="col-md-8">
                                            <select name="application" id="application" class="form-control" required>
                                                <option value="">--Choose--</option>
                                                <?php foreach ($appItems as $p): ?>
                                                    <option value="<?= $p->id; ?>"><?= $p->item_name .' '. $p->item_price; ?></option>
                                                <?php endforeach ?>
                                            </select>
                                              <div class="invalid-feedback">Applications Fee is required.</div>
                                             <span id="application_error" class="text-danger"></span>
                                        </div>
                                    </div>
                                  <div class="form-group row">
                                    <label class="col-md-2 col-form-label">Course Period <span class="text-danger">*</span></label>
                                <div class="col-md-3">
                               <select class="form-control" name="academic_type" required>
                                <option value="">-choose-</option>
                                       <?php
                                   foreach ($clvl as  $value) {
                                          ?>
                                         <option value="<?php echo $value->id;?>"><?php echo $value->academic_type;?></option>
                                       <?php } ?>
                                    </select>
                                     <div class="invalid-feedback">Course Period is required.</div>
                                </div>
                                </div>
                                    <div class="form-group row">
                                        <label class="col-md-2 col-form-label" for="items">Charged Items</label>
                                        <div class="col-md-8">
                                            <select class="form-select form-control" id="js-example-data-ajax1" style="width:400px;height: 15px;">
                                                <option>Select Items to be Charged</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-2"></div>
                                        <div class="col-md-8">
                                            <div class="card">
                                                <p Class=" d-flex justify-content-center mt-3">CHARGED ITEMS</p>
                                                <table class="table table-striped table-borderless" id="table">
                                                <thead>
                                                        <tr>
                                                            <th>Item No#</th>
                                                            <th>Item Name</th>
                                                            <th>Attr</th>
                                                            <th>Size</th>
                                                            <th>UoM</th>
                                                            <!-- <th>Group</th> -->
                                                            <th>Qty</th>
                                                            <th>Price</th>
                                                            <th>Total</th>
                                                            <th>Action</th>
                                                        </tr>
                                                </thead>
                                                <tbody id="show_item">
                                                    
                                                </tbody>
                                                </table>
                                                </table>
                                    <table>
                                        <tr>
                                        <th col=4>
                                        <span id="totalp" style="margin-left:400px;"></span>
                                        </th>
                                        </tr>
                                    </table>
                                            </div>
                                        </div>
                                    </div>
                                
                            <div class="form-group row">
                                <label class="col-md-2 col-form-label">Account Receivable<span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <select name="account" id="account" class="form-control" required="required">
                                        <option value="">--Select Account Receivable--</option>
                                        <?php foreach ($account as $ac): ?>
                                            <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                        <?php endforeach ?>
                                    </select>
                                      <div class="invalid-feedback">Account Receivable is required.</div>
                                </div>
                            </div>
                                    <div class="form-group row">
                                        <label class="col-md-2 col-form-label"></label>
                                        <div class="col-md-8">
                                            <button type="submit" class="btn btn-outline-secondary">Cancel</button>
                                            <button type="submit" class="btn btn-primary float-right">Save</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ------view modal------ -->
    <!-- Modal -->
    <div id="mModal"  class="modal fade" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" style="width:800px">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="ViewLevel"></div>
                </div>
                <div class="modal-footer">
                    
                </div>
            </div>

        </div>
    </div>


<!-- Modal -->
  <div id="myModal" class="modal fade" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="">Edit Level</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Updtelvl"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>


<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">

    var hold_selected_items = []; // hold all selected items

    $(document).ready(function(){
        fetch_data();
         $('#js-example-data-ajax1').select2({
            ajax: {
                url: "<?= base_url('load_data'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

        $('#js-example-data-ajax1').on('select2:select', function (e) {
            selectedItems();
        });
         
        function selectedItems(){  
            var rows = '';
           var itemData = 'item_selected='+$('#js-example-data-ajax1').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Itemdata')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }else{
                        var len  = data.length;

                        for (var i = 0; i <len; i++ ){
                            hold_selected_items.push(data[i]['id']);// push all selected items
                            var prc = data[i]['iprice'];
                            var name = data[i]['iname'];
                            var iid = data[i]['id'];
                            var size = data[i]['isize'];
                            var attr = data[i]['iattr'];
                            var uom = data[i]['iattr'];
                            var ttl = data[i]['iattr'];

                        
                            
                            rows += '<tr id="table_row'+ iid +'">';
                            rows += '<td><input type="hidden" name="id[]" value="'+iid+'">'+ iid +'</td>';
                            rows += '<td>'+ name +'</td>';
                            rows += '<td>'+ attr +'</td>';
                            rows += '<td>'+ size +'</td>';
                            rows += '<td>'+ uom +'</td>';
                            rows += '<td><input type="number" class="form-control" onchange ="totalAmount('+iid+')" name="qty'+iid+'" id="qty"></td>';
                            rows += '<td><input type="hidden"  name="prc_'+iid+'" value="'+prc+'">'+ prc +'</td>';
                            rows += '<td id="ttl_'+iid+'"></td>';
                            rows += '<td><a href="javascript:RemoveSelectItemRow('+iid+');" class="btn btn-danger btn">X</a></td>';
                            rows += '</tr>';
                            $('#show_item').append(rows);
                        }
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }  
           });  
        } 
    });
       sumVal=0;
    function totalAmount(id){
        $('#ttl_' + id).empty();
        var prc = $('input[name=prc_' + id+']').val();

        var qty = $('input[name=qty' + id+']').val();
        var calc = prc*qty; 
            $('#ttl_' + id).append(calc);

             var table = document.getElementById("table"); 
           sumVal = sumVal + calc;
            
            
            document.getElementById("totalp").innerHTML = "Total = " + sumVal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(sumVal);
            return sumVal;
    }
   $(document).ready(function(){
   
    // code to read selected table row cell data (values).
    $("#table").on('click','.btn',function(){
         
         var currentRow=$(this).closest("tr"); 
         
         var col1=currentRow.find("td:eq(7)").text(); 
          //sum=totalAmounts();
          //sum=sumval;
         var data=col1;
         //alert(data);
        sumVal=sumVal-data;
        document.getElementById("totalp").innerHTML = "Total = " + sumVal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(sumVal);
         
    });
});
    function RemoveSelectItemRow(item_id){
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }

        $('#table_row'+item_id).remove();
    }


    $('#SaveLevel').submit(function(e){
          e.preventDefault();
           if (!this.checkValidity()) {
        this.classList.add("was-validated");
        return;
             }
        var levelData = $(this).serialize();
       //alert(levelData);
       if(remain>0){
        swal('warning','Please! assign '+remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+' to installments','warning');
       }else{
        $.ajax({
            method: 'POST',
            url: '<?= base_url('createLevel')?>',
           data: levelData,
            success:function(res){
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                    
                    $("#SaveLevel")[0].reset();
                    $('#fdbkarea').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#fdbkarea').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            },
            error:function(){
                $('#fdbkarea').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Save Level.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
            
            }
            
        });
       } 
      
    });

    $(".EditID").click(function () {
        var data = 'ids=' + $(this).attr('data-id');
        // $("#idkl").val( ids );
         //alert (data);
        $('#myModal').modal('show');


        $.ajax({
            type: "GET",
            url: "<?= base_url('/editLevel')?>",
            data: data,
            beforSend: function()
            {
                $('#Updtelvl').html();
            },
            success: function(res){
                $('#Updtelvl').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });

    $(".RemoveID").click(function(){

        var id = $(this).attr('data-id');

           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this Level!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/classLevel_dlt')?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      // $("#"+id).remove();
                    swal("Deleted!", "Level has been deleted.", "success");

                    // location.reload();
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                      
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });

        $('#temp').click(function(event){
     //totalAmounts();
     //fetch_data();
     //event.preventDefault();
       var data = 'installname=' + $('select[name=install]').val() + '&amount=' + $('input[name=amount]').val()+ '&id=' + $('input[name=ids]').val();
       var k=sumVal;
      // alert(k);
      if(k==0){
        alert("Enter charged Items first");
       }else{
       if(!remain && remain!=0){
          remain=k; 
       }
       var mount=$('input[name=amount]').val();
       var sum=remain-mount;
       //alert(sum);
       if(sum>=0){
     document.getElementById("more").innerHTML="";
       $.ajax({
            type: 'POST',
           url: 'temporaryLevel',
            data: data,
            success:function(data){
                if(data==1){
                    alert("Term, Already Selected");
                    sum=remain+mount;
                }
                fetch_data();
                
                            }
       });
       }else{
        document.getElementById("more").innerHTML="Enter less amount or equal to "+remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
      $('input[name=amount]').val()="";     
       }}
        event.preventDefault();
    });

        var remain;
       function fetch_data(){
        $('#show2').empty();
                
        var datta = 'level_id=0';
        $.ajax({
            type: 'GET',
            data: datta,
            //url: 'fetchinstallments',
            url: 'fetchinst3',
            success:function(response){
                console.log(response);
                var temp_data = JSON.parse(response);
                var len = temp_data.length;
                //total=fetch_class_itemsCharged();
                var ttlamount=0;
                for(var i = 0; i < len; i++){
                    var amounted=parseInt(temp_data[i]['amount']);
                    ttlamount=parseInt(ttlamount+amounted);
                    $('#show2').append('<tr>'+
                        
                        '<td>'+temp_data[i]['installname']+'</td>\
                        <td>'+temp_data[i]['amount']+'</td>\
                        <td>'+temp_data[i]['duedate']+'</td>\
                        <td>\
                            <a href="javascript:RemoveSelecttemp('+temp_data[i]['id']+');" class="btn btn-danger dlt">x</a>\
                        </td>\
                    </tr>');
                }
        total=sumVal;
        //total=temp_data[0]['tamount'];
        remain=total-ttlamount;
        document.getElementById("remained").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(remain);
            }
        });
        
    }
    function RemoveSelecttemp(id)
    {
        $.ajax({
            type: 'GET',
            url: 'delete_temp/'+id,
            success: function(){
         alert('deleted successfuly');
         remain= sumVal;
         document.getElementById("remained").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(remain);
         
                 fetch_data();
                
            }
        });
    }

     $('#saveAccomodate').submit(function(e){
        var Data=$(this).serialize();
   
        $.ajax({
            method: 'POST',
            url: '<?= base_url('createLevel')?>',
            data: Data,
            // dataType: 'json',
            success:function(res){
                var data = JSON.parse(res);
                
                    $("#saveAccomodate")[0].reset();
                    $('#accfbk').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                
            },
            error:function(res){
                $('#accfbk').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Save Accomodation.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
            }
        });
        
        e.preventDefault();
    });
  $(".level").click(function () {
        var data = 'lid=' + $(this).attr('cl_id');


        $('#mModal').modal('show');


        $.ajax({
            type: "GET",
            url: "<?= base_url('/classLevel_View')?>",
            data: data,
            beforSend: function()
            {
                $('#ViewLevel').html();
            },
            success: function(res){
                $('#ViewLevel').html(res);

            },
            error: function ()
            {

            }
        });
    });
</script>