 
<?php 
helper('age');
$studentModel = new App\Models\studentModel();
$lmodel = new App\Models\LoginModel();
    $staffModel = new App\Models\StaffModel();
    $imodel = new App\Models\ItemsModel();


   $graduats = $studentModel->gettable_data('graduation_tbl',$where = array('graduation_year' => $year));
    $male=0;
    $female=0;
    if(count($graduats)>0){
        foreach ($graduats as $v) {
            $adms = $studentModel->gettable_data('admission_tbl',$where = array('id' => $v->adm_id));
             
    if(count($adms)>0){
             $gender = $studentModel->gettable_data('students',$where = array('id' => $adms[0]->student_id)); 

             if($gender[0]->gender=='Male') {
               $male=$male+1;
             }else{
              $female=$female+1;
             }
         }else{
            echo $v->adm_id.'/';
         }

        }
      
    }
   ;
   $pboys=number_format((float)$male/count($graduats),3,'.','');
   $pgirls=number_format((float)$female/count($graduats),3,'.','');
  
  
?>

<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Students</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Student Dashboard</li>
                </ol>
            </div>
          
        </div>
    </div>
</div>

<div class="section-body mt-4">
<div class="container-fluid">
<div class="row clearfix row-deck">
                       
                      
     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:#8A3324;">
            <div class="card-body ribbon">
             
                   <span style="color:white;">Graduates</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= count($graduats); ?></span></h5>
             
            </div>
        </div>
    </div>

     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:blue;">
            <div class="card-body ribbon">
             
                   <span style="color:white;"> BOYS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= number_format($male); ?></span></h5>  <h5><b><span style="color:greenyellow;"><?= ($pboys)*100; ?>%</span></b></h5>
             
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:pink;">
            <div class="card-body ribbon">
             
                   <span style="color:black;">GIRLS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:black;"><?= number_format($female); ?></span></h5>
                   <h5><b><span style="color:green;"><?= ($pgirls)*100; ?>%</span></b></h5>
                   <!-- <h6 id="OPDtotal"><span style=""></span></h6> -->
             
            </div>
        </div>
    </div>
    
    </div>

  
 <div class="row mt-3"> 
       <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">Graduates BY GENDER</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="genderadmition">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>

        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">Graduates BY CLASS</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="admitionbylevel">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
     
    </div>
    </div> 
    </div>

<script>
   

$(document).ready(function () {
       loadAdimissionGender();
      // loadNationality();
       //admitiontype();
       //selColl();
        studentReligion();
       //admitionbyclass();
    });

// function loadapp() {
//          $('#classlevel').load('<?php echo base_url() . '../index.php/StudentController/get_classlevel_details'; ?>');
//     }
  
function loadAdimissionGender() {
        $.ajax({
            beforeSend: function () {
                $('#genderadmition').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StaffController/get_gender_graph/'.$year?>',
            success: function (result) {
                $('#genderadmition').html(result);
            },
            error: function () {
                $('genderadmition').html('Sorry! Something went wrong.');
            }
        });
    }
    
    
     function studentReligion() {
        $.ajax({
            beforeSend: function () {
                $('#admitionbylevel').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StaffController/graduants_by_class/'.$year?>',
            success: function (result) {
                $('#admitionbylevel').html(result);
            },
            error: function () {
                $('admitionbylevel').html('Sorry! Something went wrong.');
            }
        });
    }
    
</script>