<?php 

    $cmodel = new App\Models\ClassesModel();
  $smodel = new App\Models\StudentModel();

    $clvl = $smodel->gettable_data('academic_types_tbl', $where = array('status' => 1));
  //  $schoolTerms = $cmodel->Load_SchoolTerms();
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">School Terms</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">School Terms</li>
                </ol>
            </div>
            
             <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#sem-all">Term(s) List</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#sem-add">New Term</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#sem-all">Term(s) List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#sem-add">New Term</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="sem-all">
              <div class="d-flex justify-content-center">
                    <form id="academic" class="form-inline">

                        
                        <div class="me-3">
                             Academic year: 
                           <select id="year" name="year" class="form-select form-control">
                      <!-- JavaScript loop to generate year options -->
                      <script>
                        const currentYear = new Date().getFullYear();
                        const startYear = 2023; // Change this to set a different start year
                        for (let year = currentYear+1; year >= startYear; year--) {
                            if(year==currentYear){
                            document.write(`<option value="${year}" selected>${year}</option>`);
                            }else{
                            document.write(`<option value="${year}">${year}</option>`);    
                            }
                        
                        }
                      </script>
                    </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Create</button>
                        </form>
                        </div> 
                     <center>
                    <div id="semister_results" class="mt-4"></div>
                </center> 
            </div>
            <div class="tab-pane" id="sem-add">
                <div class="row clearfix">
                    <div class="card">
                        <div class="card-header" style="height:5px">
                            <h3 class="card-title">New Term</h3>
                            <div class="card-options ">
                                <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                            </div>
                        </div>
                        <hr>
                        <div class="card-body">
                            <div id="feedback"></div>
                            <form class="form-horizontal" id="AddSemister">
                                <div class="form-group row">
                                <label class="col-md-3 col-form-label">Academic Year:</label>
                                <div class="col-md-3">
                                    <select class="form-control" name="academic">
                                       <?php
                                       $year = (int)date('Y')-1;
                                       $y=$year+5;
                                       for ($year; $y>= $year; $year++): ?>
                                         <option value="<?php echo $year;?>"><?php echo $year;?></option>
                                       <?php endfor; ?>
                                    </select>
                                    <!-- <input type="number" min="1900" max="2099" step="1" value="2023"  name="acdy" id="datepicker" class="form-control"> -->
                                </div>
                                </div>
                                 <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Course Period <span class="text-danger">*</span></label>
                                <div class="col-md-3">
                               <select class="form-control" name="academic_type" required>
                                <option value="">-choose-</option>
                                       <?php
                                   foreach ($clvl as  $value) {
                                          ?>
                                         <option value="<?php echo $value->id;?>"><?php echo $value->academic_type;?></option>
                                       <?php } ?>
                                    </select>
                                </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Term Name <span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <input type="text" name="tname" id="tname" class="form-control form-control-sm" placeholder="eg: Semister 1" required="required">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Description </label>
                                    <div class="col-md-7">
                                        <input type="text" name="tdescr" id="tdescr" class="form-control form-control-sm">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Start Date <span class="text-danger">*</span></label>
                                    <div class="col-md-3">
                                        <input type="date" name="startDate" id="startDate" class="form-control form-control-sm" required="required">
                                    </div>
                                    <label class="col-md-1 col-form-label">End Date <span class="text-danger">*</span></label>
                                    <div class="col-md-3">
                                        <input type="date" name="endDate" id="endDate" class="form-control form-control-sm" required="required">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Due Date <span class="text-danger">*</span></label>
                                    <div class="col-md-3">
                                        <input type="date" name="dueDate" id="dueDate" class="form-control form-control-sm" required="required">
                                    </div>
                                    </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label"></label>
                                    <div class="col-md-7">
                                        <!-- <button type="submit" class="btn btn-outline-secondary">Cancel</button> -->
                                        <button type="submit" class="btn btn-primary float-right">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>


<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Edit School Term</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="UpdateTerm"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>

<!-view- Modal -->
  <div class="modal fade" id="viewModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <!-- <h5 class="modal-title" id="staticBackdropLabel">Edit School Term</h5> -->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="viewTerm"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>

<script type="text/javascript">
    $('#AddSemister').submit(function(e){
     //   alert($(this).serialize());
        $.ajax({
            type:"POST",
            url:"new_Semister",
            data: $(this).serialize(),
            success:function(res){
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                    
                    $('#AddSemister')[0].reset();
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            },
            error:function(){
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Save Semister.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>')
            }
        });
        e.preventDefault();
    });

   
    $(".deleteID").click(function(){

        var id = $(this).attr('data-id');


           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this ledger!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/deleteterm')?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      // $("#"+id).remove();
                    swal("Deleted!", "Ledger deleted.", "success");

                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                      
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
    $('#academic').submit(function (e) {
            
            $('#semister_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "year=" + $('#year option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_semisters'; ?>',
                data: dta,
                success: function (res) {
                    $('#semister_results').html(res);
                },
                error: function () {
                    $('#semister_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
</script>