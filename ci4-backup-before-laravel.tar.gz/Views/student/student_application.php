<style>
    
</style>
<?php
    $student_model = new App\Models\StudentModel();
    $amodel = new App\Models\AdmissionModel();
    //echo session()->get('user_id');
    //echo $_SESSION['user_id'];
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Application</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Application</li>
                </ol>
            </div>
           <!--  <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="application-tab" data-toggle="tab" href="#app-all">Application List</a></li>
                <li class="nav-item"><a class="nav-link" id="application-tab" data-toggle="tab" href="#app-add">New Application</a></li>
                 <li class="nav-item"><a class="nav-link" id="selection-tab" data-toggle="tab" href="#select-add">Selection</a></li>
                 <li class="nav-item"><a class="nav-link" id="selection-tab" data-toggle="tab" href="#select-list">Selection List</a></li>
            </ul> -->

            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="application-tab" data-toggle="tab" href="#app-all">Application List</a></li>
                <li class="nav-item"><a class="nav-link" id="application-tab" data-toggle="tab" href="#app-add">New Application</a></li>
                
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="application-tab" data-toggle="tab" href="#app-all">Application List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="application-tab" data-toggle="tab" href="#app-add">New Application</a></li>
                
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="app-all">
                 <!--------------------------------------->

              <div class="d-flex justify-content-center">
                <div id="messageDisplayArea"></div>
                    <form id="Rept1Result_app" class="form-inline">
                         Application date:
                         <div class="input-group ms-3 me-3">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                      
                <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="application_area"></div>
                </center>
         <!--------------------------------------------->
            </div>
            <div class="tab-pane" id="app-add">
                <div class="card">
                 <section class="wizard-section">
                    <div class="card-header" style="height:5px">
                        <h3 class="card-title">Application Form</h3>
                        <div class="card-options ">
                            <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                        </div>
                    </div>
                    <hr>
                    <div class="card-body">
                        <div id="applcnFDCK"></div>
                          <form id="save_application" class="form-horizontal">
                        <h3 class="card-title">Student Details</h3>

                 <div class="row mb-5">
                    <div class="col-sm-2"></div>
                    <label for="psearch" class="col-sm-2 col-form-label col-form-label-sm">Search Name</label>
                    <div class="col-sm-5">
                        <input type="search" class="form-control form-control-sm" id="appname" name="appname" placeholder="Search Application Name">
                    </div>
                    <button class="btn btn-primary col-sm-1" type="button" onclick="search_student()">Search</button>
                </div>
               <div class="row mb-3 col-md-5 ms-5" id="name_loaded">

               </div>
                 <div class="form-group row mb-3">
                                <label class="col-md-2 col-form-label">Applicant Name<span class="text-danger">*</span></label>
                                <div class="col-md-3">
                                    <input type="text" class="form-control" name="fname" placeholder="First Name" autocomplete="off">
                                </div>
                                <div class="col-md-3">
                                    <input type="text" class="form-control" name="mname" placeholder="Middle Name" autocomplete="off">
                                </div>
                                <div class="col-md-3">
                                    <input type="text" class="form-control" name="lname" placeholder="Last Name" autocomplete="off">
                                </div>
                            </div>
                            <div class="form-group row mb-3">
                                <label class="col-md-2 col-form-label">Date of Birth<span class="text-danger">*</span></label>
                                <div class="col-md-3">
                                    <!-- <input type="date" class="form-control" id="datePickerId" name="dob" placeholder="F"  min="2007-12-31"> -->
                                    <input type='text' class="form-control"  name="dob" id='datetimepicker1' placeholder="2018-07-24"  min="1980-12-31"/>
                                </div>

                                <label for="" class="col-md-2 col-form-label">Gender<span class="text-danger">*</span></label>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input mt-1" type="radio" name="gender" id="female" value="Female">
                                        <label class="form-check-label" for="day">
                                        Female
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input mt-1" type="radio" name="gender" id="male" value="Male">
                                        <label class="form-check-label" for="board">
                                        Male
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row mb-3">
                                <label class="col-md-2 col-form-label">Class Level<span class="text-danger">*</span></label>
                                <div class="col-md-3">
                                    <select name="classlevel" id="classlevel" class="form-control" required >
                                        <option value="">--Select Level--</option>
                                        <?php foreach ($clevel as $c): 
                                            $getRemainTotal = $amodel->remain_classLevel_capacity($c->id);
                                            if($getRemainTotal[0]->remainTotal != '' || $getRemainTotal[0]->remainTotal != NULL){
                                                $remain_capacity = '- '.$getRemainTotal[0]->remainTotal;
                                            }else{
                                                $remain_capacity = '- No';
                                            }
                                        ?>
                                        <option value="<?= $c->id ?>"><?= $c->level_name.' '; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <label class="col-md-2 col-form-label">Class<span class="text-danger">*</span></label>
                                <div class="col-md-4">
                                    <select id="class" name="class" class="form-select me-4 form-control form-control-sm" >
                                        <option value="">--Select Class--</option>
                                       
                                    </select>
                                </div>
                            </div>
                        <hr>
                        <h3 class="card-title">Parent Details</h3>
                            <div class="form-group row mb-3">
                                <label class="col-md-2 col-form-label">Parent/Gurdian Name<span class="text-danger">*</span></label>
                                <div class="col-md-4">
                                    <input type="text" class="form-control" name="pfname" placeholder="First Name" autocomplete="off">
                                </div>
                                <div class="col-md-4">
                                    <input type="text" class="form-control" name="plname" placeholder="Last Name" autocomplete="off">
                                </div>
                            </div>
                            <div class="form-group row mb-3">
                                <label class="col-md-2 col-form-label">Bill Phone No.<span class="text-danger">*</span></label>
                                <div class="col-md-4"> 
                                    <input type="tel" class="form-control" name="bphone" id="bphone" placeholder="+255-xxx-xxx-xxx" value="255" size="20" minlength="9" maxlength="13" required autocomplete="off" data-inputmask="'mask': '999-999999999'">
                                </div>
                            </div>
                            <div class="form-group row mb-3">
                                <div class="col-md-3"></div>
                                <div class="col-md-4 offset-md-4 pull-right">
                                    <span class="float-right">
                                       <button type="reset" class="btn btn-secondary"><i class="fa fa-ban"></i> Cancel</button>&nbsp;&nbsp;
                                       <button type="button" class="btn btn-primary" id="add_application" onclick="Save_Application()"><i class="fa fa-save"></i>&nbsp; Save</button> 
                                    </span>
                              </div>
                            </div>
                        </form>
                  </div>
                    
                    </section>
                    </div>
                 </div>

                  <div class="tab-pane" id="select-add">
                <div class="card">
                 <section class="wizard-section">
                    <div class="card-header" style="height:5px">
                        <h3 class="card-title">Student Selection</h3>
                        <div class="card-options ">
                            <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                        </div>
                    </div>
                    </section>
                    </div>
                    
                    <hr>
                    <div class="card-body">
                        <div id="slctnFDCK"></div>
<!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="box box-danger">
           
            <div class="box-body">
          
                <div class="d-flex justify-content-center">
                    <form id="Rept1Result" class="form-inline">

                        Class: 
                        <select class="form-control form-select ms-2 me-2" name="cls" id="cls">
                            <option value="0">-choose-</option>
                            <?php
                           $c = $student_model->get_class_details();
                          foreach($c as $cc){
                           echo '<option value="' . $cc->id . '">' . $cc->class_name . '</option>'; 
                          }

                           ?>
                        </select>
                         
                        Search: 
                        <select class="form-control form-select ms-2" name="st" id="status">
                            
                            <option value="1">selected students</option>
                            <option value="0">students not Selected</option>
                           
                        </select>
                        <button type="submit" class="btn btn-primary ms-2">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>
           
            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
                    </div>
            </div>
        </div>

         <div class="tab-pane" id="select-list">
                <div class="card">
                 <section class="wizard-section">
                    <div class="card-header" style="height:5px">
                        <h3 class="card-title">Selection List</h3>
                        <div class="card-options ">
                            <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                        </div>
                    </div>
                    </section>
                      <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                    <th>selection no:</th>
                                    <th>Selection Date</th>
                                    <th>Student</th>
                                    <th>Date of Birth</th>
                                    <th>Age</th>
                                    <th>Updated by</th>
                                    <th>Created date</th>
                                  
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                            </table>
                    </div>
                    </div>
    </div>
</div>
</div>
<div class="modal fade" id="EditApp" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel"><center>Edit Student Details</center></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="EditApp_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>
<!-----------------------pay aplication model------------------------------------------------>
<div class="modal fade" id="payApp" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <div class=" d-flex justify-content-center"><h5 class="modal-title" id="staticBackdropLabel"> Application form Payments</h5></div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="payApp_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>
<!----------------------print receipt model------------------->
<div class="modal fade" id="viewreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content">
      </div>
      <div class="modal-footer">

        <center>
 <!-- <button class="btn btn-primary btn-sm" onclick="printable_area('printcashdtls')"><span class="fa fa-print"></span> Print</button> -->
</center> 
        <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
        <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('viewreceipt_content')">Print</button>

        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    // datePickerId.max = new Date().toISOString().split("T")[0];
    $(function () {
        var year = (new Date).getFullYear();
        var day = (new Date).getDate();
        var m = (new Date).getMonth();
        $('#datetimepicker1').datetimepicker({
            // format: 'Y/m/d',
            format:"YYYY-MM-DD",
            minDate: new Date(1950, 0, 1),
            maxDate: new Date(year, m, day)
        });
    });
    $(document).ready(function(){ 
    $(":input").inputmask();     
        // $("#bphone").inputmask({"mask": "(999) 999-9999"});
    });



  function Save_Application(){
   // alert($('#save_application').serialize());
   // return;
    $.ajax({
        beforeSend: function () {
              //$('#add_application').prop("disabled", true);
              $('#applcnFDCK').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
        },
        url: 'save_application',
        type: 'POST',
        data: $('#save_application').serialize()+'&'+$("#header_form").serialize(),
        success: function (res) {
            var data = JSON.parse(res);
               $('#applcnFDCK').html('');
              
                Swal.fire({
                    title: data['status'], 
                    html: data['statusDesc'], 
                    icon: data['status']
                  }).then((result) => {
                  if (result.isConfirmed) {
                    if(data['status']=='error'){

                    }else{
                        location.reload();  
                    }
                  }
                });
              },     
        error: function () {
             $('#add_application').prop("disabled", false);
             $('#applcnFDCK').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
        }
    });
  }
  $("#classlevel").change(function(){
        var InputOption = '';
        var clvl = $(this).val();   
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value=''>-Choose Class-</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    var total = response[i]['total'];
                    // if(total <= 0){
                    //     InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Room for New Student'+"</option>";
                    // }else{
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+''+"\xa0"+''+"</option>";
                   // }

                    $("#class").append(InputOption);;
                }
            }
        });
    });
    function edit_application(id){
        
        $('#EditApp').modal('show'); 
        $('#EditApp_content').load('edit_application/'+id);
       
    }
       function pay_application(id){
        
        $('#payApp').modal('show'); 
         $('#payApp_content').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
        $('#payApp_content').load('pay_application/'+id);
       
    }
   function invoice_request(id,lvl){
       var data = 'id='+ id +'&lvl=' + lvl+'&'+$("#header_form").serialize();
       //alert(data);
        $.ajax({
            beforeSend: function () {
              $('#applcnFDCK').append('<div class="alert alert-primary alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button><i class="fa fa-spinner fa-spin"></i>Preparing Control Number Please wait..</div>');
            },
            type: "POST",
            url: 'request_control_number',
            data: data,
              success: function (res) {
               $('#applcnFDCK').html('');
               swal({
                    title: "successful", 
                    text: res, 
                    type: "success"
                  },
                function(){ 
                    location.reload();
                }
             );
            },
            error: function () {
                $('#applcnFDCK').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
            }
        });
    }

    function print_receipt(inv){
      $('#viewreceipt').modal('show');
      $('#viewreceipt_content').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>'); 
      $('#viewreceipt_content').load('print_receipt/'+inv);
    }

    function printable_rept(area) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=700, height=600, left=100, top=25";
        var content_vlue = document.getElementById(area).innerHTML;

        var docprint = window.open("", "", disp_setting);
        docprint.document.open();
        docprint.document.write('<html><head><title>MHI</title><link rel="stylesheet" href="<?php echo base_url() . 'syst_assets/'; ?>bootstrap/css/bootstrap.css">');
        $('#ReptHeader').load('<?php echo base_url() . 'index.php/Gp_ctrl/load_printable_header'; ?>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }

     $('#Rept1Result').submit(function (e) {
            
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Loading..');
            var dta = "class=" + $('#cls option:selected').val()+ "&status=" + $('#status option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
                //url: '<?php echo base_url() . '/staff_report'; ?>',
                url: '<?php echo base_url() . '../index.php/StudentController/selection_report'; ?>',
                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
     function check_sms(msgid){
                //alert(msgid);
            var data = "id=" + msgid;
              $.ajax({
            type: 'POST',
          url: '<?php echo base_url() . '/index.php/SystemController/check_sms/'; ?>'+msgid,
            data: data,
            success: function (res) {
            
              
            },
            error: function (){
                alert('error encounted');
            }
        });
            }
            $('#Rept1Result_app').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#Rept1Result_app').html('Please specify valid date.');
        } else {
            $('#application_area').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn span').html();
            //alert(dta);
            $.ajax({
                type: "POST",
                //url: '<?php echo base_url() . '/receipt2'; ?>',
             url: "<?php echo base_url() . '/index.php/StudentController/fetch_application'; ?>",
                data: dta,
                success: function (res) {
                    $('#application_area').html(res);
                },
                error: function () {
                    $('#application_area').html('<div class="alert alert-warning">Fail to retreive applications.!!</div>');
                }
            });

}
        e.preventDefault();
    });

             $(function () {
            var start = moment();
            var end = moment();
            function cb(start, end) {
                $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
            }
            $('#daterange-btn').daterangepicker({
                startDate: start,
                endDate: end,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                     'This Year': [moment().startOf('year'), moment().endOf('year')]
                }
            }, cb);
            cb(start, end);

     });
  function search_student(){
  var mydat = 'appname='+ $('#appname').val();
      // alert(mydat);
      // return;
  $.ajax({
    type: "POST",
    url: '<?php echo base_url() . '/index.php/SystemController/search_application'; ?>',
    data: mydat,
    success: function (res) {
        $('#name_loaded').html(res); 
},
error: function () {
   alert('Something went wrong');           
}
});

}
  function select_name(id,fullname){
  var mydat = 'id='+ id;
      // alert(mydat);
      // return;
  $.ajax({
    type: "POST",
    url: '<?php echo base_url() . '/index.php/SystemController/get_application_name'; ?>',
    data: mydat,
    success: function (res) {
          $('#name_loaded').html(''); 
       var data = JSON.parse(res);
       // alert(data.student[0]['first_name']);
       //   return; 
        //alert(data[0]['first_name']);  
       $('input[name=fname]').val(data.student[0]['first_name']);
       $('input[name=mname]').val(data.student[0]['middle_name']);
       $('input[name=lname]').val(data.student[0]['last_name']);
       $('input[name=dob]').val(data.student[0]['birth_date']);
        $('input[name=pfname]').val(data.parent[0]['first_name']);
        $('input[name=plname]').val(data.parent[0]['last_name']);
        $('input[name=bphone]').val(data.parent[0]['phone1']);
       if(data.student[0]['gender']=='Female'){
         document.getElementById("female").setAttribute("checked","true");
     }else{
        document.getElementById("male").setAttribute("checked","true");
    }
    var data ='<input type="hidden" name="ap_id" value="'+ data.student[0]['id'] +'"><input type="hidden" name="classlevel2" value="'+ data.student[0]['level_id'] +'"><input type="hidden" name="class2" value="'+ data.student[0]['class_id'] +'" >';
            $('#name_loaded').append(data);
},
error: function () {
    alert('Sorry!, Something went wrong');
}
});

}
</script>    