<style>
    
</style>
<?php
    $student_model = new App\Models\StudentModel();
    $amodel = new App\Models\AdmissionModel();
    //echo session()->get('user_id');
    //echo $_SESSION['user_id'];
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Aliens Students</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Alien Students</li>
                </ol>
            </div>
          
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="application-tab" data-toggle="tab" href="#app-all">Alien Student List</a></li>
                <li class="nav-item"><a class="nav-link" id="application-tab" data-toggle="tab" href="#app-add">New Alien Student</a></li>
                
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="application-tab" data-toggle="tab" href="#app-all">Alien Student List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="application-tab" data-toggle="tab" href="#app-add">New Alien Student</a></li>
                
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="app-all">
                 <!--------------------------------------->

              <div class="d-flex justify-content-center">
                <div id="messageDisplayArea"></div>
                    <form id="Rept1Result_other" class="form-inline">
                         Status:
                         <div class="input-group ms-3 me-3">
                            <!-- <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button> -->
                          <select class="form-select form-control" name="statuss" id="status">
                        <option value="0">All</option>
                        <option value="1">Active</option>
                          <option value="2">Inactive</option>
                         </select>
                        </div>
                      
                <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="other_area"></div>
                </center>
         <!--------------------------------------------->
            </div>
            <div class="tab-pane" id="app-add">
                <div class="card">
                 <section class="wizard-section">
                    <div class="card-header" style="height:5px">
                        <h3 class="card-title">Registration Form</h3>
                        <div class="card-options ">
                            <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                        </div>
                    </div>
                    <hr>
                    <div class="card-body">
                        <div id="applcnFDCK"></div>
                          <form id="save_others" class="form-horizontal">
                        <h3 class="card-title">Student Details</h3>
                            <div class="form-group row mb-3">
                                <label class="col-md-2 col-form-label">Names<span class="text-danger">*</span></label>
                                <div class="col-md-3">
                                    <input type="text" class="form-control" name="fname" placeholder="First Name" autocomplete="off">
                                </div>
                                <div class="col-md-3">
                                    <input type="text" class="form-control" name="mname" placeholder="Middle Name" autocomplete="off">
                                </div>
                                <div class="col-md-3">
                                    <input type="text" class="form-control" name="lname" placeholder="Last Name" autocomplete="off">
                                </div>
                            </div>
                            <div class="form-group row mb-3">
                                <label class="col-md-2 col-form-label">Date of Birth<span class="text-danger">*</span></label>
                                <div class="col-md-3">
                                    <!-- <input type="date" class="form-control" id="datePickerId" name="dob" placeholder="F"  min="2007-12-31"> -->
                                    <input type='text' class="form-control"  name="dob" id='datetimepicker1'/>
                                </div>

                                <label for="" class="col-md-2 col-form-label">Gender<span class="text-danger">*</span></label>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input mt-1" type="radio" name="gender" id="female" value="Female">
                                        <label class="form-check-label" for="day">
                                        Female
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input mt-1" type="radio" name="gender" id="male" value="Male">
                                        <label class="form-check-label" for="board">
                                        Male
                                        </label>
                                    </div>
                                </div>
                            </div>
                        <div class="form-group row mb-3">
                         <label class="col-md-2 col-form-label">Phone<span class="text-danger">*</span></label>
                                <div class="col-md-4">
                                    <input type="tel" class="form-control" name="bphone" id="bphone" placeholder="+255-xxx-xxx-xxx" value="255" size="20" minlength="9" maxlength="13" required autocomplete="off" data-inputmask="'mask': '999-999999999'">
                                </div>
                                
                            </div>
                        <hr>
                        
                            </div>
                            <div class="form-group row mb-3">
                                <div class="col-md-3"></div>
                                <div class="col-md-4 offset-md-4 pull-right">
                                    <span class="float-right">
                                       <button type="reset" class="btn btn-secondary"><i class="fa fa-ban"></i> Cancel</button>&nbsp;&nbsp;
                                       <button type="button" class="btn btn-primary" id="add_application" onclick="Save_others()"><i class="fa fa-save"></i>&nbsp; Save</button> 
                                    </span>
                              </div>
                            </div>
                        </form>
                  </div>
                    
                    </section>
                    </div>
                 </div>

          
</div>
</div>
<div class="modal fade" id="EditOther" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel"><center>Edit Student Details</center></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="EditOther_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>
<!-----pay aplication model------------------------------------------------>
<div class="modal fade" id="payApp" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <div class=" d-flex justify-content-center"><h5 class="modal-title" id="staticBackdropLabel"> Application form Payments</h5></div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="payApp_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>
<!----------------------print receipt model------------------->
<div class="modal fade" id="view_aliens" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><center>View Aliens Students Details</center></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="aliens_content">
      </div>
      <div class="modal-footer">

     
         <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> 
        <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('aliens_content')">Print</button> -->

        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    // datePickerId.max = new Date().toISOString().split("T")[0];
    $(function () {
        var year = (new Date).getFullYear();
        var day = (new Date).getDate();
        var m = (new Date).getMonth();
        $('#datetimepicker1').datetimepicker({
            // format: 'Y/m/d',
            format:"YYYY-MM-DD",
            minDate: new Date(2007, 0, 1),
            maxDate: new Date(year, m, day)
        });
    });
    $(document).ready(function(){ 
    $(":input").inputmask();     
        // $("#bphone").inputmask({"mask": "(999) 999-9999"});
    });



  function Save_others(){
   // alert($('#save_others').serialize());
    $.ajax({
        beforeSend: function () {
              $('#add_application').prop("disabled", true);
              $('#applcnFDCK').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
        },
      url: 'save_others',
        type: 'POST',
        data: $('#save_others').serialize(),
        success: function (res) {
            var data = JSON.parse(res);
            if(data['status'] == 0){
                $('#applcnFDCK').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
//invoice_request(data['student'],$("#classlevel").val());
                $('#save_others')[0].reset();
              // location.reload();
            }else{
                $('#add_application').prop("disabled", false);
                $('#applcnFDCK').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
             }
        },       
        error: function () {
             $('#add_application').prop("disabled", false);
             $('#applcnFDCK').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
        }
    });
  }
  
    function edit_otherstudent(id){
        
        $('#EditOther').modal('show'); 
        $('#EditOther_content').load("<?php echo base_url() . '/index.php/StudentController/edit_otherstudents/'; ?>"+id);
       
    }
    function view_otherstudent(id){
        $('#view_aliens').modal('show'); 
        $('#aliens_content').load("<?php echo base_url() . '/index.php/StudentController/view_aliens/'; ?>"+id);
    }
       function pay_application(id){
        
        $('#payApp').modal('show'); 
         $('#payApp_content').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
        $('#payApp_content').load('pay_application/'+id);
       
    }

   function invoice_request(id,lvl){
       var data = 'id='+ id +'&lvl=' + lvl+'&'+$("#header_form").serialize();
       //alert(data);
        $.ajax({
            beforeSend: function () {
              $('#applcnFDCK').append('<div class="alert alert-primary alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button><i class="fa fa-spinner fa-spin"></i>Preparing Control Number Please wait..</div>');
            },
            type: "POST",
            url: 'request_control_number',
            data: data,
              success: function (res) {
               $('#applcnFDCK').html('');
               swal({
                    title: "successful", 
                    text: res, 
                    type: "success"
                  },
                function(){ 
                    location.reload();
                }
             );
            },
            error: function () {
                $('#applcnFDCK').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
            }
        });
    }

    function print_receipt(inv){
      $('#viewreceipt').modal('show');
      $('#viewreceipt_content').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>'); 
      $('#viewreceipt_content').load('print_receipt/'+inv);
    }

    function printable_rept(area) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=700, height=600, left=100, top=25";
        var content_vlue = document.getElementById(area).innerHTML;

        var docprint = window.open("", "", disp_setting);
        docprint.document.open();
        docprint.document.write('<html><head><title>MHI</title><link rel="stylesheet" href="<?php echo base_url() . 'syst_assets/'; ?>bootstrap/css/bootstrap.css">');
        $('#ReptHeader').load('<?php echo base_url() . 'index.php/Gp_ctrl/load_printable_header'; ?>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }

      $('#Rept1Result_other').submit(function (e) {
             $('#other_area').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            //var dta = "thedate=" + $('#daterange-btn span').html();
            var dta = "status=" + $('#status').val();
            //alert(dta);
            $.ajax({
                type: "POST",
                
             url: "<?php echo base_url() . '/index.php/StudentController/fetch_otherstudent'; ?>",
                data: dta,
                success: function (res) {
                    $('#other_area').html(res);
                },
                error: function () {
                    $('#other_area').html('<div class="alert alert-warning">Fail to retreive students.!!</div>');
                }
            });


        e.preventDefault();
    });

             $(function () {
            var start = moment();
            var end = moment();
            function cb(start, end) {
                $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
            }
            $('#daterange-btn').daterangepicker({
                startDate: start,
                endDate: end,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                     'This Year': [moment().startOf('year'), moment().endOf('year')]
                }
            }, cb);
            cb(start, end);

                            });
</script>    