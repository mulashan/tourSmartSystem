<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>

<?php 

    $cmodel = new App\Models\ClassesModel();
    $amodel = new App\Models\AdmissionModel();

    $classLevl = $cmodel->get_all_classLevel();
    $classList = $cmodel->load_allSaved_Classes();
    $boardFee = $cmodel->load_boarding_fee();
    $account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Classes</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                        <?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
                    </a></li>
                    <li class="breadcrumb-item active" aria-current="page">Classes</li>
                </ol>
            </div>
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#Class-all">Classes List</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#Class-add">Add Class</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="Class-all">
                <div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable">
                            <thead>
                                <tr>
                                    <th>Class ID</th>
                                    <th>Class Name</th>
                                    <th>Class Level</th>
                                    <th>No. Stream(s)</th>
                                    <th>Status</th>
                                     <th>Updated By</th>
                                    <th>Updated Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $status=""; foreach ($classList as $list): 
                                    if($list->status == 1){ 
                                        $status = "<b style='color:green;'>Active</b>";
                                    }else{
                                        $status = "<b style='color:red;'>Inative</b>";
                                    }

                                    $count = $cmodel->get_number_ofStreams($list->id);
                                 ?>
                                    <tr>
                                        <td><?= $list->id; ?></td>
                                        <td><?= $list->class_name; ?></td>
                                        <td><?= $list->level_name; ?></td>
                                        <td><?= $count[0]->stream_name; ?></td>
                                        <td><?= $status; ?></td>
                                        <td><?= $list->first_name." ".$list->last_name; ?></td>
                                        <td><?= $list->updated_date; ?></td>
                                        <td>
                                            <button type="button" class="btn btn-primary btn-sm editBtn" data-id="<?= $list->id;?>"><i class="fa fa-edit"></i> Edit</button>
                                            <!-- <button type="button" class="btn btn-danger btn-sm remove"  data-id="<?php //echo $list->id;?>"><i class="fa fa-trash"></i></button> -->
                                            <a href="#" data-toggle="modal" class="btn btn-primary btn-sm view" c_id="<?php echo $list->id;?>"><i class="fa fa-eye"></i> View</a>
                                        </td>
                                    </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="tab-pane" id="Class-add">
                <div class="card">
                    <div class="card-header" style="height:5px">
                        <h3 class="card-title">Add New Class</h3>
                        <div class="card-options ">
                            <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                        </div>
                    </div>
                    <hr>
                    <div class="card-body">
                        <form class="form-horizontal" id="addClass">
                             <div id="fdbkarea"></div>
                            <div class="form-group row">
                                <label class="col-md-2 col-form-label">Class Name <span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" name="cname" required="required">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 col-form-label">Class Level <span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <select name="classlvl" id="clevel" class="form-control" required="required">
                                        <option value="">--Select Level--</option>
                                        <?php foreach ($classLevl as $level): ?>
                                            <option value="<?= $level->id; ?>"><?= $level->level_name; ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 col-form-label">Stream Name<span class="text-danger">*</span><span class="text-danger"></span></label>
                                <div class="col-md-3">
                                    <input type="text" class="form-control" id="stream">
                                </div> 
                                <label class="col-md-2 col-form-label">Seating Capacity<span class="text-danger">*</span><span class="text-danger"></span></label>
                                <div class="col-md-2">
                                    <input type="number" name="class_capacity" class="form-control" id="numb">
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-primary" id="saveData"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>

                           
                            <div class="row">
                                <div class="col-md-2"></div>
                                <div class="col-md-8">
                                    <div class="card">
                                        <table class="table table-hover table-vcenter mb-0 text-nowrap">
                                        <thead>
                                                <tr>
                                                    <th>No#</th>
                                                    <th>Stream Name</th>
                                                    <th>Capacity</th>
                                                    <th>Action</th>
                                                </tr>
                                        </thead>
                                        <tbody  id="display">

                                        </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="form-group row">-->
                            <!--    <label class="col-md-2 col-form-label">Boarding Fee <span class="text-danger">*</span></label>-->
                            <!--    <div class="col-md-8">-->
                            <!--      <select name="hostelFee" id="hfee" class="form-control" required="required">-->
                            <!--            <option selected>--Select fee--</option>-->
                            <!--            <?php foreach ($boardFee as $fee): ?>-->
                            <!--                <option value="<?= $fee->id; ?>"><?= $fee->item_name; ?></option>-->
                            <!--            <?php endforeach ?>-->
                            <!--        </select>-->
                            <!--    </div>-->
                            <!--</div>-->
                            
                            <div class="form-group row">
                                <label class="col-md-2 col-form-label">Charged Items<span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                     <select class="form-select form-control" id="selectItems" style="width:100%;">
                                        <option>Select Items to be Charged</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-2"></div>
                                <div class="col-md-10">
                                    <div class="card">
                                        <p Class=" d-flex justify-content-center mt-3">CHARGED ITEMS</p>
                                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="table" style="">
                                        <thead>
                                                <tr>
                                                    <th>Item No#</th>
                                                    <th>Item Name</th>
                                                    <th>Attribute</th>
                                                    <th>Size</th>
                                                
                                                    <th>Qty</th>
                                                    <th>Price</th>
                                                    <th>Total</th>
                                                    <th>Use Type</th>
                                                    <th>Action</th>
                                                </tr>
                                        </thead>
                                        <tbody id="show_item">
                                        

                                        </tbody>
                                        
                                        </table>
                                        <table>
                                        <tr>
                                        <th col=4>
                                        <span id="val" style="margin-left:400px;"></span>
                                        </th>
                                        </tr>
                                        </table>
                                        
                                    </div>
                                </div>
                            </div>
                            
                            <!-- <div class="form-group row">
                                <label class="col-md-2 col-form-label">Terms Installment(s)</label>
                                <div class="col-md-8">
                                    <select id="installmnt" class="form-select me-4 form-control form-control-sm">
                                        <option selected>--Select--</option>
                                        <option value="">...</option>
                                    </select>
                                </div>
                            </div> -->
                            
                            
                            <!--<div class="form-group row">-->
                            <!--  <label class="col-md-2 col-form-label">Installment Terms<span class="text-danger">*</span></label>-->
                            <!--  <form>-->
                            <!--    <div class="col-md-2">-->
                            <!--        <?php $terms = $cmodel->get_all_terms();?>-->
                            <!--       <select name="install" class="form-select">-->
                            <!--        <option value="" selected>select term</option>-->
                            <!--        <?php foreach($terms as $term){?>-->
                            <!--          <option value="<?php echo $term->id;?>"><?php echo $term->term_name; ?></option>-->
                            <!--          <?php } ?> -->
                            <!--       </select>-->
                            <!--    </div>-->
                            <!--    <input type="hidden" class="form-control" value="0" name="ids" placeholder="" id="type"> -->
                            <!--   <label class="col-md-1 col-form-label">Amount<span class="text-danger">*</span></label>-->
                            <!--    <div class="col-md-2">-->
                            <!--        <input type="number"  class="form-control" name="amount" id="amount" placeholder="Amount">-->
                            <!--        <span class="text-danger" id="more"></span>-->
                            <!--    </div>-->
                               <!--  <label class="col-md-1 col-form-label">Duedate<span class="text-danger"></span></label>
                                 <div class="col-md-2">
                                    <input type="date" class="form-control" name="duedate" placeholder="Duedate" id="duedate">
                                </div> -->
                            <!--    <div class="col-md-1">-->
                            <!--        <button type="button" class="btn btn-primary" id="temp"><i class="fa fa-plus"></i></button>-->
                            <!--    </div>-->
                            <!--</div>-->

                            <!--<div class="row">-->
                            <!--    <div class="col-md-2"></div>-->
                            <!--    <div class="col-md-8">-->
                            <!--        <div class="card">-->
                            <!--            <p Class=" d-flex justify-content-center mt-3">TERMS INSTALLMENT(S)</p>-->
                            <!--            <table class="table table-hover table-vcenter mb-0 text-nowrap" id="table2">-->
                            <!--            <thead>-->
                            <!--                    <tr>-->
                                                    
                            <!--                        <th>Installment Terms</th>-->
                            <!--                        <th>Amount</th>-->
                            <!--                        <th>Due Date</th>-->
                            <!--                        <th>Action</th>-->
                                                    
                                                    
                            <!--                    </tr>-->
                            <!--            </thead>-->
                            <!--            <tbody id="show">-->

                            <!--            </tbody>-->
                                        
                            <!--            </table>-->
                            <!--             <table>-->
                            <!--            <tr>-->
                            <!--            <th col=4>-->
                                      
                            <!--            <span id="remained" style="margin-left:200px;"></span>-->
                            <!--            </th>-->
                            <!--            </tr>-->
                            <!--            </table>-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->
                            <div class="form-group row">
                                <label class="col-md-2 col-form-label">Account Receivable<span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <select name="account" id="account" class="form-control" required="required">
                                        <option value="">--Select Account Receivable--</option>
                                        <?php foreach ($account as $ac): ?>
                                            <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 col-form-label"></label>
                                <div class="col-md-8">
                                    <br>
                                    <button type="submit" id="createbtn" class="btn btn-primary float-right">Create</button>
                                </div>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- Modal -->
    <div id="mModal"  class="modal fade" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" style="width:800px">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="ViewClass"></div>
                </div>
                <div class="modal-footer">
                    
                </div>
            </div>

        </div>
    </div>

<!-- ----edit class modal---- -->
<div id="myModal" class="modal fade"  role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Update Class</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="updateClass"></div>
        </div>
      </div>
      
    </div>
</div>

<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
    var hold_selected_items = []; // hold all selected items
     
    $(document).ready(function(){
         $('#addClass')[0].reset();
  
        $('#remained').val(0);
       // fetch_data();
        $('#show').empty();
         $('#selectItems').select2({
            ajax: {
                url: "<?= base_url('load_data'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

        $('#selectItems').on('select2:select', function (e) {
            selectedItems();
        });
         
        function selectedItems(){  
            var rows = '';
           var itemData = 'item_selected='+$('#selectItems').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Itemdata')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }else{
                        var len  = data.length;

                        for (var i = 0; i <len; i++ ){
                            hold_selected_items.push(data[i]['id']);// push all selected items
                            var prc = data[i]['iprice'];
                            var name = data[i]['iname'];
                            var iid = data[i]['id'];
                            var size = data[i]['isize'];
                            var attr = data[i]['iattr'];
                            
                            var ttl = data[i]['iattr'];

                        var group = data[i]['item_group'];
                    var grp="";
                    if(group==0){
                        grp="Other Item";
                    }else if(group==1){
                        grp="Application";
                    }else if(group==2){
                        grp="New Comer";
                    }
                            
                            rows += '<tr id="table_row'+ iid +'">';
                            rows += '<td><input type="hidden" name="id[]" value="'+iid+'">'+ iid +'</td>';
                            rows += '<td>'+ name +'</td>';
                            rows += '<td>'+ attr +'</td>';
                            rows += '<td>'+ size +'</td>';
                            rows += '<td><input type="number" class="form-control qty" onchange ="totalAmounts('+iid+')" name="qtys'+iid+'" style="width:60px;"></td>';
                            rows += '<td><input type="hidden"  name="prc'+iid+'" value="'+prc+'">'+ prc +'</td>';
                            rows += '<td id="ttl'+iid+'"></td>';
                            rows += '<td id="grp'+iid+'">'+grp+'</td>';
                            rows += '<td><a href="javascript:RemoveSelectItemRow('+iid+');" class="btn btn-danger slt">X</a></td>';
                            rows += '</tr>';
                            $('#show_item').append(rows);
                            
                        }
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }  
           });  
        } 
    });

    function RemoveSelectItemRow(item_id){
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }
       
        $('#table_row'+item_id).remove();
        
    }
     
    $(document).ready(function(){
   
    // code to read selected table row cell data (values).
    $("#table").on('click','.slt',function(){
         
         var currentRow=$(this).closest("tr"); 
         
         var col1=currentRow.find("td:eq(6)").text(); 
          sum=totalAmounts();
          //sum=sumval;
         var data=col1;
         sum=sum-data;
         //remain=sum;
         //alert(remain);
        // document.getElementById("remained").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         document.getElementById("val").innerHTML = "Total = " + sum;
         console.log(sum);
         
    });
});
     var total=0;
    
    function totalAmounts(id){
        $('#ttl' + id).empty();
        var prc = $('input[name=prc' + id+']').val();

        var qty = $('input[name=qtys' + id+']').val();
        var calc = prc*qty; 
        
            
            $('#ttl' + id).append(calc);
            
            var table = document.getElementById("table"), sumVal = 0;
            
            for(var i = 1; i < table.rows.length; i++)
            {
                sumVal = sumVal + parseInt(table.rows[i].cells[6].innerHTML);
            }
            //remain=sumVal;
            document.getElementById("val").innerHTML = "Total = " + sumVal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(sumVal);
            return sumVal;
    }

  
            
            
     $('#addClass').submit(function(e){
        // alert($(this).serialize()+"&stream="+JSON.stringify(myStream));
       
        var strmData = $(this).serialize()+"&stream="+JSON.stringify(myStream)+'&'+$("#header_form").serialize();
        //+"&installment="+JSON.stringify(myInstallment);
       //alert(remain);
        if(remain>0){
        swal('warning','Please! assign '+remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+' to installments','warning');
       }else{
        $.ajax({
            method: 'POST',
            url: '<?= base_url('createNewClass')?>',
            data: strmData,
           
            success:function(res){
                var data =JSON.parse(res);
                 $('#createbtn').prop("disabled", true);
                if(data['status'] == "0"){
                    
                    $("#addClass")[0].reset();
                    $('#fdbkarea').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#fdbkarea').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            },
            error:function(){
                $('#fdbkarea').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Save Class.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
            }
        });
    }
        e.preventDefault();
    })


    var myStream = [];
   $('#saveData').click(function(evt){
        
        var row ="";
        var sn = 1;
        var data = {
            "name" : $('#stream').val(),
            "capacity" : $('#numb').val()
        }
        myStream.push(data);

        var len = myStream.length;

        $('#display').empty();
        $('#stream').val('');
        $('#numb').val('');
        for (i = 0; i < len; i++) {
            
            row += '<tr id="table_row">';
            row += '<td>'+ (i + 1) +'</td>';
            row += '<td>'+ myStream[i].name +'</td>';
            row += '<td>'+ myStream[i].capacity +'</td>';
            row += '<td><a href="javascript:RemoveSelectRow();" class="btn btn-danger">X</a></td>';
            row += '</tr>';

        }
            $('#display').append(row);

        evt.preventDefault();
   });

    function RemoveSelectRow(){
        for( var i = 0; i < myStream.length; i++){                      
            myStream.splice(i, 1); 
        }

        $('#table_row').remove();
    }

   $('.editBtn').click(function(){
       var data = 'id=' + $(this).attr('data-id');
        $('#myModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?= base_url('/edit_class')?>",
            data: data,
            beforSend: function()
            {
                $('#updateClass').html();
            },
            success: function(res){
                $('#updateClass').html(res);
                 
            },
            error: function ()
            {

            }
        });

   });

   $(".remove").click(function(){

        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "You will not be able to recover this Data!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/remove_class')?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      // $("#"+id).remove();
                    swal("Deleted!", "Class has been deleted.", "success");

                    // location.reload();
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                      
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
     var myInstallment = [];
     var sum;
     var mon;
   /*$('#installment').click(function(evt){
        
        var row ="";
        var sn = 1;
        var data = {
            "installname" : $('#install').val(),
            "amount" : $('#amount').val(),
            "duedate" : $('#duedate').val()
        }
        myInstallment.push(data);

        var len = myInstallment.length;

        $('#show').empty();
        $('#install').val('');
        $('#amount').val('');
        $('#duedate').val('');
        
        
        sum=totalAmounts();
        
        //alert(sum);
                      
        for (i = 0; i < len; i++) {
            
          sum=sum-myInstallment[i].amount;
          $('#remained').html('Remained='+sum);
          if(sum>=0){
          $('#more').html('');            
            row += '<tr id="table_row'+i+'">';
            //row += '<td>'+ (i + 1) +'</td>';
            row += '<td>'+ myInstallment[i].installname +'</td>';
            row += '<td>'+ myInstallment[i].amount +'</td>';
            row += '<td>'+ myInstallment[i].duedate +'</td>';
            //row += '<td>'+ sum +'</td>';
            row += '<td><a href="javascript:RemoveRow('+i+','+myInstallment[i].amount+');" class="btn btn-danger">X</a></td>';
            row += '</tr>';
          }else{
            var amount=parseInt(myInstallment[i].amount);
            var k=i;
            if(i==k){
            $('#more').html('Please Enter less or exact amount remain!');
            }
           sum=parseInt(sum+amount);    
            //alert(sum);
                    
          }
          
         }
      
        $('#show').append(row);  
        evt.preventDefault();
    });*/
   function RemoveRow(id,amount){
        for( var i = 0; i < myInstallment.length; i++){                      
            myInstallment.splice(i, 1); 
        }
       sum=sum+amount;
       console.log(sum);
       $('#table_row'+id).remove();
       $('#remained').html('Remained='+sum);
    }
    
    $('#temp').click(function(event){
     totalAmounts();
     //fetch_data();
     //event.preventDefault();
       var data = 'installname=' + $('select[name=install]').val() + '&amount=' + $('input[name=amount]').val()+ '&id=' + $('input[name=ids]').val();
       //alert(data);
       var k=totalAmounts();
       
       if(k==0){
        alert("Enter charged Items first");
       }else{
       if(!remain && remain!=0){
          remain=k; 
       }
       var mount=$('input[name=amount]').val();
       var sum=remain-mount;
       //alert(sum);
       if(sum>=0){
     document.getElementById("more").innerHTML="";
       $.ajax({
            type: 'POST',
           url: 'temporary',
            data: data,
            success:function(data){
                if(data==1){
                    alert("Term, Already Selected");
                    sum=remain+mount;
                }
                fetch_data();
                //totalAmounts();
            }
       });
       }else{
        document.getElementById("more").innerHTML="Enter less amount or equal to "+remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
      $('input[name=amount]').val()="";     
       }}
        event.preventDefault();
    });
    
       var remain;
       function fetch_data(){
        $('#show').empty();
                
        var datta = 'class_id=0';
        $.ajax({
            type: 'GET',
            data: datta,
            //url: 'fetchinstallments',
            url: 'fetchinst',
            success:function(response){
                  console.log(response);
                var temp_data = JSON.parse(response);
                var len = temp_data.length;
                //total=fetch_class_itemsCharged();
                var ttlamount=0;
                for(var i = 0; i < len; i++){
                    var amounted=parseInt(temp_data[i]['amount']);
                    ttlamount=parseInt(ttlamount+amounted);
                    $('#show').append('<tr>'+
                        
                        '<td>'+temp_data[i]['installname']+'</td>\
                        <td>'+temp_data[i]['amount']+'</td>\
                        <td>'+temp_data[i]['duedate']+'</td>\
                        <td>\
                            <a href="javascript:RemoveSelecttemp('+temp_data[i]['id']+');" class="btn btn-danger dlt">x</a>\
                        </td>\
                    </tr>');
                }
        total=totalAmounts();
        //total=temp_data[0]['tamount'];
        remain=total-ttlamount;
        document.getElementById("remained").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(remain);
            }
        });
        
    }
    function RemoveSelecttemp(id)
    {
        $.ajax({
            type: 'GET',
            url: 'delete_temp/'+id,
            success: function(){
                 fetch_data();
                totalAmounts();
            }
        });
    }
    
    $(document).ready(function(){
   
    // code to read selected table row cell data (values).
    $("#table2").on('click','.dlt',function(){
         // get the current row
         var currentRow=$(this).closest("tr"); 
         
         var col1=currentRow.find("td:first").text(); 
         var td= $("#table2").find('td:first').text();
         var firstCell = $(this).find('td').first();
         
         var sum=0;
         
         alert('deleted successfuly');
         remain= totalAmounts();
         document.getElementById("remained").innerHTML = "Remain = " + totalAmounts();
         console.log(sum);
         
         
    });
});
     $(".view").click(function () {
        var data = 'cid=' + $(this).attr('c_id');


        $('#mModal').modal('show');


        $.ajax({
            type: "GET",
            url: "<?= base_url('/class_View')?>",
            data: data,
            beforSend: function()
            {
                $('#ViewClass').html();
            },
            success: function(res){
                $('#ViewClass').html(res);

            },
            error: function ()
            {

            }
        });
    });
</script>