 
<?php 
helper('age');
$studentModel = new App\Models\studentModel();
$ino = "";
$sid = $studentModel->get_max_id('students','student_id');
if (count($sid) > 0) {
    $stid = $sid[0]->max_id + 1;
    $ino = $stid;
} else {
    $ino =  1;
}

 $lmodel = new App\Models\LoginModel();
    $staffModel = new App\Models\StaffModel();
    $imodel = new App\Models\ItemsModel();

   // $staff = $staffModel->get_total_user('station_tbl','user_id',$where = array('status' => 1));
    $cont = $staffModel->get_total_user('admission_tbl','id',$where = array('adimit_for' => 0));
    $new = $staffModel->get_total_user('admission_tbl','id',$where = array('adimit_for' => 2));
     $day = $staffModel->get_total_user('admission_tbl','id',$where = array('admission_type' => 0));
     $bod = $staffModel->get_total_user('admission_tbl','id',$where = array('admission_type' => 3));
    $sales = $imodel->get_total_admision_collection('ledger_transaction_tbl','amount');
    $coll = $imodel->get_total_admision_collected('ledger_transaction_tbl','amount');
    $app = $imodel->get_total_accounts('route_tbl','id');
    $station = $imodel->get_total_accounts('station_tbl','id');
   $pcont=number_format((float)$cont[0]->id/$app[0]->id,2,'.','');
   $pnew=number_format((float)$new[0]->id/$app[0]->id,2,'.','');
   $pday=number_format((float)$day[0]->id/$app[0]->id,2,'.','');
   $pbod=number_format((float)$bod[0]->id/$app[0]->id,2,'.','');
   if($coll[0]->amount>0){
   $pcol=number_format((float)$coll[0]->amount/$sales[0]->amount,4,'.','');
    }else{
        $pcol=0;
    }
   // $pnew=number_format($new[0]->id/$app[0]->id);
  //$perc=($sales[0]->amount/$coll[0]->amount)*100;
?>

<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Transport</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                        <?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
                    </a></li>
                    <li class="breadcrumb-item active" aria-current="page">Transport Dashboard</li>
                </ol>
            </div>
          <!--   <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Student-all">Students List</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Student-add">New Student</a></li>
            </ul> -->
        </div>
    </div>
</div>

<div class="section-body mt-4">
<div class="container-fluid">
    <div class="row mt-3"> 
        <div class="col-md-6">  
            <?php
            $vhcl = $staffModel->get_vehicle('vehicles_list_tbl',$where = array('status' => 1));
            ?>
            <style type="text/css">
                table{
                    border: 1px solid black;
                }
                table tr,th,td{
                      border: 1px solid black;
                      text-align: center;
                      padding: 10px; 
                }
            </style>
<table id="myTable" >
    <thead>
        <tr><th colspan="5">Vehicles Capacity</th></tr>
        <tr>
      <td>Reg</td>
      <td>Name</td>
      <td>Capacity</td>
      <td>Occupied</td>
      <td>Rate%</td>
        </tr>
    </thead>
    <tbody>
        <?php
foreach($vhcl as $vh){
        ?>
        <tr>
            <td><?=$vh->vehicle_number;?></td>
            <td><?=$vh->driver_contact;?></td>
            <td><?=$vh->capacity;?></td>
            <td></td>
            <td></td>
        </tr>
        <?php }?>
    </tbody>
</table>
        </div>
  

    <div class="col-6 col-md-4 col-xl-2 mt-5">
        <div class="card" style="background-color:#8A3324;">
            <div class="card-body ribbon">
             
                   <span style="color:white;">No Of Routes</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= $app[0]->id; ?></span></h5>
             
            </div>
        </div>
    </div>

     <div class="col-6 col-md-4 col-xl-2 mt-5">
        <div class="card" style="background-color:#3D2B1F;">
            <div class="card-body ribbon">
             
                   <span style="color:white;"> No Of Stations</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= $station[0]->id; ?></span></h5>
             
            </div>
        </div>
    </div>
   <!--  <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:  #8A3324;">
            <div class="card-body ribbon">
             
                   <span style="color:white;">COLLECTED</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= number_format($coll[0]->amount); ?></span></h5>
                   <h5><b><span style="color:yellow;"><?= ($pcol)*100; ?>%</span></b></h5>
                    <h6 id="OPDtotal"><span style=""></span></h6> --
             
            </div>
        </div>
    </div>
  <div class="col-6 col-md-4 col-xl-3">
        <div class="card" style="background-color:green;">
            <div class="card-body ribbon">
             
                   <span style="color:white;"> CONTINOUS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= $cont[0]->id; ?></span></h5>
                    <h5><b><span style="color:yellow;"><?= ($pcont)*100; ?>%</span></b></h5>
             
            </div>
        </div>
    </div>
        <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:#3D2B1F;">
            <div class="card-body ribbon">
             
                   <span  style="color: white;">NEW</span>
                    <br>
                   <h5 id="slctotal"><span style="color: white;"><?= $new[0]->id; ?></span></h5>
                    <h5><b><span style="color: yellow;"><?= (($pnew)*100); ?>%</span></b></h5>
            </div>
        </div>
    </div>
      <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:#7BB661;">
            <div class="card-body ribbon">
             
                   <span>DAY</span>
                    <br>
                   <h5 id="slctotal"><span><?= $day[0]->id; ?></span></h5>
                    <h5><b><span style="color: yellow;"><?= (($pday)*100); ?>%</span></b></h5>
            </div>
        </div>
    </div>
      <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:  #555D50;">
            <div class="card-body ribbon">
             
                   <span style="color:white;">BOARDING</span>
                    <br>
                   <h5 id="slctotal"><span style="color:white;"><?= $bod[0]->id; ?></span></h5>
                     <h5><b><span style="color: yellow;"><?= (($pbod)*100); ?>%</span></b></h5>
            </div>
        </div>
    </div> -->  

    </div>


       <div class="row mt-3"> 
        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">GENDER PIE</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="genderadmition">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">Transport By Class Level</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="contvsnew">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
    </div>

       <div class="row mt-3"> 
        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">Transport By Class</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="admitiontype">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
       <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">No Of Students by Route</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="salesvscoll">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div> 
    </div>

       <div class="row mt-3"> 
        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">Sales By Route</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="admitionbylevel">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
     
    </div>
    </div> 
    </div>
<script>
   

$(document).ready(function () {
       // loadAdimissionGender();
       // loadContVsNew();
       // admitiontype();
       // selColl();
       // admitionbylevel();
       // admitionbyclass();
    });

// function loadapp() {
//          $('#classlevel').load('<?php echo base_url() . '../index.php/StudentController/get_classlevel_details'; ?>');
//     }
  
function loadAdimissionGender() {
        $.ajax({
            beforeSend: function () {
                $('#genderadmition').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'../index.php/StudentController/get_AdimissionGender_details'?>',
            success: function (result) {
                $('#genderadmition').html(result);
            },
            error: function () {
                $('genderadmition').html('Sorry! Something went wrong.');
            }
        });
    }
    function loadContVsNew() {
        $.ajax({
            beforeSend: function () {
                $('#contvsnew').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'../index.php/StudentController/get_contVsNew_details'?>',
            success: function (result) {
                $('#contvsnew').html(result);
            },
            error: function () {
                $('contvsnew').html('Sorry! Something went wrong.');
            }
        });
    }
      function admitiontype() {
        $.ajax({
            beforeSend: function () {
                $('#admitiontype').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'../index.php/StudentController/get_admitiontype_details'?>',
            success: function (result) {
                $('#admitiontype').html(result);
            },
            error: function () {
                $('admitiontype').html('Sorry! Something went wrong.');
            }
        });
    }
    function selColl() {
        $.ajax({
            beforeSend: function () {
                $('#salesvscoll').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'../index.php/StudentController/get_selColl_details'?>',
            success: function (result) {
                $('#salesvscoll').html(result);
            },
            error: function () {
                $('salesvscoll').html('Sorry! Something went wrong.');
            }
        });
    }
     function admitionbylevel() {
        $.ajax({
            beforeSend: function () {
                $('#admitionbylevel').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'../index.php/StudentController/admitionbylevel_details'?>',
            success: function (result) {
                $('#admitionbylevel').html(result);
            },
            error: function () {
                $('admitionbylevel').html('Sorry! Something went wrong.');
            }
        });
    }
      function admitionbyclass() {
        $.ajax({
            beforeSend: function () {
                $('#admitionbyclass').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'../index.php/StudentController/admitionbyclass_details'?>',
            success: function (result) {
                $('#admitionbyclass').html(result);
            },
            error: function () {
                $('admitionbyclass').html('Sorry! Something went wrong.');
            }
        });
    }
</script>