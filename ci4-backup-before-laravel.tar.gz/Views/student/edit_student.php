<ul class="nav nav-tabs tab-primary page-header-tab">
    <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Student-details">Students Details</a></li>
    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#parent-details" onclick="parent_data()" >Parent/Guardian Details</a></li>
    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#school-details" onclick="load_previous_school()">Previous School Details</a></li>
    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#bill-info">Bill Information Details</a></li>
</ul>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="Student-details">
                <div id="UpadateFedbck"></div>
            <form  method="post" id="updatetudent" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <div class="row mb-3">
                            <label for="fname" class="col-sm-4 col-form-label col-form-label-sm">First Name<span class="text-red">*</span></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control form-control-sm"  name="firstname" placeholder="First Name" value="<?= $student[0]->first_name; ?>">
                                <input type="hidden"  name="studentid" value="<?= $student[0]->id; ?>">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="mname" class="col-sm-4 col-form-label col-form-label-sm">Middle Name<span class="text-red">*</span></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control form-control-sm"  name="mname" placeholder="Middle Name" value="<?= $student[0]->middle_name; ?>">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="lname" class="col-sm-4 col-form-label col-form-label-sm">Last Name<span class="text-red">*</span></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control form-control-sm"  name="lname" placeholder="Last Name" value="<?= $student[0]->last_name; ?>">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="dob" class="col-sm-4 col-form-label col-form-label-sm">Date of Birth<span class="text-red">*</span></label>
                            <div class="col-sm-6">
                                <input type="date" class="form-control form-control-sm"  name="dob" placeholder="Date of Birth" value="<?= $student[0]->birth_date; ?>">
                            </div>
                        </div>
                        <fieldset class="row mb-3">
                            <legend class="col-sm-4 col-form-label col-form-label-sm">Gender<span class="text-red">*</span></legend>
                            <div class="col-sm-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender"  value="Male" <?php if($student[0]->gender == "Male") echo "checked";?>>
                                    <label class="form-check-label" for="male">
                                    Male
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender"  value="Female" <?php if($student[0]->gender == "Female") echo "checked";?>>
                                    <label class="form-check-label" for="female">
                                    Female
                                    </label>
                                </div>
                            </div>
                        </fieldset>
                        <div class="row mb-3">
                            <label for="ntlity" class="col-sm-4 col-form-label col-form-label-sm">Nationality<span class="text-red">*</span></label>
                            <div class="col-sm-6">
                                <input list="nationality" name="nationalty"  class="form-control form-control-sm" value="<?php echo $student[0]->nationality; ?>">
                                    <datalist id="nationality">
                                       <?php
                                            foreach($nation as $natn){
                                                 ?>
                                           <option value="<?php echo $natn->nation; ?>"<?php
                                              if ($student[0]->nationality == $natn->nation) {
                                                  echo 'selected';
                                                  }?>><?php echo $natn->nation; ?></option>
                                          <?php
                                            }
                                          ?>
                                    </datalist>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row mb-3">
                            <legend class="col-sm-4  col-form-label col-form-label-sm">Profile Photo</legend>
                            <div class="col-sm-5">
                                <div><img src="<?php echo base_url('public/student_photos/'.$student[0]->student_photo);?>"  class="p-photo  mb-2 img-thumbnail" alt="" style="width:80px; height:100px;border: 1px wheat solid"></div>
                                <input type="file"   name="imgFile" value="<?= $student[0]->student_photo; ?>" >
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="religion" class="col-sm-4 col-form-label col-form-label-sm">Religion<span class="text-red">*</span></label>
                            <div class="col-sm-6">
                                <select id="religion" name="religion" class="form-select form-control form-control-sm" required="">
                             <?php 
                                $db=session()->get('db_id');
                                if($db==4){
                                 ?>
                              <option value="Catholic" selected>Catholic</option>
                                <?php }else{ ?>
                                     <option value="Christianity" <?php if ($student[0]->religion == 'Christianity') { echo 'selected'; } ?>>Christianity</option>
                                     <option value="Islam" <?php if ($student[0]->religion == 'Islam') { echo 'selected'; } ?>>Islam</option>
                                     <option value="Hinduism" <?php if ($student[0]->religion == 'Hinduism') { echo 'selected'; } ?>>Hinduism</option>
                                     <option value="Buddhism" <?php if ($student[0]->religion == 'Buddhism') { echo 'selected'; } ?>>Buddhism</option>
                                     <option value="Others" <?php if ($student[0]->religion == 'Others') { echo 'selected'; } ?>>Others</option>>
                                 <?php }?>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="gnno" class="col-sm-4 col-form-label col-form-label-sm">Government No</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control form-control-sm"  name="gnno" placeholder="Government No" value="<?= $student[0]->government_no; ?>">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="regid" class="col-sm-4 col-form-label col-form-label-sm">Student Id<span class="text-red">*</span></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control form-control-sm"  name="regid" placeholder="Student Id" value="<?= $student[0]->student_id; ?>">
                            </div>
                        </div>
         <div class="row mb-3">
    <label for="religion" class="col-sm-4 col-form-label col-form-label-sm">Initial Class<span class="text-danger">*</span></label>
    <div class="col-sm-6">
        <select id="iclass" name="iclass" class="form-select form-control form-control-sm" required="">
            <option value="" reruired="required">-select-</option>
            <?php 
            $studentModel = new App\Models\studentModel();
             $classes = $studentModel->gettable_data('classes_tbl', $where = array('status' => 1));
             if(count($classes)>0){
             foreach($classes as $cl){
             if($student[0]->initial_class==$cl->id){
             ?>
          <option value="<?php echo $cl->id;?>" selected><?php echo $cl->class_name;?></option>
      <?php }else{?>
          <option value="<?php echo $cl->id;?>" ><?php echo $cl->class_name;?></option>
            <?php }}}?>
        </select>
    </div>
</div>
                    </div>
                </div>
                <?php
            $checkAdmitted = $studentModel->gettable_data('admission_tbl', $where = array('student_id' => $student[0]->id));
                    if(count($checkAdmitted)>0){
                        $btnState="disabled";
                    }else{
                     $btnState="";   
                    }
                ?>
                <button type="button" class="btn btn-danger float-left btn-sm <?= $btnState;?>" onclick="delete_student(<?php echo $student[0]->id;?>)" ><i class="fa fa-trash"></i> Delete</button>

                <div class="form-group clearfix">
                    <button class="btn btn-primary float-right" type="submit" id="update_student">Update</button>
                   
                </div>
               </form>
                
            </div>
            <div class="tab-pane" id="parent-details">
                <div id="errorshowparent"></div>
                <div class="row">
                    <div class="row mb-4">
                        <label for="parentsearch" class="col-sm-2 col-form-label col-form-label-sm">Search Parent</label>
                        <div class="col-sm-5">
                            <input type="search" class="form-control form-control-sm" id="parentsID" name="parentsID" placeholder="Search Parent Here">
                        </div>
                        <button class="btn btn-primary col-sm-1" type="button" onclick="search_parent()">Search</button>
                        <div class="col-sm-4">
                            <button class="btn btn-primary" type="button" onclick="add_newParents()"><i class="fa fa-plus"></i> Add New Parent</button>
                        </div>
                        <hr class="mt-3">
                    </div>
                    <div class="row mb-4">
                        <div class="col-sm-12">
                             <div id="Parent_loaded"></div>
                             <div id="NewParent" style="display:none;">
                                <div id="save_status"></div>
                                 <form id="update_parent_dtls" class="needs-validation" novalidate>
                        <div class="row">
                                <div class="col-md-6">
                                        <div class="row mb-3">
                                                <label for="pname" class="col-sm-4 col-form-label col-form-label-sm">First Name<span class="text-red">*</span></label>
                                                <div class="col-sm-6">
                                                        <input type="hidden"  name="studentid" value="<?= $student[0]->id; ?>">
                                                        <input type="hidden" class="form-control" id="parentid" name="parentid" value="" placeholder="First Name" required>
                                                        <input type="text" class="form-control form-control-sm" id="Pfname"  name="pname" placeholder="First Name" required>
                                                         <div class="invalid-feedback">First Name is required.</div>
                                                </div>
                                        </div>
                                        <div class="row mb-3">
                                                <label for="plname" class="col-sm-4 col-form-label col-form-label-sm">Last Name<span class="text-red">*</span></label>
                                                <div class="col-sm-6">
                                                        <input type="text" class="form-control form-control-sm" id="Plname" name="plname" placeholder="Last Name" required="">
                                                            <div class="invalid-feedback">Last Name is required.</div>
                                                </div>
                                        </div>
                                        <div class="row mb-3">
                                                <label for="rltn" class="col-sm-4 col-form-label col-form-label-sm">Relation<span class="text-red">*</span></label>
                                                <div class="col-sm-6">
                                                        <select  name="rltn" class="form-select form-control form-control-sm" id="Prelation" required>
                                                                <option value="">Choose</option>
                                                                <option value="1">Mother</option>
                                                                <option value="2">Father</option>
                                                                <option value="3">Guardian</option>
                                                        </select>
                                                             <div class="invalid-feedback">Relation is required.</div>
                                                </div>
                                        </div>
                                        <div class="row mb-3">
                                                <label for="email" class="col-sm-4 col-form-label col-form-label-sm">Email</label>
                                                <div class="col-sm-6">
                                                        <input type="email" class="form-control form-control-sm" id="Pemail"  name="email" placeholder="eg: example@gmail.com">
                                                </div>
                                        </div>
                                </div>
                                <div class="col-md-6">
                                        <div class="row mb-3">
                                                <label for="addrs" class="col-sm-4 col-form-label col-form-label-sm">Address<span class="text-red">*</span></label>
                                                <div class="col-sm-6">
                                                        <input type="text" class="form-control form-control-sm" id="Paddress" name="addrs" placeholder="Home Address" required="">
                                                        <div class="invalid-feedback">Address is required.</div>
                                                </div>
                                        </div>
                                        <div class="row mb-3">
                                                <label for="occp" class="col-sm-4 col-form-label col-form-label-sm">Occupation<span class="text-red">*</span></label>
                                                <div class="col-sm-6">
                                                        <input type="text" class="form-control form-control-sm" id="Poccp"  name="occp" placeholder="Occupation" required="">
                                                        <div class="invalid-feedback">Occupation is required.</div>
                                                </div>
                                        </div>
                                        <div class="row mb-3">
                                                <label for="phone1" class="col-sm-4 col-form-label col-form-label-sm">Phone Number 1<span class="text-red">*</span></label>
                                                <div class="col-sm-6">
                                                 
                                                    <input type="text" class="form-control" value="+255" name="phone1" id="Pphone1" placeholder="+255-xxx-xxx-xxx"  minlength="9"  maxlength="13"   autocomplete="off">
                                                    <!--<div class="invalid-feedback">Please enter a valid phone number (e.g., +255712345678).</div>-->
                                                </div>
                                        </div>
                                        <div class="row mb-3">
                                                <label for="phone2" class="col-sm-4 col-form-label col-form-label-sm">Phone Number 2</label>
                                                <div class="col-sm-6">
                                                  
                                        <input type="text" class="form-control" value="" name="phone2" id="Pphone2" placeholder="+255-xxx-xxx-xxx"  minlength="9"  maxlength="13">
                                                    <!--<div class="invalid-feedback">Please enter a valid phone number (e.g., +255712345678).</div>-->
                                                </div>
                                        </div>

                                </div>
                                <div class="d-flex justify-content-end mt-2 mb-3">
                                    <input type="reset" class="btn btn-secondary" value="Cancel" onclick="cancelbtn(1)" >&nbsp;&nbsp;
                                        <button type="button" class="btn btn-primary" onclick="register_parent()" id="addparent"><i class="fa fa-plus me-2"></i>Add</button>
                                        <button type="button" class="btn btn-primary" onclick="update_parent()" id="updateparent"><i class="fa fa-edit" ></i> Update</button>
                                </div>
                        </div>
                    </form>
                             </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                        <div ></div>
                        <div class="card mb-5">
                            <div class="card-body">
                                <table class="table table-hover table striped">
                                    <thead>
                                        <tr>
                                            <th>No#</th>
                                            <th>Name</th>
                                            <th>Relation</th>
                                            <th>Phone No</th>
                                            <th>Email</th>
                                            <th>Occupation</th>
                                            <th>Address</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="edit_show_parent">
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
               
            </div>
            <div class="tab-pane" id="school-details">
              <form id="previous_school_update">
                <div class="row">
                    <h5>Previously Schools Attended</h5>
                    <div class="col-md-6">
                        <div class="row mb-3">
                            <label for="scname" class="col-sm-4 col-form-label col-form-label-sm">School Name<span class="text-red">*</span></label>
                            <div class="col-sm-6">
                                <input type="hidden"  name="studentid" value="<?= $student[0]->id; ?>">
                                <input type="text" class="form-control form-control-sm" id="Pschool" name = "scname" placeholder="School Name" required="">
                                <input type="hidden" class="form-control form-control-sm" id="PcId" name ="PcId" >
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row mb-3">
                            <label for="scyr" class="col-sm-4 col-form-label col-form-label-sm">Year Attended<span class="text-red">*</span></label>
                            <div class="col-sm-6">
                                <input type="text" min="1900" step="1" value="2016" class="form-control form-control-sm" id="Pyear" name = "scyr" placeholder="Year Attended" required="">
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end mt-2 mb-3">
                         <input type="reset" class="btn btn-secondary" value="Cancel" onclick="cancelbtn(2)" >&nbsp;&nbsp;
                         <button type="button" class="btn btn-primary" onclick="update_school()" id="updateschool"><i class="fa fa-edit" ></i> Update</button>
                         <button type="button" class="btn btn-primary" id="addschool" onclick="add_schools()"><i class="fa fa-plus me-2" ></i>Add</button>
                    </div>
                </div>
                </form>
                    <div class="row">
                    <div class="card mb-5">
                        <div class="card-body">
                            <div id="ErrorEditprevious_school"></div>
                            <table class="table table-hover table striped">
                                <thead>
                                    <tr>
                                        <th>No#</th>
                                        <th>School Name</th>
                                        <th>Year Attended</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody id="edit_previous_school">

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane" id="bill-info">
                <div id="BillFedbck"></div>
                   <form id="update_bill_info" class="needs-validation" novalidate >
                        <h5>Billing Information</h5>
            <div class="row mb-3" align="center">
           <label class="col-sm-4 col-form-label col-form-label-sm">Select Bill Payer</label>
            <div class="col-sm-6">
                 <select name="payer" id="payer" class="form-control" onchange="payerInformation(this.value)" >

                    <option selected>--Choose--</option>

                    <option value="1">Mother/Gurdian</option>

                    <option value="2">Father/Gurdian</option>

                    <option value="3">Other</option>

                </select>
                <div class="invalid-feedback">Select Bill Payer is required.</div>

            </div>
            </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <label for="bname" class="col-sm-4 col-form-label col-form-label-sm">First Name<span class="text-red">*</span></label>
                                    <div class="col-sm-6">
                                         <input type="hidden"  name="studentid" value="<?= $student[0]->id; ?>">
                                         <input type="hidden"  name="bid" value="<?= count($bill)>0?$bill[0]->id:''; ?>">
                                        <input type="text" class="form-control form-control-sm" id="bname" placeholder="First Name" name="pname" value="<?= count($bill)>0?$bill[0]->first_name:''; ?>" required>
                                           <div class="invalid-feedback">First Name is required.</div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="blname" class="col-sm-4 col-form-label col-form-label-sm">Last Name<span class="text-red">*</span></label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control form-control-sm" id="blname" placeholder="Last Name" name="plname" value="<?= count($bill)>0?$bill[0]->last_name:''; ?>" required>
                                           <div class="invalid-feedback">Last Name is required.</div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="bemail" class="col-sm-4 col-form-label col-form-label-sm">Email</label>
                                    <div class="col-sm-6">
                                        <input type="email" class="form-control form-control-sm" id="bemail" name="email" placeholder="eg: example@gmail.com" value="<?= count($bill)>0?$bill[0]->email:''; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <label for="baddrs" class="col-sm-4 col-form-label col-form-label-sm">Postal Address<span class="text-red">*</span></label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control form-control-sm" id="baddrs" name="paddrs" placeholder="Postal Address" value="<?= count($bill)>0?$bill[0]->postal_address:''; ?>" >
                                           <div class="invalid-feedback">Postal Address is required.</div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="bpaddrs" class="col-sm-4 col-form-label col-form-label-sm">Physical Address<span class="text-red">*</span></label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control form-control-sm" id="bpaddrs" placeholder="Physical Address" name="baddrs" value="<?= count($bill)>0?$bill[0]->address:''; ?>" required>
                                           <div class="invalid-feedback">Physical Address is required.</div>

                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="bphone1" class="col-sm-4 col-form-label col-form-label-sm">Phone Number<span class="text-red">*</span></label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" value="<?= count($bill)>0?$bill[0]->phone1:''; ?>" name="phone1" id="bphone1" placeholder="+255-xxx-xxx-xxx"  minlength="9"  maxlength="13"  required  autocomplete="off"pattern="^\+?255[0-9]{9}$" title="Phone must start with +255 and contain 12 digits total">
                                                    <div class="invalid-feedback">Please enter a valid phone number (e.g., +255712345678).</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end mt-2 mb-3">
                             <button type="button" class="btn btn-primary" id="updatebillbtn" onclick="update_bill_info()">Submit</button>
                        </div>
                    </form>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){ 
        $(":input").inputmask();     
    });
     $('#updateparent').hide();
     $('#updateschool').hide();
    $('#updatetudent').submit(function (e) {
        var form_data = new FormData(this);
        $.ajax({
            beforeSend: function () {
                  $('#update_student').prop("disabled", true);
                  $('#UpadateFedbck').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
            },
            url: 'update_student',
            type: 'POST',
            data: form_data,
            success: function (res) {
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                    $('#UpadateFedbck').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }else if(data['status'] == "2"){
                 update_control_names(data);
                }
                else{
                    $('#update_student').prop("disabled", false);
                    $('#UpadateFedbck').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                 }
            },
            contentType: false,
            cache: false,
            processData: false,       
            error: function () {
                 $('#update_student').prop("disabled", false);
                 $('#UpadateFedbck').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');;
            }
        });
        e.preventDefault();
    });

    function update_control_names(data){
         swal({
            title: "Are you sure?",
            text: "Update names on control number",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, update!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {

                var id=data['student_id'];
              $.ajax({
                url: '<?php echo base_url() . '/index.php/AdmissionController/editControlnumber_names'; ?>/'+id,

                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(res) {
                      // $("#"+id).remove();
                    swal("Updated!", data['statusDesc'], "success");

                    // location.reload();
                      
                 }
              });

            } else {
                $('#UpadateFedbck').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
               swal("Cancelled");
            }

          });
    }

    function parent_data(){
         $('#edit_show_parent').load('show_parent1/<?= $student[0]->id; ?>'); 
     }
     function edit_item(id,tbl){
        $('#NewParent').show();
          var data = 'id='+id +'&tbl='+ tbl;
       $.ajax({
            type: "POST",
            url: 'get_parent',
            data: data,
            success: function (result) {
               var data = JSON.parse(result);
               if(tbl == 'parents_tbl'){
                 $('#addparent').hide();
                $('#Pfname').val(data[0]['first_name']);
                $('#Plname').val(data[0]['last_name']);
                $('select#Prelation').val(data[0]['relation']);
                $('#Paddress').val(data[0]['address']);
                $('#Poccp').val(data[0]['occupation']);
                $('#Pemail').val(data[0]['email']);
                $('#Pphone1 ').val(data[0]['phone1']);
                $('#Pphone2 ').val(data[0]['phone2']);
                $('#parentid ').val(data[0]['id']);
                $('#updateparent').show();
              }else{
                  $('#addschool').hide();
                  $('#Pschool').val(data[0]['school_name']);
                  $('#Pyear').val(data[0]['year_attended']);
                  $('#PcId').val(data[0]['id']);
                  $('#updateschool').show();
              }
            },
            error: function () {
               // $('#error'+divToUpdate ).html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
            }
        });;
     }
function validateParentForm() {
  const form = document.getElementById('update_parent_dtls');

  if (!form.checkValidity()) {
    form.classList.add('was-validated');
    return false;
  }
const phone1 = $('#Pphone1').val().replace(/\s+/g, '').replace(/[^\+\d]/g, '').trim();
const phone2 = $('#Pphone2').val().replace(/\s+/g, '').replace(/[^\+\d]/g, '').trim();

  const phonePattern = /^\+?255[0-9]{9}$/;
  if (phone1 && !phonePattern.test(phone1)) {
    swal("Invalid Phone", "Phone Number 1 must be in format +255712345678", "error");
    return false;
  }

  return true;
}
function validateBillForm() {
  const form = document.getElementById('update_bill_info');

  if (!form.checkValidity()) {
    form.classList.add('was-validated');
    return false;
  }
let phone1 = $('#bphone1').val().replace(/\s+/g, '').replace(/[^\+\d]/g, '').trim();
const phonePattern = /^\+?255[0-9]{9}$/;

if (phone1 && !phonePattern.test(phone1)) {
  swal("Invalid Phone", "Phone Number 1 must be in format +255712345678", "error");
  return false;
}


  return true;
}

function register_parent() {
  if (!validateParentForm()) return;

  $.ajax({
    beforeSend: function() {
      $('#addparent').prop("disabled", true);
    },
    type: "POST",
    url: "save_parent",
    data: $('#update_parent_dtls').serialize(),
    success: function(res) {
      $('#addparent').prop("disabled", false);
      const data = JSON.parse(res);
      if (data.status === "0") {
           $('#save_status').html(
          `<div class="alert alert-success alert-dismissible" role="alert">Parent details saved Successfully</div>`
        )
           .stop(true, true)
                .show()
                .delay(10000)
                .fadeOut();
        $('#update_parent_dtls')[0].reset();
 $('#edit_show_parent').html('<center><i class="fa fa-spinner fa-spin"></i> Loading changes..</center>');
$('#edit_show_parent').load('<?= base_url("show_parent1/" . $student[0]->id); ?>');
      } else {
        $('#errorshowparent').html(
          `<div class="alert alert-danger alert-dismissible" role="alert">${data.statusDesc}</div>`
        );
      }
    },
    error: function() {
      $('#addparent').prop("disabled", false);
      $('#errorshowparent').html(
        '<div class="alert alert-danger alert-dismissible" role="alert">Sorry, something went wrong.</div>'
      );
    }
  });
}

function update_parent() {
  if (!validateParentForm()) return;

  $.ajax({
    beforeSend: function() {
      $('#updateparent').prop("disabled", true);
    },
    type: "POST",
    url: "update_parent",
    data: $('#update_parent_dtls').serialize(),
    success: function(res) {
      $('#updateparent').prop("disabled", false);
      const data = JSON.parse(res);

      if (data.status === "0") {
          $('#save_status').html(
          `<div class="alert alert-success alert-dismissible" role="alert">Parent details saved Successfully</div>`
        )
           .stop(true, true)
                .show()
                .delay(10000)
                .fadeOut();
        
        $('#addparent').show();
        $('#updateparent').hide();
        $('#update_parent_dtls')[0].reset();
         $('#edit_show_parent').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
 $('#edit_show_parent').load('<?= base_url("show_parent1/" . $student[0]->id); ?>');

      } else {
        $('#errorshowparent').html(
          `<div class="alert alert-danger alert-dismissible" role="alert">${data.statusDesc}</div>`
        );
      }
    },
    error: function() {
      $('#updateparent').prop("disabled", false);
      $('#errorshowparent').html(
        '<div class="alert alert-danger alert-dismissible" role="alert">Sorry, something went wrong.</div>'
      );
    }
  });
}

    function delete_item(id,pid,sid,tbl,divToUpdate){
       var data = 'id='+id +'&tbl='+ tbl;
       $.ajax({
            beforeSend: function () {
                $('#edit_'+divToUpdate).html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
            },
            type: "POST",
            url: 'delete_item',
            data: data,
            success: function (res) {
                 $('#edit_'+divToUpdate).load(divToUpdate+'1/<?= $student[0]->id; ?>');
            },
            error: function () {
                $('#error'+divToUpdate ).html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
            }
        });
    }
    function load_previous_school(){
        $('#edit_previous_school').load('previous_school/<?= $student[0]->id; ?>');  
    }
     function cancelbtn(num){
        if(num === 1){
            $('#addparent').show();
            $('#updateparent').hide();
           // $('#NewParent').hide();
          }else if(num === 2){
             $('#updateschool').hide();
             $('#addschool').show();
          }
     }
    function update_school(){
         $.ajax({
            beforeSend: function () {
              $('#updateschool').prop("disabled", true);
              $('#ErrorEditprevious_school').html('');
            },
            url: 'update_previous_school',
            type: 'POST',
            data:  $('#previous_school_update').serialize(),
            success: function (res) {
                $('#updateschool').prop("disabled", false);
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                   $('#previous_school_update')[0].reset();
                   $('#edit_previous_school').load('previous_school/<?= $student[0]->id; ?>');  
                }else{
                   $('#ErrorEditprevious_school').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
               }
            },       
            error: function () {
                 $('#updateschool').prop("disabled", false);
                 $('#ErrorEditprevious_school').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');;
            }
        });
    }
    function add_schools(){
        $.ajax({
            beforeSend: function () {
              $('#addschool').prop("disabled", true);
              $('#ErrorEditprevious_school').html('');
            },
            url: 'save_previous_school',
            type: 'POST',
            data:  $('#previous_school_update').serialize(),
            success: function (res) {
                $('#addschool').prop("disabled", false);
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                   $('#previous_school_update')[0].reset();
                   $('#edit_previous_school').load('previous_school/<?= $student[0]->id; ?>');  
                }else{
                   $('#ErrorEditprevious_school').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
               }
            },       
            error: function () {
                 $('#addschool').prop("disabled", false);
                 $('#ErrorEditprevious_school').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');;
            }
        });
    }
     function update_bill_info(){
          if (!validateBillForm()) return;
         $.ajax({
            beforeSend: function () {
                $('#updatebillbtn').prop("disabled", true);
                $('#BillFedbck').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
            },
            type: "POST",
            url: 'update_bill_info',
            data: $('#update_bill_info').serialize(),
            success: function (res) {
                $('#updatebillbtn').prop("disabled", false);
                if(res == 1){
                    $('#BillFedbck').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Bill Information Updated Successfull</div>').stop(true, true)
                .show()
                .delay(10000)
                .fadeOut();
                 }else{
                     $('#BillFedbck').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ res + '</div>')
                     .stop(true, true)
                .show()
                .delay(10000)
                .fadeOut();  
                 }
            },
            error: function () {
                $('#updatebillbtn').prop("disabled", false);
                $('#BillFedbck').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
            }
        });
    }
    function search_parent(){
        if($('#parentsID').val() == ""){
            swal("warning","Please Enter Parent Name","warning");
        }else{
             $('#NewParent').hide();
            var student = <?= $student[0]->id;?>;
            var data = 'parentData=' + $('#parentsID').val() + '&student=' + student;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/StudentController/search_parentData'; ?>',
                data: data,
                success: function (res) {
                    console.log(res);
                    $('#Parent_loaded').html(res);
                }
            });
        }
    }

    function saveParentInfo(parentID,studentID){
        var datas = 'pID=' + parentID + '&student_id=' + studentID;
        //alert(datas);
        //return;
         $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/index.php/StudentController/save_studentParent_details'; ?>',
            data: datas,
            success: function (res) {
                console.log(res);
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                   $('#selectParent').empty();
                   $('#edit_show_parent').load('show_parent1/<?= $student[0]->id; ?>'); 
                }            
            },
            error: function () {
                $('#errorshowparent').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
            }
        });  
    }

 function add_newParents(){
    $('#Parent_loaded').hide();
    var student = <?= $student[0]->id;?>;
    var data = 'student=' + student;
    // alert(data);
    $('#NewParent').show();
    // $.ajax({
    //     type: 'POST',
    //     url: '<?php echo base_url() . '/index.php/StudentController/new_ParentInfo'; ?>',
    //     data: data,
    //     success:function(res){
    //         $('#NewParent').html(res);
    //     }
    // });
}
/////////////////billing info ////////////////////////////////////////////////////////
function payerInformation(id){
    var data = "student=" +<?= $student[0]->id; ?> + "&relation=" + id;
        // alert(data)
    $('input[name=pname]').val('');
    $('input[name=plname]').val('');
    $('input[name=email]').val('');
    $('input[name=baddrs]').val('');
    $('input[name=paddrs]').val('');
    $('input[name=phone1]').val('');

    $.ajax({
        type:'POST',
        url:'<?php echo base_url() . '/index.php/StudentController/load_payerInfo'; ?>',
        data: data,
        dataType: 'json',
        success: function(data){
                // var data = JSON.parse(res);
            console.log(data)



            $('input[name=pname]').val(data[0]['fname']);
            $('input[name=plname]').val(data[0]['lname']);
            $('input[name=email]').val(data[0]['email']);
            $('input[name=baddrs]').val(data[0]['address']);
            $('input[name=paddrs]').val(data[0]['paddress']);
            $('input[name=phone1]').val(data[0]['phone']);
        },
        error: function(){

        }
    });
}
</script>    