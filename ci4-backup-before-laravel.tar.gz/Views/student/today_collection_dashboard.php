 
<?php 
helper('bank');
$studentModel = new App\Models\studentModel();
$ino = "";
$sid = $studentModel->get_max_id('students','student_id');


 $lmodel = new App\Models\LoginModel();
    $staffModel = new App\Models\StaffModel();
    $imodel = new App\Models\ItemsModel();


    // $transfered = $studentModel->gettable_data('student_not_show_tbl',$where = array('academic_year' => $year));
    // $male=0;
    // $female=0;
   //  if(count($transfered)>0){
   //      foreach ($transfered as $v) {
   //          $adms = $studentModel->gettable_data('admission_tbl',$where = array('id' => $v->adm_id));
             
   //  if(count($adms)>0){
   //           $gender = $studentModel->gettable_data('students',$where = array('id' => $adms[0]->student_id)); 

   //           if($gender[0]->gender=='Male') {
   //             $male=$male+1;
   //           }else{
   //            $female=$female+1;
   //           }
   //       }else{
   //          echo $v->adm_id.'/';
   //       }

   //      }
      
   //  }
   // ;
   // $pboys=number_format((float)$male/count($transfered),3,'.','');
   // $pgirls=number_format((float)$female/count($transfered),3,'.','');
           $bank = $studentModel->gettable_data('accounts_tbl', $where = array('account_type_id' => 9));
                 $sdate=date('Y-m-d 00:00');
                $edate=date('Y-m-d 23:59');
                $results=bank_cash($sdate,$edate);
               // print_r($results);
                $ttl_collected=0;
                foreach ($results as $account) {
                   
               $ttl_collected=$ttl_collected + $account['amount_in'];
                }
?>

<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Students</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Collection Dashboard</li>
                </ol>
            </div>
          
        </div>
    </div>
</div>

<div class="section-body mt-4">
<div class="container-fluid">
<div class="row clearfix row-deck">
                       
                      
     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:#8A3324;">
            <div class="card-body ribbon">
             
                   <span style="color:white;">Total Collected</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= number_format($ttl_collected); ?></span></h5>
             
            </div>
        </div>
    </div>
     <?php
     if($ttl_collected ==0){
        return;
     }
     $i=0;
      foreach($results as $account){
         $barColors = ["orange","blue","green","brown","red","pink","brown"];
     $percentage=number_format((float)$account['amount_in']/$ttl_collected,3,'.','');
     ?>
     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:<?= $barColors[$i]?>;">
            <div class="card-body ribbon">
             
                   <span style="color:white;"> <?php echo $account['account_name'] ?></span>
                    <br>
                   <h5 ><span style="color:white;"><?= number_format($account['amount_in']); ?></span></h5>  <h5><b><span style="color:greenyellow;"><?= ($percentage)*100; ?>%</span></b></h5>
             
            </div>
        </div>
    </div>
<?php 
$i++;
} ?>
   
    
    </div>

  
 <div class="row mt-3"> 
       <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">Bank Collection Graph</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="genderadmition">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>

        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">Bank Balances</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="admitionbylevel">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
     
    </div>
    </div> 
    </div>

<script>
   

$(document).ready(function () {
       bankCollection();
       bankBalances();
    });

function bankCollection() {
        $.ajax({
            beforeSend: function () {
                $('#genderadmition').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StaffController/bankCollection/'?>',
            success: function (result) {
                $('#genderadmition').html(result);
            },
            error: function () {
                $('genderadmition').html('Sorry! Something went wrong.');
            }
        });
    }

    function bankBalances() {
        $.ajax({
            beforeSend: function () {
                $('#admitionbylevel').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StaffController/bankBalances/'?>',
            success: function (result) {
                $('#admitionbylevel').html(result);
            },
            error: function () {
                $('admitionbylevel').html('Sorry! Something went wrong.');
            }
        });
    }
    
</script>