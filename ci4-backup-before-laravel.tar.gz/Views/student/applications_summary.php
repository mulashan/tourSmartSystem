 
<?php 
helper('age');
$studentModel = new App\Models\studentModel();
$ino = "";
$sid = $studentModel->get_max_id('students','student_id');
if (count($sid) > 0) {
    $stid = $sid[0]->max_id + 1;
    $ino = $stid;
} else {
    $ino =  1;
}

 $lmodel = new App\Models\LoginModel();
    $staffModel = new App\Models\StaffModel();
    $imodel = new App\Models\ItemsModel();

    // $staff = $staffModel->get_total_user('users','user_id',$where = array('status' => 1));
    $boys = $staffModel->get_total_application('students_application_tbl','id',$where = array('gender' => 'Male'),$year);
    $girls = $staffModel->get_total_application('students_application_tbl','id',$where = array('gender' => 'Female'),$year);
     $sel = $staffModel->get_total_application('students_application_tbl','id',$where = array('selection_status' => 1),$year);
    $coll = $imodel->get_total_collection('ledger_transaction_tbl','amount',$year);

    $tstudents=$staffModel->application_students('students_application_tbl',$year);


       $tcoll=0;
    if(count($tstudents)>0){
        foreach ($tstudents as $value) {
     $rc_amount = $studentModel->gettable_data('ledger_transaction_tbl',$where = array('ledger_id' => 9,'trans_type'=>2,'transation_nature'=>1,'name_type_id='=>4,'name_id='=>1));
     //print_r($rc_amount);

         if(count($rc_amount)>0){
          $tcoll=$tcoll + $rc_amount[0]->amount;
          }
            // code...
        }

    }
    $app = $imodel->get_total_application('students_application_tbl','id',$year);
   $pboys=number_format((float)$boys[0]->id/$app[0]->id,2,'.','');
   $pgrls=number_format((float)$girls[0]->id/$app[0]->id,2,'.','');
   $psel=number_format((float)$sel[0]->id/$app[0]->id,2,'.','');
?>

<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Students</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Application Dashboard</li>
                </ol>
            </div>
          <!--   <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Student-all">Students List</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Student-add">New Student</a></li>
            </ul> -->
        </div>
    </div>
</div>

<div class="section-body mt-4">
<div class="container-fluid">
<div class="row clearfix row-deck">
                       
                      
     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:orange;">
            <div class="card-body ribbon">
             
                   <span>APPLICATIONS</span>
                    <br>
                   <h5 id="OPDtotal"><span><?= $app[0]->id; ?></span></h5>
                
            </div>
        </div>
    </div>

     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:blue;">
            <div class="card-body ribbon">
             
                   <span style="color:white;">BOYS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= $boys[0]->id; ?></span></h5>
                    <h5><b><span style="color:yellow;"><?= ($pboys)*100; ?>%</span></b></h5>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:pink;">
            <div class="card-body ribbon">
             
                   <span>GIRLS</span>
                    <br>
                   <h5 id="OPDtotal"><span style=""><?= $girls[0]->id; ?></span></h5>
                   <h5><b><span style="color:yellow;"><?= ($pgrls)*100; ?>%</span></b></h5>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-3">
        <div class="card" style="background-color:green;">
            <div class="card-body ribbon">
             
                   <span style="color:white;"> COLLECTION</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= number_format($tcoll); ?></span></h5>
             
            </div>
        </div>
    </div>
        <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:#3C1414;">
            <div class="card-body ribbon">
             
                   <span  style="color:white;">SELECTION</span>
                    <br>
                   <h5 id="slctotal"><span  style="color:white;"><?= $sel[0]->id; ?></span></h5>
                <h5><b><span style="color:yellow;"><?= ($psel)*100; ?>%</span></b></h5>
            </div>
        </div>
    </div>
    </div>

       <div class="row mt-3"> 
        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">CLASS LEVEL PIE</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="classlevel">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">CLASS CHART</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="class">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
    </div>

       <div class="row mt-3"> 
        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">GENDER PIE</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="genderpie">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
       <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">APPLICATION-SELECTION CHART</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="appsel">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div> 
    </div>
    </div> 
    </div>
<script>
   

$(document).ready(function () {
    
       loadapp();
       loadclasses();
       genderpie();
       appsel();
    });

// function loadapp() {
//          $('#classlevel').load('<?php echo base_url() . '../index.php/StudentController/get_classlevel_details'; ?>');
//     }
  
function loadapp() {
    
        $.ajax({
            beforeSend: function () {
                $('#classlevel').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/get_classlevel_details/'.$year;?>',
            success: function (result) {
                $('#classlevel').html(result);
            },
            error: function () {
                $('classlevel').html('Sorry! Something went wrong.');
            }
        });
    }
    function loadclasses() {
        $.ajax({
            beforeSend: function () {
                $('#class').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/get_classes_details/'.$year;?>',
            success: function (result) {
                $('#class').html(result);
            },
            error: function () {
                $('class').html('Sorry! Something went wrong.');
            }
        });
    }
      function genderpie() {
        $.ajax({
            beforeSend: function () {
                $('#genderpie').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/get_gender_details/'.$year;?>',
            success: function (result) {
                $('#genderpie').html(result);
            },
            error: function () {
                $('genderpie').html('Sorry! Something went wrong.');
            }
        });
    }
    function appsel() {
        $.ajax({
            beforeSend: function () {
                $('#appsel').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/get_appsel_details/'.$year;?>',
            success: function (result) {
                $('#appsel').html(result);
            },
            error: function () {
                $('appsel').html('Sorry! Something went wrong.');
            }
        });
    }
</script>