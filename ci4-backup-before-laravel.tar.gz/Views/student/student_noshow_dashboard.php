 
<?php 
helper('age');
$studentModel = new App\Models\studentModel();
$ino = "";
$sid = $studentModel->get_max_id('students','student_id');


 $lmodel = new App\Models\LoginModel();
    $staffModel = new App\Models\StaffModel();
    $imodel = new App\Models\ItemsModel();


    $transfered = $studentModel->gettable_data('student_not_show_tbl',$where = array('academic_year' => $year));
    $male=0;
    $female=0;
    if(count($transfered)>0){
        foreach ($transfered as $v) {
            $adms = $studentModel->gettable_data('admission_tbl',$where = array('id' => $v->adm_id));
             
    if(count($adms)>0){
             $gender = $studentModel->gettable_data('students',$where = array('id' => $adms[0]->student_id)); 

             if($gender[0]->gender=='Male') {
               $male=$male+1;
             }else{
              $female=$female+1;
             }
         }else{
            echo $v->adm_id.'/';
         }

        }
      
    }
   ;
   $pboys=number_format((float)$male/count($transfered),3,'.','');
   $pgirls=number_format((float)$female/count($transfered),3,'.','');
  
  
?>

<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Students</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Student Dashboard</li>
                </ol>
            </div>
          
        </div>
    </div>
</div>

<div class="section-body mt-4">
<div class="container-fluid">
<div class="row clearfix row-deck">
                       
                      
     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:#8A3324;">
            <div class="card-body ribbon">
             
                   <span style="color:white;">No Show</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= count($transfered); ?></span></h5>
             
            </div>
        </div>
    </div>

     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:blue;">
            <div class="card-body ribbon">
             
                   <span style="color:white;"> BOYS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= number_format($male); ?></span></h5>  <h5><b><span style="color:greenyellow;"><?= ($pboys)*100; ?>%</span></b></h5>
             
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:pink;">
            <div class="card-body ribbon">
             
                   <span style="color:black;">GIRLS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:black;"><?= number_format($female); ?></span></h5>
                   <h5><b><span style="color:green;"><?= ($pgirls)*100; ?>%</span></b></h5>
                   <!-- <h6 id="OPDtotal"><span style=""></span></h6> -->
             
            </div>
        </div>
    </div>
    
    </div>

  
 <div class="row mt-3"> 
       <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">NO SHOW BY GENDER</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="genderadmition">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>

        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">NO SHOW BY CLASS</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="admitionbylevel">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
     
    </div>
    </div> 
    </div>

<script>
   

$(document).ready(function () {
       loadnoshowGender();
       noshowByClass();
    });

// function loadapp() {
//          $('#classlevel').load('<?php echo base_url() . '../index.php/StudentController/get_classlevel_details'; ?>');
//     }
  
function loadnoshowGender() {
        $.ajax({
            beforeSend: function () {
                $('#genderadmition').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StaffController/noshow_gender_details/'.$year?>',
            success: function (result) {
                $('#genderadmition').html(result);
            },
            error: function () {
                $('genderadmition').html('Sorry! Something went wrong.');
            }
        });
    }
    
    
     function noshowByClass() {
        $.ajax({
            beforeSend: function () {
                $('#admitionbylevel').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StaffController/noshow_by_class/'.$year?>',
            success: function (result) {
                $('#admitionbylevel').html(result);
            },
            error: function () {
                $('admitionbylevel').html('Sorry! Something went wrong.');
            }
        });
    }
    
</script>