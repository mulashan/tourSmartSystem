 
<?php 
helper('age');
$studentModel = new App\Models\studentModel();
$ino = "";
$sid = $studentModel->get_max_id('students','student_id');
if (count($sid) > 0) {
    $stid = $sid[0]->max_id + 1;
    $ino = $stid;
} else {
    $ino =  1;
}

 $lmodel = new App\Models\LoginModel();
    $staffModel = new App\Models\StaffModel();
    $imodel = new App\Models\ItemsModel();

    // $staff = $staffModel->get_total_user('users','user_id',$where = array('status' => 1));
    $cont = $staffModel->get_total_user('admission_tbl','id',$where = array('adimit_for' => 0,'academic_year'=>$year));
    $new = $staffModel->get_total_user('admission_tbl','id',$where = array('adimit_for' => 2,'academic_year'=>$year));
     $day = $staffModel->get_total_user('admission_tbl','id',$where = array('admission_type' => 0,'academic_year'=>$year));
     $bod = $staffModel->get_total_user('admission_tbl','id',$where = array('admission_type' => 3,'academic_year'=>$year));
    $sales = $studentModel->get_total_admision_collection('ledger_transaction_tbl','amount',$year);
    $coll = $imodel->get_total_admision_collected('ledger_transaction_tbl','amount',$year);
    $tcol=0;
    $tsales=0;
    foreach ($sales as $sale) {
        $tsales=$tsales+$sale->amount;
        $rcn = $studentModel->gettable_data('transactions_relation',$where = array('invoice_trans_no' => $sale->trans_number));

       if(count($rcn)>0){
        foreach ($rcn as $s) {
      $rc_amount = $studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $s->receipt_trans_no,'trans_type'=>2,'transation_nature'=>1,'ledger_id!='=>9,'ledger_id!='=>22,));
      if(count($rc_amount)>0){
       $tcol=$tcol+$rc_amount[0]->amount;
          }
        }
    }
        // collected end...
    }
    // foreach ($coll as $col) {
    //     $tcol=$tcol+$col->amount;
    //     // code...
    // }
    //print_r($coll);
    $app = $imodel->get_total_admission('admission_tbl','id',$year);
   $pcont=number_format((float)$cont[0]->id/$app[0]->id,2,'.','');
   $pnew=number_format((float)$new[0]->id/$app[0]->id,2,'.','');
   $pday=number_format((float)$day[0]->id/$app[0]->id,2,'.','');
   $pbod=number_format((float)$bod[0]->id/$app[0]->id,2,'.','');
   if($tsales>0){
   $pcol=number_format((float)$tcol/$tsales,4,'.','');
    }else{
        $pcol=0;
    }
   // $pnew=number_format($new[0]->id/$app[0]->id);
  //$perc=($sales[0]->amount/$coll[0]->amount)*100;
?>

<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Admissions</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Admission Dashboard</li>
                </ol>
            </div>
          <!--   <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Student-all">Students List</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Student-add">New Student</a></li>
            </ul> -->
        </div>
    </div>
</div>

<div class="section-body mt-4">
<div class="container-fluid">
<div class="row clearfix row-deck">
                       
                      
     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:orange;">
            <div class="card-body ribbon">
             
                   <span>ADMISSIONS</span>
                    <br>
                   <h5 id="OPDtotal"><span><?= $app[0]->id; ?></span></h5>
             
            </div>
        </div>
    </div>

     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:red;">
            <div class="card-body ribbon">
             
                   <span style="color:white;"> SALES</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= number_format($tsales); ?></span></h5>
             
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:  #8A3324;">
            <div class="card-body ribbon">
             
                   <span style="color:white;">COLLECTED</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= number_format($tcol); ?></span></h5>
                   <h5><b><span style="color:yellow;"><?= ($pcol)*100; ?>%</span></b></h5>
                   <!-- <h6 id="OPDtotal"><span style=""></span></h6> -->
             
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-3">
        <div class="card" style="background-color:green;">
            <div class="card-body ribbon">
             
                   <span style="color:white;"> CONTINOUS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= $cont[0]->id; ?></span></h5>
                    <h5><b><span style="color:yellow;"><?= ($pcont)*100; ?>%</span></b></h5>
             
            </div>
        </div>
    </div>
        <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:#3D2B1F;">
            <div class="card-body ribbon">
             
                   <span  style="color: white;">NEW</span>
                    <br>
                   <h5 id="slctotal"><span style="color: white;"><?= $new[0]->id; ?></span></h5>
                    <h5><b><span style="color: yellow;"><?= (($pnew)*100); ?>%</span></b></h5>
            </div>
        </div>
    </div>
      <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:#7BB661;">
            <div class="card-body ribbon">
             
                   <span>DAY</span>
                    <br>
                   <h5 id="slctotal"><span><?= $day[0]->id; ?></span></h5>
                    <h5><b><span style="color: yellow;"><?= (($pday)*100); ?>%</span></b></h5>
            </div>
        </div>
    </div>
      <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:  #555D50;">
            <div class="card-body ribbon">
             
                   <span style="color:white;">BOARDING</span>
                    <br>
                   <h5 id="slctotal"><span style="color:white;"><?= $bod[0]->id; ?></span></h5>
                     <h5><b><span style="color: yellow;"><?= (($pbod)*100); ?>%</span></b></h5>
            </div>
        </div>
    </div>
    </div>

       <div class="row mt-3"> 
        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">GENDER PIE</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="genderadmition">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">CONTINOUS VS NEW</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="contvsnew">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
    </div>

       <div class="row mt-3"> 
        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">ADMISSION TYPE PIE</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="admitiontype">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
       <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">SALES VS COLLECTION BAR</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="salesvscoll">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div> 
    </div>

       <div class="row mt-3"> 
        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">ADMISSION BY CLASS LEVEL</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="admitionbylevel">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
       <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">ADMISSION BY CLASSES</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="admitionbyclass">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div> 
    </div>

<div class="row mt-3"> 
          <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">ADMISSION BY STUDENT RELIGION</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="student_religion">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>

       
        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">ADMISSION BY NATIONALITY</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="nationality_here">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
    </div>


    </div> 
    </div>

<script>
   

// window.onload = function() {
//      loadContVsNew();
//       loadAdimissionGender();
      
//       admitiontype();
//       selColl();
//       admitionbylevel();
//       admitionbyclass();
//       studentReligion();
//       loadNationality();
//     };


  $(document).ready(function () {
    loadContVsNew();
     loadAdimissionGender();
      
       admitiontype();
       selColl();
       admitionbylevel();
       admitionbyclass();
       studentReligion();
       loadNationality();
});

    function loadContVsNew() {
        $.ajax({
            beforeSend: function () {
                $('#contvsnew').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/get_contVsNew_details/'.$year;?>',
            success: function (result) {
                $('#contvsnew').html(result);
            },
            error: function () {
                $('contvsnew').html('Sorry! Something went wrong.');
            }
        });
    }
    function loadAdimissionGender() {
        $.ajax({
            beforeSend: function () {
                $('#genderadmition').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/get_AdimissionGender_details/'.$year;?>',
            success: function (result) {
                $('#genderadmition').html(result);
            },
            error: function () {
                $('genderadmition').html('Sorry! Something went wrong.');
            }
        });
    }
      function admitiontype() {
        $.ajax({
            beforeSend: function () {
                $('#admitiontype').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/get_admitiontype_details/'.$year;?>',
            success: function (result) {
                $('#admitiontype').html(result);
            },
            error: function () {
                $('admitiontype').html('Sorry! Something went wrong.');
            }
        });
    }
    function selColl() {
        $.ajax({
            beforeSend: function () {
                $('#salesvscoll').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/get_selColl_details/'.$year;?>',
            success: function (result) {
                $('#salesvscoll').html(result);
            },
            error: function () {
                $('salesvscoll').html('Sorry! Something went wrong.');
            }
        });
    }
     function admitionbylevel() {
        $.ajax({
            beforeSend: function () {
                $('#admitionbylevel').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/admitionbylevel_details/'.$year;?>',
            success: function (result) {
                $('#admitionbylevel').html(result);
            },
            error: function () {
                $('admitionbylevel').html('Sorry! Something went wrong.');
            }
        });
    }
      function admitionbyclass() {
        $.ajax({
            beforeSend: function () {
                $('#admitionbyclass').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/admitionbyclass_details/'.$year;?>',
            success: function (result) {
                $('#admitionbyclass').html(result);
            },
            error: function () {
                $('admitionbyclass').html('Sorry! Something went wrong.');
            }
        });
    }

    function studentReligion() {
        $.ajax({
            beforeSend: function () {
                $('#student_religion').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StaffController/students_details/'.$year?>',
            success: function (result) {
                $('#student_religion').html(result);
            },
            error: function () {
                $('student_religion').html('Sorry! Something went wrong.');
            }
        });
    }

    function loadNationality() {
        $.ajax({
            beforeSend: function () {
                $('#nationality_here').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StaffController/students_nationality/'.$year?>',
            success: function (result) {
                $('#nationality_here').html(result);
            },
            error: function () {
                $('nationality_here').html('Sorry! Something went wrong.');
            }
        });
    }
</script>