<?php 

    $cmodel = new App\Models\ClassesModel();
  $smodel = new App\Models\StudentModel();

    $period = $smodel->gettable_data('academic_types_tbl', $where = array('status !=' => 10));
  //  $schoolTerms = $cmodel->Load_SchoolTerms();
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Course Period</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Course Period</li>
                </ol>
            </div>
            
             <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#sem-all">Course Period List</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#sem-add">New Course Period</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#sem-all">Course Period List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#sem-add">New Course Period</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="sem-all">
              <div class="d-flex justify-content-center">
                <div class="card">
                <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
              
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Course Period</th>
                      <th>Status</th>
                      <th>Craeated by</th>
                      <th>Created Date</th>
                      <th></th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                  if(count($period)>0){
                    $i=0;
                    foreach ($period as $key) {
                        $i++;
                        if($key->status==1){
                            $status='<span style="color:green">Active</span>';
                        }else{
                           $status='<span style="color:red">Inactive</span>'; 
                        }
                        $created = $smodel->gettable_data('users', $where = array('user_id' => $key->created_by));
                        ?>
                   <tr>
                     <td><?= $i?></td>     
                     <td><?= $key->academic_type;?></td>     
                     <td><?= $status?></td>     
                     <td><?= $created[0]->first_name.' '.$created[0]->last_name;?></td>     
                     <td><?= $key->date_created;?></td>   
                     <td><button type="button" class="btn btn-primary btn-sm UpdateID" data-id="<?= $key->id;?>"><i class="fa fa-edit"></i> Edit</button></td>  
                      </tr>
                        <?php
                    }
                  }
                    ?>
                      
                  </tbody>
              </table>
            </div> 
            </div> 
            </div> 
                     
            </div>
            <div class="tab-pane" id="sem-add">
                <div class="row clearfix">
                    <div class="card">
                        <div class="card-header" style="height:5px">
                            <h3 class="card-title">New Course Period</h3>
                            <div class="card-options ">
                                <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                            </div>
                        </div>
                        <hr>
                        <div class="card-body">
                            <div id="feedback"></div>
                            <form class="form-horizontal" id="AddPeriod">
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Course Period Name <span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <input type="text" name="pname" id="pname" class="form-control form-control-sm" placeholder="" required="required">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label"></label>
                                    <div class="col-md-7">
                                        <!-- <button type="submit" class="btn btn-outline-secondary">Cancel</button> -->
                                        <button type="submit" class="btn btn-primary float-right">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>


<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Edit Course Period</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="UpdateTerm"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>

<!-view- Modal -->
  <div class="modal fade" id="viewModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <!-- <h5 class="modal-title" id="staticBackdropLabel">Edit School Term</h5> -->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="viewTerm"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>

<script type="text/javascript">
    $('#AddPeriod').submit(function(e){
        //alert($(this).serialize());
        $.ajax({
            type:"POST",
          //  url:"new_Semister",
             url: '<?php echo base_url() . '/index.php/SemisterController/save_course_period'; ?>',
            data: $(this).serialize()+"&"+$("#header_form").serialize(),
            success:function(res){
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                    
                    $('#AddPeriod')[0].reset();
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            },
            error:function(){
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Save course Period.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>')
            }
        });
        e.preventDefault();
    });

   
    $(".deleteID").click(function(){

        var id = $(this).attr('data-id');


           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this ledger!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/deleteterm')?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      // $("#"+id).remove();
                    swal("Deleted!", "Ledger deleted.", "success");

                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                      
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    });
    $('#academic').submit(function (e) {
            
            $('#semister_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "year=" + $('#year option:selected').val();
            //alert(dta);
            $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_semisters'; ?>',
                data: dta,
                success: function (res) {
                    $('#semister_results').html(res);
                },
                error: function () {
                    $('#semister_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
       $(".UpdateID").click(function () {
        var data = 'id=' + $(this).attr('data-id');
        // alert (data);
        $('#myModal').modal('show');

        $.ajax({
            type: "GET",
           // url: "<?= base_url('/editSchoolTerm')?>",
             url: '<?php echo base_url() . '/index.php/SemisterController/editCoursePeriod'; ?>',
            data: data,
            beforSend: function()
            {
                $('#UpdateTerm').html();
            },
            success: function(res){
                $('#UpdateTerm').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
</script>