<style type="text/css">
    .text-right {
    text-align: right !important;
}
</style>
<link rel="stylesheet" href="<?php// echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 
    helper('age');

    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();
    $app_class = 0;
    $app_lvl="";
    $age = findAge($student_dtl[0]->birth_date);

    $level = $amodel->admisiion_details('class_level_tbl');
    $admission = $amodel->get_student_details('admission_tbl',$where = array('student_id' => $student_dtl[0]->id,'status' => 0));
    $appln = $amodel->get_student_details('students_application_tbl',$where = array('id' => $student_dtl[0]->id));
    $terms = $amodel->admisiion_details('school_terms_tbl');
    $hstl = $amodel->get_hostel_details($student_dtl[0]->gender,$age);
    $transport = $amodel->admisiion_details('route_tbl');

    if(count($appln) > 0){        
        $app_class = $appln[0]->class;
        $app_lvl = $appln[0]->class_lvl;
    }else{
        $app_class = "";
        $app_lvl = "";
    }
    $parent = $amodel->get_student_details('parents_tbl', $where = array('id' => $studentparent[0]->parent_id));

?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <!-- <div class="card"> -->
           <!--  <div class="card-header" style="height:5px">
                <h3 class="card-title">Admission Details</h3>
                <div class="card-options ">
                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                </div>
            </div>
            <hr> -->
            <!-- <div class="card-body"> -->
                <div class="row">
                        <div id="feedback"></div>
                    <div class="col-md-5">
                        <!-- <h6 class="card-title d-flex justify-content-center mb-2">Student Information</h6> -->
                        <div class="card">
                                <p Class=" d-flex justify-content-center mt-2">STUDENT DETAILS</p>
                            <center>
                                <?php 
                                    $source = "";
                                    if($student_dtl[0]->student_photo != ""){
                                      $source =  base_url('public/student_photos/'.$student_dtl[0]->student_photo);
                                    }
                                ?>
                                <img src="<?php echo $source; ?>" style="margin-top: 2em;width:80px; height:100px;border: 1px wheat solid">
                                <table class="table table-borderless mt-3">
                                    <tr>
                                        <th>Student Name:</th>
                                        <td><?= $student_dtl[0]->first_name.' '. $student_dtl[0]->middle_name.' '.$student_dtl[0]->last_name;?></td>
                                    </tr>
                                    <tr>
                                        <th>Date of Birth:</th>
                                        <td><?= $student_dtl[0]->birth_date;?></td>
                                    </tr>
                                    <tr>
                                        <th>Age:</th>
                                        <td><?= findAge($student_dtl[0]->birth_date); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Gender:</th>
                                        <td><?= $student_dtl[0]->gender;?></td>
                                    </tr>
                                    <tr>
                                        <th>Nationality:</th>
                                        <td><?= $student_dtl[0]->nationality;?></td>
                                    </tr>
                                    <tr>
                                        <th>Gurdian / Parent Name:</th>
                                        <td><?= $parent[0]->first_name.' '. $parent[0]->last_name;?></td>
                                    </tr>
                                    <tr>
                                        <th>Gurdian / Parent Phone:</th>
                                        <td><?= $parent[0]->phone1;?></td>
                                    </tr>
                                    <tr>
                                        <th>Address:</th>
                                        <td><?= $parent[0]->postal_address;?></td>
                                    </tr>
                                </table>
                            </center>
                        </div>
                        <div class="card mt-3">
                            <p Class=" d-flex justify-content-center mt-1">ADMISSION HISTORY</p>
                            <table class="table table-hover table-vcenter mb-0 text-nowrap">
                                <thead>
                                    <tr>
                                        <th>Adm. No:</th>
                                        <th>Adm. Date</th>
                                        <th>Class</th>
                                        <th>Stream</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if(count($admission) > 0){
                                    foreach ($admission as $adm): 
                                        $classdtl = $amodel->class_stream_details($adm->class_id,$adm->stream_id);
                                        ?>
                                        <tr>
                                            <td><?= $adm->id; ?></td>
                                            <td><?= $adm->admitted_date; ?></td>
                                            <td><?= $classdtl[0]->class_name; ?></td>
                                            <td><?= $classdtl[0]->stream_name; ?></td>
                                        </tr>
                                    <?php endforeach; }else{ ?>
                                        <tr>
                                            <td colspan="4" style="text-align:center;">No Admission Data Found</td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <form class="form-horizontal" id="admsionDtls">
                            <div class="card">
                         <p Class=" d-flex justify-content-center mt-2">ADMISSION DETAILS</p>
                            <input type="hidden" name="sid" value="<?= $student_dtl[0]->id;?>">
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label">Academic Year:</label>
                                <div class="col-md-3">
                                    <select class="form-control" name="acdy">
                                       <?php
                                       $year = (int)date('Y');
                                       $y=$year+5;
                                       for ($year; $y>= $year; $year++): ?>
                                         <option value="<?php echo $year;?>"><?php echo $year;?></option>
                                       <?php endfor; ?>
                                    </select>
                                    <!-- <input type="number" min="1900" max="2099" step="1" value="2023"  name="acdy" id="datepicker" class="form-control"> -->
                                </div>
                                <?php 
                                    if(count($admission) == 0){
                                    
                                ?>
                                <label class="col-md-2 col-form-label">Admission Date:</label>
                                <div class="col-md-4">
                                    <!-- <input type="date"  name="djoin" id="datePickerId" class="form-control" min="2007-12-31"> -->
                                    <input type='date' class="form-control"  value="<?php echo date('Y-m-d')?>" name="djoin" id='' />
                                </div>
                            <?php } ?>
                            </div>
                            <!--------------------------------------------------->
                               <div class="form-group row">
                                <label class="col-md-3 col-form-label">Admission For:</label>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="admit" id="cont" value="0" required="required" checked="checked">
                                        <label class="form-check-label" for="Continous">
                                            Continous
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="admit" id="new" value="2" required="required">
                                        <label class="form-check-label" for="new">
                                            New Comer
                                        </label>
                                    </div>
                                </div>
                               
                                </div>
                            <!---------------------------------------------------->
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label">Class Level:</label>
                                <div class="col-md-5">
                                    <select id="clevel" name="clevel" class="form-select me-4 form-control form-control-sm" required>
                                        <option selected value="">Choose</option>
                                        <?php foreach ($level as $l): 
                                            $getRemainTotal = $amodel->remain_classLevel_capacity($l->id);
                                            if($getRemainTotal[0]->remainTotal != '' || $getRemainTotal[0]->remainTotal != NULL){
                                                $remain_capacity = '- '.$getRemainTotal[0]->remainTotal;
                                            }else{
                                                $remain_capacity = '- No';
                                            }
                                        ?>
                                            <option value="<?= $l->id;?>"<?php if($app_lvl == $l->id){ echo 'selected'; } ?>><?= $l->level_name.' '. $remain_capacity ;?></option>
                                        <?php endforeach ?>
                                    </select>
                                    <div id="filLv" style="color:red"></div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label">Class:</label>
                                <div class="col-md-3">
                                    <select id="croom" name="croom" onchange="ShowStream(this,'<?= findAge($student_dtl[0]->birth_date);?>')" class="form-select me-4 form-control form-control-sm">
                                        <option selected value="">Choose</option>
                                    </select>
                                <div id="ageLert" style="color:red"></div>
                                <div id="filLert" style="color:red"></div>
                                </div>
                                <label class="col-md-3 col-form-label">Stream:</label>
                                <div class="col-md-3">
                                    <select id="stream" name="stream" class="form-select me-4 form-control form-control-sm checkLimit">
                                        <option selected>Choose</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label">Admission Type:</label>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="state" id="day" value="0" required="required" checked="checked">
                                        <label class="form-check-label" for="day">
                                            Day
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="state" id="board" value="3" required="required">
                                        <label class="form-check-label" for="board">
                                            Boarding
                                        </label>
                                    </div>
                                </div>
                                <label class="col-md-3 col-form-label">Transport:</label>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="transp" id="no" value="No" required="required" checked="checked">
                                        <label class="form-check-label" for="board">
                                            No
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="transp" id="yes" value="Yes" required="required">
                                        <label class="form-check-label" for="day">
                                            Yes
                                        </label>
                                    </div>
                                </div>
</div>
<div class="form-group row">
    <div class="col-md-6">
        <div class="card" id="hostelDtls" style="display:none;">
            <div class="form-group row">
                <p Class=" d-flex justify-content-center mt-1">HOSTEL DETAILS</p>
                <label  class="col-md-4 col-form-label">Select Hostel</label>
                <div class="col-md-7">
                    <select id="hstl" name="hstl" class="form-select me-4 form-control form-control-sm checkLimit" onchange="hostelItems(this)">
                        <option selected>Choose</option>
                        <?php 
                            foreach ($hstl as $h):
                            $remainingBalnc = $amodel->hostel_remaining_capacity($h->id);
                            if($remainingBalnc[0]->remaining_capacity != '' || $remainingBalnc[0]->remaining_capacity != NULL){
                                $remain_capacity = '- '.$remainingBalnc[0]->remaining_capacity;
                            }else{
                                $remain_capacity = '- ';
                            }
                         ?>
                            <option value="<?= $h->id;?>"><?= $h->hostel_name .' '.$remain_capacity;?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card" id="trnspDtls" style="display:none;">
            <div class="form-group row">
                <p Class=" d-flex justify-content-center mt-1">TRANSPORT DETAILS</p>
                <label  class="col-md-4 col-form-label">Select Route</label>
                <div class="col-md-7">
                    <select id="trans" name="trans" class="form-select me-4 form-control form-control-sm checkLimit" onchange="TransportItems(this)">
                        <option selected>Choose</option>
                        <?php 
                            foreach ($transport as $t): 
                            $remainingBalnc = $amodel->Transprt_remaining_capacity($t->id);
                            if(count($remainingBalnc) > 0){
                                if($remainingBalnc[0]->remaining_Vehiclecapacity != '' || $remainingBalnc[0]->remaining_Vehiclecapacity != NULL){
                                    $remain_capacity = '- '.$remainingBalnc[0]->remaining_Vehiclecapacity;
                                }else{
                                    $remain_capacity = '- ';
                                }
                            }
                        ?>
                            <option value="<?= $t->id;?>"><?= $t->route_name .' '.$remain_capacity;?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
  
<div class="form-group row">
    <div class="col-md-12">
        <div class="card">
            <p Class=" d-flex justify-content-center mt-1">CHARGED ITEMS</p>
             <div class="form-group row">
                                <label class="col-md-2 col-form-label">Charged Items<span class="text-danger"></span><span class="text-danger"></span></label>
                                <div class="col-md-5">
                                    <select name="chargedItem" class="form-select form-control" id="chargedItem">
                                        <option class="">-search-</option>
                                     <!--    <?php
                                        //$charged=$amodel->getChargedItems();
                                        //foreach($charged as $ch){
                                    ?>
                                        <option value="<?php //echo $ch->id; ?>"><?php //echo $ch->item_name.' '.$ch->item_size.' '.number_format($ch->item_price).'/='; ?></option>
                                    <?php //}?> -->
                                    </select>
                                </div> 
                                <label class="col-md-2 col-form-label">Quantity<span class="text-danger"></span><span class="text-danger"></span></label>
                                <div class="col-md-2">
                                    <input type="number" name="qtyitem" min="1" class="form-control" id="numb">
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-primary" id="saveitem"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>
            <table class="table table-hover table-vcenter mb-0 text-nowrap" style="">
                <thead>
                    <tr>
                        
                        <th>No#</th>
                        <th>Item Name</th>
                        
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th></th>
                        <th class="text-center">Total</th>
                        <th></th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="itemsbdy" style="">

                </tbody>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td colspan="3" id="totalsum" style="font-size: 18px;"></td>
                </tr>
            </table>
        </div>
    </div>
</div>
                            <div class="form-group row">
                                <div class="col-md-12"> 
                                    <button type="submit" class="btn btn-primary float-right" id="admit_student">Admit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            <!-- </div> -->
        <!-- </div> -->
    </div>
</div>

<script src="<?php //echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
         var selectedItem = [];
   $(document).ready(function(){
        
         $('#chargedItem').select2({
            ajax: {
                url: "<?= base_url('load_data'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

        $('#chargedItem').on('select2:select', function (e) {
            selectedItems();
        });
         
        function selectedItems(){ 
            var rows = '';
           var itemData = 'item_selected='+$('#chargedItem').val()+'&selected_items_array='+selectedItem;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Itemdata')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }  
           });  

        } 
    });

   $('#saveitem').click(function(evt){
     //$('#itemsbdy').empty();
    //alert($(this).serialize());
        var data = 'itemid=' + $('#chargedItem').val();
        var account_ttl = 0; 
        var classlevel_items = "";
        var account = 0;
        
        var qty =$('#numb').val();
        var sn = 1;
   
  $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/ClassController/fetch_charged_item'; ?>',
            success: function(response){
                console.log(response);
                var lData = JSON.parse(response);
                var len = lData.length;

                for(var i = 0; i < len; i++){
                    
                    var price = lData[i]['price'];
                    var ttl = qty * price;
                     account_ttl = account_ttl + ttl; 
                     account = 6;

                    $('#total').val(ttl);

                    $('#itemsbdy').append('<tr id="row_'+ lData[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+lData[i]['item_id']+'">'+lData[i]['item_id']+'</td>\
                        <td>'+lData[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+lData[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                        <td><div class="text-end"><input type="hidden" name="price'+lData[i]['item_id']+'" value="'+price+'">'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</div></td>\
                        <td></td>\
                        <td id="total" class=""><div class="text-end"><input type="hidden" name="total'+lData[i]['item_id']+'" value="'+ttl+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</div></td>\
                        <td></td>\
                        <td>\
                            <a href="javascript:RemoveRow('+lData[i]['item_id']+','+account_ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
                classlevel_items = {account_receivable: account, amount: account_ttl};
                receivable_total_balance.push(classlevel_items);

               totalsum=totalsum+account_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });

        evt.preventDefault();
   });

    /////////////////////////////////////////////////////////////////////
    var appclass;
    var totalsum=0;
    $(document).ready(function(){
        $('#clevel').change();
       appclass = '<?php echo $app_class; ?>';
    
    });
    
    // datePickerId.max = new Date().toISOString().split("T")[0];
    $(function () {
        $('#datetimepicker1').datetimepicker();
    });

    $(function() {
        $( "#datepicker" ).datepicker({dateFormat: 'yy'});
    });
    var receivable_total_balance = [];
    // $('#croom').load('load_classRooms');
    $('#clevel').change(function(){
         document.getElementById("day").checked = true;
    document.getElementById("no").checked = true;
        var InputOption = '';
        var data = 'level=' + $('#clevel').val();
        // alert(data);

        $.ajax({
            type:'POST',
            url:'load_classRooms',
            data:data,
            dataType:'json',
            success:function(res){
               
                var len = res.length;
                $("#croom").empty();
                $("#croom").append("<option value=''>-Choose-</option>");

                for( var i = 0; i<len; i++){

                    var id = res[i]['id'];
                    var name = res[i]['cname'];
                    var total = res[i]['capcity'];
                    if(total <= 0){
                        InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Room for New Student'+"</option>";
                    }else{
                        if(appclass == id)
                        InputOption = "<option value='"+id+"' selected>"+name+"\xa0\xa0"+'-'+"\xa0"+total+"</option>";
                        else
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+'-'+"\xa0"+total+"</option>";    
                    }
                    $("#croom").append(InputOption);

                   
                }
                 get_classlevel_chargedItems();
            }
        });
    });
    function ShowStream(id,age){
        var InputOption = '';
        var data = 'id=' + id.value;
        // alert(data);
        // return;
        // if(age < 5 ){
        //     $('#ageLert').html('Age is young to join class one');
        // }
        $.ajax({
            type:'POST',
            url:'getStreamdta',
            data: data,
            dataType: 'json',
            success:function(data){

                // console.log(data);
                // return;
                var len = data.length;
                $("#stream").empty();
                $("#stream").append("<option value=''>-Choose-</option>");

                // $('#stream').html(data);
                for( var i = 0; i<len; i++){

                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    var stream = data[i]['stream'];
                    if(stream <= 0){
                        InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Room for New Student'+"</option>";
                    }else{
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+'-'+"\xa0"+stream+"</option>";
                    }
                    $("#stream").append(InputOption);
                }
                // console.log(sum);

                getClass_Charged_items();
            }
        });
    }

    function get_classlevel_chargedItems(){
         document.getElementById("filLv").innerHTML = "";
        $('#itemsbdy').empty();
        var data = 'levelID=' + $('#clevel').val();
        var account_ttl = 0; 
        var classlevel_items = "";
        var account = 0;
        $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/ClassController/fetch_classLevel_ItemData'; ?>',
            success: function(response){
                console.log(response);
                var lData = JSON.parse(response);
                var len = lData.length;

                for(var i = 0; i < len; i++){
                    var qty = lData[i]['quantity'];
                    var price = lData[i]['price'];
                    var ttl = qty * price;
                     account_ttl = account_ttl + ttl; 
                     account = lData[i]['account'];

                    $('#total').val(ttl);
                  $('#itemsbdy').append('<tr id="row_'+ lData[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+lData[i]['item_id']+'">'+lData[i]['item_id']+'</td>\
                        <td>'+lData[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+lData[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                        <td style="text-align:right"  class="text-end"><input type="hidden" name="price'+lData[i]['item_id']+'" value="'+price+'">'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td id="total" style="text-align:right"  class="text-end"><input type="hidden" name="total'+lData[i]['item_id']+'" value="'+ttl+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td>\
                            <a href="javascript:RemoveRow('+lData[i]['item_id']+','+account_ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
                classlevel_items = {account_receivable: account, amount: account_ttl};
                receivable_total_balance.push(classlevel_items);

               totalsum=totalsum+account_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });
    }
    function getClass_Charged_items(){
        // $('#itemsbdy').empty();

        document.getElementById("filLert").innerHTML = ""; 
        var type= $("input[type='radio'][name='admit']:checked").val();
        //alert(type);
        var data = 'class_id=' + $('#croom').val() +'&admfor='+type;
        //alert(data);
        var account_ttl = 0; 
        var class_items = "";
        var account = 0;
        $.ajax({
            type: 'GET',
            data: data,
            url: 'fetch_clsItems_data',
            success:function(res){

                var class_data = JSON.parse(res);
                var len = class_data.length;
                for(var i = 0; i < len; i++){

                    // receivable_total_balance.push(class_data[i]['account']);
                    // alert(receivable_total_balance);
                    // return;

                    var qty = class_data[i]['quantity'];
                    var price = class_data[i]['price'];
                    var ttl = qty * price;
                     account_ttl = account_ttl + ttl; 
                     account = class_data[i]['account'];

                    $('#total').val(ttl);


                    $('#itemsbdy').append('<tr id="row_'+ class_data[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+class_data[i]['item_id']+'">'+class_data[i]['item_id']+'</td>\
                        <td>'+class_data[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+class_data[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                        <td style="text-align:right"  class="text-end"><input type="hidden" name="price'+class_data[i]['item_id']+'" value="'+price+'">'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td id="total" style="text-align:right"  class="text-end"><input type="hidden" name="total'+class_data[i]['item_id']+'" value="'+ttl+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td>\
                            <a href="javascript:RemoveRow('+class_data[i]['item_id']+','+account_ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
                class_items = {account_receivable: account, amount: account_ttl};
                receivable_total_balance.push(class_items);
                // console.log(receivable_total_balance);

                  totalsum=totalsum+account_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });
    }
    
    function RemoveRow(item_id,account_ttl){
         totalsum=totalsum-account_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
           // return totalsum;
         $('#row_'+item_id).remove();

              
    }

    

$('input[type=radio][name=admit]').change(function(){
    document.getElementById("day").checked = true;
    document.getElementById("no").checked = true;
        var data =  $(this).val();
        $('#itemsbdy').empty();
         $(function() {
        $( "#clevel" ).change();
        totalsum=0;
        document.getElementById("filLert").innerHTML = "Choose class";
       console.log(totalsum);
            return totalsum;
    });
      if($( "#clevel" ).val()==""){
       document.getElementById("filLv").innerHTML = "Choose Level"; 
      }
        
    });

$('input[type=radio][name=state]').change(function(){
        var data =  $(this).val();
        // alert(data);
        if(this.value == 3){
            if($( "#croom" ).val()==""){
                 document.getElementById("day").checked = true;
                document.getElementById("no").checked = true;
       document.getElementById("filLert").innerHTML = "Choose Class"; 
      }else{
         
         var data = 'class_id=' + $('#croom').val();
        // alert(data);
        var amount_ttl = 0; 
        var hostel_items = "";
        var accounts = 0;
        $.ajax({
            type: 'GET',
            data: data,
            url: 'fetch_hostelItems_data',
            success:function(res){
                 // 
                var hostel_data = JSON.parse(res);
                var len = hostel_data.length;
                for(var i = 0; i < len; i++){
                  
                    var qty = hostel_data[i]['quantity'];
                    var price = hostel_data[i]['price'];
                    var ttl = qty * price;

                    amount_ttl = amount_ttl + ttl;
                    account = hostel_data[i]['accounts'];

                    $('#total').val(ttl);
                     //alert(ttl);

                    $('#itemsbdy').append('<tr id="row_'+ hostel_data[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+hostel_data[i]['item_id']+'">'+hostel_data[i]['item_id']+'</td>\
                        <td><input type="hidden" name="iid[]" value="'+hostel_data[i]['item_id']+'">'+hostel_data[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+hostel_data[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                        <td style="text-align:right"  class="text-right"><input type="hidden" name="price'+hostel_data[i]['item_id']+'" value="'+price+'">'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td id="total"  class="text-right" style="text-align:right"><input type="hidden" name="total'+hostel_data[i]['item_id']+'" value="'+ttl+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td>\
                           <a href="javascript:RemoveRow('+hostel_data[i]['item_id']+','+amount_ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
                hostel_items = {account_receivable: accounts, amount: amount_ttl};
                receivable_total_balance.push(hostel_items);
                // console.log(receivable_total_balance);

            totalsum=totalsum+amount_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });
        $('#hostelDtls').show();
       }
       
    }else if (this.value == 0){
          $(function() {
        $( "#clevel" ).change();
        totalsum=0;
        document.getElementById("filLert").innerHTML = "Choose class again";
       console.log(totalsum);
            return totalsum;
    });
            $('#hostelDtls').hide();
        }
    });

    function TransportItems(id){
        var data = 'vehicle_id=' + id.value;
        // alert(data);
        var amount_ttl = 0; 
        var vehicle_items = "";
        var accounts = 0;
        $.ajax({
            type: 'GET',
            data: data,
            url: 'fetch_vehicleItems_data',
            success:function(res){

                var transData = JSON.parse(res);
                var len = transData.length;
                for(var i = 0; i < len; i++){

                    var qty = transData[i]['quantity'];
                    var price = transData[i]['price'];
                    var ttl = qty * price;

                    amount_ttl = amount_ttl + ttl;
                    account = transData[i]['RecAccnt'];

                    $('#total').val(ttl);


                    $('#itemsbdy').append('<tr id="row_'+ transData[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+transData[i]['item_id']+'">'+transData[i]['item_id']+'</td>\
                        <td><input type="hidden" name="iid[]" value="'+transData[i]['item_id']+'">'+transData[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+transData[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                        <td class="text-end"><input type="hidden" name="price'+transData[i]['item_id']+'" value="'+price+'">'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td id="total" class="text-end" style="text-align:right"><input type="hidden" name="total'+transData[i]['item_id']+'" value="'+ttl+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td>\
                            <a href="javascript:RemoveRow('+transData[i]['item_id']+','+amount_ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
                vehicle_items = {account_receivable: accounts, amount: amount_ttl};
                receivable_total_balance.push(vehicle_items);
                totalsum=totalsum+amount_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });
    }

    $('input[type=radio][name=transp]').change(function(){
        var data =  $(this).val();
        // alert(data);
        if(this.value == 'Yes'){
            $('#trnspDtls').show();
        }else if (this.value == 'No'){
            $('#trnspDtls').hide();
        }
    });

    $('#admsionDtls').submit(function(e){
         alert($(this).serialize()+'&receivable_total_balance=' + JSON.stringify(receivable_total_balance));
        // return;
        $.ajax({
            beforeSend: function () {
                  $('#admit_student').prop("disabled", true);
                  $('#feedback').append('<div class="alert alert-primary alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button><i class="fa fa-spinner fa-spin"></i>Preparing Control Number Please wait..</div>');
            },
            type: 'POST',
            url: 'save_admission',
            data: $(this).serialize()+'&receivable_total_balance=' + JSON.stringify(receivable_total_balance),
            success:function(res){
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#admit_student').prop("disabled", false);
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            },
            error:function(res){
                $('#admit_student').prop("disabled", false);
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Admit student.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                setTimeout(function(){
            window.location.reload();
        },1000)
            }
        });

        e.preventDefault();
    });
    //////////////////////////////////////////////////////////////////////


</script>