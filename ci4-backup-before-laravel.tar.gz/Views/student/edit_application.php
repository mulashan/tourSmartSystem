<?php
    $student_model = new App\Models\StudentModel();
?>
<ul class="nav nav-tabs tab-primary page-header-tab">
    <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#PayDetails" >Payment Details</a></li>
    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#StudentData">Applicant Details</a></li>
    
    
</ul>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane" id="StudentData">
            <div id="updatFDBCK"></div>
               <form id="update_application" class="form-horizontal">
                 <div class="form-group row mb-3">
                     <label class="col-md-2 col-form-label">Applicant Name</label>
                     <div class="col-md-3">
                         <input type="text" class="form-control" name="fname" placeholder="First Name" autocomplete="off" value="<?= $app[0]->first_name;?>">
                         <input type="hidden" class="form-control" name="appid" value="<?= $app[0]->id;?>">
                     </div>
                     <div class="col-md-3">
                         <input type="text" class="form-control" name="mname" placeholder="Middle Name" autocomplete="off" value="<?= $app[0]->middle_name;?>">
                     </div>
                     <div class="col-md-3">
                         <input type="text" class="form-control" name="lname" placeholder="Last Name" autocomplete="off" value="<?= $app[0]->last_name;?>">
                     </div>
                 </div>
                 <div class="form-group row mb-3">
                     <label class="col-md-2 col-form-label">Date of Birth</label>
                     <div class="col-md-3">
                         <input type="date" class="form-control" name="dob" placeholder="F" value="<?= $app[0]->date_of_birth;?>">
                     </div>

                     <label for="" class="col-md-2 col-form-label">Gender</label>
                     <div class="col-md-3">
                         <div class="form-check">
                             <input class="form-check-input mt-1" type="radio" name="gender" id="female" value="Female" <?php if($app[0]->gender == "Female") echo "checked";?>>
                             <label class="form-check-label" for="day">
                             Female
                             </label>
                         </div>
                         <div class="form-check">
                             <input class="form-check-input mt-1" type="radio" name="gender" id="male" value="Male" <?php if($app[0]->gender == "Male") echo "checked";?>>
                             <label class="form-check-label" for="board">
                             Male
                             </label>
                         </div>
                     </div>
                 </div>
                 <div class="form-group row mb-3">
                     <label class="col-md-2 col-form-label">Class Level</label>
                     <div class="col-md-3">
                         <select name="classlevel" id="classlevel1" class="form-control" required >
                             <option value="">--Select Level--</option>
                             <?php foreach ($clevel as $c): ?>
                             <option value="<?= $c->id ?>" <?php if ($app[0]->class_lvl == $c->id) { echo 'selected'; } ?>><?= $c->level_name ?></option>
                             <?php endforeach; ?>
                         </select>
                     </div>
                     <?php
                     $class = $student_model->gettable_data('classes_tbl',$where = array('class_level' => $app[0]->class_lvl));
                     ?>
                     <label class="col-md-2 col-form-label">Class</label>
                     <div class="col-md-4">
                         <select id="class2" name="class" class="form-select me-4 form-control form-control-sm" >
                             <?php foreach ($class as $cl): ?>
                             <option value="">--Select Class--</option>
                             <option value="<?= $cl->id ?>" <?php if ($app[0]->class == $cl->id) { echo 'selected'; } ?>><?= $cl->class_name ?></option>
                             <?php endforeach; ?>
                         </select>
                     </div>
                 </div>
                <div class="form-group row mb-3">
                    <label class="col-md-2 col-form-label">Parent/Gurdian Name</label>
                    <div class="col-md-4">
                        <input type="text" class="form-control" value="<?= $app[0]->parent_firstname; ?>" name="pfname" placeholder="First Name" autocomplete="off">
                    </div>
                    <div class="col-md-4">
                        <input type="text" class="form-control" value="<?= $app[0]->parent_lastname; ?>" name="plname" placeholder="Last Name" autocomplete="off">
                    </div>
                </div>
                 <div class="form-group row mb-3">
                     <label class="col-md-2 col-form-label">Bill Phone No.</label>
                     <div class="col-md-4">
                         <input type="tell" class="form-control" name="bphone" placeholder="+255-xxx-xxx-xxx"  required autocomplete="off" value="<?= $app[0]->phone_number;?>">
                     </div>
                 </div>
                <div class="form-group row mb-3">
                  <div class="col-md-3">
                  </div>
                  <div class="col-md-4 offset-md-4">
                    <button type="button" class="btn btn-primary float-right" id="updtappbtn" onclick="Update_Application()">Update</button> 
                </div>
                </div>      
             </form>
            </div>
            <div class="tab-pane active" id="PayDetails">
                        <div class="row">
            <div class="col-md-6">
                <?php if(count($pay) > 0){ ?>
                <form id="PaymntResndForm">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Control Number:</th>
                        <td><?= $pay[0]->reference_no; ?></td>
                    </tr>
                    <tr>
                        <th>Applicant Name:</th>
                        <td><?= $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; ?></td>
                    </tr>
                    <tr>
                        <th>Applicant Id:</th>
                        <td><?= $app[0]->id ; ?></td>
                    </tr>
                    <tr>
                        <th>Charged Amount:</th>
                        <td><?= number_format($pay[0]->amount) ; ?></td>
                    </tr>
                    <tr>
                        <th>Date Created:</th>
                        <td><?= $pay[0]->date_created; ?></td>
                    </tr>
                    <tr>
                        <th>Phone No:</th>
                        <td><?= $app[0]->phone_number; ?>
                            <input type="hidden" name="phone_no" id="PhoneNO" class="form-control" value="<?= $app[0]->phone_number; ?>">
                            <input type="hidden" name="ref_no" class="form-control" value="<?= $pay[0]->reference_no; ?>">
                            <input type="hidden" name="type" class="form-control" value="0">
                        
                        </td>
                    </tr>
                        <?php
                           $m = $student_model->gettable_data('messages',$where = array('reference_no' => $pay[0]->student_id,'message_type' => 6));
                             if(count($m) > 0){
                       ?>
                    <tr>
                        <th>Invoice Msg:</th>
                        <td><textarea class="form-control" name="msg" readonly><?= $m[0]->message ?></textarea></td>
                    </tr>
                    
                    <tr id="invoicetmsg">
                       <th >Message status:</th>
                        <td>
                           <?php if( $m[0]->sent_status == 1) {?>
                           <i>Sent date:<?php echo date("d-m-Y H:i:s",$m[0]->created_at); ?> 
                             <br>Status: <?php echo $m[0]->status_description; ?>
                             <span class="pull-right">
                             <button type="button" onclick="checksmsstatus('<?php echo $m[0]->message_id; ?>','invoicetmsg')" class="btn btn-success btn-sm pull-left"><i class="fa fa-refresh"></i></button>
                                         &nbsp;&nbsp;<button type="button" onclick='PaymntResndSMSform("PaymntResndForm","invoicetmsg")' class='btn btn-primary btn-sm'>Resend</button></span>
                             <script>
                                $(function() {
                                    checksmsstatus('<?php echo $m[0]->message_id; ?>','invoicetmsg');
                                 });
                             </script>
                             <?php }elseif( $m[0]->sent_status == 2){ ?>
                                  <i>Sent Date:<?php echo $m[0]->time_sent; ?> 
                                  <br>Status: <?php echo $m[0]->status_description; ?>
                                  <br>Delivered Date:<?php echo $m[0]->time_delivered; ?>       
                             <?php } ?> 
                        </td>            
                    </tr>
                     <tr>
                        <td></td>
                        <td>
                            <a href="javascript:void(0)" onclick="resendSMS('<?=$app[0]->phone_number;?>','<?= $m[0]->message; ?>','6','<?= $app[0]->id; ?>','<?= $m[0]->send_no; ?>')"  class="btn btn-primary "><i class="fa fa-rotate-left"></i> Resend SMS</a>
                        </td> 
                    </tr>
                    
                     <?php }else{ ?>
                    <tr >
                       <th>Message status:</th>
                        <td>
                            <i class="text-warning">Not Sent</i>
                        </td>   
                    </tr>
                     <?php } ?>
                
                </table>
                    </form>
                </div>
                <div class="col-md-5 offset-1" id="PaymentSection">
                    
                </div>
                 <script>
                    $('#PaymentSection').load('<?php echo base_url() . '/index.php/StudentController/Api_payment_loader/' . $pay[0]->reference_no.'/' .$app[0]->id; ?>/'+$('#PhoneNO').val());                                   
                 </script>  
                  <?php }else{ ?>
                    <div class="mb-5">
                <td colspan="3" >
                <a href="javascript:void(0)" onclick="generateCTR('<?= $app[0]->id;?>')"  class="btn btn-primary "><i class="fa fa-rotate-left"></i> create control number</a>
            </td>
            </div>
                <?php } ?>
          </div>
            <div class="row">
            <div class="col-md-12">
                <div class="card">
                <p class=" d-flex justify-content-center mt-3">CHARGED ITEMS</p>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Item Id</th>
                            <th>Item Name</th>
                            <th>Item Size</th>
                            <th>Item Attribute</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody id="">
                        <?php
                       $dbname=session()->get('db_name');
                    $db = \Config\Database::connect($dbname);
                        $query = $db->query('SELECT item_id,item_size,item_attribute,item_name,quantity,unit_price FROM temp_item_transation_tbl ,items_tbl where temp_item_transation_tbl .item_id = items_tbl.id AND student_id='.$app[0]->id);
                        $result = $query->getResult();
                        $due=0;
                        foreach($result as $itm){
                            $due=+$itm->unit_price * $itm->quantity;
                            ?>
                         <tr>
                             <td><?= $itm->item_id; ?></td>
                             <td><?= $itm->item_name; ?></td>
                             <td><?= $itm->item_size; ?></td>
                             <td><?= $itm->item_attribute; ?></td>
                             <td><?= $itm->quantity; ?></td>
                             <td><?= number_format($itm->unit_price); ?></td>
                             <td><?= number_format($itm->unit_price * $itm->quantity); ?></td>
                         </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
            </div>
            </div>
               
            
                
              
            </div>
        </div>
  </div>
    <?php
$bill=$student_model->gettable_data('temp_item_transation_tbl', $where = array('student_id' => $app[0]->id));
if($bill[0]->bill_status==1){

}else{
?>
<button type="button" onclick="deleteTrans('<?= $app[0]->id;?>','<?= $pay[0]->reference_no?? 0;?>')" class="btn btn-danger pull-left">Delete</button>
<?php
}
?>
</div>

<script>
    function deleteTrans(id,ref){
           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this Application!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
               // alert(id+'/'+ref);
              $.ajax({
              
                 url: '<?php echo base_url() . '/index.php/StudentController/delete_application'; ?>/'+id+'/'+ref,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      
                    swal("Deleted!", "Application deleted successfuly.", "success");

                    location.reload();
                      
                 }
              });

            } else {
               swal("Cancelled");
            }

          });

    }
     
      function Update_Application(){
        $.ajax({
           beforeSend: function () {
                 $('#updtappbtn').prop("disabled", true);
                 $('#updatFDBCK').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
           },
           url: 'updat_application',
           type: 'POST',
           data: $('#update_application').serialize(),
           success: function (res) {
               var data = JSON.parse(res);
               if(data['status'] == "0"){
                   $('#updatFDBCK').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                   location.reload();
                }else{
                   $('#updtappbtn').prop("disabled", false);
                   $('#updatFDBCK').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
           },       
           error: function () {
                $('#updtappbtn').prop("disabled", false);
                $('#updatFDBCK').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');;
           }
       });
    }
     $("#classlevel1").change(function(){
        var clvl = $(this).val();   
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class2").empty();
                $("#class2").append("<option value=''>-Choose Class-</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    $("#class2").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });
    function check_payment(ref){
      
       var paydata = 'ref_no=' + ref;
        $.ajax({
            type: "POST",
            url: 'check_payment',
            beforeSend: function () {
                $('#CheckPayment').prop("disabled", true);
                $('#PaymentSection').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
            },
            data: paydata,
            success: function (result) {
                $('#PaymentSection').load('<?php echo base_url() . '/index.php/StudentController/Api_payment_loader/' . $app[0]->id; ?>');
            },
            error: function () {
                $('#CheckPayment').prop("disabled", false);
                $('#PaymentSection').html('<p class="text-red">Sorry Something went wrong</p>');;
           }
        });
    }
     function checksmsstatus(id,divhtml){
     var data = "id=" + id;
         $.ajax({
            beforeSend: function () {
                $('#'+divhtml).html('<i class="fa fa-spinner fa-spin"></i> Checking sms status..');
            },
            type: "POST",
            url: '<?php echo base_url() . '/index.php/StudentController/check_sms'; ?>',
            data: data,
            success: function (result) {
                // $('#notsent').remove();
                $('#'+divhtml).html(result);             
            },
            error: function () {
                $('#'+divhtml).html('Sorry! Something went wrong.');
            }
        });
    }
     function PaymntResndSMSform(formId,divhtml) {
          $.ajax({
            beforeSend: function () {
                $('#'+ divhtml).html('<i class="fa fa-spinner fa-spin"></i> Sending Message..');
            },
            type: "POST",
            url: '<?php //echo base_url() . '/index.php/StudentController/resend_sms'; ?>',
            data: $('#'+formId).serialize(),
            success: function (result) {
              //  alert(result);
                $('#'+ divhtml).html(result);             
            },
            error: function () {
                $('#'+divhtml).html('Sorry! Something went wrong.');
            }
        });
    }
    function generateCTR(student_id){
    $('#EditApp').modal('hide');
 //alert('trans='+trans+' studentid='+student_id+' due='+due);
  var data = 'sID=' + student_id + '&due=' + '<?php echo $due;?>'+'&'+$("#header_form").serialize();
        // alert(data);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/StudentController/generate_appl_controlnumber'; ?>',
            data: data,
            success: function (res) {
                //var data = JSON.parse(res);

                 Swal.fire({
                    title: data['status'], 
                    html: data['statusDesc'], 
                    icon: data['status']
                  }).then((result) => {
                  if (result.isConfirmed) {
                    if(data['status']=='error'){

                    }else{
                        location.reload();  
                    }
                  }
                });
                
            },
            error: function () {
                alert('Sorry!, Something went wrong');
            }

        });
   }
   function resendSMS(phone,msg,type,ref,snn){
        var message = escape(msg);
        var data = 'phn=' + phone + '&msg=' + msg + '&type=' + type + '&ref=' + ref;
         var response=1;
         // alert(data);
         // return;
         swal({
            title: "Are you sure?",
            text: "To resend this message "+msg+" to "+phone,
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, update!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },
          function(isConfirm) {
            if (isConfirm) {
               
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/SMSsender/'; ?>' + phone +'/'+ message +'/' + type +'/' + ref+'/' + snn+'/'+response,
            success: function(res){
                //console.log(res)
                swal('success','Message sent successfully','success');
               
            },
             error:function(res){
               swal('error','Message not sent','error');
            }
        });
    }else{
        swal('Cancelled');
    }}
    );
    }
</script>    