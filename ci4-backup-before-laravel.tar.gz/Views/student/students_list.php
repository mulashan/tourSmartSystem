     <?php
     helper('age');
     $studentModel = new App\Models\studentModel();
     ?>
      <div class="card">
                <div class="table-responsive mt-3">
                    <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                        <thead>
                            <tr>
                                <th>Photo</th>
                                <th>Student No.</th>
                                <th>Reg Date</th>
                                <th>Student Names</th>
                                <th>Gender</th>
                                <th>Birth Date</th>
                                <th>Age</th>
                                <th>Initial Class</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody style="padding:1px;">
                            <?php 
                            if(count($student)>0){
                            foreach($student as $s){ 
                                $source = "";
                                if($s->student_photo != ""){
                                  $source =  base_url('public/student_photos/'.$s->student_photo);
                              }
                              if($s->status==1){
                                $status="Pending";
                              }elseif($s->status==2){
                                   $status="Admitted";
                              }elseif($s->status==3){
                                   $status="Transfered";
                              }elseif($s->status==4){
                                   $status="Graduates";
                              }elseif($s->status==5){
                             $status="Absconded";
                              
                              }elseif($s->status==6){
                             $status="No show";
                              
                              }
                              else{
                                $status="";
                              }
                            $clas="";
                            if($s->initial_class >0){
                                $class = $studentModel->gettable_data('classes_tbl', $where = array('id' => $s->initial_class));
                                $clas=$class[0]->class_name??"";
                            }

                    $checkAdmitted = $studentModel->gettable_data('admission_tbl', $where = array('student_id' => $s->id));
                    if(count($checkAdmitted)>0){
                        $btnState="disabled";
                    }else{
                     $btnState="";   
                    }

                        

                              ?>
                              <tr>
                                <td><img src="<?php echo $source; ?>" width="30" height="50"> </td>
                                <td><?php echo $s->student_id;?></td>
                                <td><?php echo $s->date_created ;?></td>
                                <td><?php echo $s->first_name.' '.$s->middle_name.' '.$s->last_name;?></td>
                                <td><?php echo $s->gender;?></td>
                                <td><?php echo $s->birth_date;?></td>
                                <td><?= findAge($s->birth_date);?>
                                <td><?php echo $clas;?></td>
                                  <td><?php echo $status;?></td>
                                  
                                    <?php //echo (date('Y') - date('Y',strtotime($s->birth_date))); ?></td>
                                <!--<td></td>-->
                                <td><a href="javascript:void(0)" onclick="edit_student(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>
                                    <button type="button" class="btn btn-primary btn-sm passingData" data-id="<?= $s->id;?>"><i class="fa fa-eye"></i> View</button>

                                   
                                </td>

                            </tr>
                        <?php }} ?>
                    </tbody>
                </table>
            </div>
        </div>

        <script type="text/javascript">
            $(document).ready( function () {
        $('#myTable').DataTable();
    } );

            $(".passingData").click(function () {
        var data = 'ids=' + $(this).attr('data-id');

        $('#myModalview').modal('show');
        $.ajax({
            type: "GET",
            url: "view_student",
            data: data,
            beforeSend: function () {
                $('#showLedger').html('<center><i class="fa fa-spinner fa-spin"></i> Loading please wait..</center>');
            },
            success: function(res){
                $('#showLedger').html(res);

            },
            error: function ()
            {

            }
        });
    });

    function delete_student(student_id){
      swal({
            title: "Delete Student",
            text: 'Are you sure?',
           
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Ok",
            cancelButtonText: "Cancell",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
            var data = 'id=' + student_id; 
          //  alert(data);
              $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/StudentController/delete_student'; ?>',
            data: data,
            success: function (res) {
              var data = JSON.parse(res);
              if(data['status'] == "1"){
            swal("success","Deleted successfuly","success");
             location.reload();
            }
            },
            error: function (){
                alert('error encounted');
                swal("error","Sorry! Something went wrong","error");
            }
        });
            } else {
              swal("Cancelled");
            }

          });
       }
        </script>    
