 
<?php 
helper('age');
$studentModel = new App\Models\studentModel();
$ino = "";
$sid = $studentModel->get_max_id('students','student_id');
if (count($sid) > 0) {
    $stid = $sid[0]->max_id + 1;
    $ino = $stid;
} else {
    $ino =  1;
}

 $lmodel = new App\Models\LoginModel();
    $staffModel = new App\Models\StaffModel();
    $imodel = new App\Models\ItemsModel();

    $staff = $staffModel->get_total_user('users','user_id',$where = array('status' => 1));
    $boys = $staffModel->get_total_user('students','id',$where = array('gender' => 'Male'));
    $girls = $staffModel->get_total_user('students','id',$where = array('gender' => 'Female'));
     $day = $staffModel->get_total_user('admission_tbl','id',$where = array('admission_type' => 0));
     $bod = $staffModel->get_total_user('admission_tbl','id',$where = array('admission_type' => 3));
    $sales = $imodel->get_total_admision_collection('ledger_transaction_tbl','amount');
    $coll = $imodel->get_total_admision_collected('ledger_transaction_tbl','amount');
    $app = $imodel->get_total_accounts('students','id');
   //$pcont=number_format((float)$cont[0]->id/$app[0]->id,2,'.','');
   //$pnew=number_format((float)$new[0]->id/$app[0]->id,2,'.','');
   $pboys=number_format((float)$boys[0]->id/$app[0]->id,3,'.','');
   $pgirls=number_format((float)$girls[0]->id/$app[0]->id,3,'.','');
   if($coll[0]->amount>0){
   $pcol=number_format((float)$coll[0]->amount/$sales[0]->amount,4,'.','');
    }else{
        $pcol=0;
    }
   // $pnew=number_format($new[0]->id/$app[0]->id);
  //$perc=($sales[0]->amount/$coll[0]->amount)*100;
?>

<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Students</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                        <?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
                    </a></li>
                    <li class="breadcrumb-item active" aria-current="page">Student Dashboard</li>
                </ol>
            </div>
          <!--   <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Student-all">Students List</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Student-add">New Student</a></li>
            </ul> -->
        </div>
    </div>
</div>

<div class="section-body mt-4">
<div class="container-fluid">
<div class="row clearfix row-deck">
                       
                      
     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:#8A3324;">
            <div class="card-body ribbon">
             
                   <span style="color:white;">STUDENTS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= $app[0]->id; ?></span></h5>
             
            </div>
        </div>
    </div>

     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:blue;">
            <div class="card-body ribbon">
             
                   <span style="color:white;"> BOYS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= number_format($boys[0]->id); ?></span></h5>  <h5><b><span style="color:greenyellow;"><?= ($pboys)*100; ?>%</span></b></h5>
             
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:pink;">
            <div class="card-body ribbon">
             
                   <span style="color:black;">GIRLS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:black;"><?= number_format($girls[0]->id); ?></span></h5>
                   <h5><b><span style="color:green;"><?= ($pgirls)*100; ?>%</span></b></h5>
                   <!-- <h6 id="OPDtotal"><span style=""></span></h6> -->
             
            </div>
        </div>
    </div>
    
    </div>

       <div class="row mt-3"> 
          <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">STUDENT RELIGION</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="admitionbylevel">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>

       
        <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">NATIONALITY</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="contvsnew">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
    </div>

 <div class="row mt-3"> 
       <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">GENDER</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="genderadmition">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
     
    </div>
    </div> 
    </div>
<script>
   

$(document).ready(function () {
       loadAdimissionGender();
       loadNationality();
       //admitiontype();
       //selColl();
       studentReligion();
       //admitionbyclass();
    });

// function loadapp() {
//          $('#classlevel').load('<?php echo base_url() . '../index.php/StudentController/get_classlevel_details'; ?>');
//     }
  
function loadAdimissionGender() {
        $.ajax({
            beforeSend: function () {
                $('#genderadmition').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/get_AdimissionGender_details2'?>',
            success: function (result) {
                $('#genderadmition').html(result);
            },
            error: function () {
                $('genderadmition').html('Sorry! Something went wrong.');
            }
        });
    }
    function loadNationality() {
        $.ajax({
            beforeSend: function () {
                $('#contvsnew').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/get_nationality_trends'?>',
            success: function (result) {
                $('#contvsnew').html(result);
            },
            error: function () {
                $('contvsnew').html('Sorry! Something went wrong.');
            }
        });
    }
    //   function admitiontype() {
    //     $.ajax({
    //         beforeSend: function () {
    //             $('#admitiontype').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
    //         },
    //         type: "POST",
    //         url: '<?php echo base_url().'../index.php/StudentController/get_admitiontype_details'?>',
    //         success: function (result) {
    //             $('#admitiontype').html(result);
    //         },
    //         error: function () {
    //             $('admitiontype').html('Sorry! Something went wrong.');
    //         }
    //     });
    // }
    // function selColl() {
    //     $.ajax({
    //         beforeSend: function () {
    //             $('#salesvscoll').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
    //         },
    //         type: "POST",
    //         url: '<?php echo base_url().'/index.php/StudentController/get_selColl_details'?>',
    //         success: function (result) {
    //             $('#salesvscoll').html(result);
    //         },
    //         error: function () {
    //             $('salesvscoll').html('Sorry! Something went wrong.');
    //         }
    //     });
    // }
     function studentReligion() {
        $.ajax({
            beforeSend: function () {
                $('#admitionbylevel').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/students_details'?>',
            success: function (result) {
                $('#admitionbylevel').html(result);
            },
            error: function () {
                $('admitionbylevel').html('Sorry! Something went wrong.');
            }
        });
    }
    //   function admitionbyclass() {
    //     $.ajax({
    //         beforeSend: function () {
    //             $('#admitionbyclass').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
    //         },
    //         type: "POST",
    //         url: '<?php echo base_url().'../index.php/StudentController/admitionbyclass_details'?>',
    //         success: function (result) {
    //             $('#admitionbyclass').html(result);
    //         },
    //         error: function () {
    //             $('admitionbyclass').html('Sorry! Something went wrong.');
    //         }
    //     });
    // }
</script>