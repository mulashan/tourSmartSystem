 
<?php 
helper('age');
$studentModel = new App\Models\studentModel();
$ino = "";
$sid = $studentModel->get_max_id('students','student_id');
if (count($sid) > 0) {
    $stid = $sid[0]->max_id + 1;
    $ino = $stid;
} else {
    $ino =  1;
}

 $lmodel = new App\Models\LoginModel();
    $staffModel = new App\Models\StaffModel();
    $imodel = new App\Models\ItemsModel();

    $par = $staffModel->get_total_user('parents_tbl','id',$where = array('bill_account' => 0));
    $fa = $staffModel->get_total_user('parents_tbl','id',$where = array('relation' => 2));
    $ma = $staffModel->get_total_user('parents_tbl','id',$where = array('relation' => 1));
     $gu = $staffModel->get_total_user('parents_tbl','id',$where = array('relation' => 3));
     $bod = $staffModel->get_total_user('admission_tbl','id',$where = array('admission_type' => 3));
    // $sales = $imodel->get_total_admision_collection('ledger_transaction_tbl','amount');
    // $coll = $imodel->get_total_admision_collected('ledger_transaction_tbl','amount');
    $app = $imodel->get_total_accounts('students','id',$year);
  if(count($fa)>0)
   $pfa=number_format((float)$fa[0]->id/$par[0]->id,2,'.','');
if(count($ma)>0)
   $pma=number_format((float)$ma[0]->id/$par[0]->id,2,'.','');
if(count($gu)>0)
   $pgu=number_format((float)$gu[0]->id/$par[0]->id,2,'.','');
   // if($coll[0]->amount>0){
   // $pcol=number_format((float)$coll[0]->amount/$sales[0]->amount,4,'.','');
   //  }else{
   //      $pcol=0;
   //  }
   // $pnew=number_format($new[0]->id/$app[0]->id);
  //$perc=($sales[0]->amount/$coll[0]->amount)*100;
?>

<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Parents</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                    <?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Parents Dashboard</li>
                </ol>
            </div>
          <!--   <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Student-all">Students List</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Student-add">New Student</a></li>
            </ul> -->
        </div>
    </div>
</div>

<div class="section-body mt-4">
<div class="container-fluid">
<div class="row clearfix row-deck">
                       
                      
     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:blueviolet;">
            <div class="card-body ribbon">
             
                   <span style="color:white;">PARENTS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= $par[0]->id; ?></span></h5>
             
            </div>
        </div>
    </div>

     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:darkblue;">
            <div class="card-body ribbon">
             
                   <span style="color:white;"> FATHERS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= number_format($fa[0]->id); ?></span></h5>  <h5><b><span style="color:yellow;"><?= ($pfa)*100; ?>%</span></b></h5>
             
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:seagreen;">
            <div class="card-body ribbon">
             
                   <span style="color:white;">MOTHERS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= number_format($ma[0]->id); ?></span></h5>
                   <h5><b><span style="color:yellow;"><?= ($pma)*100; ?>%</span></b></h5>
                   <!-- <h6 id="OPDtotal"><span style=""></span></h6> -->
             
            </div>
        </div>
    </div>
     <div class="col-6 col-md-4 col-xl-2">
        <div class="card" style="background-color:darkgreen;">
            <div class="card-body ribbon">
             
                   <span style="color:white;">GURDIANS</span>
                    <br>
                   <h5 id="OPDtotal"><span style="color:white;"><?= number_format($gu[0]->id); ?></span></h5>
                   <h5><b><span style="color:yellow;"><?= ($pgu)*100; ?>%</span></b></h5>
                   <!-- <h6 id="OPDtotal"><span style=""></span></h6> -->
             
            </div>
        </div>
    </div>
    </div>

       <div class="row mt-3"> 
          <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">Parents relation</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="relation">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>

       
        <!-- <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">Parents vs students</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="c3-donut-chart3">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div> -->
    </div>

<!--  <div class="row mt-3"> 
       <div class="col-md-6">   
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h6 class="box-title">GENDER</h6>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="genderadmition">
                        <center><span class="fa fa-spinner fa-spin"></span> Please wait..</center>
                    </div> 
                </div>
            </div>
        </div>
     
    </div> -->
    </div> 
    </div>
<script>
   

$(document).ready(function () {
       loadRelation();
       //parents();
      // admitiontype();
       //selColl();
       ///studentReligion();
      // admitionbyclass();
    });


  
function loadRelation() {
        $.ajax({
            beforeSend: function () {
                $('#genderadmition').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/get_relation_details'?>',
            success: function (result) {
                $('#relation').html(result);
            },
            error: function () {
                $('relation').html('Sorry! Something went wrong.');
            }
        });
    }

    
  
    function parents() {
                 $.ajax({
            beforeSend: function () {
                $('#c3-donut-chart3').html('<center><i class="fa fa-spinner fa-spin"></i> Wait please..</center>');
            },
            type: "POST",
            url: '<?php echo base_url().'/index.php/StudentController/students_parents'?>',
            success: function (result) {
                $('#c3-donut-chart3').html(result);
            },
            error: function () {
                $('c3-donut-chart3').html('Sorry! Something went wrong.');
            }
        });
            }
</script>