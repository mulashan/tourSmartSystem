<form id="ReceiptResndForm">
    <table class="table table-borderless">
    <?php
        $student_model = new App\Models\StudentModel();

        $trns_status = "";
        $rec_no = "";
        $amount = 0;
        $message = "";
        
        if($checking_status[0]->bill_status == 1){
            $ledger = $student_model->gettable_data('ledger_transaction_tbl', $where = array('name_type_id' => $checking_status[0]->name_type_id , 'name_id' => $checking_status[0]->student_id ));

            if(count($payment_resp) > 0){
                $rec_no = $payment_resp[0]->transaction_receipt;
                $amount = number_format($payment_resp[0]->amount_payed);
                $trns_status = 'Paid';
            }else{
                $rec_no =  $ledger[0]->trans_no;
                $amount = number_format($ledger[0]->amount);
                $trns_status = 'Paid';
            }
    ?>
        <tr>
            <th>Transaction Status:</th>
            <td class="text-blue"><b><?= $trns_status; ?></b></td><th></th>
        </tr>
        <tr>
            <th>Transaction Receipt:</th>
            <td><?= $rec_no; ?></td>
        </tr>
    <?php if(count($payment_resp) > 0){?>
         <tr>
            <th>Payed By:</th>
            <td><?= $payment_resp[0]->customer_name ; ?></td>
        </tr>
         <tr>
            <th>Account Number:</th>
            <td><?= $payment_resp[0]->account_no ; ?></td>
        </tr>
    <?php } ?>
        <tr>
            <th>Amount Paid:</th>
            <td><?=  $amount; ?></td>
        </tr>
    <?php if(count($payment_resp) > 0){?>
        <tr>
            <th>Transaction Date:</th>
            <td><?= $payment_resp[0]->transaction_date ; ?>
            <input type="hidden" name="phone_no" class="form-control" value="<?= $phone_no; ?>">
            <input type="hidden" name="ref_no" class="form-control" value="<?= $ref; ?>">
            <input type="hidden" name="type" class="form-control" value="1">
            </td>
        </tr>
    <?php } ?>
        <!-- <tr>
            <th>Receipt Msg:</th>
            <td><textarea class="form-control" name="msg" readonly><?php// $message; ?></textarea></td>
        </tr> -->

      <!--   <tr id="paymentmsg">
           <th>Message status:</th>
            <td>
               <?php //if( $msg[0]->sent_status == 1) {?>
               <i>Sent date:<?php //echo date("d-m-Y H:i:s",$msg[0]->created_at); ?> 
                 <br>Status: <?php //echo $msg[0]->status_description; ?>
                 <span class="pull-right">
                 <button type="button" onclick="checksmsstatus('<?php //echo $msg[0]->message_id; ?>','paymentmsg')" class="btn btn-primary btn-sm "><i class="fa fa-refresh"></i></button>
                 &nbsp;&nbsp;<button type="button" onclick='PaymntResndSMSform("ReceiptResndForm","paymentmsg")' class='btn btn-primary btn-sm'>Resend</button></span>
                   <script>
                   $(function() {
                       checksmsstatus('<?php //echo $msg[0]->message_id; ?>','paymentmsg');
                   });
                  </script>    
                 <?php //}elseif( $msg[0]->sent_status == 2){ ?>
                      <i>Sent Date:<?php //echo $msg[0]->time_sent; ?> 
                      <br>Status: <?php //echo $msg[0]->status_description; ?>
                      <br>Delivered Date:<?php //echo $msg[0]->time_delivered; ?>       
                 <?php //} ?> 
            </td>            
        </tr>
     <?php //}else{ ?>
        <tr >
           <th>Message status:</th>
            <td>
                <i class="text-warning">Not Sent</i>
            </td>   
        </tr>
         <?php //} ?> -->

      <?php }else{ ?>
    <tr>
        <th>Transaction Status:</th>
        <td class="text-green"><b>Pending</b> </td>
        <!-- <td class="text-green"><b>Pending</b> <button type="button" class="btn btn-primary btn-sm float-right" id="CheckPayment" onclick="check_payment('<?php //$ref; ?>')" ><span class="badge bg-info text-dark">Check Payment</span></button> </td> -->
    </tr>
      <?php }?>
    </table>
</form>