<style type="text/css">
    .text-right {
    text-align: right !important;
}
table tr:hover{
    background: white;
}

</style>
<link rel="stylesheet" href="<?php// echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 
    helper('age');

    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();
    $app_class = 0;
    $app_lvl="";
    $age = findAge($student_dtl[0]->birth_date);

    $level = $amodel->admisiion_details('class_level_tbl');
    $admission = $amodel->get_student_details('admission_tbl',$where = array('student_id' => $student_dtl[0]->id,'status' => 1));
    $appln = $amodel->get_student_details('students_application_tbl',$where = array('id' => $student_dtl[0]->id));
    $terms = $amodel->admisiion_details('school_terms_tbl');
    $hstl = $amodel->get_hostel_details($student_dtl[0]->gender,$age);
    $transport = $amodel->admisiion_details('route_tbl');

    if(count($appln) > 0){        
        $app_class = $appln[0]->class;
        $app_lvl = $appln[0]->class_lvl;
    }else{
        $app_class = "";
        $app_lvl = "";
    }
    $parent = $amodel->get_student_details('parents_tbl', $where = array('id' => $studentparent[0]->parent_id));

?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <!-- <div class="card"> -->
           <!--  <div class="card-header" style="height:5px">
                <h3 class="card-title">Admission Details</h3>
                <div class="card-options ">
                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                </div>
            </div>
            <hr> -->
            <!-- <div class="card-body"> -->
                <div class="row">
                        <div id="feedback"></div>
                    <div class="col-md-5">
                        <!-- <h6 class="card-title d-flex justify-content-center mb-2">Student Information</h6> -->
                        <div class="card">
                                <p Class=" d-flex justify-content-center mt-2">STUDENT DETAILS</p>
                            <center>
                                <?php 
                                    $source = "";
                                    if($student_dtl[0]->student_photo != ""){
                                      $source =  base_url('public/student_photos/'.$student_dtl[0]->student_photo);
                                    }
                                ?>
                                <img src="<?php echo $source; ?>" style="margin-top: 2em;width:80px; height:100px;border: 1px wheat solid">
                                <table class="table table-borderless mt-3">
                                    <tr>
                                        <th>Student Name:</th>
                                        <td><?= $student_dtl[0]->first_name.' '. $student_dtl[0]->middle_name.' '.$student_dtl[0]->last_name;?></td>
                                    </tr>
                                    <tr>
                                        <th>Date of Birth:</th>
                                        <td><?= $student_dtl[0]->birth_date;?></td>
                                    </tr>
                                    <tr>
                                        <th>Age:</th>
                                        <td><?= findAge($student_dtl[0]->birth_date); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Gender:</th>
                                        <td><?= $student_dtl[0]->gender;?></td>
                                    </tr>
                                    <tr>
                                        <th>Nationality:</th>
                                        <td><?= $student_dtl[0]->nationality;?></td>
                                    </tr>
                                    <tr>
                                        <th>Gurdian / Parent Name:</th>
                                        <td><?= $parent[0]->first_name.' '. $parent[0]->last_name;?></td>
                                    </tr>
                                    <tr>
                                        <th>Gurdian / Parent Phone:</th>
                                        <td><?= $parent[0]->phone1;?></td>
                                    </tr>
                                    <tr>
                                        <th>Address:</th>
                                        <td><?= $parent[0]->postal_address;?></td>
                                    </tr>
                                </table>
                            </center>
                        </div>
                        <div class="card mt-3">
                            <p Class=" d-flex justify-content-center mt-1">BOARDING HISTORY</p>
                            <table class="table table-hover table-vcenter mb-0 text-nowrap">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Permit no</th>
                                        <th>Hostel</th>
                                        <th>Start date</th>
                                        <th>End date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if(count($admission) > 0){
                                    foreach ($admission as $adm): 
                                        $classdtl = $amodel->class_stream_details($adm->class_id,$adm->stream_id);
                                        ?>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                    <?php endforeach; }else{ ?>
                                        <tr>
                                            <td colspan="4" style="text-align:center;">No Admission Data Found</td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <form class="form-horizontal" id="admsionDtls">
                            <div class="card">
                         <p Class=" d-flex justify-content-center mt-2">BOARDING DETAILS</p>
                            <input type="hidden" name="sid" value="<?= $student_dtl[0]->id;?>">
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label">Academic Year:</label>
                                <div class="col-md-3">
                                    <select class="form-control" name="acdy">
                                       <?php
                                       $year = (int)date('Y');
                                       $y=$year+5;
                                       for ($year; $y>= $year; $year++): ?>
                                         <option value="<?php echo $year;?>"><?php echo $year;?></option>
                                       <?php endfor; ?>
                                    </select>
                                    <!-- <input type="number" min="1900" max="2099" step="1" value="2023"  name="acdy" id="datepicker" class="form-control"> -->
                                </div>
                               
                                <label class="col-md-2 col-form-label"> Date:</label>
                                <div class="col-md-4">
                                    <!-- <input type="date"  name="djoin" id="datePickerId" class="form-control" min="2007-12-31"> -->
                                    <input type='date' class="form-control"  value="<?php echo date('Y-m-d')?>" name="djoin" id='' />
                                </div>
                            
                            </div>
                            <!--------------------------------------------------->
                               <div class="form-group row">
                                <label class="col-md-3 col-form-label">Admission Type:</label>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="admit" id="cont" value="0" required="required" checked="checked">
                                        <label class="form-check-label" for="Continous">
                                            Continous
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="admit" id="new" value="2" required="required">
                                        <label class="form-check-label" for="new">
                                            New Comer
                                        </label>
                                    </div>
                                </div>
                                <label class="col-md-2 col-form-label"> Class:</label>
                                <label class="col-md-2 col-form-label"> <?php echo $classdtl[0]->class_name;?></label>
                                
                                </div>
                           
                        
<div class="form-group row">
    <div class="col-md-6">
        <div class="card" id="hostelDtls" style="">
            <div class="form-group row">
                <p Class=" d-flex justify-content-center mt-1">HOSTEL DETAILS</p>
                <label  class="col-md-4 col-form-label">Select Hostel</label>
                <div class="col-md-7">
                    <select id="hstl" name="hstl" class="form-select me-4 form-control form-control-sm checkLimit" onchange="hostelItems(this)">
                        <option selected value="">Choose</option>
                        <?php 
                            foreach ($hstl as $h):
                            $remainingBalnc = $amodel->hostel_remaining_capacity($h->id);
                            if($remainingBalnc[0]->remaining_capacity != '' || $remainingBalnc[0]->remaining_capacity != NULL){
                                $remain_capacity = '- '.$remainingBalnc[0]->remaining_capacity;
                            }else{
                                $remain_capacity = '- ';
                            }
                         ?>
                            <option value="<?= $h->id;?>"><?= $h->hostel_name .' '.$remain_capacity;?></option>
                        <?php endforeach ?>
                    </select>
                     <div id="hostelf" style="color:red"><span>Choose hostel</span></div>
                </div>
            </div>
        </div>
    </div>
   
                                 <label class="col-md-2 col-form-label mt-3">End Date:</label>
                                <div class="col-md-3 mt-3">
                                     <input type='date' class="form-control"  value="<?php echo date('Y-m-d')?>" name="end" id='end' />
                                <div id="ageLert" style="color:red"></div>
                                <div id="filLert" style="color:red"></div>
                                </div>
    
                             
                                
                              <!--   <label class="col-md-3 col-form-label">Total Month:</label>
                                <div class="col-md-3">
                                      <input type='number' class="form-control"  value="" onchange="month_item(this)" name="tmonth" id='tmonth' />
                                <div id="ageLert" style="color:red"></div>
                                <div id="filLert" style="color:red"></div> -->
                                </div>
                                 
                            </div>
                           <!--  <div class="form-group row" id="end_date" style="display:none;">
                                <label class="col-md-2 col-form-label" style="">End Date:</label>
                                  <div class="col-md-3">
                                     <input type='date' class="form-control"  value="<?php echo date('Y-m-d')?>" name="end" id='end' />
                                
                                </div> 
                               
                            </div> -->

                             

  
<div class="form-group row">
    <div class="col-md-12">
        <div class="card">
            <p Class=" d-flex justify-content-center mt-1">CHARGED ITEMS</p>
             <div class="form-group row">
                                <label class="col-md-2 col-form-label">Charged Items<span class="text-danger"></span><span class="text-danger"></span></label>
                                <div class="col-md-5">
                                    <select name="chargedItem" class="form-select form-control" id="chargedItem">
                                        <option class="">-search-</option>
                                     <!--    <?php
                                        //$charged=$amodel->getChargedItems();
                                        //foreach($charged as $ch){
                                    ?>
                                        <option value="<?php //echo $ch->id; ?>"><?php //echo $ch->item_name.' '.$ch->item_size.' '.number_format($ch->item_price).'/='; ?></option>
                                    <?php //}?> -->
                                    </select>
                                </div> 
                                <label class="col-md-2 col-form-label">Quantity<span class="text-danger"></span><span class="text-danger"></span></label>
                                <div class="col-md-2">
                                    <input type="number" name="qtyitem" min="1" class="form-control" id="numb">
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-primary" id="saveitem"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>
            <table class="table table-vcenter mb-0 text-nowrap" style="">
                <thead>
                    <tr>
                        
                        <th>No#</th>
                        <th>Item Name</th>
                        
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th></th>
                        <th class="text-center">Total</th>
                        <th></th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="itemsbdy" style="">
                 
                             <div  class="cust_popup" id="cash" style="display: none">
                                    <h6>Change price</h6>
                                <div id="prcres"></div>
                                     
                               </div> 
                </tbody>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td colspan="3" id="totalsum" style="font-size: 18px;"></td>
                </tr>
            </table>
        </div>
    </div>
</div>
                            <div class="form-group row">
                                <div class="col-md-12"> 
                                    <button type="submit" class="btn btn-primary float-right" id="admit_student">Admit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            <!-- </div> -->
        <!-- </div> -->
    </div>
</div>
<!-- <div class="cust_popup" id="cash" style="display: none">
            <button class="btn pull-right" onclick="taxpop()">X</button> &nbsp;
            <div id="txres"></div>
            
        </div> -->
<script src="<?php //echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
         var selectedItem = [];
          var hold_selected_items = [];
   $(document).ready(function(){
        
         $('#chargedItem').select2({
            ajax: {
                url: "<?= base_url('load_data'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

        $('#chargedItem').on('select2:select', function (e) {
            selectedItems();
        });
         
         
        function selectedItems(){ 
            var rows = '';
           var itemData = 'item_selected='+$('#chargedItem').val()+'&selected_items_array='+selectedItem;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Itemdata')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }  
           });  

        } 
    });

   $('#saveitem').click(function(evt){
     //$('#itemsbdy').empty();
    //alert($(this).serialize());
        var data = 'itemid=' + $('#chargedItem').val();
        var account_ttl = 0; 
        var classlevel_items = "";
        var account = 0;
        
        var qty =$('#numb').val();
        var sn = 1;
   
  $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/ClassController/fetch_charged_item'; ?>',
            success: function(response){
                console.log(response);
                var lData = JSON.parse(response);
                var len = lData.length;

                for(var i = 0; i < len; i++){
                     var iid=lData[i]['item_id'];
                    var price = lData[i]['price'];
                    var ttl = qty * price;
                     account_ttl = account_ttl + ttl; 
                     account = 6;

                    $('#total').val(ttl);

                    $('#itemsbdy').append('<tr id="row_'+ lData[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+lData[i]['item_id']+'">'+lData[i]['item_id']+'</td>\
                        <td>'+lData[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+lData[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                         <td>\
                        <a class="cost2" id="cost' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getid(' +iid+','+price+')"><input type="text" value="'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" id="prc'+iid+'" readonly></a>\
                        </td>\
                        <td><input type="hidden" name="prco'+iid+'" id="prco'+iid+'" value="'+price+'"></td>\
                       <td class="text-right" style="text-align:right" id="total'+lData[i]['item_id']+'">'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td>\
                            <a href="javascript:RemoveRow('+lData[i]['item_id']+','+ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                    classlevel_items = {iid:iid,qty:qty, price:price, account_receivable: account, amount: account_ttl};
                receivable_total_balance.push(classlevel_items);
                }
                //classlevel_items = {account_receivable: account, amount: account_ttl};
               // receivable_total_balance.push(classlevel_items);

               totalsum=totalsum+account_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });

        evt.preventDefault();
   });

 function getid(id,prc) {
     $('#cash').toggle(100);
      
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/priceview'; ?>",
            beforeSend: function () {
                $('#prcres').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#prcres').html(result);
                console.log(prc);
             document.querySelector('[id="cash_amt"]').value = prc;
             document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }
    
    
     function savebtn(){
        totalsum=0;
      var cash=$('#cash_amt').val();
      var item_id=$('#item_id').val();
      //alert(item_id); 
      for( var i = 0; i < hold_selected_items.length; i++){ 
           id1=hold_selected_items[i];
           if(id1==item_id){
            var cashAmt =parseInt(cash);
            document.querySelector('[id="prco'+id1+'"]').value = cashAmt;
            document.querySelector('[id="prc'+id1+'"]').value = cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            document.getElementById("total"+id1).innerHTML = cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

           // $('#cost'+id1+'').append(cashAmt);
           }else{
            var cashAmt1 =$('#prc'+id1+'').val();
            let result = cashAmt1.replace(/,/gi, "");
        
            var cashAmt =parseInt(result);
           // alert(cashAmt);
           }
       
        totalsum=totalsum+cashAmt;
        }       
          $('#cash').hide(); 
             document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;       
         e.preventDefault(); 
    }


    /////////////////////////////////////////////////////////////////////
    var appclass;
    var totalsum=0;
    // $(document).ready(function(){
    //     $("#clevel").empty();
    //      $("#croom").empty();
    
    //    $('#clevel').change();
    //  appclass = '<?php echo $app_class; ?>';

    // });
    
    // datePickerId.max = new Date().toISOString().split("T")[0];
    $(function () {
        $('#datetimepicker1').datetimepicker();
    });

    $(function() {
        $( "#datepicker" ).datepicker({dateFormat: 'yy'});
    });
    var receivable_total_balance = [];
   

     function month_item(id){
         var data = 'start=' + $('#start').val()+'&month=' + id.value;
     $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/ClassController/append_date'; ?>',
            success: function(res){
                var date = JSON.parse(res);
                  $('#end_date').show();
                  $('#end').val(date[0]['end_date']);
                  monthly_items(id.value);
            }
            });

     }
   
    function hostelItems(id){
       // alert(id);
       //var data =id.value; 
        if(id==''){
            document.getElementById("hstlf").innerHTML = "Choose hostel"; 
        }else{
           document.getElementById("hostelf").innerHTML = "";
            $('#hostelf').hide();
            monthly_items(1);  
        }
    }
   
    function RemoveRow(item_id,account_ttl){
         totalsum=totalsum-account_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
           // return totalsum;
         $('#row_'+item_id).remove();

              
    }
    
    $('#change_cash').submit(function(e){
       alert('here');
    });

  $('#admsionDtls').submit(function(e){
     var type= $("input[type='radio'][name='admit']:checked").val();
    data='student_id='+ $('input[name=sid]').val()+'&acdy='+ $('select[name=acdy]').val()+'&djoin='+ $('input[name=djoin]').val()+'&receivable_total_balance=' + JSON.stringify(receivable_total_balance)+'&end_date='+ $('input[name=end]').val()+'&hostel='+$('#hstl').val()+'&type='+type;
        //alert($(this).serialize());
          //var bod=$('#hstl').val();
          //alert(type);
          //alert(bod);
         if(type==3 && bod==''){
            document.getElementById("hostelf").innerHTML = "Choose hostel";
            swal('','Choose hostel','');
         }else{
           // alert('filled');
       alert($(this).serialize()+'&receivable_total_balance=' + JSON.stringify(receivable_total_balance));
        // return;
        $.ajax({
            beforeSend: function () {
                  $('#admit_student').prop("disabled", true);
                 // $('#feedback').append('<div class="alert alert-primary alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button><i class="fa fa-spinner fa-spin"></i>Preparing Control Number Please wait..</div>');
            },
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/StaffController/save_boarding_details'; ?>',
            data: $(this).serialize()+'&receivable_total_balance=' + JSON.stringify(receivable_total_balance),
            success:function(res){
                var data = JSON.parse(res);
                if(res ==0){
                  $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Student added to boarding succesfuly</strong> .<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#admit_student').prop("disabled", false);
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Student added to boarding succesfuly</strong> .<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                     setTimeout(function(){
                        window.location.reload();
                    },1000)
                }
            },
            error:function(res){
                $('#admit_student').prop("disabled", false);
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> .<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                setTimeout(function(){
            window.location.reload();
        },1000)
            }
        });

        e.preventDefault();
    }
    });
    //////////////////////////////////////////////////////////////////////


   
function monthly_items(id){
    $('#itemsbdy').empty();
    totalsum=0;
     var type= $("input[type='radio'][name='admit']:checked").val();
        //var data =  $(this).val();
        // alert(data);
      //   if(this.value == 3){
      //       if($( "#croom" ).val()==""){
      //            document.getElementById("day").checked = true;
      //           document.getElementById("no").checked = true;
      //  document.getElementById("filLert").innerHTML = "Choose Class"; 
      // }else{
         
         var data = 'class_id=' + <?=$adm->class_id?> +'&admfor='+type+'&qty='+id;
        //alert(data);
        var amount_ttl = 0; 
        var hostel_items = "";
        var accounts = 0;
        $.ajax({
            type: 'GET',
            data: data,
            //url: 'fetch_hostelItems_data', 
            url: '<?php echo base_url() . '/index.php/AdmissionController/get_hostel_chargedItemsbod'; ?>',
            success:function(res){
                 // 
                var hostel_data = JSON.parse(res);
                var len = hostel_data.length;
                for(var i = 0; i < len; i++){
                    hold_selected_items.push(hostel_data[i]['item_id']);
                  
                  var iid=hostel_data[i]['item_id'];
                    var qty = hostel_data[i]['quantity'];
                    var price = hostel_data[i]['price'];
                    var ttl = qty * price;

                    amount_ttl = amount_ttl + ttl;
                    account = hostel_data[i]['accounts'];

                    $('#total').val(ttl);
                     //alert(ttl);

                    $('#itemsbdy').append('<tr id="row_'+ hostel_data[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+hostel_data[i]['item_id']+'">'+hostel_data[i]['item_id']+'</td>\
                        <td>'+hostel_data[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+hostel_data[i]['item_id']+'" value="'+qty+'">'+1+'</td>\
                        <td>\
                        <a class="cost2" id="cost' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getid(' +iid+ ','+price+')"><input type="text" value="'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" id="prc'+iid+'" readonly></a>\
                        </td>\
                        <td><input type="hidden" name="prco'+iid+'" id="prco'+iid+'" value="'+price+'"></td>\
                        <td class="text-right" style="text-align:right" id="total'+hostel_data[i]['item_id']+'">'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td>\
                           <a href="javascript:RemoveRow('+hostel_data[i]['item_id']+','+ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                    
                
                hostel_items = {iid:iid,qty:qty, price:price, account_receivable: accounts, amount: ttl};
                receivable_total_balance.push(hostel_items);
            }
                // console.log(receivable_total_balance);
                  totalsum=totalsum+amount_ttl;
           
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });
        //$('#hostelDtls').show();
    //    }
       
    // }else if (this.value == 0){
    //       $(function() {
    //     $( "#clevel" ).change();
    //     totalsum=0;
    //     document.getElementById("filLert").innerHTML = "Choose class again";
    //    console.log(totalsum);
    //         return totalsum;
    // });
    //         $('#hostelDtls').hide();
    //     }
    };

$('input[type=radio][name=admit]').change(function(){
 
        $('#itemsbdy').empty();
         document.getElementById("totalsum").innerHTML = "Total = 0";
      });

      function tg_change(id,ttl) {
        totalsum=0;
          var name="item";
          var qty=1;
          //alert(ttl);
        
       /// alert(cashAmt);/////////////////////////////////////////
        for( var i = 0; i < hold_selected_items.length; i++){ 
           id1=hold_selected_items[i];
       var cashAmt =parseInt($('input[name=total'+id1+']').val());
        totalsum=totalsum+cashAmt;
        }       
        
        //totalsum=totalsum-ttl;
       // totalsum=totalsum+cashAmt;
             document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;       
         e.preventDefault();
    };
</script>