 <link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 
helper('age');
$studentModel = new App\Models\studentModel();
$ino = "";
$sid = $studentModel->get_max_id('students','student_id');
if (count($sid) > 0) {
    $stid = $sid[0]->max_id + 1;
    $ino = $stid;
} else {
    $ino =  1;
}

?>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script> -->

<!--  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />-->
<style type="text/css"> 

    #results { padding:5px; border:1px solid; background:#ccc; }

</style>

<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Students</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Students</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Student-all">Students List</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Student-add">New Student</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#import_excel">Import Excel</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Student-all">Students List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Student-add">New Student</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
       <?php if(session()->getFlashdata('resp')){ ?>
        <?= session()->getFlashdata('resp'); ?>
    <?php }?>
    <div class="tab-content">
        <div class="tab-pane active" id="Student-all">
      <!-------filter selection here------------>
  <div class="d-flex justify-content-center">
        <form id="students_form" class="form-inline">
                    
        <div class="me-3">
                Initial Class:  
          <select id="initial" name="initial" class="form-select form-control form-control-sm" required="">
            <option value="0">All</option>
            <option value="-1">Unassigned</option>
            <?php 
             $classes = $studentModel->gettable_data('classes_tbl', $where = array('status' => 1));
             if(count($classes)>0){
             foreach($classes as $cl){
            
             ?>
          <option value="<?php echo $cl->id;?>" ><?php echo $cl->class_name;?></option>
            <?php }}?>
        </select>
                </div>
                 <div class="me-3">
                           status:  
                    <select id="status" name="status" class="form-select form-control">
                        <option value="0">All</option>
                        <option value="1">Pending</option>
                        <option value="2" selected>Admitted</option>
                        <option value="4">Graduates</option>
                        <option value="3">Transfered</option>
                        <option value="5">Absconded</option>
                     
                    </select>
                </div>
                    <button type="submit" class="btn btn-primary">Create</button>
                    
                     <div class="input-group ms-3">
                 <input type="text" class="form-control" name="payer_name" id="search_name"   placeholder="Search Student Name" aria-label="Student Name" aria-describedby="button-st">
              
                <button class="btn btn-outline-primary" type="button" id="button-st" onclick="searchnamebtn()"><i class="fa fa-search" aria-hidden="true"></i></button>
            </div>
                        </form>
                        </div>
                        <hr>
                &nbsp; 
                     <center>
                    <div id="student_results" class="mt-4"></div>
                </center> 
      <!---------------ended here------------------>
    </div>
<div class="tab-pane" id="Student-add">
<div id="RegFedbck"></div>

<section class="wizard-section">
<div class="row no-gutters clearfix">
<div class="col-lg-12 col-md-12 col-sm-12">
<div class="card">
<div class="card-header"  style="height:5px">
<h3 class="card-title">Student Registration</h3>
<div class="card-options ">
    <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
</div>
</div>
<hr>


<div class="card-body">
<div class="form-wizard">
    <fieldset class="wizard-fieldset show">
        <form  method="post" id="savestudent" enctype="multipart/form-data">
            <div class="row">
                <div class="row mb-4">
                    <div class="col-sm-2"></div>
                    <label for="psearch" class="col-sm-2 col-form-label col-form-label-sm">Search Application</label>
                    <div class="col-sm-5">
                        <input type="search" class="form-control form-control-sm" id="appID" name="appID" placeholder="Search Application Number">
                    </div>
                    <button class="btn btn-primary col-sm-1" type="button" onclick="search_student()">Search</button>
                </div>
                <div class="col-md-6">
                    <div class="row mb-3">
                        <label for="fname" class="col-sm-4 col-form-label col-form-label-sm">First Name<span class="text-danger">*</span></label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm" id="fname" name="firstname" placeholder="First Name" required="">
                            <div class="wizard-form-error"></div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="mname" class="col-sm-4 col-form-label col-form-label-sm">Middle Name<span class="text-danger">*</span></label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm" id="mname" name="mname" placeholder="Middle Name" required="">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="lname" class="col-sm-4 col-form-label col-form-label-sm">Last Name<span class="text-danger">*</span></label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm" id="lname" name="lname" placeholder="Last Name" required="">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="dob" class="col-sm-4 col-form-label col-form-label-sm">Date of Birth<span class="text-danger">*</span></label>
                        <div class="col-sm-6">
                            <!-- <input type="date" class="form-control form-control-sm" id="datePickerId" name="dob" placeholder="Date of Birth" min="2007-12-31"> -->
                            <input type='text' class="form-control form-control-sm"  name="dob" id='datetimepicker1' placeholder="2018-07-24"  min="1980-12-31"/>
                        </div>
                    </div>
                    <fieldset class="row mb-3">
                        <legend class="col-sm-4 col-form-label col-form-label-sm">Gender<span class="text-danger">*</span></legend>
                        <div class="col-sm-6">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" id="male" value="Male">
                                <label class="form-check-label" for="male">
                                    Male
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" id="female" value="Female">
                                <label class="form-check-label" for="female">
                                    Female
                                </label>
                            </div>
                        </div>
                    </fieldset>
                    <div class="row mb-3">
                        <label for="ntlity" class="col-sm-4 col-form-label col-form-label-sm">Nationality<span class="text-danger">*</span></label>
                        <div class="col-sm-6">
                            <input list="nationality" name="nationalty" id="nationalty" class="form-control form-control-sm" required="">
                            <datalist id="nationality">
                                <?php
                                foreach($nationalities as $natn){
                                  echo '<option data-value='.$natn->id.' value='.$natn->nation.'>';
                              }
                              ?>
                          </datalist>
                      </div>
                  </div>
              </div>
              <div class="col-md-6">
                <div class="row mb-3">
                    <legend class="col-sm-4  col-form-label col-form-label-sm">Profile Photo</legend>
                    <div class="col-sm-7">
                        <div id="browser"><img src="" class="p-photo  mb-2 img-thumbnail" alt="" style="width:80px; height:100px;border: 1px wheat solid">
                            <input type="file"   name="imgFile" id="imgFile" style="float:left;">
                            <button type="button" id="capture-btn" style="float: right;" class="btn-secondary btn-sm">Capture</button>
                        </div>
                        <div id="results" style="display:none; width: 100px;height: 100px;" class=" mb-2"></div>


                    </div>
                    <!------capture image start here------------>
                    <!-- <div style="display:none" id="capture" class="col-sm-5">
                      <div class="container">
                    <form method="POST" action="storeImage.php"> 

                            <div class="row">

                                <div class="col-md-6" id="camera">

                                    <div id="my_camera"></div>

                                    <br/>
                                    <table>
                                        <tr><td>
                                <input type=button value="Take Snapshot" class="btn btn-primary" onClick="take_snapshot()">
                            </td><td style="padding-left: 30px;">
                              <input type=button value="close" class="btn btn-warning" onClick="close_snapshot()">

                              <input type="hidden" name="image" class="image-tag">
                          </td>
                      </tr>
                  </table>
              </div>

              <div class="col-md-12">
              </div>

              <div class="col-md-5 text-center">

                <br/>

             <button class="btn btn-success">Submit</button> --

            </div>

        </div> -->

 <!--    </form>
 --
</div>  
</div>
------capture image end here------------>

</div>
<div class="row mb-3">
    <label for="religion" class="col-sm-4 col-form-label col-form-label-sm">Religion<span class="text-danger">*</span></label>
    <div class="col-sm-6">
        <select id="religion" name="religion" class="form-select form-control form-control-sm" required="">
            <?php 
            $db=session()->get('db_id');
            if($db==4){
             ?>
          <option value="Catholic" selected>Catholic</option>
            <?php }else{ ?>
            <option value="">Choose</option>
            <option value="Christianity">Christianity</option>
            <option value="Islam">Islam</option>
            <option value="Hinduism">Hinduism</option>
            <option value="Buddhism">Buddhism</option>
            <option value="Others">Others</option>
            <?php }?>
        </select>
    </div>
</div>
<div class="row mb-3">
    <label for="gnno" class="col-sm-4 col-form-label col-form-label-sm">Government No</label>
    <div class="col-sm-6">
        <input type="text" class="form-control form-control-sm" id="gnno" name="gnno" placeholder="Government No">
    </div>
</div>
<!--///////////////////////////////////////////////////////////////////-->
<div class="row mb-3">
    <label for="regid" class="col-sm-4 col-form-label col-form-label-sm">Student Id<span class="text-danger">*</span></label>
    <div class="col-sm-6">
        <input type="text" class="form-control form-control-sm" value="<?php echo $ino; ?>" id="regid" name="regid" placeholder="Student Id" required="">
    </div>
</div>

<div class="row mb-3">
    <label for="religion" class="col-sm-4 col-form-label col-form-label-sm">Initial Class<span class="text-danger">*</span></label>
    <div class="col-sm-6">
        <select id="iclass" name="iclass" class="form-select form-control form-control-sm" required="">
            <option value="" reruired="required">-select-</option>
            <?php 
             $classes = $studentModel->gettable_data('classes_tbl', $where = array('status' => 1));
             if(count($classes)>0){
             foreach($classes as $cl){
            
             ?>
          <option value="<?php echo $cl->id;?>" ><?php echo $cl->class_name;?></option>
            <?php }}?>
        </select>
    </div>
</div>
<!--///////////////////////////////////////////////////////////////////-->

</div>
<div class="row mb-12">
    <div class="col-sm-4"></div>
    <div class="col-sm-2 offset-sm-6">
       <button class="btn btn-primary" type="submit" id="register_student"><i class="fa fa-save"></i> Register</button>

   </div>
   <span style="display:none;">
    <a href="javascript:;" class="nav-link form-wizard-next-btn" id="nextbtn"></a>
</span>
</div>
</div>

</form>
</fieldset> 
<fieldset class="wizard-fieldset">
     <div class="row">
        <div class="row mb-4">
            <label for="parentsearch" class="col-sm-2 col-form-label col-form-label-sm">Search Parent</label>
            <div class="col-sm-5">
                <input type="search" class="form-control form-control-sm" id="parentID" name="parentID" placeholder="Search Parent Here">
                <input type="hidden" class="form-control" id="studentid" name="studentid"  >
            </div>
            <button class="btn btn-primary col-sm-1" type="button" onclick="search_parent()">Search</button>
            <div class="col-sm-4">
                <button class="btn btn-primary" type="button" onclick="add_newParent()"><i class="fa fa-plus"></i> Add New Parent</button>
            </div>
            <hr class="mt-2">
        </div>
        <div class="row mb-4">
            <div class="col-sm-12">
                 <div id="Parents_loaded"></div>
                 <div id="NewParents"></div>
            </div>
        </div>
    </div>
    <div class="row mt-5">
        <div id="errorshow_parent"></div>
        <div class="card mb-5">
            <div class="card-body">
                <table class="table table-hover table striped">
                    <thead>
                        <tr>
                            <th>No#</th>
                            <th>Name</th>
                            <th>Relation</th>
                            <th>Phone No</th>
                            <th>Email</th>
                            <th>Occupation</th>
                            <th>Address</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="show_parent"></tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="form-group clearfix">
        <a href="javascript:;" class="nav-link form-wizard-back-btn float-left">Back</a>
    </div>
    <div class="form-group clearfix">
        <a href="javascript:;" class="nav-link form-wizard-next-btn float-right">Next</a>
    </div>
</fieldset> 
<fieldset class="wizard-fieldset">
    <form id="previous_school_form">
        <div class="row">
            <h5>Previously Schools Attended</h5>
            <div class="col-md-6">
                <div class="row mb-3">
                    <label for="scname" class="col-sm-4 col-form-label col-form-label-sm">School Name</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control form-control-sm" id="scname" name = "scname" placeholder="School Name" required="">
                        <input type="hidden" class="form-control form-control-sm" id="pcid" name ="PcId" >
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row mb-3">
                    <label for="scyr" class="col-sm-4 col-form-label col-form-label-sm">Year Attended</label>
                    <div class="col-sm-6">
                        <input type="text" min="1900" max="" step="1" value="2016" class="form-control form-control-sm" id="scyr" name = "scyr" placeholder="Year Attended" required="">
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-end mt-2 mb-3">
                <button type="submit" id="pschoolbtn" class="btn btn-primary"><i class="fa fa-plus me-2" ></i>Add</button>
                <button type="button" class="btn btn-primary" onclick="update_school()" id="Updateschool"><i class="fa fa-edit" ></i> Update</button>
            </div>
        </div>     
    </form>
    <div class="row">
        <div class="card mb-5">
            <div class="card-body">
                <div id="errorprevious_school"></div>
                <table class="table table-hover table striped">
                    <thead>
                        <tr>
                            <th>No#</th>
                            <th>School Name</th>
                            <th>Year Attended</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="previous_school">

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="form-group clearfix">
        <a href="javascript:;" class="nav-link form-wizard-next-btn float-right">Next</a>
    </div>
</fieldset> 
<fieldset class="wizard-fieldset">
    <form id="bill_info" >
        <h5>Billing Information</h5>
        <div class="row mb-3" align="center">

            <label class="col-sm-4 col-form-label col-form-label-sm">Select Bill Payer</label>

            <div class="col-sm-6">

                <select name="payer" id="payer" class="form-control" onchange="payerInformation(this.value)" >

                    <option selected>--Choose--</option>

                    <option value="1">Mother</option>

                    <option value="2">Father</option>

                    <option value="3">Guardian</option>

                </select>

            </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="row mb-3">
                        <label for="bname" class="col-sm-4 col-form-label col-form-label-sm">First Name</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm" id="bname" placeholder="First Name" name="pname" required="">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="blname" class="col-sm-4 col-form-label col-form-label-sm">Last Name</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm" id="blname" placeholder="Last Name" name="plname" required="">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="bemail" class="col-sm-4 col-form-label col-form-label-sm">Email</label>
                        <div class="col-sm-6">
                            <input type="email" class="form-control form-control-sm" id="bemail" name="email" placeholder="eg: example@gmail.com" required="">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row mb-3">
                        <label for="baddrs" class="col-sm-4 col-form-label col-form-label-sm">Postal Address</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm" id="baddrs" name="baddrs" name="paddrs" placeholder="Postal Address" required="">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="bpaddrs" class="col-sm-4 col-form-label col-form-label-sm">Physical Address</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm" id="bpaddrs" placeholder="Physical Address" name="paddrs" required="">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="bphone1" class="col-sm-4 col-form-label col-form-label-sm">Phone Number</label>
                        <div class="col-sm-6">
                            <input type="tel" class="form-control form-control-sm" id="bphone1" placeholder="Phone Number" name="phone1" required="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group clearfix">
                <a href="javascript:;" class="nav-link form-wizard-submit float-right" onclick="save_bill_info()" id="billbtn">Submit</a>
            </div>
        </form>
    </fieldset> 


</div>
</div>
</div>
</div>
</div>
</section>
</div>

<div class="tab-pane" id="import_excel">
<div class="card">
<div class="card-header"  style="height:5px">
<h3 class="card-title">Import Student information Excel File</h3>
<div class="card-options ">
    <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
</div>
</div>
<hr>


<div class="card-body">
    <div class="row">
<div class="col-md-6">
<input type="file" id="excelFile" class="form-control" onchange="validateFile(this)">
</div>
<div class="col-md-4">
<button onclick="startUpload()" class="btn btn-primary">Import</button>
</div>
</div>

<div id="progressWrapper">
    <div id="progressBar">0%</div>
</div>

<div id="importMessage"></div>
<div id="result"></div>

</div>
</div>
</div>

</div>
</div>
</div>
<div class="modal fade" id="EditStudent" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel"><center>Edit Student Details</center></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="EditStudent_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save</button>-->
    </div>
</div>
</div>
</div>
<style type="text/css">
        #progressBar {
            width: 0%;
            height: 25px;
            background: green;
            color: white;
            text-align: center;
        }
        #progressWrapper {
            width: 100%;
            background: #ddd;
            margin-top: 10px;
        }
    </style>

<!-- View Modal -->
<div id="myModalview" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">

      <!-- Modal content-->
      <div class="modal-content" style="width:130%">
        <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="staticBackdropLabel" style="">STUDENT DETAILS REPORT</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
              <div id="showLedger"></div>
          </div>
          <div class="modal-footer">
              <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
          </div>
      </div>
      
  </div>
</div>

<script>
     $('#students_form').submit(function (e) {
           
            $('#student_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = $('#students_form').serialize();
           //alert(dta);
           // return;
            $.ajax({
                type: "POST",
               url: "<?php echo base_url() . '/index.php/StudentController/fetch_students'; ?>",
                data: dta,
                success: function (res) {
                    $('#student_results').html(res);
                },
                error: function () {
                    $('#student_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });

     //                        });
    // datePickerId.max = new Date().toISOString().split("T")[0];
    $(function () {
        var year = (new Date).getFullYear();
        var day = (new Date).getDate();
        var m = (new Date).getMonth();
        $('#datetimepicker1').datetimepicker({
            // format: 'Y/m/d',
            format:"YYYY-MM-DD",
            minDate: new Date(1950, 0, 1),
            maxDate: new Date(year, m, day)
        });
    });

    $('#Updateparent').hide();
    $('#Updateschool').hide();
    jQuery(document).ready(function() {
    // click on next button
       jQuery('.form-wizard-next-btn').click(function() {
          var parentFieldset = jQuery(this).parents('.wizard-fieldset');
          var currentActiveStep = jQuery(this).parents('.form-wizard').find('.form-wizard-steps .active');
          var next = jQuery(this);
          var nextWizardStep = true;
          parentFieldset.find('.wizard-required').each(function(){
             var thisValue = jQuery(this).val();

             if( thisValue == "") {
                jQuery(this).siblings(".wizard-form-error").slideDown();
                nextWizardStep = false;
            }
            else {
                jQuery(this).siblings(".wizard-form-error").slideUp();
            }
        });
          if( nextWizardStep) {
             next.parents('.wizard-fieldset').removeClass("show","400");
             currentActiveStep.removeClass('active').addClass('activated').next().addClass('active',"400");
             next.parents('.wizard-fieldset').next('.wizard-fieldset').addClass("show","400");
             jQuery(document).find('.wizard-fieldset').each(function(){
                if(jQuery(this).hasClass('show')){
                   var formAtrr = jQuery(this).attr('data-tab-content');
                   jQuery(document).find('.form-wizard-steps .form-wizard-step-item').each(function(){
                      if(jQuery(this).attr('data-attr') == formAtrr){
                         jQuery(this).addClass('active');
                         var innerWidth = jQuery(this).innerWidth();
                         var position = jQuery(this).position();
                         jQuery(document).find('.form-wizard-step-move').css({"left": position.left, "width": innerWidth});
                     }else{
                         jQuery(this).removeClass('active');
                     }
                 });
               }
           });
         }
     });
    //click on previous button
       jQuery('.form-wizard-previous-btn').click(function() {
          var counter = parseInt(jQuery(".wizard-counter").text());;
          var prev =jQuery(this);
          var currentActiveStep = jQuery(this).parents('.form-wizard').find('.form-wizard-steps .active');
          prev.parents('.wizard-fieldset').removeClass("show","400");
          prev.parents('.wizard-fieldset').prev('.wizard-fieldset').addClass("show","400");
          currentActiveStep.removeClass('active').prev().removeClass('activated').addClass('active',"400");
          jQuery(document).find('.wizard-fieldset').each(function(){
             if(jQuery(this).hasClass('show')){
                var formAtrr = jQuery(this).attr('data-tab-content');
                jQuery(document).find('.form-wizard-steps .form-wizard-step-item').each(function(){
                   if(jQuery(this).attr('data-attr') == formAtrr){
                      jQuery(this).addClass('active');
                      var innerWidth = jQuery(this).innerWidth();
                      var position = jQuery(this).position();
                      jQuery(document).find('.form-wizard-step-move').css({"left": position.left, "width": innerWidth});
                  }else{
                      jQuery(this).removeClass('active');
                  }
              });
            }
        });
      });
    //click on form submit button
       jQuery(document).on("click",".form-wizard .form-wizard-submit" , function(){
          var parentFieldset = jQuery(this).parents('.wizard-fieldset');
          var currentActiveStep = jQuery(this).parents('.form-wizard').find('.form-wizard-steps .active');
          parentFieldset.find('.wizard-required').each(function() {
             var thisValue = jQuery(this).val();
             if( thisValue == "" ) {
                jQuery(this).siblings(".wizard-form-error").slideDown();
            }
            else {
                jQuery(this).siblings(".wizard-form-error").slideUp();
            }
        });
      });
    // focus on input field check empty or not
       jQuery(".form-control").on('focus', function(){
          var tmpThis = jQuery(this).val();
          if(tmpThis == '' ) {
             jQuery(this).parent().addClass("focus-input");
         }
         else if(tmpThis !='' ){
             jQuery(this).parent().addClass("focus-input");
         }
     }).on('blur', function(){
      var tmpThis = jQuery(this).val();
      if(tmpThis == '' ) {
         jQuery(this).parent().removeClass("focus-input");
         jQuery(this).siblings('.wizard-form-error').slideDown("3000");
     }
     else if(tmpThis !='' ){
         jQuery(this).parent().addClass("focus-input");
         jQuery(this).siblings('.wizard-form-error').slideUp("3000");
     }
 });
 });
 $('#savestudent').submit(function (e) {
      $('#register_student').prop("disabled", true);
    $('#studentid').val('');
    var form_data = new FormData(this);
    $.ajax({
        beforeSend: function () {
          $('#register_student').prop("disabled", true);
          $('#RegFedbck').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
      },
      url: 'save_student',
      type: 'POST',
      data: form_data,
      success: function (res) {
        var data = JSON.parse(res);
        if(data['status'] == "0"){
            $('#savestudent')[0].reset();
            $('#studentid').val(data['student']);
            $('#nextbtn').click();
            $('#RegFedbck').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
        }else{
            swal('warning','Student Arleady added','');
           
           $('#RegFedbck').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
       }
   },
   contentType: false,
   cache: false,
   processData: false,       
   error: function () {
       
       $('#RegFedbck').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');;
   }
});
    e.preventDefault();
});

$('#previous_school_form').submit(function (e) {
    $.ajax({
        beforeSend: function () {
          $('#pschoolbtn').prop("disabled", true);
      },
      url: 'save_previous_school',
      type: 'POST',
      data:  $('#previous_school_form').serialize() + '&studentid='+ $('#studentid').val(),
      success: function (res) {
        $('#pschoolbtn').prop("disabled", false);
        var data = JSON.parse(res);
        if(data['status'] == "0"){
         $('#previous_school_form')[0].reset();
         $('#previous_school').load('previous_school/'+  $('#studentid').val());  
     }else{
         $('#RegFedbck').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
     }
 },       
 error: function () {
   $('#pschoolbtn').prop("disabled", false);
   $('#Errorprevious_school').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');;
}
});
    e.preventDefault();
});
/////////////////billing info ////////////////////////////////////////////////////////
function payerInformation(id){
    var data = "student=" +$("#studentid").val() + "&relation=" + id;
         //alert(data);
    $('input[name=pname]').val('');
    $('input[name=plname]').val('');
    $('input[name=email]').val('');
    $('input[name=baddrs]').val('');
    $('input[name=paddrs]').val('');
    $('input[name=phone1]').val('');

    $.ajax({
        type:'POST',
        url:'<?php echo base_url() . '/index.php/StudentController/load_payerInfo'; ?>',
        data: data,
        dataType: 'json',
        success: function(data){
                // var data = JSON.parse(res);
            console.log(data)


            $("#studentid").html(''); 
            $('input[name=pname]').val(data[0]['fname']);
            $('input[name=plname]').val(data[0]['lname']);
            $('input[name=email]').val(data[0]['email']);
            $('input[name=baddrs]').val(data[0]['address']);
            $('input[name=paddrs]').val(data[0]['paddress']);
            $('input[name=phone1]').val(data[0]['phone']);
        },
        error: function(){

        }
    });
}

function save_bill_info(){
   $.ajax({
    beforeSend: function () {
        $('#billbtn').prop("disabled", true);
        $('#RegFedbck').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
    },
    type: "POST",
    url: 'save_bill_info',
    data: $('#bill_info').serialize() +'&studentid='+ $('#studentid').val(),
    success: function (res) {
        $('#billbtn').prop("disabled", false);
        if(res == 1){
           location.reload();
       }else{
           $('#RegFedbck').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ res + '</div>');  
       }
    $('input[name=pname]').val('');
    $('input[name=plname]').val('');
    $('input[name=email]').val('');
    $('input[name=baddrs]').val('');
    $('input[name=paddrs]').val('');
    $('input[name=phone1]').val('');
   },
   error: function () {
    $('#billbtn').prop("disabled", false);
    $('#RegFedbck').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
}
});
    e.preventDefault();
}
function delete_item(id,pid,sid,tbl,divToUpdate){
 var data = 'id='+id +'&tbl='+ tbl+'&pid='+ pid+'&sid='+ sid;
 //alert(data);
 $.ajax({
    beforeSend: function () {
        $('#'+divToUpdate).html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
    },
    type: "POST",
    url: 'delete_item',
    data: data,
    success: function (res) {
       $('#'+divToUpdate).load(divToUpdate+'/'+pid+'/'+sid);
   },
   error: function () {
    $('#error'+divToUpdate ).html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
}
});
}
function delete_item1(id,tbl,divToUpdate){
 var data = 'id='+id +'&tbl='+ tbl;
 //alert(data);
 $.ajax({
    beforeSend: function () {
        $('#'+divToUpdate).html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
    },
    type: "POST",
    url: 'delete_item1',
    data: data,
    success: function (res) {
       $('#'+divToUpdate).load(divToUpdate+'/'+id);
   },
   error: function () {
    $('#error'+divToUpdate ).html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
}
});
}
function edit_student(id){

    $('#EditStudent').modal('show'); 
    $('#EditStudent_content').load('edit_student/'+id);

}
function edit_item(id,tbl){
    $('#NewParents').show();
 var data = 'id='+id +'&tbl='+ tbl;
 $.ajax({
    type: "POST",
    url: 'get_parent',
    data: data,
    success: function (result) {
     var data = JSON.parse(result);
     if(tbl == 'parents_tbl'){
       $('#submitparent').hide();
       $('#pname').val(data[0]['first_name']);
       $('#plname').val(data[0]['last_name']);
       $('select#rltn').val(data[0]['relation']);
       $('#addrs').val(data[0]['address']);
       $('#occp').val(data[0]['occupation']);
       $('#email').val(data[0]['email']);
       $('#phone1 ').val(data[0]['phone1']);
       $('#phone2 ').val(data[0]['phone2']);
       $('#parentId ').val(data[0]['id']);
       $('#Updateparent').show();
   }else{
      $('#pschoolbtn').hide();
      $('#scname').val(data[0]['school_name']);
      $('#scyr').val(data[0]['year_attended']);
      $('#pcid').val(data[0]['id']);
      $('#Updateschool').show();
  }
},
error: function () {
               // $('#error'+divToUpdate ).html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
}
});;
}
function update_parent_dts(){
    $.ajax({
        beforeSend: function () {
            $('#Updateparent').prop("disabled", true);
        },
        type: "POST",
        url: 'update_parent',
        data: $('#parent_dtls').serialize(),
        success: function (res) {
            $('#Updateparent').prop("disabled", false);
            var data = JSON.parse(res);
            if(data['status'] == "0"){
                $('#submitparent').show();
                $('#Updateparent').hide();
                $('#parent_dtls')[0].reset();
                $('#show_parent').load('show_parent1/'+$('#studentid').val()); 
            }
            else if(data['status'] == "1"){
              $('#errorshow_parent').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
          }             
      },
      error: function () {
        $('#Updateparent').prop("disabled", false);
        $('#errorshow_parent').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
    }
});  
}
function update_school(){
   $.ajax({
    beforeSend: function () {
      $('#Updateschool').prop("disabled", true);
      $('#Errorprevious_school').html('');
  },
  url: 'update_previous_school',
  type: 'POST',
  data:  $('#previous_school_form').serialize(),
  success: function (res) {
    $('#Updateschool').prop("disabled", false);
    var data = JSON.parse(res);
    if(data['status'] == "0"){
        $('#pschoolbtn').show();
        $('#Updateschool').hide();
        $('#previous_school_form')[0].reset();
        $('#previous_school').load('previous_school/'+$('#studentid').val());  
    }else{
     $('#Errorprevious_school').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
 }
},       
error: function () {
   $('#Updateschool').prop("disabled", false);
   $('#Errorprevious_school').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');;
}
});
}  
function search_student(){
  var mydat = 'appId='+ $('#appID').val();
      // alert(mydat);
      // return;
  $.ajax({
    type: "POST",
    url: '<?php echo base_url() . '/index.php/StudentController/search_application'; ?>',
    data: mydat,
    success: function (res) {
       var data = JSON.parse(res);
       console.log(data);
                 // return;   
       $('#fname').val(data[0]['first_name']);
       $('#mname').val(data[0]['middle_name']);
       $('#lname').val(data[0]['last_name']);
       $('input[name=dob]').val(data[0]['date_of_birth']);
       if(data[0]['gender']=='Female'){
         document.getElementById("female").setAttribute("checked","true");
     }else{
        document.getElementById("male").setAttribute("checked","true");
    }
},
error: function () {
               // $('#submitparent').prop("disabled", false);
               // $('#errorshow_parent').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
}
});

}
</script>
<script>
    
    

    Webcam.set({

        width: 490,

        height: 390,

        image_format: 'jpeg',

        jpeg_quality: 90

    });



    Webcam.attach( '#my_camera' );



    function take_snapshot() {

        Webcam.snap( function(data_uri) {

            $(".image-tag").val(data_uri);

            document.getElementById('results').innerHTML = '<img src="'+data_uri+'"/>';
            $('#results').show();
            $('#browser').hide();
        } );

    }
    $("#capture-btn").click(function () {
     $('#capture').show();

 });
    function close_snapshot(){
     $('#capture').hide(); 
 }
 function search_parent(){
    if($('#parentID').val() == ""){
            swal("warning","Please Enter Parent Name","warning");
        }else{
        $('#NewParents').hide();
        var data = 'parentData=' + $('#parentID').val() + '&student=' + $('#studentid').val();
        // alert(data);
        $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/index.php/StudentController/search_parentData'; ?>',
            data: data,
            success: function (res) {
                console.log(res);
                $('#Parents_loaded').show();
                $('#Parents_loaded').html(res);
            }
        });
    }
}

    function saveParentInfo(parentID,studentID){
        var datas = 'pID=' + parentID + '&student_id=' + studentID;
        // alert(data);
        // return;
         $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/index.php/StudentController/save_studentParent_details'; ?>',
            data: datas,
            success: function (res) {
                console.log(res);
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                   $('#selectParent').empty();
                   $('#show_parent').load('show_parent/'+  parentID+'/'+studentID); 
                }            
            },
            error: function () {
                $('#errorshow_parent').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');
            }
        });  
    }

    function add_newParent(){
         $('#Parents_loaded').hide(); 
        var data = 'student=' + $('#studentid').val();
        // alert(data);
        $.ajax({
            type: 'GET',
            url: '<?php echo base_url() . '/index.php/StudentController/new_ParentInfo'; ?>',
            data: data,
            success:function(res){
               $('#NewParents').show(); 
                $('#NewParents').html(res);
            }
        });
    }

 function searchnamebtn(){
            var name=$('#search_name').val();
          
            // alert(year);
            if(name.length >=3){
                $('#student_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
                var dta="name="+name;
           // toastr.success(name.length);
             $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/index.php/StudentController/fetch_student_byname'; ?>",
                data: dta,
                success: function (res) {
                    $('#student_results').html(res);
                },
                error: function () {
                    $('#student_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
        }else{
            if(name.length==0){
               $('#student_results').html(''); 
            }else{
               $('#student_results').html('<div class="alert alert-info">Search atleat 3 characters</div>'); 
            }
        
        }
        }
        
        function startUpload() {
    let file = document.getElementById('excelFile').files[0];
    if (!file) {
        alert("Please select a file.");
        return;
    }

 document.getElementById('result').innerHTML =
                `<p style='color:red;'>'<span class="fa fa-spinner fa-spin"></span> importing plese wait..'</p>`;
    let formData = new FormData();
    formData.append("excelFile", file);

    let xhr = new XMLHttpRequest();
    xhr.open("POST", "<?= base_url(). '/index.php/StudentController/import_students_excel' ?>", true);

    xhr.upload.onprogress = function (e) {
        if (e.lengthComputable) {
            let percent = Math.round((e.loaded / e.total) * 100);
            document.getElementById('progressBar').style.width = percent + "%";
            document.getElementById('progressBar').innerHTML = percent + "%";
        }
    };

    xhr.onload = function () {
        let response = JSON.parse(xhr.responseText);
         console.log(response);
        if (response.status === "success") {
            document.getElementById('result').innerHTML =
                `<p><b>Imported:</b> ${response.inserted} row(s)</p>
                <p><b>Duplicates:</b> ${response.duplicates} row(s)</p>`;
        } else {
            document.getElementById('result').innerHTML =
                `<p style='color:red;'>${response.statusDesc}</p>`;
        }

        document.getElementById('progressBar').style.background = "green";
    };

    xhr.send(formData);
}

function validateFile(input) {
    const file = input.files[0];
    const allowedExtensions = /(\.xls|\.xlsx)$/i;

    if (!allowedExtensions.exec(file.name)) {
      
        swal('error','Invalid file. Please upload an Excel file (.xls or .xlsx)','error')
        input.value = "";
        return false;
    }

    return true;
}

</script>
