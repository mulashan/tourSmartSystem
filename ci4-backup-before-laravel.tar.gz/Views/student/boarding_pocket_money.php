
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 
    helper('age');
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();
  $remodel = new App\Models\ReportsModel();

    $student = $smodel->gettable_data('students', $where = array('status' => 1));
    $admission = $smodel->gettable_data('admission_tbl', $where = array('status' => 1,'admission_type' => 0));
   
  $hostels = $smodel->get_item_name('hostel_tbl', $where = array('status' => 1));
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Pocket Money</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Student Pocket Money</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#adm-add"> Pocket Money List </a></li>
                <li class="nav-item"><a class="nav-link " data-toggle="tab" href="#Admsn-all">New Pocket Money</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#adm-add"> Pocket Money List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link " data-toggle="tab" href="#Admsn-all">New Pocket Money</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            
            <div class="tab-pane active" id="adm-add">
                <div class="card">
                   <div class="d-flex justify-content-center mt-3">
                    <form id="bodResult" class="form-inline">
                     <div class="me-3">
                             Academic year: 
                           <select id="yearb" name="yearb" class="form-select form-control">
                      <!-- JavaScript loop to generate year options -->
                      <script>
                        const cYear = new Date().getFullYear();
                        const sYear = 2023; // Change this to set a different start year
                        for (let year = cYear+1; year >= sYear; year--) {
                            if(year==cYear){
                            document.write(`<option value="${year}" selected>${year}</option>`);
                            }else{
                            document.write(`<option value="${year}">${year}</option>`);    
                            }
                        
                        }
                      </script>
                    </select>
                        </div>
                        
                        <div class="me-3">
                             Level: 
                            <select class="form-control form-select" name="level" id="level">
                                <option value="0">All</option>
                                <?php
                               $l = $remodel->get_levels();
                              foreach($l as $le){
                               echo '<option value="' . $le->id . '">' . $le->level_name . '</option>'; 
                              }

                               ?>
                            </select>
                        </div>

                         <div class="me-3">
                             Class: 
                            <select class="form-control form-select" name="classb" id="classb">
                                <option value="0">All</option>
                                <?php
                               $c = $remodel->get_classes1();
                              foreach($c as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->class_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                      
                         <div class="me-3">
                             Stream: 
                            <select class="form-control form-select" name="streamb" id="streamb">
                                <option value="0">All</option>
                                <?php
                               $s = $remodel->get_stream1();
                              foreach($s as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->stream_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                         <div class="me-3">
                             Hostel: 
                             <select class="form-control form-select" name="hostelb" id="hostelb">
                                <option value="0">All</option>
                              <?php
                              foreach($hostels as $h){
                               echo '<option value="' . $h->id . '">' . $h->hostel_name . '</option>'; 
                              }

                               ?>   
                             </select>

                         </div>

                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="ResultsForBoding"></div>
                </center>

                </div>
            </div>
            <div class="tab-pane" id="Admsn-all">
               <div class="card">
     <!--------------------------another code here----------------->
 <div class="content-wrapper mt-3">
    <section class="content">
        <div class="box box-danger">
           
            <div class="box-body">
          
                <div class="d-flex justify-content-center">
                    <form id="Rept1Result" class="form-inline">
                     <div class="me-3">
                             Academic year: 
                           <select id="year" name="year" class="form-select form-control">
                      <!-- JavaScript loop to generate year options -->
                      <script>
                        const currentYear = new Date().getFullYear();
                        const startYear = 2023; // Change this to set a different start year
                        for (let year = currentYear+1; year >= startYear; year--) {
                            if(year==currentYear){
                            document.write(`<option value="${year}" selected>${year}</option>`);
                            }else{
                            document.write(`<option value="${year}">${year}</option>`);    
                            }
                        
                        }
                      </script>
                    </select>
                        </div>
                        
                        <div class="me-3">
                             Level: 
                            <select class="form-control form-select" name="classlevel" id="classlevel">
                                <option value="0">All</option>
                                <?php
                               $l = $remodel->get_levels();
                              foreach($l as $le){
                               echo '<option value="' . $le->id . '">' . $le->level_name . '</option>'; 
                              }

                               ?>
                            </select>
                        </div>

                         <div class="me-3">
                             Class: 
                            <select class="form-control form-select" name="class" id="class">
                                <option value="0">All</option>
                                <?php
                               $c = $remodel->get_classes1();
                              foreach($c as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->class_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                      
                         <div class="me-3">
                             Stream: 
                            <select class="form-control form-select" name="stream" id="stream">
                                <option value="0">All</option>
                                <?php
                               $s = $remodel->get_stream1();
                              foreach($s as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->stream_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                         <div class="me-3">
                             Hostel: 
                             <select class="form-control form-select" name="hostel" id="hostel">
                                <option value="0">All</option>
                              <?php
                              foreach($hostels as $h){
                               echo '<option value="' . $h->id . '">' . $h->hostel_name . '</option>'; 
                              }

                               ?>   
                             </select>

                         </div>

                        <button type="submit" class="btn btn-primary">Load</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>
            <!--   <center>
 <button class="btn btn-primary btn-sm" onclick="printable('Rept1ResultViewResults')"><span class="fa fa-print"></span> Print</button>
</center> -->
            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
</div>
            </div>
            </div>

        </div>
    </div>
</div>


<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">


    $(document).ready(function () {
      $('#myTable2').DataTable();
         ShowTerms();
    });

    $(".AdmitID").click(function () {
        var data = 'id=' + $(this).attr('data-id');
        // alert (data);

        $('#myModal').modal('show');


        $.ajax({
            type: "GET",
            url: "boarding_details",
            data: data,
            beforSend: function()
            {
                $('#admission').html();
            },
            success: function(res){
                $('#admission').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });

    $("#closeAdmissionYearForm").submit(function(e) {
        var data = $(this).serialize();
        swal({
            title: "Are you sure?",
            text: "You are about to Close This Academic Year.",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, Close!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
        },
        function(isConfirm) {
            if (isConfirm) {
                $.ajax({
                    method: 'POST',
                    url: 'close_academic_year',
                    data: data,
                    error: function() {
                    alert('Something is wrong');
                    },
                    success: function(data) {
                        if(data == 1){
                            swal("Academic Year Closed!", "success");
                        }else{
                            alert('Something is wrong');
                        }    
                        setTimeout(function(){
                            window.location.reload();
                        },1000)
                    }
                });

            } else {
                swal("Cancelled");
            }
        });
        e.preventDefault();
    });

    function manage_admission(adm){
        $('#viewadmission').modal('show'); 
        $('#viewadmission_content').load('view_admissions/'+adm);
    }
 $("#classlevel").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#class").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });

        $("#class").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            //url: 'class_list',
             url: '<?php echo base_url() . '/index.php/StudentController/get_stream_details'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#stream").empty();
                $("#stream").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    $("#stream").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });
         $('#Rept1Result').submit(function (e) {
            
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "class=" + $('#class option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&year="+$('#year option:selected').val()+ "&hostel="+$('#hostel option:selected').val();
          //  alert(dta);
            //return;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/get_pocket_details'; ?>',
                 data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });

         $('#bodResult').submit(function (e) {
            
            $('#ResultsForBoding').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
          var dta = "class=" + $('#classb option:selected').val()+ "&classlevel="+$('#level option:selected').val()+ "&stream="+$('#streamb option:selected').val()+ "&year="+$('#yearb option:selected').val()+"&hostel="+$('#hostelb option:selected').val();
           // alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/get_pocket_money'; ?>',

                data: dta,
                success: function (res) {
                    $('#ResultsForBoding').html(res);
                },
                error: function () {
                    $('#ResultsForBoding').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
         $("#level").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#classb").empty();
                $("#classb").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#classb").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });

        $("#classb").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            //url: 'class_list',
             url: '<?php echo base_url() . '/index.php/StudentController/get_stream_details'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#streamb").empty();
                $("#streamb").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    $("#streamb").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });


   function ShowTerms(){
         var InputOption = '';
        var data = 'id=' + $('#level option:selected').val()+'&year='+$('#yearb option:selected').val();
        var year=$('#yearb option:selected').val();
        var cyear='<?php echo date('Y');?>';
        //alert(data);
        $.ajax({
            type:'POST',
            url: '<?php echo base_url() . '/index.php/SystemController/fetch_terms'; ?>',
            data: data,
            dataType: 'json',
            success:function(data){

                // console.log(data);
                // return;
                var len = data.length;
                $("#terms").empty();
                //$("#terms").append("<option value=''>-Choose-</option>");

                // $('#stream').html(data);

                for( var i = 0; i<len; i++){
                 var id = data[i]['id'];
                    var name = data[i]['name'];
                   
                     if(i == 0){
                        InputOption = "<option value='"+id+"' selected>"+name+"</option>";
                        $("#terms").append(InputOption);
                    }else if(year!=cyear){
                       InputOption = "<option value='"+id+"'>"+name+"</option>";
                   $("#terms").append(InputOption);
                   }
                    
                }
                // console.log(sum);

                
            }
        });
    }
</script>