<style type="text/css">
    .text-right {
    text-align: right !important;
}
</style>
<link rel="stylesheet" href="<?php// echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 
    helper('age');
      
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();
    $app_class = 0;
    $app_lvl="";
    $age = findAge($student_dtl[0]->birth_date);

    $level = $amodel->admisiion_details('class_level_tbl');
    $admission = $amodel->get_student_details('admission_tbl',$where = array('student_id' => $student_dtl[0]->id,'status' => 0));
    $appln = $amodel->get_student_details('students_application_tbl',$where = array('id' => $student_dtl[0]->id));
    $terms = $amodel->admisiion_details('school_terms_tbl');
    $hstl = $amodel->get_hostel_details($student_dtl[0]->gender,$age);
    $transport = $amodel->admisiion_details('route_tbl');

    if(count($appln) > 0){        
        $app_class = $appln[0]->class;
        $app_lvl = $appln[0]->class_lvl;
    }else{
        $app_class = "";
        $app_lvl = "";
    }
     if(count($studentparent)>0){
        $parent = $amodel->get_student_details('parents_tbl', $where = array('id' => $studentparent[0]->parent_id));
    }else{
        echo "Please fill parent informations";
    }
  $comeYear=$year+1;  
$date='01/08/'.$comeYear;
 $date=date("Y-m-d",strtotime($date));
 
 $strVl = $amodel->get_student_details('streams_tbl', $where = array('id' => $str));
?>

<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <!-- <div class="card"> -->
           <!--  <div class="card-header" style="height:5px">
                <h3 class="card-title">Admission Details</h3>
                <div class="card-options ">
                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                </div>
            </div>
            <hr> -->
            <!-- <div class="card-body"> -->
                <div class="row">
                        <div id="feedback"></div>
                    <div class="col-md-5">
                        <!-- <h6 class="card-title d-flex justify-content-center mb-2">Student Information</h6> -->
                        <div class="card">
                                <p Class=" d-flex justify-content-center mt-2">STUDENT DETAILS</p>
                            <center>
                                <?php 
                                    $source = "";
                                    if($student_dtl[0]->student_photo != ""){
                                      $source =  base_url('public/student_photos/'.$student_dtl[0]->student_photo);
                                    }
                                ?>
                                <img src="<?php echo $source; ?>" style="margin-top: 2em;width:80px; height:100px;border: 1px wheat solid">
                                <table class="table table-borderless mt-3">
                                    <tr>
                                        <th>Student Name:</th>
                                        <td><?= $student_dtl[0]->first_name.' '. $student_dtl[0]->middle_name.' '.$student_dtl[0]->last_name;?></td>
                                    </tr>
                                    <tr>
                                        <th>Date of Birth:</th>
                                        <td><?= $student_dtl[0]->birth_date;?></td>
                                    </tr>
                                    <tr>
                                        <th>Age:</th>
                                        <td><?= findAge($student_dtl[0]->birth_date); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Gender:</th>
                                        <td><?= $student_dtl[0]->gender;?></td>
                                    </tr>
                                    <tr>
                                        <th>Nationality:</th>
                                        <td><?= $student_dtl[0]->nationality;?></td>
                                    </tr>
                                    <tr>
                                        <th>Gurdian / Parent Name:</th>
                                        <td><?= $parent[0]->first_name??"".' '. $parent[0]->last_name??"";?></td>
                                    </tr>
                                    <tr>
                                        <th>Gurdian / Parent Phone:</th>
                                        <td><?= $parent[0]->phone1??"";?></td>
                                    </tr>
                                    <tr>
                                        <th>Address:</th>
                                        <td><?= $parent[0]->postal_address??"";?></td>
                                    </tr>
                                </table>
                            </center>
                        </div>
                        <div class="card mt-3">
                            <p Class=" d-flex justify-content-center mt-1">ADMISSION HISTORY</p>
                            <table class="table table-hover table-vcenter mb-0 text-nowrap">
                                <thead>
                                    <tr>
                                        <th>Adm. No:</th>
                                        <th>Adm. Date</th>
                                        <th>Class</th>
                                        <th>Stream</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if(count($admission) > 0){
                                    foreach ($admission as $adm): 
                                        $classdtl = $amodel->class_stream_details($adm->class_id,$adm->stream_id);
                                        ?>
                                        <tr>
                                            <td><?= $adm->id; ?></td>
                                            <td><?= $adm->admitted_date; ?></td>
                                            <td><?= $classdtl[0]->class_name; ?></td>
                                            <td><?= $classdtl[0]->stream_name; ?></td>
                                        </tr>
                                    <?php endforeach; }else{ ?>
                                        <tr>
                                            <td colspan="4" style="text-align:center;">No Admission Data Found</td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <form class="form-horizontal" id="admsionDtls">
                            <div class="card">
                         <p Class=" d-flex justify-content-center mt-2">ADMISSION DETAILS</p>
                            <input type="hidden" name="sid" value="<?= $student_dtl[0]->id;?>">
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label">Academic Year:</label>
                                <div class="col-md-3">
                                    <select class="form-control" name="acdy">
                                       <?php
                                      // $year = (int)date('Y');
                                       $y=$year+5;
                                       for ($year+1; $y>= $year; $year++): ?>
                                         <option value="<?php echo $year+1;?>"><?php echo $year+1;?></option>
                                       <?php endfor; ?>
                                    </select>
                                    <!-- <input type="number" min="1900" max="2099" step="1" value="2023"  name="acdy" id="datepicker" class="form-control"> -->
                                </div>
                                <?php 
                                    if(count($admission) == 0){
                                    
                                ?>
                                <label class="col-md-2 col-form-label">Admission Date:</label>
                                <div class="col-md-4">
                                    <!-- <input type="date"  name="djoin" id="datePickerId" class="form-control" min="2007-12-31"> -->
                                    <input type='date' class="form-control"  value="<?php echo $date;?>" name="djoin" id='' />
                                </div>
                            <?php } ?>
                            </div>
                            <!--------------------------------------------------->
                               <div class="form-group row">
                                <label class="col-md-3 col-form-label">Admission For:</label>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="admit" id="cont" value="0" required="required" checked="checked">
                                        <label class="form-check-label" for="Continous">
                                            Continous
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="admit" id="new" value="2" required="required">
                                        <label class="form-check-label" for="new">
                                            New Comer
                                        </label>
                                    </div>
                                </div>
                                
                                   <?php
                             $cls= $amodel->get_student_details('company_tbl', $where = array('classification' => 1));
                             if(count($cls)>0){
                                ?>
                                 <label for="inputpaidBy" class="col-md-2 col-form-label">Class Name</label>
                                   <div class="col-md-4">
                      <?php
                         $clss=$amodel->get_student_details('classification_tbl', $where = array('id >' => 0));
                          ?>
                        <select class="form-control" name="classification_id" id="classification_id">
                            <option value="0">-Choose-</option>
                            <?php foreach($clss as $type): ?>
                            <option value="<?= $type->id ?>"><?= $type->class_name; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php
                           }
                       ?>
                               
                                </div>
                            <!---------------------------------------------------->
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label">Class Level:</label>
                                <div class="col-md-5">
                                    <select id="clevel" name="clevel" class="form-select me-4 form-control form-control-sm" required>
                                        <option selected value="">Choose</option>
                                        <?php foreach ($level as $l): 
                                            $getRemainTotal = $amodel->remain_classLevel_capacity($l->id);
                                            if($getRemainTotal[0]->remainTotal != '' || $getRemainTotal[0]->remainTotal != NULL){
                                                $remain_capacity = '- '.$getRemainTotal[0]->remainTotal;
                                            }else{
                                                $remain_capacity = '- No';
                                            }
                                        ?>
                                            <option value="<?= $l->id;?>"<?php if($app_lvl == $l->id){  } ?>><?= $l->level_name.' '. $remain_capacity ;?></option>
                                        <?php endforeach ?>
                                    </select>
                                    <div id="filLv" style="color:red"></div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label">Class:</label>
                                <div class="col-md-3">
                                    <select id="croom" name="croom" class="form-select me-4 form-control form-control-sm">
                                        <option selected value="">Choose</option>
                                    </select>
                                <div id="ageLert" style="color:red"></div>
                                <div id="filLert" style="color:red"></div>
                                </div>
                                <label class="col-md-3 col-form-label">Stream:</label>
                                <div class="col-md-3">
                                    <select id="stream" name="stream" class="form-select me-4 form-control form-control-sm checkLimit">
                                        <option selected value="">Choose</option>
                                    </select>
                                     <div id="fstrm" style="color:red"></div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label">Admission Type:</label>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="state" id="day" value="0" required="required" checked="checked">
                                        <label class="form-check-label" for="day">
                                            Day
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="state" id="board" value="3" required="required">
                                        <label class="form-check-label" for="board">
                                            Boarding
                                        </label>
                                    </div>
                                </div>
                              <!--   <label class="col-md-3 col-form-label">Transport:</label>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="transp" id="no" value="No" required="required" checked="checked">
                                        <label class="form-check-label" for="board">
                                            No
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="transp" id="yes" value="Yes" required="required">
                                        <label class="form-check-label" for="day">
                                            Yes
                                        </label>
                                    </div>
                                </div> -->
</div>
<div class="form-group row">
    <div class="col-md-6">
        <div class="card" id="hostelDtls" style="display:none;">
            <div class="form-group row">
                <p Class=" d-flex justify-content-center mt-1">HOSTEL DETAILS</p>
                <label  class="col-md-4 col-form-label">Select Hostel</label>
                <div class="col-md-7">
                    <select id="hstl" name="hstl" class="form-select me-4 form-control form-control-sm checkLimit" onchange="hostelItems(this)">
                        <!--<option selected value="">Choose</option>-->
                        <?php 
                            foreach ($hstl as $h):
                            $remainingBalnc = $amodel->hostel_remaining_capacity($h->id);
                            if($remainingBalnc[0]->remaining_capacity != '' || $remainingBalnc[0]->remaining_capacity != NULL){
                                $remain_capacity = '- '.$remainingBalnc[0]->remaining_capacity;
                            }else{
                                $remain_capacity = '- ';
                            }
                         ?>
                            <option value="<?= $h->id;?>"><?= $h->hostel_name .' '.$remain_capacity;?></option>
                        <?php endforeach ?>
                    </select>
                     <!--<div id="hostelf" style="color:red"><span>Choose hostel</span></div>-->
                </div>
            </div>
       
        </div>
    </div>
   <!--  <div class="col-md-6">
        <div class="card" id="trnspDtls" style="display:none;">
            <div class="form-group row">
                <p Class=" d-flex justify-content-center mt-1">TRANSPORT DETAILS</p>
                <label  class="col-md-4 col-form-label">Select Route</label>
                <div class="col-md-7">
                    <select id="trans" name="trans" class="form-select me-4 form-control form-control-sm checkLimit" onchange="TransportItems(this)">
                        <option selected>Choose</option>
                        <?php 
                            foreach ($transport as $t): 
                            $remainingBalnc = $amodel->Transprt_remaining_capacity($t->id);
                            if(count($remainingBalnc) > 0){
                                if($remainingBalnc[0]->remaining_Vehiclecapacity != '' || $remainingBalnc[0]->remaining_Vehiclecapacity != NULL){
                                    $remain_capacity = '- '.$remainingBalnc[0]->remaining_Vehiclecapacity;
                                }else{
                                    $remain_capacity = '- ';
                                }
                            }
                        ?>
                            <option value="<?= $t->id;?>"><?= $t->route_name .' '.$remain_capacity;?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
        </div>
    </div> -->
    </div>
         <!------------------------------------------------------------------>

            <div class="form-group row" style="display:none;" id="hostel_show">
                                 <label class="col-md-2 col-form-label">End Date:</label>
                                <div class="col-md-3">
                                     <input type='date' class="form-control"  value="<?php echo date('Y-m-d')?>" name="end" id='end' />
                                <div id="ageLert" style="color:red"></div>
                                <div id="filLert" style="color:red"></div>
                                </div>
                               
                                 
                            </div>
                            <!--  <div class="form-group row" id="end_date" style="display:none;">
                                <label class="col-md-2 col-form-label" style="">End Date:</label>
                                  <div class="col-md-3">
                                     <input type='date' class="form-control"  value="<?php echo date('Y-m-d')?>" name="end" id='end' />
                                
                                </div> 
                               
                            </div> -->
            <!------------------------------------------------------------------>
</div>
  
<div class="form-group row">
    <div class="col-md-12">
        <div class="card">
            <p Class=" d-flex justify-content-center mt-1">CHARGED ITEMS</p>
             <div class="form-group row">
                                <label class="col-md-2 col-form-label">Charged Items<span class="text-danger"></span><span class="text-danger"></span></label>
                                <div class="col-md-5">
                                    <select name="chargedItem" class="form-select form-control" id="chargedItem">
                                        <option class="">-search-</option>
                                     <!--    <?php
                                        //$charged=$amodel->getChargedItems();
                                        //foreach($charged as $ch){
                                    ?>
                                        <option value="<?php //echo $ch->id; ?>"><?php //echo $ch->item_name.' '.$ch->item_size.' '.number_format($ch->item_price).'/='; ?></option>
                                    <?php //}?> -->
                                    </select>
                                </div> 
                                <!-- <label class="col-md-2 col-form-label">Quantity<span class="text-danger"></span><span class="text-danger"></span></label> -->
                                <!-- <div class="col-md-2">
                                    <input type="number" name="qtyitem" min="1" class="form-control" id="numb">
                                </div> -->
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-primary" id="saveitem"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>
            <table class="table table-hover table-vcenter mb-0 text-nowrap" style="">
                <thead>
                    <tr>
                        
                        <th>No#</th>
                        <th>Item Name</th>
                        
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th></th>
                        <th class="text-center">Total</th>
                        <th></th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="itemsbdy" style="">
                          
                </tbody>

                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><div  class="cust_popup" id="cash" style="display: none">
                                    <h6>Change price</h6>
                                <div id="prcres"></div>
                                     
                               </div></td>
                    <td colspan="3" id="totalsum" style="font-size: 18px;"></td>
                </tr>
            </table>
        </div>
    </div>
</div>
                            <div class="form-group row">
                                <div class="col-md-12"> 
                                    <button type="submit" class="btn btn-primary float-right" id="admit_student">Admit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            <!-- </div> -->
        <!-- </div> -->
    </div>
</div>
<?php
if($cl==4){

}else{
  
?>
  <script type="text/javascript">
                                        
     $(function() {
        
           //$('#stream').val(clValue);
         
        // alert($('#croom').val());
       
      

        // alert(<?php  echo $lv; ?>);
      });
 </script>
 <?php
}
?>
<script src="<?php //echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script type="text/javascript">
         var selectedItem = [];
   $(document).ready(function(){
    var bod='<?php echo $bod; ?>';
    var forv='<?php echo $for; ?>';
     if(forv==0){
      document.getElementById("cont").checked = true;
    }else{
      document.getElementById("new").checked = true;
    }
     $('#clevel option[value="<?php echo $lv; ?>"]').prop('selected', true);
        // $('#croom option[value="<?php echo $cl; ?>"]').prop('selected', true);
         var select = document.getElementById('croom');
         var streamSelect = document.getElementById('stream');
         select.options[0].value=<?php echo $cl; ?>;
         streamSelect.options[0].value=<?php echo $str; ?>;
          showClasses(<?php echo $lv; ?>);
           ShowStream('<?php echo $cl; ?>',8);
           
    if(bod==0){
      document.getElementById("day").checked = true;
    }else{
      document.getElementById("board").checked = true;
     showBoardingItems();
     }
    
    $('#chargedItem').select2({
            ajax: {
                url: "<?= base_url('load_data'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

        $('#chargedItem').on('select2:select', function (e) {
            selectedItems();
        });
         
        function selectedItems(){ 
            var rows = '';
           var itemData = 'item_selected='+$('#chargedItem').val()+'&selected_items_array='+selectedItem;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Itemdata')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }  
           });  

        } 
    });
    $('#clevel').change(function(){
     totalsum=0;   
     console.log(totalsum);
      showClasses(1);
    return totalsum;

    });
$('#croom').change(function(){
        
     $('#clevel').change();
      ShowStream(1);
   
    });
   $('#saveitem').click(function(evt){
     //$('#itemsbdy').empty();
   // alert($(this).serialize());
        var data = 'itemid=' + $('#chargedItem').val();
        var account_ttl = 0; 
        var classlevel_items = "";
        var account = 0;
        
        var qty =1;
        var sn = 1;
   
  $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/ClassController/fetch_charged_item'; ?>',
            success: function(response){
                console.log(response);
                var lData = JSON.parse(response);
                var len = lData.length;

                for(var i = 0; i < len; i++){
                    var iid=lData[i]['item_id'];
                    var price = lData[i]['price'];
                    var ttl = qty * price;
                     account_ttl = account_ttl + ttl; 
                     account = 6;
                    // alert(lData[i]['item_group']);
                        if(lData[i]['item_group']==7){
                           $('#total').val(ttl);

                    $('#itemsbdy').append('<tr id="row_'+ lData[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+lData[i]['item_id']+'">'+lData[i]['item_id']+'</td>\
                        <td>'+lData[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+lData[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                         <td>\
                        <a class="cost2" id="cost' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getid(' +iid+ ','+price+')"><input type="text" value="'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" id="prc'+iid+'" readonly></a>\
                        </td>\
                        <td><input type="hidden" name="price'+iid+'" id="prco'+iid+'" value="'+ttl+'"></td>\
                        <td class="text-right" style="text-align:right" id="total'+iid+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td>\
                            <a href="javascript:RemoveRow('+lData[i]['item_id']+','+ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                        }else{
                    $('#total').val(ttl);

                    $('#itemsbdy').append('<tr id="row_'+ lData[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+lData[i]['item_id']+'">'+lData[i]['item_id']+'</td>\
                        <td>'+lData[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+lData[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                        <td>\
                         <a class="cost2" id="cost' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getid_popup(' +iid+ ','+price+')"><input type="text" name="price'+iid+'" value="'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" id="prc'+iid+'" readonly></a>\
                        </td>\
                          <td><input type="hidden" name="price'+iid+'" id="prco'+iid+'" value="'+price+'"></td>\
                       <td class="text-right" style="text-align:right" id="total'+iid+'">'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td>\
                            <a href="javascript:RemoveRow('+lData[i]['item_id']+','+ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
            }
                classlevel_items = {account_receivable: account, amount: account_ttl};
                receivable_total_balance.push(classlevel_items);

               totalsum=totalsum+account_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });

        evt.preventDefault();
   });

    /////////////////////////////////////////////////////////////////////
    var appclass;
    var totalsum=0;
    
    $(function () {
        $('#datetimepicker1').datetimepicker();
    });

    $(function() {
        $( "#datepicker" ).datepicker({dateFormat: 'yy'});
    });
    var receivable_total_balance = [];
    // $('#croom').load('load_classRooms');
   
  function showClasses(id){
         //document.getElementById("day").checked = true;
      //document.getElementById("no").checked = true;
        var InputOption = '';
        var data = 'level=' + $('#clevel').val();
        // alert(data);
         var clasVal= $('#croom').val();
        $.ajax({
            type:'POST',
            url:'load_classRooms',
            data:data,
            dataType:'json',
            success:function(res){
               
                var len = res.length;
                $("#croom").empty();
                $("#croom").append("<option value='' selected>-Choose-</option>");

                for( var i = 0; i<len; i++){
                     
                    var id = res[i]['id'];
                    var name = res[i]['cname'];
                    var total = res[i]['capcity'];
                    //if(total <= 0){
                        // InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Room for New Student'+"</option>";
                    //}else{
                        if(clasVal == id)
                        InputOption = "<option value='"+id+"' selected>"+name+"\xa0\xa0"+'-'+"\xa0"+total+"</option>";
                        else
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+'-'+"\xa0"+total+"</option>";    
                   // }
                    $("#croom").append(InputOption);

                   
                }
                 get_classlevel_chargedItems();
            }
        });
    };
  
    function changeStream(id){
       //var data =id.value; 
        if(id==''){
            document.getElementById("fstrm").innerHTML = "Choose stream"; 
        }else{
           document.getElementById("fstrm").innerHTML = "";  
        }
    }
    function hostelItems(id){
       //var data =id.value; 
        if(id==''){
            document.getElementById("hstlf").innerHTML = "Choose hostel"; 
        }else{
           document.getElementById("hostelf").innerHTML = "";  
           $('#hostel_show').show();
        }
    }
    function ShowStream(id,age){
          //$('#clevel').change();
        //  document.getElementById("fstrm").innerHTML = "Choose stream";
        var InputOption = '';
        var data = 'id=' + $('#croom').val();
        
        // alert(streamval);
        // return;
        // if(age < 5 ){
        //     $('#ageLert').html('Age is young to join class one');
        // }
        $.ajax({
            type:'POST',
            url:'getStreamdta',
            data: data,
            dataType: 'json',
            success:function(data){

                // console.log(data);
                // return;
                var len = data.length;
                $("#stream").empty();
                $("#stream").append("<option value=''>-Choose-</option>");

                // $('#stream').html(data);

                for( var i = 0; i<len; i++){
                 var id = data[i]['id'];
                    var name = data[i]['name'];
                    var stream = data[i]['stream'];
                    var comb = data[i]['comb'];
                    if(i == 0){
                         InputOption = "<option value='"+id+"' selected>"+name+" ("+comb+") "+"\xa0\xa0"+'-'+"\xa0"+stream+"</option>";
                    }else{
                        InputOption = "<option value='"+id+"'>"+name+" ("+comb+") "+"\xa0\xa0"+'-'+"\xa0"+stream+"</option>";
                    }
                    $("#stream").append(InputOption);
                }
                // console.log(sum);

                getClass_Charged_items();
            }
        });
    }

    function get_classlevel_chargedItems(){
         document.getElementById("filLv").innerHTML = "";
        $('#itemsbdy').empty();
             var type= $("input[type='radio'][name='admit']:checked").val();
        var data = 'levelID=' + $('#clevel').val()+'&admfor='+type;
        var account_ttl = 0; 
        var classlevel_items = "";
        var account = 0;
        $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/ClassController/fetch_classLevel_ItemData'; ?>',
            success: function(response){
                console.log(response);
                var lData = JSON.parse(response);
                var len = lData.length;

                for(var i = 0; i < len; i++){
                    var qty = lData[i]['quantity'];
                    var price = lData[i]['price'];
                    var iid=lData[i]['item_id'];
                    var ttl = qty * price;
                     account_ttl = account_ttl + ttl; 
                     account = lData[i]['account'];
                     
                    $('#total').val(ttl);
                  $('#itemsbdy').append('<tr id="row_'+ lData[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+lData[i]['item_id']+'">'+lData[i]['item_id']+'</td>\
                        <td>'+lData[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+lData[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                        <td>\
                         <a class="cost2" id="cost' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getid_popup(' +iid+ ','+price+')"><input type="text" name="price'+iid+'" value="'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" id="prc'+iid+'" readonly></a>\
                        </td>\
                          <td><input type="hidden" name="price'+iid+'" id="prco'+iid+'" value="'+ttl+'"></td>\
                       <td class="text-right" style="text-align:right" id="total'+iid+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td>\
                            <a href="javascript:RemoveRow('+lData[i]['item_id']+','+ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
                classlevel_items = {account_receivable: account, amount: account_ttl};
                receivable_total_balance.push(classlevel_items);

               totalsum=totalsum+account_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });
    }
    function getClass_Charged_items(){
        // $('#itemsbdy').empty();

        document.getElementById("filLert").innerHTML = ""; 
        var type= $("input[type='radio'][name='admit']:checked").val();
        //alert(type);
        var data = 'class_id=' + $('#croom').val() +'&admfor='+type;
        //alert(data);
        var account_ttl = 0; 
        var class_items = "";
        var account = 0;
        $.ajax({
            type: 'GET',
            data: data,
            url: 'fetch_clsItems_data',
            success:function(res){

                var class_data = JSON.parse(res);
                var len = class_data.length;
                for(var i = 0; i < len; i++){

                    // receivable_total_balance.push(class_data[i]['account']);
                    // alert(receivable_total_balance);
                    // return;
                    var iid=class_data[i]['item_id'];
                    var qty = class_data[i]['quantity'];
                    var price = class_data[i]['price'];
                    var ttl = qty * price;
                     account_ttl = account_ttl + ttl; 
                     account = class_data[i]['account'];

                    $('#total').val(ttl);


                    $('#itemsbdy').append('<tr id="row_'+ class_data[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+class_data[i]['item_id']+'">'+class_data[i]['item_id']+'</td>\
                        <td>'+class_data[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+class_data[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                      <td>\
                         <a class="cost2" id="cost' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getid_popup(' +iid+ ','+price+')"><input type="text" name="price'+iid+'" value="'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" id="prc'+iid+'" readonly></a>\
                        </td>\
                          <td><input type="hidden" name="price'+iid+'" id="prco'+iid+'" value="'+ttl+'"></td>\
                       <td class="text-right" style="text-align:right" id="total'+iid+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td>\
                            <a href="javascript:RemoveRow('+class_data[i]['item_id']+','+ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
                class_items = {account_receivable: account, amount: account_ttl};
                receivable_total_balance.push(class_items);
                // console.log(receivable_total_balance);

                  totalsum=totalsum+account_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });
    }
    
    function RemoveRow(item_id,account_ttl){
        if(item_id==64){
            account_ttl=$('#prco'+item_id+'').val();
         totalsum=totalsum+parseInt(account_ttl);
     }else{
         totalsum=totalsum-account_ttl;
     }
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
           // return totalsum;
         $('#row_'+item_id).remove();

              
    }

    

$('input[type=radio][name=admit]').change(function(){
   // document.getElementById("day").checked = true;
    document.getElementById("no").checked = true;
        var data =  $(this).val();
        $('#itemsbdy').empty();
         $(function() {
        $( "#clevel" ).change();
        totalsum=0;
        document.getElementById("filLert").innerHTML = "Choose class";
       console.log(totalsum);
            return totalsum;
    });
      if($( "#clevel" ).val()==""){
       document.getElementById("filLv").innerHTML = "Choose Level"; 
      }
        
    });

$('input[type=radio][name=state]').change(function(){
    
        var data =  $(this).val();
        // alert(data);
        if(this.value == 3){
            if($( "#croom" ).val()==""){
                 document.getElementById("day").checked = true;
                document.getElementById("no").checked = true;
       document.getElementById("filLert").innerHTML = "Choose Class"; 
      }else{
         showBoardingItems();
        
       }
       
    }else if (this.value == 0){
          $(function() {
        $( "#clevel" ).change();
        totalsum=0;
        document.getElementById("filLert").innerHTML = "Choose class again";
       console.log(totalsum);
            return totalsum;
    });
            $('#hostelDtls').hide();
        }
    });
function showBoardingItems(){
     var type= $("input[type='radio'][name='admit']:checked").val();
     var data = 'class_id=' + $('#croom').val() +'&admfor='+type;
      // alert(data);
        var amount_ttl = 0; 
        var hostel_items = "";
        var accounts = 0;
        $.ajax({
            type: 'GET',
            data: data,
            url: 'fetch_hostelItems_data',
            success:function(res){
                 // 
                var hostel_data = JSON.parse(res);
                var len = hostel_data.length;
                for(var i = 0; i < len; i++){
                  
                    var qty = hostel_data[i]['quantity'];
                    var price = hostel_data[i]['price'];
                    var iid=hostel_data[i]['item_id'];
                    var ttl = qty * price;

                    amount_ttl = amount_ttl + ttl;
                    account = hostel_data[i]['accounts'];

                    $('#total').val(ttl);
                     //alert(ttl);

                    $('#itemsbdy').append('<tr id="row_'+ hostel_data[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+hostel_data[i]['item_id']+'">'+hostel_data[i]['item_id']+'</td>\
                        <td>'+hostel_data[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+hostel_data[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                        <td>\
                         <a class="cost2" id="cost' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getid_popup(' +iid+ ','+price+')"><input type="text" name="price'+iid+'" value="'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" id="prc'+iid+'" readonly></a>\
                        </td>\
                          <td><input type="hidden" name="price'+iid+'" id="prco'+iid+'" value="'+ttl+'"></td>\
                       <td class="text-right" style="text-align:right" id="total'+iid+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td>\
                           <a href="javascript:RemoveRow('+hostel_data[i]['item_id']+','+ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                    
                }
                hostel_items = {account_receivable: account, amount: amount_ttl};
                receivable_total_balance.push(hostel_items);
                // console.log(receivable_total_balance);
                  totalsum=totalsum+amount_ttl;
           
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });
        $('#hostelDtls').show();
}

    function TransportItems(id){
        var data = 'vehicle_id=' + id.value;
        // alert(data);
        var amount_ttl = 0; 
        var vehicle_items = "";
        var accounts = 0;
        $.ajax({
            type: 'GET',
            data: data,
            url: 'fetch_vehicleItems_data',
            success:function(res){

                var transData = JSON.parse(res);
                var len = transData.length;
                for(var i = 0; i < len; i++){

                    var qty = transData[i]['quantity'];
                    var iid=transData[i]['item_id'];
                    var price = transData[i]['price'];
                    var ttl = qty * price;

                    amount_ttl = amount_ttl + ttl;
                    account = transData[i]['RecAccnt'];

                    $('#total').val(ttl);


                    $('#itemsbdy').append('<tr id="row_'+ transData[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+transData[i]['item_id']+'">'+transData[i]['item_id']+'</td>\
                        <td><input type="hidden" name="iid[]" value="'+transData[i]['item_id']+'">'+transData[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+transData[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                       <td>\
                         <a class="cost2" id="cost' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getid_popup(' +iid+ ','+price+')"><input type="text" name="price'+iid+'" value="'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" id="prc'+iid+'" readonly></a>\
                        </td>\
                          <td><input type="hidden" name="price'+iid+'" id="prco'+iid+'" value="'+price+'"></td>\
                       <td class="text-right" style="text-align:right" id="total'+iid+'">'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td>\
                            <a href="javascript:RemoveRow('+transData[i]['item_id']+','+ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
                vehicle_items = {account_receivable: accounts, amount: amount_ttl};
                receivable_total_balance.push(vehicle_items);
                totalsum=totalsum+amount_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });
    }

    $('input[type=radio][name=transp]').change(function(){
        var data =  $(this).val();
        // alert(data);
        if(this.value == 'Yes'){
            $('#trnspDtls').show();
        }else if (this.value == 'No'){
            $('#trnspDtls').hide();
        }
    });

    $('#admsionDtls').submit(function(e){
         var type= $("input[type='radio'][name='state']:checked").val();
          var bod=$('#hstl').val();
          //alert(type);
          //alert(bod);
         if(type==3 && bod==''){ 
            document.getElementById("hostelf").innerHTML = "Choose hostel";
            swal('','Choose hostel','');
         }else{
           // alert('filled');
       // alert($(this).serialize()+'&receivable_total_balance=' + JSON.stringify(receivable_total_balance));
       //   return;
        $.ajax({
            beforeSend: function () {
                  $('#admit_student').prop("disabled", true);
                  Swal.fire({
              title: 'Please wait...',
              html: '<span class="text-danger">Saving Data</span>',
              icon: 'info',
              allowOutsideClick: false,
              showConfirmButton: false,
              timerProgressBar: true,
              onBeforeOpen: () => {
                Swal.showLoading();
              }
            });
                  
            },
            type: 'POST',
           url: 'save_admission',
            data: $(this).serialize()+'&receivable_total_balance=' + JSON.stringify(receivable_total_balance)+'&'+$("#header_form").serialize(),
            success:function(res){
                 refreshPage();
                $('#myModal').modal('hide');
                Swal.close();
                 
                var data = JSON.parse(res);
                if(data['status'] == 0){
                    
                    Swal.fire({
                    title: "successful", 
                    html: data['statusDesc'], 
                    icon: "success"
                  }).then((result) => {
                  if (result.isConfirmed) {
                    //location.reload();
                  }
                });
                }else{
                    $('#admit_student').prop("disabled", false);
                    Swal.fire({
                    title: "successful", 
                    html: data['statusDesc'], 
                    icon: "success"
                  }).then((result) => {
                  if (result.isConfirmed) {
                   // location.reload();
                  }
                });
                }
            },
            error:function(res){
                $('#admit_student').prop("disabled", false);
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Admit student.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                setTimeout(function(){
            window.location.reload();
        },1000)
            }
        });

        e.preventDefault();
    }
    });
    //////////////////////////////////////////////////////////////////////

  function month_item(id){
         var data = 'start=' + $('#start').val()+'&month=' + id.value;
     $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/ClassController/append_date'; ?>',
            success: function(res){
                var date = JSON.parse(res);
                  $('#end_date').show();
                  $('#end').val(date[0]['end_date']);
                 // monthly_items(id.value);
            }
            });

     }
     function getid(id,prc) {
     $('#cash').toggle(100);
      var price=$('#prc'+id).val().replace(/,/gi, "");
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/priceview'; ?>",
            beforeSend: function () {
                $('#prcres').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#prcres').html(result);
                console.log(prc);
             document.querySelector('[id="cash_amt"]').value = price;
             document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }

         function getid_popup(id,prc) {
     $('#cash').toggle(100);
      var price=$('#prco'+id).val().replace(/,/gi, "");
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/form_popup'; ?>",
            beforeSend: function () {
                $('#prcres').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#prcres').html(result);
                console.log(prc);
             document.querySelector('[id="cash_amt"]').value = price;
             document.querySelector('[id="item_id"]').value = id;
             
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }
    function savebtn(){
       // totalsum=0;
      var cash=$('#cash_amt').val();
      var id1=$('#item_id').val();
      var oprc=$('#prco'+id1).val().replace(/,/gi, "");
          oprc=parseInt(oprc);
          
            var cashAmt =parseInt(cash);
            document.querySelector('[id="prco'+id1+'"]').value =cashAmt;
            document.querySelector('[id="prc'+id1+'"]').value = '-'+cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            document.getElementById("total"+id1).innerHTML = '-'+cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
 
        totalsum=totalsum-cashAmt+oprc;
            
          $('#cash').hide(); 
             document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;       
         e.preventDefault(); 
    }

 function save_amount(){
       // totalsum=0;
      
      var cash=$('#cash_amt').val();
      var item_id=$('#item_id').val();
      var oprc=$('#prc'+item_id).val().replace(/,/gi, "");
          oprc=parseInt(oprc);
        // alert(oprc);
            var cashAmt =parseInt(cash);
            document.querySelector('[id="prco'+item_id+'"]').value =cashAmt;
            document.querySelector('[id="prc'+item_id+'"]').value =cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            document.getElementById("total"+item_id).innerHTML = cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

           
        totalsum=totalsum+cashAmt-oprc;
            
          $('#cash').hide(); 
             document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;       
         e.preventDefault(); 
    }
   function append_class_items(lv){
         get_classlevel_chargedItems();
   }
   function refreshPage(){
        $('#pending_results').html('<div class=""><span class="fa fa-spin"></span>refreshing page...</div>');
        var dta = "year=" + $('#cyear option:selected').val()+'&class='+ $('#class option:selected').val();
         // alert(dta);
         $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_pending_continous'; ?>',
                data: dta,
                success: function (res) {
                    $('#pending_results').html(res);
                },
                error: function () {
                    $('#pending_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
      }
</script>