<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<style type="text/css">
    .text-c{
    text-align: left; !important;
}
</style>
<?php 

    $transport = new App\Models\TransportModel();
      $cmodel = new App\Models\ClassesModel();
?>


             
             
                    
                    <div class="container-fluid"><br>
                 <div class="" id="printable">
                        <center>
             <h5>EDEN GARDEN EDUCATION TRUST</h5>  
             <h5>CLASS SETUP</h5>  
          </center>
                   
                    <?php
                    foreach($updated as $updateNow){
                        ?>
                    
        <table class="table table-hover mb-0 text-nowrap att-list">
        <tr><th>Class Name</th><td><?php echo $updateNow->class_name;?></td><td></td><td></td><td></td><td></td><td></td></tr>
        <tr><th>Class Level </th><td><?php echo $updateNow->level_name;?></td></tr>
        <?php
         $count = $cmodel->get_number_ofStreams($updateNow->id);
        ?>
        <tr><th>Stream Capacity</th><td><?php echo $count[0]->stream_name;?></td></tr>
        <?php $status= $updateNow->status;
          if($status==1){
            $st="Active";
          }else{
           $st="Inactive"; 
          }
        ?>
        <tr><th>Status</th><td><?= $st;?></td></tr>
    
 </table><br>
                                    <?php
                                   }
                                       ?>
                         
             <form  id="VehicleItemUpdate">
                 <input type="hidden" class="form-control" name="vid" value="<?php echo $updateNow->id;?>">
                    
                        
                                    
                                    <div class="row">
                                    <div class="col-md-12">
                                    <div class="card">
                                         <p Class=" d-flex justify-content-center">CHARGED ITEMS</p>
                                   <table class="table table-hover table-vcenter mb-0 text-nowrap att-list">
                                    <thead>
                                    <thead>
                                            <tr>
                                                <th>No#</th>
                                                <th>Item Name</th>
                                                <th></th>
                                               <th></th>
                                                <th>Quantity</th>
                                                <th>Price</th>
                                                <th>Total</th>
                                               
                                                
                                    </thead>
                                    
                                    <tbody id="show_detail">
                          <tr>
                            <td colspan="3"></td>
                            <td><b>CONTINOUS USE TYPES</b></td>
                        </tr>   
                                               
                                                <?php
                                                $total=0;
                                                foreach($item as $items){
                                                    $transport = new App\Models\TransportModel();
                            
                                                $dbname=session()->get('db_name');
                                                $db = \Config\Database::connect($dbname);
                                                $item_id=$items->item_id;
                                                $query=$this->db->table('price_tbl');
                                                $query->select('item_id,item_price');
                                                $query->where('item_id',$item_id);
                                                $result=$query->get()->getResult();
                                                      $grp= $items->item_group;
                                              if($grp==0){
                                                $group="Continous";
                                                ?>
                        
                            <tr id="<?php echo $items->id;?>">
                            <td class="text-c"><?php echo $items->item_id;?> </td>
                            <td class="text-c"><?php echo $items->item_name;?></td>
                            <!-- <td class="text-c"><?php echo $items->item_attribute;?></td>
                            <td class="text-c"><?php echo $items->item_size;?></td>-->
                            <td></td>
                            <td></td>
                            <td class="text-c"><?php echo $items->quantity;?></td>
                             
                            
                                                <?php
                             foreach($result as $i){
                            $tprice= $items->quantity*$i->item_price;
                            $total=$total+$tprice;
                            ?>
                         <td class="text-right"><?php echo number_format($i->item_price);?></td>
                                                     
                            <td class="text-right"><?php echo number_format($tprice);?></td>
                               <!-- <td class="text-c"><?php echo $group;?></td> -->
                          <?php   
                                 }
                               ?>  
                </tr>
           
            <?php } }  ?>

                           <tr>
                            <td colspan="6"><b>Total</b></td>
                            <td class="text-right"><b><?php echo number_format($total); ?></b></td>
                        </tr>  

                        <!--==================================================-->
                         <tr>
                            <td colspan="3"></td>
                            <td><b>NEW COMER USE TYPES</b></td>
                        </tr>
                           <?php
                                                $total=0;
                                                foreach($item as $items){
                                                    $transport = new App\Models\TransportModel();
                            
                                              $dbname=session()->get('db_name');
                                                $db = \Config\Database::connect($dbname);
                                                $item_id=$items->item_id;
                                                $query=$this->db->table('price_tbl');
                                                $query->select('item_id,item_price');
                                                $query->where('item_id',$item_id);
                                                $result=$query->get()->getResult();
                                                      $grp= $items->item_group;
                                              if($grp==2){
                                                $group="New Comer";
                                                ?>
                            <tr id="<?php echo $items->id;?>">
                            <td class="text-c"><?php echo $items->item_id;?> </td>
                            <td class="text-c"><?php echo $items->item_name;?></td>
                         <!--    <td class="text-c"><?php echo $items->item_attribute;?></td>
                            <td class="text-c"><?php echo $items->item_size;?></td> -->
                             <td></td>
                            <td></td>
                            <td class="text-c"><?php echo $items->quantity;?></td>
                             
                            
                                                <?php
                             foreach($result as $i){
                            $tprice= $items->quantity*$i->item_price;
                            $total=$total+$tprice;
                            ?>
                         <td class="text-right"><?php echo number_format($i->item_price);?></td>
                                                     
                            <td class="text-right"><?php echo number_format($tprice);?></td>
                               <!-- <td class="text-c"><?php echo $group;?></td> -->
                          <?php   
                                 }
                               ?>  
                </tr>
           
            <?php }
               
                          }  ?>

                           <tr>
                            <td colspan="6"><b>Total</b></td>
                            <td class="text-right"><b><?php echo number_format($total); ?></b></td>
                        </tr>  
                        <!--===================================================--->
                         <tr>
                            <td colspan="3"></td>
                            <td><b>bOARDING ALL USE TYPES</b></td>
                        </tr>
                           <?php
                                                $total=0;
                                                foreach($item as $items){
                                                    $transport = new App\Models\TransportModel();
                            
                                               $dbname=session()->get('db_name');
                                                 $db = \Config\Database::connect($dbname);
                                                $item_id=$items->item_id;
                                                $query=$this->db->table('price_tbl');
                                                $query->select('item_id,item_price');
                                                $query->where('item_id',$item_id);
                                                $result=$query->get()->getResult();
                                                      $grp= $items->item_group;
                                              if($grp==3){
                                                $group="Boarding All";
                                                ?>
                            <tr id="<?php echo $items->id;?>">
                            <td class="text-c"><?php echo $items->item_id;?> </td>
                            <td class="text-c"><?php echo $items->item_name;?></td>
                          <!--   <td class="text-c"><?php echo $items->item_attribute;?></td>
                            <td class="text-c"><?php echo $items->item_size;?></td> -->
                             <td></td>
                            <td></td>
                            <td class="text-c"><?php echo $items->quantity;?></td>
                             
                            
                                                <?php
                             foreach($result as $i){
                            $tprice= $items->quantity*$i->item_price;
                            $total=$total+$tprice;
                            ?>
                         <td class="text-right"><?php echo number_format($i->item_price);?></td>
                                                     
                            <td class="text-right"><?php echo number_format($tprice);?></td>
                               <!-- <td class="text-c"><?php echo $group;?></td> -->
                          <?php   
                                 }
                               ?>  
                </tr>
           
            <?php }
                  }  ?>

                           <tr>
                            <td colspan="6"><b>Total</b></td>
                            <td class="text-right"><b><?php echo number_format($total); ?></b></td>
                        </tr>     
                        <!--=====================================================-->
                         <tr>
                            <td colspan="3"></td>
                            <td><b>BOARDING NEW COMER USE TYPES</b></td>
                        </tr>
                       <?php
                                                $total=0;
                                                foreach($item as $items){
                                                    $transport = new App\Models\TransportModel();
                            
                                                
                                                $item_id=$items->item_id;
                                                $query=$this->db->table('price_tbl');
                                                $query->select('item_id,item_price');
                                                $query->where('item_id',$item_id);
                                                $result=$query->get()->getResult();
                                                      $grp= $items->item_group;
                                              if($grp==4){
                                                $group="Boarding NewComer";
                                                ?>
                            <tr id="<?php echo $items->id;?>">
                            <td class="text-c"><?php echo $items->item_id;?> </td>
                            <td class="text-c"><?php echo $items->item_name;?></td>
                            <!-- <td class="text-c"><?php echo $items->item_attribute;?></td>
                            <td class="text-c"><?php echo $items->item_size;?></td>
                             --> <td></td>
                            <td></td>
                            <td class="text-c"><?php echo $items->quantity;?></td>
                             
                            
                                                <?php
                             foreach($result as $i){
                            $tprice= $items->quantity*$i->item_price;
                            $total=$total+$tprice;
                            ?>
                         <td class="text-right"><?php echo number_format($i->item_price);?></td>
                                                     
                            <td class="text-right"><?php echo number_format($tprice);?></td>
                               <!-- <td class="text-c"><?php echo $group;?></td> -->
                          <?php   
                                 }
                               ?>  
                </tr>
           
            <?php }
               }  ?>

                           <tr>
                            <td colspan="6"><b>Total</b></td>
                            <td class="text-right"><b><?php echo number_format($total); ?></b></td>
                        </tr>  
                        <!---=====================================================-->
                </tbody>
                </table>
                <br>
                <?php 
                $tem = $cmodel->get_termsPayments($updateNow->id);
                ?>
               <p Class="d-flex justify-content-center mt-3">INSTALLMENTS</p>
                <table class="table table-hover table-vcenter mb-0 text-nowrap att-list">
                <thead> 
                    <tr>
                    <th>Term Name</th>
                    
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Amount</th>
                </tr>
            </thead>
                    <?php
                    $tterm=0; 
                    foreach($tem as $tm){
                        $tterm=$tterm+$tm->amount;
                    ?>
                    <tr>
                       <td class="text-c"><?php echo $tm->term_name; ?></td> 
                       
                       <td class="text-c"><?php echo $tm->start_date; ?></td>
                       <td class="text-c"><?php echo $tm->end_date; ?></td>
                       <td class="text-c"><?php echo number_format($tm->amount); ?></td>
                    </tr>
                <?php }?>
                <tr>
                    <td class="text-c" colspan="3"><b>Total</b></td>
                    <td class="text-c"><b><?php echo number_format($tterm);?></b></td>
                </tr>
                </table><br>
                <p Class="d-flex justify-content-center mt-3">ACCOUNT RECEIVABLE</p>
                 <table class="table table-hover table-vcenter mb-0 text-nowrap att-list">
                    <thead>
                         <?php 
                $rv = $transport->get_receivableAccount($item[0]->account_receivable);

                ?>

                        <tr><td>Account Receivable:</td>
                            <?php
                      if(count($rv)>0){
                            ?>
                            <td><?=$rv[0]->account_name; ?></td>
                            <?php 
                           }else{
                            ?>
                            <td>No data</td>
                        <?php }?>
                        </tr>
                    </thead>
                </table>
                </div>
                                
         
                     
        <button type="button" class="btn btn-danger" id="cancel" style="padding:5px; float:right" data-bs-dismiss="modal">Cancel</button>
        <center>
            <button class="btn btn-success btn-sm col-sm-3" type="button" id="print_att"><i class="fa fa-print"></i> Print</button>
        </center>
                          </div>
                        </div>
                        </div>
                        
<noscript>
    <style>
        table.att-list{
            width:100%;
            border-collapse:collapse
        }
        table.att-list td,table.att-list th{
            border:1px solid
            text-align: left;
        }
        .text-center,.text-right,.d-flex{
            text-align:right;
        }
        #cancel,#print_att{
            display: none;
        }
    </style>
</noscript>

<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
     $('#print_att').click(function(){
        var _c = $('#printable').html();
        var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=900,height=600')
        nw.document.write(_c)
        nw.document.write(ns.html())
        nw.document.close()
        nw.print()
       
    })
    var hold_selected_items = []; // hold all selected items

    $(document).ready(function(){
         $('#js-example-data').select2({
            ajax: {
                url: "<?= base_url('get_data'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

        $('#js-example-data').on('select2:select', function (e) {
            selectedItems();
        });
         
        function selectedItems(){  
        var transport_id= $("#tid").val();
            var rows = '';
           var itemData = 'item_selected='+$('#js-example-data').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                 url:"<?= base_url('item_data')?>/"+ transport_id,   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }else{
                        var len  = data.length;

                        for (var i = 0; i <len; i++ ){
                            hold_selected_items.push(data[i]['id']);// push all selected items
                            var prc = data[i]['iprice'];
                            var name = data[i]['iname'];
                            var iid = data[i]['id'];
                            var size = data[i]['isize'];
                            var attribute = data[i]['iattribute'];
                            //var quantity= window.prompt('enter quantity');
                            //var total= quantity*prc;

                            
                            rows += '<tr id="table_row'+ iid +'">';
                            rows += '<td>'+ iid +'</td>';
                            rows += '<td>'+ name +'</td>';
                            rows += '<td>'+ attribute +'</td>';
                            rows += '<td>'+ size +'</td>';
                            rows += '<td>'+ 1 +'</td>';
                             
                            rows += '<td><input type="number" name="qty[]'+iid+'"  id="qty'+iid+'" onkeyup=confirm('+iid+'); style="width:60px"></td>';
                            rows += '<td id="item_price'+iid+'">'+ prc +'</td>';
                            rows += '<td><input type="text" name="tprice" id="tprice'+iid+'" style="width:80px;" readonly></td>';
                           rows +='<input type="hidden" name="id[]" value="'+iid+'">';
                             rows += '<td><a href="javascript:RemoveSelectItemRow('+iid+');" class="btn btn-danger" >X</a></td>';
                            rows += '</tr>';
                            $('#show_detail').append(rows);
                            
                        }
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }  
           });  
        } 
    });
    function confirm(iid){
    var totalPrice = $('#qty'+iid).val()* $('#item_price'+iid).html()        
    document.getElementById('tprice'+iid).value = totalPrice.toLocaleString('en-US');   

var totalPrice = totalPrice.toLocaleString('en-US');
console.log(usFormat);  
        
}       

    function RemoveSelectItemRow(item_id){
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }

        $('#table_row'+item_id).remove();
    }


    $('#Vehicle').submit(function(e){
         var Dat = $(this).serialize()+ '&item_iid='+$("#item_iiid").val();
         
          

        $.ajax({
            method: 'POST',
            url: '<?= base_url('Update_vehicle_item')?>',
            data:Dat,
            
            success:function(data){
                alert('data updated successfully');  
            },
            error:function(){
                 alert('data not updated try again');   
            }
        });
        
        e.preventDefault();
    });
     $('#VehicleItemUpdate').submit(function(e){
         var Data1 = $(this).serialize();
         
            //alert(Data1);

        $.ajax({
            method: 'POST',
            url: '<?= base_url('updateItem')?>',
            data:Data1,
            
            success:function(data){
              
                 swal("Updated!", "Item has been Updated.", "success");
            

                    // location.reload();
                    
            },
            error:function(){
                     $("#ErrorModal").modal('show');
            }
        });
        
        e.preventDefault();
    });
    
    
     $(".deleteid").click(function () {
         var id=$(this).attr('data-id');
       // var data3 = 'trid=' + $(this).attr('trans_id')+ '&itid='+$(this).attr('delete_id');
    //alert(id);
    //return;
        
        


        $.ajax({
            type: "GET",
            url: "DeleteVehicleItem/"+ id,
            //data: data,
            success: function(res){
               // $('#UpdateTransport').html(res);
                swal("Deleted!", "Item has been deleted.", "success");
                $("#"+id).remove();

                    
                 
            },
            error: function ()
            {

            }
        });
    });
    
    
</script>
