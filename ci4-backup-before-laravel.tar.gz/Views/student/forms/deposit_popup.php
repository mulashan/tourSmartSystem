                                        <?php
                                           $bmodel = new App\Models\BillingModel();
                                    $acc = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 9));
                                ?>
                                       <h6>Receive Cash</h6>
                                     <form id="csh_proc1" method="POST" onsubmit="event.preventDefault();">
                                         <select class="form-control" name="ledger" id="ledger" required="">
                                             <option value="">Select ledger</option>
                                            <?php foreach($acc as $ac):?>
                                                 <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                             <?php endforeach; ?>
                                         </select><br>
                                         <input class="form-control" name="cash_amt1" id="cash_amt1" type="number" required="" ><br>
                                         <button class="btn btn-warning" onclick="tg_cash()">Cancel</button>
                                         <button type="submit" class="btn btn-primary pull-right" onclick="csh_proc1()">Save</button>&nbsp;
                                     </form>
                                   <button class="btn btn-sm btn-warning" style="display:none" id="removeCash">Remove Cash</button>&nbsp;

<script type="text/javascript">
      function cancelbtn(){
            //alert('yes');
      $('#cash').hide();  
    }


</script>