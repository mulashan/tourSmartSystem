   <?php
   helper('age');
  $bmodel = new App\Models\BillingModel();
  $smodel = new App\Models\StudentModel();
  $cmodel = new App\Models\ClassesModel();
 $report = new App\Models\ReportsModel();
   $ps = getStatus($id);
       if($ps>0){
        $pstatus="Not Paid";
        $row='red';
       }else{
         $pstatus="Paid";
        $row="green";
       }

 $logo = $bmodel->get_table_details('company_tbl');
 $source="";
            if($logo[0]->logo_name != ""){
               $source =  base_url('public/company_photos/'.$logo[0]->logo_name);
            }

             $admn = $bmodel->get_item_name('admission_tbl', $where = array('id'=>$id));
               $bod = $bmodel->get_item_name('boarding_tbl', $where = array('student_id'=>$admn[0]->student_id,'academic_year'=>$admn[0]->academic_year));
               $tm = $bmodel->get_item_name('school_terms_tbl', $where = array('id'=>$term));
               $std = $bmodel->get_item_name('students', $where = array('id'=>$admn[0]->student_id));
               $cls = $bmodel->get_item_name('classes_tbl', $where = array('id'=>$admn[0]->class_id));
            $age = findAge($std[0]->birth_date);
            $hostel= $bmodel->get_item_name('hostel_tbl', $where = array('id'=>$admn[0]->hostel_id));
            ?>
          <center>
            <div class="container">
             <div class="img"> <img src="<?php  echo $source; ?>"  style="background: white;width: 25%;height: 25%" ></div>
            <!-- <h3><b>INVOICE</b></h3> -->
            <!-- <div class="mt-3"><img src="<?php //echo $source; ?>" width="180" height="130"></div></br> -->
            <div class="mt-4"><b><?= $logo[0]->company_name; ?> </b></div>
            <div class="modify"><?= $logo[0]->address; ?></div>
            <div class="mb-3">
                <div><span class="modify">Phone: <?= $logo[0]->phone1; ?></span></div>
                <div><span class="modify">Email: <?= $logo[0]->email; ?></span></div>
                <div><span class="modify"> <?= $logo[0]->website; ?></span></div>
             
            </div>
            </div>
           <hr style="color:black;">

             <div class="modify"><span class="modify"><b>BOARDING PASS</b></span></div>
        </center>

 <div class="row">
  <div class="col-md-12">
     <table class="table table-borderless mt-3">
        <tr> 
            <td style="font-size: 14px;">Acc Year:</td>
            <td style="font-size: 14px;"><?php echo $admn[0]->academic_year;?></td>
        </tr> 
       <tr> 
            <td style="font-size: 14px;">Pass No:</td>
            <td style="font-size: 14px;"><?php echo $bod[0]->permit_id;?></td>
        </tr> 
         <tr> 
            <td style="font-size: 14px;">Pass Date:</td>
            <td style="font-size: 14px;"><?php echo $bod[0]->created_date;?></td>
        </tr>  
         <tr> 
            <td style="font-size: 14px;">Term:</td>
            <td style="font-size: 14px;"><?php echo $tm[0]->term_name;?></td>
        </tr>
       
          <tr> 
            <td style="font-size: 14px;">Payment Status:</td>
            <td style="font-size: 14px;color: <?= $row;?>"><?php echo $pstatus;?></td>
        </tr> 
        
        <tr> 
            <td style="font-size: 14px;">Student Name:</td>
            <td style="font-size: 14px;"><?php echo $std[0]->full_name;?></td>
        </tr>
        <tr> 
            <td style="font-size: 14px;">Age:</td>
            <td style="font-size: 14px;"><?php echo $age;?></td>
        </tr>
        <tr> 
            <td style="font-size: 14px;">Class:</td>
            <td style="font-size: 14px;"><?php echo $cls[0]->class_name;?></td>
        </tr>
        <tr> 
            <td style="font-size: 14px;">Hostel:</td>
            <td style="font-size: 14px;"><?php echo $hostel[0]->hostel_name;?></td>
        </tr>
     </table>
 </div>
</div>
<br>
<center>
    <i><span>Powered by Micro Health Initiative</span></i>
</center>


      
         