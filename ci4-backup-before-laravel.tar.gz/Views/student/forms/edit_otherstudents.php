<?php
    $student_model = new App\Models\StudentModel();
?>
<!-- <ul class="nav nav-tabs tab-primary page-header-tab">
    <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#PayDetails" >Payment Details</a></li>
    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#StudentData">Applicant Details</a></li>
    
    
</ul> -->
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            
            <div id="updatFDBCK"></div>
               <form id="update_others" class="form-horizontal">
                 <div class="form-group row mb-3">
                     <label class="col-md-2 col-form-label"> Names</label>
                     <div class="col-md-3">
                         <input type="text" class="form-control" name="fname" placeholder="First Name" autocomplete="off" value="<?= $app[0]->first_name;?>">
                         <input type="hidden" class="form-control" name="appid" value="<?= $app[0]->id;?>">
                     </div>
                     <div class="col-md-3">
                         <input type="text" class="form-control" name="mname" placeholder="Middle Name" autocomplete="off" value="<?= $app[0]->middle_name;?>">
                     </div>
                     <div class="col-md-3">
                         <input type="text" class="form-control" name="lname" placeholder="Last Name" autocomplete="off" value="<?= $app[0]->last_name;?>">
                     </div>
                 </div>
                 <div class="form-group row mb-3">
                     <label class="col-md-2 col-form-label">Date of Birth</label>
                     <div class="col-md-3">
                         <input type="date" class="form-control" name="dob" placeholder="F" value="<?= $app[0]->birth_date;?>">
                     </div>

                     <label for="" class="col-md-2 col-form-label">Gender</label>
                     <div class="col-md-3">
                         <div class="form-check">
                             <input class="form-check-input mt-1" type="radio" name="gender" id="female" value="Female" <?php if($app[0]->gender == "Female") echo "checked";?>>
                             <label class="form-check-label" for="day">
                             Female
                             </label>
                         </div>
                         <div class="form-check">
                             <input class="form-check-input mt-1" type="radio" name="gender" id="male" value="Male" <?php if($app[0]->gender == "Male") echo "checked";?>>
                             <label class="form-check-label" for="board">
                             Male
                             </label>
                         </div>
                     </div>
                 </div>

                 <div class="form-group row mb-3">
                     <label class="col-md-2 col-form-label">Phone No.</label>
                     <div class="col-md-3">
                         <input type="tell" class="form-control" name="bphone" placeholder="+255-xxx-xxx-xxx"  required autocomplete="off" value="<?= $app[0]->phone;?>">
                     </div>
                     <label class="col-md-2 col-form-label">Status.</label>
                     <div class="col-md-3">
                        <?php
                        if($app[0]->status==1){
                            $status='Active';
                        }else{
                            $status='Inactive';
                        }
                        ?>
                         <select class="form-select form-control" name="status">
                          <option value="<?= $app[0]->status;?>"><?= $status;?></option>
                          <option value="1">Active</option>
                          <option value="2">Inactive</option>
                         </select>
                     </div>
                 </div>
                <div class="form-group row mb-3">
                  <div class="col-md-3">
                  </div>
                  <div class="col-md-4 offset-md-4">
                    <button type="button" class="btn btn-primary float-right" id="updtappbtn" onclick="Update_others()">Update</button> 
                </div>
                </div>      
             </form>
            

        </div>
    </div>
</div>
<script>
     
      function Update_others(){
      //  alert($('#update_others').serialize());
        $.ajax({
           beforeSend: function () {
                 $('#updtappbtn').prop("disabled", true);
                 $('#updatFDBCK').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
           },
           //url: 'updat_application',
            url: '<?php echo base_url() . '/index.php/StudentController/update_other_students'; ?>',
           type: 'POST',
           data: $('#update_others').serialize(),
           success: function (res) {
               var data = JSON.parse(res);
               if(data['status'] == "0"){
                   $('#updatFDBCK').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                   location.reload();
                }else{
                   $('#updtappbtn').prop("disabled", false);
                   $('#updatFDBCK').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
           },       
           error: function () {
                $('#updtappbtn').prop("disabled", false);
                $('#updatFDBCK').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry Something went wrong.</div>');;
           }
       });
    }
     $("#classlevel1").change(function(){
        var clvl = $(this).val();   
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class2").empty();
                $("#class2").append("<option value=''>-Choose Class-</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    $("#class2").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });
    function check_payment(ref){
      
       var paydata = 'ref_no=' + ref;
        $.ajax({
            type: "POST",
            url: 'check_payment',
            beforeSend: function () {
                $('#CheckPayment').prop("disabled", true);
                $('#PaymentSection').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
            },
            data: paydata,
            success: function (result) {
                $('#PaymentSection').load('<?php echo base_url() . '/index.php/StudentController/Api_payment_loader/' . $app[0]->id; ?>');
            },
            error: function () {
                $('#CheckPayment').prop("disabled", false);
                $('#PaymentSection').html('<p class="text-red">Sorry Something went wrong</p>');;
           }
        });
    }
     function checksmsstatus(id,divhtml){
     var data = "id=" + id;
         $.ajax({
            beforeSend: function () {
                $('#'+divhtml).html('<i class="fa fa-spinner fa-spin"></i> Checking sms status..');
            },
            type: "POST",
            url: '<?php echo base_url() . '/index.php/StudentController/check_sms'; ?>',
            data: data,
            success: function (result) {
                // $('#notsent').remove();
                $('#'+divhtml).html(result);             
            },
            error: function () {
                $('#'+divhtml).html('Sorry! Something went wrong.');
            }
        });
    }
     function PaymntResndSMSform(formId,divhtml) {
          $.ajax({
            beforeSend: function () {
                $('#'+ divhtml).html('<i class="fa fa-spinner fa-spin"></i> Sending Message..');
            },
            type: "POST",
            url: '<?php //echo base_url() . '/index.php/StudentController/resend_sms'; ?>',
            data: $('#'+formId).serialize(),
            success: function (result) {
              //  alert(result);
                $('#'+ divhtml).html(result);             
            },
            error: function () {
                $('#'+divhtml).html('Sorry! Something went wrong.');
            }
        });
    }
   
</script>    