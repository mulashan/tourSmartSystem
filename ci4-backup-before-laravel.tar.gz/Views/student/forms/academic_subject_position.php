<?php
$filtered_positions = array_filter($subject_position_term1, function ($pos) use ($subjects) {
    return $pos['subject'] == $subjects;
});
usort($filtered_positions, function ($a, $b) {
    return $a['position'] <=> $b['position'];
});
?>
<center>
  <h3>Subject position details</h3>
  <h4>Subject name: <small><?=$subject_name->subject_name;?><small></h4>
</center>
<div class="table-responsive">
  
<table class="table table-bordered">
  <thead>
    <tr>
      <th>#</th>
      <th>Student Name</th>
      
                        <?php
                        if(isset($exams_term)){
               foreach ($exams_term as $exam){
$exam_name = $exam->exam_name;
$words = explode(' ', $exam_name);
$first = isset($words[0]) ? substr($words[0], 0, 4) : '';
$second = isset($words[1]) ? substr($words[1], 0, 4) : '';
echo '<th>';
echo esc($first.'..'." " . $second);
echo '</th>';

}}
                    ?>
                
      <th>Average</th>
      <th>Position</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $i = 1;
    foreach ($filtered_positions as $s):
        $student = array_filter($students, fn($stu) => $stu->id == $s['student_id']);
        $student = reset($student);
        if (!$student) continue;
    ?>
    <tr>
      <td><?= $i++ ?></td>
      <td><?= esc($student->full_name ?? 'Unknown') ?></td>
        <?php
              if(isset($exams_term)){
               foreach ($exams_term as $exam){
                $found = false;
                if(isset($subject_marks)){
                   foreach ($subject_marks as $marks){
                    if($marks->exam_type_id==$exam->exam_id && $marks->student_id==$student->id){
                                  ?>
      <td><?=number_format($marks->avg_marks, 0)?></td>
      <?php
      $found = true;
         break; 
    }

  }}
   if (!$found) {
            echo '<td>-</td>';
        }
}}
      ?>
      <td><?= number_format($s['average'], 1) ?></td>
      <td><?= $s['position'] ?? '-' ?></td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>


<!-- <span style="font-size: 16px;" class="text-success"> Sum of scores = Exams -->
   <?php

    // if (isset($exams_term) && count($exams_term) > 0) {
    //     $parts = array_map(function($exam) {
    //         return $exam->exam_name;
    //     }, $exams_term);

     //   echo implode(' + ', $parts);
    // } else {
    //     echo 'No exam components found';
    // }
    ?>
 <!-- </span> --> 
<!-- <br>

<span style="font-size: 19px; font-weight: bold;">AVERAGE = </span>
<span style="font-size: 16px; color: blue;"><b>(Sum of scores ÷  -->
<?php
// if (isset($exams_term)) {
//    // echo count($exams_term);
// } else {
//     echo '0';
// }
?>
<!--  exams)</b></span>
<br><br> --> 
