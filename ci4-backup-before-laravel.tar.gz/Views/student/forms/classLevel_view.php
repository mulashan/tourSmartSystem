<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 

    $transport = new App\Models\TransportModel();
      $cmodel = new App\Models\ClassesModel();
      $rmodel = new App\Models\ReportsModel();
      $schoolname=$rmodel->get_schoolname();
?>


             
             
                    
                    <div class="container-fluid"><br>
                 <div class="" id="printable">
                        <center>
             <h5><?php echo $schoolname[0]->company_name;?></h5>  
             <h5>CLASS LEVEL SETUP</h5>  
          </center>
                   
                    <?php
                    foreach($updated as $updateNow){
                        ?>
                    
        <table class="table table-hover mb-0 text-nowrap att-list">
        <tr><th>Level Name</th><td><?php echo $updateNow->level_name;?></td><td></td><td></td><td></td><td></td><td></td></tr>
        
        <?php
         $count = $cmodel->get_number_ofClasses($updateNow->id);
        ?>
        <tr><th>Number of Classes</th><td><?php echo $count[0]->class_name;?></td><td></td><td></td><td></td><td></td><td></td></tr>
        <?php $status= $updateNow->status;
          if($status==1){
            $st="Active";
          }else{
           $st="Inactive"; 
          }
        ?>
        <tr><th>Status</th><td><?= $st;?></td><td></td><td></td><td></td><td></td><td></td></tr>
    
                                    <?php
                                   }
                                   foreach($item as $items){
                                              $grp= $items->item_group;
                                              if($grp==1){
                                                ?>
        <tr><th>Application Fee</th><td><?= number_format($items->item_price);?></td><td></td><td></td><td></td><td></td><td></td></tr>
                                                <?php
                                              }
                                          }
                                       ?>

     </table><br>
                         
             <form  id="VehicleItemUpdate">
                                 <div class="row">
                                    <div class="col-md-12">
                                    <div class="card">
                                         <p Class=" d-flex justify-content-center">CHARGED ITEMS</p>
                                   <table class="table table-hover table-vcenter mb-0 text-nowrap att-list">
                                    <thead>
                                    <thead>
                                            <tr>
                                                <th>No#</th>
                                                <th>Item Name</th>
                                                <th>Attribute</th>
                                                <th>size</th>
                                                <th>Qty</th>
                                                
                                                <th>Price</th>
                                                <th>Total</th>
                                                <th>UseType</th>
                                                
                                    </thead>
                                    
                                    <tbody id="show_detail">
                                                    
                                          
                                    </tbody>
                                    </table>
                                    <table>
                                        <tr>
                                        <th col=3>
                                        <span id="tot" style="margin-left:450px;"></span>
                                        </th>
                                        </tr>
                            </table>
                                         <br>
                <?php 
                $tem = $cmodel->get_termsLevel($updateNow->id);
                ?>
              <br>
                <p Class="d-flex justify-content-center mt-3">ACCOUNT RECEIVABLE</p>
                 <table class="table table-hover table-vcenter mb-0 text-nowrap att-list">
                    <thead>
                         <?php 
                $rv = $transport->get_receivableAccount($item[0]->account_receivable);
                ?>

                        <tr><td>Account Receivable:</td>
                            <td><?php if(count($rv)>0){ echo $rv[0]->account_name;} ?></td>
                        </tr>
                    </thead>
                </table>
                </div>
                                
         
                     
        <button type="button" class="btn btn-danger" id="cancel" style="padding:5px; float:right" data-bs-dismiss="modal">Cancel</button>
        <center>
            <button class="btn btn-success btn-sm col-sm-3" type="button" id="print_att"><i class="fa fa-print"></i> Print</button>
        </center>
                          </div>
                        </div>
                        </div>
                        
<noscript>
    <style>
        table.att-list{
            width:100%;
            border-collapse:collapse
        }
        table.att-list td,table.att-list th{
            border:1px solid
            text-align: left;
        }
        .text-center,.text-c,.d-flex{
            text-align:center
        }
        #cancel,#print_att{
            display: none;
        }
    </style>
</noscript>

<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
     $('#print_att').click(function(){
        var _c = $('#printable').html();
        var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=900,height=600')
        nw.document.write(_c)
        nw.document.write(ns.html())
        nw.document.close()
        nw.print()
       
    })
   fetch_level_itemsCharged();
   function fetch_level_itemsCharged(){
        $('#show_detail').empty();     
        
        var data = 'level_id=<?= $updated[0]->id; ?>';
        $.ajax({
            type: 'GET',
            data: data,
            url: 'fetch_levelItems_data',
            success:function(res){

                var level_data = JSON.parse(res);
                var len = level_data.length;
                var sum=0;
                for(var i = 0; i < len; i++){

                    var group = level_data[i]['item_group'];
                    var grp="";
                    if(group==0){
                        grp="Other Item";
                    }else if(group==1){
                        grp="Application";
                    }else if(group==2){
                        grp="New Comer";
                    }
                    var qty = level_data[i]['quantity'];
                    var price = level_data[i]['price'];
                    var ttl = qty * price;
                     sum=sum+ttl;
                    var account = level_data[i]['account'];
                    $('#total').val(ttl);
                    document.getElementById("tot").innerHTML = "Total = " + sum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                    console.log(sum);
                    window.sum=sum;
                    //$('#sum').val(sum);


                    $('#show_detail').append('<tr>'+
                        '<td><input type="hidden" name="account" value="'+account+'">'+level_data[i]['item_id']+'</td>\
                        <td>'+level_data[i]['name']+'</td>\
                        <td>'+level_data[i]['attribute']+'</td>\
                        <td>'+level_data[i]['size']+'</td>\
                        <td>'+qty+'</td>\
                        <td>'+price+'</td>\
                        <td id="total">'+ttl+'</td>\
                        <td id="grp">'+grp+'</td>\
                        </td>\
                    </tr>');
                    
                }
                //return sum;
            }
            
        });
        
    }
    
</script>
