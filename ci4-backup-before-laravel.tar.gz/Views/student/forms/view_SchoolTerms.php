                    <div class="container-fluid"><br>
                 <div class="" id="printable">
                        <center>
             <!--<h5>EDEN GARDEN EDUCATION TRUST</h5>  -->
             <h5>SCHOOL TERMS SETUP</h5>  
          </center>
            
                    
        <table class="table table-hover mb-0 text-nowrap att-list">
        <tr><th>Term Name</th><td><?= $terms[0]->term_name; ?></td><td></td><td></td><td></td><td></td><td></td></tr>
       
        <tr><th>Description</th><td><?= $terms[0]->description; ?></td></td><td></td><td></td><td></td><td></td></tr>
            <tr><th>Start Date</th><td><?= date('Y-m-d',strtotime($terms[0]->start_date)); ?></td></td><td></td><td></td><td></td><td></td></tr>
                <tr><th>End Date</th><td><?= date('Y-m-d',strtotime($terms[0]->end_date)); ?></td></td><td></td><td></td><td></td><td></td></tr>
        <?php
         $status= $terms[0]->status;
          if($status==1){
            $st="Active";
          }else{
           $st="Inactive"; 
          }
        ?>
        <tr><th>Status</th><td><?= $st;?></td></td><td></td><td></td><td></td><td></td></tr>
    
 </table><br>
</div>
<button type="button" class="btn btn-danger" id="cancel" style="padding:5px; float:right" data-bs-dismiss="modal">Cancel</button>
        <center>
            <button class="btn btn-success btn-sm col-sm-3" type="button" id="print_att"><i class="fa fa-print"></i> Print</button>
        </center>
</div>
<noscript>
    <style>
        table.att-list{
            width:100%;
            border-collapse:collapse
        }
        table.att-list td,table.att-list th{
            border:1px solid
            text-align: left;
        }
        .text-center,.text-c,.d-flex{
            text-align:center
        }
        #cancel,#print_att{
            display: none;
        }
    </style>
</noscript>

<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
     $('#print_att').click(function(){
        var _c = $('#printable').html();
        var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=900,height=600')
        nw.document.write(_c)
        nw.document.write(ns.html())
        nw.document.close()
        nw.print()
       
    })
   

    
</script>