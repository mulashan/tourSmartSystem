 <?php 
    helper('age');
    
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();
  $remodel = new App\Models\ReportsModel();
 // print_r($admission);
    $student = $smodel->gettable_data('students', $where = array('status' => 1));
    // $admission = $smodel->gettable_data('admission_tbl', $where = array('status' => 1,'admission_type' => 3,'academic_year'=>$year));
   
  $hostels = $smodel->get_item_name('hostel_tbl', $where = array('status' => 1));
   $term_name = $smodel->get_item_name('school_terms_tbl', $where = array('id' => $term));
?>
 <form id="closeAdmissionYearForm">
                        <div class="table-responsive mt-3">
                            <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                                <thead>
                                    <tr>
                                        <th>Permit No.</th>
                                        <th>Adm. No.</th>
                                        <th>Adm. Date</th>
                                        <th>Adm. Type</th>
                                        <th>Student Name</th>
                                        <th>DoB</th>
                                        <th>Age</th>
                                        <th>Level</th>
                                        <th>Class</th>
                                        <th>Stream</th>
                                        <th>Hostel</th>
                                        <th>Term</th>
                                        <th>P/Status</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $sn = 0;
                                    foreach ($admission as $adm):
                                        $std = $amodel->get_student_details('students', $where = array('id' => $adm->student_id));
                                        if($std[0]->status !=2){
                                            continue;
                                        }
                                       
                                    
                                      
                                      // if($ps>)
                                      
                                        $sn++;
                                       
                                        
                                         $pid = $amodel->get_student_details('boarding_tbl', $where = array('student_id' => $adm->student_id,'academic_year'=>$adm->academic_year));
                                         if(count($pid)==0){
                                       //////////////////////////////////////                                    
        $ino = "";
        $tkens = $smodel->get_max_id('boarding_tbl','permit_id');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
          
                $datah = [
                    'student_id' => $adm->student_id,
                    'academic_year' => $adm->academic_year,
                    'permit_id' => $ino,
                    'admission_type' => $adm->admission_type,
                    'hostel' => $adm->hostel_id,
                    'month' => 10,
                    'start_date' => $adm->date_joined,
                    'end_date' => date('Y')."-12-08",
                      'created_date' => $adm->date_joined,
                    'created_by' =>$adm->admitted_by,
                    'status ' => 1
                   
                ];
                 $amodel->SaveDetails('boarding_tbl',$datah);
                 continue;
        ///////////////////////////////////////////////
                                         }
                                        echo $adm->id.'/';
                                        $room = $amodel->get_student_details('classes_tbl', $where = array('id' => $adm->class_id));
                                        $strm = $amodel->get_student_details('streams_tbl', $where = array('id' => $adm->stream_id));
                                        $user = $amodel->get_student_details('users', $where = array('user_id' => $adm->admitted_by));
                                        $level = $amodel->get_student_details('class_level_tbl', $where = array('id' => $adm->level_id));
                                          $row="black";
                                         if($pid[0]->hostel==0){
                                         $hostelname='';
                                        }else{
                                        $hostel=$amodel->get_student_details('hostel_tbl', $where = array('id' => $pid[0]->hostel));
                                           $hostelname=$hostel[0]->hostel_name;
                                           $ps = getStatus($adm->id);
                                           if($ps>0){
                                            $pstatus="Not Paid";
                                            $row='red';
                                           }else{
                                             $pstatus="Paid";
                                             $row="green";
                                           }
                                    }
                                    
                                    ?>
                                        <tr style="color: <?= $row;?>;">
                                            <td><?= $pid[0]->permit_id;?></td>
                                            <td><?= $std[0]->student_id;?><input type="hidden" name="student_<?= $sn;?>" value="<?= $adm->student_id; ?>"><input type="hidden" name="admission_<?= $sn;?>" value="<?= $adm->id; ?>"></td>
                                            <td><?= $adm->admitted_date;?></td>
                                            <td><?php if($adm->admission_type==0){
                                               echo 'DAY';
                                            }else{echo 'BOARDING';}?></td>
                                            <td><?= $std[0]->first_name.' '.$std[0]->middle_name.' '.$std[0]->last_name;?></td>
                                            <td><?= $std[0]->birth_date;?></td>
                                            <td><?= findAge($std[0]->birth_date);?>
                                        </td>
                                            <td><?= $level[0]->level_name;?></td>
                                            <td><?= $room[0]->class_name;?></td>
                                            <td><?= $strm[0]->stream_name;?></td>
                                            <td><?= $hostelname;?></td>
                                            <td><?= $term_name[0]->term_name;?></td>
                                            <td><?= $pstatus;?></td>
                                            <td>
                                            <button type="button" class="btn btn-primary btn-sm UpdateID" data-id="<?= $adm->id;?>"><i class="fa fa-edit"></i> Edit</button>
                                            <button type="button" class="btn btn-primary btn-sm viewID" onclick="viewbod('<?= $adm->id;?>','<?= $term_name[0]->id;?>')" data-id="<?= $adm->id;?>"><i class="fa fa-eye"></i> View</button>
                                            </td>
                                        </tr>
                                    <?php endforeach ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- <input type="hidden" name="total_admitted" value="<?php //$sn; ?>">
                        <button type="submit" class="btn btn-primary float-right mb-3 me-3">Close Academic Year</button> -->
                    </form>

     <div id="myModal" class="modal fade"  role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <!-- <h5 class="modal-title" id="staticBackdropLabel">Student Admission Details</h5> -->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div id="view_details"></div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="close_rept()">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('view_details')"><i class="fa fa-print"></i> Print</button>
      </div>
      </div>
      
    </div>
</div>
 <?php
 
    ?>
   <script type="text/javascript">
           $(document).ready(function () {
                  $('#myTable').DataTable();
                }); 

               function viewbod(id,term){
                $('#myModal').modal('show'); 
        $('#view_details').load('<?php echo base_url() . '/index.php/ReportsController/view_boarding_details'; ?>/'+id+'/'+term);
     };

         
         function printable_rept(area) {
  var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
  disp_setting += "scrollbars=yes,width=750, height=600, left=80, top=25";
  var content_value = document.getElementById(area).innerHTML;

  var docprint = window.open("", "", disp_setting);
  docprint.document.open();
  docprint.document.write('<html><head><title>MHI</title>');

  // Add a <style> block to set the font family and other print-specific styles
  docprint.document.write('<style>');
  docprint.document.write('@media print {');
  docprint.document.write('  body {');
  docprint.document.write('    font-family: "Times New Roman", sans-serif;');
  docprint.document.write('    font-size: 15px;');
  docprint.document.write('  }');
  docprint.document.write('</style>');

  docprint.document.write('</head><body onLoad="self.print()" style="width:100%;">');

  // Modify content_value to include the colspan attribute
  var modifiedContent = content_value.replace('<td class="colspan-cell">', '<td colspan="2" class="colspan-cell">');
  docprint.document.write(modifiedContent);

  docprint.document.write('</body></html>');
  docprint.document.close();
  docprint.focus();
 
}                    
      </script>