 <form id="change_cash" action="#" method="post" onsubmit="event.preventDefault();">
 <input class="form-control" name="item_id" id="item_id" type="hidden" value="">
 <input class="form-control" name="cash_amt" id="cash_amt" type="number" required="" ><br>
<button class="btn btn-warning" onclick="cancelbtn()">Cancel</button>
<button type="submit" class="btn btn-primary pull-right" onclick="save_amount()">Save</button>&nbsp;
</form>

<script type="text/javascript">
      function cancelbtn(){
            //alert('yes');
      $('#cash').hide();  
    }


</script>