<?php 

    $cmodel = new App\Models\ClassesModel();
     $amodel = new App\Models\AdmissionModel();
 //$accounts = $cmodel->get_accounts_items();
  $accounts = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));
?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center ">
        <ul class="nav nav-tabs page-header-tab">
            <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#class">Classes</a></li>
            <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#items">Charged Items</a></li>
            <!--<li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#ments">Installments</a></li>-->
            <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#acctab">Account Receivable</a></li>
        </ul>
    </div>
</div>

<div class="container-fluid">
    <div class="tab-content">
        <div id="class" class="tab-pane active">
            <div id="updacc"></div>
            <form class="form-horizontal" id="updateClass">
                <input type="hidden" class="form-control" name="id" id="id" value="<?= $classes[0]->id; ?>">
 
                <div class="form-group row">
                    <label class="col-md-2 col-form-label">Class Name <span class="text-danger">*</span></label>
                    <div class="col-md-9">
                        <input type="text" class="form-control" name="cname" id="cname" value="<?= $classes[0]->class_name; ?>">
                        <!-- <input type="text" name="cname" class="form-control" > -->
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-2 col-form-label">Class Level <span class="text-danger">*</span></label>
                    <div class="col-md-9">
                        <select name="classlvl" id="classlvl" class="form-control">
                            <option value="">--Select Level--</option>
                            <?php foreach ($classLevl as $level): ?>
                                <option value="<?= $level->id; ?>"  <?php if($classes[0]->class_level == $level->id){ echo 'selected'; } ?>><?= $level->level_name; ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-2 col-form-label" for="status">Status</label>
                    <div class="col-md-9">
                        <select class="form-select form-control form-control-sm" id="status" name="status" >
                            <option value="">-Status-</option>
                            <option value="1" <?php
                            if ($classes[0]->status == 1) {
                                echo 'selected';
                            }
                        ?>>Active</option>
                        <option value="2" <?php
                        if ($classes[0]->status == 2) {
                            echo 'selected';
                        }
                    ?>>Inactive</option>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-md-2 col-form-label">Stream Name<span class="text-danger"></span></label>
                    <div class="col-md-3">
                        <input type="text" class="form-control" name="stream">
                    </div> 
                    <label class="col-md-2 col-form-label">Seating Capacity<span class="text-danger"></span></label>
                    <div class="col-md-3">
                        <input type="number" class="form-control" name="numb">
                    </div>
                    <div class="col-md-1">
                        <button type="button" class="btn btn-primary" id="UpdData"><i class="fa fa-plus"></i></button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-9">
                        <div class="card">
                            <table class="table table-hover table-vcenter mb-0 text-nowrap">
                                <thead>
                                    <tr>
                                        <th>No#</th>
                                        <th>Stream Name</th>
                                        <th>Capacity</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody id="tblbody">
                                     <div  class="cust_popup" id="customPopup" style="display: none">
                                    <h5>Edit Stream</h5>
                                    <form id="editStreamFoam">
                                <div id="prcres">
                                    <div class="form-group row">
                                     <label class="col-md-4 col-form-label">Stream Name</label>
                                     <div class="col-md-6">
                                        <input type="hidden" name="id_stream" id="id_stream">
                                    <input type="text" name="stream_name" placeholder="" id="stream_name" class="form-control">
                                    </div>
                                </div>
                                     
                                         <div class="form-group row">
                                     <label class="col-form-label col-md-4">Capacity</label>
                                      <div class="col-md-6">
                                    <input type="text" name="cap_acity" id="cap_acity" class=" form-control">
                                </div>
                                </div>
                                   
                                    <button type="button" onclick="submitStreamData()" class="btn btn-primary float-right">Save</button>
                                </form>
                                </div>
                                     
                                </div>
                                     
                               
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-2 col-form-label"></label>
                    <div class="col-md-9">
                        <button type="submit" class="btn btn-primary float-right">Update</button>
                    </div>
                </div>
            </form>
        </div>

        <div id="items" class="tab-pane">
            <div id="updacc1"></div>
            <form class="form-horizontal" id="">
                
                <input type="hidden" class="form-control" name="id" id="id" value="<?= $classes[0]->id; ?>">

                <div class="form-group row">

                    <label class="col-md-2 col-form-label">Charged Items<span class="text-danger">*</span></label>
                    <div class="col-md-5">
                       <select class="form-select form-control" id="itemselect" style="width:300px;" >
                            <option>Select Items to be Charged</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <input type="number" id="qtty" class="form-control" min="1">
                    </div>
                    <div class="col-md-1">
                        <button type="button" class="btn btn-primary" id="updateItem"><i class="fa fa-plus"></i></button>
                    </div>
                </div>
                <?php
              
    $itemsg = $cmodel->get_item_name('item_groups_types_tbl',$where = array('id >' => 0));
                 ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="row mt-3 mb-3" style="padding-top:20px;">
                            <label class="col-md-2 col-form-label">Use Type</label>
                    <div class="col-md-3">
                       <select class="form-select form-control" name="item_group" onchange="useGroup(this)">
                           <option value="11">All</option>
                           <?php
                            foreach($itemsg as $itm){
                           echo "<option value='".$itm->group_id."'>".$itm->group_name."</option>";
                            }
                           ?>
                       </select>
                    </div>
                   <div class="col-md-3">
                            CHARGED ITEMS
                        </div> 
                    </div> 
                            
                            <table class="table table-hover table-vcenter mb-0 text-nowrap" id="tbl">
                                <thead>
                                    <tr>
                                        <th>Item No#</th>
                                        <th class="">Item Name</th>
                                        <th  class="text-center">Qty</th>
                                        <th  class="text-center">Price</th>
                                        <th  class="text-center">Total</th>
                                        <th class="">Use Type</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="itemsbdy">

                                </tbody>
                            </table>
                            <table>
                                        <tr>
                                        <th col=4>
                                        <span id="sum" style="margin-left:400px;"></span>
                                        </th>
                                        </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-2 col-form-label"></label>
                    <div class="col-md-9">
                        <button type="button" class="btn btn-primary float-right" onclick="submitData()">Update</button>
                    </div>
                </div>
            </form>
        </div>
        
        

         <div id="acctab" class="tab-pane">
            <div id="updatedacc"></div>
            <form class="form-horizontal" id="updateAccount">
                <input type="hidden" class="form-control" name="cid" id="id" value="<?= $classes[0]->id; ?>">
            <div class="form-group row">
                    <label class="col-md-2 col-form-label">Account Receivable <span class="text-danger">*</span></label>
                    <div class="col-md-9">
                         <select name="acid" id="acid" class="form-control">
                            <?php 
                           $acid = $cmodel->get_accounts_id($classes[0]->id);
                             if(count($acid)>0){
                             ?>
                            
                           <?php foreach ($accounts as $leve): ?>
                                <option value="<?= $leve->id; ?>"  <?php if($acid[0]->account_receivable == $leve->id){ echo 'selected'; } ?>><?= $leve->account_name; ?></option>
                            <?php endforeach ?>
                        <?php }else{?>
                            <option value="">--Select Account--</option>
                               <?php foreach ($accounts as $leve): ?>
                                <option value="<?= $leve->id; ?>" ><?= $leve->account_name; ?></option>
                            <?php endforeach ?>
                             <?php }?>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-2 col-form-label"></label>
                    <div class="col-md-9">
                        <button type="submit" class="btn btn-primary float-right">Update</button>
                    </div>
                </div>
            </form>
    </div>
    </div>
</div>


<script type="text/javascript">  
    
    $(document).ready(function(){
        fetch_stream_data();
       
        fetch_class_itemsCharged();
         fetch_installment_data();

        $('#itemselect').select2({
            ajax: {
                url: "<?= base_url('load_data'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

        $('#itemselect').on('select2:select', function (e) {
            //selectedItems();
        });
             
        function selectedItems(){  
            var rows = '';
           var itemData = 'item_selected='+$('#itemselect').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Itemdata')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }  
           });  
        }

    });

    function RemoveSelectItemRow(item_id){
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }

        $('#table_row'+item_id).remove();
    }

    function totalAmounts(id){
        $('#ttl' + id).empty();
        var prc = $('input[name=prc' + id+']').val();

        var qty = $('input[name=qtys' + id+']').val();
        var calc = prc*qty; 
            $('#ttl' + id).append(calc);
    }

    function fetch_stream_data(){
        $('#tblbody').empty();     
        var datta = 'class_id=<?= $classID; ?>';
        $.ajax({
            type: 'GET',
            data: datta,
            url: 'fetchdata',
            success:function(response){

                var stream_data = JSON.parse(response);
                var len = stream_data.length;

                for(var i = 0; i < len; i++){
                    $('#tblbody').append('<tr>'+
                        '<td>'+(i + 1)+'</td>\
                        <td>'+stream_data[i]['name']+'</td>\
                        <td>'+stream_data[i]['capacity']+'</td>\
                        <td>\
                       <a href="javascript:editStream('+stream_data[i]['id']+', \''+stream_data[i]['name']+'\','+stream_data[i]['capacity']+');" class="btn btn-primary"><span class="fa fa-edit"></span></a>\
                            <a href="javascript:RemoveSelectStreamRow('+stream_data[i]['id']+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
            }
        });
    }
    


    function RemoveSelectStreamRow(id){

        $.ajax({
            type: 'GET',
            url: 'deleteStream/'+id,
            success: function(){
                fetch_stream_data();
            }
        });

    }

    function editStream(id,name,cap){
    $('#customPopup').toggle(100);
     $('input[name=stream_name]').val(name);
     $('input[name=cap_acity]').val(cap);
     $('input[name=id_stream]').val(id);

    }

    function RemoveRow(id,total){

        $.ajax({
            type: 'GET',
            url: 'deleteMents/'+id,
            success: function(){
                
                alert('deleted successfuly');
         remain= total;
         document.getElementById("rem").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(remain);
         fetch_installment_data();
            }
        });

    }
    


      $('#updateAccount').submit(function(e){
       var data = 'cid=' + $('input[name=cid]').val() + '&acid=' + $('select[name=acid]').val();
       //alert(data);

       $.ajax({
            type: 'POST',
            url: 'updateAccount',
            data: data,
            success:function(data){
                $('#updatedacc').html(data);
            // setTimeout(function(){
            //      window.location.reload();
            // },1000)
            }
       });

        event.preventDefault();
    });
    $('#UpdData').click(function(event){
       var data = 'name=' + $('input[name=stream]').val() + '&capacity=' + $('input[name=numb]').val() + '&id=' + $('input[name=id]').val();
       // alert(data);

       $.ajax({
            type: 'POST',
            url: 'addStream',
            data: data,
            success:function(){
                fetch_stream_data();
            }
       });

        event.preventDefault();
    });

$('#installupdate').click(function(event){
    var datta = <?= $classID; ?>;
   //alert(datta);
       var data = 'installname=' + $('select[name=install1]').val() + '&amount=' + $('input[name=amount1]').val()+ '&id=' + $('input[name=id]').val();
       if(remain==undefined){
        remain=10000000;
       }
       //alert(remain);
       var enteredAmount=$('input[name=amount1]').val();
       
       var present=remain-enteredAmount;
       //alert(present);
       if(present>=0){
         document.getElementById("morethan").innerHTML="";  
       $.ajax({
            type: 'POST',
            url: 'addinstallments/'+datta,
            data: data,
            success:function(data){
                if(data==1){
                alert("Term, Already Selected");
                present=remain+enteredAmount;
                }
                fetch_installment_data();
            }
       });
      }else{
        document.getElementById("morethan").innerHTML="Enter less amount or equal to "+remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
     // $('input[name=amount1]').val()="";    
      }
        event.preventDefault();
    });
    $('#updateClass').submit(function(e){
        var data = 'id=' + $('input[name=id]').val() + '&name=' + $('#cname').val() + '&level=' + $('#classlvl').val() + '&status=' + $('#status').val(); 
        // alert(data);
        $.ajax({
        type: 'POST',
        url: 'update_class',
        data: data,
        success: function (res) {
            $('#updacc').html(res);
            setTimeout(function(){
                 window.location.reload();
            },1000)
        },
        error: function () {
            $('#updacc').html('Error! Couldnt update Class.');            }
        });
        e.preventDefault();
    });

     
    function fetch_class_itemsCharged(){
        $('#itemsbdy').empty();     
        var sum=0;
        var data = 'class_id=<?= $classID; ?>'+'&item_group=11';
        //alert(data);
        $.ajax({
            type: 'GET',
            data: data,
            url: 'fetch_classItems_data',
            success:function(res){

                var class_data = JSON.parse(res);
                var len = class_data.length;
                
                for(var i = 0; i < len; i++){

                    var group = class_data[i]['item_group'];
                    var grp = class_data[i]['item_group_name'];
                    //var grp="";
                    // if(group==0){
                    //     grp="Other Item";
                    // }else if(group==1){
                    //     grp="Application";
                    // }else if(group==2){
                    //     grp="New Comer";
                    // }else if(group==3){
                    //     grp="Boarding All";
                    // }else if(group==4){
                    //     grp="Board NewComer";
                    // }
                    // else{
                    //   grp="No group";  
                    // }
                    var qty = class_data[i]['quantity'];
                    var price = class_data[i]['price'];
                    var ttl = qty * price;
                     sum=sum+ttl;
                    var account = class_data[i]['account'];
                    $('#total').val(ttl);
                    document.getElementById("sum").innerHTML = "Total = " + sum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                    console.log(sum);
                    window.sum=sum;
                    //$('#sum').val(sum);


                    $('#itemsbdy').append('<tr>'+
                        '<td><input type="hidden" name="account" value="'+account+'">'+class_data[i]['item_id']+'</td>\
                        <td>'+class_data[i]['name']+'</td>\
                       <td>'+qty+'</td>\
                        <td style="text-align:right">'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td id="total" style="text-align:right">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td id="grp">'+grp+'</td>\
                        <td>\
                            <a href="javascript:RemoveSelectItemRow('+class_data[i]['id']+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                    
                }
                //return sum;
            }
            
        });
        
    }

  function fetch_installment_data(){
        $('#showtbody').empty();
                
        var datta = 'class_id=<?= $classID; ?>';
        $.ajax({
            type: 'GET',
            data: datta,
            url: 'fetchinstallments',
            success:function(response){
                console.log(response);
                var ments_data = JSON.parse(response);
                var len = ments_data.length;
                //total=fetch_class_itemsCharged();
                var ttlamount=0;
                for(var i = 0; i < len; i++){
                    total=ments_data[0]['tprice'];
                    var amounted=parseInt(ments_data[i]['amount']);
                    ttlamount=parseInt(ttlamount+amounted);
                    $('#showtbody').append('<tr>'+
                        
                        '<td>'+ments_data[i]['installname']+'</td>\
                        <td>'+ments_data[i]['amount']+'</td>\
                        <td>'+ments_data[i]['duedate']+'</td>\
                        <td>\
                            <a href="javascript:RemoveRow('+ments_data[i]['id']+','+total+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
        //total=window.sum;
        total=ments_data[0]['tprice'];
        remain=total-ttlamount;
        document.getElementById("rem").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(total);
            }
        });
        
    }
  
    $('#updateItem').click(function(e){

        var data = "item=" + $('#itemselect').val() + "&quantity=" + $('#qtty').val()+ '&id=' + $('input[name=id]').val()+ '&account=' + $('input[name=account]').val();
        // alert(data);
        // return;

        $.ajax({
            type: 'POST',
            url: 'add_class_Item',
            data: data,
            success:function(){
                $('#itemselect').val('');
                $('input[name=qtty]').val('');
                fetch_class_itemsCharged();
                fetch_installment_data();
            }

       });

        e.preventDefault();
    });

    function RemoveSelectItemRow(id)
    {
        $.ajax({
            type: 'GET',
            url: 'delete_Class_ChargdItem/'+id,
            success: function(){
                fetch_class_itemsCharged();
                fetch_installment_data();
            }
        });
    }

    function submitData(){
        $('#updacc1').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
        setTimeout(function(){
            window.location.reload();
        },1000)
    }
function submitData2(){
        $('#updacc2').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
        setTimeout(function(){
            window.location.reload();
        },1000)
    }

    

     function useGroup(id){
        var data = 'item_group=' + id.value;
        $('#itemsbdy').empty();     
         var sum=0;
        var data = 'class_id=<?= $classID; ?>'+ '&item_group=' + id.value;
        $.ajax({
            type: 'GET',
            data: data,
            url: 'fetch_classItems_data',
            success:function(res){
             
                var class_data = JSON.parse(res);
                var len = class_data.length;
              
                for(var i = 0; i < len; i++){

                    var group = class_data[i]['item_group'];
                   var grp = class_data[i]['item_group_name'];
                    // if(group==0){
                    //     grp="Other Item";
                    // }else if(group==1){
                    //     grp="Application";
                    // }else if(group==2){
                    //     grp="New Comer";
                    // }else if(group==3){
                    //     grp="Boarding All";
                    // }else if(group==4){
                    //     grp="Board NewComer";
                    // }
                    var qty = class_data[i]['quantity'];
                    var price = class_data[i]['price'];
                    var ttl = qty * price;
                     sum=sum+ttl;
                    var account = class_data[i]['account'];
                    $('#total').val(ttl);
                    
                    //$('#sum').val(sum);


                    $('#itemsbdy').append('<tr>'+
                        '<td><input type="hidden" name="account" value="'+account+'">'+class_data[i]['item_id']+'</td>\
                        <td>'+class_data[i]['name']+'</td>\
                        <td>'+qty+'</td>\
                        <td style="text-align:right">'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td id="total" style="text-align:right">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td id="grp">'+grp+'</td>\
                        <td>\
                            <a href="javascript:RemoveSelectItemRow('+class_data[i]['id']+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                    
                }
                //return sum;
                document.getElementById("sum").innerHTML = "Total = " + sum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                    console.log(sum);
                    window.sum=sum;
            }
            
        });
        
    }

    function submitStreamData(){
        var strem_name=$('#stream_name').val();
        var capacity=$('#cap_acity').val();
        var id_stream=$('#id_stream').val();
     var stf='stream_name='+strem_name+'&capacity='+capacity+'&id='+id_stream;
    
     $.ajax({
        type: 'POST',
       url: '<?php echo base_url() . '/index.php/StudentController/edit_stream_data'; ?>',
        data: stf,
        success: function (res) {
            
             fetch_stream_data();   
            $('#customPopup').hide();
        },
        error: function () {
            alert('Error! Couldnt update Class.');            }
        });
    }
</script>