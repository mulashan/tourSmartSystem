 <form id="change_amount" action="#" method="post" onsubmit="event.preventDefault();">
                                       
<input class="form-control" name="receivable_amount" id="receivable_amount" type="text" required="" ><br>
<button class="btn btn-warning" onclick="cancelbtn()">Cancel</button>
<button type="submit" class="btn btn-primary pull-right" onclick="editReceivable()">Save</button>&nbsp;
</form>

<script type="text/javascript">
      function cancelbtn(){
            //alert('yes');
      $('#receivablePopup').hide();  
      
    }


</script>