<!--<link rel="stylesheet" href="<?php //echo base_url('public/assets/plugins/select2/select2.css')?>"/>-->
<?php 
    $cmodel = new App\Models\ClassesModel();
    $appItems = $cmodel->get_applications_items();
    $accounts = $cmodel->get_accounts_items();
   // print_r($accounts);
    //return;
 $smodel = new App\Models\StudentModel();
   $cperd = $smodel->gettable_data('academic_types_tbl', $where = array('status' => 1));
?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center ">
        <ul class="nav nav-tabs page-header-tab">
            <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#levels">Levels</a></li>
            <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#items">Charged Items</a></li>
            <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#ments">Installments</a></li>
              <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#acctab">Account Receivable</a></li>
        </ul>
    </div>
</div>
 
<div class="container-fluid">
    <div class="tab-content">
        <div id="levels" class="tab-pane active">
            <div id="updacc"></div>
            <form id="updateLevel" class="form-horizontal">
                <input type="hidden" class="form-control" name="id" id="id" value="<?= $levels[0]->id;?>">

                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Level Name</label>
                    <div class="col-md-9">
                        <input type="text" class="form-control" name="level" value="<?= $levels[0]->level_name; ?>">
                      
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Government Level</label>
                    <div class="col-md-9">
                        <!-- <input type="text" class="form-control" name="level" value="<?= $levels[0]->g_level; ?>"> -->
                               <select name="glevel" id="glevel" class="form-select form-control form-control-sm" required="required">
         <option value="">--Choose--</option>

<?php if (isset($gvmt_level) && isset($levels[0])): ?>
    <?php foreach ($gvmt_level as $gv_level): ?>
        <?php if ($gv_level->level_id == $levels[0]->level_id): ?>
            <option value="<?= $gv_level->level_id; ?>" selected><?= $gv_level->level_name; ?></option>
        <?php else: ?>
            <option value="<?= $gv_level->level_id; ?>"><?= $gv_level->level_name; ?></option>
        <?php endif; ?>
    <?php endforeach; ?>
<?php endif; ?>
</select>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Applications Fee Charged</label>
                    <div class="col-md-9">
                        <?php

                        ?>
                        <select name="application" id="application" class="form-select form-control form-control-sm" required="required">
                            <option value="">--Choose--</option>

                            <?php
                            
                             if(count($appItems)>0){
                             if(count($leveldatap)>0){
                            foreach ($appItems as $p){ ?>
                                <option value="<?= $p->id; ?>" <?php if($leveldatap[0]->item_id == $p->id){ echo 'selected'; }?>><?= $p->item_name .' '. $p->item_price; ?></option>
                            <?php } 
                        }else{
                             foreach ($appItems as $p){ ?>
                                <option value="<?= $p->id; ?>"><?= $p->item_name .' '. $p->item_price; ?></option>
                            <?php }
                        }
                    }else{
                     echo '<option>No Data</option>'; 
                    }?>

                        </select>
                         <span id="application_error" class="text-danger"></span>
                    </div>
                </div>
              <div class="form-group row">
                    <label class="col-md-3 col-form-label" for="status">Course Period</label>
                    <div class="col-md-9">
                        <select class="form-select form-control form-control-sm" id="cperiod" name="cperiod" >
                            <option value="">-Select-</option>
                            <?php
                            foreach($cperd as $pr){
                                if($pr->id==$levels[0]->academic_type){
                            
                                  ?>
                           <option value="<?php echo $pr->id;?>" selected><?php echo $pr->academic_type;?></option>
                       <?php }else{ ?>
                        <option value="<?php echo $pr->id;?>"><?php echo $pr->academic_type;?></option>
                       <?php } }?>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label" for="status">Status</label>
                    <div class="col-md-9">
                        <select class="form-select form-control form-control-sm" id="status" name="status" >
                            <option value="">-Status-</option>
                            <option value="1" <?php
                            if ($levels[0]->status == 1) {
                                echo 'selected';
                            }
                        ?>>Active</option>
                        <option value="2" <?php
                        if ($levels[0]->status == 2) {
                            echo 'selected';
                        }
                    ?>>Inactive</option>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-md-2 col-form-label"></label>
                    <div class="col-md-10">
                        <button type="submit" class="btn btn-primary float-right">Update</button>
                    </div>
                </div>
            </form>
        </div>
        <div id="items" class="tab-pane">
            <div id="success"></div>
            <form  class="form-horizontal" id="updateTable">
                <input type="hidden" class="form-control" name="level_id" id="levelId" value="<?= $levels[0]->id;?>">

                <div class="form-group row" id="updateCharged_Items">
                    <label class="col-md-2 col-form-label" for="items">Charged Items<span class="text-danger">*</span></label>
                    <div class="col-md-5">
                        <select class="form-select form-control" id="example" style="width:300px;">
                            <option>Select Items to be Charged</option>
                        </select>
						<div class="text-danger" id="select"></div>

                    </div>
                    <div class="col-md-2">
                        <input type="number" id="qtty" class="form-control" min="1">
                    </div>
                    <div class="col-md-1">
                        <button type="button" class="btn btn-primary" id="updateItem"><i class="fa fa-plus"></i></button>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                          <div class="row mt-3 mb-3" style="padding-top:20px;">
                            <label class="col-md-2 col-form-label">Use Type</label>
                    <div class="col-md-3">
                       <select class="form-select form-control" name="item_group" onchange="useGroup(this)">
                           <option value="11">All</option>
                           <option value="0">Other Income</option>
                          <option value="2">New Comer</option>
                       </select>
                    </div>
                   <div class="col-md-3 mt-1">
                            CHARGED ITEMS
                        </div> 
                    </div> 
                            <table class="table table-hover table-vcenter mb-0 text-nowrap">
                                <thead>
                                    <tr>
                                        <th>Item No#</th>
                                        <th>Item Name</th>
                                        <th>Attribute</th>
                                        <th>Size</th>
                                
                                        <th>Qty</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                        <th>use type</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody id="show_item2">
                                 	<!--  -->   
                                </tbody>
                            </table>
                            <table>
                                        <tr>
                                        <th col=3>
                                        <span id="totaly" style="margin-left:450px;"></span>
                                        </th>
                                        </tr>
                            </table>

                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-2 col-form-label"></label>
                    <div class="col-md-10">
                        <button type="submit" class="btn btn-primary float-right">Update</button>
                    </div>
                </div>
            </form>
        </div>
        <div id="ments" class="tab-pane">
            <div id="updacc2"></div>
            <form class="form-horizontal" id="read">
                
                <input type="hidden" class="form-control" name="id" id="id" value="<?= $levels[0]->id;?>">
                <div class="form-group row">
                              <label class="col-md-2 col-form-label">Installment Name<span class="text-danger"></span></label>
                                <div class="col-md-2">
                                    <?php $terms = $cmodel->get_all_terms();?>
                                   <select name="install1" class="form-select">
                                    <option value="" selected>select term</option>
                                    <?php foreach($terms as $term){?>
                                      <option value="<?php echo $term->id;?>"><?php echo $term->term_name; ?></option>
                                      <?php } ?> 
                                   </select>
                                </div> 
                               <label class="col-md-1 col-form-label">Amount<span class="text-danger"></span></label>
                                <div class="col-md-2">
                                    <input type="number"  class="form-control" name="amount1" id="amount" placeholder="">
                                    <span class="text-danger" id="morethan"></span>
                                </div>
                              <!--   <label class="col-md-1 col-form-label">Duedate<span class="text-danger"></span></label>
                                 <div class="col-md-2">
                                    <input type="date" class="form-control" name="duedate1" placeholder="Duedate" id="duedate">
                                </div> -->
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-primary st" id="installupdate"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2"></div>
                                <div class="col-md-12">
                                    <div class="card">
                                        <p Class=" d-flex justify-content-center mt-3">TERMS INSTALLMENT(S)</p>
                                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="">
                                        <thead>
                                                <tr>
                                                    
                                                    <th>Installment Name</th>
                                                    <th>Amount</th>
                                                    
                                                    
                                                    <th>Action</th>
                                                    
                                                </tr>
                                        </thead>
                                        <tbody id="showtbody">

                                    </tbody>
                                        
                                        </table>
                                        <table>
                                        <tr>
                                        <th col=4>
                                        <span id="rem" style="margin-left:200px;"></span>
                                        </th>
                                        </tr>
                                    </table>
                                    </div>
                                </div>
                            </div>
                            
                <div class="form-group row">
                    <label class="col-md-2 col-form-label"></label>
                    <div class="col-md-9">
                        <button type="button" class="btn btn-primary float-right" onclick="submitData2()">Update</button>
                    </div>
                </div>

            </form>
        </div>

                <div id="acctab" class="tab-pane">
            <div id="updatedacc"></div>
            <form class="form-horizontal" id="updateAccount">
                <input type="hidden" class="form-control" name="cid" id="id" value="<?= $levels[0]->id;?>">
            <div class="form-group row">
                    <label class="col-md-2 col-form-label">Account Receivable <span class="text-danger">*</span></label>
                    <div class="col-md-9">
                        <select name="acid" id="acid" class="form-control">
                            <?php 
                           $levid = $cmodel->get_levelAccounts_id($levels[0]->id);
                           //echo $levid[0]->account_receivable;
                            ?>
                            <option value="">--Select Account--</option>
                           <?php foreach ($accounts as $leve): ?>
                                <option value="<?= $leve->id; ?>"  <?php if(count($levid)>0 && $levid[0]->account_receivable == $leve->id){ echo 'selected'; } ?>><?= $leve->account_name; ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-2 col-form-label"></label>
                    <div class="col-md-9">
                        <button type="submit" class="btn btn-primary float-right">Update</button>
                    </div>
                </div>
            </form>
    </div>
    </div>
</div>



<!--<script src="<?php //echo base_url('public/assets/plugins/select2/select2.js')?>"></script>-->
<script type="text/javascript">
   var hold_selected_items = [];


    $(document).ready(function(){
        fetch_installment_data();
        fetch_level_itemsCharged();
       $('#example').select2({

            ajax: {
                url: "<?= base_url('load_datalv'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

        $('#example').on('select2:select', function (e) {
            selectedItems();
        });
             
          function selectedItems(){
          var levelId = $('#levelId').val();			  
           var rows = '';
           var itemData = 'item_selected='+$('#example').val()+'&selected_items_array='+hold_selected_items;
          // alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Itemdata2')?>/"+levelId, 
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
						 $('#select').html('The Item Already Selected.');
                        //alert('The Item Already Selected');
                    }
						//  $('#select').html('');
                        // var len  = data.length;

                        // for (var i = 0; i <len; i++ ){
                        //     hold_selected_items.push(data[i]['id']);// push all selected items
                        //     var prc = data[i]['iprice'];
                        //     var name = data[i]['iname'];
                        //     var iid = data[i]['id'];
                        //     var size = data[i]['isize'];
                        //     var attr = data[i]['iattr'];
                        //     var uom = data[i]['iattr'];
                        //     var ttl = data[i]['iattr'];

                        
                            
                        //    rows += '<tr id="table_row'+ iid +'">';

                        //    rows+='<td><input type="hidden" name="id[]" value="'+iid+'">'+ iid +'</td>';
							
                        //     rows += '<td>'+ name +'</td>';
                        //     rows += '<td>'+ attr +'</td>';
                        //     rows += '<td>'+ size +'</td>';
                        //     rows += '<td>'+ 1 +'</td>';
                        //     rows += '<td><input type="number" name="qty'+iid+'" id="qty'+iid+'" onkeyup=mult('+iid+'); style="width:45px" required="required"></td>';
                        //     rows += '<td id="item_price'+iid+'">'+ prc +'</td>';
                        //     rows += '<td id="tprice'+iid+'"></td>';

                        //     rows += '<td><a href="javascript:RemoveSelectItemRow('+iid+');">X</a></td>';
							
                        //     rows += '</tr>';
                        //     $('#show_item2').append(rows);
                        // }
                      },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }  
           });  
        } 
    }); 

	  $('#updateItemlv').click(function(e){

        var data = "item=" + $('#example').val() + "&quantity=" + $('#qtty').val()+ '&id=' + $('input[name=id]').val()+ '&account=' + $('input[name=account]').val();
        // alert(data);
        // return;

        $.ajax({
            type: 'POST',
            url: 'add_level_Item',
            data: data,
            success:function(){
                $('#example').val('');
                $('input[name=qtty]').val('');
                fetch_level_itemsCharged();
                fetch_installment_data();
            }
       });

        e.preventDefault();
    });

      function fetch_level_itemsCharged(){
        $('#show_item2').empty();     
        
        var data = 'level_id=<?= $levelID; ?>';
        $.ajax({
            type: 'GET',
            data: data,
            url: 'fetch_levelItems_data',
            success:function(res){

                var level_data = JSON.parse(res);
                var len = level_data.length;
                var sum=0;
                for(var i = 0; i < len; i++){

                    var group = level_data[i]['item_group'];
                    var grp="";
                    // if(group==0){
                    //     grp="Other Item";
                    // }else if(group==1){
                    //     grp="Application";
                    // }else if(group==2){
                    //     grp="New Comer";
                    // }
                    var qty = level_data[i]['quantity'];
                    var price = level_data[i]['price'];
                    var ttl = qty * price;
                     sum=sum+ttl;
                    var account = level_data[i]['account'];
                    $('#total').val(ttl);
                    document.getElementById("totaly").innerHTML = "Total = " + sum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                    console.log(sum);
                    window.sum=sum;
                    //$('#sum').val(sum);


                    $('#show_item2').append('<tr>'+
                        '<td><input type="hidden" name="account" value="'+account+'">'+level_data[i]['item_id']+'</td>\
                        <td>'+level_data[i]['name']+'</td>\
                        <td>'+level_data[i]['attribute']+'</td>\
                        <td>'+level_data[i]['size']+'</td>\
                        <td>'+qty+'</td>\
                        <td>'+price+'</td>\
                        <td id="total">'+ttl+'</td>\
                        <td id="grp">'+group+'</td>\
                        <td>\
                            <a href="javascript:deleteitem('+level_data[i]['id']+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                    
                }
                //return sum;
            }
            
        });
        
    }
    function useGroup(id){
        var data = 'item_group=' + id.value;
        $('#show_item2').empty();     
         var sum=0;
        var data =  'level_id=<?= $levelID;?>'+ '&item_group=' + id.value;
        $.ajax({
            type: 'GET',
            data: data,
            url: 'fetch_lItems_data',
            success:function(res){
             
            
                var level_data = JSON.parse(res);
                var len = level_data.length;
                var sum=0;
                for(var i = 0; i < len; i++){

                    var group = level_data[i]['item_group'];
                    var grp="";
                    // if(group==0){
                    //     grp="Other Item";
                    // }else if(group==1){
                    //     grp="Application";
                    // }else if(group==2){
                    //     grp="New Comer";
                    // }
                    var qty = level_data[i]['quantity'];
                    var price = level_data[i]['price'];
                    var ttl = qty * price;
                     sum=sum+ttl;
                    var account = level_data[i]['account'];
                    $('#total').val(ttl);
                   
                    //$('#sum').val(sum);


                    $('#show_item2').append('<tr>'+
                        '<td><input type="hidden" name="account" value="'+account+'">'+level_data[i]['item_id']+'</td>\
                        <td>'+level_data[i]['name']+'</td>\
                        <td>'+level_data[i]['attribute']+'</td>\
                        <td>'+level_data[i]['size']+'</td>\
                        <td>'+qty+'</td>\
                        <td>'+price+'</td>\
                        <td id="total">'+ttl+'</td>\
                        <td id="grp">'+group+'</td>\
                        <td>\
                            <a href="javascript:deleteitem('+level_data[i]['id']+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                    
                }
             document.getElementById("totaly").innerHTML = "Total = " + sum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                    console.log(sum);
                    window.sum=sum;

            }
            
        });
        
    }
function mult(iid){
	var totalPrice = $('#qty'+iid).val()* $('#item_price'+iid).html()        
	document.getElementById('tprice'+iid).value = 		
	totalPrice.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 	
}		
function RemoveSelectItemRow(item_id){
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }

        $('#table_row'+item_id).remove();
    }


  $('#updateItem').click(function(e){

        var data = "item=" + $('#example').val() + "&quantity=" + $('#qtty').val()+ '&id=' + $('input[name=id]').val();

        $.ajax({
            type: 'POST',
            url: 'add_anotherItem',
            data: data,
            success:function(){
                fetch_level_itemsCharged();
            }
       });

        e.preventDefault();
    });

   function submitlevelData(){
        $('#updacc1').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
        setTimeout(function(){
            window.location.reload();
        },1000)
    }

$('#updateTable').submit(function(e){
		//var Data=$(this).serialize();
       
           //alert(Data);

        // $.ajax({
        //     method: 'POST',
        //     url: '<?= base_url('editLevelItems')?>',
        //     data: Data,
		// 	dataType: 'json',
        //      success:function(data){
			$('#success').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
        //         setTimeout(function(){
        //     window.location.reload();
        // },1000)
        //     },
        //     error:function(data){
		// 		$('#success').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>'); 
        //   setTimeout(function(){
        //     window.location.reload();
        // },1000)
        //     }
       // });
        
        e.preventDefault();
    });
	
    function deleteitem(id){
       // var id = $(this).attr('data-id');
        //alert (id);
      
           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this item!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('/deletelevelItem')?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      // $("#"+id).remove();
					  fetch_installment_data();
                       fetch_level_itemsCharged();
                    swal("Deleted!", "Item deleted.", "success");
                    //location.reload(true);
                    $("#"+id).remove();  
                 }
              });

            } else {
               swal("Cancelled");
            }

          });
       }

        $('#installupdate').click(function(event){
            var id=<?= $levels[0]->id;?>;
       var data = 'installname=' + $('select[name=install1]').val() + '&amount=' + $('input[name=amount1]').val()+ '&id=' + $('input[name=id]').val();
       //alert(ttl);
       if(ttl==undefined){
        remain=10000000;
       }
       //alert(remain);
       var enteredAmount=$('input[name=amount1]').val();
       
       var present=remain-enteredAmount;
       //alert(present);
       if(present>=0){
         document.getElementById("morethan").innerHTML="";  
       $.ajax({
            type: 'POST',
            url: 'addinstallments3/'+id,
            data: data,
            success:function(data){
                 if(data==1){
                alert("Term, Already Selected");
                present=remain+enteredAmount;
                }
                fetch_installment_data();
            }
       });
      }else{
        document.getElementById("morethan").innerHTML="Enter less amount or equal to "+remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
     // $('input[name=amount1]').val()="";    
      }
        event.preventDefault();
    });
    var ttl;
    var remain;
 function fetch_installment_data(){
        $('#showtbody').empty();
                
        var datta = 'level_id=<?=$levels[0]->id; ?>';
        //alert(data);
        $.ajax({
            type: 'GET',
            data: datta,
            url: 'fetchinstallments3',
            success:function(response){
                console.log(response);
                var ments_data = JSON.parse(response);
                var len = ments_data.length;
                //total=fetch_class_itemsCharged();
                var ttlamount=0;
                for(var i = 0; i < len; i++){
                    total=ments_data[0]['tprice'];
                    var amounted=parseInt(ments_data[i]['amount']);
                    ttlamount=parseInt(ttlamount+amounted);
                    $('#showtbody').append('<tr>'+
                        
                        '<td>'+ments_data[i]['installname']+'</td>\
                        <td>'+ments_data[i]['amount']+'</td>\
                        <td>\
                            <a href="javascript:RemoveRow('+ments_data[i]['id']+','+total+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
        //total=window.sum;
        total=ments_data[0]['tprice'];
        remain=total-ttlamount;
        ttl=remain;
        document.getElementById("rem").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        document.getElementById("totaly").innerHTML = "Total = " + total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(total);
            }
        });
        
    }
    function RemoveRow(id,total){

        $.ajax({
            type: 'GET',
            url: 'deleteMents/'+id,
            success: function(){
                
                alert('deleted successfuly');
         remain= total;
         document.getElementById("rem").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(remain);
         fetch_installment_data();
            }
        });

    }
    function submitData2(){
        $('#updacc2').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
        setTimeout(function(){
            window.location.reload();
        },1000)
    }

     $('#updateLevel').submit(function(e){
        //alert($(this).serialize());
        $.ajax({
            type: 'POST',
            url: '<?= base_url('/updateLvel') ?>',
            data: $(this).serialize(),
            success: function (res) {
                $('#updacc').html(res);
                setTimeout(function(){
                     window.location.reload();
                },1000)
            },
            error: function () {
                $('#updacc').html('Error! Couldnt Update Level.');            }
        });
        //alert($(this).serialize());
        e.preventDefault();
    });

      $('#updateAccount').submit(function(e){
       var data = 'lid=' + $('input[name=cid]').val() + '&acid=' + $('select[name=acid]').val();
       //alert(data);

       $.ajax({
            type: 'POST',
            url: 'updateAccountLevel',
            data: data,
            success:function(data){
                $('#updatedacc').html(data);
            // setTimeout(function(){
            //      window.location.reload();
            // },1000)
            }
       });

        event.preventDefault();
    });

</script>
