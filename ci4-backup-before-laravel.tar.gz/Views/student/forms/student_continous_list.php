 <?php 
    helper('age');
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();

    $student = $smodel->gettable_data('students', $where = array('status' => 2));
    $thisClass=$classId;
    //echo $classId;
     if($classId==20 && session()->get('db_id')==7){
       $classId=10; 
    }
     if($classId==20 && session()->get('db_id')==8){
       $classId=10; 
    }
    
     if($classId==2 && session()->get('db_id')==6){
       $classId=3;
        //echo $classId;
    }else if($classId==4 && session()->get('db_id')==6){
       $classId=5; 
      // echo $classId;
    }else if($classId==6 && session()->get('db_id')==6){
       $classId=0; 
       //echo $classId;
    }else if($classId==1 && session()->get('db_id')==6){
       $classId=2; 
      // echo $classId;
    }else if($classId==3 && session()->get('db_id')==6){
       $classId=6; 
      // echo $classId;
    }
    else if($classId==7 && session()->get('db_id')==6){
       $classId=4;
     //  echo $classId;
    }
    else if($classId==5 && session()->get('db_id')==6){
       $classId=7; 
    //   echo $classId;
    }
    
    $clas = $smodel->gettable_data('classes_tbl', $where = array('id'=>$classId+1,'status' => 1));
   
 $DB_ID=session()->get('db_id');
    $comeYear=$year+1;
    $date='01/08/'.$comeYear;
 $date=date("Y-m-d",strtotime($date));
 if($classId==10 && $DB_ID==1){}else{
?>
           <form id="admission_details" class="form-inline">
 <div class="card">
          <div class="d-flex justify-content-center mt-3 mb-3">
                  
                         Academic year: <?php echo $year+1; ?>
                         <div class="input-group ms-3 me-5">
                             <input type="hidden" name="Academic_year" value="<?php echo $year+1;?>">
                        </div>
                        Admission date:
                        <div class="input-group ms-3 me-3">
                        <input type="date" name="admission_date" value="<?php echo $date; ?>" class="form-control">
                        </div>
                        <div class="input-group ms-3 me-5">
                        </div>
                        Admission class: <?php echo $clas[0]->class_name;?>
                        <input type="hidden" name="class" value="<?php echo $clas[0]->id;?>">
                        <input type="hidden" name="class_level" value="<?php echo $clas[0]->class_level;?>">
                 
                        <div class="input-group ms-3 me-5">
                        </div>
            
                 <?php if($classId==10 && $DB_ID==1){
                       }else{
                      
                        ?>
                      <button type="button" id="saveAdmission" onclick="save_admission()" class="btn btn-primary btn-lg pull-right "><i class=""> </i> Admit</button>
                        <?php
                      
                    }
                     ?>
                            </div>
                            <!--------------------------------------------------->
  
                              </div>
                              <?php
                                }
                              ?>
 
                    <div class="card">
                         
                    <div class="table-responsive mt-1">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                     <td> <input type="checkbox" name="" value="" onclick="Allcheckbox()" id="Allselected"> All</td>
                                    <th>Names</th>
                                    <th>Birth Date</th>
                                    <th>Age </th>
                                    <th>Gender</th>
                                    <th>Current Class</th>
                                    <th>Stream/Comb</th>
                                    <th>Type</th>
                                    <th>For</th>
                                    <th>School Fees</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $class = "";
                                $row ="";
                                $i=0;
                                //$lastYr=$year-1;
                                $holid_student=array();
                                if($classId==10 && $DB_ID==1){}else{
                            foreach ($student as $st){
                                $details= $smodel->gettable_data('admission_tbl', $where = array('student_id' => $st->id,'academic_year'=>$year,'class_id'=>$thisClass));
                               //print_r($details);
                                
                                // echo $lastYr;
                                // echo 'class='.$classId;
                                // print_r($details);
                                if(count($details)>0){
                                 foreach ($details as $dt){

                                    //getting streams
                                $stream_res= $smodel->gettable_data('streams_tbl', $where = array('id' => $dt->stream_id));
                                $stream_results= $smodel->gettable_data('streams_tbl', $where = array('class_id' =>$clas[0]->id,'stream_name'=> $stream_res[0]->stream_name));
                                  
                                  if(count($stream_results)==0){
                                $stream_results= $smodel->gettable_data('streams_tbl', $where = array('class_id' =>$clas[0]->id));   
                                  }  
                                    if($dt->admission_type==0){
                                        $adType='Day';
                                    }else{
                                     $adType='Boarding';   
                                    }
                                
                                $admission = $smodel->gettable_data('admission_tbl', $where = array('student_id' => $st->id,'academic_year'=>$year+1,'class_id'=>$clas[0]->id));
                                    if(count($admission) > 0){
                                        $row = 'color:#804000';
                                        continue;
                                    }else{
                                     $i++;
                                        $row = 'color:#27af50';
                                     $className = $smodel->gettable_data('classes_tbl', $where = array('id'=>$thisClass,'status' => 1));  
                                      $stream = $smodel->gettable_data('streams_tbl', $where = array('id'=>$dt->stream_id,'status' => 1)); 
                                        $comb= $amodel->get_stream_comb_allocatiion($dt->stream_id);
                                      ///fee calculation here
                                      $levelFee=$amodel->fetch_classLevel_fee(0,$clas[0]->class_level);
                                      
                                      
                                      $levelPrice=0;
                                      $totalFee=0;
                                      foreach($levelFee as $lv){
                                      if($lv->item_group==7){
                               
                                    $levelPrice=$levelPrice-$lv->item_price;
                                   
                                    
                                        }else{
                                   
                                     $levelPrice=$levelPrice+$lv->item_price;
                                            }
                                      }
                                      
                                      //for class
                                      $classPrice=0;
                                       $db_id=session()->get('db_id');
                                      if($classId==3 && $db_id ==1){
                                        $admFor='NewComer';
                                        ?>
                                        <input type="hidden" id="for<?= $st->id;?>" name="for<?= $st->id;?>" value="2"/>
                                        <?php
                                    
                                  ///////start///////////////
                                       
                                        $classFee=$amodel->fetch_class_fee(2,$classId+1);
                                     foreach($classFee as $cl){
                                     if($cl->item_group==7){
                                   $classPrice-=$cl->item_price;
                                        }else{
                                    $classPrice+=$cl->item_price;
                                            }
                                     //echo $cl->item_price.'/'.$cl->item_id.'</br>';
                                      }
                                    $totalFee=$levelPrice+$classPrice;
                                    //   echo $levelPrice.'/cl-'.$classPrice;
                                    //   return;
                                    //for Boarding
                                     $bPrice=0;
                                $bFee=$amodel->fetch_boarding_fee(2,$classId+1);
                                if($dt->admission_type==3 && count($bFee)>0){
                                foreach($bFee as $bf){
                                    $bPrice+=$bf->item_price;
                                      }
                                    $totalFee=$totalFee+$bPrice;
                                }
                                
                                $bFee=$amodel->fetch_boarding_fee2(2,$clas[0]->class_level);
                                 $bPrice2=0;
                                if($dt->admission_type==3 && count($bFee)>0){
                                foreach($bFee as $bf){
                                    $bPrice2+=$bf->item_price;
                                   
                                      }
                                      
                                    $totalFee=$totalFee+$bPrice2;
                                }
                                ///////end///////////////
                                      }else{
                                        $admFor='Continous';
                                        ?>
                                        <input type="hidden" id="for<?= $st->id;?>"  name="for<?= $st->id;?>" value="0"/>
                                        <?php
                               ///////start///////////////
                                        $classFee=$amodel->fetch_class_fee(0,$classId+1);
                                     foreach($classFee as $cl){
                                    $classPrice+=$cl->item_price;
                                    
                                    // echo $cl->item_price.'/'.$cl->item_id.'</br>';
                                      }
                                    $totalFee=$levelPrice+$classPrice;

                                    //for Boarding
                                     $bPrice=0;
                                $bFee=$amodel->fetch_boarding_fee(0,$classId+1);
                                if($dt->admission_type==3 && count($bFee)>0){
                                foreach($bFee as $bf){
                                    $bPrice+=$bf->item_price;
                                      }
                                    $totalFee=$totalFee+$bPrice;
                                }
                                
                                $bFee=$amodel->fetch_boarding_fee2(0,$clas[0]->class_level);
                                 $bPrice2=0;
                                if($dt->admission_type==3 && count($bFee)>0){
                                foreach($bFee as $bf){
                                    $bPrice2+=$bf->item_price;
                                   
                                      }
                                      
                                    $totalFee=$totalFee+$bPrice2;
                                }
                                ///////end///////////////
                              }
                              $requiredFee=0;
                               $check_bal = $smodel->gettable_data('student_balance_tbl', $where = array('student_id'=>$st->id,'year' =>$year));
                               if(count($check_bal)>0){
                                $requiredFee=$totalFee+$check_bal[0]->balance;
                               }else{
                                $requiredFee=$totalFee;
                               } 
                                $holid_student[]=array($st->id);
                                 ?>
                    
                     <input type="hidden" name="stream<?= $st->id;?>" value="<?= $stream_results[0]->id;?>"/> 
                     <input type="hidden" name="hstl<?= $st->id;?>" value="<?= $details[0]->hostel_id;?>"/> 
                    <input type="hidden" name="admission_type<?= $st->id;?>" value="<?=$dt->admission_type;?>"/>
                     <input type="hidden" name="total_fee<?= $st->id;?>" value="<?=$requiredFee;?>"/>
                    <?php //if($classId==3){
                        ?>
                         <?php
                     // }else{?>
                    
                                     <tr style="<?php echo $row;?>" onclick="selectRow('<?php echo $st->id; ?>')" id="<?php echo $st->id; ?>">
                                         <td><?= $i;?></td>
                                        <td>  <input type="checkbox" name="selected[]" value="<?php echo $st->id; ?>" onclick="checkbox('<?php echo $st->id; ?>')" id="selected<?php echo $st->id; ?>"></td>
                                       
                                       
                                        <td><?= $st->first_name.' '. $st->middle_name.' '.$st->last_name;?></td>
                                        <td><?= $st->birth_date;?></td>
                                        <td><?= findAge($st->birth_date);?></td>
                                         <td><?= $st->gender;?></td>
                                         <td><?= $className[0]->class_name;?></td>
                                         <td><?= $stream_results[0]->stream_name;?>
                                          <?php if (isset($comb[0])): ?>
                                            (<?= $comb[0]->comb_name; ?>)
                                            <?php else: ?>
                                            (no comb)
                                            <?php endif; ?></td>
                                         <td><?= $adType;?></td>
                                         <td><?= $admFor;?></td>
                                         <td><?= number_format($totalFee);?></td>
                                        <td>
                                          <button type="button" class="btn btn-primary btn-sm AdmitID" onclick="AdmitID(<?= $st->id;?>,<?=$clas[0]->class_level;?>,<?=$classId+1;?>,<?= $details[0]->stream_id;?>,<?=$dt->admission_type;?>)" data-id="<?= $st->id;?>"><i class="fa fa-edit"></i> Edit</button>
                                        </td>
                                    </tr> 
                                <?php }
                                    }
                                    }
                                }
                           // }
                                 }?>
                            </tbody>
                        </table>
                    </div>
                    </form>
         <div class="row mb-12 me-3 mt-3">
    <div class="col-sm-4"></div>
    <div class="col-sm-2 offset-sm-6">
        
         
                </div>
                </div>
                <script type="text/javascript">
    // $(document).ready(function () {
    //   $('#myTable').DataTable();
    // });
   function AdmitID(id,lv,cl,str,bd) {
            var fortype=$('#for'+id).val();
         var data = 'id=' + id+'&year='+'<?php echo $year;?>'+'&level='+lv+'&class='+cl+'&bod='+bd+'&stream='+str+'&for='+fortype;
         //alert (data);

        $('#myModal').modal('show');
        $.ajax({
            type: "GET",
            url: "admission_details",
            data: data,
            beforSend: function()
            {
                $('#admission').html();
            },
            success: function(res){
                $('#admission').html(res);
                 
            },
            error: function ()
            {

            }
        });
    };
      function save_admission() {
          var data=$('#admission_details').serialize()+'&'+$('#header_form').serialize();
             // alert(data);
             // return;
            $.ajax({
                type: "POST",
              url: '<?php echo base_url() . '/index.php/AdmissionController/continous_admission'; ?>',
                data: data,
                success: function (res) {
                    refreshPage();
                    if(res){
                      
                         swal('success','Students admitted successfuly','success');
                         
                    }else{
                        swal('error','something went wrong','error'); 
                    }
                
                },
                error: function () {
                    alert('something went wrong');
                }
            });
        };
      function refreshPage(){
        $('#pending_results').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
        var dta = "year=" + $('#cyear option:selected').val()+'&class='+ $('#class option:selected').val();
         // alert(dta);
         $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_pending_continous'; ?>',
                data: dta,
                success: function (res) {
                    $('#pending_results').html(res);
                },
                error: function () {
                    $('#pending_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
      }

      function selectRow(id){
         var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {
    row.style.backgroundColor = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {

    row.style.backgroundColor = 'black';
  } else {
    console.error("Invalid row ID");
  }  
        }
      
      }
      function checkbox(id){
        var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {

    row.style.backgroundColor = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {
    row.style.backgroundColor = 'black';
  } else {
    console.error("Invalid row ID");
  }  
        } 
      }
      function Allcheckbox(){
        var values=<?php echo json_encode($holid_student);?>;
        //alert(values.length);
        var rememberAll = document.getElementById("Allselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
            if(rememberAll.checked){
     remember.checked=true;  
      if (row) {
    
    row.style.backgroundColor = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=false; 
      
       if (row) {
      row.style.backgroundColor = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        }
        }
      }
</script>