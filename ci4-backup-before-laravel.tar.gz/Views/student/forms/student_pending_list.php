 <?php 
    helper('age');
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();

    $student = $smodel->gettable_data('students', $where = array('initial_class' =>$iclass,'status !='=>2));
   // print_r($student);
    $lv = $smodel->gettable_data('classes_tbl', $where = array('id' => $iclass));

?>

    <form id="admission_details" class="">
 <input type="hidden" name="class_level" value="<?= $lv[0]->class_level;?>"/> 
         <input type="hidden" name="class" value="<?= $iclass;?>"/> 
         <input type="hidden" name="stream" value="<?= $stream;?>"/> 
         <input type="hidden" name="for" value="<?= $adfor;?>"/> 
        
                    <?php
                    if($bod==3){
                        ?>
                     <input type="hidden" name="hstl" value="<?= $hostel;?>"/> 
                     <?php
                    }else{
                        ?>
                  <input type="hidden" name="hstl" value="0"/> 
                        <?php

                           }?>
                    <input type="hidden" name="admission_type" value="<?=$bod;?>"/>
        <button type="button" id="saveAdmission" onclick="save_admission()" class="btn btn-primary btn-lg pull-right mb-3" style="margin-right: 50px;"><i class=""> </i> Admit</button>
         <div class="card">
                    
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable1">
                             <thead>
                                <tr>
                                    <th>#</th>
                                     <td> <input type="checkbox" name="" value="" onclick="Allcheckbox()" id="Allselected"> All</td>
                                    <th>Names</th>
                                    <th>Birth Date</th>
                                    <th>Age </th>
                                    <th>Gender</th>
                                    <th>Class</th>
                                    <th>Stream/Comb</th>
                                    <th>Type</th>
                                    <th>For</th>
                                    <th>School Fees</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                
                                $class = "";
                                
                                $row ="";
                                  $holid_student=array();
                                  $i=0;
                                foreach ($student as $st){
                                    $cname="";
                                    $bPrice=0;
                                    $i++;
                            $stream_result= $smodel->gettable_data('streams_tbl', $where = array('id' =>$stream));
                             $comb= $amodel->get_stream_comb_allocatiion($stream);
                            if($bod==0){
                                $adType='Day';
                                 }else{
                                 $adType='Boarding';   
                                 }
                                  
                             $cla = $smodel->gettable_data('classes_tbl', $where = array('id'=>$iclass,'status' => 1)); 

                               ///fee calculation here
                                      if($adfor==0){
                                $levelFee=$amodel->fetch_classLevel_fee(0,$cla[0]->class_level);
                            }else{
                               $levelFee=$amodel->fetch_classLevel_fee(2,$cla[0]->class_level); 
                            }
                                      $levelPrice=0;
                                       $classPrice=0;
                                      $totalFee=0;
                                     // print_r($levelFee);return;
                                      foreach($levelFee as $lv){
                                           
                                   
                                       if($lv->item_group==7){
                                   
                                    $levelPrice=$levelPrice-$lv->item_price;
                                        }else{
                                   
                                     $levelPrice=$levelPrice+$lv->item_price;
                                            }
                                    // echo 'lvamot='. $levelPrice.'</br>';
                                      }
                                     
                                 if($adfor==0){
                                    $admFor='Continous';
                                    $classFee=$amodel->fetch_class_fee(0,$iclass);
                                   // echo $classPrice;
                                     foreach($classFee as $cl){
                                     if($cl->item_group==7){
                                   $classPrice-=$cl->item_price;
                                        }else{
                                    $classPrice+=$cl->item_price;
                                            }
                                        
                                    //  echo 'cl+='. $cl->item_price.'/';
                                    //  echo 'cl='. $classPrice.'</br>';
                                      }
                                 // return;
                                    $totalFee=$levelPrice+$classPrice; 
                                   
                                      
                                 $bFee=$amodel->fetch_boarding_fee(0,$iclass);
                                
                                if($bod==3 && count($bFee)>0){
                                foreach($bFee as $bf){
                                    $bPrice+=$bf->item_price;
                                   // echo 'bd='. $bf->item_price.'</br>';
                                      }
                                    $totalFee=$totalFee+$bPrice;
                                }

                                $bFee=$amodel->fetch_boarding_fee2(0,$cla[0]->class_level);
                                 $bPrice2=0;
                                if($bod==3 && count($bFee)>0){
                                foreach($bFee as $bf){
                                    $bPrice2+=$bf->item_price;
                                   
                                      }
                                      
                                    $totalFee=$totalFee+$bPrice2;
                                }

                                }else{
                                    $admFor='New Comer';
                                    $classFee=$amodel->fetch_class_fee(2,$iclass);
                                     foreach($classFee as $cl){
                                    $classPrice+=$cl->item_price;
                                    
                                      }
                                    $totalFee=$levelPrice+$classPrice;

                           
                              $bFee=$amodel->fetch_boarding_fee(2,$iclass);
                                if($bod==3 && count($bFee)>0){
                                foreach($bFee as $bf){
                                  //  $bPrice+=$bf->item_price;
                                    $totalFee=$totalFee+$bf->item_price;
                                      }
                                    
                                }
                          
                                 $bFee=$amodel->fetch_boarding_fee2(2,$cla[0]->class_level);  
                                
                                if($bod==3 && count($bFee)>0){
                                foreach($bFee as $bf){
                                     $totalFee=$totalFee+$bf->item_price;
                                      }
                                   // $totalFee=$totalFee+$bPrice;
                                }
                                
                                }
                               
                                   $holid_student[]=array($st->id);
                                 ?>
                   
                     <input type="hidden" name="total_fee<?= $st->id;?>" value="<?=$totalFee;?>"/>
                                   <tr style="<?php echo $row;?>" onclick="selectRow('<?php echo $st->id; ?>')" id="<?php echo $st->id; ?>">
                                         <td><?= $i;?></td>
                                        <td>  <input type="checkbox" name="selected[]" value="<?php echo $st->id; ?>" onclick="checkbox('<?php echo $st->id; ?>')" id="selected<?php echo $st->id; ?>"></td>
                                       
                                       
                                        <td><?= $st->first_name.' '. $st->middle_name.' '.$st->last_name;?></td>
                                        <td><?= $st->birth_date;?></td>
                                        <td><?= findAge($st->birth_date);?></td>
                                         <td><?= $st->gender;?></td>
                                         <td><?= $cla[0]->class_name;?></td>
                                         <td><?= $stream_result[0]->stream_name;?>
                                           <?php if (isset($comb[0])): ?>
                                                (<?= $comb[0]->comb_name; ?>)
                                            <?php else: ?>
                                                (no comb)
                                            <?php endif; ?>
                                         </td>
                                         <td><?= $adType;?></td>
                                         <td><?= $admFor;?></td>
                                         <td class="text-right"><?= number_format($totalFee);?></td>
                                        <td>
                                          <button type="button" class="btn btn-primary btn-sm AdmitID" onclick="AdmitID(<?= $st->id;?>,<?=$cla[0]->class_level;?>,<?=$iclass;?>,<?= $stream;?>,<?=$adfor;?>)" data-id="<?= $st->id;?>"><i class="fa fa-edit"></i> Edit</button>
                                        </td>
                                    </tr> 
                                <?php 
                                    }
                                 ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                 </form>
                <script type="text/javascript">
    $(document).ready(function () {
      $('#myTable').DataTable();
    });
     $(".AdmitID").click(function () {
           var data = 'id=' + $(this).attr('data-id')+'&year='+ $('#year option:selected').val();
         //alert (data);

        $('#myModal').modal('show');
        $.ajax({
            type: "GET",
             url: '<?php echo base_url() . '/index.php/AdmissionController/student_pending_details'; ?>',
            data: data,
            beforSend: function()
            {
                $('#admission').html();
            },
            success: function(res){
                $('#admission').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
      function selectRow(id){
         var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {
    row.style.backgroundColor = 'white';
     row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {

    row.style.backgroundColor = 'black';
     row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        }
      
      }

 function checkbox(id){
        var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {

    row.style.backgroundColor = 'white';
     row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {
    row.style.backgroundColor = 'black';
     row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        } 
      }
  function Allcheckbox(){
        var values=<?php echo json_encode($holid_student);?>;
        //alert(values.length);
        var rememberAll = document.getElementById("Allselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
            if(rememberAll.checked){
     remember.checked=true;  
      if (row) {
    row.style.backgroundColor = 'black';
     row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=false; 
      
       if (row) {
      row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }  
        }
        }
      }

      function save_admission() {
          var data=$('#admission_details').serialize()+'&'+$('#pending').serialize()+'&'+$('#header_form').serialize()+'&admission_date='+$('#admission_date').val()+'&class_id='+$('#classification_id').val();
              //alert(data);
             // return;
            $.ajax({
                type: "POST",
              url: '<?php echo base_url() . '/index.php/SemisterController/new_admission'; ?>',
                data: data,
                success: function (res) {
                    refreshPage();
                    if(res){
                       if(res=="2"){
                         swal('error','Please set account receivable on class level','error');  
                       }else{
                         swal('success','Students admitted successfuly','success');
                       }
                         
                    }else{
                        swal('error','something went wrong','error'); 
                    }
                
                },
                error: function () {
                    alert('something went wrong');
                }
            });
        };
      function refreshPage(){
        $('#student_results').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
        var dta = $('#load_students').serialize();
         // alert(dta);
         $.ajax({
                type: "POST",
              //  url: '<?php echo base_url() . '/class_list2'; ?>',
                url: '<?php echo base_url() . '/index.php/SemisterController/get_pending'; ?>',
                data: dta,
                success: function (res) {
                    $('#student_results').html(res);
                },
                error: function () {
                    $('#student_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
      }
</script>