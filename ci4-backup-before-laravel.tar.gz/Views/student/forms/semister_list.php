 <?php 

    $cmodel = new App\Models\ClassesModel();
  $smodel = new App\Models\StudentModel();

     $schoolTerms = $cmodel->Load_SchoolTerms($year);
     //print_r($schoolTerms);
?>
 <div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                    <th>No.#</th>
                                  <th>Academic year</th>
                                  <th>Course Period</th>
                                    <th>Term Name</th>
                                    <th>Description</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Due Date</th>
                                    <th>Status</th>
                                    <th>Updated By</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $sn = "0"; $status="";
                                if(count($schoolTerms)>0){
                                  //  print_r($schoolTerms);
                                 foreach ($schoolTerms as $terms): $sn++; if($terms->status == 1){
                                    $status = "<b style='color:green;'>Active</b>";
                                }else{$status = "<b style='color:red;'>Inactive</b>";
                            } 
                            $period = $smodel->gettable_data('academic_types_tbl', $where = array('id' => $terms->type_id));
                            if(count($period)>0){
                                $per=$period[0]->academic_type;
                            }else{
                                $per="";
                            }

                                ?>
                                    <tr>
                                        <td><?= $terms->id; ?></td>
                                        <td><?= $terms->academic_year; ?></td>
                                        <td><?= $per; ?></td>
                                        <td><?= $terms->term_name; ?></td>
                                        <td><?= $terms->description; ?></td>
                                        <td><?= date('d-M-Y',strtotime($terms->start_date)); ?></td>
                                        <td><?= date('d-M-Y',strtotime($terms->end_date)); ?></td>
                                        <td><?= date('d-M-Y',strtotime($terms->due_date)); ?></td>
                                        <td><?= $status; ?></td>
                                         <td><?= $terms->first_name.' '.$terms->last_name; ?></td>
                                        <td>
                                            <button type="button" class="btn btn-primary btn-sm UpdateID" data-id="<?= $terms->id;?>"><i class="fa fa-edit"></i> Edit</button>
                                            <button type="button" class="btn btn-primary btn-sm viewID" data-id="<?= $terms->id;?>"><i class="fa fa-eye"></i> View</button>
                                            <!-- <button type="button" class="btn btn-danger btn-sm deleteID"  data-id="<?php //echo $terms->id;?>"><i class="fa fa-trash"></i></button> -->
                                        </td>
                                    </tr>
                                <?php endforeach; 
                                 }else{
                                    echo "<tr><td colspan='4'></td><td>No data available</td></tr>";
                                 }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
        <script type="text/javascript">
           $(".UpdateID").click(function () {
        var data = 'id=' + $(this).attr('data-id');
        // alert (data);
        $('#myModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?= base_url('/editSchoolTerm')?>",
            data: data,
            beforSend: function()
            {
                $('#UpdateTerm').html();
            },
            success: function(res){
                $('#UpdateTerm').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
 
  $(".viewID").click(function () {
        var data = 'id=' + $(this).attr('data-id');
        // alert (data);
        $('#viewModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?= base_url('/viewSchoolTerm')?>",
            data: data,
            beforSend: function()
            {
                $('#viewTerm').html();
            },
            success: function(res){
                $('#viewTerm').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
                </script>