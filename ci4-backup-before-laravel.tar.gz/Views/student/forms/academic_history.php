<style>
    table.term2, th.term2, td.term1{
        background-color: #81a6fd;
        border: 1px solid black;
    }
    table.term1, th.term1{
        background-color: #3ddeff;
        border: 1px solid black;
    }
       table.term1, td.term1{
        background-color: #ccffff;
        border: 1px solid black;
    }
        table.term2, td.term2{
        background-color: #ccccff;
        border: 1px solid black;
    }
    table.summary, th.summary, td.summary{
          border: 1px solid black;
          margin-bottom: 13px;
          padding: 5px;
    }
    
</style>
<h3 class="text-center">Student Academic Report</h3>
 <div class="col-md-12">

                  <?php
      if(isset($student_data)){
       $studentID= $student_data->id;

        ?>

            
        </div>
    
        <div class="col-md-12">

<p><strong>Academic Year:</strong> <?= esc($year) ?></p>
<p><strong>Report Range:</strong> <span class="badge bg-success"><?= esc(date('F, d Y', strtotime($start_date))) ?> to <?= esc(date('F, d Y', strtotime($end_date))) ?></span></p>
<center>
    <!-- ==============================================TERM 1 SUMMARY============================================= -->
    <table class="summary">
            <tr>
                <th class="summary">FIRST ACADEMIC TERM REPORT SUMMARY</th>
           
                <td class="summary">
                       <?php
if(isset($overallAverages_term1)){
    foreach($overallAverages_term1 as $overall_data){
        if($overall_data->student_id==$studentID){
            $overall_avg_term1=round($overall_data->overall_avg, 1);
                 foreach ($gradeBoundaries as $boundary) {
                            if ($overall_avg_term1 >= $boundary->lower_performance && $overall_avg_term1 <= $boundary->upper_performance) {
                                 $averageGrade_term1 = $boundary->grade_name;
                                break;
                            }
                        }
?>


<span>Amepata jumla ya alama: <b><u><?= esc(round($overall_data->overall_total,0)); ?></u></b> Sawa na wastani wa alama: <b><u><?= esc(round($overall_data->overall_avg, 1)); ?></u></b> Daraja: <b><u><?= esc($averageGrade_term1); ?></u></b> </span>
       <?php 
       if(isset($government_level) && !empty($government_level)){
       if($government_level==3 || $government_level==4){
       ?>
       Division: <b><u><span id="term1division"></span></u></b> ya point: <b><u><span id="term1_points"></span></u></b>
    <?php
          }
elseif($government_level==5 || $government_level==6){
?>
G.P.A: <b><u><?= esc($overall_averageGrade); ?></u></b> Points: <b><u><?= $total_points ?></u></b>
<?php
}if($government_level==1 || $government_level==2){
    ?>
    <?php

}
}
if (isset($overallAverages_term1)) {
    foreach ($overallAverages_term1 as $item) {
        if ($item->student_id == $studentID) {
            echo "Nafasi yake darasani: <b><u>$item->position</u></b>";
         }
    }
}
?>

 Kati ya wanafunzi: <b><u><?= esc($students_count);  ?></u></b>

<?php
}
}
}
?> 
                </td>
     
        </tr>
        <tr>

                <th class="summary">SECOND ACADEMIC TERM REPORT SUMMARY</th>
           
                <td class="summary">
                       <?php
if(isset($overallAverages_term2)){
    foreach($overallAverages_term2 as $overall_data){
        if($overall_data->student_id==$studentID){
                 $overall_avg_term2=round($overall_data->overall_avg, 1);
                 foreach ($gradeBoundaries as $boundary) {
                            if ($overall_avg_term2 >= $boundary->lower_performance && $overall_avg_term2 <= $boundary->upper_performance) {
                                 $averageGrade_term2 = $boundary->grade_name;
                                break;
                            }
                        }
    ?>
<span>Amepata jumla ya alama: <b><u><?= esc(round($overall_data->overall_total,0)); ?></u></b> Sawa na wastani wa alama: <b><u><?= esc(round($overall_data->overall_avg, 1)); ?></u></b> Daraja: <b><u><?= esc($averageGrade_term2); ?></u></b> </span>
       <?php 
       if(isset($government_level) && !empty($government_level)){
       if($government_level==3 || $government_level==4){
       ?>
       Division: <b><u><span id="term2division"></span></u></b> ya point: <b><u><span id="term2_points"></span></u></b>
    <?php
          }
elseif($government_level==5 || $government_level==6){
?>
G.P.A: <b><u><?= esc($overall_averageGrade); ?></u></b> Points: <b><u><?= $total_points ?></u></b>
<?php
}if($government_level==1 || $government_level==2){
    ?>

    <?php
}
}
if (isset($overallAverages_term2)) {
    foreach ($overallAverages_term2 as $item) {
        if ($item->student_id == $studentID) {
            echo "Nafasi yake darasani: <b><u>$item->position</u></b>";
         }
    }
}
    ?>
  Kati ya wanafunzi: <b><u><?= esc($students_count);  ?></u></b>
<?php
}
}

}
?> 
                </td>
     
        </tr>
    </table>
</center>

<div class="table-responsive">
<table class="table table-bordered">
    <thead>
        <tr>
            <th colspan="2" class="text-center">Subjects Data</th>
            <th colspan="7" class="text-center term1">First Academic Term</th>
            <th colspan="7" class="text-center term2">Second Academic Term</th>
        </tr>
        <tr>
            <th>No</th>
            <th>Subject</th>

            <?php foreach ($exams_term1 as $exam1): ?>
                <th class="term1">
                                       <?php
$exam_name = $exam1->exam_name;
$words = explode(' ', $exam_name);
$first = isset($words[0]) ? substr($words[0], 0, 4) : '';
$second = isset($words[1]) ? substr($words[1], 0, 4) : '';
echo esc($first.'..'." " . $second);
                    ?>
                </th>
            <?php endforeach; ?>
            <th class="term1">AVG(%)</th>
            <th class="term1">Position</th>
            <th class="term1">Grade</th>
            <th class="term1">Comments</th>
            <?php foreach ($exams_term2 as $exam2): ?>
            <th class="term2">
                    <?php
$exam_name = $exam2->exam_name;
$words = explode(' ', $exam_name);
$first = isset($words[0]) ? substr($words[0], 0, 4) : '';
$second = isset($words[1]) ? substr($words[1], 0, 4) : '';
echo esc($first.'..'." " . $second);
                    ?>
                </th>
            <?php endforeach; ?>
            <th class="term2">AVG(%)</th>
            <th class="term2">Position</th>
            <th class="term2">Grade</th>
            <th class="term2">Comments</th>
        </tr>
    </thead>
                <?php
//return;
?>
    <tbody>


        <?php
        $allTerm1Subjects = [];
$Term1_TotalPoint = 0;
        $core_total_points = 0;
if (isset($classdata)):
       $i=0;
    foreach ($classdata as $data):
        $i++;
        $total_marks = 0;
    $marks_count = 0;
    $total_points = 0;
    $exam_number = 0;

?>
    <tr>
        <td><?= $i; ?></td>
        <td><?= $data->subject_name; ?></td>
        <?php if (isset($exams_term1)): ?>
       <?php foreach ($exams_term1 as $info): ?>
            <?php
                $marks = '-';
                $grade_name = '-';
            if(isset($Mid1subjectAverages)){
                foreach ($Mid1subjectAverages as $result) {
                    if ($result->exam_type_id == $info->exam_id && $result->subject_id == $data->subject_id && $result->student_id == $studentID) {
                        $marks = $result->avg_marks;
                        foreach ($gradeBoundaries as $boundary) {
                            if ($marks >= $boundary->lower_performance && $marks <= $boundary->upper_performance) {
                                $points = $boundary->division_point;
                                break;
                            }
                        }

                        if ($marks !== '-') {
                            $total_marks += $marks;
                            $marks_count++;
                            $total_points += $points ?? 0;
                            $exam_number++;
                        }

                        break;
                    }
                }
            }
            ?>
            <?php if($marks !== '-'){?>
            <td class="term1"><?= number_format($marks, 0); ?></td>
            <?php
               }else{
            ?>
            <td class="term1"><?= $marks; ?></td>
            <?php
        }?>
        <?php endforeach; ?>

        <?php endif; ?>
      <?php
            $average = $marks_count > 0 ? $total_marks /  $exam_number : 0;
            $averageGrade = '';
            $averageComment = '';
             $averagePoint1=0;
              $subjectsWithPoints1 = [];
            foreach ($gradeBoundaries as $boundary) {
                if ($average >= $boundary->lower_performance && $average <= $boundary->upper_performance) {
                    $averageGrade = $boundary->grade_name;
                    $averageComment = $boundary->comments;
                    break;
                }
            }
               if(isset($government_level)){
            if($government_level==4){

                //---A-level---
                  if ($data->selection == 1) {
                        foreach ($gradeBoundaries as $boundary) {
                            if ($average >= $boundary->lower_performance && $average <= $boundary->upper_performance) {
                                $averagePoint1  += $boundary->division_point;
                                break;
                            }}}
            $Term1_TotalPoint += $averagePoint1;
        }
        elseif($government_level==3){

            //------olevel----------
               if(isset($Mid1subjectAverages)){
                foreach ($Mid1subjectAverages as $result) {
                  foreach ($gradeBoundaries as $boundary) {
                        if ($average >= $boundary->lower_performance && $average <= $boundary->upper_performance) {
                            $subjectsWithPoints1[] = [
                                'subject_id' => $result->subject_id,
                                'marks1' => $average,
                                'points1' => $boundary->division_point
                            ];
                            break;
                        }
                    }}}
        
  }
      usort($subjectsWithPoints1, function ($a, $b) {
        return $b['marks1'] <=> $a['marks1'];
    });

    $bestSubjects1 = array_slice($subjectsWithPoints1, 0, 7);
    foreach ($bestSubjects1 as $subject) {
        $Term1_TotalPoint += $subject['points1'];
    }}
$term1_division = getDivisionFromPoints($Term1_TotalPoint, $government_level);

        ?>
        <td class="term1"><?= number_format($average, 1); ?></td>
       <?php 
       $found = false;
if(isset($subject_position_term1 )){
    foreach ($subject_position_term1 as $sp) {
        if ($sp['subject'] == $data->subject_id && $sp['student_id'] == $studentID) {
            echo '<td class="term1">' . esc($sp['position']) . '</td>';
            $found = true;
            break;
        }
    }
}
if (!$found){
     echo '<td class="term2"> - </td>';
}

?>

        <td class="term1"><?= $averageGrade; ?></td>
        <td class="term1"><?=$averageComment?></td>


<!-- ==================================Term 2=============================================== -->
    <?php
$total_marks2 = 0;
$marks_count2 = 0;
$total_points2 = 0;
$exam_number2 = 0;
?>
        <?php if (isset($exams_term2)): ?>
            <?php
            ?>
       <?php foreach ($exams_term2 as $info): ?>
            <?php
                $marks2 = '-';
                $grade_name2 = '-';
            if(isset($Mid2subjectAverages)){
                foreach ($Mid2subjectAverages as $result) {
                    if ($result->exam_type_id == $info->exam_id && $result->subject_id == $data->subject_id && $result->student_id == $studentID) {
                        $marks2 = $result->avg_marks;
                        foreach ($gradeBoundaries as $boundary) {
                            if ($marks >= $boundary->lower_performance && $marks <= $boundary->upper_performance) {
                                $points = $boundary->division_point;
                                break;
                            }
                        }
                        if ($marks2 !== '-') {
                            $total_marks2 += $marks2;
                            $marks_count2++;
                             $exam_number2++;
                        }

                        break;
                    }
                }
            }
            ?>
            <?php if($marks2 !== '-'){?>
            <td class="term2"><?= number_format($marks2, 0); ?></td>
            <?php
               }else{
            ?>
            <td class="term2"><?= $marks2; ?></td>
            <?php
        }?>
        <?php endforeach; ?>

        <?php endif; ?>
      <?php
            $average2 = $marks_count2 > 0 ? $total_marks2 /  $exam_number2 : '-';
            $averageGrade = '';
            $averageComment = '';
            $averagePoint=0;
            $Term2_TotalPoint=0;
             $subjectsWithPoints = [];
            foreach ($gradeBoundaries as $boundary) {
                if ($average2 >= $boundary->lower_performance && $average2 <= $boundary->upper_performance) {
                    $averageGrade = $boundary->grade_name;
                    $averageComment = $boundary->comments;
                    break;
                }
            }
       if(isset($government_level)){
            if($government_level==4){
                //---A-level---
                  if ($data->selection == 1) {
                        foreach ($gradeBoundaries as $boundary) {
                            if ($average2 >= $boundary->lower_performance && $average2 <= $boundary->upper_performance) {
                                $averagePoint += $boundary->division_point;
                                break;
                            }}}
            $Term2_TotalPoint += $averagePoint;
        }
        elseif($government_level==3){
            //------olevel----------
                  foreach ($gradeBoundaries as $boundary) {
                        if ($average2 >= $boundary->lower_performance && $average2 <= $boundary->upper_performance) {
                            $subjectsWithPoints[] = [
                                'subject_id' => $result->subject_id,
                                'marks' => $average2,
                                'points' => $boundary->division_point
                            ];
                            break;
                        }
                    }
        
        usort($subjectsWithPoints, function ($a, $b) {
        return $b['marks'] <=> $a['marks'];
    });

    // Step 3: Take best 7 subjects
    $bestSubjects = array_slice($subjectsWithPoints, 0, 7);

    // Step 4: Sum their division points
    foreach ($bestSubjects as $subject) {
        $Term2_TotalPoint += $subject['points'];
    }}}


        ?>
       <?php
  if($average2 != '-'){
    $term2_division = getDivisionFromPoints($Term2_TotalPoint, $government_level);
       ?>

        <td class="term2"><?= number_format($average2, 1); ?></td>
        <?php
        }else{
            $term2_division ='-';
        ?>
        <td class="term2"> - </td>
        <?php
}
        ?>

       <?php 
       $found2 = false;
if(isset($subject_position_term2 )){
    foreach ($subject_position_term2 as $sp) {
        if ($sp['subject'] == $data->subject_id && $sp['student_id'] == $studentID) {
            echo '<td class="term2">' . esc($sp['position']) . '</td>';
            $found2 = true;
            break;
        }
    }
}
if (!$found2){
     echo '<td class="term2"> - </td>';
}

?>

        <td class="term2"><?= $averageGrade; ?></td>
        <td class="term2"><?=$averageComment?></td>
        <?php

    endforeach;
endif;
?>
 </tr>





    </tbody>
</table>
<?php
// ===================== O-Level Division Calculation ===================== //

$subjectsWithPoints1 = []; // For Term 1
$subjectsWithPoints2 = []; // For Term 2
$Term1_TotalPoint = 0;
$Term2_TotalPoint = 0;

if (isset($classdata)):
    foreach ($classdata as $data):
        // ----- Term 1 Avg Marks & Grade Point Collection -----
        $total_marks = 0;
        $exam_number = 0;

        foreach ($exams_term1 as $exam1):
            if (isset($Mid1subjectAverages)) {
                foreach ($Mid1subjectAverages as $result) {
                    if (
                        $result->exam_type_id == $exam1->exam_id &&
                        $result->subject_id == $data->subject_id &&
                        $result->student_id == $studentID
                    ) {
                        $total_marks += $result->avg_marks;
                        $exam_number++;
                        break;
                    }
                }
            }
        endforeach;

        $average = $exam_number > 0 ? $total_marks / $exam_number : 0;

        if ($government_level == 3 && $average > 0) { // O-Level only
            foreach ($gradeBoundaries as $boundary) {
                if ($average >= $boundary->lower_performance && $average <= $boundary->upper_performance) {
                    $subjectsWithPoints1[] = [
                        'subject_id' => $data->subject_id,
                        'marks' => $average,
                        'points' => $boundary->division_point
                    ];
                    break;
                }
            }
        }

        // ----- Term 2 Avg Marks & Grade Point Collection -----
        $total_marks2 = 0;
        $exam_number2 = 0;

        foreach ($exams_term2 as $exam2):
            if (isset($Mid2subjectAverages)) {
                foreach ($Mid2subjectAverages as $result) {
                    if (
                        $result->exam_type_id == $exam2->exam_id &&
                        $result->subject_id == $data->subject_id &&
                        $result->student_id == $studentID
                    ) {
                        $total_marks2 += $result->avg_marks;
                        $exam_number2++;
                        break;
                    }
                }
            }
        endforeach;

        $average2 = $exam_number2 > 0 ? $total_marks2 / $exam_number2 : 0;

        if ($government_level == 3 && $average2 > 0) {
            foreach ($gradeBoundaries as $boundary) {
                if ($average2 >= $boundary->lower_performance && $average2 <= $boundary->upper_performance) {
                    $subjectsWithPoints2[] = [
                        'subject_id' => $data->subject_id,
                        'marks' => $average2,
                        'points' => $boundary->division_point
                    ];
                    break;
                }
            }
        }

    endforeach;

    // ===== After Loop: Calculate Term1 Best 7 =====
    usort($subjectsWithPoints1, function($a, $b) {
        return $b['marks'] <=> $a['marks'];
    });
    $best1 = array_slice($subjectsWithPoints1, 0, 7);
    foreach ($best1 as $s) {
        $Term1_TotalPoint += $s['points'];
    }
    $term1_division = getDivisionFromPoints($Term1_TotalPoint, $government_level);

    // ===== After Loop: Calculate Term2 Best 7 =====
    usort($subjectsWithPoints2, function($a, $b) {
        return $b['marks'] <=> $a['marks'];
    });
    $best2 = array_slice($subjectsWithPoints2, 0, 7);
    foreach ($best2 as $s) {
        $Term2_TotalPoint += $s['points'];
    }
    $term2_division = getDivisionFromPoints($Term2_TotalPoint, $government_level);
endif;

?>


</div>

</div>
<?php

}
?>
<script>
    setTimeout(function () {
  const division1 = '<?= esc($term1_division) ?>';
  const points1 = <?= json_encode($Term1_TotalPoint) ?>;
  document.getElementById("term1division").textContent = division1;
  document.getElementById("term1_points").textContent = points1;
  const division2 = '<?= esc($term2_division) ?>';
  const points2 = <?= json_encode($Term2_TotalPoint) ?>;
  document.getElementById("term2division").textContent = division2;
  document.getElementById("term2_points").textContent = points2;
  
}, 500);


</script>
