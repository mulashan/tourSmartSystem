<?php
    $student_model = new App\Models\StudentModel();
?>
<!-- <ul class="nav nav-tabs tab-primary page-header-tab">
    <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#PayDetails" >Payment Details</a></li>
    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#StudentData">Applicant Details</a></li>
    
    
</ul> -->
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            
           
               <form id="update_others" class="form-horizontal">
                 <div class="form-group row mb-3">
                     <label class="col-md-2 col-form-label"> Names:</label>
                     <div class="col-md-3">
                      <label class="col-form-label"> <?= $app[0]->first_name." ".$app[0]->middle_name." ".$app[0]->last_name;?></label>
                       
                  </div>
                  </div>
                 <div class="form-group row mb-3">
                     <label class="col-md-2 col-form-label">Date of Birth:</label>
                     <div class="col-md-3">
                         <input type="date" class="form-control-plaintext" value="<?= $app[0]->birth_date;?>" readonly>
                     </div>

                     <label for="" class="col-md-2 col-form-label">Gender:</label>
                     <div class="col-md-3">
                         <input type="text" class="form-control-plaintext" value="<?= $app[0]->gender;?>" readonly>
                     </div>
                 </div>

                 <div class="form-group row mb-3">
                     <label class="col-md-2 col-form-label">Phone No:</label>
                     <div class="col-md-3">
                         <input type="tell" class="form-control-plaintext" name="bphone" placeholder="+255-xxx-xxx-xxx"  required autocomplete="off" value="<?= $app[0]->phone;?>" readonly>
                     </div>
                     <label class="col-md-2 col-form-label">Status:</label>
                     <div class="col-md-3">
                        <?php
                        if($app[0]->status==1){
                            $status='Active';
                        }else{
                            $status='Inactive';
                        }
                        ?>
                          <input type="text" class="form-control-plaintext" value="<?= $status;?>" readonly>
                     </div>
                 </div>
                   
             </form>
            

        </div>
    </div>
</div>
<script>
  
</script>    