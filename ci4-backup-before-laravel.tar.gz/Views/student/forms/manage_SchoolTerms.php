<?php
$smodel = new App\Models\StudentModel();
   $clvl = $smodel->gettable_data('academic_types_tbl', $where = array('status' => 1));
?>
<div id="updtFeedback"></div>
<form class="form-horizontal" id="UpdateSemister">
    <input type="hidden" class="form-control" name="id" id="id" value="<?= $terms[0]->id;?>">
      <div class="form-group row">
        <label class="col-md-3 col-form-label">Academic Year<span class="text-danger">*</span></label>
        <div class="col-md-8">
            <input type="text" name="academic" id="academic" value="<?= $terms[0]->academic_year; ?>" class="form-control form-control-sm" placeholder="">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label">Term Name<span class="text-danger">*</span></label>
        <div class="col-md-8">
            <input type="text" name="tname" id="tname" value="<?= $terms[0]->term_name; ?>" class="form-control form-control-sm" placeholder="eg: Semister 1">
        </div>
    </div>

     <div class="form-group row">
            <label class="col-md-3 col-form-label">Course Period <span class="text-danger">*</span></label>
               <div class="col-md-8">
                 <select class="form-control form-select" name="academic_type" required>
                     <option value="">-choose-</option>
                           <?php

                          foreach ($clvl as  $value) {
                            if($value->id ==$terms[0]->type_id){
                                 ?>
                      <option value="<?php echo $value->id;?>" selected="selected"><?php echo $value->academic_type;?></option>
                  <?php }else{?>
                      <option value="<?php echo $value->id;?>"><?php echo $value->academic_type;?></option>
                          <?php }} ?>
                                    </select>
                                </div>
                                </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label">Description<span class="text-danger">*</span></label>
        <div class="col-md-8">
            <input type="text" name="tdescr" id="tdescr" value="<?= $terms[0]->description; ?>" class="form-control form-control-sm">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label">Start Date<span class="text-danger">*</span></label>
        <div class="col-md-8">
            <input type="date" name="startDate" id="startDate" value="<?= date('Y-m-d',strtotime($terms[0]->start_date)); ?>" class="form-control form-control-sm" >
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label">End Date<span class="text-danger">*</span></label>
        <div class="col-md-8">
            <input type="date" name="endDate" id="endDate" value="<?= date('Y-m-d',strtotime($terms[0]->end_date)); ?>" class="form-control form-control-sm" >
        </div>
    </div>
     <div class="form-group row">
        <label class="col-md-3 col-form-label">Due Date<span class="text-danger">*</span></label>
        <div class="col-md-8">
            <input type="date" name="dueDate" id="dueDate" value="<?= date('Y-m-d',strtotime($terms[0]->due_date)); ?>" class="form-control form-control-sm" >
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label" for="status">Status<span class="text-danger">*</span></label>
        <div class="col-md-8">
            <select class="form-select form-control form-control-sm" id="status" name="status" >
                <option value="">-Status-</option>
                <option value="1" <?php
                if ($terms[0]->status == 1) {
                    echo 'selected';
                }
            ?>>Active</option>
            <option value="2" <?php
            if ($terms[0]->status == 2) {
                echo 'selected';
            }
        ?>>Inactive</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label"></label>
        <div class="col-md-8">
            <button type="submit" class="btn btn-primary float-right">Update</button>
        </div>
    </div>
</form>


<script type="text/javascript">
    $('#UpdateSemister').submit(function(e){
        $.ajax({
            type: "POST",
            url: "save_Terms",
            data: $(this).serialize(),
            success: function (res) {
                $('#updtFeedback').html(res);
                setTimeout(function(){
                     window.location.reload();
                },1000)
            },
            error: function () {
                $('#updtFeedback').html('Error! Couldnt Update Level.'); 
            }
        });
        e.preventDefault();
    });
</script>