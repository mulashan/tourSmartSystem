 <?php
    $student_model = new App\Models\StudentModel();
    $amodel = new App\Models\AdmissionModel();
    //echo session()->get('user_id');
    //echo $_SESSION['user_id'];
?>
 <div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                   
                                    <th>Reg. Id</th>
                                    <th>Reg. Date</th>
                                    <th>Student Name(s)</th>
                                    <th>Gender</th>
                                     <th>Birth Date</th>
                                    <!-- <th>Age</th> -->
                                  
                                    <th>Created_by</th>
                                    <th>status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($student as $s){
                                    
                                   if($s->status == 1){ $status = "<b style='color:green;'>Active</b>";}else{$status = "<b style='color:red;'>Inactive</b>";}

                                    $mod = $student_model->gettable_data('users',$where = array('user_id' => $s->created_by));
                                    ?>
                                <tr>
                                    <td><?php echo $s->id;?></td>
                                    <td><?php echo $s->date_created ;?></td>
                                    <td><?php echo $s->first_name.' '.$s->middle_name.' '.$s->last_name;?></td>
                                    <td><?php echo $s->gender;?></td>
                                     <td><?php echo $s->birth_date;?></td>
                                    <!-- <td><?php //echo (date('Y') - date('Y',strtotime($s->date_of_birth))); ?></td> -->
                                   
                                    <td><?php echo $mod[0]->first_name;?></td>
                                    <td><?php echo $status;?></td>
                                    <!-- <td></td> -->

                                    <td><a href="javascript:void(0)" onclick="edit_otherstudent(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>Edit</a>
                                     <a href="javascript:void(0)" onclick="view_otherstudent(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>View</a>
                                        
                                    </td>
                                    
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <script type="text/javascript">
                    $('#myTable').DataTable();
                </script>