 <?php
    $student_model = new App\Models\StudentModel();
    $amodel = new App\Models\AdmissionModel();
    //echo session()->get('user_id');
    //echo $_SESSION['user_id'];
      helper('age');
?>
 <div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                    <th>App. No.</th>
                                    <th>App. Date</th>
                                    <th>Student Name(s)</th>
                                    <th>Gender</th>
                                    <!-- <th>Birth Date</th> -->
                                    <th>Age</th> 
                                    <th>Class Level</th>
                                    <th>Class</th>
                                  <th>Control No</th>
                                <th>Msg Status</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($student as $s){
                                    $lvl = $student_model->gettable_data('class_level_tbl',$where = array('id' => $s->class_lvl));
                                    $class = $student_model->gettable_data('classes_tbl',$where = array('id' => $s->class));
                                   if($s->application_status == 1){ $status = "<b style='color:red;'>Pending</b>";}else{$status = "<b style='color:green;'>Paid</b>";}

                                    $cnumber = $student_model->gettable_data('payment_request', $where = array('student_id'=>$s->id,'trans_no'=>$s->id,'inv_type'=>1)); 

                                            
                                            if(count($cnumber) > 0){
                                                $control_number = $cnumber[0]->reference_no;
                                            } else{
                                              $control_number=""; 
                                            }

                                     $msg_status = $student_model->gettable_data('message_groups_tbl', $where = array('trans_number' => $s->id,'message_type'=>6));
                                     if(count($msg_status)>0){
                                         $msg_st = $student_model->gettable_data('messages', $where = array('send_no' => $msg_status[0]->send_number));
                                         
                                         if(count($msg_st)>0){
                                            ?>
                                         <script type="text/javascript">
                                        
                                             $(function() {
                                        //  check_sms('<?php echo $msg_st[0]->message_id;?>');
                                              });
                                         </script>
                                         <?php
                                          $msg_s =$student_model->gettable_data('messages', $where = array('message_id' => $msg_st[0]->message_id));

                                         $del=$msg_s[0]->status_description;
                                         $time=$msg_s[0]->time_delivered;
                                         $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                                     }else{
                                         $stata='<span style="color:red">Not Sent'; 
                                     }
                                     }else{
                                       $stata='<span style="color:red">Not Sent';  
                                     }

                                    ?>
                                <tr>
                                    <td><?php echo $s->id;?></td>
                                    <td><?php echo $s->date_created ;?></td>
                                    <td><?php echo $s->first_name.' '.$s->middle_name.' '.$s->last_name;?></td>
                                    <td><?php echo $s->gender;?></td>
                                    <td><?php echo findAge($s->date_of_birth);?></td>
                                    <!-- <td><?php //echo (date('Y') - date('Y',strtotime($s->date_of_birth))); ?></td> -->
                                    <td><?php echo $lvl[0]->level_name ?? "" ;?></td>
                                    <td><?php echo $class[0]->class_name ?? "";?></td>
<!--                                    <td></td>-->
                                    <td><?php echo $control_number;?></td>
                                    <td><?php echo $stata;?></td>
                                    <td><?php echo $status;?></td>
                                    <!-- <td></td> -->

                                    <td><a href="javascript:void(0)" onclick="edit_application(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>Edit</a>
                                        <?php if($s->application_status == 1){ ?>
                                   <a href="javascript:void(0)" onclick="pay_application(<?php echo $s->id;?>)"  class="btn btn-warning btn-sm"><i class="fa fa-money">Pay</i></a>
                               <?php }else{?>
                               <a href="javascript:void(0)" onclick="print_receipt(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-print">Print</i></a>
                               <?php }?>
                                    </td>
                                    
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <script type="text/javascript">
                    $('#myTable').DataTable();
                </script>