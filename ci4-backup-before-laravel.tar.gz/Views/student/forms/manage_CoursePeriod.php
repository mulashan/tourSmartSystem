<?php
$smodel = new App\Models\StudentModel();
   $clvl = $smodel->gettable_data('academic_types_tbl', $where = array('status' => 1));
?>
<div id="updtFeedback"></div>
<form class="form-horizontal" id="UpdatePeriod">
    <input type="hidden" class="form-control" name="id" id="id" value="<?= $period[0]->id;?>">
      <div class="form-group row">
        <label class="col-md-3 col-form-label">Course Period<span class="text-danger">*</span></label>
        <div class="col-md-8">
            <input type="text" name="period" id="period" value="<?= $period[0]->academic_type; ?>" class="form-control form-control-sm" placeholder="">
        </div>
    </div>
 
    <div class="form-group row">
        <label class="col-md-3 col-form-label" for="status">Status<span class="text-danger">*</span></label>
        <div class="col-md-8">
            <select class="form-select form-control form-control-sm" id="status" name="status" >
                <option value="">-Status-</option>
                <option value="1" <?php
                if ($period[0]->status == 1) {
                    echo 'selected';
                }
            ?>>Active</option>
            <option value="2" <?php
            if ($period[0]->status == 2) {
                echo 'selected';
            }
        ?>>Inactive</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label"></label>
        <div class="col-md-8">
            <button type="submit" class="btn btn-primary float-right">Update</button>
        </div>
    </div>
</form>


<script type="text/javascript">
    $('#UpdatePeriod').submit(function(e){
        //alert($(this).serialize());
        $.ajax({
            type: "POST",
           url: '<?php echo base_url() . '/index.php/SemisterController/update_period'; ?>',
            data: $(this).serialize(),
            success: function (res) {
                $('#updtFeedback').html(res);
                setTimeout(function(){
                     window.location.reload();
                },1000)
            },
            error: function () {
                $('#updtFeedback').html('Error! Couldnt Update Course Period.'); 
            }
        });
        e.preventDefault();
    });
</script>