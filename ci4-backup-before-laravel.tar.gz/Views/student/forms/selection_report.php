
<!DOCTYPE html>
<?php
    helper('age');
    $student_model = new App\Models\StudentModel();
    $amodel = new App\Models\AdmissionModel();
    $name=$student_model->get_class_det($classid);
?>

<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>
<body>
<div>
<div id="printcashdtls">
    <div class="row">
    <center>
       <?php 
       if($status==1){
        $ss='Selected';
       }else{
        $ss='Not Selected';
       }
       echo '<h5>EDEN GARDEN EDUCATION TRUST</h5>';
       echo '<h5>Class '.$name[0]->class_name.' '.$ss.' '; ?>Students 
       </h5>
    </center>

          </div>                 
                     <div class="card">
                      <form id="attend">
                    <div class="table-responsive mt-3">
                       <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead >
                               <tr>
                                    <th>#</th>
                                     <th>App No</th>
                                     <th>Full Name</th>
                                    <th>Gender</th>
                                    <th>Gender</th>
                                    <th>Birthdate</th>
                                    <th>Age</th>
                                    <?php 
                                   if($status==0){
                                    ?>
                                    <th>Select</th>
                                <?php }?>
                                <?php 
                                   if($status==1){
                                    ?>
                                    <th><span class="text-red">Deselect</span></th>
                                <?php }?>
                                 </tr>
                            </thead>
                           <tbody style="border: 1px solid silver;">
                            <?php 
                            if(count($dta)>0){
                            $i=0;
                             foreach($dta as $st){
                                $i++;
                             
                            ?>
                        <tr>

                    <td><input class="" type="hidden" name="student_id[<?=$st->id;?>]" value="<?=$st->id;?>">
                                <?=$i;?></td>
                                     <td><?=$st->id;?></td>
                                     <td><?=$st->full_name;?></td>
                                     <td><?=$st->gender;?></td>
                                     <td><?=$st->date_of_birth;?></td>
                                     <td><?=findAge($st->date_of_birth);?></td>
                                     <td><?=$st->class_name;?></td>
                                       <?php 
                                   if($status==0){
                                    ?>
                                    <td class="text-center"><input class="form-check-input present-inp" type="checkbox" name="select[<?=$st->id;?>]" value="1"></td>
                                <?php }?>
                                <?php 
                                   if($status==1){
                                    ?>
                                    <td class="text-center"><input class="form-check-input present-inp2" type="checkbox" name="select[<?=$st->id;?>]" value="2"></td>
                                <?php }?>
                                </tr>
                          <?php }
         }else{
            echo "<tr>";
            echo "<td></td>";
            echo "<td colspan='7'>Currently there is no history</td>";
            echo "</tr>";
         }
                          ?>        
    </tbody>
</table>
                                <?php 
                            if(count($dta)>0){
                                ?>
   <div class="col-md-12 mt-3" id="sbmt">
                            <center>
                <button type="submit" class="btn btn-primary btn-sm col-sm-3">Save</button>
                           </center>
                        </div> 
                         <?php 
                           }
                                ?>
                    
</div>
</form>
</div>
</div>

</div>
 

</body>
</html>
<style>
    .present-inp{
        cursor: pointer;
        border: 1px solid red;
    }
     .present-inp2{
        cursor: pointer;
        border: 1px solid green;
    }
</style>
<script type="text/javascript">
    $('#attend').submit(function(e){
        e.preventDefault()
      
        //alert($(this).serialize());
        $.ajax({
            
           url: '<?php echo base_url() . '../index.php/StudentController/student_selection'; ?>',
            method:'POST',
            data:$(this).serialize(),
            success:function(resp){
              $('#Rept1ResultViewResults').html(''); 
            }
        })
    })

function printable_area(printcashdtls) {
       var TableToPrint = document.getElementById('myTable2');
       var htmlToPrint = '' +
           '<style type="text/css">' +
               'table th, table td {' +
               'padding: 5px; ' +'color: black; ' +

               '}' +
               ' #printHeader2{border-left: none!important; border-right: none!important;}' +
               ' #myTable2{padding: 4px; border-collapse:collapse; font; font-size:12pt;}' +
               ' #printHeader2 td{ border-bottom: solid black 1px; border-right: solid black 1px!important; }' +
               ' td{ border-bottom: solid black 1px; border-right: solid black 1px!important; border-left: solid black 1px!important; }' +
           '</style>';
       htmlToPrint += TableToPrint.outerHTML;
       newWin = window.open("");
       newWin.document.write('<head><title>MHI</title></head>');
       newWin.document.write("<h2><center>OUTSTANDING BALANCE STATEMENT</center></h2>");
       newWin.document.write(htmlToPrint);
       newWin.print();
       newWin.close();
   }

   function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");

  filter = input.value.toUpperCase();
  table = document.getElementById("myTable2");
  tr = table.getElementsByTagName("tr");
  for (var i = 1; i < tr.length; i++) {
    var tds = tr[i].getElementsByTagName("td");
    var flag = false;
    for(var j = 0; j < tds.length; j++){
      var td = tds[j];
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        flag = true;
      } 
    }
    if(flag){
        tr[i].style.display = "";
    }
    else {
        tr[i].style.display = "none";
    }
  }
}


$(document).ready(function () {
  $('#myTable').DataTable();
});


</script>