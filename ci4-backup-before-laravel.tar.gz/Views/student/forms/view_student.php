<?php 
    helper('age');
    ?>
<style type="text/css">
		.data,data1{
		padding: 5px;

	          }
	.data{
		padding-left: 90px;
		}
	.modal-title{
		margin-left: 350px;
	}
h5{

text-align: center;	
}

.custom-offset {
    margin-left: auto; 
}

</style>
<?php
 $studentModel = new App\Models\studentModel();
  $status="";
   $color="";
foreach($student as $st){
     if($st->status==1){
            $status="Pending";
            $color="blue";
          }elseif($st->status==2){
               $status="Admitted";
                $color="green";
          }elseif($st->status==3){
               $status="Transfered";
                $color="red";
          }elseif($st->status==4){
               $status="Graduate";
                $color="brown";
          }elseif($st->status==5){
               $status="Absconded";
                $color="violet";
          }
	$source = "";
    if($st->student_photo != ""){
      $source =  base_url('public/student_photos/'.$st->student_photo);
    }
?>


<table>
	<tbody>
        <tr>
          <td></td>  <td style="font-family: 'Castellar', sans-serif;padding-left:100px;color: <?php echo $color;?>; font-size: 20px"><b><?php echo ' '.$status; ?></b></td>
    
        </tr>
 <tr>
<td><img src="<?php echo $source; ?>" width="90" height="90"> </td>
<td style="padding-left:500px;">
 <legend>Include</legend>
      <input type="checkbox" name="type" value="<?php echo $id; ?>" onclick="checkbox1()" id="opt1"> <span id="msg"><label for="track"> Class Attended</label><br />
    <input type="checkbox" name="type" value="<?php echo $id; ?>" onclick="checkbox2()" id="opt2"> <span id="msg"><label for="event">Parent Info</label><br />
    <input type="checkbox" name="type" value="<?php echo $id; ?>" onclick="checkbox3()" id="opt3"> <span id="msg"><label for="message">Previous Schools</label><br />
    <input type="checkbox" name="type" value="<?php echo $id; ?>" onclick="checkbox4()" id="opt4"> <span id="msg"><label for="message">Billing Address</label><br />
    <input type="checkbox" name="type" value="<?php echo $id; ?>" onclick="checkbox5()" id="opt5"> <span id="msg"><label for="message">Financial Transactions</label><br />

    <input type="checkbox" name="type" value="<?php echo $id; ?>" onclick="checkbox6()" id="opt6"> <span id="msg"><label for="message">Pocket Money History</label><br />

<input type="checkbox" name="type" value="<?php echo $id; ?>" onclick="checkbox7()" id="opt7"> <label for="message">Boarding History</label><br />
<input type="checkbox" name="type" value="<?php echo $id; ?>" onclick="checkbox8()" id="opt8"> <label for="message">Academic History</label><br />

 	</td>
 </tr>
	<tr>
		<td class="data1"><b>Student Names:</b><?=" ".$st->first_name." ".$st->middle_name." ".$st->last_name; ?></td>
		<td class="data"><b>Student ID:</b><?=" ".$st->student_id; ?></td>
	</tr>
	<tr>
		<td class="data1"><b>DOB: </b><?=" ".$st->birth_date; ?></td>
		<td class="data"><b>Gorvernment ID: </b><?=" ".$st->government_no; ?></td>
	</tr>
	<tr>
        <td class="data1"><b>Age:</b><?= " ".findAge($st->birth_date);?> 
    </td>
        <td class="data"><b>Nationality: </b><?=" ".$st->nationality; ?></td>
	</tr>
	<tr>
		<td class="data1"><b>Gender:</b> <?=" ".$st->gender; ?></td>
		<td class="data"><b>Religion: </b><?=" ".$st->religion; ?></td>
		
	</tr>
	</tbody>
</table>
<?php
}
?>
<br>
<br>
<div class="box box-default" style="">
      <div class="box-body" style="" id="class"></div>
 <div id="line1"></div>
</div>
<div class="box box-default">
      <div class="box-body" style="" id="parentinfo"></div>
      <div id="line2"></div>
</div>
<div class="box box-default">
      <div class="box-body" style="" id="prevSchool"></div>
       <div id="line3"></div>
</div>
<div class="box box-default">
      <div class="box-body" style="" id="billing"></div>
       <div id="line4"></div>
</div>


  <div  id="select_date" style="display: none;" class="mb-3">
    <div class="d-flex justify-content-center" style="display: none;">
                    <form id="Rept1Result" class="form-inline" >
                         Trans date:
                         <div class="input-group ms-3 me-3">
                            <button type="button" class="btn btn-default pull-right daterange" id="daterange">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-up"></i>
                            </button>
                        </div>
                      
                        
                        <button type="submit" class="btn btn-primary" onclick="loadTrans(event)">Create</button>
                        
                    </form>

                </div>
                </div>
         <div class="box box-default">
      <div class="box-body" style="" id="transactions"></div>
       <div id="line5"></div>
</div>
        <div id="academic_year" style="display: none;" class="mb-3 row">
            <div class="d-flex justify-content-center" style="display: none;">
                <form id="academic_report" class="form-inline">
                      <input type="hidden" name="student" id="student" value="<?=esc($student_key);?>">
                         <label for="year" class="form-label">Academic Year:<span class="text-danger">*</span></label>&nbsp;&nbsp;
                                
                                   <select id="year" name="year" class="report-select" style="width: 130px;"  required>
                                    <?php
                                    $initial_year=2023;
                                    $current_year=date('Y');
                                    $final_year=$current_year+1;
                                    for ($initial_year; $initial_year <=$final_year ; $initial_year++) { 
                                
                                    ?>
                        <?php if($initial_year == $current_year){?>
                                    <option value="<?=$initial_year;?>" selected><?=$initial_year;?></option>
                                    <?php
                                           }else{
                                    ?>
                                    <option value="<?=$initial_year;?>" ><?=$initial_year;?></option>
                                    <?php
                                        }
                                    ?>

                                    <?php

                                       }
                                    ?>

            </select>
            <div class="invalid-feedback">Academic Year is required.</div>

                                <div class="">
                                &nbsp;&nbsp; <button type="submit" class="btn btn-primary">Create</button>
                             </div>
                             <!-- </div> -->
                                </form>
</div>
                            </div>
                            <hr>
         <div class="box box-default">
            <center>
                <div class="load_data"></div>
            </center>
      <div class="box-body" style="">
        <div id="academic_data"></div>
        <div id="academic_chart"></div>
          
      </div>

</div>
	<script>
            $(document).ready(function() {
        $(".report-select").select2();
    });
    // $('#select_date').hide();
function checkbox1() {
 var remember = document.getElementById("opt1");
  if (remember.checked) {
    $('#class').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');

    $('#class').load('<?php echo base_url() . '/class_info/' . $id; ?>');
    var elem = document.createElement("hr");
elem.setAttribute("style", "border:2px solid blue");
 $('#line1').append(elem);
     }else
     {
	$('#line1').html('');
  $('#class').html('');
     }
 
}
function checkbox2() {
	var remember = document.getElementById("opt2");
  if (remember.checked) {
  	$('#parentinfo').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
   $('#parentinfo').load('<?php echo base_url() . '/parent_info/' . $id; ?>');
   var elem = document.createElement("hr");
elem.setAttribute("style", "border:2px solid blue");
 $('#line2').append(elem);

     }else
     {
	$('#line2').html('');
  $('#parentinfo').html('');
     }
    }
function checkbox3() {
	var remember = document.getElementById("opt3");
  if (remember.checked) {
  	$('#prevSchool').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
   $('#prevSchool').load('<?php echo base_url() . '/prev_school/' . $id; ?>');
var elem = document.createElement("hr");
elem.setAttribute("style", "border:2px solid blue");
 $('#line3').append(elem);
     }else{
	$('#line3').html('');
  $('#prevSchool').html('');
     } 
   }
function checkbox4() {
	var remember = document.getElementById("opt4");
  if (remember.checked) {
    $('#billing').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');

   $('#billing').load('<?php echo base_url() . '/bill_address/' . $id; ?>');
   var elem = document.createElement("hr");
elem.setAttribute("style", "border:2px solid blue");
 $('#line4').append(elem);
     }else{
	$('#line4').html('');
  $('#billing').html('');
         }    
    }
function checkbox5() {
    var remember = document.getElementById("opt5");
    var remember2 = document.getElementById("opt6");
    var remember3 = document.getElementById("opt7");
  if (remember.checked) {
    remember2.checked=false;
    remember3.checked=false;
 $('#select_date').show();

}else{
    $('#line5').html('');
  $('#transactions').html('');
  $('#select_date').hide();

}
}

function loadTrans(e) {
    $('#line5').html('');
     var dta = "thedate=" + $('#daterange span').html()+"&ids="+<?= $id;?>;
   
    //$('#select_date').hide();
     // alert(dta);
    var remember = document.getElementById("opt5");
    var remember2 = document.getElementById("opt6");
	var remember3 = document.getElementById("opt7");
  if (remember.checked || remember2.checked || remember3.checked) {
   $('#transactions').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>'); 
   if(remember.checked){
      var purl='<?php echo base_url() . '/index.php/StudentController/stu_transaction'; ?>';
   }else if(remember2.checked){
      var purl='<?php echo base_url() . '/index.php/ReportsController/student_pocket_money'; ?>';
   }else if(remember3.checked){
      var purl='<?php echo base_url() . '/index.php/ReportsController/student_boarding_history'; ?>';
   }
   else{
    var purl='';
   }
  // $('#transactions').load('<?php echo base_url() . '/stu_transaction/' . $id.'/' ?>'+thedate);
$.ajax({
                type: "POST",
                  url: purl,
                 data: dta,
                success: function (res) {
                    $('#transactions').html(res);
                },
                error: function () {
                    $('#transactions').html('<div class="alert alert-warning">Fail to retreive Transactions.!!</div>');
                }
            });

  var elem = document.createElement("hr");
elem.setAttribute("style", "border:2px solid blue");
 $('#line5').append(elem);
}else{
	$('#line5').html('');
  $('#transactions').html('');

}
e.preventDefault();
};

 $(function () {  
    var start = moment().startOf('year'); 
    var end = moment().endOf('year');
    function cb(start, end) {
        $('#daterange span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
    }
    $('.daterange').daterangepicker({
         orientation: "top auto",
        startDate: start,
        endDate: end,
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
             'This Year': [moment().startOf('year'), moment().endOf('year')],
            'Last Year': [moment().subtract(1, 'year').startOf('year'), moment().subtract(1, 'year').endOf('year')],
        },
         opens: 'center',
         drops: 'up'
    }, cb);
    cb(start, end);

}); 

 function checkbox6(){
     var remember = document.getElementById("opt6");
      var remember2 = document.getElementById("opt5");
      var remember3 = document.getElementById("opt7");
  if (remember.checked) {
  remember2.checked=false;
  remember3.checked=false;
 $('#select_date').show();
}else{
    $('#line5').html('');
  $('#transactions').html('');
  $('#select_date').hide();

}
 }

 function checkbox7(){
     var remember = document.getElementById("opt7");
      var remember2 = document.getElementById("opt5");
      var remember3 = document.getElementById("opt6");
  if (remember.checked) {
  remember2.checked=false;
  remember3.checked=false;
 $('#select_date').show();
}else{
    $('#line5').html('');
  $('#transactions').html('');
  $('#select_date').hide();

}
 }
  function checkbox8(){
      var remember8 = document.getElementById("opt8");
  if (remember8.checked) {
 $('#select_date').hide();
 $('#academic_year').show();
   $('#academic_data').html('');
}else{
    $('#line5').html('');
  $('#transactions').html('');
  $('#select_date').hide();
  $('#academic_year').hide();
 $('#academic_data').html('');

}
 }
 
                

                
    //  $('#academic_report').submit(function (e) {
    //    e.preventDefault();
    // if (!this.checkValidity()) {
    //     this.classList.add("was-validated");
    //     return;
    //          }
            
    //         $('#load_data').html('<span class="fa fa-spinner fa-spin"></span> Loading data..');
    //         var formData = $(this).serialize();
    //         $.ajax({
    //             type: "POST",
    //             url: '<?php echo base_url() . '/academic-report'; ?>',
    //             data: formData,
    //             beforeSend: function(){
    //                     $('#load_data').html('<span class="fa fa-spinner fa-spin"></span> Loading data..'); 
    //             },
    //             success: function (res) {
    //                // $('#load_data').html('');
    //                  $('#load_data').html('<span class="fa fa-spinner fa-spin"></span> Loading data..'); 
    //                 $('#academic_data').html(res);
    //             },
    //             error: function () {
    //                 $('#academic_data').html('<div class="alert alert-warning">Fail to retreive data.!!</div>');
    //             }
    //         });
    //          $('#load_chat').html('<span class="fa fa-spinner fa-spin"></span> Loading data..');
    //         var formData = $(this).serialize();
    //         $.ajax({
    //             type: "POST",
    //             url: '<?php echo base_url() . '/student-performance'; ?>',
    //             data: formData,
    //             beforeSend: function(){
    //                     $('#load_chat').html('<span class="fa fa-spinner fa-spin"></span> Loading data..'); 
    //             },
    //             success: function (res) {
    //                // $('#load_data').html('');
    //                  $('#load_chat').html('<span class="fa fa-spinner fa-spin"></span> Loading data..'); 
    //                 $('#academic_chart').html(res);
    //             },
    //             error: function () {
    //                 $('#academic_chart').html('<div class="alert alert-warning">Fail to retreive data.!!</div>');
    //             }
    //         });

    // });

       function initDateRangePicker(year) {
    var start = moment(`${year}-01-01`);
    var end = moment(`${year}-12-31`);

    // Full range with exam type ID
    const fullRanges = {
        'First Midterm': [2, moment(`${year}-03-01`), moment(`${year}-03-31`)],
        'Terminal Report': [3, moment(`${year}-01-01`), moment(`${year}-06-30`)],
        'Second Midterm': [5, moment(`${year}-09-01`), moment(`${year}-09-30`)],
        'Annual Report': [4, moment(`${year}-07-01`), moment(`${year}-11-30`)],
        'Whole Year': [0, start, end]
    };

    // Create a simplified ranges object for daterangepicker
    let displayRanges = {};
    for (let label in fullRanges) {
        const [, startDate, endDate] = fullRanges[label];
        displayRanges[label] = [startDate, endDate];
    }

    function cb(start, end, label) {
        const formattedRange = `${start.format('YYYY/MM/DD')} - ${end.format('YYYY/MM/DD')}`;

        if (label && fullRanges[label]) {
            const [examType] = fullRanges[label];
             $('#selected-report-label').html(`<i class="fa fa-clipboard"></i> ${label}`);
             $('#report_title').html(` ${label}`);
            $('#reportrange-text').html(`${label} (${formattedRange})`);
            $('#exam_type_label').val(label);
            $('#exam_type_value').val(examType);
        } else {
              $('#selected-report-label').html(`<i class="fa fa-clipboard"></i> ${formattedRange}`);
               $('#report_title').html(` ${label}`);
            $('#reportrange-text').html(`${formattedRange} (Custom Range)`);
            $('#exam_type_label').val('Custom Range');
            $('#exam_type_value').val('custom');
        }

        $('#start_date').val(start.format('YYYY-MM-DD'));
        $('#end_date').val(end.format('YYYY-MM-DD'));
    }

    $('#reportrange-btn').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: displayRanges
    }, cb);

    // Initialize with default range
    cb(start, end, 'Whole Year');
}

$(function () {
    const initialYear = $('#year').val();
    initDateRangePicker(initialYear);
});

$('#year').change(function () {
    const selectedYear = $(this).val();
    initDateRangePicker(selectedYear);
});


$('#academic_report').submit(function (e) {
    e.preventDefault();

    // Form validation
    if (!this.checkValidity()) {
        this.classList.add("was-validated");
        return;
    }

    // Spinner + serialize form once
    var formData = $(this).serialize();
    $('#load_data').html('<span class="fa fa-spinner fa-spin"></span> Loading data..');
    $('#load_chart').html('<span class="fa fa-spinner fa-spin"></span> Loading chart..');

    // First AJAX: Fetch report table
    $.ajax({
        type: "POST",
        url: "<?= base_url('/academic-report') ?>",
        data: formData,
        success: function (res) {
            $('#load_data').html(''); 
            $('#academic_data').html(res);
        },
        error: function () {
            $('#academic_data').html('<div class="alert alert-warning">Failed to retrieve data.</div>');
        }
    });
    // $.ajax({
    //     type: "POST",
    //     url: "<?= base_url('/student-performance') ?>",
    //     data: formData,
    //     success: function (res) {
    //         $('#load_chart').html('');
    //         $('#academic_chart').html(res);
    //     },
    //     error: function () {
    //         $('#academic_chart').html('<div class="alert alert-warning">Failed to load chart.</div>');
    //     }
    // });
});

</script>
<script>
    // Send AJAX request to get student performance data
    // $.ajax({
    //     type: "POST",
    //     url: "<?= base_url('student-performance') ?>",
    //     data: {
    //         student: '<?= $student_key ?>',   // Replace or set dynamically
    //         year: year,
    //         exam_type_value: exam_type_value,
    //         exam_type_label: exam_type_label
    //     },
    //     success: function(res) {
    //         $('#load_chart').html('');

    //         const performance = res.performance;
    //         const labels = performance.map(p => p.subject);
    //         const data = performance.map(p => p.mark);

    //         const ctx = document.getElementById('performanceChart').getContext('2d');
    //         new Chart(ctx, {
    //             type: 'bar',
    //             data: {
    //                 labels: labels,
    //                 datasets: [{
    //                     label: 'Marks',
    //                     data: data,
    //                     backgroundColor: 'rgba(54, 162, 235, 0.6)',
    //                     borderColor: 'rgba(54, 162, 235, 1)',
    //                     borderWidth: 1
    //                 }]
    //             },
    //             options: {
    //                 responsive: true,
    //                 scales: {
    //                     y: {
    //                         beginAtZero: true,
    //                         max: 100
    //                     }
    //                 }
    //             }
    //         });
    //     },
    //     error: function() {
    //         $('#load_chart').html('<div class="alert alert-danger">Failed to load chart.</div>');
    //     }
    // });
</script>