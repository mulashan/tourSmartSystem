<ul class="nav nav-tabs tab-primary page-header-tab">
    <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Student-transfer">Students Transfer</a></li>
</ul>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="Student-transfer">
                <div class="row">
                    <div id="feedback"></div>
                    <form method="post" id="saveTransfer" class="form-horizontal">
                        <div class="col-md-12">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label col-form-label-sm">Transfer To:</label>
                                <div class="col-sm-7">
                                    <input type="hidden"  name="adm_id" value="<?= $admn[0]->id; ?>">
                                    <input type="hidden"  name="student_id" value="<?= $admn[0]->student_id; ?>">
                                    <input type="text" class="form-control form-control-sm"  name="transfer">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label col-form-label-sm">Reason for Transfer:</label>
                                <div class="col-sm-7">
                                    <!-- <input type="text" class="form-control form-control-sm"  name="reason"> -->
                                    <textarea cols='35' rows='4' class="form-control form-control-sm" name="reason"></textarea>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-sm-10">
                                    <button class="btn btn-primary float-right" type="submit" id="save-transfer">Save Transfer</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $('#saveTransfer').submit(function(e){

        $.ajax({
            beforeSend: function () {
                $('#save-transfer').prop("disabled", true);
            },
            
            url: '<?php echo base_url() . '/index.php/AdmissionController/save_transferDetails'; ?>',
            type: 'POST',
            data: $('#saveTransfer').serialize(),
            success: function(res){
                var data = JSON.parse(res);

                if(data['status'] == "0"){
                   $('#saveTransfer')[0].reset();
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#save-transfer').prop("disabled", false);
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }   
            },
            error: function(res){
                $('#save-transfer').prop("disabled", false);
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Transfer student.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
            }
        });

        e.preventDefault();
    });
</script>