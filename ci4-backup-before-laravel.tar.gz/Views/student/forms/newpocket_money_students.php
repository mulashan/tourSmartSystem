 <?php
 helper('age');
  $amodel = new App\Models\AdmissionModel();
 $smodel = new App\Models\StudentModel();
$remodel = new App\Models\ReportsModel();
 $bmodel = new App\Models\BillingModel();
  
  $cmodel = new App\Models\ClassesModel();
 $report = new App\Models\ReportsModel();
  $student = $smodel->gettable_data('students', $where = array('status' => 1));
    $admission = $smodel->gettable_data('admission_tbl', $where = array('status' => 1,'admission_type' => 0));
    $prc = $smodel->gettable_data('price_tbl', $where = array('item_id' => 65));
   
 ?>
                <div class="card">
                   <form id="pocketMoneyForm">
                        <div class="table-responsive mt-3">
                            <input type="hidden" name="year" value="<?php echo $year;?>">
                            <input type="hidden" name="item_price" value="<?php echo $prc[0]->item_price;?>">
                             <input type="hidden" name="item" value="<?php echo $prc[0]->item_id;?>">
                             <?php if(count($bd_val)>0){ ?>
                             <button type="button" id="saveAdmission" onclick="save_pocketMoney()" class="btn btn-primary btn-lg pull-right me-5"><i class=""> </i> Create Control Number</button>
                               <?php }?>
                            <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable2">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <td> <input type="checkbox" name="" value="" onclick="Allcheckbox()" id="Allselected"> All</td>
                                        <th>Permit No.</th>
                                        <th>Permit. Date</th>
                                        
                                        <th>Student Name</th>
                                        <th>DoB</th>
                                        <th>Age</th>
                                        <th>Level</th>
                                        <th>Class</th>
                                        <th>Stream</th>
                                        <th>Hostel Name</th>
                                        <th>P/Balance</th>
                                        <th>P/Money</th>
                                      
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $holid_student=array();
                                    if(count($bd_val)>0){
                                    $sn = 0;
                                    
                                    foreach ($bd_val as $adm){
                                          $std = $amodel->get_student_details('students', $where = array('id' => $adm->student_id));
                                        if($std[0]->status !=2){
                                            continue;
                                        }
                                        $sn++;
                                    
                                        $holid_student[]=array($adm->student_id);
                                        $room = $amodel->get_student_details('classes_tbl', $where = array('id' => $adm->class_id));
                                        $strm = $amodel->get_student_details('streams_tbl', $where = array('id' => $adm->stream_id));
                                        $user = $amodel->get_student_details('users', $where = array('user_id' => $adm->admitted_by));
                                        $level = $amodel->get_student_details('class_level_tbl', $where = array('id' => $adm->level_id));
                                        $pid = $amodel->get_student_details('boarding_tbl', $where = array('student_id' => $adm->student_id,'academic_year'=>$year));
         if(count($pid)==0){
        $pid=0;
          // $ino = "";
        $tkens = $smodel->get_max_id('boarding_tbl','permit_id');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        
$date = new DateTime($adm->date_joined); // Your initial date
$date->add(new DateInterval('P11M'));
$enddate= $date->format('Y-m-d');
          $data = [
                    'student_id' => $adm->student_id,
                    'academic_year' => $adm->academic_year,
                    'permit_id' => $ino,
                    'admission_type' => $adm->adimit_for,
                    'hostel' => $adm->hostel_id,
                    'month' => 11,
                    'start_date' => $adm->date_joined,
                    'end_date' =>$enddate,
                      'created_date' =>  $adm->date_joined,
                    'created_by' =>3,
                    'status ' => 1
                   
                ];
                $save= $amodel->SaveDetails('boarding_tbl',$data);
            }else{
             $pid=1;
            }
                                        $pid2 = $amodel->get_student_details('boarding_tbl', $where = array('student_id' => $adm->student_id,'academic_year'=>$year));

                                        if($pid2[0]->hostel==0){
                                         $hostelname='';
                                        }else{
                                        $hostel=$amodel->get_student_details('hostel_tbl', $where = array('id' => $pid2[0]->hostel));
                                           $hostelname=$hostel[0]->hostel_name;
                                    }
                                    $dbal = $amodel->get_student_details('ledger_transaction_tbl', $where = array('name_id' => $adm->student_id,'name_type_id'=>1,'trans_type'=>3,'trans_item'=>65));
                                    $bamount=0;
                                    $col='';
                                    if(count($dbal)>0){
                                      
                                    foreach($dbal as $bal){
                                         $check_y=$amodel->get_student_details('transaction_numbers_tbl', $where = array('trans_number' => $bal->trans_no,'trans_type_id'=>3,'trans_desc'=>$year));

                                         if(count($check_y)>0){
                                          
                                              $col='green';
                                            $bamount+=$bal->amount;  
                                         }
                                      
                                    }
                                     }
                                    ?>
                                        <tr style="<?php echo "";?>" onclick="selectRow('<?php echo $adm->student_id; ?>')" id="<?php echo $adm->student_id; ?>">
                                             <td><?= $sn;?></td>
                                             <td>  <input type="checkbox" name="selected[]" value="<?php echo $adm->student_id; ?>" onclick="checkbox('<?php echo $adm->student_id; ?>')" id="selected<?php echo $adm->student_id; ?>"></td>
                                            <td><?= $pid2[0]->permit_id;?></td>
                                            <td><?= $pid2[0]->created_date;?></td>
                                            <td><?= $std[0]->first_name.' '.$std[0]->middle_name.' '.$std[0]->last_name;?></td>
                                            <td><?= $std[0]->birth_date;?></td>
                                            <td><?= findAge($std[0]->birth_date);?>
                                        </td>
                                            <td><?= $level[0]->level_name;?></td>
                                            <td><?= $room[0]->class_name;?></td>
                                            <td><?= $strm[0]->stream_name;?></td>
                                            <td><?= $hostelname;?></td>
                                            <td style="color: <?php echo $col;?>"><?= number_format($bamount);?></td>
                                            <td><?= number_format($prc[0]->item_price);?></td>
                                                  
                                            <td>
                                               
                                            </td>
                                        </tr>
                                    
                                <?php }}?>
                                </tbody>
                            </table>
                        </div>
                       
                    </form>
                </div>
               

<script type="text/javascript">
    function selectRow(id){
         var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {
    row.style.backgroundColor = 'white';
    row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {

    row.style.backgroundColor = 'black';
     row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        }
      
      }
      function checkbox(id){
        var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {

    row.style.backgroundColor = 'white';
    row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {
    row.style.backgroundColor = 'black';
    row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        } 
      }
      function Allcheckbox(){
        var values=<?php echo json_encode($holid_student);?>;
        //alert(values.length);
        var rememberAll = document.getElementById("Allselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
            if(rememberAll.checked){
     remember.checked=true;  
      if (row) {
    
    row.style.backgroundColor = 'black';
    row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=false; 
      
       if (row) {
      row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }  
        }
        }
      }
      function save_pocketMoney() {
          var data=$('#pocketMoneyForm').serialize()+'&'+$('#header_form').serialize();
               alert(data);
               return;
            $.ajax({
                type: "POST",
              url: '<?php echo base_url() . '/index.php/AdmissionController/save_pocket_transaction_items'; ?>',
                data: data,
                success: function (res) {
                    if(res){
                      
                         swal('success','Created successfuly','success');
                         
                    }else{
                        swal('error','something went wrong','error'); 
                    }
                
                },
                error: function () {
                    alert('something went wrong');
                }
            });
        };
</script>