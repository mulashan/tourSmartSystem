<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 

    $transport = new App\Models\TransportModel();
    $csmodel = new App\Models\ClassesModel();
    $charged_item = $transport->items_chargedList();
?>

<style>

		
modal-content {
    background: #ccc;
  }
font-family: 'Varela Round', sans-serif;
}
.modal-confirm {		
	color: #636363;
	width: 400px;
}
input{
	width:14px:
}
.modal-confirm .modal-content {
	padding: 20px;
	border-radius: 5px;
	border: none;
	text-align: center;
	font-size: 14px;
}
.modal-confirm .modal-header {
	border-bottom: none;   
	position: relative;
}
.modal-confirm h4 {
	text-align: center;
	font-size: 26px;
	margin: 30px 0 -10px;
}
.modal-confirm .close {
	position: absolute;
	top: -5px;
	right: -2px;
}
.modal-confirm .modal-body {
	color: #999;
}
.modal-confirm .modal-footer {
	border: none;
	text-align: center;		
	border-radius: 5px;
	font-size: 13px;
	padding: 10px 15px 25px;
}
.modal-confirm .modal-footer a {
	color: #999;
}		
.modal-confirm .icon-box {
	width: 80px;
	height: 80px;
	margin: 0 auto;
	border-radius: 50%;
	z-index: 9;
	text-align: center;
	border: 3px solid #f15e5e;
}
.modal-confirm .icon-box i {
	color: #f15e5e;
	font-size: 46px;
	display: inline-block;
	margin-top: 13px;
}
.modal-confirm .btn, .modal-confirm .btn:active {
	color: #fff;
	border-radius: 4px;
	background: #60c7c1;
	text-decoration: none;
	transition: all 0.4s;
	line-height: normal;
	min-width: 120px;
	border: none;
	min-height: 40px;
	border-radius: 3px;
	margin: 0 5px;
}
.modal-confirm .btn-secondary {
	background: #c1c1c1;
}
.modal-confirm .btn-secondary:hover, .modal-confirm .btn-secondary:focus {
	background: #a8a8a8;
}
.modal-confirm .btn-danger {
	background: #f15e5e;
}
.modal-confirm .btn-danger:hover, .modal-confirm .btn-danger:focus {
	background: #ee3535;
}
.trigger-btn {
	display: inline-block;
	margin: 100px auto;
}
p{
	text-weight:20px;
	font-size:16pt;
}
</style>
<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center ">
	
        <ul class="nav nav-tabs page-header-tab">
            <li class="nav-item"><a class="nav-link active" id="vehicle-tab" data-toggle="tab" href="#hicles">Vehicle</a></li>
            <li class="nav-item"><a class="nav-link" id="vehicle-tab" data-toggle="tab" href="#Items">Charged Items</a></li>
            <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#ments">Installments</a></li>
        </ul>
    </div>
</div>

    <div class="container-fluid">
    <div class="tab-content">
            <div  id="hicles" class="tab-pane active">    
             
                    
                    <hr>
                    <div id="feedback"></div>
                    <form class="card-body form-horizontal" id="Vehicle">
					

                                <input type="hidden"  id="tid" class="form-control" name="vid" value="<?php echo $updated[0]->id;?>">
                          
                       <div class="form-group row">
                            <label class="col-md-3 col-form-label">Route</label>
                            <div class="col-md-8">
                       <?php 
                     $rt = $transport->select_route();
                        ?>
                    <select class="form-control form-select" name="route">
                        <?php 
                       foreach($rt as $r){
                        ?>
                        
                        <option value="<?= $r->id; ?>"<?php
                                    if ($updated[0]->route_id == $r->id) {
                                        echo 'selected';
                                    }
                                    ?>><?=$r->route_name?></option>
                                    
                       <?php
                             
                              }

                               ?>
                    </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Vehicle Number</label>
                            <div class="col-md-8">
                                <?php 
                $vhc = $transport->select_vehicle();
               
                 ?>
                    <select class="form-control form-select" name="vname">
                        <?php 
                       foreach($vhc as $v){
                        ?>
                        
                        <option value="<?= $v->id; ?>"<?php
                                    if ($updated[0]->vehicle_number == $v->vehicle_number) {
                                        echo 'selected';
                                    }
                                    ?>><?=$v->vehicle_number?></option>
                                    
                       <?php
                             //foreach($vhc as $v){
                              // echo '<option value="' . $v->id . '">' . $v->vehicle_number .'</option>'; 
                              }

                               ?>
                    </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Seating Capacity</label>
                            <div class="col-md-8">
                                <input type="number" class="form-control" name="scapcty" value="<?php echo $updated[0]->capacity;?>">
                            </div>
                        </div>
                      				<div class="form-group row">
                            <label class="col-md-3 col-form-label">Status</label>
                            <div class="col-md-8">
                                <select class="form-select form-control form-control-sm" id="status" name="status" >
                                    <option value="">-Status-</option>
                                    <option value="1" <?php
                                    if ($updated[0]->status == 1) {
                                        echo 'selected';
                                    }
                                    ?>>Active</option>
                                    <option value="2" <?php
                                    if ($updated[0]->status == 2) {
                                        echo 'selected';
                                    }
                                ?>>Inactive</option>
                                </select>
                            </div>
                        </div>
					
					
					
					<div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-8">
                                
                                <button type="submit" class="btn btn-primary float-right">Update</button>
								</form>
                         
                       
                        </div>
                        </div>
                        </div>
                         
					 <div class="tab-pane " id="Items">    
                         <div id="updacc1"></div>
                    
					<form class="card-body form-horizontal" id="VehicleItemUpdate">
				 <input type="hidden" class="form-control" name="vid" value="<?php echo $updated[0]->id;?>">
					
                        <div class="form-group row">
                                        <label class="col-md-2 col-form-label" for="items">Charged Items<span class="text-danger">*</span></label>
                                        <div class="col-md-9">
                                            <select class="form-select form-control" id="js-example-data" style="width:100%;height: 15px;"></select>
                                        </div>
                                    </div>
									
							
                        
                        <div class="row">
                            <!-- <div class="col-md-2"></div> -->
                            <div class="col-md-12">
                               <div class="card">
                                         <p Class=" d-flex justify-content-center mt-3">CHARGED ITEMS</p>
                                    <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable">
                                    <thead>
                                            <tr>
                                                <th>No#</th>
                                                <th>Item Name</th>
                                                <th>Attribute</th>
                                                <th>size</th>
                                                <th>UOM</th>
                                                <th>Quantity</th>
                                                <th>Price</th>
                                                <th>Total</th>
                                                <th>Action</th>
                                            </tr>
                                    </thead>
									
									<tbody id="show_detail">
                                                    
                                               
								<?php
												
							foreach($item as $items){
								?>

							<tr id="<?php echo $items->id;?>">
                            <td><?php echo $items->item_id;?> </td>
                            <td><?php echo $items->item_name;?></td>
                            <td><?php echo $items->item_attribute;?></td>
                            <td><?php echo $items->item_size;?></td>
                            <td>1</td>
                            <td><input type="number"   value="<?php echo $items->quantity;?>" style="width:60px" name="qty[]<?php echo $items->item_id?>"  id="qty<?php echo $items->item_id;?>" onkeyup=confirm(<?php echo $items->item_id;?>)></td>
							 
							
												<?php
									 
							$transport = new App\Models\TransportModel();
							
							 $dbname=session()->get('db_name');
                           $db = \Config\Database::connect($dbname);
							$item_id=$items->item_id;
							$query=$this->db->table('price_tbl');
							$query->select('item_id,item_price');
							$query->where('item_id',$item_id);
							$result=$query->get()->getResult();
						
						foreach($result as $i){
							$tprice= $items->quantity*$i->item_price;
							?>
							                            <td id="item_price<?php echo $i->item_id;?>"><?php echo $i->item_price;?></td>
														
							<td><input value="<?php echo number_format($tprice);?>"type="text" name="tprice" id="tprice<?php echo $i->item_id;?>" style="border:none;width:80px;background-color:rgb(255, 255, 255)" readonly></td>
							
							
					
	
							 
							 <td>
							 <button type="button" class="btn btn-danger  deleteid" data-id="<?= $items->id;?>">X</button>
							<!--<a href="#" id="deleteid" data-toggle="modal" trans_id="<?php// echo $items->transport_id;?>" delete_id="<?php //echo $items->item_id;?>" class="btn btn-primary bt-sm"><i class="fa fa-close"></i></a>
							-->
							</td>

						<?php	
						}
					
							?>
							<?php	
							}
						     ?>
						 </tr>
					
							        </tbody>
                                    </table>
                                    <table>
                                        <tr>
                                        <th col=4>
                                        <span id="totaly" style="margin-left:450px;"></span>
                                        </th>
                                        </tr>
                                </table>
                                </div>
                                </div>
                                </div>
                               
                           <div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-8">
                                
                                <button type="submit" class="btn btn-primary float-right">Update</button>
                            </div>
                        
                         </form> 
                        </div>
                        </div>

         <div id="ments" class="tab-pane">
            <div id="updacc2"></div>
            <form class="form-horizontal" id="read">
                
                <input type="hidden" class="form-control" name="tid" value="<?php echo $updated[0]->id;?>">
                <div class="form-group row">
                              <label class="col-md-2 col-form-label">Installment Term<span class="text-danger"></span></label>
                                <div class="col-md-2">
                                    <?php $terms = $csmodel->get_all_terms();?>
                                   <select name="install1" class="form-select">
                                    <option value="" selected>select</option>
                                    <?php foreach($terms as $term){?>
                                      <option value="<?php echo $term->id;?>"><?php echo $term->term_name; ?></option>
                                      <?php } ?> 
                                   </select>
                                </div> 
                               <label class="col-md-1 col-form-label">Amount<span class="text-danger"></span></label>
                                <div class="col-md-2">
                                    <input type="number"  class="form-control" name="amount1" id="amount" placeholder="">
                                    <span class="text-danger" id="morethan"></span>
                                </div>
                               <!--  <label class="col-md-1 col-form-label">Duedate<span class="text-danger"></span></label>
                                 <div class="col-md-2">
                                    <input type="date" class="form-control" name="duedate1" placeholder="Duedate" id="duedate">
                                </div> -->
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-primary st" id="installupdate"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2"></div>
                                <div class="col-md-12">
                                    <div class="card">
                                        <p Class=" d-flex justify-content-center mt-3">TERMS INSTALLMENT(S)</p>
                                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="">
                                        <thead>
                                                <tr>
                                                    
                                                    <th>Installment Term</th>
                                                    <th>Amount</th>
                                                    <th>Due Date</th>
                                                    
                                                    <th>Action</th>
                                                    
                                                </tr>
                                        </thead>
                                        <tbody id="showtbody">

                                    </tbody>
                                        
                                        </table>
                                        <table>
                                        <tr>
                                        <th col=4>
                                        <span id="rem" style="margin-left:200px;"></span>
                                        </th>
                                        </tr>
                                    </table>
                                    </div>
                                </div>
                            </div>
                            
                <div class="form-group row">
                    <label class="col-md-2 col-form-label"></label>
                    <div class="col-md-9">
                        <button type="button" class="btn btn-primary float-right" onclick="submitData2()">Update</button>
                    </div>
                </div>

            </form>
        </div>
                        </div>
                        </div>
                        

              
              

<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
    var hold_selected_items = []; // hold all selected items
   
    $(document).ready(function(){
        fetch_installment_data();
         $('#js-example-data').select2({
            ajax: {
                url: "<?= base_url('get_data'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

        $('#js-example-data').on('select2:select', function (e) {
            selectedItems();
        });
         
        function selectedItems(){  
		var transport_id= $("#tid").val();
            var rows = '';
           var itemData = 'item_selected='+$('#js-example-data').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                 url:"<?= base_url('item_data')?>/"+ transport_id,   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }else{
                        var len  = data.length;

                        for (var i = 0; i <len; i++ ){
                            hold_selected_items.push(data[i]['id']);// push all selected items
                            var prc = data[i]['iprice'];
                            var name = data[i]['iname'];
                            var iid = data[i]['id'];
                            var size = data[i]['isize'];
                            var attribute = data[i]['iattribute'];
							//var quantity= window.prompt('enter quantity');
							//var total= quantity*prc;

                            
                            rows += '<tr id="table_row'+ iid +'">';
                            rows += '<td><input type="hidden">'+ iid +'</td>';
                            rows += '<td>'+ name +'</td>';
                            rows += '<td>'+ attribute +'</td>';
                            rows += '<td>'+ size +'</td>';
                            rows += '<td>'+ 1 +'</td>';
                             
                            rows += '<td><input type="number" name="qt[]"  id="qty'+iid+'" onkeyup=mult('+iid+'); style="width:60px"></td>';
                            rows += '<td id="item_price'+iid+'">'+ prc +'</td>';
                            rows += '<td><input type="text" name="tprice" id="tprice'+iid+'" style="width:85px; border:none; background-color:rgb(255,255,255)" readonly></td>';
                           rows +='<input type="hidden" name="id[]" value="'+iid+'">';
                             rows += '<td><a href="javascript:RemoveSelectItemRow('+iid+');" class="btn  btn-danger" >X</a></td>';
                            rows += '</tr>';
                            $('#show_detail').append(rows);
							
                        }
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }  
           });  
        } 
    });
	function mult(iid){
	var totalPrice = $('#qty'+iid).val()* $('#item_price'+iid).html()        
	document.getElementById('tprice'+iid).value = totalPrice.toLocaleString('en-US');	

var totalPrice = totalPrice.toLocaleString('en-US');
console.log(usFormat);	
		
}		

    function RemoveSelectItemRow(item_id){
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }

        $('#table_row'+item_id).remove();
    }


    $('#Vehicle').submit(function(e){
		 
           //alert($(this).serialize());
          // return;

        $.ajax({
            type: 'POST',
            url: '<?= base_url('Update_vehicle_item')?>',
			data:$(this).serialize(),
            
            success:function(data){
                // alert('data updated successfully');  
                 $('#feedback').html(data);
                setTimeout(function(){
                     window.location.reload();
                },1000)
            },
            error:function(){
     //              $("#VehicleModal").modal('show');
				 // location.reload();
                 $('#feedback').html('Error! Couldnt Update Transport Detaails.');
            }
        });
        
        e.preventDefault();
    });
	 $('#VehicleItemUpdate').submit(function(e){
         var Data1 = $(this).serialize();
		 
        //alert(Data1);

        $.ajax({
            method: 'POST',
            url: '<?= base_url('updateItem')?>',
			data:Data1,
            
            success:function(data){
             $('#updacc1').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                 
                setTimeout(function(){
                     window.location.reload();
                },1000)
                    
            },
            error:function(){
                    $('#updacc1').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Not Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                 
            }
        });
        
        e.preventDefault();
    });
	
	
	 $(".deleteid").click(function () {
		 var id=$(this).attr('data-id');
       // var data3 = 'trid=' + $(this).attr('trans_id')+ '&itid='+$(this).attr('delete_id');
	//alert(id);
	//return;
        
         swal({
            title: "Are you sure?",
            text: "You will not be able to recover this item!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },
		  function(isConfirm) {
            if (isConfirm) {


        $.ajax({
            type: "GET",
            url: "DeleteVehicleItem/"+ id,
            //data: data,
            success: function(res){
               // $('#UpdateTransport').html(res);
				swal("Deleted!", "Item has been deleted.", "success");
                $("#"+id).remove();

                    
                 
            },
            error: function ()
            {

            }
        });
		} else {
               swal("Cancelled");
            }

          });

    });
	   $('#installupdate').click(function(event){
        var id=<?php echo $updated[0]->id;?>;
       var data = 'installname=' + $('select[name=install1]').val() + '&amount=' + $('input[name=amount1]').val()+ '&id=' + $('input[name=tid]').val();
       //alert(ttl);
       if(ttl==undefined){
        remain=10000000;
       }
       //alert(remain);
       var enteredAmount=$('input[name=amount1]').val();
       
       var present=remain-enteredAmount;
       //alert(data);
       if(present>=0){
         document.getElementById("morethan").innerHTML="";  
       $.ajax({
            type: 'POST',
            url: 'addinstallments4/'+id,
            data: data,
            success:function(data){
                 if(data==1){
                alert("Term, Already Selected");
                present=remain+enteredAmount;
                }
                fetch_installment_data();
            }
       });
      }else{
        document.getElementById("morethan").innerHTML="Enter less amount or equal to "+remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
     // $('input[name=amount1]').val()="";    
      }
        event.preventDefault();
    });
    var ttl;
    var remain;
 function fetch_installment_data(){
        $('#showtbody').empty();
                
        var datta = 'tra_id=<?= $updated[0]->id; ?>';
        //alert(datta);
        $.ajax({
            type: 'GET',
            data: datta,
            url: 'fetchinstallments4',
              success:function(response){

                var ments_data = JSON.parse(response);
                var len = ments_data.length;
                //total=fetch_class_itemsCharged();
                var ttlamount=0;
                for(var i = 0; i < len; i++){
                    total=ments_data[0]['tprice'];
                    var amounted=parseInt(ments_data[i]['amount']);
                    ttlamount=parseInt(ttlamount+amounted);
                    $('#showtbody').append('<tr>'+
                        
                        '<td>'+ments_data[i]['installname']+'</td>\
                        <td>'+ments_data[i]['amount']+'</td>\
                        <td>'+ments_data[i]['duedate']+'</td>\
                        <td>\
                            <a href="javascript:RemoveRow('+ments_data[i]['id']+','+total+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
        //total=window.sum;
        total=ments_data[0]['tprice'];
        remain=total-ttlamount;
        ttl=remain;
        document.getElementById("rem").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        document.getElementById("totaly").innerHTML = "Total = " + total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(total);
            }
        });
        
    }
     function RemoveRow(id,total){

        $.ajax({
            type: 'GET',
            url: 'deleteMents/'+id,
            success: function(){
                
                alert('deleted successfuly');
         remain= total;
         document.getElementById("rem").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         console.log(remain);
         fetch_installment_data();
            }
        });

    }
    function submitData2(){
        $('#updacc2').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Updated Successfully</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
        setTimeout(function(){
            window.location.reload();
        },1000)
    }
</script>
