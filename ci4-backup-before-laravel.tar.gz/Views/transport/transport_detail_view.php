<style type="text/css">
    .text-right {
    text-align: right !important;
}
.table-container {
  overflow: auto;
 /* height: 400px;  Set the desired height for the fixed table */
}

.table-container table {
  table-layout: fixed;
}

.table-container th,
.table-container td {
  width: 75px; /* Set the desired width for each cell */
   word-break: break-all;
    word-wrap: break-word;
  white-space: normal;
}

.table-container thead th {
  position: sticky;
  top: 0;
  z-index: 1;
  background-color: #fff; /* Set the desired background color for the fixed header */
}

.table-container tbody th,
.table-container tbody td {
  position: sticky;
  left: 0;
  z-index: 1;
  background-color: #fff; /* Set the desired background color for the fixed column */
}

</style>
<link rel="stylesheet" href="<?php// echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<?php 
    helper('age');

    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();
    $app_class = 0;
    $app_lvl="";
    $age = findAge($student_dtl[0]->birth_date);

    $level = $amodel->admisiion_details('class_level_tbl');
    $admission = $amodel->get_student_details('admission_tbl',$where = array('student_id' => $student_dtl[0]->student_id,'status' => 0));
    $appln = $amodel->get_student_details('students_application_tbl',$where = array('id' => $student_dtl[0]->id));
    $terms = $amodel->admisiion_details('school_terms_tbl');
    $hstl = $amodel->get_hostel_details($student_dtl[0]->gender,$age);
    $transport = $amodel->admisiion_details('route_tbl');

    if(count($appln) > 0){        
        $app_class = $appln[0]->class;
        $app_lvl = $appln[0]->class_lvl;
    }else{
        $app_class = "";
    }
        $app_lvl = "";
    $studentparent=$amodel->get_student_details('parents_students_tbl', $where = array('student_id' => $student_dtl[0]->student_id));
    $parent = $amodel->get_student_details('parents_tbl', $where = array('id' => $studentparent[0]->parent_id));
     $tps = $amodel->get_student_details('transport_details',$where = array('permit_id' => $id));



?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12">
       
                <div class="row">
                        <div id="feedback"></div>
                    <div class="col-md-5">
                     
                        <div class="card">
                                <p Class=" d-flex justify-content-center mt-2">STUDENT DETAILS</p>
                            <center>
                                <?php 
                                    $source = "";
                                    if($student_dtl[0]->student_photo != ""){
                                      $source =  base_url('public/student_photos/'.$student_dtl[0]->student_photo);
                                    }
                                ?>
                                <img src="<?php echo $source; ?>" style="margin-top: 2em;width:80px; height:100px;border: 1px wheat solid">
                                <table class="table table-borderless mt-3">
                                    <tr>
                                        <th>Student Name:</th>
                                        <td><?= $student_dtl[0]->first_name.' '. $student_dtl[0]->middle_name.' '.$student_dtl[0]->last_name;?></td>
                                    </tr>
                                    <tr>
                                        <th>Date of Birth:</th>
                                        <td><?= $student_dtl[0]->birth_date;?></td>
                                    </tr>
                                    <tr>
                                        <th>Age:</th>
                                        <td><?= findAge($student_dtl[0]->birth_date); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Gender:</th>
                                        <td><?= $student_dtl[0]->gender;?></td>
                                    </tr>
                                    <tr>
                                        <th>Nationality:</th>
                                        <td><?= $student_dtl[0]->nationality;?></td>
                                    </tr>
                                    <tr>
                                        <th>Gurdian / Parent Name:</th>
                                        <td><?= $parent[0]->first_name.' '. $parent[0]->last_name;?></td>
                                    </tr>
                                    <tr>
                                        <th>Gurdian / Parent Phone:</th>
                                        <td><?= $parent[0]->phone1;?></td>
                                    </tr>
                                    <tr>
                                        <th>Address:</th>
                                        <td><?= $parent[0]->postal_address;?></td>
                                    </tr>
                                </table>
                            </center>
                        </div>

                        <div class="card">
                          <p Class=" d-flex justify-content-center mt-2">CAR DETAILS</p>  
                          <table class="table table-borderless">
                            <thead>
                                <tr>
                              <th>session</th>
                              <th>car name</th>
                              <th>Driver name</th>
                          </tr>
                              </thead>
                              <tbody>
                                <?php
                                if($student_dtl[0]->pickup_station >0){
                             $pr = $smodel->gettable_data('station_session_tbl', $where = array('session_name' => $student_dtl[0]->pickup_session, 'station_id' => $student_dtl[0]->pickup_station));
                              $pick_session="";
                                if($student_dtl[0]->pickup_session==1){
                               $pick_session="Morning";
                                }
                                if($student_dtl[0]->pickup_session==2){
                               $pick_session="Afternoon";
                                }
                                 if($student_dtl[0]->pickup_session==3){
                               $pick_session="Evening";
                                }
                             //   echo $pr[0]->route_id;
                         $route = $smodel->gettable_data('route_tbl', $where = array('id' => $pr[0]->route_id,));
                        //  print_r($route);
                        //  return;
                         $vhcl = $smodel->gettable_data('vehicles_list_tbl', $where = array('id' => $route[0]->vehicle,));
                          $driver = $smodel->gettable_data('users', $where = array('user_id' => $vhcl[0]->driver_name,));
                                ?>
                                  <tr>
                             <td><?= $pick_session;?></td>  
                            <td><?= $vhcl[0]->driver_contact." (".$vhcl[0]->vehicle_number.")";?></td>
                            <td><?= $driver[0]->first_name." ".$driver[0]->last_name;?></td>  
                                  </tr>
                              <?php 
                          } 
                               if($student_dtl[0]->drop_station >0){
                             $pr = $smodel->gettable_data('station_session_tbl', $where = array('session_name' => $student_dtl[0]->drop_session, 'station_id' => $student_dtl[0]->drop_station));
                              $drop_session="";
                                if($student_dtl[0]->drop_session==1){
                               $drop_session="Morning";
                                }
                                if($student_dtl[0]->drop_session==2){
                               $drop_session="Afternoon";
                                }
                                 if($student_dtl[0]->drop_session==3){
                               $drop_session="Evening";
                                }
                         $route = $smodel->gettable_data('route_tbl', $where = array('id' => $pr[0]->route_id,));
                        
                         $vhcl = $smodel->gettable_data('vehicles_list_tbl', $where = array('id' => $route[0]->vehicle,));
                          $driver = $smodel->gettable_data('users', $where = array('user_id' => $vhcl[0]->driver_name,));
                                ?>
                                  <tr>
                             <td><?= $drop_session;?></td>  
                            <td><?= $vhcl[0]->driver_contact." (".$vhcl[0]->vehicle_number.")";?></td>
                            <td><?= $driver[0]->first_name." ".$driver[0]->last_name;?></td>  
                                  </tr>
                              <?php } ?>
                              </tbody>
                          </table>
                        </div>
                     
                    </div>
                    <div class="col-md-7">
                        <form class="form-horizontal" id="admtion">
                            <div class="card">
                         <p Class=" d-flex justify-content-center mt-2">TRANSPORT DETAILS</p>
                        
                            <div class="form-group row">
                                   <?php
                                $t_name="";
                                if($student_dtl[0]->transport_type !=0){
                             $types = $amodel->get_student_details('transport_type_tbl',$where = array('id ' => $student_dtl[0]->transport_type));
                             $t_name=$types[0]->type_name;
                                 }
                                ?>

                                 <label class="col-md-3 col-form-label mb-3">Transport Type:</label>
                                <div class="col-md-3 mb-3">
                                   <input type="text" class=" form-control-plaintext" value="<?php echo $t_name;?>" readonly>
                                </div>
                                <div class="col-md-6 mb-3"></div>
                                
                                <label class="col-md-3 col-form-label">Academic Year:</label>
                                <div class="col-md-3">
                                   
                                   <input type="text" class=" form-control-plaintext" value="<?php echo date('Y');?>" readonly>
                                </div>
                                <?php 
                                    if(count($admission) == 0){
                                    
                                ?>
                                <label class="col-md-2 col-form-label"> Date:</label>
                                <div class="col-md-4">
                                   <input type='date' class="form-control-plaintext"  value="<?php echo date('Y-m-d',strtotime($student_dtl[0]->date_created))?>" readonly />
                                </div>
                            <?php } ?>
                            </div>
                            <!--------------------------------------------------->
                               <div class="form-group row">
                                <label class="col-md-3 col-form-label">Transport Trip:</label>
                                <div class="col-md-2">
                                    <?php
                                   if($student_dtl[0]->transport_trip==1){
                                    ?>
                                    
                                        <label class="col-form-label" for="Continous">
                                       One way
                                        </label>
                                     
                                    <?php }?>
                                    
                                         <?php
                                   if($student_dtl[0]->transport_trip==2){
                                    ?>
                                   <label class="col-form-label" for="new">
                                            Round Trip
                                        </label>
                                   
                                    <?php }?>
                                    
                                </div>
                              
                            <!---------------------------------------------------->
                                </div>
             
                            <div id="pickup_e" style="display:none;">
                            <div class="form-group row">
                                 <?php
                                   if($student_dtl[0]->transport_trip==2 ||$student_dtl[0]->transport_trip==1 && $student_dtl[0]->pickup_station >0){
                                     $pist = $smodel->gettable_data('station_tbl', $where = array('id' => $student_dtl[0]->pickup_station));
                                     $pr = $smodel->gettable_data('station_session_tbl', $where = array('session_name' => $student_dtl[0]->pickup_session, 'station_id' => $student_dtl[0]->pickup_station));
                                     if($student_dtl[0]->pickup_session==1){
                                        $sessp='Morning';
                                    }
                                    elseif($student_dtl[0]->pickup_session==2){
                                        $sessp='Afternoon';
                                    }
                                    elseif($student_dtl[0]->pickup_session==3){
                                        $sessp='Evening';
                                    }
                                    ?>
                                <label class="col-md-3 col-form-label">Pick Up Station:</label>
                                <div class="col-md-3">
                                    
                                     <input type='text' class="form-control-plaintext"  value="<?php echo $pist[0]->station_name ?>" readonly />
                                     <input type='hidden' class="form-control-plaintext"  id="pick" value="<?php echo $student_dtl[0]->pickup_station ?>" readonly />
                                         <input type='hidden' class="form-control-plaintext"  id="trip" value="<?php echo $student_dtl[0]->transport_trip ?>" readonly />
                                    
                                </div>

                               <label class="col-md-3 col-form-label">Session:</label>
                                <div class="col-md-3">
                                      <input type='text' class="form-control-plaintext"  value="<?php echo $sessp.'-'.$pr[0]->session_time; ?>" readonly />
                                 </div>
                                 <script type="text/javascript">
                                    $(document).ready(function(){
                                     showStations(1);
                                     ShowSession(<?php echo $student_dtl[0]->pickup_station ?>,1);
                                       //alert('drop');
                                   });
                                         </script>
                                  <?php 
                                }
                                ?>
                            </div>
                            </div>
                           
                           <div id="dropoff_e" style="display: none;">
                              <div class="form-group row">
                                <?php
                                   if($student_dtl[0]->transport_trip==2 ||$student_dtl[0]->transport_trip==1 && $student_dtl[0]->drop_station >0){
                                     $pist = $smodel->gettable_data('station_tbl', $where = array('id' => $student_dtl[0]->drop_station));
                                     $pr = $smodel->gettable_data('station_session_tbl', $where = array('session_name' => $student_dtl[0]->drop_session, 'station_id' => $student_dtl[0]->drop_station));
                                     if($student_dtl[0]->drop_session==1){
                                        $sessp='Morning';
                                    }
                                    elseif($student_dtl[0]->drop_session==2){
                                        $sessp='Afternoon';
                                    }
                                    elseif($student_dtl[0]->drop_session==3){
                                        $sessp='Evening';
                                    }
                                    ?>
                                <label class="col-md-3 col-form-label">Drop Off Station:</label>
                                <div class="col-md-3">
                                    <input type='text' class="form-control-plaintext"  value="<?php echo $pist[0]->station_name ?>" readonly />
                                     <input type='hidden' id="drop" class="form-control-plaintext"  value="<?php echo $student_dtl[0]->drop_station ?>" readonly />
                                 </div>
                                 <label class="col-md-3 col-form-label">Session:</label>
                                <div class="col-md-3">
                                   <input type='text' class="form-control-plaintext"  value="<?php echo $sessp.'-'.$pr[0]->session_time; ?>" readonly />
                                 
                                </div>
                                <script type="text/javascript">
                                    $(document).ready(function(){
                                     showStations(2);
                                     ShowSession(<?php echo $student_dtl[0]->drop_station ?>,2);
                                       //alert('drop');
                                   });
                                         </script>
                                <?php 
                                }
                                ?>
                            </div>
                            </div>
                            <!-----------------------original pickup and drop  show----------------------------->
                            <!---------------------------------------------------->
                           
                            <!--------------------------end pick and drop-------------------------->
                          <div class="form-group row">
                                <label class="col-md-3 col-form-label">Start Date:</label>
                                <div class="col-md-3">
                                     <input type='text' class="form-control-plaintext"  value="<?php echo date('Y-m-d',strtotime($student_dtl[0]->start_date))?>" readonly/>
                                
                                </div>
                                <label class="col-md-3 col-form-label">Total Month:</label>
                                <div class="col-md-3">
                                      <input type='text' class="form-control-plaintext"  value="<?php echo $student_dtl[0]->month ?>" readonly />
                                
                                </div>
                            </div>

                              <div class="form-group row" id="end_date" style="">
                                <label class="col-md-3 col-form-label">End Date:</label>
                                <div class="col-md-3">
                              <input type='text' class="form-control-plaintext"  value="<?php echo date('Y-m-d',strtotime($student_dtl[0]->end_date))?>"  readonly/>
                                
                                </div>
                               
                            </div>


</div>
<script type="text/javascript">
    $(document).ready(function(){
   
     //monthly_item(<?php echo $student_dtl[0]->month ?>);
       //alert('drop');
   });
         </script>
  

<div class="form-group row">
    <div class="col-md-12">
        <div class="card">
            <p Class=" d-flex justify-content-center mt-1">TRANSACTION HISTORY</p>
              <table class="table table-hover table-vcenter mb-0 text-nowrap" style="">
                <thead>
                    <tr>
                        
                        <th>Date</th>
                        <th>TRANS NO</th>
                        
                        <th>Trans type</th>
                        <th>aMOUNT</th>
                        <th>RECEIVED BY</th>
                     </tr>
                </thead>
                <tbody style="">
                 <?php 
                $inv_amount = $amodel->get_student_details('ledger_transaction_tbl',$where = array('trans_no' => $tps[0]->trans_numb,'trans_type'=>1,'transation_nature'=>2,'ledger_type'=>7));
                  $by = $amodel->get_student_details('transaction_numbers_tbl',$where = array('trans_number' =>  $tps[0]->trans_numb,'trans_type_id'=>1));
                  $inv_name=$amodel->get_student_details('users',$where = array('user_id' => $by[0]->updated_by));
                  ?>
                  <tr>
                <td><?= $by[0]->updated_date; ?></td>
               <td><?= $tps[0]->trans_numb; ?></td>
               <td><?= 'Invoice'; ?></td>
                <td><?= number_format($inv_amount[0]->amount); ?></td>
                
               <td><?= $inv_name[0]->first_name.' '.$inv_name[0]->last_name; ?></td>
                </tr>
                  <?php

              $tsc = $amodel->get_student_details('transactions_relation',$where = array('invoice_trans_no' => $tps[0]->trans_numb));

                              if(count($tsc)>0){
                                foreach($tsc as $ts){
                             $lg = $amodel->get_student_details('ledger_transaction_tbl',$where = array('trans_no' => $ts->receipt_trans_no,'trans_type'=>2,'transation_nature'=>1,'ledger_type'=>7)); 

                             $tn = $amodel->get_student_details('transaction_numbers_tbl',$where = array('trans_number' => $lg[0]->trans_no,'trans_type_id'=>2));
                             $name=$amodel->get_student_details('users',$where = array('user_id' => $tn[0]->updated_by));
                             $type=$amodel->get_student_details('transaction_types_tbl',$where = array('type_id' => $tn[0]->trans_type_id));
                              
                                      ?>
                                        <tr>
                                            <td><?= $tn[0]->updated_date; ?></td>
                                           <td><?= $ts->receipt_trans_no; ?></td>
                                           <td><?= $type[0]->type_name; ?></td>
                                            <td><?= number_format($lg[0]->amount); ?></td>
                                            
                                           <td><?= $name[0]->first_name.' '.$name[0]->last_name; ?></td>
                                        </tr>
                                    <?php 

                                }
                             
                              }    ?>
                </tbody>
              
            </table>
        </div>
    </div>
</div>

<div class="form-group row">
    <div class="col-md-12">
        <div class="card" style="overflow-x:auto;">
            <p Class=" d-flex justify-content-center mt-1">MASSAGE HISTORY</p>
               <table class="table table-hover table-vcenter mb-0 text-nowrap" style="width: 500px">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th> Massage Id</th>
                                        <th>phone</th>
                                        <th>message</th>
                                        <th>Status</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                   
                              $mgt = $amodel->get_student_details('message_groups_tbl',$where = array('trans_number' => $tps[0]->trans_numb,'message_type'=>1));
                              if(count($mgt)>0){
                                        
                                 $msg = $amodel->get_student_details('messages',$where = array('send_no' => $mgt[0]->send_number,'message_type'=>1));
                                 // print_r($msg);
                                 $del=$msg[0]->status_description;
                                         $time=$msg[0]->time_delivered;
                                    $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                            
                                      ?>
                                        <tr>
                                            <td><?= $mgt[0]->massage_date; ?></td>
                                            <td><?= $msg[0]->message_id; ?></td>
                                            <td><?= $msg[0]->phone_no; ?></td>
                                    <td> <textarea cols='25' rows='5' readonly style='border:none;outline:none;resize:none;'> <?php echo $msg[0]->message; ?></textarea></td>
                                           <td><?= $stata; ?></td>
                                        </tr>
                                    <?php } 
                             $mgt = $amodel->get_student_details('message_groups_tbl',$where = array('trans_number' => $tps[0]->trans_numb,'message_type'=>7));
                              if(count($mgt)>0){
                                 foreach($mgt as $mg){       
                                 $msg = $amodel->get_student_details('messages',$where = array('send_no' => $mg->send_number,'message_type'=>7));
                                 // print_r($msg);
                                 $del=$msg[0]->status_description;
                                         $time=$msg[0]->time_delivered;
                                    $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                                    ?>
                                    
                                        <tr>
                                            <td><?= $mgt[0]->massage_date; ?></td>
                                            <td><?= $msg[0]->message_id; ?></td>
                                            <td><?= $msg[0]->phone_no; ?></td>
                                         <td> <textarea cols='25' rows='5' readonly style='border:none;outline:none;resize:none;'> <?php echo $msg[0]->message; ?></textarea></td>
                                           <td><?= $stata; ?></td>
                                        </tr>
                                    <?php }}
                                    $rct = $amodel->get_student_details('transactions_relation',$where = array('invoice_trans_no' => $tps[0]->trans_numb));
                                    if(count($rct)>0){

                                 $rcm = $amodel->get_student_details('message_groups_tbl',$where = array('trans_number' => $rct[0]->receipt_trans_no,'message_type'=>2)); 

                                 if(count($rcm)>0){
                                    //echo $rct[0]->receipt_trans_no;
                                 foreach($rcm as $rc){       
                                 $msg = $amodel->get_student_details('messages',$where = array('send_no' => $rc->send_number,'message_type'=>2));
                                 // print_r($msg);
                                 $del=$msg[0]->status_description;
                                         $time=$msg[0]->time_delivered;
                                    $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                                    ?>
                                    
                                     <tr>
                                            <td><?= $rcm[0]->massage_date; ?></td>
                                            <td><?= $msg[0]->message_id; ?></td>
                                            <td><?= $msg[0]->phone_no; ?></td>
                                        <td> <textarea cols='25' rows='5' readonly style='border:none;outline:none;resize:none;'> <?php echo $msg[0]->message; ?></textarea></td>
                                           <td><?= $stata; ?></td>
                                        </tr>
                                    <?php }}
                                    }
                                    $rct = $amodel->get_student_details('transactions_relation',$where = array('invoice_trans_no' => $tps[0]->trans_numb));
                                    if(count($rct)>0){
                                 $rcm = $amodel->get_student_details('message_groups_tbl',$where = array('trans_number' => $rct[0]->receipt_trans_no,'message_type'=>7)); 

                                 if(count($rcm)>0){
                                 foreach($rcm as $rc){       
                                 $msg = $amodel->get_student_details('messages',$where = array('send_no' => $rc->send_number,'message_type'=>7));
                                 // print_r($msg);
                                 $del=$msg[0]->status_description;
                                         $time=$msg[0]->time_delivered;
                                    $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                                    ?>
                                    
                                     <tr>
                                            <td><?= $rcm[0]->massage_date; ?></td>
                                            <td><?= $msg[0]->message_id; ?></td>
                                            <td><?= $msg[0]->phone_no; ?></td>
                                        <td> <textarea cols='25' rows='5' readonly style='border:none;outline:none;resize:none;'> <?php echo $msg[0]->message; ?></textarea></td>
                                           <td><?= $stata; ?></td>
                                        </tr>
                                    <?php }}
                                    }
                                    ?>
                                </tbody>
                            </table>
    
</div>
</div>
</div>
                            
                        </form>
                    </div>
                </div>
            <!-- </div> -->
        <!-- </div> -->
    </div>
</div>


<script src="<?php //echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
         var selectedItem = [];
        var  hold_selected_items=[];
   $(document).ready(function(){
     $('#selectone_e').show();
        $('#pickup_e').show();
        $('#dropoff_e').show();
         $('#chargedItem').select2({
            ajax: {
                url: "<?= base_url('load_data'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

        $('#chargedItem').on('select2:select', function (e) {
            selectedItems();
        });
         
        function selectedItems(){ 
            var rows = '';
           var itemData = 'item_selected='+$('#chargedItem').val()+'&selected_items_array='+selectedItem;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Itemdata')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }  
           });  

        } 
    });

   $('#saveitem').click(function(evt){
     //$('#itemsbdy').empty();
    //alert($(this).serialize());
        var data = 'itemid=' + $('#chargedItem').val();
        var account_ttl = 0; 
        var classlevel_items = "";
        var account = 0;
        
        var qty =$('#numb').val();
        var sn = 1;
   
  $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/ClassController/fetch_charged_item'; ?>',
            success: function(response){
                console.log(response);
                var lData = JSON.parse(response);
                var len = lData.length;

                for(var i = 0; i < len; i++){
                    // var qty = lData[i]['quantity'];
                    var price = lData[i]['price'];
                    var iid = lData[i]['item_id'];
                    var ttl = qty * price;
                     account_ttl = account_ttl + ttl; 
                     account = 6;
                     var qua='quantity'+iid+'';

                    $('#total').val(ttl);

                    $('#itemsbdy').append('<tr id="row_'+ lData[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+lData[i]['item_id']+'">'+lData[i]['item_id']+'</td>\
                        <td>'+lData[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+lData[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                        <td><div class="text-end"><input type="hidden" name="price'+lData[i]['item_id']+'" value="'+price+'">'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</div></td>\
                        <td></td>\
                        <td class=""><div class="text-end"><input type="hidden" name="price'+lData[i]['item_id']+'" value="'+ttl+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</div></td>\
                        <td></td>\
                        <td>\
                            <a href="javascript:RemoveRow('+lData[i]['item_id']+','+account_ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
                classlevel_items = {iid:iid, account: account,qua:qty, prco: account_ttl};
                receivable_total.push(classlevel_items);

               totalsum=totalsum+account_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });

        evt.preventDefault();
   });

    /////////////////////////////////////////////////////////////////////
    var appclass;
    var totalsum=0;
    $(document).ready(function(){
        $('#clevel').change();
       appclass = '<?php echo $app_class; ?>';
    
    });
    
    // datePickerId.max = new Date().toISOString().split("T")[0];
    $(function () {
        $('#datetimepicker1').datetimepicker();
    });

    $(function() {
        $( "#datepicker" ).datepicker({dateFormat: 'yy'});
    });
    var receivable_total_balance = [];
    var receivable_total = [];
    // $('#croom').load('load_classRooms');
    $('#clevel').change(function(){
         document.getElementById("day").checked = true;
    document.getElementById("no").checked = true;
        var InputOption = '';
        var data = 'level=' + $('#clevel').val();
        // alert(data);

        $.ajax({
            type:'POST',
            url:'load_classRooms',
            data:data,
            dataType:'json',
            success:function(res){
               
                var len = res.length;
                $("#croom").empty();
                $("#croom").append("<option value=''>-Choose-</option>");

                for( var i = 0; i<len; i++){

                    var id = res[i]['id'];
                    var name = res[i]['cname'];
                    var total = res[i]['capcity'];
                    if(total <= 0){
                        InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Room for New Student'+"</option>";
                    }else{
                        if(appclass == id)
                        InputOption = "<option value='"+id+"' selected>"+name+"\xa0\xa0"+'-'+"\xa0"+total+"</option>";
                        else
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+'-'+"\xa0"+total+"</option>";    
                    }
                    $("#croom").append(InputOption);

                   
                }
                 get_classlevel_chargedItems();
            }
        });
    });
    function ShowSession(id,pd){
          //alert(id);
        
        var InputOption = '';
        if(id >0){
           var data = 'id=' + id;
           var empty=0;
        }else{
        var data = 'id=' + id.value;
        var empty=1;
        }
        $.ajax({
            type:'POST',
            url:'getSessiondta',
            data: data,
            dataType: 'json',
            success:function(data){

                // console.log(data);
                // return;
                var len = data.length;
                if(pd==1){

                    if(empty==1){
                  $('#itemsbdy').empty();
                 $('#end_date').hide();
                 $('#tmonth').val('');
                  totalsum=0;
     document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                $("#sess").empty();
                $("#sessnew").empty();
                $("#sess").append("<option value=''>-Choose-</option>");
                $("#sessnew").append("<option value=''>-Choose-</option>");
                  }
                // 

                // $('#stream').html(data);
                for( var i = 0; i<len; i++){

                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    var time = data[i]['time'];
                    var stm = 20;
                    if(stm <= 0){
                        InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Seat for New Student'+"</option>";
                    }else{
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+'-'+"\xa0"+time+"</option>";
                    }
                    $("#sess").append(InputOption);
                    $("#sessnew").append(InputOption);
                }
            }else if(pd==2){

              if(empty==1){
                 $('#itemsbdy').empty();
                 $('#end_date').hide();
                 $('#tmonth').val('');
                  totalsum=0;
     document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                $("#session").empty();
                $("#sessionnew").empty();
                $("#session").append("<option value=''>-Choose-</option>");
                $("#sessionnew").append("<option value=''>-Choose-</option>");
                  }
                // 

                // $('#stream').html(data);
                for( var i = 0; i<len; i++){

                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    var time = data[i]['time'];
                    var stm = 20;
                    if(stm <= 0){
                        InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Seat for New Student'+"</option>";
                    }else{
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+'-'+"\xa0"+time+"</option>";
                    }
                    $("#session").append(InputOption);
                    $("#sessionnew").append(InputOption);
                }  
            }
                // console.log(sum);

                //getClass_Charged_items();
            }
        });
    }

    function get_classlevel_chargedItems(){
         document.getElementById("filLv").innerHTML = "";
        $('#itemsbdy').empty();
        var data = 'levelID=' + $('#clevel').val();
        var account_ttl = 0; 
        var classlevel_items = "";
        var account = 0;
        $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/ClassController/fetch_classLevel_ItemData'; ?>',
            success: function(response){
                console.log(response);
                var lData = JSON.parse(response);
                var len = lData.length;

                for(var i = 0; i < len; i++){
                    var qty = lData[i]['quantity'];
                    var price = lData[i]['price'];
                    var ttl = qty * price;
                     account_ttl = account_ttl + ttl; 
                     account = lData[i]['account'];

                    $('#total').val(ttl);
                  $('#itemsbdy').append('<tr id="row_'+ lData[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid[]" value="'+lData[i]['item_id']+'">'+lData[i]['item_id']+'</td>\
                        <td>'+lData[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+lData[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                        <td style="text-align:right"  class="text-end"><input type="hidden" name="price'+lData[i]['item_id']+'" value="'+price+'">'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td id="total" style="text-align:right"  class="text-end"><input type="hidden" name="total'+lData[i]['item_id']+'" value="'+ttl+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\
                        <td>\
                            <a href="javascript:RemoveRow('+lData[i]['item_id']+','+account_ttl+');" class="btn btn-danger">x</a>\
                        </td>\
                    </tr>');
                }
                //classlevel_items = {account_receivable: account, amount: account_ttl};
                 classlevel_items = {iid:iid,qty:qty, price:price, account_receivable: account, amount: account_ttl};
                //receivable_total_balance.push(class_items);
                receivable_total_balance.push(classlevel_items);

               totalsum=account_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });
    }
     function monthly_item(id){
        if(id>0){
             var hold=0;
           monthly_items(id,hold);

        }else{
            id=id.value;
         var hold=1;
         var data = 'start=' + $('#start').val()+'&month=' + id;
         //alert(data);
     $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/ClassController/append_date'; ?>',
            success: function(res){
                var date = JSON.parse(res);
                  $('#end_date').show();
                  $('#end').val(date[0]['end_date']);
                  monthly_items(id,hold);
            }
            });
       }
     }
    function monthly_items(id,hold){
         $('#itemsbdy').empty();
         totalsum=0;
     document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         
        var trip= $('#trip').val();
        //alert(type);
        if($('#pick').val()==""){
          var pick=$('#picknew').val();
        }else{
           var pick=$('#pick').val();
        }
        if($('#drop').val()==""){
          var drop=$('#dropnew').val();
        }else{
           var drop=$('#drop').val();
        }
        var data = 'station_pick=' + pick+'&station_drop=' + drop+'&trip=' + trip+'&month=' + id;
       // alert(data);

        var account_ttl = 0; 
        var station_items = "";
        var account = 0;
        $.ajax({
            type: 'GET',
            data: data,
           // url: 'fetch_clsItems_data',
            url: 'fetch_station_data',
            success:function(res){

                var class_data = JSON.parse(res);
                var len = class_data.length;
                for(var i = 0; i < len; i++){
                    
                 hold_selected_items.push(class_data[i]['item_id']);
                     
                    // receivable_total_balance.push(class_data[i]['account']);
                    // alert(receivable_total_balance);
                    // return;
                    var iid=class_data[i]['item_id'];
                    var qty = class_data[i]['quantity'];
                    var price = class_data[i]['price'];
                    var ttl = qty * price;
                     account_ttl = account_ttl + ttl; 
                     account = class_data[i]['account'];

                    $('#total').val(ttl);


                    $('#itemsbdy').append('<tr id="row_'+ class_data[i]['item_id'] +'"><input type="hidden" name="account" value="'+account+'">'+
                        '<td><input type="hidden" name="iid" value="'+class_data[i]['item_id']+'">'+class_data[i]['item_id']+'</td>\
                        <td>'+class_data[i]['name']+'</td>\
                        <td></td>\
                        <td></td>\
                        <td></td>\
                        <td><input type="hidden" name="quantity'+class_data[i]['item_id']+'" value="'+qty+'">'+qty+'</td>\
                        <td>\
                        <a class="cost2" id="cost' +iid+'" style=""><input type="text" value="'+price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'" style="border:none;cursor:pointer;width:60px;text-align:right;" id="prc'+iid+'" readonly></a>\
                        </td>\
                        <td><input type="hidden" name="prco'+iid+'" id="prco'+iid+'" value="'+ttl+'"></td>\
                        <td class="text-right" style="text-align:right" id="total'+iid+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>\
                        <td></td>\ </tr>');
                }
                class_items = {iid:iid,qty:qty, price:price, account_receivable: account, amount: account_ttl};
                receivable_total_balance.push(class_items);
                // console.log(receivable_total_balance);

                  totalsum=account_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;
            }
        });
    }
    function tg_cash(id,ttl) {
        $('#cash').toggle(100);
        
        $('input[name=cash_amt0]').val(ttl);

    }

        function tg_change(id) {
          var name="item";
          var qty=1;
          //alert('change');
        var cashAmt =parseInt($('input[name=total'+id+']').val());
        alert(cashAmt);/////////////////////////////////////////
                  
        
         totalsum=cashAmt;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;       
        e.preventDefault();
    };
    function RemoveRow(item_id,account_ttl){
         totalsum=totalsum-account_ttl;
            document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
           // return totalsum;
         $('#row_'+item_id).remove();

              
    }

    

$('input[type=radio][name=admit]').change(function(){
    //document.getElementById("day").checked = true;
    //document.getElementById("no").checked = true;
        var data =  $(this).val();
        $('#itemsbdy').empty();
         $(function() {
        $( "#clevel" ).change();
        totalsum=0;
        document.getElementById("filLert").innerHTML = "Choose class";
       console.log(totalsum);
            return totalsum;
    });
      if($( "#clevel" ).val()==""){
       document.getElementById("filLv").innerHTML = "Choose Level"; 
      }
        
    });



    $('input[type=radio][name=trip]').change(function(){
        $('#itemsbdy').empty();
        $('#tmonth').val('');
        $('#end_date').hide();
        totalsum=0;
     document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        var data =  $(this).val();
        var InputOption = '';
        // alert(data);
        if(this.value == 1){
            $('#selectone').show();
            $('#selectone_e').hide();
              $('#dropoff_e').hide();
              $('#pickup_e').hide();
              $('#pickup').hide();
              $('#dropoff').hide();
        }else if(this.value == 2){
               $('#selectone').hide();
               $('#selectone_e').hide();
                $('#dropoff_e').hide();
              $('#pickup_e').hide();
              $('#pickup').show();
            $('#dropoff').show();
               //////////////////////////////////////////////////////
            $.ajax({
            type:'POST',
            //url:'getStreamdta',
            url:'getStationdata',
            data: data,
            dataType: 'json',
            success:function(data){

                // console.log(data);
                // return;
                var len = data.length;
                $("#pick").empty();
                $("#picknew").empty();
                $("#drop").empty();
                $("#dropnew").empty();
                $("#pick").append("<option value=''>-Choose-</option>");
                $("#picknew").append("<option value=''>-Choose-</option>");
                $("#drop").append("<option value=''>-Choose-</option>");
                $("#dropnew").append("<option value=''>-Choose-</option>");

                // $('#stream').html(data);
                for( var i = 0; i<len; i++){

                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    var stream = 20;
                    if(stream <= 0){
                        InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Room for New Student'+"</option>";
                    }else{
                         InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+"</option>";
                    }
                    $("#pick").append(InputOption);
                    $("#picknew").append(InputOption);
                    $("#drop").append(InputOption);
                    $("#dropnew").append(InputOption);
                }
                // console.log(sum);

                //getClass_Charged_items();
            }
        });
        /////////////////////////////////////////////////////
        }
    });

 $('input[type=radio][name=selectednew]').change(function(){
    $('#itemsbdy').empty();
     $('#tmonth').val('');
     $('#end_date').hide();
    totalsum=0;
     document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        var data =  $(this).val();
        var InputOption = '';
         //alert(data);
        if(this.value == 1){
            $('#pickup').show();
              $('#dropoff').hide();
              $('#dropoff_e').hide();
              $('#pickup_e').hide();
          //////////////////////////////////////////////////////
            $.ajax({
            type:'POST',
            //url:'getStreamdta',
            url:'getStationdata',
            data: data,
            dataType: 'json',
            success:function(data){

                // console.log(data);
                // return;
                var len = data.length;
                $("#pick").empty();
                $("#picknew").empty();
                $("#pick").append("<option value=''>-Choose-</option>");
                $("#picknew").append("<option value=''>-Choose-</option>");

                // $('#stream').html(data);
                for( var i = 0; i<len; i++){

                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    var stream = 20;
                    if(stream <= 0){
                        InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Room for New Student'+"</option>";
                    }else{
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+"</option>";
                    }
                    $("#pick").append(InputOption);
                    $("#picknew").append(InputOption);
                }
                // console.log(sum);

               // getClass_Charged_items();
            }
        });
        /////////////////////////////////////////////////////
        }else if(this.value == 2){
              $('#pickup').hide();
              $('#pickup_e').hide();
              $('#dropoff_e').hide();
            $('#dropoff').show();
            var InputOption = '';
             //////////////////////////////////////////////////////
            $.ajax({
            type:'POST',
            //url:'getStreamdta',
            url:'getStationdata',
            data: data,
            dataType: 'json',
            success:function(data){

                // console.log(data);
                // return;
                var len = data.length;
                $("#drop").empty();
                $("#dropnew").empty();
                $("#drop").append("<option value=''>-Choose-</option>");
                $("#dropnew").append("<option value=''>-Choose-</option>");

                // $('#stream').html(data);
                for( var i = 0; i<len; i++){

                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    var stream = 20;
                    if(stream <= 0){
                        InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Room for New Student'+"</option>";
                    }else{
                         InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+"</option>";
                    }
                    $("#drop").append(InputOption);
                    $("#dropnew").append(InputOption);
                }
                // console.log(sum);

               // getClass_Charged_items();
            }
        });
        /////////////////////////////////////////////////////
        }
    });
    $('#admtion').submit(function(e){
       //function manage_transport(){
          var trip= $("input[type='radio'][name='trip']:checked").val();
        var data='student_id='+ $('input[name=sid]').val()+'&djoin='+ $('input[name=djoin]').val()+'&trip='+trip+'&pick='+ $('select[name=pick]').val()+'&drop='+$('select[name=drop]').val()+'&pick_sess='+ $('select[name=session_pick]').val()+'&drop_sess='+$('select[name=session_drop]').val()+'&receivable_total_balance=' + JSON.stringify(receivable_total_balance)+'&start_date='+ $('input[name=start]').val()+'&end_date='+ $('input[name=end]').val()+'&month='+ $('input[name=tmonth]').val()+'&ttl='+$('#total').val()+'&iid='+ $('input[name=iid]').val()+'&price='+ $('input[name=prco[]]').val();
        alert(data);
      // alert($(this).serialize());
         //alert($(this).serialize()+'&receivable_total_balance=' + JSON.stringify(receivable_total_balance));
        // return;
        $.ajax({
            beforeSend: function () {
                  $('#admit_student').prop("disabled", true);
                  $('#feedback').append('<div class="alert alert-primary alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button><i class="fa fa-spinner fa-spin"></i>Preparing Control Number Please wait..</div>');
            },
            type: 'POST',
           // url: '<?php echo base_url() . '/index.php/TransportController/save_transport_details'; ?>',
            data: data,
            success:function(res){
                var data = JSON.parse(res);
                if(res == "1"){
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Saved successfuly</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#admit_student').prop("disabled", false);
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            },
            error:function(res){
                $('#admit_student').prop("disabled", false);
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Admit student.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                setTimeout(function(){
            window.location.reload();
        },1000)
            }
        });

        e.preventDefault();
    })
    function getid(id,prc) {
     $('#cash').toggle(100);
      
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/priceview'; ?>",
            beforeSend: function () {
                $('#prcres').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#prcres').html(result);
                console.log(prc);
             document.querySelector('[id="cash_amt0"]').value = prc;
             document.querySelector('[id="item_id0"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }

    function savebtn(){
        //alert('yes');
        totalsum=0;
      var cash=$('#cash_amt0').val();
      var item_id=$('#item_id0').val();
      var month=parseInt($('#tmonth').val());
      alert(item_id+'/'+cash); 
      var c=0;
      for( var i = 0; i < hold_selected_items.length; i++){ 
           id1=hold_selected_items[i];
           if(id1==item_id){
            c=c+1;
            if(c>1){
                continue;
            }
            var cashAmt =parseInt(cash);
            var ttl =cashAmt*month;
            document.querySelector('[id="prco'+id1+'"]').value = cashAmt;
            document.querySelector('[id="prc'+id1+'"]').value = cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            document.getElementById("total"+id1).innerHTML = ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

           // $('#cost'+id1+'').append(cashAmt);
           }else{
            var cashAmt1 =$('#prc'+id1+'').val();
            let result = cashAmt1.replace(/,/gi, "");
        
            var cashAmt =parseInt(result);
           // alert(cashAmt);
           }
       //alert(cashAmt);
        totalsum=totalsum+ttl;
        }       
          $('#cash').hide(); 
             document.getElementById("totalsum").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            return totalsum;       
         e.preventDefault(); 
    }
    //////////////////////////////////////////////////////////////////////
document.getElementById("submitButton").addEventListener("click", function() {
  const form = document.getElementById("admtion");
  const formData = new FormData(form);
  const serializedFormData = {};
 
  for (const [key, value] of formData.entries()) {
    serializedFormData[key] = value;
  }
receivable_total.push(serializedFormData);
  const serializedJSON = JSON.stringify(receivable_total);
  console.log(serializedJSON);

  var data='trans_data='+serializedJSON+'&'+$("#header_form").serialize();
  // alert($(this).serialize());
  //alert(data);
      $.ajax({
            beforeSend: function () {
                  $('#admit_student').prop("disabled", true);
                  $('#feedback').append('<div class="alert alert-primary alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button><i class="fa fa-spinner fa-spin"></i>Preparing Control Number Please wait..</div>');
            },
            type: 'POST',
          //  url: '<?php echo base_url() . '/index.php/TransportController/Edit_transport_details'; ?>',
            data: data,
            success:function(res){
                var data = JSON.parse(res);
                if(res == "1"){
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Transport Edited successfuly</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#admit_student').prop("disabled", false);
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            },
            error:function(res){
                $('#admit_student').prop("disabled", false);
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt edit transport.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
        //         setTimeout(function(){
        //     window.location.reload();
        // },1000)
            }
        });

        e.preventDefault();

});

function showStations(id){
        
         var data = id;
        var InputOption = '';
        // alert(data);
        if(id == 1){
            $('#pickup_e').show();
              $('#dropoff').hide();
          //////////////////////////////////////////////////////
            $.ajax({
            type:'POST',
            //url:'getStreamdta',
            url:'getStationdata',
            data: data,
            dataType: 'json',
            success:function(data){

                // console.log(data);
                // return;
                var len = data.length;
                // $("#pick").empty();
                // $("#pick").append("<option value=''>-Choose-</option>");

                // $('#stream').html(data);
                for( var i = 0; i<len; i++){

                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    var stream = 20;
                    if(stream <= 0){
                        InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Room for New Student'+"</option>";
                    }else{
                        InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+"</option>";
                    }
                    $("#pick").append(InputOption);
                }
                // console.log(sum);

               // getClass_Charged_items();
            }
        });
        /////////////////////////////////////////////////////
        }else if(id == 2){
           // alert(id);
              $('#pickup').hide();
            $('#dropoff_e').show();
            var InputOption = '';
             //////////////////////////////////////////////////////
            $.ajax({
            type:'POST',
            //url:'getStreamdta',
            url:'getStationdata',
            data: data,
            dataType: 'json',
            success:function(data){

                // console.log(data);
                // return;
                var len = data.length;
                // $("#drop").empty();
                // $("#drop").append("<option value=''>-Choose-</option>");

                // $('#stream').html(data);
                for( var i = 0; i<len; i++){

                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    var stream = 20;
                    if(stream <= 0){
                        InputOption = "<option value='"+id+"' disabled style='color:red'>"+name+"\xa0\xa0"+'-'+"\xa0"+'No Room for New Student'+"</option>";
                    }else{
                         InputOption = "<option value='"+id+"'>"+name+"\xa0\xa0"+"</option>";
                    }
                    $("#drop").append(InputOption);
                }
                // console.log(sum);

               // getClass_Charged_items();
            }
    })
        }
    };
</script>