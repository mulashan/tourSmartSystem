<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<style>
  
    #strengthMeter {
    width: 100%;     /* Width of the entire container */
    height: 20px;    /* Height of the bar */
    background-color: #e0e0e0; /* Background color for the container */
    position: relative;
}

#strengthBar {
    height: 100%;      /* Ensures the bar fills the container height */
    width: 0%;         /* Start with a width of 0% */
    background-color: red; /* Initial color */
    position: absolute; /* Positioned within the container */
    left: 0;           /* Start from the left */
    transition: width 0.3s ease; /* Smooth expansion transition */
}
  </style>
<?php 
    helper('age');
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();
    $tmodel = new App\Models\TransportModel();

    $student = $smodel->gettable_data('students', $where = array('transport_status' => 0,'status'=>2));
    // $admission = $tmodel->gettable_dataT('transport_details');

?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Admission</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Student Transport</li>
                </ol>
            </div>
            
<!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#adm-add">Student(s) Transport List</a></li>
                <li class="nav-item"><a class="nav-link " data-toggle="tab" href="#Admsn-all">New Transport</a></li>
                
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#adm-add">Student(s) Transport List</a></li>
                  <li></li><li></li>
                <li class="nav-item"><a class="nav-link " data-toggle="tab" href="#Admsn-all">New Transport</a></li>
                
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane" id="Admsn-all">
                <div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable">
                            <thead>
                                <tr>
                                    <th>Reg no:</th>
                                    <th>Reg Date</th>
                                    <th>Student Name(s)</th>
                                    <th>DoB</th>
                                    <th>Age</th>
                                    <th>Class</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $class = "";
                                $row ="";
                                foreach ($student as $st):
                                    $admissions = $amodel->admission_classData($st->id);
                                    if(count($admissions) > 0){
                                        if($admissions[0]->status == 1){
                                            $class = $admissions[0]->class_name;
                                            $row = 'color:#804000';
                                        }
                                    }else{
                                        $class = "";
                                            $row = 'color:#27af50';
                                    }
                                 ?>
                                    <tr style="<?php echo $row;?>">
                                        <td><?= $st->student_id;?></td>
                                        <td><?= $st->date_created;?></td>
                                        <td><?= $st->first_name.' '. $st->middle_name.' '.$st->last_name;?></td>
                                        <td><?= $st->birth_date;?></td>
                                        <td><?= findAge($st->birth_date);?></td>
                                        <!-- <td><?php //echo (date('Y') - date('Y',strtotime($st->birth_date)));?></td> -->
                                        <td><?= $class;?></td>
                                        <td>
                                            <button type="button" class="btn btn-primary btn-sm AdmitID" data-id="<?= $st->id;?>"><i class="fa fa-truck"></i> Manage</button>
                                        </td>
                                    </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="tab-pane active" id="adm-add">
             <!--------------------------------------->

              <div class="input-group ms-3 me-3 mb-3 d-flex justify-content-center">
                           <form id="form1" class="form-inline">
                            Permit Date:
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </form>
                        </div>
                  <div class="d-flex justify-content-center">
                <div id="messageDisplayArea"></div>
                    <form id="form2" class="form-inline">
                      
                         Status: 
                        <select class="form-control form-select me-3" name="status" id="status">
                            <option value="0">All</option>
                            <option value="4">Paid</option>
                            <option value="3">Pending</option>
                            <option value="1">Active</option>
                            <option value="2">Expired</option>
                            </select>

                             Trans Type: 
                        <select class="form-control form-select me-3" name="trans_type" id="trans_type">
                            <option value="0">All</option>
                             <option value="1">One Way</option>
                            <option value="2">Round Trip</option>
                            </select>

                             Expire date: 
                          <button type="button" class="btn btn-default pull-right" id="daterange-btn2">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>

                            
                             <!--
                            
                        </select> -->
                        <button type="submit" class="btn btn-primary ms-3">Create</button>
                        
                    </form>

                </div>

                <center>
                 <div class="input-group col-md-4 mt-3">
                                                    
                    <input type="text" class="form-control" name="payer_name" id="search_name"   placeholder="Search Student Name" aria-label="Student Name" aria-describedby="button-st">
                    <button class="btn btn-outline-success" type="button" id="button-y">
                        <span>
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                        </span></button>
                    <button class="btn btn-outline-primary" type="button" id="button-st" onclick="searchnamebtn()"><i class="fa fa-search" aria-hidden="true"></i></button>
                </div>
                </center>
                <hr>
                &nbsp;<p></p>
                <center>
                    <!-- <div id="transport_area">
                        
                    </div> -->
                    <div id="strengthMeter" style="display:none">
                    <div id="strengthBar">
                         <span id="passantage" style="color: white;">0%</span>
                    </div>
                    </div>
                    
                                            
                      <div class="card">
                  
                        <div class="table-responsive mt-3">
                            <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable2">
                                <thead>
                                    <tr>
                                        <th>Permit NO</th>
                                        <th>Date</th>
                                        
                                        <th>Trans Type</th>
                                        <th>Student Names</th>
                                        <th>Age</th>
                                        <th>Class</th>
                                        <th>Days</th>
                                        <th>Expire Date</th>
                                        <th>Status</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody id="transport_area">

                             </tbody>
                            </table>
                        </div>

                   </div>
                </center>
         <!--------------------------------------------->
            </div>
        </div>
    </div>
</div>

<!-- ------Admit modal------ -->
<div id="editModal" class="modal fade"  role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <!-- <h5 class="modal-title" id="staticBackdropLabel">Transport Details</h5> -->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div id="transport_details">
                 <span class="fa fa-spinner">Loading...</span>
            </div>
        </div>
      </div>
      
    </div>
</div>
<!-- ------view modal------ -->
<!-- ------edit modal------ -->
<div id="myModal" class="modal fade"  role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
           <h5 class="modal-title" id="staticBackdropLabel">New Transport</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div id="admission"></div>
        </div>
      </div>
      
    </div>
</div>

   <!-- ------view modal------ -->
<div id="viewModal" class="modal fade"  role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <!-- <h5 class="modal-title" id="staticBackdropLabel">Transport Details</h5> -->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div id="admission_view">
                <span class="fa fa-spin"><i class="fa fa-spinner"></i></span>Loading...
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" id="print_att"><span class="fa fa-print"></span>Print</button>
            </div>
        </div>
      </div>
      
    </div>

<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script type="text/javascript">
    $(document).ready(function () {
      //$('#myTable2').DataTable();
    });

    $(".AdmitID").click(function () {
         // Call the function to clear cache and reload the page
         
        var data = 'id=' + $(this).attr('data-id');
        // alert (data);

        $('#myModal').modal('show');
         $('#admission').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');

        $.ajax({
            type: "GET",
            //url: "admission_details",
            url: "manage_transport_setup",
            data: data,
            beforSend: function()
            {
                $('#admission').html();
               //  clearCacheAndReload(); 
            },
            success: function(res){
                $('#admission').html(res);
                
            },
            error: function ()
            {

            }
        });
    });

    $("#closeAdmissionYearForm").submit(function(e) {
        var data = $(this).serialize();
        swal({
            title: "Are you sure?",
            text: "You are about to Close This Academic Year.",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, Close!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
        },
        function(isConfirm) {
            if (isConfirm) {
                $.ajax({
                    method: 'POST',
                    url: 'close_academic_year',
                    data: data,
                    error: function() {
                    alert('Something is wrong');
                    },
                    success: function(data) {
                        if(data == 1){
                            swal("Academic Year Closed!", "success");
                        }else{
                            alert('Something is wrong');
                        }    
                        setTimeout(function(){
                            window.location.reload();
                        },1000)
                    }
                });

            } else {
                swal("Cancelled");
            }
        });
        e.preventDefault();
    });

    function manage_admission(adm){
        $('#viewadmission').modal('show'); 
        $('#viewadmission_content').load('view_admissions/'+adm);
    }

      
     
//       function clearCacheAndReload() {
//   window.location.reload(true); // Pass 'true' to force a reload from the server and bypass the cache
// }


     $(function () {
            var start = moment();
            var end = moment();
            function cb(start, end) {
                $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
            }
            $('#daterange-btn').daterangepicker({
                startDate: start,
                endDate: end,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                     'This Year': [moment().startOf('year'), moment().endOf('year')]
                }
            }, cb);
             cb(start, end);

                            });

         $(function () {
            var start2 = moment().startOf('year');
            var end2 = moment().endOf('year');
            function cb2(start2, end2) {
                $('#daterange-btn2 span').html(start2.format('YYYY/M/D') + ' - ' + end2.format('YYYY/M/D'));
            }
            $('#daterange-btn2').daterangepicker({
                startDate: start2,
                endDate: end2,
                ranges: {
                    'All': [moment().startOf('year'), moment().endOf('year')],
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                     'This Year': [moment().startOf('year'), moment().endOf('year')]
                   
                }
            }, cb2);
             cb2(start2, end2);

                            });
   $('#form2').submit(function (e) {
   var start=0;
   var end=100;
    var table = $('#myTable2').DataTable();
          table.clear().destroy();
          //$('#transport_area').empty();
             if (!$('#daterange-btn span').html()) {
            $('#transport_area').html('Please specify valid date.');
        } else {
            // $('#transport_area').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn span').html()+"&expire=" + $('#daterange-btn2 span').html()+'&'+ $('#form2').serialize();
           // alert(dta);
            $.ajax({
                type: "POST",
               
               url: "<?php echo base_url() . '/index.php/TransportController/fetch_transports'; ?>/"+start+"/"+end,
                data: dta,
                success: function (res) {
                    $('#transport_area').append(res);
                    load_transport(end+1,end+100);
                    // $('#myTable2').DataTable();

                 var counted=$("#counted0").val();
               
                

                },
                error: function () {
                    $('#transport_area').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

          }
        e.preventDefault();
    });

var strength = (0/100)*100;
 const strengthBar = document.getElementById('strengthBar');
 const passantage = document.getElementById('passantage');
 strengthBar.style.width = strength + '%';
strengthBar.style.backgroundColor = 'red';
passantage.textContent = `${strength}%`;

function load_transport(start,end){
 var counted=$("#counted0").val();
  strength = parseInt((start/counted)*100);

 strengthBar.style.width = strength + '%';
       passantage.textContent = `${strength}%`;
      strengthBar.style.backgroundColor = 'green';

 if(start >=counted){
    $('#myTable2').DataTable();
    return;
 }
   $('#strengthMeter').show();
  var dta = "thedate=" + $('#daterange-btn span').html()+"&expire=" + $('#daterange-btn2 span').html()+'&'+ $('#form2').serialize();
           // alert(dta);
            $.ajax({
                type: "POST",
               
               url: "<?php echo base_url() . '/index.php/TransportController/fetch_transports'; ?>/"+start+"/"+end,
                data: dta,
                success: function (res) {
                    $('#transport_area').append(res);
                    if(end <=counted){
                    load_transport(end+1,end+100);
                       }else{
                        strength=100;
                        strengthBar.style.width = strength + '%';
                          passantage.textContent = `${strength}%`;
                        strengthBar.style.backgroundColor = 'green';
                        $('#strengthMeter').hide();
                        $('#myTable2').DataTable();
                       }
                    // $('#myTable2').DataTable();
                },
                error: function () {
                    $('#transport_area').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
}

function searchnamebtn(){
            var name=$('#search_name').val();
            var  year=$('#button-y').html();
            var table = $('#myTable2').DataTable();
                table.clear().destroy();
            // alert(year);
            if(name.length >=3){
                $('#transport_area').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
                var dta="name="+name+"&year="+year;
           // toastr.success(name.length);
             $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/index.php/TransportController/fetch_transport_byname'; ?>",
                data: dta,
                success: function (res) {
                    $('#transport_area').html(res);
                     $('#myTable2').DataTable();
                },
                error: function () {
                    $('#transport_area').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
        }else{
            if(name.length==0){
               $('#transport_area').html(''); 
            }else{
               $('#transport_area').html('<div class="alert alert-info">Search atleat 3 characters</div>'); 
            }
        
        }
        }

         function editTrans(id){
        // var id=$(this).attr('data-id');
        $('#editModal').modal('show');
        
      $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/index.php/TransportController/transport_detail_edit'; ?>/'+id,
           
            beforSend: function()
            {
                $('#transport_details').html();
            },
            success: function(res){
                $('#transport_details').html(res);
                 
            },
            error: function ()
            {

            }
        });
    };
           // $(".viewTrans").click(function () {
           function viewTrans(id){
        // var id=$(this).attr('data-id');
        $('#viewModal').modal('show');
        
      $.ajax({
            type: "GET",
            url: '<?php echo base_url() . '/index.php/TransportController/transport_detail_view'; ?>/'+id,
           
            beforSend: function()
            {
                $('#admission_view').html();
            },
            success: function(res){
                $('#admission_view').html(res);
                 
            },
            error: function ()
            {

            }
        });
    };
</script>