           <?php
          $transport = new App\Models\TransportModel();
            ?>
 <?php 

    $cmodel = new App\Models\ClassesModel();
 $accounts = $cmodel->get_accounts_items();
 $vehicle = $transport->search_vehicle($route[0]->vehicle);
 $drv = $transport->select_driver($vehicle[0]->driver_name);
 $stn = $transport->select_station($route[0]->id);
?>

<div class="container-fluid">
      <div class="" id="printable">
                        <center>
             
             <h5>SCHOOL BUS ROUTES SCHEDULE</h5>  
            
         
          <?php
              //********session route*********//
                     if($route[0]->route_session==1){
                                    $sess='Morning';
                                }
                                elseif($route[0]->route_session==2){
                                    $sess='Afternoon';
                                }
                                elseif($route[0]->route_session==3){
                                    $sess='Evening';
                                }           
             ?>
             <table class="mt-3">
                 <tr>
                     <td class="">ROUTE NAME:</td><td style="padding-left: 50px" class="w"></td><td style=""><?=$route[0]->route_name.'('.$sess.')'; ?></td>
                 </tr><tr>
                     <td class="me-5">VEHICLE NO:</td><td></td><td><?=$vehicle[0]->vehicle_number; ?></td>
                 </tr><tr>
                     <td class="me-5">VEHICLE CAPACITY:</td><td></td><td><?=$vehicle[0]->capacity; ?></td>
                 </tr><tr>
                     <td class="me-5">DRIVER NAME:</td><td></td><td><?=$drv[0]->first_name." ".$drv[0]->last_name; ?></td>
                 </tr><tr>
                     <td class="me-5">DRIVER'S NUMBER:</td><td></td><td><?=$drv[0]->phone_no; ?></td>
                 </tr><tr>
                     <td class="me-5">STARTING POINT:</td><td></td><td><?=$route[0]->station; ?></td>
                 </tr><tr>
                     <td class="me-5">STARTING TIME:</td><td></td><td><?=$route[0]->start_time; ?></td>
                 </tr>
                 </tr>
             </table>
             
                 </center>   
    <div class="tab-content mt-3">
        <div id="class" class="tab-pane active">
             <div class="row">
                    <!-- <div class="col-md-2"></div> -->
                    <div class="col-md-12">
                        <div class="card">
                              <!-- <div class="row mt-3 mb-3" id="aside" style="padding-top:20px;">
                             <div class="col-md-3">
                             </div>
                             <label class="col-md-2 col-form-label">Session</label> -->
                    <!-- <div class="col-md-3">
                       <select class="form-select form-control" name="session" onchange="sessionGroup(this)">
                           <option value="0">All</option>
                           <option value="1">Morning</option>
                          <option value="2">Afternoon</option>
                          <option value="3">Evening</option>
                          
                       </select>
                    </div> -->
                    <!-- </div> -->
                             <!-- <p Class=" d-flex justify-content-center mt-3">PASSING SESSIONS</p> -->
                            <table class="table table-hover table-vcenter mt-3 text-nowrap">
                                <thead>
                                    <tr>
                                        <th>NO#</th>
                                        <th>STATION</th>
                                        <th>Session</th>
                                        <th>TIME</th>
                                      </tr>
                                </thead>
                                <tbody id="sss">
                                  <!--   <?php 
                                    $i=0;
                                  foreach($stn as $tn){
                                    if($tn->session_name==1){
                                        $name="Morning";
                                    }elseif ($tn->session_name==2) {
                                          $name="Afternoon";
                                    }elseif ($tn->session_name==3) {
                                          $name="Evening";
                                    }
                                    $i++;
                                    ?>
                                   <tr>
                                       <td><?= $i; ?></td>
                                       <td><?= $tn->station_name; ?></td>
                                       <td><?= $name; ?></td>
                                       <td><?= $tn->session_time; ?></td>
                                   </tr>
                                   <?php
                                    }
                                   ?> -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
        
      
         
    </div>
         <button type="button" class="btn btn-danger" id="cancel" style="padding:5px; float:right" data-bs-dismiss="modal">Close</button>
        <center>
            <button class="btn btn-success btn-sm col-sm-3" type="button" id="print_att"><i class="fa fa-print"></i> Print</button>

    </div>
    </div>
</div>
                        
<noscript>
    <style>
        label{
            margin-left: 50px;
        }
        table.att-list{
            width:100%;
            border-collapse:collapse
        }
        table td,table th{
            border:1px solid
            text-align: left;
        }
        .text-center,.text-right,.d-flex,.table{
            text-align:center;
        }
        .w{
         color:white;
        }
         .table{
            padding-left:130px;
        }
        #cancel,#print_att,#aside{
            display: none;
        }
    </style>
</noscript>
<script type="text/javascript">

       $('#print_att').click(function(){
      
        var _c = $('#printable').html();
        var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=900,height=600')
        nw.document.write(_c)
        nw.document.write(ns.html())
        nw.document.close()
        nw.print()
       
    }) 
     
 $(document).ready(function(){
       fetch_station_data();
   
});
     

       
     function fetch_station_data(){
        $('#sss').empty();     
        var datta = 'route_id=<?= $route[0]->id; ?>'+ '&sess_group=' + 0;
        $.ajax({
            type: 'GET',
            data: datta,
            //url: 'fetchstationdata',
            url: 'fetchstationrdata',
            success:function(response){

                var stream_data = JSON.parse(response);
                var len = stream_data.length;

                for(var i = 0; i < len; i++){
                    if(stream_data[i]['session_name']==1){
                        var sess="Morning";
                    }else if(stream_data[i]['session_name']==2){
                        var sess="Afternoon";
                    }else if(stream_data[i]['session_name']==3){
                       var sess="Evening";  
                    }
                    $('#sss').append('<tr>'+
                        '<td>'+(i + 1)+'</td>\
                        <td>'+stream_data[i]['station_name']+'</td>\
                        <td>'+sess+'</td>\
                        <td>'+stream_data[i]['time']+'</td>\
                      </tr>');
                }
            }
        });
    }
    
       function sessionGroup(id){
        //var data = 'sess_group=' + id.value;
        $('#sss').empty();     
        
        var data ='route_id=<?= $route[0]->id; ?>'+ '&sess_group=' + id.value;
            $.ajax({
            type: 'GET',
            data: data,
            //url: 'fetchstationdata',
            url: 'fetchstationrdata',
            success:function(response){

                var stream_data = JSON.parse(response);
                var len = stream_data.length;

                for(var i = 0; i < len; i++){
                    if(stream_data[i]['session_name']==1){
                        var sess="Morning";
                    }else if(stream_data[i]['session_name']==2){
                        var sess="Afternoon";
                    }else if(stream_data[i]['session_name']==3){
                       var sess="Evening";  
                    }
                    $('#sss').append('<tr>'+
                        '<td>'+(i + 1)+'</td>\
                        <td>'+stream_data[i]['station_name']+'</td>\
                        <td>'+sess+'</td>\
                        <td>'+stream_data[i]['time']+'</td>\
                      </tr>');
                }
            }
        });
        } 
     
</script>