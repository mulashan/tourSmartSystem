  <?php  
$imodel = new App\Models\ItemsModel();
helper('age');
 //$age = findAge($student_dtl[0]->birth_date);
 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
 $vhc=$amodel->get_item_name('vehicles_list_tbl', $where = array('id' => $vid));
 $dr=$amodel->get_item_name('users', $where = array('user_id' => $vhc[0]->driver_name));
 $date=date('Y-m-d');
 $year=date('Y');
 $db = \Config\Database::connect(session()->get('db_name'));
 $pendingApprovalCache = [];
 $isPendingApproval = function ($transNo) use ($db, &$pendingApprovalCache) {
    if (isset($pendingApprovalCache[$transNo])) {
        return $pendingApprovalCache[$transNo];
    }

    $approvalRow = $db->table('approval_numbers')
        ->where('trans_no', $transNo)
        ->where('trans_type', 1)
        ->get()
        ->getRow();

    if (! $approvalRow) {
        $pendingApprovalCache[$transNo] = 0;
        return 0;
    }

    $latestHistory = $db->table('approval_history')
        ->where('app_no', $approvalRow->app_id)
        ->orderBy('hist_id', 'DESC')
        ->get()
        ->getRow();

    $pendingApprovalCache[$transNo] = ($latestHistory && (int) $latestHistory->hstatus === 3) ? 1 : 0;
    return $pendingApprovalCache[$transNo];
 };
 ?>
       
                      
                              <?php
                           //   echo $thedate;
                         $item_data = array();
                        // $enddate = strtotime($endingdate. ' 23:59:59');
                        //   $sdate = strtotime($startingdate);
                               $vhc=$amodel->get_item_name('vehicles_list_tbl', $where = array('id' => $vid));
                            if(count($vhc)>0){

                                  $c=0;
                                  $trans_numbers=array();
                                  $actual_numbers=array();
                     foreach($vhc as $s){
                                $ttl=0;
                                $ttlReceipt=0;
                        $dr=$amodel->get_item_name('users', $where = array('user_id' => $s->driver_name));
                        $route=$amodel->get_item_name('route_tbl', $where = array('vehicle' => $s->id));

                        foreach($route as $rt){
                               
                          $check_station=$amodel->get_item_name('station_session_tbl', $where = array('route_id' => $rt->id));
                          if(count($check_station)>0){
                            foreach($check_station as $st){
              
                         $check_transp=$amodel->get_item_name('transport_details', $where = array('pickup_station' => $st->station_id,'pickup_session' => $st->session_name,'status' => $type)); 

                         $check_transd=$amodel->get_item_name('transport_details', $where = array('drop_station' => $st->station_id,'drop_session' => $st->session_name,'transport_trip'=>1,'status' => $type));
                  
                        //  print_r($check_transd);echo '</br>';
                        //   print_r($check_transp);
                      if(count($check_transp)>0) {

                            foreach($check_transp as $sp){
                                
                                 $date = $sp->date_created; // your date

                   $days = floor((time() - strtotime($date)) / (60 * 60 * 24));
                    if($days <= '30'){
                        continue;
                    }
                                  /////remove doublicate
                          if (in_array($sp->trans_numb, $actual_numbers)) {
                         
                            continue;
                        }
                         $actual_numbers[]=$sp->trans_numb;
                        ///removes duplicates
                        
                                $trans_numbers[]=array('no'=>$sp->trans_numb);
                        $check_amount=$amodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $sp->trans_numb,'trans_type'=>1,'transation_nature'=>2));
                        $stname=$amodel->get_item_name('students', $where = array('id' => $sp->student_id));
                          $admission=$amodel->get_item_name('admission_tbl', $where = array('student_id' => $sp->student_id,'academic_year'=>$year));
                          
                          if(count($admission) >0){
                              
                          }else{
                              //echo '('.$sp->student_id.'/'.$year.')';
                              $admission=$amodel->get_item_name('admission_tbl', $where = array('student_id' => $sp->student_id));
                             // continue;
                          }
                          
                          if(count($admission) ==0){
                            //  return;
                              continue;
                          }
                         // print_r($admission);
                          $class=$amodel->get_item_name('classes_tbl', $where = array('id' => $admission[0]->class_id));
                            $stationp=$amodel->get_item_name('station_tbl', $where = array('id' => $sp->pickup_station));
                            $stationd=$amodel->get_item_name('station_tbl', $where = array('id' => $sp->drop_station));

                             $today=date('Y-m-d');
                                        $start=$sp->start_date;
                                        $end=$sp->end_date;
                                        if($start > $today){
                                            $ex=1;
                                        }elseif($start <= $today && $today <=$end){
                                             $ex=2;
                                        }else{
                                            $ex=3;
                                        }
                                     if($sp->status==1 && $ex==1){
                                            $status='Paid';
                                            $color='blue';
                                        }elseif($sp->status==2){
                                           $status='Expired';  
                                           $color='red';  
                                        }
                                        elseif($sp->status==3){
                                           $status='Pending';  
                                           $color=' #d35400';  
                                        }elseif($sp->status==1 && $ex==2){
                                           $status='Active';  
                                           $color='green';  
                                        }elseif($sp->status==1 && $ex==3){
                                           $status='Expired';  
                                           $color='red';  
                                        }
                           $amt=0; 
                        if(count($check_amount)>0){
                            $amt=$check_amount[0]->amount;
                           
                            foreach($check_amount as $am){
                                $ttl+=$am->amount;
                            }
                        }
                        if(count($stationd)>0){
                          $stt='- '.$stationd[0]->station_name;  
                        }else{
                            $stt="-";
                        }
                        
                     $data = array("check"=>$trans_numbers,"pid" => $sp->permit_id,"trans_no"=>$sp->trans_numb,"date_created" => $sp->date_created, "full_name" => $stname[0]->full_name, "class" => $class[0]->class_name,"age" => findAge($stname[0]->birth_date),"station"=>$stationp[0]->station_name." ".$stt,"start_date"=>$sp->start_date,"end_date"=>$sp->end_date,"amount"=>$amt,"status"=>$status,"color"=>$color,"pending_approval"=>$isPendingApproval($sp->trans_numb));
                     if($amt != '0'){
                     array_push($item_data,$data);
                     }
                         ?>
                                  
                                 <?php
                          }}
                  
                         if(count($check_transd)>0) {

                          $result = array();
                        foreach ($trans_numbers as $item) {
                        $result[] = $item['no'];
                        }
                      $new_array['no'] = $result;
                      //print_r($new_array);

                            foreach($check_transd as $sd){

                        //////////////////////////////////
                    $date = $sd->date_created; // your date

                   $days = floor((time() - strtotime($date)) / (60 * 60 * 24));
                    if($days <= '30'){
                        continue;
                    }
                          $value_to_check =$sd->trans_numb;
                         // echo $value_to_check;echo '</br>';

                        if (in_array($value_to_check, $new_array['no'])) {
                          //  echo "$value_to_check is present in the array.";
                            continue;
                        } else {
                            //$trans_numbers[]=array('no'=>$value_to_check);
                            // echo $sd->permit_id.'</br>';
                            $check_amount=$amodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $sd->trans_numb,'trans_type'=>1,'transation_nature'=>2)); 
                            
                            
                            $stname=$amodel->get_item_name('students', $where = array('id' => $sd->student_id));
                          $admission=$amodel->get_item_name('admission_tbl', $where = array('student_id' => $sd->student_id,'academic_year'=>$year));
                          if(count($admission) >0){
                              
                          }else{
                              //echo '('.$sp->student_id.'/'.$year.')';
                              $admission=$amodel->get_item_name('admission_tbl', $where = array('student_id' => $sd->student_id));
                             // continue;
                          }
                          if(count($admission)==0){
                              continue;
                          }
                        //  print_r($check_amount);echo "</br>";
                          $class=$amodel->get_item_name('classes_tbl', $where = array('id' => $admission[0]->class_id));
                             $stationp=$amodel->get_item_name('station_tbl', $where = array('id' => $sd->pickup_station));
                            $stationd=$amodel->get_item_name('station_tbl', $where = array('id' => $sd->drop_station));

                             $today=date('Y-m-d');
                                        $start=$sd->start_date;
                                        $end=$sd->end_date;
                                        if($start > $today){
                                            $ex=1;
                                        }elseif($start <= $today && $today <=$end){
                                             $ex=2;
                                        }else{
                                            $ex=3;
                                        }
                                     if($sd->status==1 && $ex==1){
                                            $status='Paid';
                                            $color='blue';
                                        }elseif($sd->status==2){
                                           $status='Expired';  
                                           $color='red';  
                                        }
                                        elseif($sd->status==3){
                                           $status='Pending';  
                                           $color=' #d35400';  
                                        }elseif($sd->status==1 && $ex==2){
                                           $status='Active';  
                                           $color='green';  
                                        }elseif($sd->status==1 && $ex==3){
                                           $status='Expired';  
                                           $color='red';  
                                        }
                          $amt=0;
                        if(count($check_amount)>0){
                             $amt=$check_amount[0]->amount;
                             
                            foreach($check_amount as $am){
                                $ttl+=$am->amount;
                            }
                        }


                         $data = array("check"=>$trans_numbers,"pid" => $sd->permit_id,"trans_no"=>$sd->trans_numb,"date_created" => $sd->date_created, "full_name" => $stname[0]->full_name, "class" => $class[0]->class_name,"age" => findAge($stname[0]->birth_date),"station"=>'-'.$stationd[0]->station_name,"start_date"=>$sd->start_date,"end_date"=>$sd->end_date,"amount"=>$amt,"status"=>$status,"color"=>$color,"pending_approval"=>$isPendingApproval($sd->trans_numb));
                       if($amt != '0'){
                     array_push($item_data,$data);
                     }
                         ?>
                                  

                     <?php
                        }
                               
                        }
                         }
                            }
                           
                          }  
                            
                        }
                          
                           }
                        }
                        echo json_encode($item_data);
                              ?>
                             
                              
        
