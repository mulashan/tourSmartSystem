<?php
$billmodel = new App\Models\BillModel();
$studentModel = new App\Models\StudentModel();
$transportRows = $billmodel->get_item_name('transport_details', $where = array('trans_numb' => $inv[0]->trans_number));
$transport = count($transportRows) > 0 ? $transportRows[0] : null;
$student = !empty($transport) ? $billmodel->get_item_name('students', $where = array('id' => $transport->student_id)) : array();
$admission = !empty($transport) ? $billmodel->get_item_name_desc('admission_tbl', $where = array('student_id' => $transport->student_id), 'id') : array();
$class = count($admission) > 0 ? $billmodel->get_item_name('classes_tbl', $where = array('id' => $admission[0]->class_id)) : array();
$bill = $billmodel->billdata($inv[0]->trans_number, $inv[0]->trans_type_id);
$hist_data = count($bill) > 0 ? $billmodel->getdatabill($bill[0]->app_id) : array();
$ledger = $billmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $inv[0]->trans_number, 'trans_type' => 1, 'transation_nature' => 2));
$amount = count($ledger) > 0 ? $ledger[0]->amount : 0;
$permitIds = array();
foreach ($transportRows as $row) {
    $permitIds[] = $row->permit_id;
}
?>

<div class="container-fluid">
    <?php if (empty($transport)) { ?>
        <div class="alert alert-warning">Transport permit details not found for this invoice.</div>
    <?php } else { ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card invoice">
                <div class="card-header">
                    <h5>Transport Delete Request</h5>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <th>Invoice No:</th>
                            <td><?= $inv[0]->trans_number; ?></td>
                        </tr>
                        <tr>
                            <th>Permit No:</th>
                            <td><?= implode(', ', array_unique($permitIds)); ?></td>
                        </tr>
                        <tr>
                            <th>Student:</th>
                            <td><?= $student[0]->full_name ?? ''; ?></td>
                        </tr>
                        <tr>
                            <th>Class:</th>
                            <td><?= $class[0]->class_name ?? ''; ?></td>
                        </tr>
                        <tr>
                            <th>Invoice Date:</th>
                            <td><?= $inv[0]->trans_date; ?></td>
                        </tr>
                        <tr>
                            <th>Amount:</th>
                            <td><?= number_format($amount); ?></td>
                        </tr>
                        <tr>
                            <th>Action:</th>
                            <td>Delete overdue transport invoice together with its permit after approval.</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card invoice">
                <div class="card-header">
                    <h5>Permit Details</h5>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Permit</th>
                                <th>Station</th>
                                <th>Start</th>
                                <th>End</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($transportRows as $row) {
                                $pickup = $row->pickup_station > 0 ? $billmodel->get_item_name('station_tbl', $where = array('id' => $row->pickup_station)) : array();
                                $drop = $row->drop_station > 0 ? $billmodel->get_item_name('station_tbl', $where = array('id' => $row->drop_station)) : array();
                                $stationName = ($pickup[0]->station_name ?? '-') . ' - ' . ($drop[0]->station_name ?? '-');
                                ?>
                                <tr>
                                    <td><?= $row->permit_id; ?></td>
                                    <td><?= $stationName; ?></td>
                                    <td><?= $row->start_date; ?></td>
                                    <td><?= $row->end_date; ?></td>
                                    <td><?= (int) $row->status === 3 ? 'Pending' : $row->status; ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card invoice">
                <div class="card-header">
                    <h5>Approval History</h5>
                    <div id="feedback"></div>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <th>Entry Date</th>
                            <th>Comment</th>
                            <th>Name</th>
                            <th>User Role</th>
                        </tr>
                        <?php foreach($hist_data as $in): ?>
                        <tr>
                            <td><strong><?= $in->hist_date; ?></strong></td>
                            <td class="text-primary"><?= $in->comment; ?></td>
                            <td><?= $in->first_name.' '.$in->last_name; ?></td>
                            <td>
                                <?php
                                if($in->user_role == '1'){
                                    echo 'Initiator';
                                }elseif($in->user_role == '2'){
                                    echo 'Checker';
                                }elseif($in->user_role == '3'){
                                    echo 'Approver';
                                }
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <button type="button" class="btn btn-success float-right ml-3 ApprovalId" data-id="<?= $inv[0]->trans_number; ?>">Approve</button>
            <button type="button" class="btn btn-warning float-right RejectId" data-id="<?= $inv[0]->trans_number; ?>">Reject</button>
        </div>
    </div>
    <?php } ?>
</div>

<div class="modal fade" id="transportRejectModal" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Comment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form class="form-group" id="RejectTransportComment">
                    <div class="form-group">
                        <textarea class="form-control" name="comment" id="transport_comment"></textarea>
                    </div>
                    <button type="button" class="btn btn-primary" id="save_transport_comment">Submit</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
$(".ApprovalId").click(function(){
    var type='<?= $inv[0]->trans_type_id;?>';
    var data = "trans_number="+$(this).attr('data-id')+'&type='+type;

    $.ajax({
        type:"GET",
        url:"<?= base_url('/send_approved_data')?>",
        data:data,
        dataType:"json",
        success: function (res){
            if(res.status == 1){
                $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>'+res.message+'</strong></div>');
                setTimeout(function(){
                    window.location.reload();
                },1000);
            }else{
                $('#feedback').html('<div class="alert alert-danger">'+res.message+'</div>');
            }
        },
        error:function () {
            $('#feedback').html('<div class="alert alert-danger">Error! Could not approve request.</div>');
        }
    });
});

$(".RejectId").click(function(){
    $('#transportRejectModal').modal('show');
    var type='<?= $inv[0]->trans_type_id;?>';
    var dat = "trans_number="+$(this).attr('data-id')+'&type='+type;

    $('#save_transport_comment').off('click').on('click', function(){
        var data = "comment="+$('#transport_comment').val()+"&"+dat;

        $.ajax({
            type:"GET",
            url:"<?= base_url('/send_rejected') ?>",
            data:data,
            success: function(){
                $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Request rejected successfully.</strong></div>');
                setTimeout(function(){
                    window.location.reload();
                },1000);
            },
            error: function (){
                $('#feedback').html('<div class="alert alert-danger">Error! Could not reject request.</div>');
            }
        });
    });
});
</script>
