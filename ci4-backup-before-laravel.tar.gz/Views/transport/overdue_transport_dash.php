  <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
 ?>
 <div class="section-body mt-4">
    <div class="container-fluid">
             
                <div class="card">
               <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable2">
                            <thead>
                                <tr>
                                     
                                    <th>#</th>
                                    <th>Vehicle No</th>
                                    <th>Vehicle Name</th>
                                    <th>Driver</th>
                                    <th>No. Of Permit</th>
                                    <th>Overdue</th>
                                    <!-- <th>Recepted</th> -->
                                    <th>Action</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                              <?php
                            //  echo $thedate;
                        //  list($startingdate, $endingdate) = explode('-', $thedate);
                        // $enddate = strtotime($endingdate. ' 23:59:59');
                              $startingdate=date('Y-m-d');
                           $sdate = strtotime($startingdate);
                               $vhc=$amodel->get_item_name('vehicles_list_tbl', $where = array('status' => 1));
                                  if(count($vhc)>0){

                                  $c=0;
                         $trans_numbers=array();
                     foreach($vhc as $s){
                               $permits=0;
                                $ttl=0;
                                $ttlReceipt=0;
                        $dr=$amodel->get_item_name('users', $where = array('user_id' => $s->driver_name));
                        $route=$amodel->get_item_name('route_tbl', $where = array('vehicle' => $s->id));

                        foreach($route as $rt){
                               
                          $check_station=$amodel->get_item_name('station_session_tbl', $where = array('route_id' => $rt->id));
                          if(count($check_station)>0){
                            foreach($check_station as $st){
                         $check_transp=$amodel->get_item_name('transport_details', $where = array('pickup_station' => $st->station_id,'pickup_session' => $st->session_name,'status'=>3)); 

                          $check_transd=$amodel->get_item_name('transport_details', $where = array('drop_station' => $st->station_id,'drop_session' => $st->session_name,'transport_trip'=>1,'status'=>3));
                         //print_r($check_transd);
                   
                      if(count($check_transp)>0) {

                            foreach($check_transp as $sp){
         //////////////////////////////////

                    $date = $sp->date_created; // your date

                   $days = floor((time() - strtotime($date)) / (60 * 60 * 24));
                    if($days <= '30'){
                        continue;
                    }

             $check=$amodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $sp->trans_numb,'trans_type_id'=>1));
             if(count($check)>0){
          $Transaction = [
               'date_created' => $check[0]->trans_date
                   ];
             $amodel->update_table_details('transport_details',$where = array('trans_numb' =>$sp->trans_numb),$Transaction);
                   }
             /////////////////////////////////////////

                        $trans_numbers[]=array('no'=>$sp->trans_numb);
                        
                        $check_amount=$amodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $sp->trans_numb,'trans_type'=>1,'transation_nature'=>2));

                         $check_receipt=$amodel->get_item_name('transactions_relation', $where = array('invoice_trans_no' => $sp->trans_numb));

                        if(count($check_amount)>0){
                            //foreach($check_amount as $am){
                                $ttl+=$check_amount[0]->amount;
                                if($check_amount[0]->amount != "0"){
                                    $permits+=1;
                                }
                            //}
                        }

                      
                        
                         }}

                         if(count($check_transd)>0) {

                          $result = array();
                        foreach ($trans_numbers as $item) {
                        $result[] = $item['no'];
                        }
                      $new_array['no'] = $result;
                      //print_r($new_array);

                            foreach($check_transd as $sd){
                                //////////////////////////////////
                        $date = $sd->date_created; // your date

                   $days = floor((time() - strtotime($date)) / (60 * 60 * 24));
                    if($days <= '30'){
                        continue;
                    }
             $check=$amodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $sd->trans_numb,'trans_type_id'=>1));
             if(count($check)>0){
          $Transaction = [
               'date_created' => $check[0]->trans_date
                   ];
             $amodel->update_table_details('transport_details',$where = array('trans_numb' =>$sd->trans_numb),$Transaction);
                   }
             /////////////////////////////////////////

                        //////////////////////////////////
                          $value_to_check =$sd->trans_numb;

                        if (in_array($value_to_check, $new_array['no'])) {
                            //echo "$value_to_check is present in the array.</br>";
                        } else {
                            $permits+=1;
                            $trans_numbers[]=array('no'=>$value_to_check);
                          //  echo "$value_to_check is not present in the array.</br>";
                            $check_amount=$amodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $sd->trans_numb,'trans_type'=>1,'transation_nature'=>2)); 

                            $check_receipt=$amodel->get_item_name('transactions_relation', $where = array('invoice_trans_no' => $sd->trans_numb));

                          if(count($check_amount)>0){
                             if($check_amount[0]->amount != "0"){
                                    $permits+=1;
                                }
                            foreach($check_amount as $am){
                                $ttl+=$am->amount;

                            }
                        }

                        
                        }
                        ////////////////////////////////        
                        
                            }
                         }
                            }
                           
                          }  
                            
                        }
                          
                                $c++;
                                ?>
                                <tr>
                            <td><?php echo $c;?></td>
                            <td><?php echo $s->vehicle_number;?></td>
                            <td><?php echo $s->driver_contact;?></td>
                            <td><?php echo $dr[0]->first_name.' '.$dr[0]->last_name;?></td>
                            <td><?php echo number_format($permits);?></td>
                            <td><?php echo number_format($ttl);?></td>
                             
                            <td><button type="button" onclick="vehicle_btn('<?php echo $s->id;?>')" class="btn btn-primary btn-sm"><i class="fa fa-eye">View</button></td>
                                 </tr>
                                <?php

                            }
                        }
                              ?>
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
          
        </div>
        <!-- ------View vehicle modal------- -->
<div class="modal fade" id="vehicleview" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="view_details">
      </div>
       <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_report('view_details')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
        <script type="text/javascript">
$(document).ready(function () {
      $('#myTable2').DataTable();
    });

function vehicle_btn(vid){
  //  alert(sdate+'/'+enddate);
    $('#vehicleview').modal('show'); 
      $('#view_details').html('<center><i class="fa fa-spinner fa-spin"></i> Please wait..</center>');
 var viewUrl = "<?php echo base_url() . '/index.php/TransportController/vehicle_overdue'; ?>/" + vid + "?v=" + new Date().getTime();
 $('#view_details').load(viewUrl);
}
</script>
