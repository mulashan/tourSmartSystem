              <?php 
    helper('age');
    $amodel = new App\Models\AdmissionModel();
    $smodel = new App\Models\StudentModel();
    $tmodel = new App\Models\TransportModel();

    $student = $smodel->gettable_data('students', $where = array('transport_status' => 0,'status'=>2));
    // $admission = $tmodel->gettable_dataT('transport_details');

?>
               <div class="card">
                    <form id="closeAdmissionYearForm">
                        <div class="table-responsive mt-3">
                            <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable2">
                                <thead>
                                    <tr>
                                        <th>Permit NO</th>
                                        <th>Date</th>
                                        
                                        <th>Trans Type</th>
                                        <th>Student Names</th>
                                        <th>Age</th>
                                        <th>Class</th>
                                        <th>Days</th>
                                        <th>Expire Date</th>
                                        <th>Status</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $sn = 0;
                                    //print_r($admission);
                                    foreach ($admission as $adm):
                                        $sn++;
                                        if($adm->transport_trip==1){
                                            $trip='One Way';
                                        }else{
                                           $trip='Round Trip';  
                                        }

                                        $today=date('Y-m-d');
                                        $start=$adm->start_date;
                                        $end=$adm->end_date;
                                        if(strtotime($start) > strtotime($today)){
                                            $ex=1;
                                        }elseif(strtotime($start) <= strtotime($today) && strtotime($today) <= strtotime($end)){
                                             $ex=2;
                                        }else{
                                            $ex=3;
                                        }
                                     if($adm->status==1 && $ex==1){
                                            $status='Paid';
                                            $color='blue';
                                        }elseif($adm->status==2){
                                           $status='Expired';  
                                           $color='red';  
                                        }
                                        elseif($adm->status==3){
                                           $status='Pending';  
                                           $color=' #d35400';  
                                        }elseif($adm->status==1 && $ex==2){
                                           $status='Active';  
                                           $color='green';  
                                        }elseif($adm->status==1 && $ex==3){
                                           $status='Expired';  
                                           $color='red';  
                                        }
                                        $std = $amodel->get_student_details('students', $where = array('id' => $adm->student_id));
                                         $stadm = $amodel->get_student_details('admission_tbl', $where = array('student_id' => $adm->student_id));
                                        $room = $amodel->get_student_details('classes_tbl', $where = array('id' => $stadm[0]->class_id));
                                        //$strm = $amodel->get_student_details('streams_tbl', $where = array('id' => $adm->stream_id));
                                        $user = $amodel->get_student_details('users', $where = array('user_id' => $adm->created_by));
                                       // $level = $amodel->get_student_details('class_level_tbl', $where = array('id' => $adm->level_id));
                                    ?>
                                        <tr>
                                            
                                            <td><?= $adm->permit_id;?></td>
                                            <td><?= $adm->start_date;?><input type="hidden" name="student_<?= $sn;?>" value="<?= $adm->student_id; ?>"><input type="hidden" name="admission_<?= $sn;?>" value="<?= $adm->id; ?>"></td>
                                            <td><?= $trip;?></td>
                                            <td><?= $std[0]->first_name.' '.$std[0]->middle_name.' '.$std[0]->last_name;?></td>
                                            <!-- <td><?= $std[0]->birth_date;?></td> -->
                                            <td><?= findAge($std[0]->birth_date);?>
                                        </td>
                                            <!-- <td><?//= $level[0]->level_name;?></td> -->
                                            <td><?= $room[0]->class_name;?></td>
                                            <td><?= $adm->month *30;?></td>
                                            <td><?= $adm->end_date;?></td>
                                            <td style="color: <?=$color;?>"><?= $status;?></td>
                                            <!-- <td><?//= $strm[0]->stream_name;?></td> -->
                                            <td>
                                                <button type="button" class="btn btn-primary btn-sm editTrans" onclick="editTrans('<?= $adm->permit_id;?>')"><i class="fa fa-edit"></i> Edit</button>
                                             <button type="button" class="btn btn-primary btn-sm viewTrans" onclick="viewTrans('<?= $adm->permit_id;?>')"><i class="fa fa-eye"></i> View</button>
                                            </td>
                                        </tr>
                                    <?php endforeach ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- <input type="hidden" name="total_admitted" value="<?php //$sn; ?>">
                        <button type="submit" class="btn btn-primary float-right mb-3 me-3">Close Academic Year</button> -->
                    </form>
                </div>
                <!-- ------view modal------ -->
<div id="viewModal" class="modal fade"  role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <!-- <h5 class="modal-title" id="staticBackdropLabel">Transport Details</h5> -->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div id="admission_view">
                <span class="fa fa-spin"><i class="fa fa-spinner"></i></span>Loading...
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" id="print_att"><span class="fa fa-print"></span>Print</button>
            </div>
        </div>
      </div>
      
    </div>
      <script type="text/javascript">
          $('#myTable2').DataTable();

           // $(".editTrans").click(function () {
        function editTrans(id){
        // var id=$(this).attr('data-id');
        $('#editModal').modal('show');
        
      $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/index.php/TransportController/transport_detail_edit'; ?>/'+id,
           
            beforSend: function()
            {
                $('#transport_details').html();
            },
            success: function(res){
                $('#transport_details').html(res);
                 
            },
            error: function ()
            {

            }
        });
    };
           // $(".viewTrans").click(function () {
           function viewTrans(id){
        // var id=$(this).attr('data-id');
        $('#viewModal').modal('show');
        
      $.ajax({
            type: "GET",
            url: '<?php echo base_url() . '/index.php/TransportController/transport_detail_view'; ?>/'+id,
           
            beforSend: function()
            {
                $('#admission_view').html();
            },
            success: function(res){
                $('#admission_view').html(res);
                 
            },
            error: function ()
            {

            }
        });
    };
      </script>          