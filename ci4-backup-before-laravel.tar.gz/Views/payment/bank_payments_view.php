<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<style type="text/css">
    tr:hover {
cursor: pointer;

}

    .help-icon {
    display: inline-block;
    position: relative;
    font-size: 13px; /* Adjust the size as needed */
    vertical-align: super;
    line-height: 1;
}

.icon1 {
    display: inline-block;
    width: 20px;
    height: 20px;
    background-color: #00BFFF;
    color: white;
    border-radius: 50%;
    text-align: center;
    line-height: 20px;
    font-size: 14px;
    font-weight: bold;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Hover effect */
.icon1:hover {
    background-color: #2980b9;
}
</style>
<?php
  $bmodel = new App\Models\BillingModel();
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Billing</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Bank</li>
                    <!--  <li class="help-icon">
                    <a href="#" onclick="tg_help()" style="margin-left:8px"><span class="icon1">?</span></a>
                   </li> -->
                </ol>
            </div>
           
             <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#inv-all">Control Number History</a></li>
                 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#inv-add">Ctr Receipt List</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
             <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#inv-all">Control Number History</a></li>
                <li></li><li></li>
                 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#inv-add">Ctr Receipt List</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="inv-all">
               <div class="input-group ms-3 me-3 mb-3 d-flex justify-content-center">
                           <form id="Rept1Result2" class="form-inline">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </form>
                        </div>
                
                <div class="d-flex justify-content-center">
                <div id="messageDisplayArea"></div>
                    <form id="Rept1Result" class="form-inline">
                      
                        Ledger: 
                        <select class="form-control form-select me-3" name="ledger" id="ledger">
                            <option value="0">All</option>
                            <option value="3">CRDB</option>
                            <option value="2">NMB</option>
                            </select>

                             Trans Type: 
                        <select class="form-control form-select me-3" name="trans" id="trans">
                            <option value="0">All</option>
                             <?php
                           $result = $bmodel->trans_types2();
                          foreach($result as $re){
                           echo '<option value="' . $re->type_id . '">' . $re->type_name . '</option>'; 
                          }
                             ?>
                            </select>

                             Inv Type: 
                        <select class="form-control form-select me-3" name="inv" id="inv">
                            <option value="0">All</option>
                           <?php
                           $res = $bmodel->trans_types();
                          foreach($res as $re){
                           echo '<option value="' . $re->id . '">' . $re->type_name . '</option>'; 
                          }

                           ?>
                            </select>

                             Status: 
                        <select class="form-control form-select" name="status" id="status">
                            <option value="2">All</option>
                            <option value="1">Paid</option>
                            <option value="0">Unpaid</option>
                            <option value="3">Canceled</option>
                            </select>
                             <!--
                            
                        </select> -->
                        <button type="submit" class="btn btn-primary ms-3">Create</button>
                        
                    </form>
                       
                </div>

                <div class="input-group mt-3 mb-3 d-flex justify-content-center">
                      <form id="Rept1Re" class="form-inline">
                <input type="text" class="form-control" name="payer_name" id="search_name"   placeholder="Search Student Name" aria-label="Student Name" aria-describedby="button-st">
                <button class="btn btn-outline-success" type="button" id="button-y">
                    <span>
                        <i class="fa fa-calendar" aria-hidden="true"></i>
                    </span></button>
                <button class="btn btn-outline-primary" type="button" id="button-st" onclick="searchnamebtn()"><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
            </div>
                
                <hr>
                <!--<hr>-->
                
                
                <center>
                    <div id="bank_results"></div>
                </center>
            </div>
            <!---/////////////////////// list Receipt------------------>
            <div class="tab-pane" id="inv-add">
                   <!-- <div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>Ctr Date</th>
                                    <th>Ctr No</th>
                                    <th>Ctr Type</th>
                                    <th>Rct No</th>
                                    <th>Payer Name</th>
                                    <th>A/C NO</th>
                                    <th>Amout</th>
                                    <th>Channel</th>
                                   
                                   
                                </tr>
                            </thead>
                            <tbody>
                             
                            </tbody>
                        </table>
                    </div>
                </div>  -->
                 <div class="input-group ms-3 me-3 mb-3 d-flex justify-content-center">
                           <form id="receitList" class="form-inline">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn_list">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </form>
                        </div>
                
                <div class="d-flex justify-content-center">
                
                    <form id="Rept1Result_list" class="form-inline">
                      
                        Channel: 
                        <select class="form-control form-select me-3" name="Channel" id="Channel">
                            <option value="0">All</option>
                            <option value="3">CRDB</option>
                            <option value="2">NMB</option>
                            </select>

                             Control Type: 
                        <select class="form-control form-select me-3" name="Control_type" id="Control_type">
                            <option value="9">All</option>
                             <option value="0">Fixed</option>
                            <option value="1">Flexible</option>
                            </select>
<!--
                            
                        </select> -->
                        <button type="submit" class="btn btn-primary ms-3">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                
                <center>
                    <div id="bank_results_list"></div>
                </center>
            </div>
        </div>
    </div>
</div>
<!-- ------View invoice modal------- -->


<!-- ------manage invoice modal------- -->


<!-- ------invoice print modal------ -->

<!--------------help model---------------------------------->

<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script>
 $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });

                    $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn_list span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn_list').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });

  $('#Rept1Result').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#bank_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn span').html()+'&'+ $('#Rept1Result').serialize();
           // alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/load_bank_transactions' ?>',
          //      url: '<?php echo base_url() . '/receipt2'; ?>',

                data: dta,
                success: function (res) {
                    $('#bank_results').html(res);
                },
                error: function () {
                    $('#bank_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });

     $('#Rept1Result_list').submit(function (e) {
             if (!$('#daterange-btn_list span').html()) {
            //$('#RecptResult').html('Please specify valid date.');
                alert('Please specify valid date.');
        } else {
            $('#bank_results_list').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn_list span').html()+'&'+ $('#Rept1Result_list').serialize();
          //  alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/load_bank_receipt' ?>',
                 data: dta,
                success: function (res) {
                    $('#bank_results_list').html(res);
                },
                error: function () {
                    $('#bank_results_list').html('<div class="alert alert-warning">Fail to retreive results.!!</div>');
                }
            });

}
        e.preventDefault();
    });
    
     function searchnamebtn(){
            var name=$('#search_name').val();
            var  year=$('#button-y').html();
            // alert(year);
            if(name.length >=3){
                $('#bank_results').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
                var dta="name="+name+"&year="+year;
           // toastr.success(name.length);
             $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/index.php/BillingController/get_control_byname'; ?>",
                data: dta,
                success: function (res) {
                    $('#bank_results').html(res);
                },
                error: function () {
                    $('#bank_results').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
        }else{
            if(name.length==0){
               $('#bank_results').html(''); 
            }else{
               $('#bank_results').html('<div class="alert alert-info">Search atleat 3 characters</div>'); 
            }
        
        }
        }
</script>    
