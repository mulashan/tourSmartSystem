
<?php
   $bmodel = new App\Models\BillingModel();
   $smodel = new App\Models\StudentModel();
   $ctype= $bmodel->get_table_details('name_type_tbl');
   $vfd_settngs = $bmodel->get_item_name('vfd_settings_tbl',$where = array('status' =>1));
?>

<div class="section-body mt-4">
    <div class="container-fluid">
             
                <div class="card">
               <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <!-- <th>No.#</th> -->
                                    <th>Rct No.</th>
                                    <th>Receipt Type</th>
                                    <th>Rct Date</th>
                                    <th>Customer Name</th>
                                    <th>Name Type</th>
                                     <th>Class</th>
                                    <th> Amount</th>
                                    <th>Received By</th>
                                    <th>sms Status</th>
                                    <th>Trans Date</th>
                                    <?php
                             if(count($vfd_settngs)> 0){
                             echo '<th>Vfd Status</th>';
                                    }
                                    echo '<th>System Receipt</th>';
                                   if(count($vfd_settngs)> 0){
                                    echo '<th>TRA Receipt</th>';
                                    echo '<th></th>';

                                    } ?>
                                    
                                   
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                  helper('class');
                                 if(count($trans)>0){
                                    foreach($trans as $s){
                             $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type' =>2,'transation_nature' =>1));
                                  $chargesb=0;
                                  $bank_charges = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type' =>2,'ledger_id' =>22,'transation_nature' =>1));
                                   
                                  if(count($bank_charges) > 0){
                                      $chargesb=$bank_charges[0]->amount;  
                                    }
                                    
                                $reltn = $bmodel->get_item_name('transactions_relation',$where = array('receipt_trans_no' =>$s->trans_number));
                                $class="";
                                if(count($reltn)>0){
                                $class=getClass($reltn[0]->invoice_trans_no,$leger_transaction[0]->name_type_id,$s->trans_number);
                                }else{
                                 $receiv_search = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type' =>2,'transation_nature' =>1,'ledger_type'=>7));
                                 if(count($receiv_search)==0 && count($leger_transaction)>0) {
                                 $search_inv = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_type' =>1,'transation_nature' =>2,'name_type_id'=>1,'name_id'=>$leger_transaction[0]->name_id));
                                    if(count($search_inv)>0){
                                        $m=count($search_inv)-1;
                                        $inv_number=$search_inv[$m]->trans_no;
                                
             $receiv_receipt = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type' =>2,'transation_nature' =>2,'ledger_type'=>9));        
                    if(count($receiv_receipt)>0){
                    //////////////////////////////////
                         $rcledger = [
                       'ledger_id' => $search_inv[$m]->ledger_id,
                       'ledger_type' => 7,
                       'trans_item' => 0,
                       'trans_no' => $s->trans_number,
                       'trans_type' => 2,
                       'amount' => $receiv_receipt[0]->amount -$chargesb,
                       'transation_nature' => 1,
                       'name_type_id' => 1,
                       'name_id' => $leger_transaction[0]->name_id,
                       'balance' => 0
                   ];
  //   print_r($rcledger);
               $payid = $smodel->SaveData_n_get_id('ledger_transaction_tbl',$rcledger);
               
               $relation_transation = [
                       'invoice_trans_no' => $inv_number,
                       'receipt_trans_no ' => $s->trans_number,
                         ];
                $smodel->SaveData('transactions_relation',$relation_transation);
                    }
                        /////////////////////////////////
                                    }
                                 }
                                }
                                
                                    // print_r($leger_transaction);
                                    
                                    $student_name = "";
                                    $student_id = "";
                                    $control_number = "";
                                    $name_type = "";
                                    $amount =0;
                                    
                                   
                                    if(count($leger_transaction) > 0){
                                        $total_amount = $bmodel->get_total_amount_payed2($s->trans_number,9);
                                        if(count($total_amount) > 0)
                                        foreach($total_amount as $tv){
                                           
                                            if($tv->ledger_type==7){
                                             
                                            }else{
                                            $amount += $tv->amount;
                                            }
                                         
                                            }
                                            
                                        if($leger_transaction[0]->name_type_id == 4){
                                            $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                                            $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                            $student_id = $app[0]->id;
                                            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                            $name_type = $type_name[0]->name_type;
                                            
                                        }else if($leger_transaction[0]->name_type_id == 3){
                                    $app = $bmodel->get_item_name('others_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                                     $student_name = $app[0]->customer_name; 
                                      $student_id = $app[0]->id;
                                       $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                            $name_type = $type_name[0]->name_type;
                                              
                                   }
                                        else if($leger_transaction[0]->name_type_id == 5){
                                             $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }else if($leger_transaction[0]->name_type_id == 1){
                                             $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }else if($leger_transaction[0]->name_type_id == 6){
                                             $app = $bmodel->get_item_name('other_students_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }
                                        
                                    

                                    $user = $bmodel->get_item_name('users', $where = array('user_id' => $s->updated_by));

                                     $msg_status = $bmodel->get_item_name('message_groups_tbl', $where = array('trans_number' => $s->trans_number,'message_type'=>2));
                                     if(count($msg_status)>0){
                                         $msg_st = $bmodel->get_item_name('messages', $where = array('send_no' => $msg_status[0]->send_number));
                                         if(count($msg_st)>0){
                                             if($msg_st[0]->time_sent==null && $msg_st[0]->message_id !=""){
                                          
                    //update msg
                        $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_RETURNTRANSFER => 1,
                        CURLOPT_URL => 'http://www.sms.co.tz/api.php?do=dlr&id=' . $msg_st[0]->message_id . '&username=' . SMS_UNAME . '&password=' . SMS_PASSWORD . '&senderid=' . SENDER_ID . '',
                    ));
                    $msg_status = curl_exec($curl);
                    // echo $msg_status;
                    if($msg_status != ""){

                       list($sntdate, $stts, $deldate) = explode(',', $msg_status);

                       $tempsmsdata = array(
                           'sent_status' => 2, //Sent and delivered
                           'time_sent' => $sntdate,
                           'status_description' => $stts,
                           'time_delivered' => $deldate
                       );
                       //print_r($tempsmsdata);
                        $smodel->update_table_details('messages',$where = array('message_id' => $msg_st[0]->message_id),$tempsmsdata);
                        // echo 'updated';
          
                      }
                    //endup update msg      

                                             }
                                          $msg_st = $bmodel->get_item_name('messages', $where = array('message_id' => $msg_st[0]->message_id));
                                         $del=$msg_st[0]->status_description;
                                         $time=$msg_st[0]->time_delivered;
                                         $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                                     }else{
                                         $stata='<span style="color:red">Not Sent'; 
                                     }
                                     }else{
                                       $stata='<span style="color:red">Not Sent';  
                                     }

                $vfd_receipt = $bmodel->get_item_name('vfd_receipts_details_tbl',$where = array('receipt_number' =>$s->trans_number));
                 $editable=1;
                    if(count($vfd_receipt)>0){
                        $editable=0;
                        if($vfd_receipt[0]->submission_status==1){
                            
                            $sign = '<span class="text-success">Received</span>';
                        $verfy ='<a href="'.$vfd_receipt[0]->verify_link.'" target="blank"  class="btn btn-primary btn-xs" data-toggle="tooltip" title="Verify"><span class="fa fa-arrow-up"></span>Verify</a>';
                        $tra_view = '<button type="button" class="btn btn-primary btn-sm" onclick="view_traReceipt(\'' . $s->id . '\',\'' . ($amount- $chargesb) . '\',\'' . addslashes($student_name). '\')"><i class="fa fa-eye"></i> View</button></td>';
                        }else{
                            $sign = '<span class="text-warning">Pending</span>' ;  
                      $verfy = '<button type="button" class="resend btn btn-primary btn-sm" onclick="resend_vfd(\'' . $s->id . '\',\'' . ($amount- $chargesb) . '\',\'' . addslashes($student_name). '\')"><i class="fa fa-refresh"></i> Resend</button></td>';
                      $tra_view = '<button type="button" class="btn btn-primary btn-sm"  style="" onclick="view_traReceipt(\'' . $s->id . '\',\'' . ($amount- $chargesb) . '\',\'' . addslashes($student_name). '\')"><i class="fa fa-eye"></i> View</button></td>';
                        }
                    }else{

                         $sign = '<span class="text-danger">Not Sent</span>' ;  
                      $verfy = '<button type="button" class="resend btn btn-primary btn-sm" onclick="resend_vfd(\'' . $s->id . '\',\'' . ($amount- $chargesb) . '\',\'' . addslashes($student_name). '\')"><i class="fa fa-arrow-down"></i> Send</button></td>';
                      $tra_view = '<button type="button" class="btn btn-primary btn-sm" disabled style="pointer-events: none; opacity: 0.5;" onclick="view_traReceipt(\'' . $s->id . '\',\'' . ($amount- $chargesb) . '\',\'' . addslashes($student_name). '\')"><i class="fa fa-eye"></i> View</button></td>';
                          }

                          if($s->updated_by==9 || $s->updated_by==10 || $editable==0){
                               $disabled="disabled "; 
                                $style="'pointer-events: none; opacity: 0.5;'";
                                $styled= $disabled.' style='.$style;
                             }else{
                                $disabled=""; 
                                $style="";
                                 $styled= $disabled.' style='.$style;
                                  }
                                    $sales_receipt = $bmodel->get_item_name('receipt_type_transaction_tbl',$where = array('transNumber' =>$s->trans_number,'receipt_type'=>2));
                                  if(count($sales_receipt)>0){
                                     $rctType="Sales Receipt";
                                  }else{
                                    $rctType="Invoice Receipt";
                                  }
                                ?>
                                <tr>
                                    <td><?php echo $s->trans_number;?></td>
                                    <td><?php echo $rctType;?></td>
                                    <td><?php echo date('Y-m-d',strtotime($s->trans_date));?></td>
                                     <td><?php echo $student_name;?></td>
                                    <td><?php echo $name_type ?? "";?></td>
                                     <td><?php echo $class;?></td>
                                    <td><?= number_format($amount- $chargesb); ?></td>
                                    <td><?= $user[0]->first_name.' '.$user[0]->last_name; ?></td>
                                      <td><?php echo $stata;?></td>
                                     <td><?php echo date('Y-m-d H:i',strtotime($s->updated_date));?></td>
                                   
                           
                              <?php
                               $showqr=0;
                               if($amount- $chargesb >0){
                                $showqr=1;
                               }

                             if(count($vfd_settngs)> 0 ){
                             echo '<td>'.$sign.'</td>';
                                    } ?>
                                  <td>
                                  <a href="javascript:void(0)" onclick="manage_rec(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm" <?php echo $styled;?> ><i class="fa fa-edit"></i> Edit</a>

                                    <a href="javascript:void(0)" onclick="manage_receipt(<?php echo $s->id;?>,<?= $showqr;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a></td>
                                    <?php
                                   
                                   if(count($vfd_settngs)> 0 &&($amount- $chargesb)>0){

                                    echo '<th>'.$tra_view.' '.$verfy.'</th>';
                                    echo '<td></td>';
                                    } ?>
                                    <!-- <a href="javascript:void(0)" onclick="manage_receipt(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a>
                                     <a href="javascript:void(0)" onclick="generate_vfd_receipt('<?php echo $s->id;?>','<?php echo $amount- $chargesb;?>','<?= $student_name?>')"  class="btn btn-primary btn-sm"><i class="fa fa-print"></i> Vfd</a> -->
                             <!--   <td>
                            <?php 
                             if($s->updated_by==9 || $editable==0){
                                ?>
                             <a href="javascript:void(0)" onclick="manage_rec(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm" disabled style="pointer-events: none; opacity: 0.5;"><i class="fa fa-edit"></i> Edit</a>
                             <?php
                             }else{
                            ?>
                             <a href="javascript:void(0)" onclick="manage_rec(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>
                                    <?php } ?>
                                    </td> -->
                                    
                                </tr>
                            <?php }}}else{
                                echo "<tr><td>Currently there is no record</td></tr>";
                            } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
          
        </div>
   
<div class="modal fade" id="viewreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('viewreceipt_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="editreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="editreceipt_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="edit_rept()"><i class="fa fa-print"></i> Edit</button> -->
      </div>
    </div>
  </div>
</div>
<script>

    $(document).ready(function () {
      $('#myTable').DataTable();
    });
    
   function check_sms(msgid){
               // alert(msgid);
       var data = "id=" + msgid;
              $.ajax({
            type: 'POST',
           url: '<?php echo base_url() . '/index.php/SystemController/check_sms/'; ?>'+msgid,
            
            success: function (res) {
            
              
            },
            error: function (){
                alert('error encounted');
            }
        });
            }

    

  </script>