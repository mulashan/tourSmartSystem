 <?php
  $bmodel = new App\Models\BillingModel();
  $cmodel = new App\Models\ClassesModel();
  $appItems = $cmodel->get_applications_items();
   $ctype= $bmodel->get_table_details('name_type_tbl');
  $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'trans_type' =>2));
  $invoice_type = $bmodel->get_item_join_table($recpt[0]->trans_number);
  $student_name = "";
  $name_type = "";
if(count($leger_transaction) > 0){
    $amount = $leger_transaction[0]->amount;
    if($leger_transaction[0]->name_type_id == 4){
        $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $itm_details = $bmodel->get_item_name('item_transation_tbl',$where = array('trans_number' =>$recpt[0]->trans_number));
    }
    else if($leger_transaction[0]->name_type_id == 3){
        $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2));
   }else if($leger_transaction[0]->name_type_id == 1){
        $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name1 = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
         $type_name2 = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[1]->name_type_id));
        $name_type = $type_name1[0]->name_type;
        $name_type2 = $type_name2[0]->name_type;
        
        $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2,'transation_nature'=>1));
   }else if($leger_transaction[0]->name_type_id == 6){
        $app = $bmodel->get_item_name('other_students_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        
        $type_name1 = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
         $type_name2 = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[1]->name_type_id));
        $name_type = $type_name1[0]->name_type;
        $name_type2 = $type_name2[0]->name_type;
        
        $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2,'transation_nature'=>1));
   }
    $control_no = $bmodel->get_item_name('payment_request',$where = array('student_id' =>$app[0]->id));
    if(count($control_no) > 0){
    $control_number = $control_no[0]->reference_no;
    }
    $company_reg = $bmodel->get_table_details('company_tbl');
 //   $pay_dtls = $bmodel->get_item_name('payment_response',$where = array('reference_no' =>$control_number));
   // echo $leger_transaction[0]->name_id;
   // echo "</br>";
   $name_type_id= $leger_transaction[0]->name_type_id;
   $student_id= $leger_transaction[0]->name_id;
   $trans_no= $leger_transaction[0]->trans_no;
  // echo $trans_no;
   $name_type_id2= $leger_transaction[1]->name_type_id;
   $name_id2= $leger_transaction[1]->name_id;
   if($leger_transaction[1]->name_type_id==5){
     $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[1]->name_id));
        $student_name2 = $app[0]->first_name.' '.$app[0]->last_name; 
   }else{
    $student_name2 = $student_name;
   }
   $inv_no = $bmodel->get_item_name('transactions_relation',$where = array('receipt_trans_no'=>$leger_transaction[0]->trans_no));
   $invo=$inv_no[0]->invoice_trans_no;
   $rct=$recpt[0]->trans_number;
}
 $total = 0;
$i=0;
foreach($ledger_invoice as $itm){
    $total+=$itm->amount;
  }
        $dbname=session()->get('db_name');
         $db = \Config\Database::connect($dbname);
        // $query = $db->query('SELECT * FROM ledger_transaction_tbl WHERE ledger_id = 6 AND ledger_type = 7 AND trans_type = 1 AND transation_nature = 2 AND name_type_id = 1');
        //   $resulted = $query->getResult();
        //     foreach($resulted as $rs){
        //      //echo $rs->trans_no.'</br>';
        //      $trans_date = '2023-01-09 08:00';
               
        //         $upup = $bmodel->updateUpdate($rs->trans_no,$trans_date);
               
        //     }
        
      $query = $db->query('SELECT amount,account_name,accounts_tbl.id FROM ledger_transaction_tbl,accounts_tbl where ledger_transaction_tbl.ledger_id = accounts_tbl.id AND transation_nature = 2 AND trans_type=2 AND trans_no='.$recpt[0]->trans_number);
                     $result = $query->getResult();
                     $paytotal = 0;
                     foreach($result as $rsl){
                   $accounted=$rsl->account_name;
                   $ac_id=$rsl->id;
                  // echo $accounted;
                     }
 ?>
 

      <!----------------------------------------------------------------------------->
        

          <div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
          
            <!--   <center>
 <button class="btn btn-primary btn-sm" onclick="printable('Rept1ResultViewResults')"><span class="fa fa-print"></span> Print</button>
</center> -->
           
     <!--------------------------code placed here--------------------------------------------------->
      
                 <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header mt-1"  style="height:5px">
                                <h3 class="card-title">Edit Receipt 
                                    <li class="help-icon">
                                      <a href="#" onclick="tg_help()" style="margin-left:8px"><span class="icon1">?</span></a>
                                     </li>
               </h3>
                                <div class="card-options ">
                                    <button class="btn" onclick="resetReceiptData()"><i class="fa fa-refresh"></i> </button>
                                    <!-- <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a> -->
                                </div>
                            </div>
                                <hr>
                            <div class="card-body" id="receiptData">
                                <div class="row">
                                    <div class="col-md-6">
                                            <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Receipt No</label>
                                            <div class="col-sm-2 mt-1">
                                              <?php echo $rct; ?>
                                               <input type="hidden" id="rct_no" name="rct_no" value="<?php echo $rct; ?>">
                                            </div>
                                          </div>
                                        <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Receipt Date</label>
                                            <div class="col-sm-8">
                                              <input type="date" onchange="dateChanged('<?php echo $rct; ?>')" id="receipt_date" name="receipt_date" value="<?php echo date('Y-m-d',strtotime($recpt[0]->trans_date));?>" class="form-control" max="<?php echo date('Y-m-d');?>">
                                            </div>
                                          </div>
                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Paid By<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                               <select class="form-control" name="paid_by" id="paid_by1">
                                                    <option value="<?=$name_type_id2;?>" selected><?php echo $name_type2;?></option>
                                                    <option value="1">Student</option>
                                                    <option value="5">Parent/Guardian</option>
                                                </select>
                                            </div>
                                          </div>

                                          <div class="form-group row" id="payer_name_row1" style="">
                                            <label for="payerame" class="col-sm-4 col-form-label">Payer Name<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                                <div class="input-group mb-3">
                                                    <input type="hidden" id="payer_id1" name="payer_id" value="">
                                                     <input type="text" class="form-control" name="payer_name" id="payer_name" value="<?=$student_name2;?>">
                                                    <button class="btn btn-outline-primary" type="button" id="button-addon2" onclick="search_payer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                          </div>
                                          <div id="payer_details"></div>
                                         <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Customer Type<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                               <?php
                                                    $ctype= $bmodel->get_table_details('name_type_tbl');
                                                  ?>
                                                <select class="form-control" name="customer_type" id="customer_type1">
                                                    <option value="<?=$name_type_id;?>"><?=$name_type;?></option>
                                                    <?php foreach($ctype as $type): ?>
                                                    <option value="<?= $type->id ?>"><?= $type->name_type; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                          </div>
                                          <div class="form-group row" id="select_invoice1" style="">
                                            <label for="payerame" class="col-sm-4 col-form-label">Invoice Name<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" name="customer_name or Id" value="<?=$student_name;?>" id="customer_name" placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2">
                                                    <button class="btn btn-outline-primary" type="button" id="button-addon2" onclick="search_customer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                          </div>

                                            <!--------------------show credit note-------------------------->
                                          <div class="form-group row" id="ttlCredit_edit" style="display:none;">
                                                <label for="staticEmail" class="col-sm-4 col-form-label text-green">Total Credit Note</label>
                                                <div class="col-sm-8">
                                                  <input type="text" readonly class="form-control-plaintext text-green" id="credited_edit" value="0">
                                                </div>
                                               <!--  <div class="col-sm-1">
                                                </div>  -->  
                                              </div>
                                        <!---------------------------------------------->
                                          <!--------------------show Over payment-------------------------->
                                          <div class="form-group row" id="payedOver" style="display:none;">
                                                <label for="staticEmail" class="col-sm-4 col-form-label text-green">Total Over payment</label>
                                                <div class="col-sm-8">
                                                  <input type="text" readonly class="form-control-plaintext text-green" id="payover" value="0">
                                                </div>
                                               <!--  <div class="col-sm-1">
                                                </div>  -->  
                                              </div>
                                        <!---------------------------------------------->
                                        
                                    </div>   
                                    <div class="col-md-6">
                                       <div id="customer_loaded"></div> 
                                       <div id="Name_loaded"></div>
                                       <div id="Invoice_loaded"></div>
                                    </div>
                                </div>
                                 <div class="row">
                                     <div class="col-md-12">
                                         
                                         <br>
                                     </div>
                                 </div> 
                                <hr>
                                <div class="row">
                                    <div class="col-md-12">
                                        
                                        <form id="receipt_form">
                                            <div id="applicationlist" style="display:none;">
                                             <h6>Application List</h6>
                                            <table class="table" >
                                            <thead>
                                                <tr>
                                                    <th>Student Id</th>
                                                    <th>Student Name</th>
                                                    <th>Item Name</th>
                                                    <th>Quantity</th>
                                                    <th>Amount Due</th>
                                                    <th>Amount To Pay</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="itm_invoice1">
                                            </tbody>
                                        </table>
                                        </div>  
                                        <div id="invoicelist">
                                            <h6>Invoice List</h6>
                                        <table class="table table-borderless" >
                                            <thead>
                                                <tr>
                                                    <th>Select</th>
                                                    <th>Invoice type</th>
                                                    <th>Invoice No</th>
                                                    <th>Invoice Date</th>
                                                    <th>Invoice Name</th>
                                                    <th>Invoice Amount</th>
                                                    <th>Amount Due</th>
                                                    <th>Amount Payed</th>
                                                </tr>
                                            </thead>
                                            <tbody id="itm_invoice">
                                            </tbody>
                                            <tfoot>
                                                <tr id="itm_invoicefooter"></tr>
                                            </tfoot>
                                        </table>
                                        </div>
                                        </form>    
                                    </div>
                                </div>
                               
                                <!-- <div class="row mt-4"> -->
                                <?php
                                    $acc = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 9));
                                     $account = $bmodel->get_item_name('accounts_tbl', $where = array('account_type_id' => 7));
                                      $current = $bmodel->get_item_name('accounts_tbl', $where = array('id' => 21));
                                ?>
                                <div class="cust_popup" id="account" style="display: none">
                                    <form method="POST" id="acct_proc">
                                        <b>CHARGE ACCOUNT</b><i style="color: red" id="saveError"></i><br/>
                                        ACCOUNT NAME
                                        <input class="form-control" id="acc_name" type="text" onkeyup="SearchAccount()" autocomplete="off">
                                        <input id="acc_no" type="hidden">
                                        <div id="schResults"></div>
                                        <br>
                                        AMOUNT
                                        <input class="form-control" id="acc_amt" type="number" autocomplete="off"><br>
                                        <button type="submit" id="svAccnt" class="btn btn-primary pull-right">Save</button>&nbsp;
                                    </form>
                                    <button class="btn btn-warning" style="display:none" id="removeAcct">Remove Account</button>
                                    <button class="btn btn-warning" onclick="tg_acct()">Cancel</button>
                                </div>
                                <!----------------------payment popup-start---------------------------->
                                <div  class="cust_popup" id="cash" style="display: none">
                                    <h6>Receive Cash</h6>
                                     <form id="csh_proc_edit" method="POST">
                                         <select class="form-control" name="ledger" id="ledger" required="">
                                             <option value="">Select Ledger</option>
                                            <?php foreach($acc as $ac):?>
                                                 <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                             <?php endforeach; ?>
                                         </select><br>
                                         <input class="form-control" name="cash_amt" id="cash_amt" type="number" required="" ><br>
                                         <button class="btn btn-warning" onclick="close_Popup()">Cancel</button>
                                         <button type="submit" class="btn btn-primary pull-right">Save</button>&nbsp;
                                     </form>
                                   <button class="btn btn-sm btn-warning" style="display:none" id="removeCash">Remove Cash</button>&nbsp;
                               </div>  
                                <!----------------------payment popup-end---------------------------->
                               <!-------credit note popup------------------------------------------>
                                <div  class="cust_popup" id="cash_credit" style="display: none; width: 600px;">
                                    <h6 class="text-center">AVAILABLE CREDIT NOTE LIST</h6><br>
                                  
                                     <form id="csh_proc_cr_edit" method="POST" autocomplete="off">
                                      
                                <!-------------------------------------------------------->

                                      <table class="table">
                                            <thead>
                                                <tr>
                                                  <th>Type</th>
                                                    <th>Note No</th>
                                                    <th>Credit Amount</th>
                                                    <th>Credit Bal</th>
                                                    <th>Use</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="choose_credit_edit">
                                            </tbody>
                                            <tfoot class="border-less">
                                                <tr id="itm_creditfooter_edit"></tr>
                                            </tfoot>
                                        </table>
                                         <!-------------------------------------------------------->
                                         <!-- <input class="form-control" name="cash_amt_cr" id="cash_amt_cr" type="number" required="" ><br> -->
                                         <button class="btn btn-warning" onclick="closePopup()">Cancel</button>
                                         <button type="submit" class="btn btn-primary pull-right" id="savecedit">Save</button>&nbsp;
                                     </form>
                                   <button class="btn btn-sm btn-warning" style="display:none" id="removeCash">Remove Cash</button>&nbsp;
                               </div>   
                      <!------------end popup--------------------------------------------> 
                      <!-------Over payment popup------------------------------------------>
                                <div  class="cust_popup" id="cash_over" style="display: none;width: 500px;">
                                   <h6 class="text-center">OVERPAYMENT LIST</h6><br>
                                     <form id="csh_proc_over_edit" method="POST" autocomplete="off">
                                         <table class="table" >
                                            <thead>
                                                <tr>
                                                   <th>Type</th>
                                                   <th>Trans No</th>
                                                   <th>OverPayment</th>
                                                    <th>Balance</th>
                                                    <th>Use</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="choose_over_edit">
                                            </tbody>
                                            <tfoot class="border-less">
                                                <tr id="itm_overfooter_edit"></tr>
                                            </tfoot>
                                        </table>
                                        <br>
                                        <button class="btn btn-warning" onclick="closePopup_over()">Cancel</button>
                                         <button type="submit" class="btn btn-primary pull-right" id="saveo_edit">Save</button>&nbsp;
                                     </form>
                                   <!-- <button class="btn btn-sm btn-warning" style="display:none" id="remo veCash">Remove Cash</button>&nbsp; -->
                               </div>  

                      <!-------end over popup--------------------------------------------> 
                        <!------deposit usepopup------------------------------------------>
                     <div  class="cust_popup" id="deposit_popup" style="display: none;width: 500px;">
                                   <h6 class="text-center">DEPOSIT LIST
                    <li class="help-icon">
                    <a href="#" onclick="tg_help()" style="margin-left:8px"><span class="icon1">?</span></a>
                   </li></h6><br>
                                     <form id="csh_proc_deposit_edit" method="POST" autocomplete="off">
                                         <table class="table" >
                                            <thead>
                                                <tr>
                                                  
                                                   <th>Deposit No</th>
                                                   <th>Amount</th>
                                                    <th>Balance</th>
                                                    <th>Use</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="choose_deposit_edit">
                                            </tbody>
                                            <tfoot class="border-less">
                                                <tr id="itm_depositfooter_edit"></tr>
                                            </tfoot>
                                        </table>
                                        <br>
                                        <button class="btn btn-warning" onclick="closePopup_deposit()">Cancel</button>
                                         <button type="submit" class="btn btn-primary pull-right" id="saved_edit">Save</button>&nbsp;
                                     </form>
                                   <!-- <button class="btn btn-sm btn-warning" style="display:none" id="remo veCash">Remove Cash</button>&nbsp; -->
                               </div>  

                                  <!-----------------------end over popup-------------------------------------------->
                                <hr>
                                <div class="row">
                                    <!-- <div class="col-md-6">
                                     
                                     <button type="button" class="btn btn-primary" onclick="tg_patacct()"  >Account</button>
                                   <button type="button" class="btn btn-primary">Cheque</button>
                                    </div> -->
                                    <div class="col-md-12">
                                        <form id="payment_panel">
                                            <?php foreach($acc as $ap):?>
                                                  <div class="form-group row" id="ledgerRow<?= $ap->id?>" style="display: none;" >
                                                    <label for="staticEmail" class="col-sm-1 col-form-label"><?= $ap->id; ?> </label>
                                                    <label for="staticEmail" class="col-sm-3  col-form-label"><?= $ap->account_name; ?> Ledger</label>
                                                    <div class="offset-md-6 col-sm-1">
                                                      <input type="text" readonly class="form-control-plaintext" id="ledger_payed<?= $ap->id?>" value="900">
                                                    </div>
                                                    <div class="col-sm-1">
                                                        <div id="legerRata<?= $ap->id?>">
                                                        </div>    
                                                        <label style="margin-top: 10px;"><i  onclick="removePayment_edt('<?= $ap->id?>')" class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="delete"></i></label>
                                                    </div>   
                                                   </div>
                                            <?php endforeach; ?>
                         <!---------------------------credit row start here------->
                                               <?php foreach($account as $ap):?>
                                                  <div class="form-group row" id="ledgerRow<?= $ap->id?>" style="display: none;" >
                                                    <label for="staticEmail" class="col-sm-1 col-form-label"><?= $ap->id; ?> </label>
                                                    <label for="staticEmail" class="col-sm-3  col-form-label"><?= $ap->account_name; ?> Ledger</label>
                                                    <div class="offset-md-6 col-sm-1">
                                                      <input type="text" readonly class="form-control-plaintext" id="ledger_payed<?= $ap->id?>" value="900">
                                                    </div>
                                                    <div class="col-sm-1">
                                                        <div id="legerRata<?= $ap->id?>">
                                                        </div>    
                                                        <label style="margin-top: 10px;"><i  onclick="removePayment_edt('<?= $ap->id?>')" class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="delete"></i></label>
                                                    </div>   
                                                   </div>
                                            <?php endforeach; ?>
                    <!------------------------------credit row end here---------------------------->
                                             <div class="form-group row"  >
                                                <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label">Amount Due</label>
                                                <div class="offset-md-6 col-sm-1">
                                                  <input type="text" readonly class="form-control-plaintext" id="amount_due" value="0">
                                                </div>
                                                <div class="col-sm-1">
                                                </div>   
                                              </div>
                                            <div class="form-group row" style="display: none;" id="change_row" >
                                                <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label text-danger">Over Payment</label>
                                                <div class="offset-md-6 col-sm-1">
                                                  <input type="text" readonly class="form-control-plaintext text-danger" id="amount_change" value="">
                                                </div>
                                                <div class="col-sm-1">
                                                </div>   
                                              </div>
                                          
                                        </form>       
                                    </div>
                                    <div class="col-md-2">
                                         <button type="button" class="btn btn-primary pull-left" onclick="tg_cash()"> Add Payment</button>
                                     </div>
                                     <div class="col-md-2" >
                                         <button type="button" class="btn btn-primary pull-left" id="another_edit" onclick="tg_cashNote()"> Use Credit Note</button>
                                     </div>
                                      <div class="col-md-2" >
                                         <button type="button" class="btn btn-primary pull-left" id="over-btn" onclick="tg_overpay()"> Use Over Payment</button>
                                     </div>
                                     <!------below is deposit btn--------------->
                                 <div class="col-md-2" id="deposit_use">
                                         <button type="button" class="btn btn-success pull-left" id="deposit-btn" onclick="tg_deposit()"> Use Deposit</button>
                                    </div>
                       <!------above is deposit btn--------------->
                                </div> 
                            </div>

                            <div class="card-footer">
                               
                                <button type="button" id="finishReceipt" class="btn btn-primary pull-right" onclick="finish_receipt()">Update</button>
                            </div>
                        </div>
                    </div>
                </div>
                
                </div>
                </div>
            
        </div>
    
<script>
   var allvariables = "";
    var total=0;
    var amountdue =0;
    var amountpayed =0;
    var item_list = [];
    var k =0;
    var totalinv = 0;
     var overpayed=0;
     var depositpayed=0;
    var change=0;
    var credit_list = [];
     var over_list = [];
     var deposit_list = [];
    var c=0;
    var ov=0;
    var od=0;
    var totalcre = 0;
    var totalovp = 0;
    var totaldep = 0;
    //resetReceiptData();
    $('#finishReceipt').prop("disabled", true);
    prepare_invoice_student(<?=$student_id;?>,<?=$trans_no;?>);
    appendRow();
    var payer = <?php echo $name_type_id2;?> +'_' +<?php echo $name_id2;?>;
        $('#payer_id1').val(payer);
        //alert(payer);
    function manage_receipt(inv){
        //alert(inv);
      $('#viewreceipt').modal('show'); 
      $('#viewreceipt_content').load('view_receipt/'+inv);
    }
     function manage_rec(inv){
        //alert(inv);
      $('#editreceipt').modal('show'); 
      $('#editreceipt_content').load('edit_receipt/'+inv);
    }
    function search_customer(){
       if($('#customer_type1').val() == "") {
           swal("warning","Please Select Customer Type","warning");
       }else if($('#customer_name').val() == ""){
          swal("warning","Please Enter Customer Name","warning"); 
       }else{
            var paydata = 'type=' + $('#customer_type1').val() + "&cust_name=" + $('#customer_name').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/search_customer_details'; ?>',
                beforeSend: function () {
                    $('#Name_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#Name_loaded').html(result); 
                },
                error: function () {
                    $('#Name_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
       
    }
    function student_select(id){
        var paydata = 'type=' + $('#customer_type1').val()+'&id=' + id;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/loadInvoices'; ?>',
                beforeSend: function () {
                    $('#Invoice_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#Invoice_loaded').html(result); 
                },
                error: function () {
                    $('#Invoice_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
      });
    }
    function prepare_invoice(student_id){
         var paydata = 'type=' + $('#customer_type1').val()+'&id=' + student_id;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/create_invoice'; ?>',
                data: paydata,
                success: function (result) {
                    $('#Invoice_loaded').html(''); 
                    var data = JSON.parse(result); 
                    var mydata= Object.keys(data).length;
                    if(mydata>0){
                    for( var i = 0; i < mydata; i++){
                        k++;
                        item_list.push(k);
                        var unit_price = parseInt(data[i]['unit_price']);
                        total += unit_price;
                        amountdue = total - amountpayed;
                        var name_type = $('#customer_type1').val() +'_'+ student_id;
                        var itm = '<tr><input type="hidden"  name="student[]"  value="'+name_type+'">'+
                                   '<td>' + data[i]['student_id']  +'</td>'+
                                   '<td><input type="hidden"  name="studentId'+name_type+'" value="'+student_id+'">' + data[i]['full_name']  +'</td>'+
                                   '<td><input type="hidden"  name="customerType'+name_type+'" value="'+$('#customer_type1').val()+'">' + data[i]['item_name']  +'</td>'+
                                   '<td>' + data[i]['quantity']  +'</td>'+
                                   '<td>' + unit_price.toLocaleString()  +'</td>'+
                                   '<td><input type="number" class="form-control" id="amounttopay'+k+'"  value="'+data[i]['unit_price']+'" name="amount'+name_type+'" style="width:100px;" disabled></td>' +
                                   '</tr>';
                       $('#itm_invoice1').append(itm);
                       $('#receipt_calc').html(total.toLocaleString());
                       $('#amount_due').val(amountdue.toLocaleString());
                       $('#amount_due').css({"color": "red"});
                   }
                   }else{
                    
                   }
                },
                error: function () {
                    $('#itm_invoice').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
      });
    }
 
   function tg_cash() {
        $('#cash').toggle(100);
    }
    function tg_cashNote() {
        $('#cash_credit').toggle(100);
        $('#noted').val(totalnote.toLocaleString());
        $('#cash_amt_cr').val('');
    }
    var overpayed=0;
    function appendRow(){
        var data = 'trans=' +<?php echo $trans_no; ?>;
    
        //var change;
      ///////////////////////////////////////////
          $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/find_receipt_ledger'; ?>',
                data: data,
                success: function (result) {
                   
                    var data = JSON.parse(result); 
                    var mydata= Object.keys(data).length;
                    if(mydata > 0){
                    for( var i = 0; i < mydata; i++){
                          var cashAmt = data[i]['amount'];
                          var ledger = data[i]['ledger_id'];
                         // alert(cashAmt);
                       $('#ledgerRow'+data[i]['ledger_id']).show();
                       if(data[i]['trans_item']>0 && ledger==21){
                         $('#ledger_payed'+data[i]['ledger_id']).val('-'+cashAmt.toLocaleString());
                          $('#payedOver').show();
                        $('#payover').val(data[i]['balance'].toLocaleString());
                        overpayed=data[i]['balance'];
                         $('#over-btn').prop("disabled", false);
                     }else{
                       
                         $('#ledger_payed'+data[i]['ledger_id']).val(cashAmt.toLocaleString());
                     }
                    
                     
                        }
                    }},
                error: function () {
                    $('#itm_invoice').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
      });
    }
   
      //////////////////////////////////////////////
       
    
    $("#csh_proc_edit").submit(function (e) {
        var cashAmt = parseInt($('#cash_amt').val());
               //amountdue = amountdue - cashAmt;
        var ledger = $('#ledger option:selected').val();
            $('#ledgerRow'+ledger).show();
            $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
            var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" name="amount'+ledger+'" value="'+ cashAmt +'">';
            $('#legerRata'+ledger).append(data);
        if(amountdue >= 0){
            $('#change_row').hide();
           $('#amount_due').val(amountdue.toLocaleString()); 
        }else{
           change = amountdue * -1;
           amountdue = 0;
           $('#amount_due').val(amountdue);
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
        amountpayed += cashAmt;
        AmtCalc_edit_ex();
        tg_cash();
       
        e.preventDefault();
    });
    function finish_receipt1(){
       //   if($('#payer_id').val()==""){
       // swal('warning','select payer name')
       //  }else{
         $('#finishReceipt').prop("disabled", true);
        var allvariables2 = $("#receipt_form").serialize() + '&bill_payer='+$('#payer_id1').val() + '&'+ $("#payment_panel").serialize()+'&date='+$('#receipt_date').val()+'&rno='+$('#rct_no').val()+'&'+$("#header_form").serialize()+'&change='+change+'&'+$("#csh_proc_cr_edit").serialize()+'&'+$("#csh_proc_over_edit").serialize()+$("#csh_proc_deposit_edit").serialize();
        // alert(allvariables2);
         $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillingController/update_delete_rcpt'; ?>',
            data: allvariables2,
            success: function (res) {
              var data = JSON.parse(res);
              if(data['status'] == "1"){
                swal({
                    title: "successful", 
                    text: data['description'], 
                    type: "success"
                  },
                function(){ 
                  $('#editreceipt').modal('hide');   
                  // location.reload();
                }
             );
            }
            },
            error: function (){
                alert('error encounted');
            }
        });
    }
    //}
    $("#paid_by1").change(function(){
        $('#payer_name_row1').show();
        $('#payer_details').html('');
    });
    $("#customer_type1").change(function(){
        $('#select_invoice1').show();
        if($(this).val() == 4){
            $('#applicationlist').show();
            $('#invoicelist').hide();
        }else{
           $('#invoicelist').show(); 
           $('#applicationlist').hide();
        }
    });
    function search_payer(){
        //alert($('#paid_by1 option:selected').val());
       if($('#paid_by1 option:selected').val() == "") {
           swal("warning","Please Select Paid By","warning");
       }else if($('#payer_name').val() == ""){
          swal("warning","Please Enter Payer Name","warning"); 
       }else{
            var paydata = 'paid_by=' + $('#paid_by1 option:selected').val() + "&payer_name=" + $('#payer_name').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/search_payer'; ?>',
                beforeSend: function () {
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#customer_loaded').html(result); 
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
       
    }
    function select_payer(id,nametype,payer_name){
       var payer = nametype +'_' +id;
        $('#payer_id1').val(payer);
        var payerdata = "payer=" + payer;
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillingController/get_payer_details'; ?>',
            data: payerdata,
            success: function (res) {
                $('#payer_details').html(res);
                $('#payer_name_row1').hide();
                $('#customer_loaded').html('');
            },
            error: function (){
                alert('error encounted');
            }
        });
    }
    function select_pending_student(student_id){
         $('#Name_loaded').html(''); 
        $('#select_invoice1').hide();
    }

   $('#credited').val(0);
     $('#another_edit').prop("disabled", true);
     var totalnote=0;
    function prepare_invoice_student(student_id,trans_no){
        
       // alert(student_id);
        $('#itm_invoice').empty();
           var paydata = 'id=' + student_id+'&trans='+trans_no;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/select_invoice_student'; ?>',
                 data: paydata,
                 dataType: 'json',
                success: function (result) {
                    $('#Invoice_loaded').html(''); 
                    var data=result.result1;

                    var data2=result.result2; 
                    var used_credit=result.resulted; 
                    
                     var data3=result.result3;
                     var used_over=result.resulted3;

                     var data4=result.result4;
                     var used_deposit=result.resulted4; 

                   var mydata= Object.keys(data).length;
                    var mydata2= Object.keys(data2).length;
                     var mydata3= Object.keys(data3).length;
                     var mydata4= Object.keys(data4).length;
                    var credit_used= Object.keys(used_credit).length;
                    var over_used= Object.keys(used_over).length;
                    var deposit_used= Object.keys(used_deposit).length;
                    //alert(mydata);
                    if(mydata>0){
                    var name_type = $('#customer_type1').val() +'_'+ student_id;
                    itotal=0;
                if(mydata2==0){
                    var itmc = '<tr>'
                                        +'<td colspan="5">No any Credit Available</td>'
                                       +'</tr>'; 
                                        $('#choose_credit_edit').append(itmc);
                                        $('#savecedit').prop("disabled", true);
                     totalnote=0;
                    }else{

          ////////////////////////shows credit note /////////////////////// 
                var credit_total=0;               
                var credit_total_used=0;               
                for(var i = 0; i < mydata2; i++){
                        c++;
                        credit_list.push(c);
                        credit_balance = parseInt(data2[i]['balance']);
                        credit_total += parseInt(data2[i]['balance']);
                       var trans = data2[i]['trans_no'];
                         var amount_used=0;
                         if(credit_used>0){
                        for(var u = 0; u < credit_used; u++){
                             var used_no = used_credit[u]['used_no'];
                             if(used_no == trans){
                             amount_used=used_credit[u]['amount'];
                             }
                              }
                            credit_total_used+=parseInt(amount_used);
                           }
                        var itmc = '<tr id="row'+ c +'"><input type="hidden"  name="totalcredit"  value="'+mydata2+'">'
                                        +'<td><input type="hidden"  name="ledgerId"  value="'+data2[i]['ledger_id']+'">' + data2[i]['type_name']  +'</td>'
                                       +
                                      '<td><input type="hidden"  name="credit_no'+c+'" value="'+data2[i]['trans_no']+'">' + data2[i]['trans_no']  +'</td>'+
                                     '<td>' + data2[i]['amount'].toLocaleString()  +'</td>'+
                                    '<td><input type="hidden"  id="credit_due'+c+'" value="'+credit_balance+'">' + credit_balance.toLocaleString()  +'</td>'+
                                       '<td><input type="text" class="form-control qtyc" onkeyup="AmtCalcCredit()" id="amounttopayCredit'+c+'"  value="'+amount_used+'" name="credit_amount'+c+'" style="width:100px;" max="'+credit_balance+'"></td>' +
                                       '</tr>';
                                 $('#choose_credit_edit').append(itmc);
                                  $('#ttlCredit_edit').show();
                                $('#credited_edit').val(credit_total.toLocaleString());
                                $('#another_edit').prop("disabled", false);
                             $('#itm_creditfooter_edit').html('<td colspan="3"><b>Total</td><td>'+ credit_total.toLocaleString() +'</td><td id="credit_calc">'+ credit_total_used.toLocaleString() +'</b> </td>');
                }
                 totalnote=parseInt(credit_total);
      ////////////////////////end credit note /////////////////////// 
                 // totalnote=parseInt(data2[0]['balance']);
                  //alert(totalnote);
                     }

       //************start*over payment edit****************************************//
                     if(mydata3==0){
                        var itmov = '<tr>'
                                        +'<td colspan="5">No any Overpayment Available</td>'
                                       +'</tr>'; 
                                        $('#choose_over_edit').append(itmov);
                                        $('#saveo_edit').prop("disabled", true);
                     overpayed=0;
                     }else{
                   
                var over_total=0;  
                var over_total_used=0;              
                for(var i = 0; i < mydata3; i++){
                        ov++;
                        over_list.push(ov);
                        over_balance = parseInt(data3[i]['balance']);
                        over_total += parseInt(data3[i]['balance']);

                        var trans = data3[i]['trans_no'];
                         var amount_used=0;
                         if(over_used>0){
                        for(var u = 0; u < over_used; u++){
                             var used_no = used_over[u]['used_no'];
                             if(used_no == trans){
                             amount_used=used_over[u]['amount'];
                             }
                              }
                            over_total_used+=parseInt(amount_used);
                           }
                        var itmov = '<tr id="row'+ ov +'"><input type="hidden"  name="totalover"  value="'+mydata3+'">'
                                        +'<td><input type="hidden"  name="ledgerId_over"  value="'+data3[i]['ledger_id']+'">' + data3[i]['type_name']  +'</td>'
                                       +
                                      '<td><input type="hidden"  name="over_no'+ov+'" value="'+data3[i]['trans_no']+'">' + data3[i]['trans_no']  +'</td>'+
                                     '<td>' + data3[i]['amount'].toLocaleString()  +'</td>'+
                                    '<td><input type="hidden"  id="over_due'+ov+'" value="'+over_balance+'">' + over_balance.toLocaleString()  +'</td>'+
                                       '<td><input type="text" class="form-control qtyc" onkeyup="AmtCalcOver()" id="amounttopayOver'+ov+'"  value="'+amount_used+'" name="over_amount'+ov+'" style="width:100px;" max="'+over_balance+'"></td>' +
                                       '</tr>';
                                 $('#choose_over_edit').append(itmov);
                                  $('#payedOver').show();
                                $('#payover').val(over_total.toLocaleString());
                                // $('#over-btn').prop("disabled", false);
                             $('#itm_overfooter_edit').html('<td colspan="3"><b>Total</td><td>'+ over_total.toLocaleString() +'</td><td id="over_calc">'+ over_total_used.toLocaleString() +'</b> </td>');
                }
                  overpayed=parseInt(over_total);
      
                   
                    }
               
       //************end*over payment edit*********//  
       //**deposit edit***start*************************************//
                     if(mydata4==0){
                        var itmde = '<tr>'
                                        +'<td colspan="4">No any Deposit Available</td>'
                                       +'</tr>'; 
                                        $('#choose_deposit_edit').append(itmde);
                                        $('#saved_edit').prop("disabled", true);
                     depositpayed=0;
                     }else{
                   
                var deposit_total=0;  
                var deposit_total_used=0;              
                for(var i = 0; i < mydata4; i++){
                        od++;
                        deposit_list.push(od);
                        deposit_balance = parseInt(data4[i]['balance']);
                        deposit_total += parseInt(data4[i]['balance']);

                        var trans = data4[i]['trans_no'];
                         var amount_used=0;
                         if(deposit_used>0){
                        for(var u = 0; u < deposit_used; u++){
                             var used_no = used_deposit[u]['used_no'];
                             if(used_no == trans){
                             amount_used=used_deposit[u]['amount'];
                             }
                              }
                            deposit_total_used+=parseInt(amount_used);
                           }
                        var itmde = '<tr id="row'+ od +'"><input type="hidden"  name="totaldeposit"  value="'+mydata4+'">'
                                       +'<td><input type="hidden"  name="deposit_no'+od+'" value="'+data4[i]['trans_no']+'">' + data4[i]['trans_no']  +'</td>'+
                                     '<td><input type="hidden"  name="ledgerId_deposit"  value="'+data4[i]['ledger_id']+'">' + data4[i]['amount'].toLocaleString()  +'</td>'+
                                    '<td><input type="hidden"  id="deposit_due'+od+'" value="'+data4[i]['amount']+'">' + deposit_balance.toLocaleString()  +'</td>'+
                                       '<td><input type="text" class="form-control qtyc" onkeyup="AmtCalcDeposit_edit()" id="amounttopayDeposit'+od+'"  value="'+amount_used+'" name="deposit_amount'+od+'" style="width:100px;" max="'+deposit_balance+'"></td>' +
                                       '</tr>';
                                 $('#choose_deposit_edit').append(itmde);
                                  $('#payedDeposit').show();
                                $('#paydeposit').val(deposit_total.toLocaleString());
                                // $('#over-btn').prop("disabled", false);
                             $('#itm_depositfooter_edit').html('<td colspan="2"><b>Total</td><td>'+ deposit_total.toLocaleString() +'</td><td id="deposit_calc">'+ deposit_total_used.toLocaleString() +'</b> </td>');
                }
                  depositpayed=parseInt(deposit_total);
      
                   
                    }
               
       //************end*over payment edit****************************************//             
                    for( var i = 0; i < mydata; i++){
                        k++;
                        item_list.push(k);
                        var unit_price = parseInt(data[i]['balance']);
                        total += unit_price;
                        var invoice_amount = parseInt(data[i]['amount']);
                        totalinv +=invoice_amount;
                        amountdue = 0;
                        var itm = '<tr id="row'+ k +'"><input type="hidden"  name="student[]"  value="'+name_type+'">'+
                                         '<td><input type="checkbox" name="type" value="'+k+'" onclick="checkbox('+k+','+unit_price+')" id="opt'+k+'"></td>'
                                        +'<td>' + data[i]['type_name']  +'</td>'
                                       +
                                      '<td><input type="hidden"  name="trans_no'+k+'" value="'+data[i]['trans_no']+'">' + data[i]['trans_no']  +'</td>'+
                                       '<td>' + data[i]['trans_date']  +'</td>'+
                                       '<td>' + data[i]['full_name'] +'</td>'+
                                       '<td>' + invoice_amount.toLocaleString()  +'</td>'+
                                     '<td><input type="hidden"  id="due'+k+'" value="'+unit_price+'">' + unit_price.toLocaleString()  +'</td>';
                                     if (data[i]['trans_no'] == '<?php echo $invo;?>') {
                                    itm += '<td><input type="text" class="form-control qty" onkeyup="AmtCalc_edit()" id="amounttopay' + k + '" value="' + <?php echo $total; ?> + '" name="amount' + k + '" style="width:100px;"></td>';
                                } else {
                                    itm += '<td><input type="text" class="form-control qty" onkeyup="AmtCalc_edit()" id="amounttopay' + k + '" value="' + 0 + '" name="amount' + k + '" style="width:100px;"></td>';
                                }

                                itm += '</tr>';
                               
                       $('#itm_invoice').append(itm);
                       $('#itm_invoicefooter').html('<td colspan="5"><b>Total</td><td>'+ totalinv.toLocaleString() +'</td><td>'+ total.toLocaleString() +'</td><td id="receipt_calc">'+ <?php echo $total;?> +'</b> </td>');
                       // $('#Name_loaded').html(''); 
                       // $('#select_invoice').hide();
                       //$('#receipt_calc').html(total.toLocaleString());
                       $('#amount_due').val(0);
                   }
               }else{
       $('#itm_invoice').html('<p class="text-red">Sorry No invoice Available</p>');
       // $('#Name_loaded').html(''); 
       //  $('#select_invoice').hide();
               }
                },
                error: function () {
                    $('#itm_invoice').html('<p class="text-red">Sorry Something went wrong</p>');
               }
      });
    }

       function AmtCalc_edit() {
         "<?php foreach($acc as $ap){?>";
         var lg="<?php echo $ap->id;?>";
           //alert(lg);
      $('#ledgerRow'+lg).hide();
       $('#ledger_payed'+lg).html('');
       $('#legerRata'+lg).html('');
       $('#change_row').hide();
         "<?php } ?>";

         "<?php foreach($account as $ap){?>";
         var lg="<?php echo $ap->id;?>";
           //alert(lg);
      $('#ledgerRow'+lg).hide();
       $('#ledger_payed'+lg).html('');
       $('#legerRata'+lg).html('');
       $('#change_row').hide();
         "<?php } ?>";

       var needed=0;
        total = 0;
        var i=0;
        for (var j in item_list) {
          
           var due=$('#due' + item_list[j]).val(); 
           var amr=$('#amounttopay' + item_list[j]).val();
          

         total += parseInt($('#amounttopay' + item_list[j]).val()); 
             
        }
      if(i==0){
        
        amountdue = total;
        //alert(amountpayed);
        if(amountdue >= 0){
          $('#amount_due').val(amountdue.toLocaleString());
        }else if(amountdue<0){
            change = amountdue * -1;
          $('#amount_due').val(0);  
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
        if (amountdue <= 0) {
            $('#finishReceipt').prop("disabled", false);
        } else {
            $('#finishReceipt').prop("disabled", true);
        }
        $('#receipt_calc').html(total.toLocaleString());
       }else{

       } 
    }

    function AmtCalc_edit_ex() {
        //alert('here');
       var needed=0;
        total = 0;
        var i=0;
        for (var j in item_list) {
          
           var due=$('#due' + item_list[j]).val(); 
           var amr=$('#amounttopay' + item_list[j]).val();
          

              total += parseInt($('#amounttopay' + item_list[j]).val()); 
             
        }
      if(i==0){
        
        amountdue = total - amountpayed;
        //alert(amountpayed);
        if(amountdue >= 0){
          $('#amount_due').val(amountdue.toLocaleString());
        }else if(amountdue<0){
            change = amountdue * -1;
          $('#amount_due').val(0);  
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
        if (amountdue <= 0) {
            $('#finishReceipt').prop("disabled", false);
        } else {
            $('#finishReceipt').prop("disabled", true);
        }
        $('#receipt_calc').html(total.toLocaleString());
       }else{

       } 
    }
    function RemoveSelectItemRow(looper){
        for( var i = 0; i < item_list.length; i++){ 
            if ( item_list[i] == looper) {                 
                item_list.splice(i, 1); 
            }
        }
       $('#row'+looper).remove();
        AmtCalc_edit();
        
    }
    function removePayment_edt(lg){
        var amount= $('#ledger_payed'+lg).val().replace(/,/gi, "");
        //alert(amountdue);
    
       $('#ledgerRow'+lg).hide();
       $('#ledger_payed'+lg).html('');
       $('#legerRata'+lg).html('');

if(amountpayed >0){
     amountpayed -= amount;
 }
   //alert(amountpayed);
      amountdue = parseInt(amountdue) + parseInt(amount);   
 $('#amount_due').val(amountdue.toLocaleString()); 
  $('#change_row').hide();
             if (amountdue == 0) {
            $('#finishReceipt').prop("disabled", false);
        } else {
            $('#finishReceipt').prop("disabled", true);
        }
    }

 function resetReceiptData(){
        $('#payer_details').empty();
        $('#payer_name').val('');
        $('#payer_id1').val('');
        $('#payer_id').val('');
        $('#paid_by1').val('');
        $('#paid_by').val('');
        $('#customer_type1').val('');
         $('#customer_name').val('');
        $('#select_invoice1').hide();
        $('#customer_loaded').empty();
        $('#Name_loaded').empty();
        $('#Invoice_loaded').empty();
        $('#itm_invoice1').empty();
        $('#itm_invoice').empty();
        $('#amount_due').val(0);
   }
   function checkbox(k,p) {
    //alert(p);
 var remember = document.getElementById('opt'+k+'');
  if (remember.checked) {
    
       var fnsh = $('input[name=amount'+k+']').val();
       //alert(fnsh);
   $('input[name=amount'+k+']').attr('value',p);
    $('#receipt_calc').html(p.toLocaleString());
     }else
     {
    $('input[name=amount'+k+']').attr('value',0);
     $('#receipt_calc').html(0);
     }
 
}

function finish_receipt(){
         if(change>0){
        swal({
            title: "",
            text: 'The paid amount(Cash/Bank) is more than "Amount to Pay". An overpayment entry of '+change.toLocaleString()+' will be automatically generated in the Overpayment ledger. You will be able to apply this overpayment in future receipts. Are you sure you want to continue?',
           
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Ok",
            cancelButtonText: "Cancell",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
             
            finish_receipt1();
            } else {
              swal("Cancelled");
            }

          });
     // $('#over').html(change.toLocaleString());
     // $('#overPayment').modal('show'); 
    
    }else{
        change=0;
       finish_receipt1(); 
    }

    };
     function tg_overpay() {
        $('#cash_over').toggle(100);
        $('#over_show').val(overpayed.toLocaleString());
        $('#cash_amt_over').val('');
    }
  function tg_deposit() {
        $('#deposit_popup').toggle(100);
        $('#deposit_show').val(overpayed.toLocaleString());
        //$('#cash_amt_over').val('');
    }
    $("#csh_proc_over_edit").submit(function (e) {
        var cashAmt = parseInt(totalovp);
       // alert(cashAmt);
         overpayed=overpayed-cashAmt;
         amountdue = amountdue - cashAmt;
         //change=change-cashAmt;
          //$('#over_show').val(overpayed.toLocaleString());
         // $('#payover').val(overpayed.toLocaleString());

           var ledger = $('input[name=ledgerId_over]').val();
          //alert(ledger);
          //alert(amountdue);
             $('#ledgerRow'+ledger).show();
             $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
             var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" name="amount'+ledger+'" value="'+ cashAmt +'"><input type="hidden" id="over'+ledger+'" name="over'+ledger+'" value="'+ cashAmt +'">';
             $('#legerRata'+ledger).append(data);
        if(amountdue >= 0){
            $('#change_row').hide();
           $('#amount_due').val(amountdue.toLocaleString()); 
        }else{
           change = amountdue * -1;
           amountdue = 0;
           $('#amount_due').val(amountdue);
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
        amountpayed += cashAmt;
        amountpay= cashAmt;
        //alert(change);
         if (amountdue <= 0 && change==0) {
            $('#finishReceipt').prop("disabled", false);
        } else {
            $('#finishReceipt').prop("disabled", true);
        }
         tg_overpay();
       
        e.preventDefault();
    });
       $("#csh_proc_cr_edit").submit(function (e) {
        var cashAmt = parseInt(totalcre);
       //alert(cashAmt);
        var change;
        amountdue = amountdue - cashAmt;
        var ledger = $('input[name=ledgerId]').val();
        //alert(ledger);
            $('#ledgerRow'+ledger).show();
            $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
            var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" name="amount'+ledger+'" value="'+ cashAmt +'"><input type="hidden" id="credit'+ledger+'" name="credit'+ledger+'" value="'+ cashAmt +'">';
            $('#legerRata'+ledger).append(data);
        if(amountdue >= 0){
            $('#change_row').hide();
           $('#amount_due').val(amountdue.toLocaleString()); 
        }else{
           change = amountdue * -1;
           amountdue = 0;
           $('#amount_due').val(amountdue);
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
        amountpayed += cashAmt;
        amountpay= cashAmt;
        AmtCalcCR();
        tg_cashNote();
       
        e.preventDefault();
    });
         function AmtCalcDeposit_edit() {
       var needed=0;
      // alert(amountdue);
        totalod = 0;
        totaldep = 0;
        var i=0;
        for (var j in deposit_list) {
          totalod += parseInt($('#amounttopayDeposit' + deposit_list[j]).val());

        }
       // alert(totalod);
        for (var j in deposit_list) {
           var due=$('#deposit_due' + deposit_list[j]).val(); 
           var amr=$('#amounttopayDeposit' + deposit_list[j]).val();
           // alert(due+'/'+amr);
         if((due-amr)<0 || (amountdue-totalod)<0){
            i=1;
            var myVariable = parseInt($('#amounttopayDeposit' + deposit_list[j]).val()); 
            // alert(myVariable.substring(0, myVariable.length - 1)); 
            myVariable = Number(String(myVariable).slice(0, -1));
            console.log(myVariable);
            
            $('#amounttopayDeposit' + deposit_list[j]).val(myVariable);
            totaldep += parseInt($('#amounttopayDeposit' + deposit_list[j]).val());
            if((amountdue-totalod)<0){
               swal('','Please Enter amount less or equal to '+amountdue.toLocaleString());
            }else{
               swal('','Please Enter amount less or equal to '+due.toLocaleString()); 
            }
            
        //alert(total);
              //continue;
              }else{
                i=0;
         totaldep += parseInt($('#amounttopayDeposit' + deposit_list[j]).val());

         //needed=parseInt($('#amounttopay' + item_list[j]).val());
              } 
             
        }
         $('#deposit_calc').html(totaldep.toLocaleString());
        }

          $("#csh_proc_deposit_edit").submit(function (e) {
        var cashAmt = parseInt(totaldep);
       // alert(cashAmt);
         depositpayed=depositpayed-cashAmt;
         amountdue = amountdue - cashAmt;
         //change=change-cashAmt;
          //$('#over_show').val(overpayed.toLocaleString());
         // $('#payover').val(overpayed.toLocaleString());

           var ledger = 23;
          //alert(ledger);
          //alert(amountdue);
             $('#ledgerRow'+ledger).show();
             $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
             var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" name="amount'+ledger+'" value="'+ cashAmt +'"><input type="hidden" id="deposit'+ledger+'" name="deposit'+ledger+'" value="'+ cashAmt +'">';
             $('#legerRata'+ledger).append(data);
        if(amountdue >= 0){
            $('#change_row').hide();
           $('#amount_due').val(amountdue.toLocaleString()); 
        }else{
           change = amountdue * -1;
           amountdue = 0;
           $('#amount_due').val(amountdue);
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
        amountpayed += cashAmt;
        amountpay= cashAmt;
        //alert(change);
         if (amountdue <= 0 && change==0) {
            $('#finishReceipt').prop("disabled", false);
        } else {
            $('#finishReceipt').prop("disabled", true);
        }
         tg_deposit();
       
        e.preventDefault();
    });
    
    function dateChanged(id){
            var dt=$('#receipt_date').val();
            var data = 'date=' + dt+'&id=' + id;
            $.ajax({
                type: "GET",
                url: '<?php echo base_url() . '/index.php/AdmissionController/changeReceiptDate'; ?>',
                data:data,
                success: function (result) {
                  toastr.success('date changed to '+dt);
                },
                error: function () {
                   toastr.error('Sorry!, Something went wrong!','error'); 
               }
      });
            
          }
</script>


