<?php
  $bmodel = new App\Models\BillingModel();
  $cmodel = new App\Models\ClassesModel();
  $appItems = $cmodel->get_applications_items();
  $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$trans[0]->trans_number,'trans_type'=>6));
  $ref = $bmodel->get_item_name('payment_request', $where = array('trans_no' => $trans[0]->trans_number, 'student_id' =>$leger_transaction[0]->name_id));
  $student_name = "";
  $name_type = "";
  $source = "";
  $ref="";
  $adm_id ="";
  $hst="";
  $trns="";
    if(count($leger_transaction) > 0){
        $amount = $leger_transaction[0]->amount;
        if($leger_transaction[0]->name_type_id == 4){
            $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
            $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
            $name_type = $type_name[0]->name_type;     
        }else if($leger_transaction[0]->name_type_id == 1){
            $admn = $bmodel->get_item_name('students', $where = array('id'=>$leger_transaction[0]->name_id));
            $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name; 

            $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $leger_transaction[0]->name_id, 'status' => 1));
            if(count($admissn) > 0){
                $adm_id = $admissn[0]->class_id;
                $hst = $admissn[0]->admission_type;
                $trns = $admissn[0]->vehicle_id;
            }
            $class = $bmodel->get_item_name('classes_tbl', $where = array('id' => $adm_id));
            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
            $name_type = $type_name[0]->name_type;
            $installment = $bmodel->get_item_name('installments_tbl', $where = array('tbl_id' => $adm_id));
            $pay = $bmodel->get_item_name('payment_request',$where = array('student_id' => $admn[0]->id));
             if(count($pay) > 0){
                $ref = $pay[0]->reference_no;
            }
            $logo = $bmodel->get_table_details('company_tbl');
            if($logo[0]->logo_name != ""){
               $source =  base_url('public/company_photos/'.$logo[0]->logo_name);
            }
        }
    }
?>
<div class="row">
    <div class="col-md-12">
        <center>
            
            <div class="mt-3"><img src="<?php echo $source; ?>"  style="background: white;width: 25%;height: 25%"></div></br>
            <span class="mt-4"><b><?= $logo[0]->logo_name; ?></b></span><br>
            <span>Address</span>
            <div class="mb-3">
                <div><span><b>Website:</b> <?= $logo[0]->website; ?></span></div>
                <div><span><b>Email:</b> <?= $logo[0]->email; ?></span></div>
                <div><span><b>Tin:</b> <?= $logo[0]->tin; ?></span></div>
                <div><span><b>Vat:</b> <?= $logo[0]->vat; ?></span></div>
            </div>
          <h3><b>CREDIT NOTE</b></h3>
        </center>
        <table class="table table-condensed">
            <tr>
                <th align="start">Note Number:</th>
                <td><?= $trans[0]->trans_number; ?></td>
            </tr>
            <tr>
                <th style="text-align: left;">Note Date:</th>
                <td><?= $trans[0]->trans_date; ?></td>
            </tr>
            <tr>
                <th style="text-align: left;">Customer Type:</th>
                <td><?= $name_type; ?></t style="text-align: left;"d>
            </tr>
            <br>
            <tr>
                <th style="text-align: left;">Student Name:</th>
                <td><?= $student_name; ?></td>
            </tr>
            <tr>
                <th style="text-align: left;">Student Class</th>
                <td><?= count($class) > 0? $class[0]->class_name:''; ?></td>
            </tr>
            <tr>
                <th style="text-align: left;">Reg No:</th>
                <td><?= $admn[0]->student_id; ?></td>
            </tr>
            <tr>
                <th style="text-align: left;">Admission No:</th>
                <td><?= count($admissn) > 0?$admissn[0]->id:''; ?></td>
            </tr>
        </table>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <p>NOTED ITEMS</p>
        <table class="table table-condensed" width="80%">
            <thead> 
                <tr>
                    <th>Item</th>
                    <th>Item Name</th>
                    <th  style="text-align:right">Qty</th>
                    <th  style="text-align:right">Price</th>
                    <th  style="text-align:right">Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $student_id=$admn[0]->id;
                     $dbname=session()->get('db_name');
                    $db = \Config\Database::connect($dbname);
                    $total =0;
                    $amount = 0;
                    $uniform=0;
                    $tea=0;
                    $lunch=0;
                    $query = $db->query('SELECT item_id,item_name,trans_number,quantity,unit_price FROM item_transation_tbl,items_tbl where item_transation_tbl.item_id = items_tbl.id AND trans_type=6 AND trans_number='.$trans[0]->trans_number);
                    $result = $query->getResult();

                    foreach($result as $itm){
                         $query2 = $db->query('SELECT amount FROM ledger_transaction_tbl where (ledger_type = 3 OR ledger_type = 4) AND trans_type=6 AND trans_no='.$trans[0]->trans_number);
                         $result2 = $query2->getResult();

                         $amount = $itm->quantity * $itm->unit_price;
                        if($itm->item_id==64){
                        $total -= $amount;
                          }else{
                            $total += $amount;
                          }
                        if($itm->item_id==22 || $itm->item_id==23 || $itm->item_id==24|| $itm->item_id==55){
                            $uniform=$amount; 
                        }
                          if($itm->item_id==38 || $itm->item_id==39 || $itm->item_id==40){
                            $tea=$tea+$amount; 
                             if($itm->item_id==39 || $itm->item_id==40){
                                $lunch=$amount;
                            }
                        }

                ?>
                    <tr>
                     <td><?= $itm->item_id; ?></td>
                     <td><?= $itm->item_name; ?></td>
                     <td align="right"><?= $itm->quantity; ?></td>
                     <td align="right"><?= number_format($itm->unit_price); ?></td>
                     <td align="right"><?= number_format($amount); ?></td>
                 </tr>
            <?php } ?>
                    <tr align="center">
                         <td><b>TOTAL</b></td>

                         <td colspan="3"></td>

                        <td colspan="3" align="right"><b><?php echo number_format($total); ?></b></td>
                    </tr>
            </tbody>
        </table>
      
    </div>
    <center><div class="mt-4"><i><b>Powered by Micro Health Initiative</i></b></div></center>
</div>