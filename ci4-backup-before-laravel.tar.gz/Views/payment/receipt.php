
<?php
   $bmodel = new App\Models\BillingModel();
   $ctype= $bmodel->get_table_details('name_type_tbl');

   // $studentId = isset($_GET['id'])?$_GET['id']:''; 
//$url = 'https://support.advaensure.co.tz/article/2-How-To-Setup-NHIF-Signatures';
//echo file_get_contents($url);
?>
<style type="text/css">
    .btn-title {
            position: relative;
            display: inline-block;
            cursor: pointer;
            color: white;
        }
        .btn-title::before {
            content: attr(title);
            color: white;
            position: absolute;
            top: -20px; /* Adjust the distance as needed */
            left: 83%;
            transform: translateX(-50%);
            background-color: red;
            padding: 7px 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            display: block; /* Always display the title */
        }

    .help-icon {
    display: inline-block;
    position: relative;
    font-size: 13px; /* Adjust the size as needed */
    vertical-align: super;
    line-height: 1;
}

.icon1 {
    display: inline-block;
    width: 20px;
    height: 20px;
    background-color: #00BFFF;
    color: white;
    border-radius: 50%;
    text-align: center;
    line-height: 20px;
    font-size: 14px;
    font-weight: bold;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Hover effect */
.icon1:hover {
    background-color: #2980b9;
}
.icon2 {
    display: inline-block;
    width: 20px;
    height: 20px;
    background-color: #00BFFF;
    color: white;
    border-radius: 50%;
    text-align: center;
    line-height: 20px;
    font-size: 10px;
    font-weight: bold;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Hover effect */
.icon2:hover {
    background-color: #2980b9;
}
  .cust_popup {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            display: none;
        }

</style>

<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Billing</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                        <?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
                    </a></li>
                    <li class="breadcrumb-item active" aria-current="page">Receipts</li>
                    <li class="help-icon">
                    <a href="#" onclick="tg_help()" style="margin-left:8px"><span class="icon1">?</span></a>
                   </li>
                </ol>

            </div>
           <div id="largeScreenTab">
            <ul class="nav nav-tabs page-header-tab">

           <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#rcpt-all">Receipts List</a></li>
           <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#rcpt-reves">Reversal list</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#rcpt-add">New Receipt</a></li>
                </ul>
             </div>

             <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
           <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#rcpt-all">Receipts List</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#rcpt-add"></a></li>
                  <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#rcpt-add"></a></li>
                    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#rcpt-add">New Receipt</a></li>
            </ul>
             </div>
             <!--</div>-->
        </div>
    </div>
</div><br>

      <!----------------------------------------------------------------------------->
        

<div class="section-body mt-4">
<div class="container-fluid">
<div class="tab-content">
<div class="tab-pane active" id="rcpt-all">
<div class="d-flex justify-content-center">
<div id="messageDisplayArea"></div>
<form id="Rept1Result" class="form-inline">
Receipt date:
<div class="input-group ms-3 me-3">
<button type="button" class="btn btn-default pull-right daterange-btn" id="daterange-btn">
    <span>
        <i class="fa fa-calendar"></i> Please Select Date
    </span>
    <i class="fa fa-caret-down"></i>
</button>
</div>
<!--   Resdent: 
<select class="form-control form-select" name="res" id="res">
<option value="0">All</option>
<option value="Boarding">Boarding</option>
<option value="Day">Day</option>
<?php
//  $res = $remodel->get_resdent();
// foreach($res as $re){
//  echo '<option value="' . $re->admission_type . '">' . $re->admission_type . '</option>'; 
// }

?>
</select> -->
<button type="submit" class="btn btn-primary">Create</button>
<a href="#" class="btn btn-secondary ms-3" onclick="export_receipt()">Export</a>
<div class="input-group ms-3">

<input type="text" class="form-control" name="payer_name" id="search_name"   placeholder="Search Student Name" aria-label="Student Name" aria-describedby="button-st">
<button class="btn btn-outline-success" type="button" id="button-y">
<span>
<i class="fa fa-calendar" aria-hidden="true"></i>
</span></button>
<button class="btn btn-outline-primary" type="button" id="button-st" onclick="searchnamebtn()"><i class="fa fa-search" aria-hidden="true"></i></button>
</div>

</form>

</div>

<hr>
&nbsp;<p></p>
<center>
<div id="receipt"></div>
</center>
</div>
<!--reverse pannel --->
<div class="tab-pane" id="rcpt-reves">
<div class="d-flex justify-content-center">
<div id="messageDisplayArea2"></div>
<form id="Rept1ResultReves" class="form-inline">
Reverse date:
<div class="input-group ms-3 me-3">
<button type="button" class="btn btn-default pull-right" id="daterange-btn-revese">
    <span>
        <i class="fa fa-calendar"></i> Please Select Date
    </span>
    <i class="fa fa-caret-down"></i>
</button>
</div>

<button type="submit" class="btn btn-primary">Create</button>

</form>

</div>

<hr>
&nbsp;<p></p>
<center>
<div id="receipt_revese"></div>
</center>
</div>
<!--   <center>
<button class="btn btn-primary btn-sm" onclick="printable('Rept1ResultViewResults')"><span class="fa fa-print"></span> Print</button>
</center> -->

<!--------------------------code placed here--------------------------------------------------->


<div class="tab-pane" id="rcpt-add">
<div class="row clearfix">
<div class="col-lg-12 col-md-12 col-sm-12">
<div class="card">
<div class="card-header mt-1"  style="height:5px">
    <h3 class="card-title">New Receipt <?php //echo "this is new receipt" . $_GET['id'];?></h3>
    <div class="card-options ">
        <button class="btn" onclick="resetReceiptData()"><i class="fa fa-refresh"></i> </button>
        <!-- <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a> -->
    </div>
</div>
    <hr>
<div class="card-body" id="receiptData">
       <form id="receipt_details">
    <div class="row">
     
        <div class="col-md-6">
        <?php
             $cfctn = $bmodel->get_item_name('company_tbl',$where = array('classification' => 1));
              $ctype= $bmodel->get_table_details('classification_tbl');
              if(count($cfctn)>0){
                      ?>
            <div class="form-group row">
                 
                <label for="inputpaidBy" class="col-sm-4 col-form-label">Class Type<span class="text-danger">*</span></label>
                <div class="col-sm-8">
                  
                    <select class="form-control" name="class_type" id="class_type" required>
                        <option value="">Select Class Type</option>
                        <?php foreach($ctype as $type): ?>
                        <option value="<?= $type->id ?>"><?= $type->class_name; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

              </div>
               <?php
                 }
                ?>
          <div class="form-group row">
                <label for="inputpaidBy" class="col-sm-4 col-form-label">Receipt Type<span class="text-danger">*</span></label>
                <div class="col-sm-8">
                   <select class="form-control" name="receipt_type" id="receipt_type">
                       
                <option value="1">Invoice Receipt</option>
                <option value="2">Sales Receipt</option>
                    </select>
                </div>
              </div> 
             
             <?php
         $bank_acc = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 9));

             ?>
            <!--     <div class="form-group row" id="bank_select" style="display:none;">
                <label for="inputpaidBy" class="col-sm-4 col-form-label">Bank<span class="text-danger">*</span></label>
                <div class="col-sm-8">
            <select class="form-control" name="bank_type" id="bank_type">
                       
                <option value="0">-Select-</option>
                <?php 
           foreach($bank_acc as $b){
                ?>
                <option value="<?=$b->id;?>"><?= $b->account_name;?></option>
            <?php }?>
                    </select>
                </div>
              </div>  -->

            <div class="form-group row">
                <label for="inputpaidBy" class="col-sm-4 col-form-label">Receipt Date</label>
                <div class="col-sm-8">
                  <input type="date" id="receipt_date" name="receipt_date" value="<?php echo date('Y-m-d');?>" max="<?php echo date('Y-m-d');?>" class="form-control">
                </div>
              </div>
          

              <div class="form-group row" id="payer_name_row" style="display:none;">
                <label for="payerame" class="col-sm-4 col-form-label">Payer Name<span class="text-danger">*</span></label>
                <div class="col-sm-8">
                    <div class="input-group mb-3">
                        <input type="hidden" id="payer_id" name="payer_id" value="">
                        <input type="text" class="form-control" name="payer_name" id="payer_name"   placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2">
                        <button class="btn btn-outline-primary" type="button" id="button-addon2" onclick="search_payer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                    </div>
                </div>
              </div>
              <div id="payer_details"></div>
             <div class="form-group row">
                <label for="inputpaidBy" class="col-sm-4 col-form-label">Customer Type<span class="text-danger">*</span></label>
                <div class="col-sm-8">
                   <?php
                        $ctype= $bmodel->get_table_details('name_type_tbl');
                      ?>
                    <select class="form-control" name="customer_type" id="customer_type">
                        <option value="">Select Customer Type</option>
                        <?php foreach($ctype as $type): ?>
                        <option value="<?= $type->id ?>"><?= $type->name_type; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
              </div>
              <div class="form-group row" id="select_invoice" style="display:none;">
                <label for="payerame" class="col-sm-4 col-form-label">Select Invoice<span class="text-danger">*</span></label>
                <div class="col-sm-8">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="customer_name or Id"  id="customer_name" placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2">
                        <button class="btn btn-outline-primary" type="button" id="button-addon2" onclick="search_customer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                    </div>
                </div>
              </div>
            <!--------------------show credit note-------------------------->
              <div class="form-group row" id="ttlCredit" style="display:none;">
                    <label for="staticEmail" class="col-sm-4 col-form-label text-green">Total Credit Note</label>
                    <div class="col-sm-8">
                      <input type="text" readonly class="form-control-plaintext text-green" id="credited" value="0">
                    </div>
                   <!--  <div class="col-sm-1">
                    </div>  -->  
                  </div>
            <!---------------------------------------------->
     <!---show Over payment--------->
              <div class="form-group row" id="payedOver" style="display:none;">
                    <label for="staticEmail" class="col-sm-4 col-form-label text-green">Total Over payment</label>
                    <div class="col-sm-8">
                      <input type="text" readonly class="form-control-plaintext text-green" id="payover" value="0">
                    </div>
                   <!--  <div class="col-sm-1">
                    </div>  -->  
                  </div>
            <!---------------------------->
        </div>   
        <div class="col-md-6">
           <div id="customer_loaded"></div> 
           <div id="Name_loaded"></div>
           <div id="Invoice_loaded"></div>
       
    </div>
     </div>
        </form>
   <!--   <div class="row">
         <div class="col-md-12">
             
             <br>
         </div>
     </div>  -->
    
  
    <hr>
    <div id="charged_item_lists" style="display:none;"></div>
    <div class="row">
        <div class="col-md-12">
            
            <form id="receipt_form">
                <div id="applicationlist" style="display:none;">
                 <h6>Application List</h6>
                <table class="table" >
                <thead>
                    <tr>
                        <th>Student Id</th>
                        <th>Student Name</th>
                        <th>Item Name</th>
                        <th>Quantity</th>
                        <th>Amount Due</th>
                        <th>Amount To Pay</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="itm_invoice1">
                </tbody>
            </table>
            </div>
            <div  class="cust_popup" id="other_rec_popup" style="display: none;margin-left: 130px;">
              <div id="display_receipt">
                  
              </div>
              </div>
            <div id="invoicelist">
                <h6>Invoice List</h6>
            <table class="table table-borderless" >
                <thead>
                    <tr>
                        <th>Select</th>
                        <th>Invoice type</th>
                        <th>Invoice No</th>
                        <th>Invoice Date</th>
                        <th>Invoice Name</th>
                        <th>Invoice Amount</th>
                        <th>Amount Due</th>
                        <th>Amount To Pay</th>
                    </tr>
                </thead>
                <tbody id="itm_invoice">
                </tbody>
                <tfoot>
                    <tr id="itm_invoicefooter"></tr>
                </tfoot>
            </table>
            </div>
            </form>    
        </div>
    </div>
   
    <!-- <div class="row mt-4"> -->
    <?php
        $acc = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 9));
           $accoo = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 9));
        $account = $bmodel->get_item_name('accounts_tbl', $where = array('account_type_id' => 7));
        $current = $bmodel->get_item_name('accounts_tbl', $where = array('id' => 21));
        $credit = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('id' => 21));
    ?>

    <div class="cust_popup" id="account" style="display: none">
        <form method="POST" id="acct_proc">
            <b>CHARGE ACCOUNT</b><i style="color: red" id="saveError"></i><br/>
            ACCOUNT NAME
            <input class="form-control" id="acc_name" type="text" onkeyup="SearchAccount()" autocomplete="off">
            <input id="acc_no" type="hidden">
            <div id="schResults"></div>
            <br>
            AMOUNT
            <input class="form-control" id="acc_amt" type="number" autocomplete="off"><br>
            <button type="submit" id="svAccnt" class="btn btn-primary pull-right">Save</button>&nbsp;
        </form>
        <button class="btn btn-warning" style="display:none" id="removeAcct">Remove Account</button>
        <button class="btn btn-warning" onclick="tg_acct()">Cancel</button>
    </div>
    <!------------------------------------------------------------------>
     
 
    <div  class="cust_popup" id="cash" style="display: none">
        <h6>Receive Cash</h6>
         <form id="csh_proc" method="POST">
             <select class="form-control" name="ledger" id="ledger" required="">
                 <option value="">Select ledger</option>
                <?php foreach($acc as $ac):?>
                     <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                 <?php endforeach; ?>
             </select><br>
             <input class="form-control" name="cash_amt" id="cash_amt" type="number" required="" ><br>
             <button class="btn btn-warning" onclick="close_Popup()">Cancel</button>
             <button type="submit" class="btn btn-primary pull-right">Save</button>&nbsp;
         </form>
       <button class="btn btn-sm btn-warning" style="display:none" id="removeCash">Remove Cash</button>&nbsp;
   </div>
      <!-------credit note popup------------------------------------------>
    <div  class="cust_popup" id="cash_credit" style="display: none; width: 600px;">
        <h6 class="text-center">AVAILABLE CREDIT NOTE LIST
          <li class="help-icon">
        <a href="#" onclick="tg_help()" style="margin-left:8px"><span class="icon1">?</span></a>
       </li>
        </h6><br>
  <form id="csh_proc_cr" method="POST" autocomplete="off">
          
             <!-------------------------------------------------------->

          <table class="table" >
                <thead>
                    <tr>
                      
                        <th>Type</th>
                        <th>Note No</th>
                        <th>Credit Amount</th>
                        <th>Credit Bal</th>
                        <th>Use</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="choose_credit">
                </tbody>
                <tfoot class="border-less">
                    <tr id="itm_creditfooter"></tr>
                </tfoot>
            </table>
             <!-------------------------------------------------------->
             <!-- <input class="form-control" name="cash_amt_cr" id="cash_amt_cr" type="number" required="" ><br> -->
             <button class="btn btn-warning" onclick="closePopup()">Cancel</button>
             <button type="submit" class="btn btn-primary pull-right" id="savec">Save</button>&nbsp;
         </form>
       <button class="btn btn-sm btn-warning" style="display:none" id="removeCash">Remove Cash</button>&nbsp;
   </div>   
      <!-----------------------end popup--------------------------------------------> 

        <!-------Over payment popup------------------------------------------>
<div  class="cust_popup" id="cash_over" style="display: none;width: 500px;">
       <h6 class="text-center">OVERPAYMENT LIST
<li class="help-icon">
<a href="#" onclick="tg_help()" style="margin-left:8px"><span class="icon1">?</span></a>
</li></h6><br>
         <form id="csh_proc_over" method="POST" autocomplete="off">
             <table class="table" >
                <thead>
                    <tr>
                       <th>Type</th>
                       <th>Trans No</th>
                       <th>OverPayment</th>
                        <th>Balance</th>
                        <th>Use</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="choose_over">
                </tbody>
                <tfoot class="border-less">
                    <tr id="itm_overfooter"></tr>
                </tfoot>
            </table>
            <br>
            <button class="btn btn-warning" onclick="closePopup_over()">Cancel</button>
             <button type="submit" class="btn btn-primary pull-right" id="saveo">Save</button>&nbsp;
         </form>
       <!-- <button class="btn btn-sm btn-warning" style="display:none" id="remo veCash">Remove Cash</button>&nbsp; -->
   </div>  

      <!-----------------------end over popup--------------------------------------------> 

           <!-----------------------end popup--------------------------------------------> 

<!------deposit usepopup------------------------------------------>
<div  class="cust_popup" id="deposit_popup" style="display: none;width: 500px;">
       <h6 class="text-center">DEPOSIT LIST
<li class="help-icon">
<a href="#" onclick="tg_help()" style="margin-left:8px"><span class="icon1">?</span></a>
</li></h6><br>
         <form id="csh_proc_deposit" method="POST" autocomplete="off">
             <table class="table" >
                <thead>
                    <tr>
                      
                       <th>Deposit No</th>
                       <th>Amount</th>
                        <th>Balance</th>
                        <th>Use</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="choose_deposit">
                </tbody>
                <tfoot class="border-less">
                    <tr id="itm_depositfooter"></tr>
                </tfoot>
            </table>
            <br>
            <button class="btn btn-warning" onclick="closePopup_deposit()">Cancel</button>
             <button type="submit" class="btn btn-primary pull-right" id="saved">Save</button>&nbsp;
         </form>
       <!-- <button class="btn btn-sm btn-warning" style="display:none" id="remo veCash">Remove Cash</button>&nbsp; -->
   </div>  

      <!-----------------------end over popup-------------------------------------------->
      
    <hr>
    <div class="row" id="btn_list">
       
<div class="col-md-12">
<form id="payment_panel">

<?php foreach($accoo as $ap):?>
<div class="form-group row" id="ledgerRow<?= $ap->id?>" style="display: none;" >
<label for="staticEmail" class="col-sm-1 col-form-label"><?= $ap->id; ?> </label>
<label for="staticEmail" class="col-sm-3  col-form-label"><?= $ap->account_name; ?> Ledger</label>
<div class="offset-md-6 col-sm-1">
<input type="text" readonly class="form-control-plaintext" id="ledger_payed<?= $ap->id?>" value="900">
</div>
<div class="col-sm-1">
<div id="legerRata<?= $ap->id?>">
</div>    
<label style="margin-top: 10px;"><i  onclick="removePayment('<?= $ap->id?>')" class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="delete"></i></label>
</div>   
</div>
<?php endforeach; ?>

<!---------------------------credit row start here------------------------------>
<?php foreach($account as $ap):?>
<div class="form-group row" id="ledgerRow<?= $ap->id?>" style="display: none;" >
<label for="staticEmail" class="col-sm-1 col-form-label"><?= $ap->id; ?> </label>
<label for="staticEmail" class="col-sm-3  col-form-label"><?= $ap->account_name; ?> Ledger</label>
<div class="offset-md-6 col-sm-1">
<input type="text" readonly class="form-control-plaintext" id="ledger_payed<?= $ap->id?>" value="900">
</div>
<div class="col-sm-1">
<div id="legerRata<?= $ap->id?>">
</div>    
<label style="margin-top: 10px;"><i  onclick="removePayment('<?= $ap->id?>')" class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="delete"></i></label>
</div>   
</div>
<?php endforeach; ?>
<!------------------------------credit row end here---------------------------->
                 <!--   <div class="form-group row" id="ttlCredit" style="display:none;">
                    <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label">Total Credit Note</label>
                    <div class="offset-md-6 col-sm-1">
                      <input type="text" readonly class="form-control-plaintext" id="credited" value="0">
                    </div>
                    <div class="col-sm-1">
                    </div>   
                  </div> -->
                 <div class="form-group row"  >
                    <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label">Amount Due</label>
                    <div class="offset-md-6 col-sm-1">
                      <input type="text" readonly class="form-control-plaintext" id="amount_due" value="0">
                    </div>
                    <div class="col-sm-1">
                    </div>   
                  </div>
                <div class="form-group row" style="display: none;" id="change_row">
                    <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label text-danger">Over Payment</label>
                    <div class="offset-md-6 col-sm-1 text-danger">
                      <input type="text" readonly class="form-control-plaintext text-danger" id="amount_change" value="">
                    </div>
                    <div class="col-sm-1">
                    </div>   
                  </div>
              <!--   <table class="table">
                    <tr>
                        <th>Total</th>
                        <th id="receipt_calc"></th>
                         <th></th>
                    </tr> 
                    
                        <tr>
                        <th>Amount Payed</th>
                        <th id="amount_payed"></th>
                    </tr>     
                    <tr>
                        <th colspan="8">Amount Due</th>
                        <th id="amount_due"></th>
                         <th></th>
                    </tr>     
                    <tr style="display: none;" id="change_row">
                        <th colspan="6">Change</th>
                        <th id="amount_change"></th>
                         <th></th>
                    </tr>     
                </table> -->
            </form>       
        </div>
        <div class="col-md-2">
             <button type="button" class="btn btn-primary pull-left" onclick="tg_cash()" id="addPayment"> Add Payment</button>
         </div>
  
  <!----credit note button--------------------------------->
         <div class="col-md-2" id="seen1">
             <button type="button" class="btn btn-primary pull-left" id="another" onclick="tg_cashNote()"> Use Credit Note</button>
         </div>

    <div class="col-md-2" id="new1">
    <button type="button" class="btn btn-primary pull-left btn-title"  onclick="tg_notification(1)" title="New">
       Use Credit Note
    </button>
    </div>
<!----credit note button---end------------------------------>
<!----start use Over Payment btn------------------------------>

        <div class="col-md-2" id="seen2">
             <button type="button" class="btn btn-primary pull-left" id="over-btn" onclick="tg_overpay()"> Use Over Payment</button>
        </div>
         
    <div class="col-md-2" id="new2">
    <button type="button" class="btn btn-primary pull-left btn-title"  onclick="tg_notification(2)" title="New">
        Use Over Payment
    </button>
    </div>
<!----end use Over Payment btn------------------------------>
<!------below is deposit btn--------------->
          <div class="col-md-2" id="deposit_use">
             <button type="button" class="btn btn-success pull-left" id="deposit-btn" onclick="tg_deposit()"> Use Deposit</button>
        </div>
<!------above is deposit btn--------------->
<!------below is other rct btn--------------->
          <div class="col-md-3" id="use_receipt">
             <button type="button" class="btn btn-primary pull-left" id="other_receipt" onclick="otherReceipt()">  Reverse Other Receipt</button>
        </div>
<!------above is other rct btn--------------->
    </div> 
</div>

<div class="card-footer">
   
    <button type="button" id="finishReceipt" class="btn btn-primary pull-right" onclick="finish_receipt()">Finish</button>

    <button type="button" id="finishReceipt2" class="btn btn-primary pull-right" style="display: none;" onclick="finish_receipt2()">Finish</button>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
            
        </div>
        <form id="new_new">
            <input type="hidden" name="update[]" value="1">
            <input type="hidden" name="update[]" value="2">
            
        </form>
<?php for($i=1;$i<=2;$i++){ ?>
 <div class="modal fade" id="viewnotification<?=$i ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
      </div>
      <div class="modal-body" id="notification_content<?=$i ?>">
        
      
      </div>
      <div class="modal-footer">
         <button type="button" class="btn btn-secondary" onclick="read_later(<?=$i ?>)">Read Later</button>
        <button type="button" class="btn btn-primary" onclick="gotoit(<?=$i ?>)">Got it!</button>
          
      </div>
    </div>
  </div>
</div>
<?php } ?>

<div class="modal fade" id="view_help" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
     <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div id="loading_spinner">
            <center><b><span class="fa fa-spin fa-spinner"></span> Loading...</b></center>
        </div>
        <iframe id="help_frame" src="" style="height: 750px;"></iframe>
    </div>
  </div>
</div>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!---------------------------------------------------------------------------->
<div class="modal fade" id="overPayment" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
     <!--  <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div> -->
      <div class="modal-body" id="over_content">
        <form id="over_form" method="POST">
        <label for="staticEmail" class="col-sm-5 col-form-label"><span id="over"></span> is over payment</label>    
         <select class="form-control form-select" name="over_pay" id="over_pay" required="">
             <option value="">Select acount</option>
            <?php foreach($current as $acc):?>
                 <option value="<?= $acc->id; ?>"><?= $acc->account_name; ?></option>
             <?php endforeach; ?>
         </select><br>
         <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary pull-right">Save</button>&nbsp;
     </form>
      </div>
      <div class="modal-footer">
        
          <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="edit_rept()"><i class="fa fa-print"></i> Edit</button> -->
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="viewreceipt2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content2">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="close_rept()">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept2('viewreceipt_content2')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="viewreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="close_rept()">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('viewreceipt_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade bd-example-modal-sm" id="recptHist" tabindex="-1" data-keyboard="false" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
              
            </div>
            <div class="modal-body">
                <div id="recptHistDetails"></div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    var allvariables = "";
    var total=0;
    var amountdue =0;
    var amountpayed =0;
    var amountpay =0;
    var item_list = [];
    var credit_list = [];
    var over_list = [];
    var deposit_list = [];
    var k =0;
    var totalinv = 0;
    var totalnote=0;
    var overpayed=0;
    var depositpayed=0;
    var change=0;
    var unit_price=0;
    var c=0;
    var ov=0;
    var od=0;
    var totalcre = 0;
    var totalovp = 0;
    resetReceiptData();

    $(function () {
        const currentYear = new Date().getFullYear();  
         $('#button-y').yearpicker({
            year:currentYear,
           startYear:2022,
           endYear:currentYear+1,
      
         });
        
          });
          $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
              });

    $('#finishReceipt').prop("disabled", true);
      load_notification();

    //loading new updates modal contents
 $(document).ready(function () {
        // Function to update modal content
        function updateModalContent(modalIndex, newContent) {
            $('#notification_content' + modalIndex).html(newContent);

      }

        <?php for($i=1; $i<=2; $i++) { ?>
        $('#viewnotification<?=$i ?>').on('show.bs.modal', function () {
            // Fetch content using AJAX
            $.ajax({
             url: '<?php echo base_url() . '/index.php/SystemController/load_modal_content/'.$i; ?>',
               // url: 'path_to_your_controller/load_modal_content/<?=$i ?>',
                type: 'GET',
                success: function (data) {
                    updateModalContent(<?=$i ?>, data);
                }
            });
        });
        <?php } ?>
    });



    function load_notification(){
      
          var data =$('#new_new').serialize()+'&'+$("#header_form").serialize();
        //alert(data);
         $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/SystemController/load_new'; ?>',
                data: data,
                dataType: "json", 
                success: function (result) {
                  var len  = result.length;

                   for (var i = 0; i <len; i++ ){
                       var seen = result[i]['seen'];
                       var not = result[i]['update'];
                        if(seen==1){
                         $('#seen'+not+'').show();
                         $('#new'+not+'').hide();  
                        }else{
                         $('#new'+not+'').show();
                          $('#seen'+not+'').hide();    
                        }
                   } 
                },
                error: function () {
                    alert('Sorry Something went wrong');
                }
            });
        }

    function tg_notification(n){
        $('#viewnotification'+n).modal('show'); 
      //$('#viewreceipt_content').load('view_receipt/'+inv);
    }

    function tg_help() {
    $('#help_frame').attr('src', '');
    $('#loading_spinner').show(); // Show the loading spinner
    $('#view_help').modal('show');
    $('#help_frame').on('load', function() {
        $('#loading_spinner').hide(); // Hide the loading spinner once the content is loaded
    });
    $('#help_frame').attr('src', 'https://elcosupport.advaensure.co.tz/');
}
function new_gotoit(j){
     $('#seen'+j).show();
     $('#new'+j).hide();
      $('#viewnotification'+j).modal('hide');
     var update = updates[j-1]; 
      //alert(update);
      showMessage(update);
}

function read_later(id){
    $('#seen'+id+'').show();
     $('#new'+id+'').hide();
      $('#viewnotification'+id).modal('hide');
}

function gotoit(id){
    https://support.advaensure.co.tz/article/2-How-To-Setup-NHIF-Signatures
    var data ='not='+id+'&'+$("#header_form").serialize();
         //alert(data);
         $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/SystemController/load_seen'; ?>',
                data: data,
                success: function (result) {
                  
                         $('#seen'+id+'').show();
                         $('#new'+id+'').hide();
                          $('#viewnotification'+id).modal('hide'); 
                },
                error: function () {
                   alert('Sorry Something went wrong');
               }
            });
}
    function manage_receipt(inv){
        //alert(inv);
      $('#viewreceipt').modal('show'); 
      $('#viewreceipt_content').load('view_receipt/'+inv);
    }
    function manage_receipt2(inv){
        //alert(inv);
      $('#viewreceipt2').modal('show'); 
      $('#viewreceipt_content2').load('view_receipt/'+inv);
    }
     function manage_rec(inv){
        //alert(inv);
      $('#editreceipt').modal('show'); 
      $('#editreceipt_content').load('edit_receipt/'+inv);
    }
    function search_customer(){
       if($('#customer_type').val() == "") {
           swal("warning","Please Select Customer Type","warning");
       }else if($('#customer_name').val() == ""){
          swal("warning","Please Enter Customer Name","warning"); 
       }else{
            var paydata = 'type=' + $('#customer_type').val() + "&cust_name=" + $('#customer_name').val() + "&receipt_type=" + $('#receipt_type').val();
            //alert(paydata);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/search_customer'; ?>',
                beforeSend: function () {
                    $('#Name_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#Name_loaded').html(result); 
                },
                error: function () {
                    $('#Name_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
       
    }
    function student_select(id){
        var paydata = 'type=' + $('#customer_type').val()+'&id=' + id;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/loadInvoices'; ?>',
                beforeSend: function () {
                    $('#Invoice_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#Invoice_loaded').html(result); 
                },
                error: function () {
                    $('#Invoice_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
      });
    }
    function prepare_invoice(student_id){
         var paydata = 'type=' + $('#customer_type').val()+'&id=' + student_id;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/create_invoice'; ?>',
                data: paydata,
                success: function (result) {
                    $('#Invoice_loaded').html(''); 
                    var data = JSON.parse(result); 
                    var mydata= Object.keys(data).length;
                    if(mydata>0){
                    for( var i = 0; i < mydata; i++){
                        k++;
                        item_list.push(k);
                         unit_price = parseInt(data[i]['unit_price']);
                        total += unit_price;
                        amountdue = total - amountpayed;
                        var name_type = $('#customer_type').val() +'_'+ student_id;
                        var itm = '<tr><input type="hidden"  name="student[]"  value="'+name_type+'">'+
                                   '<td>' + data[i]['student_id']  +'</td>'+
                                   '<td><input type="hidden"  name="studentId'+name_type+'" value="'+student_id+'">' + data[i]['full_name']  +'</td>'+
                                   '<td><input type="hidden"  name="customerType'+name_type+'" value="'+$('#customer_type').val()+'">' + data[i]['item_name']  +'</td>'+
                                   '<td>' + data[i]['quantity']  +'</td>'+
                                   '<td>' + unit_price.toLocaleString()  +'</td>'+
                                   '<td><input type="number" class="form-control" id="amounttopay'+k+'"  value="'+data[i]['unit_price']+'" name="amount'+name_type+'" style="width:100px;" disabled></td>' +
                                   '</tr>';
                       $('#itm_invoice1').append(itm);
                       $('#receipt_calc').html(total.toLocaleString());
                       $('#amount_due').val(amountdue.toLocaleString());
                       $('#amount_due').css({"color": "red"});
                   }
                   }else{
                    
                   }
                },
                error: function () {
                    $('#itm_invoice').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
      });
    }
 
   function tg_cash() {
        $('#cash').toggle(100);
    }
     function tg_cashNote() {
        $('#cash_credit').toggle(100);
        $('#noted').val(totalnote.toLocaleString());
        $('#cash_amt_cr').val('');
    }
    function tg_overpay() {
        $('#cash_over').toggle(100);
        $('#over_show').val(overpayed.toLocaleString());
        $('#cash_amt_over').val('');
    }
     function tg_deposit() {
        $('#deposit_popup').toggle(100);
        $('#deposit_show').val(overpayed.toLocaleString());
        //$('#cash_amt_over').val('');
    }
    $("#csh_proc").submit(function (e) {
        var cashAmt = parseInt($('#cash_amt').val());
        //alert(cashAmt);
        // var change;
        amountdue = total - cashAmt;
      //  alert(total);
        var ledger = $('#ledger option:selected').val();
            $('#ledgerRow'+ledger).show();
            $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
            var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" name="amount'+ledger+'" value="'+ cashAmt +'"><input type="hidden" name="credit'+ledger+'" value="'+ 0 +'" id="credit'+ledger+'">';
            $('#legerRata'+ledger).append(data);
        if(amountdue >= 0){
            $('#change_row').hide();
           $('#amount_due').val(amountdue.toLocaleString()); 
        }else{
           change = amountdue * -1;
           amountdue = 0;
           $('#amount_due').val(amountdue);
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
        amountpayed += cashAmt;
        amountpay= cashAmt;
        AmtCalc_ex();
        tg_cash();
       
        e.preventDefault();
    });

       $("#csh_proc_cr").submit(function (e) {
        var cashAmt = parseInt(totalcre);
       //alert(cashAmt);
        var change;
        amountdue = amountdue - cashAmt;
        //var ledger = $['input']['ledger_id'].val();
        var ledger = $('input[name=ledger_id]').val();
        //alert(ledger);
            $('#ledgerRow'+ledger).show();
            $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
            var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" name="amount'+ledger+'" value="'+ cashAmt +'"><input type="hidden" id="credit'+ledger+'" name="credit'+ledger+'" value="'+ cashAmt +'">';
            $('#legerRata'+ledger).append(data);
        if(amountdue >= 0){
            $('#change_row').hide();
           $('#amount_due').val(amountdue.toLocaleString()); 
        }else{
           change = amountdue * -1;
           amountdue = 0;
           $('#amount_due').val(amountdue);
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
        amountpayed += cashAmt;
        amountpay= cashAmt;
        AmtCalcCR();
        tg_cashNote();
       
        e.preventDefault();
    });

    $("#csh_proc_over").submit(function (e) {
        var cashAmt = parseInt(totalovp);
       // alert(cashAmt);
         overpayed=overpayed-cashAmt;
         amountdue = amountdue - cashAmt;
         //change=change-cashAmt;
          $('#over_show').val(overpayed.toLocaleString());
          $('#payover').val(overpayed.toLocaleString());

         var ledger = 21;
          //alert(ledger);
          //alert(amountdue);
             $('#ledgerRow'+ledger).show();
             $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
             var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" name="amount'+ledger+'" value="'+ cashAmt +'"><input type="hidden" id="over'+ledger+'" name="over'+ledger+'" value="'+ cashAmt +'">';
             $('#legerRata'+ledger).append(data);
        if(amountdue >= 0){
            $('#change_row').hide();
           $('#amount_due').val(amountdue.toLocaleString()); 
        }else{
           change = amountdue * -1;
           amountdue = 0;
           $('#amount_due').val(amountdue);
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
        amountpayed += cashAmt;
        amountpay= cashAmt;
        //alert(change);
         if (amountdue <= 0 && change==0) {
            $('#finishReceipt').prop("disabled", false);
        } else {
            $('#finishReceipt').prop("disabled", true);
        }
         tg_overpay();
       
        e.preventDefault();
    });

    function finish_receipt1(){
        $('#finishReceipt').prop("disabled", true);
         if($('#payer_id').val()==""){
       swal('warning','select payer name')
        }else{
         $('#finishReceipt').prop("disabled", true);
        var allvariables2 = $("#receipt_form").serialize() + '&bill_payer='+$('#payer_id').val() + '&'+ $("#payment_panel").serialize()+'&date='+$('#receipt_date').val()+'&'+$("#header_form").serialize() +'&change='+change+'&'+$("#csh_proc_cr").serialize()+'&'+$("#csh_proc_over").serialize()+$("#csh_proc_deposit").serialize()+'&'+ $("#popup_form").serialize();
         //alert(allvariables2);
         $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillingController/process_receipt'; ?>',
            data: allvariables2,
            success: function (res) {
              var data = JSON.parse(res);
              if(data['status'] == "1"){
             manage_receipt2(data['id']);
             //location.reload();
            }else{
               swal('success','Payment saved successfully',"success");  
                setTimeout(function(){
                 location.reload();
                    },1500)
               
            }
            },
            error: function (){
                alert('error encounted');
            }
        });
    }

    }
    $("#paid_by").change(function(){
    
        $('#payer_name_row').show();
        $('#payer_details').html('');
    });
    $("#customer_type").change(function(){ 
         $('#select_invoice').show();
         $('#charged_item_lists').html('');
         
          
        if($("#receipt_type").val()==1){
            $('#charged_item_lists').hide();
               if($(this).val() == 4){
            $('#applicationlist').show();
            $('#invoicelist').hide();
        }else{
           $('#invoicelist').show(); 
           $('#applicationlist').hide();
        }
    }
    });
    function search_payer(){
       if($('#paid_by').val() == "") {
           swal("warning","Please Select Paid By","warning");
       }else if($('#payer_name').val() == ""){
          swal("warning","Please Enter Payer Name","warning"); 
       }else{
            var paydata = 'paid_by=' + $('#paid_by').val() + "&payer_name=" + $('#payer_name').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/search_payer'; ?>',
                beforeSend: function () {
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#customer_loaded').html(result); 
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
       
    }
    function select_payer(id,nametype,payer_name){
       var payer = nametype +'_' +id;
        $('#payer_id').val(payer);
        var payerdata = "payer=" + payer;
      //  alert(payerdata);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillingController/get_payer_details'; ?>',
            data: payerdata,
            success: function (res) {
                $('#payer_details').html(res);
                $('#payer_name_row').hide();
                $('#customer_loaded').html('');
            },
            error: function (){
                alert('error encounted');
            }
        });
    }

    $('#credited').val(0);
     $('#another').prop("disabled", true);
     $('#over-btn').prop("disabled", true);
     $('#addPayment').prop("disabled", true);
    function prepare_invoice_student(student_id,e){
           
       e.preventDefault();
       var receipt_type=$('#receipt_type').val();
      
       if(receipt_type ==2){

        prepare_sales_receipt(student_id);
        return;
        }
        $('#itm_invoice').empty();
           var paydata = 'id=' + student_id;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/create_invoice_student'; ?>',
                data: paydata,
                 dataType: 'json',
                success: function (result) {
                    $('#Invoice_loaded').html('');
                    select_payer(result.parent,5);
                    var data=result.result1; 
                    var data2=result.result2; 
                    var data3=result.result3; 
                    var data4=result.result4; 
                   // alert(data);
                    //var data = JSON.parse(result.result1); 
                    var mydata= Object.keys(data).length;
                    var mydata2= Object.keys(data2).length;
                    var mydata3= Object.keys(data3).length;
                    var mydata4= Object.keys(data4).length;
                   // alert(mydata4);
                    if(mydata>0){
                    var name_type = $('#customer_type').val() +'_'+ student_id;
                    itotal=0;
                    ctotal=0;
                    if(mydata2==0){
                        var itmc = '<tr>'
                                        +'<td colspan="5">No any Credit Available</td>'
                                       +'</tr>'; 
                                        $('#choose_credit').append(itmc);
                                        $('#savec').prop("disabled", true);
                     totalnote=0;
                    }else{
        ////////////////////////shows credit note /////////////////////// 
                var credit_total=0;               
                for(var i = 0; i < mydata2; i++){
                        c++;
                        credit_list.push(c);
                        credit_balance = parseInt(data2[i]['balance']);
                        credit_total += parseInt(data2[i]['balance']);
                        var itmc = '<tr id="row'+ c +'"><input type="hidden"  name="totalcredit"  value="'+mydata2+'">'
                                        +'<td><input type="hidden"  name="ledger_id"  value="'+data2[i]['ledger_id']+'">' + data2[i]['type_name']+'</td>'
                                       +
                                      '<td><input type="hidden"  name="credit_no'+c+'" value="'+data2[i]['trans_no']+'">' + data2[i]['trans_no']  +'</td>'+
                                     '<td>' + data2[i]['amount'].toLocaleString()  +'</td>'+
                                    '<td><input type="hidden"  id="credit_due'+c+'" value="'+credit_balance+'">' + credit_balance.toLocaleString()  +'</td>'+
                                       '<td><input type="text" class="form-control qtyc" onkeyup="AmtCalcCredit()" id="amounttopayCredit'+c+'"  value="'+0+'" name="credit_amount'+c+'" style="width:100px;" max="'+credit_balance+'"></td>' +
                                       '</tr>';
                                 $('#choose_credit').append(itmc);
                                  $('#ttlCredit').show();
                                $('#credited').val(credit_total.toLocaleString());
                                //$('#another').prop("disabled", false);
                             $('#itm_creditfooter').html('<td colspan="3"><b>Total</td><td>'+ credit_total.toLocaleString() +'</td><td id="credit_calc">'+ ctotal +'</b> </td>');
                }
                 totalnote=parseInt(credit_total);
      ////////////////////////end credit note ///////////////////////     
                     }

                     if(mydata3==0){
                        var itmov = '<tr>'
                                        +'<td colspan="5">No any Overpayment Available</td>'
                                       +'</tr>'; 
                                        $('#choose_over').append(itmov);
                                        $('#saveo').prop("disabled", true);
                     overpayed=0;
                     }else{
                        ////////////////////////shows OVER PAYMENT /////////////////////// 
                var over_total=0;               
                for(var i = 0; i < mydata3; i++){
                        ov++;
                        over_list.push(ov);
                        over_balance = parseInt(data3[i]['balance']);
                        over_total += parseInt(data3[i]['balance']);
                        var itmov = '<tr id="row'+ ov +'"><input type="hidden"  name="totalover"  value="'+mydata3+'">'
                                        +'<td>' + data3[i]['type_name']  +'</td>'
                                       +
                                      '<td><input type="hidden"  name="over_no'+ov+'" value="'+data3[i]['trans_no']+'">' + data3[i]['trans_no']  +'</td>'+
                                     '<td>' + data3[i]['amount'].toLocaleString()  +'</td>'+
                                    '<td><input type="hidden"  id="over_due'+ov+'" value="'+over_balance+'">' + over_balance.toLocaleString()  +'</td>'+
                                       '<td><input type="text" class="form-control qtyc" onkeyup="AmtCalcOver()" id="amounttopayOver'+ov+'"  value="'+0+'" name="over_amount'+ov+'" style="width:100px;" max="'+over_balance+'"></td>' +
                                       '</tr>';
                                 $('#choose_over').append(itmov);
                                  $('#payedOver').show();
                                $('#payover').val(over_total.toLocaleString());
                                // $('#over-btn').prop("disabled", false);
                             $('#itm_overfooter').html('<td colspan="3"><b>Total</td><td>'+ over_total.toLocaleString() +'</td><td id="over_calc">'+ 0 +'</b> </td>');
                }
                  overpayed=parseInt(over_total);
      ////////////////////////end over payment ///////////////////////  
                   
                    }

                 if(mydata4==0){
                    //alert('yes 0');
                        var itmod = '<tr>'
                                        +'<td colspan="4">No any deposit Available</td>'
                                       +'</tr>'; 
                                        $('#choose_deposit').append(itmod);
                                        $('#saved').prop("disabled", true);
                     depositpayed=0;
                     }else{
                          ////////////////////////shows deposit list /////////////////////// 
                var deposit_total=0;               
                for(var i = 0; i < mydata4; i++){
                        od++;
                        $lg=data4[i]['trans_no'];
                        deposit_list.push(od);
                        deposit_balance = parseInt(data4[i]['balance']);
                        deposit_total += parseInt(data4[i]['balance']);
                        var itmod = '<tr id="row'+ od +'"><input type="hidden"  name="totaldeposit"  value="'+mydata4+'">'
                                       +'<td><input type="hidden"  name="deposit_no'+od+'" value="'+data4[i]['trans_no']+'">' + data4[i]['trans_no']  +'</td>'+
                                     '<td>' + data4[i]['amount'].toLocaleString()  +'</td>'+
                                    '<td><input type="hidden"  id="deposit_due'+od+'" value="'+deposit_balance+'">' + deposit_balance.toLocaleString()  +'</td>'+
                                       '<td><input type="text" class="form-control qtyc" onkeyup="AmtCalcDeposit()" id="amounttopayDeposit'+od+'"  value="'+0+'" name="deposit_amount'+od+'" style="width:100px;" max="'+deposit_balance+'"></td>' +
                                       '</tr>';
                                 $('#choose_deposit').append(itmod);
                                  $('#payedDeposit').show();
                                $('#paydeposit').val(deposit_total.toLocaleString());
                                // $('#over-btn').prop("disabled", false);
                             $('#itm_depositfooter').html('<td colspan="2"><b>Total</td><td>'+ deposit_total.toLocaleString() +'</td><td id="deposit_calc">'+ 0 +'</b> </td>');
                }
                  depositpayed=parseInt(deposit_total);
      ////////////////////////end over payment ///////////////////////   
                     }
                  //  alert(totalnote);
                    for( var i = 0; i < mydata; i++){
                        k++;
                        item_list.push(k);
                         unit_price = parseInt(data[i]['balance']);
                        total += unit_price;
                        var invoice_amount = parseInt(data[i]['amount']);
                        totalinv +=invoice_amount;
                        amountdue = total - amountpayed;
                        var itm = '<tr id="row'+ k +'"><input type="hidden"  name="student[]"  value="'+name_type+'">'+
                                         '<td><input type="checkbox" name="type" value="'+k+'" onclick="checkbox('+k+','+unit_price+')" id="opt'+k+'"></td>'
                                        +'<td>' + data[i]['type_name']  +'</td>'
                                       +
                                      '<td><input type="hidden"  name="trans_no'+k+'" value="'+data[i]['trans_no']+'">' + data[i]['trans_no']  +'</td>'+
                                       '<td>' + data[i]['trans_date']  +'</td>'+
                                       '<td>' + data[i]['full_name'] +'</td>'+
                                       '<td>' + invoice_amount.toLocaleString()  +'</td>'+
                                       '<td><input type="hidden"  id="due'+k+'" value="'+unit_price+'">' + unit_price.toLocaleString()  +'</td>'+
                                       '<td><input type="text" class="form-control qty" onkeyup="AmtCalc()" id="amounttopay'+k+'"  value="'+0+'" name="amount'+k+'" style="width:100px;" max="'+unit_price+'"></td>' +
                                       '</tr>';
                               
                       $('#itm_invoice').append(itm);
                       $('#itm_invoicefooter').html('<td colspan="5"><b>Total</td><td>'+ totalinv.toLocaleString() +'</td><td>'+ total.toLocaleString() +'</td><td id="receipt_calc">'+ itotal +'</b> </td>');
                       $('#Name_loaded').html(''); 
                       $('#select_invoice').hide();
                       // if(totalnote>0){
                       //   $('#ttlCredit').show();
                       //  $('#credited').val(totalnote.toLocaleString());
                       //   $('#another').prop("disabled", false);
                       // }else{
                       //  $('#ttlCredit').hide();
                       // }
                       //$('#receipt_calc').html(total.toLocaleString());
                        if(overpayed>0){
                         $('#payedOver').show();
                        $('#payover').val(overpayed.toLocaleString());
                         //$('#over-btn').prop("disabled", false);
                       }else{
                        $('#payedover').hide();
                       }
                       $('#amount_due').val(0);
                   }
               }else{
       $('#itm_invoice').html('<p class="text-red">Sorry No invoice Available</p>');
       $('#Name_loaded').html(''); 
        $('#select_invoice').hide();
               }
                },
                error: function () {
                    $('#itm_invoice').html('<p class="text-red">Sorry Something went wrong</p>');
               }
      });
    }
     function AmtCalc() {
        amountpayed=0;
            "<?php foreach($accoo as $ap){?>";
         var lg="<?php echo $ap->id;?>";
           //alert(lg);
      $('#ledgerRow'+lg).hide();
       $('#ledger_payed'+lg).html('');
       $('#legerRata'+lg).html('');
       $('#change_row').hide();
         "<?php } ?>";

         "<?php foreach($account as $ap){?>";
         var lg="<?php echo $ap->id;?>";
           //alert(lg);
      $('#ledgerRow'+lg).hide();
       $('#ledger_payed'+lg).html('');
       $('#legerRata'+lg).html('');
       $('#change_row').hide();
         "<?php } ?>";
         
       var needed=0;
        total = 0;
        var i=0;
        var receipt_type=$('#receipt_type').val();
        if(receipt_type==1){
        for (var j in item_list) {
          
           var due=$('#due' + item_list[j]).val(); 
           var amr=$('#amounttopay' + item_list[j]).val();
            //alert(due-amr);
         if((due-amr)<0){
            i=1;
            var myVariable = parseInt($('#amounttopay' + item_list[j]).val()); 
            // alert(myVariable.substring(0, myVariable.length - 1)); 
            myVariable = Number(String(myVariable).slice(0, -1));
            console.log(myVariable);
            
            $('#amounttopay' + item_list[j]).val(myVariable);
            total += parseInt($('#amounttopay' + item_list[j]).val());
         swal('','Please Enter amount less or equal to '+due.toLocaleString());
         //alert(total);
              //continue;
              }else{
                i=0;
         total += parseInt($('#amounttopay' + item_list[j]).val());

         //needed=parseInt($('#amounttopay' + item_list[j]).val());
              } 
             
        } }

      if(i==0){
         // alert(amountdue+'/'+total+"/"+amountpayed);
        if(amountdue >0 && total==0){
            total=amountdue;
         amountdue = total - amountpayed;
        }else{
          amountdue = total - amountpayed;  
        }
        
        //alert(amountdue);
        if(amountdue >= 0){
          $('#amount_due').val(amountdue.toLocaleString());
        }else{
          $('#amount_due').val(0);  
        }
        if (amountdue <= 0) { 

            $('#other_receipt').prop("disabled", true);
            $('#over-btn').prop("disabled", true);
            $('#another').prop("disabled", true);
            $('#addPayment').prop("disabled", true);
            $('#finishReceipt').prop("disabled", false);
        } else if(amountdue > 0) {
            $('#over-btn').prop("disabled", false);
            $('#another').prop("disabled", false);
            $('#finishReceipt').prop("disabled", true);
            $('#other_receipt').prop("disabled", false);
            $('#addPayment').prop("disabled", false);
        }else{
           $('#over-btn').prop("disabled", true);
            $('#another').prop("disabled", true);
            $('#finishReceipt').prop("disabled", true); 
            $('#addPayment').prop("disabled", true); 
        }
        $('#receipt_calc').html(total.toLocaleString());
       }else{

       } 
    }
    //********************alternatively**************************************
        function AmtCalc_ex() {
       var needed=0;
        total = 0;
        var i=0;
        for (var j in item_list) {
          
           var due=$('#due' + item_list[j]).val(); 
           var amr=$('#amounttopay' + item_list[j]).val();
            //alert(due-amr);
         if((due-amr)<0){
            i=1;
            var myVariable = parseInt($('#amounttopay' + item_list[j]).val()); 
            // alert(myVariable.substring(0, myVariable.length - 1)); 
            myVariable = Number(String(myVariable).slice(0, -1));
            console.log(myVariable);
            
            $('#amounttopay' + item_list[j]).val(myVariable);
            total += parseInt($('#amounttopay' + item_list[j]).val());
         swal('','Please Enter amount less or equal to '+due.toLocaleString());
         //alert(total);
              //continue;
              }else{
                i=0;
         total += parseInt($('#amounttopay' + item_list[j]).val());

         //needed=parseInt($('#amounttopay' + item_list[j]).val());
              } 
             
        }
      if(i==0){
          
        amountdue = total - amountpayed;
        if(amountdue >= 0){
          $('#amount_due').val(amountdue.toLocaleString());
        }else{
          $('#amount_due').val(0);  
        }
        if (amountdue <= 0) {
            $('#over-btn').prop("disabled", true);
            $('#another').prop("disabled", true);
            $('#finishReceipt').prop("disabled", false);
        } else if(amountdue >= 0) {
            $('#over-btn').prop("disabled", false);
            $('#another').prop("disabled", false);
            $('#finishReceipt').prop("disabled", true);
        }else{
           $('#over-btn').prop("disabled", true);
            $('#another').prop("disabled", true);
            $('#finishReceipt').prop("disabled", true);  
        }
        $('#receipt_calc').html(total.toLocaleString());
       }else{

       } 
    }
    //*********************************************************//
    function AmtCalcCR() {
        total = 0;
        for (var j in item_list) {
           total += parseInt($('#amounttopay' + item_list[j]).val());  
        }
        amountdue = total - amountpayed;
     
        totalnote = totalnote - amountpay;
        if(amountdue >= 0){
          $('#amount_due').val(amountdue.toLocaleString());
           $('#credited').val(totalnote.toLocaleString());
        }else{
          $('#amount_due').val(0);  
          $('#credited').val(0);  
        }
        if (amountdue <= 0 && change==0) {
            $('#finishReceipt').prop("disabled", false);;
        } else {
            $('#finishReceipt').prop("disabled", true);;
        }
        $('#receipt_calc').html(total.toLocaleString());
        
    }
    function RemoveSelectItemRow(looper){
        for( var i = 0; i < item_list.length; i++){ 
            if ( item_list[i] == looper) {                 
                item_list.splice(i, 1); 
            }
        }
       $('#row'+looper).remove();
        AmtCalc();
        
    }
    function removePayment(lg){
          var amount= $('#ledger_payed'+lg).val().replace(/,/gi, "");
          //var credit= $('#credit'+lg).val().replace(/,/gi, "");
       //alert(amount);
      // alert(amountdue);
       $('#ledgerRow'+lg).hide();
       $('#ledger_payed'+lg).html('');
       $('#legerRata'+lg).html('');
        //AmtCalc();
       // if(credit > 0) {
       //    totalnote = parseInt(totalnote) + parseInt(amount);
       //  } 
       amountdue = parseInt(amountdue) + parseInt(amount);
     $('#amount_due').val(amountdue.toLocaleString());
     $('#change_row').hide();
     $('#credited').val(totalnote.toLocaleString());
     if (amountdue <= 0) {
            $('#finishReceipt').prop("disabled", false);
        } else {
            $('#finishReceipt').prop("disabled", true);
        }
 
    }
            $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('.daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                                         'This Year': [moment().startOf('year'), moment().endOf('year')]
                                    }
                                }, cb);
                                cb(start, end);

                            });

             $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn-revese span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn-revese').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                                         'This Year': [moment().startOf('year'), moment().endOf('year')]
                                    }
                                }, cb);
                                cb(start, end);

                            });
   $('#Rept1Result').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#receipt').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn span').html();
           // alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/receipt2'; ?>',

                data: dta,
                success: function (res) {
                    $('#receipt').html(res);
                },
                error: function () {
                    $('#receipt').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });

$('#Rept1ResultReves').submit(function (e) {
             if (!$('#daterange-btn-revese span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#receipt_revese').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn-revese span').html();
            //alert(dta);
            //return;
            $.ajax({
                type: "POST",
                  url: '<?php echo base_url() . '/index.php/SemisterController/load_reversal'; ?>',
               /// url: '<?php echo base_url() . '/receipt2'; ?>',

                data: dta,
                success: function (res) {
                    $('#receipt_revese').html(res);
                },
                error: function () {
                    $('#receipt_revese').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });
   function resetReceiptData(){
        $('#payer_details').empty();
        $('#payer_id').val('');
        $('#payer_name').val('');
        $('#paid_by').val('');
        $('#customer_type').val('');
         $('#customer_name').val('');
        $('#select_invoice').hide();
        $('#payer_name_row').hide();
        $('#customer_loaded').empty();
        $('#Name_loaded').empty();
        $('#Invoice_loaded').empty();
        $('#itm_invoice1').empty();
        $('#itm_invoice').empty();
        $('#amount_due').val(0);
         $('#other_receipt').prop("disabled", true);
   }
   function checkbox(k,p) {
    //alert(p);
 var remember = document.getElementById('opt'+k+'');
  if (remember.checked) {
    
       var fnsh = $('input[name=amount'+k+']').val();
       //alert(fnsh);
   $('input[name=amount'+k+']').attr('value',p);
    $('#receipt_calc').html(p.toLocaleString());
     }else
     {
    $('input[name=amount'+k+']').attr('value',0);
     $('#receipt_calc').html(0);
     }
}
  function finish_receipt(){
         if(change>0){
        swal({
            title: "",
            text: 'The paid amount(Cash/Bank) is more than "Amount to Pay". An overpayment entry of '+change.toLocaleString()+' will be automatically generated in the Overpayment ledger. You will be able to apply this overpayment in future receipts. Are you sure you want to continue?',
           
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Ok",
            cancelButtonText: "Cancell",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
             
            finish_receipt1();
            } else {
              swal("Cancelled");
            }

          });
     // $('#over').html(change.toLocaleString());
     // $('#overPayment').modal('show'); 
    
    }else{
        change=0;
       finish_receipt1(); 
    }

    };


   function AmtCalcCredit() {
       var needed=0;
       //alert(amountdue);
        totalcr = 0;
        totalcre = 0;
        var i=0;
        for (var j in credit_list) {
          totalcr += parseInt($('#amounttopayCredit' + credit_list[j]).val());
        }

        for (var j in credit_list) {
           var due=$('#credit_due' + credit_list[j]).val(); 
           var amr=$('#amounttopayCredit' + credit_list[j]).val();
            //alert(due-amr);
         if((due-amr)<0 || (amountdue-totalcr)<0){
            i=1;
            var myVariable = parseInt($('#amounttopayCredit' + credit_list[j]).val()); 
            // alert(myVariable.substring(0, myVariable.length - 1)); 
            myVariable = Number(String(myVariable).slice(0, -1));
            console.log(myVariable);
            
            $('#amounttopayCredit' + credit_list[j]).val(myVariable);
            totalcre += parseInt($('#amounttopayCredit' + credit_list[j]).val());
            if((amountdue-totalcr)<0){
               swal('','Please Enter amount less or equal to '+amountdue.toLocaleString());
            }else{
               swal('','Please Enter amount less or equal to '+due.toLocaleString()); 
            }
            
        //alert(total);
              //continue;
              }else{
                i=0;
         totalcre += parseInt($('#amounttopayCredit' + credit_list[j]).val());

         //needed=parseInt($('#amounttopay' + item_list[j]).val());
              } 
             
        }
         $('#credit_calc').html(totalcre.toLocaleString());
     
    }

    function AmtCalcOver() {
       var needed=0;
       //alert(amountdue);
        totalov = 0;
        totalovp = 0;
        var i=0;
        for (var j in over_list) {
          totalov += parseInt($('#amounttopayOver' + over_list[j]).val());

        }
       // alert(totalov);
        for (var j in over_list) {
           var due=$('#over_due' + over_list[j]).val(); 
           var amr=$('#amounttopayOver' + over_list[j]).val();
            //alert(due+'/'+amr);
         if((due-amr)<0 || (amountdue-totalov)<0){
            i=1;
            var myVariable = parseInt($('#amounttopayOver' + over_list[j]).val()); 
            // alert(myVariable.substring(0, myVariable.length - 1)); 
            myVariable = Number(String(myVariable).slice(0, -1));
            console.log(myVariable);
            
            $('#amounttopayOver' + over_list[j]).val(myVariable);
            totalovp += parseInt($('#amounttopayOver' + over_list[j]).val());
            if((amountdue-totalov)<0){
               swal('','Please Enter amount less or equal to '+amountdue.toLocaleString());
            }else{
               swal('','Please Enter amount less or equal to '+due.toLocaleString()); 
            }
            
        //alert(total);
              //continue;
              }else{
                i=0;
         totalovp += parseInt($('#amounttopayOver' + over_list[j]).val());

         //needed=parseInt($('#amounttopay' + item_list[j]).val());
              } 
             
        }
         $('#over_calc').html(totalovp.toLocaleString());
        }
    function closePopup() {
        event.preventDefault();
  var popup = document.getElementById('cash_credit');
  popup.style.display = 'none'; // Set display to 'none' to hide the popup
  //alert('yes');
}
   function closePopup_over() {
        event.preventDefault();
  var popup = document.getElementById('cash_over');
  popup.style.display = 'none'; // Set display to 'none' to hide the popup
  //alert('yes');
}
function close_Popup() {
 event.preventDefault();
  var popup = document.getElementById('cash');
  popup.style.display = 'none';
  //alert('yes');
}

  function closePopup_deposit() {
        event.preventDefault();
  var popup = document.getElementById('deposit_popup');
  popup.style.display = 'none'; // Set display to 'none' to hide the popup
  //alert('yes');
}

   function AmtCalcDeposit() {
       var needed=0;
       //alert(amountdue);
        totalod = 0;
        totaldep = 0;
        var i=0;
        for (var j in deposit_list) {
          totalod += parseInt($('#amounttopayDeposit' + deposit_list[j]).val());

        }
       // alert(totalod);
        for (var j in deposit_list) {
           var due=$('#deposit_due' + deposit_list[j]).val(); 
           var amr=$('#amounttopayDeposit' + deposit_list[j]).val();
            //alert(due+'/'+amr);
         if((due-amr)<0 || (amountdue-totalod)<0){
            i=1;
            var myVariable = parseInt($('#amounttopayDeposit' + deposit_list[j]).val()); 
            // alert(myVariable.substring(0, myVariable.length - 1)); 
            myVariable = Number(String(myVariable).slice(0, -1));
            console.log(myVariable);
            
            $('#amounttopayDeposit' + deposit_list[j]).val(myVariable);
            totaldep += parseInt($('#amounttopayDeposit' + deposit_list[j]).val());
            if((amountdue-totalod)<0){
               swal('','Please Enter amount less or equal to '+amountdue.toLocaleString());
            }else{
               swal('','Please Enter amount less or equal to '+due.toLocaleString()); 
            }
            
        //alert(total);
              //continue;
              }else{
                i=0;
         totaldep += parseInt($('#amounttopayDeposit' + deposit_list[j]).val());

         //needed=parseInt($('#amounttopay' + item_list[j]).val());
              } 
             
        }
         $('#deposit_calc').html(totaldep.toLocaleString());
        }

 $("#csh_proc_deposit").submit(function (e) {
        var cashAmt = parseInt(totaldep);
       // alert(cashAmt);
         depositpayed=depositpayed-cashAmt;
         amountdue = amountdue - cashAmt;
         //change=change-cashAmt;
          $('#deposit_show').val(depositpayed.toLocaleString());
          $('#paydeposit').val(depositpayed.toLocaleString());

         var ledger = 23;
          //alert(ledger);
          //alert(amountdue);
             $('#ledgerRow'+ledger).show();
             $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
             var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" name="amount'+ledger+'" value="'+ cashAmt +'"><input type="hidden" id="deposit'+ledger+'" name="deposit'+ledger+'" value="'+ cashAmt +'">';
             $('#legerRata'+ledger).append(data);
        if(amountdue >= 0){
            $('#change_row').hide();
           $('#amount_due').val(amountdue.toLocaleString()); 
        }else{
           change = amountdue * -1;
           amountdue = 0;
           $('#amount_due').val(amountdue);
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
        amountpayed += cashAmt;
        amountpay= cashAmt;
        //alert(change);
         if (amountdue <= 0 && change==0) {
            $('#finishReceipt').prop("disabled", false);
        } else {
            $('#finishReceipt').prop("disabled", true);
        }
         tg_deposit();
       
        e.preventDefault();
    });
 function close_rept(){
     $('#viewreceipt').modal('hide');
     location.reload();  
 }
 
 function printable_rept(area) {
  var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
  disp_setting += "scrollbars=yes,width=750, height=600, left=80, top=25";
  var content_value = document.getElementById(area).innerHTML;

  var docprint = window.open("", "", disp_setting);
  docprint.document.open();
  docprint.document.write('<html><head><title>MHI</title>');

  // Add a <style> block to set the font family and other print-specific styles
  docprint.document.write('<style>');
  docprint.document.write('@media print {');
  docprint.document.write('  body {');
  docprint.document.write('    font-family: "Times New Roman", sans-serif;');
  docprint.document.write('    font-size: 15px;');
  docprint.document.write('  }');
  docprint.document.write('</style>');

  docprint.document.write('</head><body onLoad="self.print()" style="width:100%;">');

  // Modify content_value to include the colspan attribute
  var modifiedContent = content_value.replace('<td class="colspan-cell">', '<td colspan="2" class="colspan-cell">');
  docprint.document.write(modifiedContent);

  docprint.document.write('</body></html>');
  docprint.document.close();
  docprint.focus();
 
}
 function printable_rept2(area) {
 
  var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
  disp_setting += "scrollbars=yes,width=750, height=600, left=80, top=25";
  var content_value = document.getElementById(area).innerHTML;

  var docprint = window.open("", "", disp_setting);
  docprint.document.open();
  docprint.document.write('<html><head><title>MHI</title>');

  // Add a <style> block to set the font family and other print-specific styles
  docprint.document.write('<style>');
  docprint.document.write('@media print {');
  docprint.document.write('  body {');
  docprint.document.write('    font-family: "Times New Roman", sans-serif;');
  docprint.document.write('    font-size: 15px;');
  docprint.document.write('  }');
  docprint.document.write('</style>');

  docprint.document.write('</head><body onLoad="self.print()" style="width:100%;">');

  // Modify content_value to include the colspan attribute
  var modifiedContent = content_value.replace('<td class="colspan-cell">', '<td colspan="2" class="colspan-cell">');
  docprint.document.write(modifiedContent);

  docprint.document.write('</body></html>');
  docprint.document.close();
  docprint.focus();
  location.reload();
}
</script>
<script>
        function updateTabVisibility() {
           //alert('here block');
            const largeScreenTab = document.getElementById('largeScreenTab');
            const smallScreenTab = document.getElementById('smallScreenTab');
            const isLargeScreen = window.innerWidth >= 900; // Adjust the width as needed

            largeScreenTab.style.display = isLargeScreen ? 'block' : 'none';
            smallScreenTab.style.display = isLargeScreen ? 'none' : 'block';
        }

        // Initial call and add a listener to update on window resize
        updateTabVisibility();
        window.addEventListener('resize', updateTabVisibility);

        function otherReceipt(){
         $('#other_rec_popup').toggle(100);
         $('#display_receipt').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');

            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/SemisterController/load_receipt'; ?>',
                beforeSend: function () {
                    $('#display_receipt').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                
                success: function (result) {
                  $('#display_receipt').html(result); 
                },
                error: function () {
                    $('#display_receipt').html('<p class="text-red">Sorry Something went wrong</p>');
               }
            });
        }

    function save_amount(){
    $('#other_rec_popup').toggle(100);
 var receipt_number =$('#receipt_number').val();
 var student_from =$('#student_from').val();
 var reason =$('#reason').val();
 var ledger =$('#from_ledger').val();
 var i_amount =parseInt($('#i_amount').val());
 //alert(receipt_number+'/'+student_from+'/'+from_ledger+'/'+i_amount);

  amountdue = amountdue - i_amount;

          //alert(ledger);
          //alert(amountdue);
             $('#ledgerRow'+ledger).show();
             $('#ledger_payed'+ledger).val(i_amount.toLocaleString());
             var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" name="amount'+ledger+'" value="'+ i_amount +'"><input type="hidden" id="transfer'+ledger+'" name="transfer'+ledger+'" value="'+ i_amount +'"><input type="hidden" id="reasons" name="reasons" value="'+ reason +'">';
             $('#legerRata'+ledger).append(data);
        if(amountdue >= 0){
            $('#change_row').hide();
           $('#amount_due').val(amountdue.toLocaleString()); 
        }else{
           change = amountdue * -1;
           amountdue = 0;
           $('#amount_due').val(amountdue);
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
        amountpayed += i_amount;
        amountpay= i_amount;
         if (amountdue <= 0 && change==0) {
            $('#finishReceipt').prop("disabled", false);
        } else {
            $('#finishReceipt').prop("disabled", true);
        }
        
     e.preventDefault();
}
function closePopup_transfer() {
        event.preventDefault();
  var popup = document.getElementById('other_rec_popup');
  popup.style.display = 'none'; // Set display to 'none' to hide the popup
  //alert('yes');
}

 function searchnamebtn(){
            var name=$('#search_name').val();
            var  year=$('#button-y').html();
            // alert(year);
            if(name.length >=3){
                $('#receipt').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
                var dta="name="+name+"&year="+year;
           // toastr.success(name.length);
             $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/index.php/AdmissionController/fetch_invoice_byname'; ?>/2",
                data: dta,
                success: function (res) {
                    $('#receipt').html(res);
                },
                error: function () {
                    $('#receipt').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
        }else{
            if(name.length==0){
               $('#receipt').html(''); 
            }else{
               $('#receipt').html('<div class="alert alert-info">Search atleat 3 characters</div>'); 
            }
        
        }
        }
        
        function export_receipt(){
            var thedate = $('#daterange-btn span').html();

        window.location.href = "<?php echo base_url() . '/exportReceipt?thedate='; ?>"+thedate;

           }
           
           $('.resend').prop("disabled", false);
    function resend_vfd(id,amount,student_name){
        $('.resend').prop("disabled", true);
      //$('#viewreceipt').modal('show'); 
      var dta='id='+id+'&amount='+amount+'&student_name='+student_name;
        $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/index.php/BillingController/process_vfd_receipt'; ?>",
                data: dta,
                success: function (res) {
                     var data = JSON.parse(res);
                     swal(''+data["status"]+'',''+data["description"]+'',''+data["status"]+'');
                     $('#Rept1Result').submit();
                    
                },
                error: function () {
                    swal('error','Sorry, Something went wrong!','error')
                }
            });
     
    }

    function view_traReceipt(id,amount,student_name){
       $('#recptHist').modal('show'); 
      var dta='id='+id+'&amount='+amount+'&student_name='+student_name;
        $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/index.php/BillingController/tra_receipt_view'; ?>",
                data: dta,
                success: function (res) {
                    $('#recptHistDetails').html(res);
                },
                error: function () {
                    $('#recptHistDetails').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            }); 
    }

      $("#receipt_type").change(function(){
        if($("#receipt_type").val()==1){
       $('#invoicelist').show();
       $('#btn_list').show();
       // $('#bank_select').hide();

        }else{
         $('#invoicelist').hide();
         $('#btn_list').show();
         // $('#bank_select').show();

        }
        
    });

      function prepare_sales_receipt(student_id){
        var customer_type=$('#customer_type').val();
        select_payer(student_id,customer_type,0);
        $('#finishReceipt').hide();
        $('#finishReceipt2').show();
         $('#Name_loaded').html('');
         //$('#charged_item_lists').show();
          document.getElementById('charged_item_lists').style.display = 'block';
         var dta='student_id='+student_id;
        $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/index.php/BillingController/fetch_charged_items'; ?>",
                data: dta,
                success: function (res) {
                    $('#charged_item_lists').html(res);
                },
                error: function () {
                    $('#charged_item_lists').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            }); 
      }

         function finish_receipt2(){
       // $('#finishReceipt2').prop("disabled", true);
        
        var allvariables2 = 'bill_payer='+$('#payer_id').val() + '&'+ $("#charged_items").serialize()+'&date='+$('#receipt_date').val()+'&'+$("#header_form").serialize()+'&'+$("#receipt_details").serialize()+ '&'+ $("#payment_panel").serialize();
         //alert(allvariables2);
        // return;
         $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillingController/process_sales_receipt'; ?>',
            data: allvariables2,
            success: function (res) {
              var data = JSON.parse(res);
              if(data['status'] == "1"){
             manage_receipt2(data['id']);
             //location.reload();
            }else{
               swal('success','Payment saved successfully',"success");  
                setTimeout(function(){
                 location.reload();
                    },1500)
               
            }
            },
            error: function (){
                alert('error encounted');
            }
        });
    
 }

 function changeQuantity(iid){
   
    var qty=$('#quantity'+iid).val();
    var price=$('#pric'+iid).val();
    var ttl=qty*price;
    $('#ttl' + iid).html(ttl.toLocaleString()); 

   calculateTotal();
    
 }
 function calculateTotal(){
     var totalsum=0;
     $('input[name="iid[]"]').each(function(){
    var iiid = $(this).val();

    totalsum = totalsum + parseInt($('#ttl' + iiid).html().replace(/,/gi, ""));
    console.log('iid =', iiid);
});
    document.getElementById("totalp").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    $('#amount_due').val(totalsum.toLocaleString());
    amountdue=totalsum;
    total=totalsum;
    //alert('amount_due='+amountdue);
     if(amountdue >= 0){
            $('#change_row').hide();
           $('#amount_due').val(amountdue.toLocaleString()); 
        }else{
           change = amountdue * -1;
           amountdue = 0;
           $('#amount_due').val(amountdue);
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
        AmtCalc();
 }
    </script>