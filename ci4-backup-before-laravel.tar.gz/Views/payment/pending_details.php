<?php
     $bmodel = new App\Models\BillingModel();
     $smodel = new App\Models\StudentModel();
     $dbname=session()->get('db_name');
     $db = \Config\Database::connect();
     if($ctype == 4){
         $names= $db->query('SELECT * FROM students_application_tbl 
                          WHERE `id` = \''.$search.'\' OR`first_name`LIKE \'%'.$search.'%\' OR`last_name`LIKE \'%'.$search.'%\' OR`full_name`LIKE \'%'.$search.'%\'');
     }elseif($ctype == 1){
         $names= $db->query('SELECT * FROM students 
                          WHERE `id` = \''.$search.'\' OR`first_name`LIKE \'%'.$search.'%\' OR`last_name`LIKE \'%'.$search.'%\' OR`full_name`LIKE \'%'.$search.'%\'');
     }else{
         return 'No Data Found';
     }
     $result = $names->getResult();
if(count($result) > 0){ 
   $rsl = $result;
$parentid = $db->query('SELECT parent_id FROM parents_students_tbl WHERE student_id = '.$rsl[0]->id.''); $pid_result = $parentid->getResult();
   $parent = $db->query('SELECT first_name,last_name,full_name FROM parents_tbl WHERE id = '.$pid_result[0]->parent_id.'');
   $p_result = $parent->getResult();

    // if($ctype == 4){
    //     $total = $db->query('SELECT sum(unit_price) as total FROM temp_item_transation_tbl 
    //                            WHERE student_id = '.$rsl[0]->id.' AND bill_status = 0');
    //     $total_price = $total->getResult();
    // }else if($ctype == 1){       
    //     $credit = $db->query('SELECT sum(amount) as credit FROM  ledger_transaction_tbl  
    //                            WHERE name_id = '.$rsl[0]->id.'  AND name_type_id ='.$ctype.' AND transation_nature = 1 and trans_type = 1');
    //     $debit = $db->query('SELECT sum(amount) as debit FROM  ledger_transaction_tbl  
    //                            WHERE name_id = '.$rsl[0]->id.' AND ledger_type = 9 and name_type_id ='.$ctype.' AND transation_nature = 2 and trans_type = 2');
    //     $credit_total = $credit->getResult(); 
    //     $debit_total = $debit->getResult(); 
    //     $diff =$credit_total[0]->credit - $debit_total[0]->debit;
    // }

    if($ctype == 4){
 ?>
        <table class="table table-hover">
            <thead>
                 <tr>
                    <th>App Id</th>
                    <th>Applicant Name</th>
                    <!-- <th>Parent</th> -->
                    <th>total</th>
                    <th></th>
                </tr>
        </thead> 
            <tbody> 
            <?php foreach ($rsl as $s) { 
                $total = $db->query('SELECT sum(unit_price) as total FROM temp_item_transation_tbl 
                               WHERE student_id = '.$s->id.' AND bill_status = 0');
                $total_price = $total->getResult();
            ?>     
                <tr>
                   <td><?= $s->id; ?></td>
                   <td><?= $s->first_name.' '.$s->middle_name.' '.$s->last_name; ?></td>
                   <td><a data-bs-toggle="collapse" href="#invoiceDetailed" aria-expanded="false" aria-controls="invoiceDetailed" style="color:#5F6468;"><?= number_format($total_price[0]->total);?></a></td>
                   <td><button class="btn btn-primary btn-sm pull-right" onclick="prepare_invoice('<?= $s->id; ?>')"><i class="fa fa-plus" aria-hidden="true"></i> Add</button></td>
               </tr>
           <?php } ?>
            </tbody>   
        </table>  
       <div class="collapse" id="invoiceDetailed">
                <?php
                $inv = $bmodel->get_item_name('temp_item_transation_tbl',$where = array('student_id' =>$rsl[0]->id,'bill_status'=>0));
                 if(count($inv) > 0){
                     ?>
                     <center><h6>Pending Bills</h6></center>
                     <table class="table">
                         <thead>
                            <tr>
                                <td>Sn</td>
                                <td>Description</td>
                                <td>Control No</td>
                                <td>Total</td>
                                </tr>
                         </thead>
                         <tbody>
                             <?php
                     $sn=1;
                     $total = 0;
                     foreach($inv as $in){
                        $itm = $bmodel->get_item_name('items_tbl',$where = array('id' =>$in->item_id));
                         echo '<tr><td>'.$sn++.'</td>';
                         echo '<td>'.$itm[0]->item_name.'</td>';
                         echo '<td>'.$in->reference_no.'</td>';
                         echo '<td>'.number_format($in->unit_price).'</td></tr>';
                         $total+=$in->unit_price;
                     }
                     ?>
                   </tbody>
                 </table>
               <?php  } ?>
        </div>
<?php }else if($ctype == 1){ ?>
    <table class="table table-hover">
            <thead>
                 <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Class</th>
                    <th>Stream</th>
                    <th></th>
                </tr>
        </thead> 
        <tbody>
            <?php foreach ($rsl as $s) {
                 $std = $smodel->gettable_stdetail($s->id);
                $credit = $db->query('SELECT sum(amount) as credit FROM  ledger_transaction_tbl  
                               WHERE name_id = '.$s->id.'  AND name_type_id ='.$ctype.' AND transation_nature = 1 and trans_type = 1');
                $debit = $db->query('SELECT sum(amount) as debit FROM  ledger_transaction_tbl  
                                       WHERE name_id = '.$s->id.' AND ledger_type = 7 and name_type_id ='.$ctype.' AND transation_nature = 1 and trans_type = 2');
                $credit_total = $credit->getResult(); 
                $debit_total = $debit->getResult(); 
                $diff =$credit_total[0]->credit - $debit_total[0]->debit;
                if(count($std)>0){
            ?>
            <tr>
                   <td><?= $s->student_id; ?></td>
                   <td><?= $s->first_name.' '.$s->middle_name.' '.$s->last_name; ?></td>
                   <td><?= $s->gender; ?></td>
                   <td><?= $std[0]->class_name; ?></td>
                   <td><?= $std[0]->stream_name; ?></td>
                   <!-- <td><?= number_format($diff);?></a></td> -->
                   <td><button class="btn btn-primary btn-sm pull-right" onclick="select_pending_student('<?= $s->id; ?>')"><i class="fa fa-plus" aria-hidden="true"></i> Add</button></td>
               </tr>
           <?php }
          else{
              echo '<tr>';
                echo '<td>'.$s->id.'</td>';
                echo '<td>'.$s->full_name.'</td>';
                echo '<td style="color:red">No Invoice</td>';
                echo '</tr>';
          }
       } ?>
        </tbody>
      </table>
<?php } }
else{
       echo "<span style='color:red'>No any data Found</span>";

}
?>

 
