
<?php
   $bmodel = new App\Models\BillingModel();
   $ctype= $bmodel->get_table_details('name_type_tbl');
?>

<div class="section-body mt-4">
    <div class="container-fluid">
             
                <div class="card">
               <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable2">
                            <thead>
                                <tr>
                                     
                                    <th>Rct Date</th>
                                    <th>Rct No</th>
                                    <th>Payer Name</th>
                                    <th>A/C NO</th>
                                    <th>Amout</th>
                                    <th>Channel</th>
                                    <th>Ctr Date</th>
                                    <th>Ctr No</th>
                                    <th>Ctr Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                 if(count($trans)>0){
                            foreach($trans as $s){
                                 if($s->payment_channel==2){
                                  $channel="NMB";
                                 }if($s->payment_channel==3){
                                    $channel="CRDB";
                                 }

                                

                                 if($s->allow_partial==1){
                                  $allow="FLEXIBLE";
                                 }else{
                                    $allow="FIXED";
                                 }

                                ?>
                                <tr>
                                    
                                    <td><?php echo date('Y-m-d H:i',strtotime($s->transaction_date));?></td>
                                     <td><?php echo $s->transaction_receipt;?></td>
                                      <td><?php echo $s->customer_name;?></td>
                                     <td><?php echo $s->account_no;?></td>
                                   <td><?= number_format($s->amount_payed); ?></td>
                                   <td><?php echo $s->transaction_channel;?></td>
                                     <td><?php echo date('Y-m-d H:i',strtotime($s->date_created));?></td>
                                    <td><?php echo $s->reference_no;?></td>
                                    <td><?php echo $allow;?></td> 
                                   
                                    
                                </tr>
                            <?php }}else{
                                echo "<tr><td>Currently there is no record</td></tr>";
                            } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
          
        </div>
   

<script>

    $(document).ready(function () {
      $('#myTable2').DataTable();
    });
    
    
  </script>