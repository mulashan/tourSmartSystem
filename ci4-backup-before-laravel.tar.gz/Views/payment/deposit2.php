
<?php
   $bmodel = new App\Models\BillingModel();
   $ctype= $bmodel->get_table_details('name_type_tbl');
?>

<div class="section-body mt-4">
    <div class="container-fluid">
             
                <div class="card">
               <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <!-- <th>No.#</th> -->
                                    <th>Deposit No.</th>
                                    <th>Deposit Type</th>
                                    <th>Deposit Date</th>
                                    <th>Customer Name</th>
                                    <th>Name Type</th>
                                    <th>Deposit Amount</th>
                                    <th>CTR NUMBER</th>
                                    <th>sms status</th>
                                    <th>Received By</th>
                                    
                                    <th>Trans Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                 if(count($trans)>0){
                                    foreach($trans as $s){
                                    
                                   // $invoice_type = $bmodel->get_item_join_table($s->trans_number);
                                    $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type' =>3));
                                    $student_name = "";
                                    $student_id = "";
                                    $control_number = "";
                                    $name_type = "";
                                    $amount =0;
                                    if(count($leger_transaction) > 0){
                                        $total_amount = $bmodel->get__amount_payed($s->trans_number,9,3);
                                        if(count($total_amount) > 0)
                                            $amount = $total_amount[0]->amount;
                                        if($leger_transaction[0]->name_type_id == 4){
                                            $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                                            $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                            $student_id = $app[0]->id;
                                            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                            $name_type = $type_name[0]->name_type;
                                            
                                        }
                                        else if($leger_transaction[0]->name_type_id == 3){
                                             $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }else if($leger_transaction[0]->name_type_id == 1){
                                             $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
                                            // echo $s->trans_number;
                                             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }
                                        
                                    

                                    $user = $bmodel->get_item_name('users', $where = array('user_id' => $s->updated_by));

                                    $msg_status = $bmodel->get_item_name('message_groups_tbl', $where = array('trans_number' => $s->trans_number,'message_type'=>5));
                                     if(count($msg_status)>0){
                                         $msg_st = $bmodel->get_item_name('messages', $where = array('send_no' => $msg_status[0]->send_number));
                                         if(count($msg_st)>0){
                                         $del=$msg_st[0]->status_description;
                                         $time=$msg_st[0]->time_delivered;
                                         $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                                         }else{
                                           $stata='<span style="color:red">Not Sent';    
                                         }
                                     }else{
                                       $stata='<span style="color:red">Not Sent';  
                                     }
                                      $ctr="";
                                     $req = $bmodel->get_item_name('payment_request', $where = array('trans_no' => $s->trans_number,'trans_type'=>3));
                                     if(count($req)>0){
                                        $ctr=$req[0]->reference_no;
                                     }else{

                                $adreq = $bmodel->get_item_name('deposit_receipt_tbl', $where = array('deposit_number' => $s->trans_number,));
                                if(count($adreq)>0){
                                  $req = $bmodel->get_item_name('payment_request', $where = array('trans_no' => $adreq[0]->invoice_number,'trans_type'=>1)); 
                                  if(count($req)>0){
                                        $ctr=$req[0]->reference_no;
                                     } 
                                     }
                                       
                                     }

                             $inv_types = $bmodel->get_item_name('invoice_type_transaction', $where = array('trans_no' => $s->trans_number,'transaction_type_id'=>3));
                             $itypes = $bmodel->get_item_name('invoice_types_tbl', $where = array('id' => $inv_types[0]->invoice_type_id));
                             
                             $get_charges = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'ledger_id' =>22,'transation_nature' =>1,'trans_type' =>3));
                       $charged=0;
                       if(count($get_charges)>0){
                        $charged=$get_charges[0]->amount;
                       }

                                ?>
                                <tr>
                                    <td><?php echo $s->trans_number;?></td>
                                    <td><?php echo $itypes[0]->type_name;?></td>
                                    <td><?php echo date('Y-m-d',strtotime($s->trans_date));?></td>
                                     <td><?php echo $student_name;?></td>
                                    <td><?php echo $name_type ?? "";?></td>
                                    <td><?= number_format($amount-$charged); ?></td>
                                    
                                    <td><?php echo $ctr;?></td>
                                    <td><?php echo $stata;?></td>
                                    <td><?= $user[0]->first_name.' '.$user[0]->last_name; ?></td>
                                     <td><?php echo date('Y-m-d H:i',strtotime($s->updated_date));?></td>
                                    <td><a href="javascript:void(0)" onclick="manage_deposi(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"> </i>  Edit</a>
                                    <a href="javascript:void(0)" onclick="manage_deposit(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a>
                                    </td>
                                    
                                </tr>
                            <?php }}}else{
                                echo "<tr><td>Currently there is no record</td></tr>";
                            } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
          
        </div>
   
<div class="modal fade" id="viewreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('viewreceipt_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="viewreceiptxl" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_contentxl">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         
      </div>
    </div>
  </div>
</div>
<script>

    $(document).ready(function () {
      $('#myTable').DataTable();
    });
    
    function printable_rept(area) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=700, height=600, left=100, top=25";
        var content_vlue = document.getElementById(area).innerHTML;

        var docprint = window.open("", "", disp_setting);
           var ns = $('noscript').clone();

        docprint.document.open();
        docprint.document.write('<html><head><title>MHI</title><link rel="stylesheet" href="<?php echo base_url() . 'syst_assets/'; ?>bootstrap/css/bootstrap.css">');
        $('#ReptHeader').load('<?php echo base_url() . 'index.php/Gp_ctrl/load_printable_header'; ?>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
          docprint.document.write(ns.html())
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
  </script>