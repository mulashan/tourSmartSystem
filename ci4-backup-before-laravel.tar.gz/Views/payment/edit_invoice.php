  <link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<style type="text/css">

     .invoice > .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }
.alert {
  font-size: 24px;
  padding: 10px;
  border-radius: 5px;
  animation: colorChange 2s infinite alternate;
}

@keyframes colorChange {
  0% {
    color: red;
  }
  50% {
    color: yellow;
  }
  100% {
    color: red;
  }
}
 </style>
 <?php
  $bmodel = new App\Models\BillingModel();
  $amodel = new App\Models\AdmissionModel();
  $cmodel = new App\Models\ClassesModel();
  $smodel = new App\Models\StudentModel();
  $appItems = $cmodel->get_applications_items();
  $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>1,'ledger_type'=>7));
  $student_name = "";
  $name_type = "";
  $ref="";
  $class_data = '';
  $amount = 0;
  $snn=0;
  $class_name="";
  $account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));
if(count($leger_transaction) > 0){
    $amount = $leger_transaction[0]->amount;
    if($leger_transaction[0]->name_type_id == 4){
        $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;    
             $class_data = $bmodel->get_class_data($leger_transaction[0]->name_id, esc($year));
                                            if($class_data>0){
                                                $class_name = $class_data[0]->class_name .'('.$class_data[0]->stream_name .')';   
                                            } 
    }else if($leger_transaction[0]->name_type_id == 1){
        $admn = $bmodel->get_item_name('students', $where = array('id'=>$leger_transaction[0]->name_id));
        //print_r($admn);
        $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name; 
        $parent = $smodel->gettable_billingdata($admn[0]->id);
        // echo $leger_transaction[0]->name_id;
        // return;
             $class_data = $bmodel->get_class_data($leger_transaction[0]->name_id, esc($year));
            //  print_r($class_data);
            //  return;
                                            if(count($class_data)>0){
                                             $class_name = $class_data[0]->class_name .'('.$class_data[0]->stream_name .')';  
                                            } 
      if(count($parent)>0){
           $phone=$parent[0]->phone1; 
       }else{
        $phone="";
        echo "<div class='alert'>Please fill student billing informations</div>";
       }
        // $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $leger_transaction[0]->name_id));
        $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $leger_transaction[0]->name_id, 'status' => 1));
        $student_id=$leger_transaction[0]->name_id;

           }else if($leger_transaction[0]->name_type_id == 6){
        $admn = $bmodel->get_item_name('other_students_tbl', $where = array('id'=>$leger_transaction[0]->name_id));
        //print_r($admn);
        $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name; 
        $phone=$admn[0]->phone;
        //$parent = $smodel->gettable_billingdata($admn[0]->id);
        // $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $leger_transaction[0]->name_id));
        $admissn = array();
             $class_data = $bmodel->get_class_data($leger_transaction[0]->name_id, esc($year));
                                            if($class_data>0){
                                               $class_name = $class_data[0]->class_name .'('.$class_data[0]->stream_name .')';  
                                            } 
           }
      
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;

        $pay = $bmodel->get_item_name('payment_request',$where = array('student_id' => $admn[0]->id,'trans_no'=>$inv[0]->trans_number));
           $student_id=$leger_transaction[0]->name_id;
        if(count($pay) > 0){
            $ref = $pay[0]->reference_no;
            $amount1 = $pay[0]->amount;
            $student_id=$pay[0]->student_id;
           $msn = $bmodel->get_item_name('message_groups_tbl',$where = array('message_type' => 1,'trans_number'=>$inv[0]->trans_number)); 
           if(count($msn)>0){
            $snn=$msn[0]->send_number;
           }else{
            $snn=0;
           }
        }else{
            //echo $admn[0]->id;
            $pay2 = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('name_id' => $admn[0]->id,'trans_no'=>$inv[0]->trans_number,'transation_nature'=>2));
            
            $amount1 = $pay2[0]->amount;
           
            $id = $leger_transaction[0]->name_id;
            $no = $leger_transaction[0]->trans_no;
            $ref = "**** ";
            // "<div id='control'><a href='javascript:void(0)' onclick='Create_ControlNumber($amount,$id,$no)'  class='btn btn-primary '>Create Control No</a></div>
            // ";
        }
  $name_id=$leger_transaction[0]->name_id??"";  
}
$sno=$inv[0]->trans_number;

 ?>
<div class="row">
    <div id="feedback"></div>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Invoice Information</h5>
            </div>
            </hr>

            <div class="card-body">
               <?php
             $cty= $bmodel->get_table_details('invoice_types_tbl');
             $typeinv = $bmodel->get_item_name('invoice_type_transaction',$where = array('transaction_type_id' => 1,'trans_no'=>$inv[0]->trans_number));
            // echo $typeinv[0]->invoice_type_id;
              ?>
            
               
                <input type="hidden" name="student_id" id="studentid" value="<?= $inv[0]->trans_number;?>">
                <table class="table table-borderless">
                    <tr>
                        <td>Invoice Type</td>
                        <td><select class="form-control form-select" name="invoice_type" id="invoice_type">
                
                <?php foreach($cty as $type): ?>
                    <?php if($typeinv[0]->invoice_type_id==$type->id){?>
                <option value="<?= $type->id ?>" selected><?= $type->type_name; ?></option>
            <?php }else{?>
                <option value="<?= $type->id ?>"><?= $type->type_name; ?></option>
            <?php }?>
                <?php endforeach; ?>
            </select></td>
                    </tr>
                    <tr>
                        <th>Invoice Number:</th>
                        <td><?= $inv[0]->trans_number; ?></td>
                    </tr>
                    <tr>
                        <div  class="cust_popup" id="changeDate" style="display: none">
                                    <h6>Change Date</h6>
                               <input type="date" name="date" id="tdate" class="form-control" value="<?= date("Y-m-d",strtotime($inv[0]->trans_date))?>">
                               <div class="mt-3">
                               <button class="btn btn-danger pull-left" onclick="cancelbtn()">Cancel</button>
                               <button class="btn btn-primary pull-right" onclick="saveDate('<?= $inv[0]->trans_number; ?>')">Change</button>
                               </div>
                               </div>

                        <th>Invoice Date:</th>
                        <td><a href="javascript:void(0);"
                            onclick="updateDate()"><?= $inv[0]->trans_date; ?></a></td>
                    </tr>
                    <tr>
                        <th>Customer Type:</th>
                        <td><?= $name_type; ?></td>
                    </tr>
                    <tr>
                        <th>Student Name:</th>
                        <td><?= $student_name; ?></td>
                    </tr>
                       <tr>
                        <th>Class Name:</th>
                        <td><?= $class_name; ?></td>
                    </tr>
                    
                    <tr>
                        <th>Registration No:</th>
                        <td><?= $admn[0]->id; ?></td>
                    </tr>
                    <tr>
                        <?php if(count($admissn)>0){?>
                        <th>Class Admission N0:</th>
                        <td><?= $admn[0]->student_id.'-'.$admissn[0]->academic_year.'-'.$admissn[0]->class_id; ?></td>
                    <?php }?>
                    </tr>
                      <tr>
                        <th>Academmic Year:</th>
                        <td><?= esc($year); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Payment Information</h5>
            </div>
            </hr>

            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Control  Number:</th>
                        <td id="controlNo"><?= $ref; ?> </td>
                    </tr>
                    <tr>
                        <th>Amount:</th>
                        <td><?= number_format($amount); ?></td>
                    </tr>
                    <tr>
                        <th>Phone No:</th>
                        <td><?= $phone;?></td>
                    </tr>
                    <?php
                        $m = $bmodel->get_invoice_message($leger_transaction[0]->name_id,$inv[0]->trans_number);
                        //echo count($m).'/'.$leger_transaction[0]->name_id.'/'.$inv[0]->trans_number;
                       $msg = "";
                       if($amount >0){
                           if($typeinv[0]->invoice_type_id==8){
                            $open_year=date('Y', strtotime($inv[0]->trans_date));
                              $msg="Kumb No: ".$ref.",Kiasi:TZS ".number_format($amount).", Deni la nyuma ".($open_year-1).", Mwanafunzi: ".$student_name.".". "Tafadhali Fanya Malipo Kupitia CRDB.";
                           }else{
                             $msg="Kumb No: ".$ref.",Kiasi:TZS ".number_format($amount).", Mwanafunzi: ".$student_name.".". "Tafadhali Fanya Malipo Kupitia CRDB.";
                           }
                           
                        }else{
                          $msg="Kumb No: ".$ref.",Kiasi:TZS ".number_format($amount).", Mwanafunzi: ".$student_name.".";  
                        }
                         if(count($m) > 0){
                            // $msg = $m[0]->message;
                            // $msg= str_replace(array("\r","\n"),' ',$msg);
                          //  echo $phone.'/'.$msg.'/'.$student_id.'/'.$snn.'/'.$inv[0]->trans_number;
                   ?>
                    <tr>
                        <th>Invoice MSG:</th>
                        <td><textarea class="form-control" name="msg" readonly><?= $msg; ?></textarea></td>
                    </tr>
                    <tr id="invoicetmsg">
                       <th >Message status:<br>
                       <a href="#"
   class="btn btn-primary resend-sms"
   data-phone="<?= esc($phone, 'attr'); ?>"
   data-msg="<?= esc($msg, 'attr'); ?>"
   data-type="1"
   data-student="<?= esc($student_id, 'attr'); ?>"
   data-snn="<?= esc($snn, 'attr'); ?>"
   data-trno="<?= esc($inv[0]->trans_number, 'attr'); ?>">
   <i class="fa fa-rotate-left"></i> Resend SMS
</a>

                       </th>
                        <td id="newstatus">
                           <?php if( $m[0]->sent_status == 1) {?>
                           <i>Sent date:<?php echo date("d-m-Y H:i:s",$m[0]->created_at); ?> 
                             <br>Status: <?php echo $m[0]->status_description; ?>
                             <span class="pull-right">
                             <button type="button" onclick="checksmsstatus('<?php echo $m[0]->message_id; ?>','invoicetmsg')" class="btn btn-success btn-sm pull-left"><i class="fa fa-refresh"></i></button>
                                         &nbsp;&nbsp;<button type="button" onclick='PaymntResndSMSform("PaymntResndForm","invoicetmsg")' class='btn btn-primary btn-sm'>Resend</button></span>
                             <script>
                                $(function() {
                                    checksmsstatus('<?php echo $m[0]->message_id; ?>','invoicetmsg');
                                 });
                             </script>
                             <?php }elseif( $m[0]->sent_status == 2){ ?>
                                  <i>Sent Date:<?php echo $m[0]->time_sent; ?> 
                                  <br>Status: <?php echo $m[0]->status_description; ?>
                                  <br>Delivered Date:<?php echo $m[0]->time_delivered; ?>       
                             <?php } ?> 
                        </td>            
                    </tr>
                                
                     <?php }else{ ?>
                    <tr>
                        <th>Invoice MSG:</th>
                        <td><textarea class="form-control" name="msg" ><?= $msg;?></textarea> </td>
                    </tr>
                    <tr >
                       <th>Message status:</th>
                        <td>
                            <i class="text-warning">Not Sent</i>
                        </td></tr>
                        <tr>

                        <td>
                            <!--<a href="javascript:void(0)" onclick="resendSMS('<?=$phone;?>','<?= $msg; ?>','1','<?= $student_id; ?>','<?= $snn; ?>','<?= $inv[0]->trans_number; ?>')"  class="btn btn-primary "><i class="fa fa-rotate-left"></i> Resend SMS</a>-->
                            <a href="#"
   class="btn btn-primary resend-sms"
   data-phone="<?= esc($phone, 'attr'); ?>"
   data-msg="<?= esc($msg, 'attr'); ?>"
   data-type="1"
   data-student="<?= esc($student_id, 'attr'); ?>"
   data-snn="<?= esc($snn, 'attr'); ?>"
   data-trno="<?= esc($inv[0]->trans_number, 'attr'); ?>">
   <i class="fa fa-rotate-left"></i> Resend SMS
</a>

                        </td> 
                    </tr>
                     <?php } ?>
                    <!-- <tr>
                        <th>Message Status:</th>
                        <td></td>
                    </tr> -->
                    <tr>
                        <th></th>
                        <td>
                            <?php 
                          if($snn!=0){
                            ?>
                            
                            <?php
                              //echo $student_id.'</br>';
                             }
                            ?>

                        </td>
                    </tr>
                 <?php if(count($pay)>0){
                      if($pay[0]->paid_charges==0){
                      if($pay[0]->allow_partial==0){
                        $allowed="Fixed";
                        $all=0;
                      }elseif($pay[0]->allow_partial==1){
                         $allowed="Flexible";
                          $all=1;
                      }else{
                         $allowed="Undefined";
                      }
                    ?>
                   
                    <tr>
                    <th>Ctr Number Type</th><td><?= $allowed;?>
                        <a href="javascript:void(0)" onclick="changeControlType('<?php echo $all;?>','<?= $pay[0]->id;?>')"  class="btn btn-primary "><i class="fa fa-rotate-left"></i> Change</a>
                    </td>  
                       
                    </tr>
                <?php }}?>
                    <tr>

                        <!-- <th>Payment Type</th>
                         <td>
                          <select class="form-select" style="display:none;">
                           <option>Flexible</option>   
                          </select>  
                        </td> -->
                    </tr>
                </table>
            </div>
        </div>
    </div>
   
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card  invoice">
            <div class="card-header">
                <h5>Charged Items</h5>
            </div>
            </hr>

            <div class="card-body">
                <form class="form-horizontal" id="add_Item">
                    <div class="form-group row mb-5">
                        <label class="col-sm-2 col-form-label">Add Charged Items<span class="text-danger">*</span></label>
                        <div class="col-sm-6">
                            <select class="form-select form-control" id="itemselect" style="width:100%;"></select>
                        </div>
                        <div class="col-sm-2">
                            <input type="number" id="qtty" class="form-control" min="1">
                            <input type="hidden" name="transNo" value="<?= $inv[0]->trans_number; ?>">
                            <input type="hidden" name="nameid" value="<?= $leger_transaction[0]->name_id;?>">
                        </div>
                        <div class="col-sm-2">
                            <button type="submit" class="btn btn-primary" id="add_invoiceItem"><i class="fa fa-plus"></i> Add Item</button>
                        </div>
                    </div>
                    <!-- <div class="form-group row">
                        <label class="col-md-2 col-form-label">Account Receivable<span class="text-danger">*</span></label>
                        <div class="col-md-8">
                            <select name="account" id="accounts" class="form-control">
                                <option value="">--Select Account Receivable--</option>
                                <?php foreach ($account as $ac): ?>
                                    <option value="<?php //echo $ac->id; ?>"><?php //echo $ac->account_name; ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div> -->
                    <!-- <div class="row">
                        <div class="col-sm-2 offset-9">
                            <button type="submit" class="btn btn-primary" id="add_invoiceItem"><i class="fa fa-plus"></i> Add Item</button>
                        </div>
                    </div> -->
                </form>
                <p class=" d-flex justify-content-start mt-3 ms-3"><b>CHARGED ITEMS</b></p>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Item Id</th>
                            <th>Item Name</th>
                            <th>Trans Comment</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th>Amount</th>
                            <th>Ledger</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="invoiceItem">
                         
                         <?php
                      $dbname=session()->get('db_name');
                    $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;
                        $query = $db->query('SELECT item_transation_tbl.item_id,item_name,account_name,trans_number,quantity,unit_price,item_group FROM item_transation_tbl,items_tbl,items_ledgers_tbl,accounts_tbl where item_transation_tbl.item_id = items_tbl.id AND items_ledgers_tbl.item_id = items_tbl.id AND item_transation_tbl.trans_type = 1 AND accounts_tbl.id = items_ledgers_tbl.account_id AND (account_type_id = 3 OR account_type_id = 4) AND trans_number='.$inv[0]->trans_number);
                        $result = $query->getResult();
                       //  print_r($result);
                        foreach($result as $itm){

                            $dat = $amodel->get_trans_type($inv[0]->trans_number);
                             $query2 = $db->query('SELECT type_name,amount FROM ledger_transaction_tbl,account_types_tbl where ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_transaction_tbl.trans_type = 1 AND (ledger_type = 3 OR ledger_type = 4) AND trans_no='.$inv[0]->trans_number);
                             $result2 = $query2->getResult();
                             $amount = $itm->quantity * $itm->unit_price;
                             if($itm->item_group==7){
                            $total -= $amount;
                             }else{
                            $total += $amount;
                             }
                              
                            ?>
                         <tr>
                             <td><?= $itm->item_id; ?></td>
                             <td><?= $itm->item_name; ?></td>
                             <td></td>
                             <td><?= $itm->quantity; ?></td>
                             <td>
                                <div  class="cust_popup" id="cash<?php echo $itm->item_id;?>" style="display: none">
                                    <h6>Change price</h6>
                                <div id="prcres<?php echo $itm->item_id;?>"></div>
                                     
                               </div>
                                 <a class="cost2" id="cost<?= $itm->item_id; ?>" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getid(<?= $itm->item_id; ?>,<?php echo $itm->unit_price;?>,<?=$inv[0]->trans_number;?>)"><input type="text" value="<?=number_format($itm->unit_price); ?>" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:70px;text-align:right;" id="prc<?php echo $itm->item_id;?>" readonly></a>
                             </td>
                             <td id="">
                                 <input type="text" value="<?=number_format($itm->quantity*$itm->unit_price); ?>" style="border:none;cursor:pointer;width:70px;text-align:right;" id="ttotal<?php echo $itm->item_id;?>" readonly>
                             </td>
                             <td><?= $itm->account_name; ?></td>
                            <td id="deletebtn<?= $itm->item_id;?>">
                                <a href="javascript:void(0)" class="btn-danger btn-sm"><i class="fa fa-trash"  onclick="Remove_item(this,<?= $itm->item_id;?>,<?= $admn[0]->id;?>,<?= $inv[0]->trans_number;?>,<?=$itm->quantity*$itm->unit_price;?>)" ></i></a>
                            </td>
                         </tr>
                    <?php } ?>
                            <tr>
                                <td colspan="5"></td>
                                <td colspan="3"><b id="item_total"> <input type="text" value="<?=number_format($total); ?>" style="border:none;cursor:pointer;width:70px;text-align:right;" id="total" readonly></b></td>
                            </tr>
                    </tbody>
                </table>

            </div>
            <?php
              $account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));
              $que = $db->query('SELECT ledger_id,account_name,amount FROM ledger_transaction_tbl,accounts_tbl where ledger_transaction_tbl.ledger_type = accounts_tbl.account_type_id AND ledger_transaction_tbl.ledger_id = accounts_tbl.id AND ledger_transaction_tbl.trans_type = 1 AND ledger_type = 7 AND trans_no='.$inv[0]->trans_number);
                $acc = $que->getResult();
                // print_r($acc);
                // return;

               
            ?>
                <br>
                              <div class="form-group row">
                                 <div class="col-md-3">

                                 </div>
                                <label class="col-md-2 col-form-label">Account Receivable<span class="text-danger">*</span></label>
                             

                                <div class="col-md-5">
                                    <select name="account_edit" id="account_edit" class="form-control" required="required">
                                        <option value="">-choose-</option>
                                        <?php foreach ($account as $ac): ?>
                                            <?php
                                        if(count($acc) > 0 && $ac->id==$acc[0]->ledger_id){
                                            ?>
                                        <option value="<?= $ac->id; ?>" selected><?= $ac->account_name; ?></option>
                                        <?php
                                           }else{
                                            ?>
                                            <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                        <?php } endforeach ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                 <div class="col-md-3">

                                 </div>
                                <label class="col-md-2 col-form-label">Amount<span class="text-danger"></span></label>
                              <div class="col-md-5">

                                 <!--------------popup---------------------->
                                <div  class="cust_popup" id="receivablePopup" style="display: none">
                                    <h6>Change Receivable</h6>
                                <div id="receivableAmount"></div>
                                     
                               </div>
                               <!------------------------------------>
                               <?php
                               if(count($acc)>0){
                                  echo number_format($acc[0]->amount);  
                               }else{
                                   echo number_format($total);
                               }
                               
                               ?>
                            
                              </div>
                              </div>
                            <?php
                            $pjid=0;
                            $pj = $amodel->get_student_details('projects_tbl', $where = array('status' => 1));

                            if($typeinv[0]->invoice_type_id==7){
                            $pjtsc = $amodel->get_student_details('project_transaction_tbl', $where = array('trans_numba' => $inv[0]->trans_number,'trans_type'=>1));
                            $pjtb = $amodel->get_student_details('projects_tbl', $where = array('id' => $pjtsc[0]->project_id));
                            $pjid=$pjtb[0]->id;
                            //echo $pjid;
                            }
                            ?>
                            <div class="form-group row" id="ProjectEdit" style="display:none">
                                <div class="col-md-3">

                                 </div>
                                <label class="col-md-2 col-form-label">Projects<span class="text-danger">*</span></label>
                                <div class="col-md-5">
                                    <select name="projectEdit" id="projectEdit" class="form-control" required="required">
                                        <option value="0">-Select project-</option>
                                        <?php foreach ($pj as $ac): ?>
                                            <?php if($pjid ==$ac->id){?>
                                               <option value="<?= $ac->id; ?>" selected><?= $ac->project_name; ?></option>
                                            <?php }else{?>
                                            <option value="<?= $ac->id; ?>"><?= $ac->project_name; ?></option>
                                        <?php }?>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                            </div>
        </div>


                <button type="button" class="btn btn-primary float-right" onclick="UpdateInvoice(<?= $inv[0]->trans_number;?>,<?= $leger_transaction[0]->name_id;?>)"><i class="fa fa-save"></i> Update</button>
    </div>
</div>

<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script>
    $(document).ready(function(){

        $('#itemselect').select2({
            ajax: {
                url: "<?= base_url('load_data'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

        $('#itemselect').on('select2:select', function (e) {
            selectedItems();
        });
             
        function selectedItems(){  
            var rows = '';
           var itemData = 'item_selected='+$('#itemselect').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Itemdata')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }  
           });  
        }

    });
    var id = $('#studentid').val();
    $('#invoicePrint_content').load('print_invoice/'+id);
    // function printable_rept(inv){
    //     // alert('hello')
    //   $('#invoiceprint').modal('show'); 
    //   $('#invoicePrint_content').load('print_invoice/'+inv);
    // }


     function PaymntResndSMSform(formId,divhtml) {
          $.ajax({
            beforeSend: function () {
                $('#'+ divhtml).html('<i class="fa fa-spinner fa-spin"></i> Sending Message..');
            },
            type: "POST",
            url: '<?php //echo base_url() . '/index.php/StudentController/resend_sms'; ?>',
            data: $('#'+formId).serialize(),
            success: function (result) {
              //  alert(result);
                $('#'+ divhtml).html(result);             
            },
            error: function () {
                $('#'+divhtml).html('Sorry! Something went wrong.');
            }
        });
    }
    function checksmsstatus(id,divhtml){
     var data = "id=" + id;
         $.ajax({
            beforeSend: function () {
                $('#'+divhtml).html('<i class="fa fa-spinner fa-spin"></i> Checking sms status..');
            },
            type: "POST",
            url: '<?php echo base_url() . '/index.php/StudentController/check_sms'; ?>',
            data: data,
            success: function (result) {
                // $('#notsent').remove();
                $('#'+divhtml).html(result);             
            },
            error: function () {
                $('#'+divhtml).html('Sorry! Something went wrong.');
            }
        });
    }

    $('#add_invoiceItem').click(function(e){
        e.preventDefault();
        var items = $('#invoiceItem');
        var data = "item=" + $('#itemselect').val() + "&quantity=" + $('#qtty').val()+ '&id=' + $('input[name=nameid]').val()+ '&trans=' + $('input[name=transNo]').val();
        var invID = "<?php echo $inv[0]->id;?>";
        var year = "<?php echo $year;?>";
        // alert(data);
        // return;
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/add_invoice_item'; ?>',
            data: data,
            dataType: "json", 
            success: function(res){
               // console.log(res)
                $('#view_details').load('invoice_details/'+invID+'/'+year);
               
            }
        });
    });

$(document).on('click', '.resend-sms', function (e) {
    e.preventDefault();

    const phone = $(this).data('phone');
    const msg = $(this).data('msg');
    const type = $(this).data('type');
    const ref = $(this).data('student');
    const snn = $(this).data('snn');
    const trno = $(this).data('trno');

    resendSMS(phone, msg, type, ref, snn, trno);
});
  function resendSMS(phone,msg,type,ref,snn,trno){
            const message = encodeURIComponent(msg);
        var data = 'trno=' + trno+'&snn='+snn;
        // alert(data);
         var response=1;
         // alert(data);
         // return;
         swal({
            title: "Are you sure?",
            text: "To resend this message "+msg+" to "+phone,
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, update!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },
          function(isConfirm) {
            if (isConfirm) {
               
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/SMSsender/'; ?>' + phone +'/'+ message +'/' + type +'/' + ref+'/' + snn+'/'+response,
             data:data,
            success: function(res){
                //console.log(res)
                swal('success','Message sent successfully','success');
               
            },
             error:function(res){
               swal('error','Message not sent','error');
            }
        });
    }else{
        swal('Cancelled');
    }}
    );
    }

    function Create_ControlNumber(total,stdID,transNo)
    {
        var data = 'total=' + total + '&id=' + stdID + '&no=' + transNo;
        // alert(data)
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/recreate_control_number/'; ?>' + total +'/'+ stdID +'/' + transNo,
            success: function(res){
                console.log(res)
               $('#controlNo').html(res);
            }
        });   
    }

    function Remove_item(root,itemID,stdID,transNo,price){
       var data = 'item=' + itemID + '&student=' + stdID + '&transNo=' + transNo+ '&price=' + price;
        var invID = "<?php echo $inv[0]->id;?>";
         var year = "<?php echo $year;?>";
         $('#deletebtn'+itemID).html('<span class="fa fa-spin fa-spinner text-red"></span>Please Wait...');
         //alert(data);
         $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/Remove_invoicedItem'; ?>',
            data: data,
            success: function(){
                 $('#deletebtn'+itemID).html('<span class="fa fa-tick text-green">Deleted</span>');
            $('#view_details').load('invoice_details/'+invID+'/'+year);
            
    //      root.parentElement.parentElement.parentElement.remove();
    //   var sum=parseInt($("#total").val().replace(/,/g, ""));
    //       sum-=price;
    //      document.querySelector('[id="total"]').value = sum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            }
        });
    }

    function UpdateInvoice(transNo,nameID)
    {
        var data = 'trans=' + transNo + '&sID=' + nameID+ '&pid=' + $('#projectEdit').val()+'&invoice_type='+$('#invoice_type').val()+'&total='+'<?php echo $total;?>';
          //alert(data);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/update_invoice'; ?>',
            data: data,
            success: function (res) {
                console.log(res);
                var data = JSON.parse(res);

                if(data['status'] == "0"){
                    $('#invoiceview').modal('hide'); 
                    swal('success','Invoice Updated successfully','success');
                }else{
                     swal('warning','Sorry! Something went wrong!','warning');
                    // $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            }
        });
    }
        var sumVal=0; 
        var prc;  
function getid(id,prc,sno) {
     var price=$('#prc'+id).val().replace(/,/gi, "");
   //  alert(price);
     $('#cash'+id).toggle(100);
     
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/ivoice_popup'; ?>/"+id,
            beforeSend: function () {
                $('#prcres'+id).html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#prcres'+id).html(result);
                console.log(prc);
             document.querySelector('[id="cash_amt'+id+'"]').value = price;
             document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }
       function savebtn(){
         //var price=$('#prc'+id).val().replace(/,/gi, "");
   //  alert(price);
        var sno=<?php echo $sno;?>;
        var nameID=<?php echo $name_id;?>;
     // alert(nameID);
        totalsum=0;
      
      var item_id=$('#item_id').val();
      var cash=parseInt($('#cash_amt'+item_id).val());
      //alert(cash);
      var price=$("#ttotal"+item_id).val();
      var number = parseInt(price.replace(/,/g, ""));
      //var sum=parseInt(<?php echo $total;?>);
      var sum=parseInt($("#total").val().replace(/,/g, ""));
      //alert('price='+number+'/sum='+sum+'/cash='+cash);
     if(item_id==64){
      sum=(sum+number)-cash;
      }else{
         sum=(sum+cash)-number;
      }
       //alert(sum);
       var data = 'trans=' + sno + '&sID=' + nameID + '&itemID=' + item_id + '&cash=' + cash;
         // alert(data);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/update_invoice_item'; ?>',
            data: data,
            success: function (res) {
                //console.log(res);
              //  var data = JSON.parse(res);

                if(res){
                     $('#cash'+item_id).hide();
                 $('#view_details').html(res);
                  // document.querySelector('[id="prc'+item_id+'"]').value = cash.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                  // document.querySelector('[id="ttotal'+item_id+'"]').value = cash.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                 
                  // document.querySelector('[id="total"]').value = sum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                     
                   //$('#invoiceprint').modal('hide'); 
                }else{
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Item Price Not Updated</div>');
                }
            }
        }); 
    }

      $('#account_edit').change(function(){
      
        var data = 'trans=' + '<?php echo $inv[0]->trans_number ?>'+'&ledger_id='+$('#account_edit').val();
        // alert(data);

        $.ajax({
            type:'POST',
           url: '<?php echo base_url() . '/index.php/AdmissionController/update_invoice_account'; ?>',
            data:data,
            success:function(res){
             
             }
        });
    });
      $("#invoice_type").change(function(){
    if($("#invoice_type").val()==7){
        $('#ProjectEdit').show();
    }else{
     $('#ProjectEdit').hide();
    }
       
    });

      var type='<?php echo $typeinv[0]->invoice_type_id; ?>';
      if(type==7){
         $('#ProjectEdit').show(); 
     }else{
         $('#ProjectEdit').hide();
     }

     function changeControlType(id,payid){
      //  alert(payid);
       if(id==0){
        var allw="Flexible";
        var al=1;
       }
       if(id==1){
        var allw="Fixed";
        var al=0;
       }
        swal({
            title: "Are you sure?",
            text: "To change Control number type to "+allw,
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, update!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
               url: '<?php echo base_url() . '/index.php/AdmissionController/updateControlType'; ?>/'+al+'/'+payid,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                     if(data==1){
                         $('#invoiceview').modal('hide'); 
                    swal("success", "Updated successfully.", "success");
                    }else{
                       swal("error", "Failed to update.", "error");  
                    }
                   // location.reload();
                      
                 }
              });

            } else {
               swal("Cancelled");
            }

          });
     }
     
      function updateDate(){
    
     $('#changeDate').toggle(100);
     }
     function cancelbtn(){
          $('#changeDate').hide();
     }
     
      function saveDate(inv){
           var dt=$('#tdate').val();
            $.ajax({
               url: '<?php echo base_url() . '/index.php/AdmissionController/updateInvDate'; ?>/'+inv+'/'+dt,
                 error: function() {
                    toastr.error('Something is wrong','error');
                 },
                 success: function(data) {
                     if(data==1){
                        
                    toastr.success("Updated successfully.", "success");
                    }else{
                       toastr.error("Failed to update.", "error");  
                    }
                   $('#changeDate').hide();
                      
                 }
              });

     }

     function changeReceivable(prc) {
     var price=$('#receivableId').val().replace(/,/gi, "");
    // alert(price);
     $('#receivablePopup').toggle(100);
     
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/recevable_edit'; ?>/"+id,
            beforeSend: function () {
                $('#receivableAmount').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#receivableAmount').html(result);
                //console.log(prc);
             document.querySelector('[id="receivable_amount"]').value = price;
            // document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }

    function editReceivable(){
    var amount=parseInt($('#receivable_amount').val());
   // alert(amount);
    var sno=<?php echo $sno;?>;
        var nameID=<?php echo $name_id;?>;
  var data = 'trans=' + sno + '&sID=' + nameID + '&amount=' + amount+'&trans_type='+1;

 $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/update_receivable'; ?>',
            data: data,
            success: function (res) {
                console.log(res);
                var data = JSON.parse(res);

                if(res){
                  document.querySelector('[id="receivableId"]').value = amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                  toastr.success("Receivable Updated successfully.", "success");
                     $('#receivablePopup').hide(); 
                   
                }else{
                   // $('#feedback').html('');
             toastr.error("Failed to update receivable.", "error"); 

                }
            }
        }); 
    }
</script>    
   