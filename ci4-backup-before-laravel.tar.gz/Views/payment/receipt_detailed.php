 <?php
  $dbname=session()->get('db_name');
 $db = \Config\Database::connect($dbname);
  $bmodel = new App\Models\BillingModel();
  $cmodel = new App\Models\ClassesModel();
  $appItems = $cmodel->get_applications_items();
  $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'trans_type' =>2,'transation_nature' =>1));
  
   $bank_charges = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'trans_type' =>2,'ledger_id' =>22,'transation_nature' =>1));
  $chargesb=0;
if(count($bank_charges) > 0){
  $chargesb=$bank_charges[0]->amount;  
}

  $invoice_type = $bmodel->get_item_join_table($recpt[0]->trans_number);
  $student_name = "";
  $name_type = "";
   $channel=[];
   $ttamount=0;
   // print_r($leger_transaction);
   // return;
if(count($leger_transaction) > 0){
    
      $total_amount = $bmodel->get_total_amount_payed2($recpt[0]->trans_number,9);
if(count($total_amount) > 0){
foreach($total_amount as $tv){
   if($tv->ledger_type==7){
    }else{
    $ttamount += $tv->amount;
    }
   }
    }
    $orgamount=$ttamount-$chargesb;
    
    $amount = $leger_transaction[0]->amount;
    if($leger_transaction[0]->name_type_id == 4){
        $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $itm_details = $bmodel->get_item_name('item_transation_tbl',$where = array('trans_number' =>$recpt[0]->trans_number,'trans_type'=>2));
        
    } else if($leger_transaction[0]->name_type_id == 3){
    $app = $bmodel->get_item_name('others_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
     $student_name = $app[0]->customer_name; 
      $student_id = $app[0]->id;
       $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
            $name_type = $type_name[0]->name_type;
              $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2));
   }
    else if($leger_transaction[0]->name_type_id == 5){
    $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
     $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
      $student_id = $app[0]->id;
       $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
            $name_type = $type_name[0]->name_type;
              $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2));
   }else if($leger_transaction[0]->name_type_id == 1){
        $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        
        $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2,'transation_nature' =>1));
   }else if($leger_transaction[0]->name_type_id == 6){
        $app = $bmodel->get_item_name('other_students_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        
        $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2,'transation_nature' =>1));
   }
    $control_number="";
     if($leger_transaction[0]->name_type_id == 4){
 $control_no = $bmodel->get_item_name('payment_request',$where = array('student_id' =>$app[0]->id,'trans_no'=>$app[0]->id,'trans_type'=>1));

            }else{
    $inv_no = $bmodel->get_item_name('transactions_relation',$where = array('receipt_trans_no' =>$recpt[0]->trans_number));
    if(count($inv_no)>0){
    $control_no = $bmodel->get_item_name('payment_request',$where = array('student_id' =>$app[0]->id,'trans_no'=>$inv_no[0]->invoice_trans_no));
        }elseif(count($inv_no)==0){
         $control_no = $bmodel->get_item_name('payment_request',$where = array('student_id' =>$app[0]->id,'trans_no'=>$recpt[0]->trans_number,'trans_type'=>2));

        }
    }
    $amount_payed = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 9,'trans_type' =>2,'transation_nature' =>2));
     if(count($amount_payed) >0){
    if(count($control_no) > 0){
    $control_number = $control_no[0]->reference_no;

   $channel = $bmodel->get_item_name('payment_response',$where = array('reference_no' => $control_number,'amount_payed'=>$amount_payed[0]->amount,'transaction_date'=>$recpt[0]->trans_date));

    if(count($channel)>0){
     $chann=$control_no[0]->payment_channel;
     $channel_name=$channel[0]->transaction_channel;
     $cus_name=$channel[0]->customer_name;
     if($chann==2){
        $ch="NMB-".$channel_name;
     }else{
        $ch="CRDB-".$channel_name;
     }
 }
    }
     }else{
      $channel=[];   
     }
    $company_reg = $bmodel->get_table_details('company_tbl');
 //   $pay_dtls = $bmodel->get_item_name('payment_response',$where = array('reference_no' =>$control_number));
   
   
}

 ?>
<div class="row">
<div class="col-md-12">
    <!-- <center><b style="font-size:14px"><u>RECEIPT</u></b></center> -->
    <center>
        <?php
        if(count($company_reg)>0){
          $logo=$company_reg[0]->logo_name;  
        }else{
           $logo=""; 
        }
        ?>
      <div> <img src="<?php  echo base_url('public/company_photos/'.$logo) ?>" style="background: white;width: 25%;height: 25%"></div>
 <span class="mt-4"><b><?= $company_reg[0]->company_name??""; ?></b></span><br>
            <span class="modify" style="font-size:15px"><?= $company_reg[0]->address??""; ?></span>
            <div class="mb-3">
                <div><span class="modify" style="font-size:15px">Phone: +<?= $company_reg[0]->phone1??""; ?></span></div>
                <div><span class="modify" style="font-size:15px">Email: <?= $company_reg[0]->email??""; ?></span></div>
                <div><span class="modify" style="font-size:15px"> <?= $company_reg[0]->website??""; ?></span></div>
             
            </div>
   <span class="mt-3"> <b style="font-size:14px"><u>RECEIPT</u></b></span>
    </b>
</center>
<?php
   helper('class');
$reltn = $bmodel->get_item_name('transactions_relation',$where = array('receipt_trans_no' =>$recpt[0]->trans_number));
$leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'trans_type' =>2,'transation_nature' =>1));
    $class="";
    if(count($reltn)>0){
    $class=getClass($reltn[0]->invoice_trans_no,$leger_transaction[0]->name_type_id,$recpt[0]->trans_number);
    }
?>
    <hr>
    <table class="table table-borderless">
        <tr>
            <th>Receipt Number:</th>
            <td><?= $recpt[0]->trans_number; ?></td>
        </tr>
        <tr>
            <th>Receipt Date:</th>
            <td><?= $recpt[0]->trans_date; ?></td>
        </tr>
        <tr>
            <th>Paid by:</th>
            <td><?= $name_type; ?></td>
        </tr>
        <tr>
            <th>Payer Name:</th>
            <td><?= $student_name; ?></td>
        </tr>

         <tr>
            <th>Class:</th>
            <td><?= $class; ?></td>
        </tr>
    </table>
    <hr>
</div>
</div>    
    <div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
        <p class=" d-flex justify-content-center mt-3" style="font-size:18px">RECEIPT DETAILS</p>
        <?php 
          $sales_receipt = $bmodel->get_item_name('receipt_type_transaction_tbl',$where = array('transNumber' =>$recpt[0]->trans_number,'receipt_type'=>2));

        if($leger_transaction[0]->name_type_id == 4){ ?>
            
            <table class="table">
                <thead>
                    <tr>
                        <th>REF TYPE</th>
                        <th>APPL NO</th>
                        <th>AMOUNT</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                   
                    $total = 0;
                    foreach($itm_details as $itm){
                        $total+=$itm->unit_price;
                    ?>
                <tr>
                    <td><?php echo "Application";?></td>
                    <td><?= $student_id; ?></td>
                    <td><?= number_format($itm->unit_price);?></td>
                </tr>
                <?php } ?>
                 <tr>
                     <td colspan="2"><b>Total</b></td>
                    <th><b><?= number_format($total); ?></b></th>
                </tr>   
            </tbody>
        </table>    
                <?php } else if(count($sales_receipt)>0){ ?>
        
         <table class="table table-condensed" width="80%">
            <thead> 
                <tr>
                    <th>Item</th>
                    <th>Item Name</th>
                    <th  style="text-align:right">Qty</th>
                    <th  style="text-align:right">Price</th>
                    <th  style="text-align:right">Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $total =0;
           $query = $db->query('SELECT item_id,item_name,item_group,trans_number,quantity,unit_price,invoice_type_id FROM item_transation_tbl,items_tbl,invoice_type_transaction where item_transation_tbl.item_id = items_tbl.id AND invoice_type_transaction.trans_no=item_transation_tbl.trans_number AND transaction_type_id = 2 AND trans_type=2 AND trans_number='.$recpt[0]->trans_number);
                    $result = $query->getResult();
                foreach($result as $itm){
                         $query2 = $db->query('SELECT amount FROM ledger_transaction_tbl where transation_nature=1 AND trans_type=2 AND trans_no='.$recpt[0]->trans_number);
                         $result2 = $query2->getResult();

                         $amount = $itm->quantity * $itm->unit_price;
                       if($itm->item_group==7){
                        $total -= $amount;
                          }else if($itm->invoice_type_id==8){
                        $openingbalance+=$amount;
                          }
                          else{
                            $total += $amount;
                          }
                        
                       

                       

                ?>
                    <tr>
                     <td><?= $itm->item_id; ?></td>
                     <td><?= $itm->item_name; ?></td>
                     <td align="right"><?= $itm->quantity; ?></td>
                     <td align="right"><?= number_format($itm->unit_price); ?></td>
                     <td align="right"><?= number_format($amount); ?></td>
                 </tr>
            <?php } ?>
             <tr align="center">
                         <td><b>TOTAL</b></td>

                         <td colspan="3"></td>

                        <td colspan="3" align="right"><b><?php echo number_format($total); ?></b></td>
                    </tr>
            </tbody>
        </table>


                  

                  <?php
                 } else if($leger_transaction[0]->name_type_id == 1){?>
                    <table class="table">
                    <thead>
                        <tr>
                            <th>INV TYPE</th>
                            <th>INV NO</th>
                            <th>INV NAME</th>
                            <th>Inv Amount</th>
                            <th>Amount Due</th>
                            <th>Amount Paid</th>
                        </tr>
                    </thead>
                    <tbody>
                   <?php
                            $total = 0;
                            $i=0;
                           // print_r($ledger_invoice);
                            foreach($ledger_invoice as $itm){
                                
                                $invamount = 0;
                                $name = $bmodel->get_item_name('students',$where = array('id' =>$itm->name_id));
                                $trans_type = $bmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>$itm->trans_type));
                                 $invoice_type = $bmodel->get_item_name('invoice_type_transaction',$where = array('trans_no' =>$itm->trans_no,'transaction_type_id'=>2));

                                 $type_name = $bmodel->get_item_name('invoice_types_tbl',$where = array('id' =>$invoice_type[$i]->invoice_type_id));
                                 
                                $get_invoice = $bmodel->get_item_name('transactions_relation',$where = array('receipt_trans_no' =>$itm->trans_no));
                                $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('id' =>$get_invoice[$i]->invoice_trans_no,'trans_type'=>2));
                                $invoice_transno = $bmodel->get_item_name('transactions_relation',$where = array('receipt_trans_no' =>$itm->trans_no));
                                 $ledger_invoice_ttl = $bmodel->get_total_amount_payed($invoice_transno[$i]->invoice_trans_no, 7);
                              //   print_r($ledger_invoice_ttl);return;
                                    $total+=$itm->amount;
                                 
                               // if(count($ledger_invoice_ttl) > 0){
//                                    foreach($ledger_invoice_ttl as $legerttl){
//                                         $invamount +=$legerttl->amount;
//                                    }
                             //   }
                            ?>
                            <tr>
                                <td><?= $type_name[0]->type_name; ?></td>
                                <td><?= $invoice_transno[$i]->invoice_trans_no; ?></td>
                                <td><?= $name[0]->full_name; ?></td>
                                <td class="text-right"><?= number_format($ledger_invoice_ttl[0]->amount); ?></td>
                                <td class="text-right"><?= number_format($ledger_invoice_ttl[0]->balance);?></td>
                                <td class="text-right"><?= number_format($itm->amount);?></td>
                            </tr>
                   <?php 
                 $i++;
               } 
            $query = $db->query('SELECT amount,account_name,ledger_id,trans_item FROM ledger_transaction_tbl,accounts_tbl where ledger_transaction_tbl.ledger_id = accounts_tbl.id AND transation_nature = 2 AND ledger_id = 21 AND trans_type=2  AND trans_item >0 AND trans_no='.$recpt[0]->trans_number);
                     $result = $query->getResult();
                    if(count($result)>0){
                        $total=$total+$result[0]->amount;
                    
               ?>
                <tr>
                     <td colspan="3"><?php echo $result[0]->account_name;?></td>
                    <th><b></b></th>
                    <th><b></b></th>
                    <th><?= number_format($result[0]->amount); ?></th>
                </tr>
            <?php 
                }
            ?>
                 <tr>
                     <td colspan="3"><b>Total</b></td>
                    <th><b></b></th>
                    <th><b></b></th>
                    <th><b><?= number_format($total); ?></b></th>
                </tr>   
            </tbody>
        </table>
       <?php } ?>
    <!--</div>-->
    </div>
    </div> 
    <?php
    $pname=array();
    if($control_number!=""){
      $pname = $bmodel->get_item_name('payment_response',$where = array('reference_no' =>$control_number));  
    }
 
    ?>  
<div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
        <p class=" d-flex justify-content-center mt-3" style="font-size:18px">PAYMENT DETAILS</p>
        <table class="table">
            <thead>
                <tr>
                    <th>CHANNEL</th>
                    <?php if(count($channel)>0){?>
                    <th>PAYER</th>
                   <?php }?>
                    <th>CTR NO</th>
                    <th class="text-right">AMOUNT</th>
                </tr>
            </thead>
            <tbody>
                <?php
                     $dbname=session()->get('db_name');
                     $check_rev=array();
                  
                     $query = $db->query('SELECT amount,account_name,ledger_id,trans_item FROM ledger_transaction_tbl,accounts_tbl where ledger_transaction_tbl.ledger_id = accounts_tbl.id AND transation_nature = 2 AND trans_type=2  AND trans_item=0 AND trans_no='.$recpt[0]->trans_number);
                     $result = $query->getResult();
                     $paytotal = 0;
                     //print_r($recpt[0]->trans_number);
                     foreach($result as $rsl){
                      $paytotal += $rsl->amount;

                      $check_rev = $bmodel->get_item_name('receipt_transfer_tbl',$where = array('new_receipt_number' =>$recpt[0]->trans_number));
                      if(count($check_rev) > 0){
                        $ch="Reversal ".$check_rev[0]->reversal_number;
                        $control_number="";
                      }
                ?>
                <tr>
                    <td><?= ($ch)??$rsl->account_name; ?></td>
                     <?php if(count($channel)>0){?>
                    <td><?= $channel[0]->customer_name; ?></td>
                   <?php }?>
                    <td><?= ($control_number)??""; ?></td>
                    <td class="text-right"><?= number_format($rsl->amount); ?></td>
                  </tr>
             <?php }
             $get_charges = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_id' =>22,'transation_nature' =>1,'trans_type' =>2));
                  
                   if(count($get_charges)>0){
                 
                   $paytotal=$paytotal-$get_charges[0]->amount;
                   if($get_charges[0]->amount >0){
                ?>
                 <tr>
                     <td colspan="2" class="colspan-cell">Bank charges</td>
                    <th><b></b></th>
                  
                    <th class="text-right">-<?= number_format($get_charges[0]->amount); ?></th>
                </tr>
            <?php }}?>
                <tr>
                    <?php if(count($channel)>0){?>
                     <td colspan="3" class="colspan-cell"><b>Total</b></td>
                    <th class="text-right"><b><?= number_format($paytotal); ?></b></th>
                <?php }else{?>
                    <td colspan="2" class="colspan-cell"><b>Total</b></td>
                    <th class="text-right"><b><?= number_format($paytotal); ?></b></th>
                <?php }?>
                </tr> 
            </tbody>
        </table>   
        
         <hr>

         <?php
         
         $vfd_settngs = $bmodel->get_item_name('vfd_settings_tbl',$where = array('status' =>1));
          if(count($vfd_settngs)>0 && count($check_rev)==0 && $orgamount>0){
           $vfd_datas=$bmodel->get_item_name('vfd_receipts_details_tbl', $where = array('receipt_number' => $recpt[0]->trans_number));
        if(count($vfd_datas)>0){
             $qr_name=$vfd_datas[0]->QRCODE_NAME;
             if($vfd_datas[0]->QR_code !=0){
            $qr_code=$vfd_datas[0]->QR_code;
             }else{
                 $qr_code="15AEB001";
             }
             
     }else{
     $qr_name='default.png';
      $qr_code="15AEB001";
    }
         ?>
      <center><b>RECEIPT VERIFICATION CODE</b><br><?php  echo $qr_code; ?></center><br><center><img src="<?php echo base_url('public/qrcodes/'.$qr_name); ?>" width='70' height='70'></center>
        
        <hr>
        <?php
          }
        ?>
        
 <p class=" d-flex justify-content-center mt-3" style="font-size:14px">Kindly note, All school Fees are Non-refundable.</p>
        <table>
        <?php
        $leg = $bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$recpt[0]->trans_number,'trans_type_id' =>2));
     $recv = $bmodel->get_item_name('users',$where = array('user_id' =>$leg[0]->updated_by));

        ?>
       
        <tr>
            <td><i>Received by: <?php echo $recv[0]->first_name." ".$recv[0]->last_name." ".$leg[0]->trans_date ?></i></td>
        </tr>
    </table>  
<!--    </div>-->
    </div>
</div> 
<br>
<center>
    <i><span>Powered by Micro Health Initiative</span></i>
</center>
<script>
function printable_rept(area) {
  var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
  disp_setting += "scrollbars=yes,width=750, height=600, left=80, top=25";
  var content_value = document.getElementById(area).innerHTML;

  var docprint = window.open("", "", disp_setting);
  docprint.document.open();
  docprint.document.write('<html><head><title>MHI</title>');

  // Add a <style> block to set the font family and other print-specific styles
  docprint.document.write('<style>');
  docprint.document.write('@media print {');
  docprint.document.write('  body {');
  docprint.document.write('    font-family: "Times New Roman", sans-serif;');
  docprint.document.write('    font-size: 15px;');
  docprint.document.write('  }');
  docprint.document.write('</style>');

  docprint.document.write('</head><body onLoad="self.print()" style="width:100%;">');

  // Modify content_value to include the colspan attribute
  var modifiedContent = content_value.replace('<td class="colspan-cell">', '<td colspan="2" class="colspan-cell">');
  docprint.document.write(modifiedContent);

  docprint.document.write('</body></html>');
  docprint.document.close();
  docprint.focus();
}

</script>


