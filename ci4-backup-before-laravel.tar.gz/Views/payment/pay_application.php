
<?php
   $bmodel = new App\Models\BillingModel();
   $ctype= $bmodel->get_table_details('name_type_tbl');
   // $parent=$bmodel->get_item_name('parents_tbl', $where = array('student_id' => $stid, 'bill_account' => 2));
   // $parent_name=$parent[0]->first_name." ".$parent[0]->last_name;
   // if(count($parent) <= 0){
      $st = $bmodel->get_item_name('students_application_tbl', $where = array('id' => $stid));
   // }
   $parent_id = $st[0]->id;
   // echo session()->get('user_id');

 //echo $_SESSION['user_id'];
?>


<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
                                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card">
                            
                           <?php 
                            
                           // $st=$bmodel->get_applicant_parent($stid);
                           // if(count($st)<=0){
                           //   $st=$bmodel->get_applicant($stid);
                           // }
                           ?>  
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Paid By</label>
                                            <div class="col-sm-8">
                                               <select class="form-control" name="paid_by" id="paid_by">
                                                    <option value="5">Parent</option>
                                                    
                                                </select>
                                            </div>
                                          </div>
                                        <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Payer Name</label>
                                            <div class="col-sm-8">
                                                <input type="hidden" id="payer_id" name="payer_id" value="">
                                                <input type="text" class="form-control" name="payer_name" id="payer_name" value="<?php echo $st[0]->parent_firstname." ".$st[0]->parent_lastname; ?>">
                                              <!--  <select class="form-control" name="paid_by" id="payer_id">
                                                    <option value="<?php ///echo $st[0]->id; ?>"><?php //echo $st[0]->first_name." ".$st[0]->last_name; ?></option>
                                                    
                                                </select> -->
                                            </div>
                                          </div>
                                         <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Customer Type</label>
                                            <div class="col-sm-8">
                                               
                                                <select class="form-control" name="customer_type" id="customer_type">
                                                    <option value="4">Applicant</option>
                                                    
                                                </select>
                                            </div>
                                          </div>                                        
                                    </div>   
                                    <div class="col-md-6">
                                       <div id="customer_loaded"></div> 
                                      <!--  <div id="Name_loaded"></div>
                                       <div id="Invoice_loaded"></div> -->
                                    </div>
                                </div>
                                 <div class="row">
                                     <div class="col-md-12">
                                         
                                         <br>
                                     </div>
                                 </div> 
                                <hr>
                                <div class="row">
                                    <div class="col-md-12">
                                        
                                        <form id="receipt_form">
                                            
                                        <div id="applicationlist">
                                            <h6>Application List</h6>
                                        <table class="table table-bordered" >
                                            <thead>
                                                <tr>
                                                    <th>Student No</th>
                                                    <th> Date</th>
                                                  <th>Student Name</th>
                                                    <th>Application Amount</th>
                                                    <th>Amount Due</th>
                                                    <th>Amount To Pay</th>
                                                </tr>
                                            </thead>
                                            <tbody id="itm_invoice1">
                                            </tbody>
                                            <tfoot>
                                                <tr id="itm_invoicefooter"></tr>
                                            </tfoot>
                                        </table>
                                        </div>
                                        </form>    
                                    </div>
                                </div>
                               
                                <!-- <div class="row mt-4"> -->
                                <?php
                                    $acc = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 9));
                                ?>
                                <div class="cust_popup" id="account" style="display: none">
                                    <form method="POST" id="acct_proc">
                                        <b>CHARGE ACCOUNT</b><i style="color: red" id="saveError"></i><br/>
                                        ACCOUNT NAME
                                        <input class="form-control" id="acc_name" type="text" onkeyup="SearchAccount()" autocomplete="off">
                                        <input id="acc_no" type="hidden">
                                        <div id="schResults"></div>
                                        <br>
                                        AMOUNT
                                        <input class="form-control" id="acc_amt" type="number" autocomplete="off"><br>
                                        <button type="submit" id="svAccnt" class="btn btn-primary pull-right">Save</button>&nbsp;
                                    </form>
                                    <button class="btn btn-warning" style="display:none" id="removeAcct">Remove Account</button>
                                    <button class="btn btn-warning" onclick="tg_acct()">Cancel</button>
                                </div>
                                <div  class="cust_popup" id="cash" style="display: none">
                                    <h6>Receive Cash</h6>
                                     <form id="csh_proc" method="POST">
                                         <select class="form-control" name="ledger" id="ledger" required="">
                                             <option value="">Select ledger</option>
                                            <?php foreach($acc as $ac):?>
                                                 <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                             <?php endforeach; ?>
                                         </select><br>
                                         <input class="form-control" name="cash_amt" id="cash_amt" type="number" required="" ><br>
                                         <button type="button" class="btn btn-warning" onclick="tg_cash()">Cancel</button>
                                         <button type="submit" class="btn btn-primary pull-right">Save</button>&nbsp;
                                     </form>
                                   <button class="btn btn-sm btn-warning" style="display:none" id="removeCash">Remove Cash</button>&nbsp;
                               </div>  
                                
                                <div class="row">
                                    <div class="col-md-6">
                                     
                                     <!--<button type="button" class="btn btn-primary" onclick="tg_patacct()"  >Account</button>-->
<!--                                     <button type="button" class="btn btn-primary">Cheque</button>-->
                                    </div>
                                    <div class="col-md-12">
                                        <form id="payment_panel">
                                            <?php foreach($acc as $ap):?>
                                                  <div class="form-group row" id="ledgerRow<?= $ap->id?>" style="display: none;" >
                                                    <label for="staticEmail" class="col-sm-1 col-form-label"><?= $ap->id; ?> </label>
                                                    <label for="staticEmail" class="col-sm-3  col-form-label"><?= $ap->account_name; ?> Ledger</label>
                                                    <div class="offset-md-6 col-sm-1">
                                                      <input type="text" readonly class="form-control-plaintext" id="ledger_payed<?= $ap->id?>" value="900">
                                                    </div>
                                                    <div class="col-sm-1">
                                                        <div id="legerRata<?= $ap->id?>">
                                                        </div>    
                                                        <label style="margin-top: 10px;"><i  onclick="removePayment('<?= $ap->id?>')" class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="delete"></i></label>
                                                    </div>   
                                                   </div>
                                            <?php endforeach; ?>
                                             <div class="form-group row"  >
                                                <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label">Amount Due</label>
                                                <div class="offset-md-6 col-sm-1">
                                                  <input type="text" readonly class="form-control-plaintext" id="amount_due" value="0">
                                                </div>
                                                <div class="col-sm-1">
                                                </div>   
                                              </div>
                                            <div class="form-group row" style="display: none;" id="change_row" >
                                                <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label">Change</label>
                                                <div class="offset-md-6 col-sm-1">
                                                  <input type="text" readonly class="form-control-plaintext" id="amount_change" value="">
                                                </div>
                                                <div class="col-sm-1">
                                                </div>   
                                              </div>
                                              <hr>
                                        </form>       
                                    </div>
                                    <div class="col-md-2">
                                         <button type="button" class="btn btn-primary pull-left" onclick="tg_cash()"> Add Payment</button>
                                     </div>
                                </div> 
                            </div>
                       
                            <div class="card-footer">
                               
                                <button type="button" id="finishReceipt" class="btn btn-primary pull-right" onclick="finish_receipt()">Finish</button>
                            </div>
                        </div>
                    </div>
                </div>
            
        </div>
    </div>
</div>
<div class="modal fade" id="viewreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>
<script>
    var std="<?php echo $stid; ?>";
    prepare_invoice(std);
    var allvariables = "";
    var total=0;
    var amountdue =0;
    var amountpayed =0;
    var item_list = [];
    var k =0;
    var totalinv = 0;
    $('#finishReceipt').prop("disabled", true);
    function manage_receipt(inv){
      $('#viewreceipt').modal('show'); 
      $('#viewreceipt_content').load('view_receipt/'+inv);
    }
    function prepare_invoice(student_id){
         var paydata = 'type=' + $('#customer_type').val()+'&id=' + student_id;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/create_invoice'; ?>',
                data: paydata,
                success: function (result) {
                    $('#Invoice_loaded').html(''); 
                    var data = JSON.parse(result); 
                    var mydata= Object.keys(data).length;
                    for( var i = 0; i < mydata; i++){
                        k++;
                        item_list.push(k);
                        var unit_price = parseInt(data[i]['unit_price']);
                        total += unit_price;
                        amountdue = total - amountpayed;
                        var name_type = $('#customer_type').val() +'_'+ student_id;
                        var itm = '<tr><input type="hidden"  name="student[]"  value="'+name_type+'">'+
                                   '<td>' + data[i]['student_id']  +'</td>'+
                                   '<td><input type="hidden"  name="studentId" value="'+student_id+'">' + data[i]['full_name']  +'</td>'+
                                   '<td><input type="hidden"  name="customerType'+name_type+'" value="'+$('#customer_type').val()+'">' + data[i]['item_name']  +'</td>'+
                                   '<td>' + data[i]['quantity']  +'</td>'+
                                   '<td>' + unit_price.toLocaleString()  +'</td>'+
                                   '<td><input type="text" class="form-control" id="amounttopay'+k+'"  value="'+data[i]['unit_price']+'" name="amount'+name_type+'" style="width:100px;" disabled></td>' +
                                   '</tr>';
                       $('#itm_invoice1').append(itm);
                       $('#receipt_calc').html(total.toLocaleString());
                       $('#amount_due').val(amountdue.toLocaleString());
                       $('#amount_due').css({"color": "red"});
                   }
                },
                error: function () {
                    $('#itm_invoice').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
      });
    }
 
 function tg_cash() {
        $('#cash').toggle(100);
         $('#cash_amt').val(total);
    }
    $("#csh_proc").submit(function (e) {
        var cashAmt = parseInt($('#cash_amt').val());
        var change;
        if(total==cashAmt){
        amountdue = total - cashAmt;
        var ledger = $('#ledger option:selected').val();
            $('#ledgerRow'+ledger).show();
            $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
            var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" name="amount'+ledger+'" value="'+ cashAmt +'">';
            $('#legerRata'+ledger).append(data);
            $('#change_row').hide();
            $('#amount_due').val(amountdue.toLocaleString());
            $('#finishReceipt').prop("disabled", false);
                }else{
              swal("warning","Please! Enter exact amount to pay","warning");
                }
        // if(amountdue >= 0){
        //     $('#change_row').hide();
        //    $('#amount_due').val(amountdue.toLocaleString()); 
        // }else{
        //    change = amountdue * -1;
        //    amountdue = 0;
        //    $('#amount_due').val(amountdue);
        //    $('#change_row').show();
        //    $('#amount_change').val(change.toLocaleString());
        // }
        amountpayed += cashAmt;
        //AmtCalc();
        tg_cash();
       
        e.preventDefault();
    });

    function finish_receipt(){
        var allvariables2 = $("#receipt_form").serialize() + '&bill_payer='+$('#payer_id').val() + '&'+ $("#payment_panel").serialize()+ '&'+ $("#header_form").serialize();
       //  alert(allvariables2);
        // return;
         $.ajax({
            type: 'POST',
             url: '<?php echo base_url() . '/index.php/BillingController/process_application'; ?>',
           // url: '<?php echo base_url() . '/index.php/BillingController/process_receipt'; ?>',
            data: allvariables2,
            success: function (res) {
                window.location.reload();
              var data = JSON.parse(res);
              if(data['status'] == "1"){
                swal({
                    title: "successful", 
                    text: data['description'], 
                    type: "success"
                  },
                function(){ 
                   location.reload();
                }
             );
            }
            if(data['status'] == "2"){
                swal({
                    title: "Error", 
                    text: data['description'], 
                    type: "error"
                  },
                function(){ 
                   location.reload();
                }
             );
            }
            },
            error: function (){
                alert('error encounted');
            }
        });
    }
    //here by---------------------------------------------------------------------

    var pID = '<?php echo $parent_id; ?>';
    // alert(pID);
  
    payer = 5 +'_' +pID;
    $('#payer_id').val(payer);


     function AmtCalc() {
        total = 0;
        for (var j in item_list) {
           total += parseInt($('#amounttopay' + item_list[j]).val());  
        }
        amountdue = total - amountpayed;
        if(amountdue >= 0){
          $('#amount_due').val(amountdue.toLocaleString());
        }else{
          $('#amount_due').val(0);  
        }
        if (amountdue <= 0) {
            $('#finishReceipt').prop("disabled", false);

        } else {
            $('#finishReceipt').prop("disabled", true);
            swal("Please pay all amount required");
        }
        $('#receipt_calc').html(total.toLocaleString());

        
     }
    function RemoveSelectItemRow(looper){
        for( var i = 0; i < item_list.length; i++){ 
            if ( item_list[i] == looper) {                 
                item_list.splice(i, 1); 
            }
        }
       $('#row'+looper).remove();
        AmtCalc();
		
    }
    function removePayment(lg){
       $('#ledgerRow'+lg).hide();
       $('#ledger_payed'+lg).html('');
       $('#legerRata'+lg).html('');
       
        AmtCalc();
    }
 
</script>