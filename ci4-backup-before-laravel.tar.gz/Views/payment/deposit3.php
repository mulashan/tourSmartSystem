
<?php
   $bmodel = new App\Models\BillingModel();
   $ctype= $bmodel->get_table_details('name_type_tbl');
?>

<div class="section-body mt-4">
    <div class="container-fluid">
             
                <div class="card">
               <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>Trans No</th> 
                                    <th>Control No.</th>
                                    <th>Control Date</th>
                                    <th>Customer Name</th>
                                    <th>Name Type</th>
                                    <th>Control Amount</th>
                                      <th>sms Status</th>
                                    <th>Created By</th>

                                   
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                 if(count($trans)>0){
                                    foreach($trans as $s){
                                    
                                   // $invoice_type = $bmodel->get_item_join_table($s->trans_number);
                                    $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type' =>3));
                                    // echo $s->trans_number.'</br>';
                                    $contrl = $bmodel->get_item_name('payment_request',$where = array('trans_no' =>$s->trans_number,'trans_type' =>3));
                                    $student_name = "";
                                    $student_id = "";
                                    $control_number = "";
                                    $name_type = "";
                                    $amount =0;
                                    if(count($leger_transaction) > 0){
                                        $total_amount = $bmodel->get__amount_payed($s->trans_number,9,3);
                                        if(count($total_amount) > 0)
                                            $amount = $total_amount[0]->amount;
                                        if($leger_transaction[0]->name_type_id == 4){
                                            $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                                            $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                            $student_id = $app[0]->id;
                                            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                            $name_type = $type_name[0]->name_type;
                                            
                                        }
                                        else if($leger_transaction[0]->name_type_id == 3){
                                             $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }else if($leger_transaction[0]->name_type_id == 1){
                                             $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
                                            
                                             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }
                                        
                                    

                                    $user = $bmodel->get_item_name('users', $where = array('user_id' => $s->updated_by));

                                    $msg_status = $bmodel->get_item_name('message_groups_tbl', $where = array('trans_number' => $s->trans_number,'message_type'=>3));
                                     if(count($msg_status)>0){
                                         $msg_st = $bmodel->get_item_name('messages', $where = array('send_no' => $msg_status[0]->send_number));
                                         if(count($msg_st)>0){
                                            ?>
                                         <script type="text/javascript">
                                        
                                             $(function() {
                                         check_sms('<?php echo $msg_st[0]->message_id;?>');
                                              });
                                         </script>
                                         <?php
                                         $msg_st = $bmodel->get_item_name('messages', $where = array('message_id' => $msg_st[0]->message_id));

                                         $del=$msg_st[0]->status_description;
                                         $time=$msg_st[0]->time_delivered;
                                         $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                                     }else{
                                         $stata='<span style="color:red">Not Sent'; 
                                     }
                                     }else{
                                       $stata='<span style="color:red">Not Sent';  
                                     }
                                ?>
                                <tr>
                                    <td><?php echo $s->trans_number;?></td>
                                   <td><?php if(count($contrl)>0){ echo  $contrl[0]->reference_no;}?></td>
                                    <td><?php echo date('Y-m-d',strtotime($s->trans_date));?></td>
                                     <td><?php echo $student_name;?></td>
                                    <td><?php echo $name_type ?? "";?></td>
                                    <td><?= number_format($amount); ?></td>
                                     <td><?php echo $stata;?></td>
                                    <td><?= $user[0]->first_name.' '.$user[0]->last_name; ?></td>
                                   
                                     <!-- <td><?php echo date('Y-m-d H:i',strtotime($s->updated_date));?></td> -->
                                   <!--  <td><a href="javascript:void(0)" onclick="manage_deposi(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"> </i>  Edit</a>
                                    <a href="javascript:void(0)" onclick="manage_deposit(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a>
                                    </td> -->
                                    
                                </tr>
                            <?php }}}else{
                                echo "<tr><td>Currently there is no record</td></tr>";
                            } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
          
        </div>
   
<div class="modal fade" id="viewreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('viewreceipt_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="viewreceiptxl" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_contentxl">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         
      </div>
    </div>
  </div>
</div>
<script>

    $(document).ready(function () {
      $('#myTable').DataTable();
    });
    
   function check_sms(msgid){
               // alert(msgid);
              $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/SystemController/check_sms/'; ?>'+msgid,
            
            success: function (res) {
             },
            error: function (){
                alert('error encounted');
            }
        });
            }
  </script>