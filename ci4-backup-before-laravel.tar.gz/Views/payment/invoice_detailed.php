    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style type="text/css">

     .invoice > .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }

 </style>

 <?php
  $bmodel = new App\Models\BillingModel();
  $amodel = new App\Models\AdmissionModel();
  $cmodel = new App\Models\ClassesModel();
  $smodel = new App\Models\StudentModel();
  $appItems = $cmodel->get_applications_items();
  $transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>1,'transation_nature'=>2));
   $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>1));

  if(count($transaction)==0){
      $legers_acc = $smodel->gettable_data('class_level_items_tbl',$where = array('account_receivable !=' => 0));
        if(count($legers_acc)>0){
          $ledgerId=$legers_acc[0]->account_receivable;
          }else{
         $legers_acc = $smodel->gettable_data('accounts_tbl',$where = array('account_type_id' => 7));
         $ledgerId=$legers_acc[0]->id;
          }
          $ttl = $bmodel->get_items_total($inv[0]->trans_number);
          $total=$ttl[0]->total;
    $ac_ledger = [
            'ledger_id' => $ledgerId,
            'ledger_type' => 7,
            'trans_no' => $inv[0]->trans_number,
            'trans_type' => 1,
            'amount' => $total,
            'transation_nature' => 2,
            'name_type_id' => 1,
            'name_id' => $leger_transaction[0]->name_id,
            'balance' => $total,
        ]; 
$smodel->SaveData('ledger_transaction_tbl',$ac_ledger);
  }
  $student_name = "";
  $name_type = "";
  $class_name = "";
  $ref="";
  $amount = 0;
if(count($leger_transaction) > 0){
    $amount = $leger_transaction[0]->amount;
    if($leger_transaction[0]->name_type_id == 4){
        $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
             $class_data = $bmodel->get_class_data($leger_transaction[0]->name_id, esc($year));
                if($class_data>0){
                                $class_name = $class_data[0]->class_name .'('.$class_data[0]->stream_name .')';  
                                            }     
    }else if($leger_transaction[0]->name_type_id == 1){
        $admn = $bmodel->get_item_name('students', $where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name; 
        $parent = $smodel->gettable_billingdata($admn[0]->id);
        if(count($parent)>0){
            $phone=$parent[0]->phone1;
               $class_data = $bmodel->get_class_data($leger_transaction[0]->name_id, esc($year));
               $class_name="";
                                            if(count($class_data)>0){
                                            $class_name = $class_data[0]->class_name .'('.$class_data[0]->stream_name .')';  
                                            }
        }else{
            $phone="";
        }
        // $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $leger_transaction[0]->name_id));
        $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $leger_transaction[0]->name_id, 'status' => 1));
             $class_data = $bmodel->get_class_data($leger_transaction[0]->name_id, esc($year));
                                            if(count($class_data)>0){
                                               $class_name = $class_data[0]->class_name .'('.$class_data[0]->stream_name .')';   
                                            }
        }else if($leger_transaction[0]->name_type_id == 6){
        $admn = $bmodel->get_item_name('other_students_tbl', $where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name; 
       $phone= $admn[0]->phone;
         $admissn = array();
        // $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $leger_transaction[0]->name_id, 'status' => 1));
              $class_data = $bmodel->get_class_data($leger_transaction[0]->name_id, esc($year));
                                            if($class_data>0){
                                              $class_name = $class_data[0]->class_name .'('.$class_data[0]->stream_name .')';   
                                            }
        }
        
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;

        $pay = $bmodel->get_item_name('payment_request',$where = array('student_id' => $admn[0]->id,'trans_no'=>$inv[0]->trans_number,'trans_type'=>1));

        if(count($pay) > 0){
            $ref = $pay[0]->reference_no;
            $amount_request = $pay[0]->amount;
        }else{
            $ref = "<b>Not Created</b>";
             $pay2 = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('name_id' => $admn[0]->id,'trans_no'=>$inv[0]->trans_number,'transation_nature'=>2,'trans_type'=>1));
            
            $amount_request = $pay2[0]->amount;
        }
    
     $classification = $bmodel->get_item_name('invoice_classification_tbl',$where = array('trans_id' => $inv[0]->id));
}
 ?>
<div class="row">
    <div id="feedback"></div>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Invoice Information</h5>
            </div>
            </hr>

            <div class="card-body">
                <!-- <input type="hidden" name="student_id" id="studentid" value="<?php //$admissn[0]->id;?>"> -->
                <input type="hidden" name="student_id" id="studentid" value="<?= $inv[0]->trans_number;?>">
                <table class="table table-borderless">
                      <?php
                    if(count($classification)>0){
                $classc = $bmodel->get_item_name('classification_tbl',$where = array('id' => $classification[0]->classification_id));
                //print_r($classification);

                     ?>
                    <tr>
                        <th>Classification Name:</th>
                        <td><?= $classc[0]->class_name??""; ?></td>
                    </tr>
                <?php }?>
                    <tr>
                        <th>Invoice Number:</th>
                        <td><?= $inv[0]->trans_number; ?></td>
                    </tr>
                    <tr>
                        <th>Invoice Date:</th>
                        <td><?= $inv[0]->trans_date; ?></td>
                    </tr>
                    <tr>
                        <th>Customer Type:</th>
                        <td><?= $name_type; ?></td>
                    </tr>
                    <tr>
                        <th>Student Name:</th>
                        <td><?= $student_name; ?></td>
                    </tr>
                         <tr>
                        <th>Class Name:</th>
                        <td><?= $class_name; ?></td>
                    </tr>
                    <tr>
                        <th>Registration No:</th>
                        <td><?= $admn[0]->id; ?></td>
                    </tr>
                    <tr>
                        <?php if(count($admissn)>0){?>
                        <th>Class Admission N0:</th>
                        <td><?= $admn[0]->student_id.'-'.$admissn[0]->academic_year.'-'.$admissn[0]->class_id; ?></td>
                    <?php }?>
                    </tr>
                       <tr>
                        <th>Academic Year:</th>
                        <td><?= esc($year) ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <?php
   $dbname=session()->get('db_name');
    $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;
                        $paid_amount=0;
                        $query = $db->query('SELECT item_transation_tbl.item_id,item_name,account_name,trans_number,quantity,unit_price,item_group FROM item_transation_tbl,items_tbl,items_ledgers_tbl,accounts_tbl where item_transation_tbl.item_id = items_tbl.id AND items_ledgers_tbl.item_id = items_tbl.id AND item_transation_tbl.trans_type = 1 AND accounts_tbl.id = items_ledgers_tbl.account_id AND (account_type_id = 3 OR account_type_id = 4) AND trans_number='.$inv[0]->trans_number);
                        $result = $query->getResult();
                       //print_r($result);
                        foreach($result as $itm){
                            $dat = $amodel->get_trans_type($inv[0]->trans_number);
                             $query2 = $db->query('SELECT type_name,amount FROM ledger_transaction_tbl,account_types_tbl where ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_transaction_tbl.trans_type = 1 AND (ledger_type = 3 OR ledger_type = 4) AND trans_no='.$inv[0]->trans_number);
                             $result2 = $query2->getResult();
                             $amount = $itm->quantity * $itm->unit_price;
                             if($itm->item_group==7){
                            $total -= $amount;
                             }else{
                            $total += $amount;
                             }
                         }
             $check= $bmodel->get_item_name('transaction_numbers_tbl',$where=array('trans_number'=>$inv[0]->trans_number,'trans_type_id'=>1));
             $original_date = $check[0]->trans_date;
            $year = date("Y", strtotime($original_date));
            
                $check_balance= $bmodel->get_item_name('student_balance_tbl',$where=array('year'=>$year-1,'student_id'=>$admn[0]->id));

                $inv_type= $bmodel->get_item_name('invoice_type_transaction',$where=array('trans_no'=>$inv[0]->trans_number,'transaction_type_id'=>1));
                 if($inv_type[0]->invoice_type_id==2){
                     if(count($check_balance)>0){
                        $paid_amount=$check_balance[0]->balance*-1;
                     $total2 =$total -$paid_amount;
                     }
                 }
    ?>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Receipt History</h5>
            </div>
            </hr>

            <div class="card-body">
                <table class="table" id="paytable">
                    <thead>
                                <tr>
                                    
                                    <th>Rcpt No.</th>
                                    <th>Trans Type</th>
                                    <th>Receipt Date</th>
                                   <th class="text-right">Receipt Amount</th>
                                    <th>Received By</th>
                                    <th width="100px">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $ttamount =0;
                                  $am_tf=0;
                                  $refundedAmount=0;
                                  $overpaid=0;
                                $trans = $bmodel->get_item_name('transactions_relation',$where = array('invoice_trans_no' =>$inv[0]->trans_number));
                                 $dsb="";
                                
                                if(count($trans)>0){
                                    $dsb="disabled";
                                    foreach($trans as $s){
                                        $number = $bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$s->receipt_trans_no,'trans_type_id'=>2));

                                    $transfered = $bmodel->get_item_name('receipt_transfer_tbl',$where = array('old_receipt_number' =>$s->receipt_trans_no));

                                       $refunded = $bmodel->get_item_name('voucher_relation_tbl',$where = array('trans_no' =>$s->receipt_trans_no,'trans_type'=>2,'voucher_type'=>5));
                                    
                                 $_type = $bmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>$number[0]->trans_type_id));

                                         $leger_transaction2 = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->receipt_trans_no,'ledger_type'=> 7,'trans_type' =>2,'transation_nature' =>1));
                                        // echo count($leger_transaction2);echo "</br>";
                                       
                                           if(count($leger_transaction2) == 0){
                                          $leger_transaction2 = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->receipt_trans_no,'ledger_type'=> 7,'trans_type' =>2,'transation_nature' =>2));
                                         }

                                       
                                         $bank_charges = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->receipt_trans_no,'trans_type' =>2,'ledger_id' =>22,'transation_nature' =>1));

                                          $over_payment = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->receipt_trans_no,'trans_type' =>2,'ledger_id' =>21));

                                    //   print_r($leger_transaction2);
                                    //     return;
                                        
                                    $student_name = "";
                                    $student_id = "";
                                    $control_number = "";
                                    $name_type = "";
                                    $amount =0;
                                    $i=0;
                                    $chargesb=0;

                                    if(count($over_payment) > 0){
                                      $overpaid=$overpaid +$over_payment[0]->amount;  
                                    }

                                    if(count($bank_charges) > 0){
                                      $chargesb=$bank_charges[0]->amount;  
                                    }

                                    if(count($leger_transaction2) > 0){
                                        // $total_amount = $bmodel->get_invoice_amount_payed($s->receipt_trans_no,9);
                                        // if(count($leger_transaction2)>1){
                                        //      print_r($leger_transaction2);
                                        // return;
                                        // }
                                       
                                      //  echo $inv[0]->trans_number;
                                  foreach($leger_transaction2 as $itm){
                                    $get_invoice = $bmodel->get_item_name('transactions_relation',$where = array('receipt_trans_no' =>$itm->trans_no));
                                      
                                    if($get_invoice[$i]->invoice_trans_no==$inv[0]->trans_number){
                                     
                                        $amount = $itm->amount;
                                    }
                                   $i++;
                                   }
                                        
                                       
                                         $ttamount=$ttamount +$amount;

                                        if($leger_transaction2[0]->name_type_id == 4){
                                            $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction2[0]->name_id));
                                            $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                            $student_id = $app[0]->id;
                                            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction2[0]->name_type_id));
                                            $name_type = $type_name[0]->name_type;
                                            
                                        }
                                        else if($leger_transaction2[0]->name_type_id == 3){
                                             $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction2[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction2[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }else if($leger_transaction2[0]->name_type_id == 1){
                                             $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction2[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction2[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }
                                        
                                    

                                  $user = $bmodel->get_item_name('users', $where = array('user_id' => $number[0]->updated_by));
                                    $vfd = $bmodel->get_item_name('vfd_receipts_details_tbl', $where = array('receipt_number' =>$s->receipt_trans_no,'submission_status'=>1));
                         if($number[0]->updated_by==9 || $number[0]->updated_by==10 || count($vfd)>0){
                            $style="pointer-events: none;opacity: 0.5";
                                    }else{
                             $style="";
                                    }
                                ?>
                                <tr>
                                    <td><?php echo $s->receipt_trans_no;?></td>
                                     <td><?php echo $_type[0]->type_name;?></td>
                                    <td><?php echo date('Y-m-d',strtotime($number[0]->trans_date));?></td>
                                      <td class="text-right"><?= number_format($amount); ?></td>
                                    <td><?= $user[0]->first_name.' '.$user[0]->last_name; ?></td>
                                     
                                    <td>
                                    <a href="javascript:void(0)" onclick="manage_receipt(<?php echo $number[0]->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i></a>
                                   <a href="javascript:void(0)" onclick="delete_receipt(<?php echo $number[0]->id;?>)"  class="btn btn-danger btn-sm" style="<?= $style;?>" ><i class="fa fa-trash"></i></a>
                                    </td>
                                    
                                </tr>
                            <?php 
                            
                          if(count($transfered)>0){
                            foreach($transfered as $fer){
                                $tnb = $bmodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $fer->reversal_number,'trans_type_id'=>7));
                                  $_type = $bmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>$tnb[0]->trans_type_id));
                                $userT = $bmodel->get_item_name('users', $where = array('user_id' => $tnb[0]->updated_by));
                             $am_tf=$am_tf+$fer->amount_transfered;
                           ?>
                           <tr style="color: black;">
                            <td><?php echo $fer->reversal_number;?></td>
                            <td><?php echo $_type[0]->type_name;?></td>
                              <td><?php echo date('Y-m-d',strtotime($tnb[0]->trans_date));?></td>
                              <td class="text-right">- <?= number_format($fer->amount_transfered); ?></td>
                              <td><?= $userT[0]->first_name.' '.$userT[0]->last_name; ?></td>
                              <td>
                                    <a href="javascript:void(0)" onclick="manage_receipt(<?php echo $tnb[0]->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i></a>
                                     <a href="javascript:void(0)" onclick="delete_receipt(<?php echo $tnb[0]->id;?>)"  class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                    </td>
                           </tr>         
                           <?php
                            }
                          }

                ///for refunded receipt
                     if(count($refunded)>0){
                    foreach($refunded as $r){
                       
                        $approval = $bmodel->get_item_name('approval_numbers', $where = array('trans_no' => $r->payment_no,'trans_type'=>5));
                 if(count($approval)>0){
                 $check_approval= $bmodel->get_item_name('approval_history', $where = array('app_no' => $approval[0]->app_id,'hstatus'=>1));
                 if(count($check_approval)==0){
                    continue;
                 }
                   
                        $tnb = $bmodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $r->payment_no,'trans_type_id'=>5));
                                  $_type = $bmodel->get_item_name('voucher_types_tbl',$where = array('id' =>5));
                                $userT = $bmodel->get_item_name('users', $where = array('user_id' => $tnb[0]->updated_by));

                            $lgamount = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $r->payment_no,'trans_type'=>5));
                             $refundedAmount=$refundedAmount+$lgamount[0]->amount;
                           ?>
                           <tr style="color: black;">
                            <td><?php echo $r->payment_no;?></td>
                            <td><?php echo $_type[0]->voucher_type_name;?></td>
                              <td><?php echo date('Y-m-d',strtotime($tnb[0]->trans_date));?></td>
                              <td class="text-right">-<?= number_format($lgamount[0]->amount); ?></td>
                              <td><?= $userT[0]->first_name.' '.$userT[0]->last_name; ?></td>
                              <td>
                                 <a href="javascript:void(0)" onclick="manage_voucher(<?php echo $tnb[0]->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i></a>
                                     <!-- <a href="javascript:void(0)" onclick="delete_receipt(<?php echo $tnb[0]->id;?>)"  class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a> -->
                                    </td>
                           </tr>     
                            <?php
                            }
                    }
                    }

                             ///for refunded receipt

                        }}}else{
                                echo "<tr><td>Currently there is no record</td></tr>";
                            } ?>
                            <tr><td><b>Total</b></td><td></td><td class="text-right"><b><?php echo number_format($ttamount-$am_tf-$refundedAmount);?></b></td></tr>
                            
                              <?php
                            //   echo $total.'/';
                            //   echo $am_tf.'/';
                            //   echo $refundedAmount.'/';
                               $due=$total-$ttamount+$am_tf+$refundedAmount;
                            ?>
                             <tr><td><b>Amount Due</b></td><td></td><td class="text-right"><b><?php echo number_format($total-$ttamount+$am_tf+$refundedAmount);?></b>
                                        
                             </td>
                             <td>
                                 <a href="javascript:void(0)" onclick="refreshBalance('<?= $inv[0]->trans_number; ?>','<?= $admn[0]->id; ?>','<?= $due; ?>')"  title="Refresh" class="btn btn-primary "><i class="fas fa-sync"></i> </a>
                             </td>
                               <?php
                               
                                 
                                if($due >0 && $ref=="<b>Not Created</b>"){
                                    ?>
                                    <td colspan="3">
                                        <a href="javascript:void(0)" onclick="generateCTR('<?= $inv[0]->trans_number; ?>','<?= $admn[0]->id; ?>','<?= $due; ?>')"  class="btn btn-primary "><i class="fa fa-rotate-left"></i> create control number</a>
                                    </td>
                              <?php
                                }
                               ?>
                             </tr>
                            </tbody>
                        </table>
            </div>
        </div>
    </div>
   
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card  invoice">
            <div class="card-header">
                <h5>Charged Items</h5>
            </div>
            </hr>

            <div class="card-body">
                <p class=" d-flex justify-content-start mt-3 ms-3"><b>CHARGED ITEMS</b></p>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Item Id</th>
                            <th>Item Name</th>
                            <th>Trans Comment</th>
                            <th>Qty</th>
                            <th class="text-right">Price</th>
                            <th class="text-right">Amount</th>
                            <th>Ledger</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="">
                        <?php
                         $dbname=session()->get('db_name');
                        $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;
                        $query = $db->query('SELECT item_transation_tbl.item_id,item_name,account_name,trans_number,quantity,unit_price,item_group FROM item_transation_tbl,items_tbl,items_ledgers_tbl,accounts_tbl where item_transation_tbl.item_id = items_tbl.id AND items_ledgers_tbl.item_id = items_tbl.id AND item_transation_tbl.trans_type = 1 AND accounts_tbl.id = items_ledgers_tbl.account_id AND trans_number='.$inv[0]->trans_number);
                        $result = $query->getResult();
                         
                          $result2 = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $inv[0]->trans_number,'trans_type'=>1,'transation_nature'=>1));
                             
                        foreach($result as $itm){
                            if(count($result2)==0){
                  $leger_items = $smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $itm->item_id));
                  
                  foreach($leger_items as $lg){
                $legers = $smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
             $ac_ledger = [
            'ledger_id' => $lg->account_id,
            'ledger_type' => $legers[0]->account_type_id,
            'trans_item' => $itm->item_id,
            'trans_no' => $inv[0]->trans_number,
            'trans_type' => 1,
            'amount' => $itm->quantity*$itm->unit_price,
            'transation_nature' => 1,
            'name_type_id' => 1,
            'name_id' => $leger_transaction[0]->name_id,
            'balance' => 0,
        ]; 
$smodel->SaveData('ledger_transaction_tbl',$ac_ledger);

          }
            }
                            $dat = $amodel->get_trans_type($inv[0]->trans_number);
                            
                             $amount = $itm->quantity * $itm->unit_price;
                             if($itm->item_group==7){
                            $total -= $amount;
                             }else{
                            $total += $amount;
                             }
                            ?>
                         <tr>
                             <td><?= $itm->item_id; ?></td>
                             <td><?= $itm->item_name; ?></td>
                             <td></td>
                             <td><?= $itm->quantity; ?></td>
                             <td class="text-right"><?= number_format($itm->unit_price); ?></td>
                             <td class="text-right"><?= number_format($amount); ?></td>
                             <td><?=$itm->account_name; ?></td>
                         </tr>
                    <?php } ?>
                            <tr>
                                <td></td> <td></td> <td></td> <td></td> <td></td>
                                <td class="text-right"><b><?php echo number_format($total); ?></b></td>
                            </tr>
                    </tbody>
                </table>

            </div>

        </div>

<!--------------------------------------------------------------------------------------->
<div class="row">
 <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Payment Information</h5>
            </div>
            </hr>

            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Control  Number:</th>
                        <td><?= $ref; ?></td>
                    </tr>
                    <tr>
                        <th>Amount:</th>
                        <td><?= number_format($amount_request); ?></td>
                    </tr>
                    <tr>
                        <th>Phone No:</th>
                        <td><?= $phone;?></td>
                    </tr>
                    <?php
                   // print_r($leger_transaction);
                    if(count($leger_transaction)>0){
                        $m = $bmodel->get_invoice_message($leger_transaction[0]->name_id,$inv[0]->trans_number);
                       $msg = "";
                         if(count($m) > 0){
                            $msg = $m[0]->message;
                   ?>
                    <tr>
                        <th>Invoice MSG:</th>
                        <td><textarea class="form-control" name="msg" readonly><?= $msg; ?></textarea></td>
                    </tr>
                    <tr id="invoicetmsg">
                       <th >Message status:</th>
                        <td id="newstatus">
                           <?php if( $m[0]->sent_status == 1) {?>
                           <i>Sent date:<?php echo date("d-m-Y H:i:s",$m[0]->created_at); ?> 
                             <br>Status: <?php echo $m[0]->status_description; ?>
                             <span class="pull-right">
                             <button type="button" onclick="checksmsstatus('<?php echo $m[0]->message_id; ?>','invoicetmsg')" class="btn btn-success btn-sm pull-left"><i class="fa fa-refresh"></i></button>
                                         &nbsp;&nbsp;<button type="button" onclick='PaymntResndSMSform("PaymntResndForm","invoicetmsg")' class='btn btn-primary btn-sm'>Resend</button></span>
                             <script>
                                $(function() {
                                    checksmsstatus('<?php echo $m[0]->message_id; ?>','invoicetmsg');
                                 });
                             </script>
                             <?php }elseif( $m[0]->sent_status == 2){ ?>
                                  <i>Sent Date:<?php echo $m[0]->time_sent; ?> 
                                  <br>Status: <?php echo $m[0]->status_description; ?>
                                  <br>Delivered Date:<?php echo $m[0]->time_delivered; ?>       
                             <?php } ?> 
                        </td>            
                    </tr>
                                
                     <?php }else{ ?>
                    <tr>
                        <th>Invoice MSG:</th>
                        <td><textarea class="form-control" name="msg" readonly><?= $msg ="Kumb No: ".$ref.",Kiasi:TZS ".number_format($total).", Mwanafunzi: ".$student_name.".". "Tafadhali Fanya Malipo Kupitia NMB.";?></textarea> </td>
                    </tr>
                    <tr >
                       <th>Message status:</th>
                        <td>
                            <i class="text-warning">Not Sent</i>
                        </td>   
                    </tr>
                     <?php } }?>

 
                </table>
            </div>
        </div>
    </div>
<!---------------------------------------------------------------------------------------->
       <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Accounts Receivable</h5>
            </div>
            </hr>
           <div class="card-body">
                <table class="table">
                    <!-- <th colspan="8"><p class=" d-flex justify-content-start mt-3"><b>ACCOUNT RECEIVABLES</b></p></th> -->
                    <tbody>
                        <?php 
                            $accnt = $db->query('SELECT ledger_transaction_tbl.id,ledger_id,ledger_type,amount,name_id,account_name,type_name 
                            FROM ledger_transaction_tbl,accounts_tbl,account_types_tbl 
                            WHERE ledger_transaction_tbl.ledger_id = accounts_tbl.id AND ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_type = 7 AND trans_type=1 AND trans_no='.$inv[0]->trans_number);
                            $results  = $accnt->getResult();
                            foreach ($results as $ac){

                        ?>
                        <tr>
                            <td><?= $ac->ledger_id; ?></td>
                            <td><?= $ac->account_name; ?></td>
                            <td colspan="3"></td>
                            <td><?= number_format($ac->amount);?></td>
                            <td><?= $ac->type_name; ?></td>
                            <td></td>
                        </tr>
                    <?php } ?>
                            <tr>
                                <td colspan="5"></td>
                                <td colspan="3"><b><?php echo number_format($total); ?></b></td>
                            </tr>
                    </tbody>
                </table>

            </div>
        </div>
        
         <!--------deposi history------------->
          <div class="col-md-12">
        <div class="card invoice">
            <div class="card-header">
                <h5>Deposit History</h5>
            </div>
            </hr>
           <div class="card-body">
                <table class="table">
                  <thead>
                <tr>
                    
                    <th>DEp No.</th>
                    <th>DEp Type</th>
                    <th>deposit Date</th>
                   <th class="text-right">deposit Amount</th>
                    <th>deposited By</th>
                    <!-- <th width="100px">Action</th> -->
                </tr>
                            </thead>
                    <tbody>
                        <?php 
                        $de_total=0;
                      $check_deposit = $bmodel->get_item_name('deposit_receipt_tbl', $where = array('invoice_number' => $inv[0]->trans_number));
                      if(count($check_deposit)>0){
                           $dsb="disabled";
                    foreach ($check_deposit as $ch){
                     $depost_type = $bmodel->get_item_name('invoice_type_transaction', $where = array('trans_no' => $ch->deposit_number,'transaction_type_id'=>3));
                     $de_type = $bmodel->get_item_name('invoice_types_tbl', $where = array('id' => $depost_type[0]->invoice_type_id));
                    $de_amount = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $ch->deposit_number,'trans_type'=>3,'transation_nature'=>1,'ledger_type'=>7));
                     $de_number = $bmodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $ch->deposit_number,'trans_type_id'=>3,));
                      $de_name = $bmodel->get_item_name('users', $where = array('user_id' => $de_number[0]->updated_by,));
                      $de_total=$de_total+$de_amount[0]->amount;
                        ?>
                        <tr>
                            <td><?= $ch->deposit_number; ?></td>
                            <td><?= $de_type[0] ->type_name; ?></td>
                            <td><?= $de_number[0] ->trans_date; ?></td>
                            <td class="text-right"><?= number_format($de_amount[0]->amount);?></td>
                            <td><?= $de_name[0]->first_name.' '.$de_name[0]->last_name; ?></td>
                            <td></td>
                        </tr>
                    <?php 
                    if($ch->receipt_number !=0){
                        $de_total=$de_total-$de_amount[0]->amount;

                        $t_number = $bmodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $ch->receipt_number,'trans_type_id'=>2,));
                        ?>
                    <tr style="color:black;">
                            <td><?= $ch->deposit_number; ?></td>
                            <td><?= $de_type[0] ->type_name; ?></td>
                            <td><?= $t_number[0] ->trans_date; ?></td>
                            <td class="text-right">-<?= number_format($de_amount[0]->amount);?></td>
                            <td><?= $de_name[0]->first_name.' '.$de_name[0]->last_name; ?></td>
                            <td></td>
                        </tr>

                   <?php
                    }
                      } 
                        }
                    ?>
                            <tr>
                                <td colspan="3">Total</td>
                                <td class="text-right"><b><?php echo number_format($de_total); ?></b></td>
                            </tr>
                    </tbody>
                </table>

            </div>
        </div>
        
        <!-------------------------------->
        </div>
     </div>
    </div>
    <!-- <button type="button" class="btn btn-danger pull-left <?= $dsb;?>" onclick="delete_invoice(<?php echo $inv[0]->id;?>)"><i class="fa fa-trash"></i> Delete</button> -->

     <?php
     if($dsb==""){
        $msg="";
        ?>
        <div class="tooltip-container mt-4">
  <button type="button" class="btn btn-danger mb-3 pull-left <?= $dsb;?>" onclick="delete_invoice(<?php echo $inv[0]->id;?>)" ><i class="fa fa-trash"></i> Delete</button>
  </div>
        <?php
     }else{
         $msg="You can no longer delete this transaction because there are related transactions already. Please delete related transactions first.";
         ?>
 <div class="tooltip-container mt-4" data-tooltip="<?php echo $msg;?>">
  <button type="button" class="btn btn-danger mb-3 tooltip-button pull-left <?= $dsb;?>" onclick="delete_invoice(<?php echo $inv[0]->id;?>)" data-toggle="tooltip" data-tooltip="<?php echo $msg;?>"><i class="fa fa-trash"></i> Delete</button>
  </div>
         <?php
     }

    ?>
</div>

<div class="modal fade" id="voucherModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"  style="z-index: 1600;">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="voucher_content">
      </div>
    </div>
  </div>
</div> 
<script>
    var id = $('#studentid').val();
    $('#invoicePrint_content').load('print_invoice/'+id);
    // function printable_rept(inv){
    //     // alert('hello')
    //   $('#invoiceprint').modal('show'); 
    //   $('#invoicePrint_content').load('print_invoice/'+inv);
    // }


     function PaymntResndSMSform(formId,divhtml) {
          $.ajax({
            beforeSend: function () {
                $('#'+ divhtml).html('<i class="fa fa-spinner fa-spin"></i> Sending Message..');
            },
            type: "POST",
            url: '<?php //echo base_url() . '/index.php/StudentController/resend_sms'; ?>',
            data: $('#'+formId).serialize(),
            success: function (result) {
              //  alert(result);
                $('#'+ divhtml).html(result);             
            },
            error: function () {
                $('#'+divhtml).html('Sorry! Something went wrong.');
            }
        });
    }
    function checksmsstatus(id,divhtml){
     var data = "id=" + id;
         $.ajax({
            beforeSend: function () {
                $('#'+divhtml).html('<i class="fa fa-spinner fa-spin"></i> Checking sms status..');
            },
            type: "POST",
            url: '<?php echo base_url() . '/index.php/StudentController/check_sms'; ?>',
            data: data,
            success: function (result) {
                // $('#notsent').remove();
                $('#'+divhtml).html(result);             
            },
            error: function () {
                $('#'+divhtml).html('Sorry! Something went wrong.');
            }
        });
    }

    function resendSMS(phone,msg,type,ref){
        var data = 'phn=' + phone + '&msg=' + msg + '&type=' + type + '&ref=' + ref;
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/SMSsender/'; ?>' + phone +'/'+ msg +'/' + type +'/' + ref,
            success: function(){
               
            }
        });
    }

    function Remove_item(root,itemID,stdID,transNo,classID,hostelID,transID){
        var data = 'item=' + itemID + '&student=' + stdID + '&transNo=' + transNo + '&class=' + classID + '&hostel=' + hostelID + '&transport=' + transID;
        // alert(data);
         $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/Remove_invoicedItem'; ?>',
            data: data,
            success: function(){

                root.parentElement.parentElement.remove();

            }
        });
    }

    function UpdateInvoice(transNo,nameID)
    {
        var data = 'trans=' + transNo + '&sID=' + nameID;
         // alert(data);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/update_invoice'; ?>',
            data: data,
            success: function (res) {
                var data = JSON.parse(res);

                if(data['status'] == "0"){
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            }
        });
    }
   function delete_receipt(id){
    //var id = $(this).attr('data-id');

           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this Receipt!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                // url: '<?= base_url('/deleteAcc')?>/'+id,
                 url: '<?php echo base_url() . '/index.php/BillingController/delete_receipt'; ?>/'+id,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      // $("#"+id).remove();
                    swal("Deleted!", "Receipt deleted successfuly.", "success");

                    location.reload();
                      
                 }
              });

            } else {
               swal("Cancelled");
            }

          });
   }
   function generateCTR(trans,student_id,due){
    $('#viewinvoice').modal('hide');
 //alert('trans='+trans+' studentid='+student_id+' due='+due);
  var data = 'trans=' + trans + '&sID=' + student_id+ '&due=' + due+'&'+$("#header_form").serialize();
         // alert(data);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/generate_invoice_controlnumber'; ?>',
            data: data,
            success: function (res) {
                var data = JSON.parse(res);

                if(data['status'] == 1){
                    Swal.fire({
                    title: "successful", 
                    html: data['statusDesc'], 
                    icon: "success"
                  }).then((result) => {
                  if (result.isConfirmed) {
                    //location.reload();
                  }
                });
                }else{
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Control number Not created successfully</div>');
                }
            },
            error: function () {
                alert('Sorry!, Something went wrong');
            }

        });
   }

   function refreshBalance(trans,student_id,due){
       var data ='student_id=' + student_id + '&transNo=' + trans + '&due=' + due;
        // alert(data);
         
         $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillingController/update_invoice_balance'; ?>',
            data: data,
            success: function(){

               toastr.success('Balance updated successfully');

            }
        });
   }

  
    

</script>    
   