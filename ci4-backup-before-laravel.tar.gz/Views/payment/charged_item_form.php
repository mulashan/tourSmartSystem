                    <link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
                     <form id="charged_items">
                        <input type="hidden" name="student_id" value="<?=$student_id;?>">
                     <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Charged Items<span class="text-danger">*</span></label>
                            <div class="col-sm-6">
                            <select class="form-select form-control" id="js-example-data-ajax" style="width:100%;height: 15px;"></select>
                        </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"></div>
                            <div class="col-md-9">
                                <div class="card">
                                    <p Class=" d-flex justify-content-center mt-3">CHARGED ITEMS</p>
                                    <table class="table table-hover table-vcenter mb-0 text-nowrap" id="table">
                                    <thead>
                                            <tr>
                                                <th>No#</th>
                                                <th>Item Name</th>
                                                <th>Attribute</th>
                                                 <th>Size</th>
                                                <th>UOM</th>
                                                 <th>Qty</th>
                                                <th>Price
                                                  <div  class="cust_popup" id="cashInv" style="display: none">
                                                    <h6>Change price</h6>
                                                <div id="prcresInv"></div>
                                             </div>
                                                </th>
                                                 
                                                <th>Total</th>
                                                <th>Bal</th>
                                                <th>Action</th>
                                            </tr>
                                    </thead>
                                    <tbody id="show_item">

                                    </tbody>
                                    </table>
                                    <table>
                                        <tr>
                                        <th class="col-sm-8"></th>
                                        <th colspan=4 id="totalp">
                                        <!-- <span id="totalp" style="margin-left:400px;"></span> -->
                                        </th>
                                        </tr>
                                        </table>
                                </div>
                            </div>
                        </div><br>
                    </form>
                    <script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>

                    <script type="text/javascript">
                        var hold_selected_items = []; // hold all selected items

    $(document).ready(function(){
        
         $('#js-example-data-ajax').select2({
            ajax: {
               // url: "<?= base_url('load_accomodation'); ?>",
                url: "<?= base_url('/index.php/AccomodationController/load_purchase_data'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            },
            escapeMarkup: function (markup) {
                        return markup; // Don't escape HTML
                        },
                        templateResult: function (data) {
                        return data.text; // Render the full HTML in 'text'
                        },
        });

        $('#js-example-data-ajax').on('select2:select', function (e) {
            selectedItems();
        });
        //var prc; 
        function selectedItems(){  
            var rows = '';
           var itemData = 'item_selected='+$('#js-example-data-ajax').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Accomodationdata1')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }else{
                        var len  = data.length;
                        
                        for (var i = 0; i <len; i++ ){
                            hold_selected_items.push(data[i]['id']);// push all selected items
                            var prc = data[i]['iprice'];
                            price= prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
                            var name = data[i]['iname'];
                            var size = data[i]['isize'];
                            var attribute = data[i]['iattribute'];
                            var iid = data[i]['id'];
                             var item_balance = data[i]['item_balance'];
                            //var qty = window.prompt("Enter quantity");
                            //var tprice = qty*prc;
                           
                            
                            rows += '<tr id="table_row'+ iid +'">';

                           rows+='<td><input type="hidden" name="iid[]" value="'+iid+'">'+ iid +'</td>';
                             rows+='<td>'+ name +'</td>';
                            //rows += '<td>'+ name +'</td>';
                            rows += '<td>'+ attribute +'</td>';
                            rows += '<td>'+ size +'</td>';
                            rows += '<td>'+ 1 +'</td>';
                            rows += '<td><input type="text" value="'+1+'" style="border:none;cursor:pointer;width:20px;text-align:right;" id="quantity'+iid+'" name="quantity'+iid+'" onkeyup="changeQuantity('+iid+')"></td>';
                            // rows += '<td><input type="hidden"  name="price'+iid+'" value="'+prc+'">'+ prc +'</td>';
                            rows += '<td><a class="cost" id="costInv' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getidInv(' +iid+ ','+prc+')"><input type="text" value="'+prc+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" name="price'+iid+'" id="pric'+iid+'" readonly></a></td>';
                            rows += '<td id="ttl'+iid+'">'+price+'</td>';
                            rows += '<td id="bal'+iid+'">'+item_balance+'</td>';
                            //rows += '<td><input type="text" name="tprice" id="tprice'+iid+'" style="width:85px; border:none; background-color:rgb(240,240,240)" readonly></td>';
                            rows += '<td><a href="javascript:RemoveSelectItemRow('+iid+','+i+');" class="btn btn-danger btn">X</a></td>';
                            
                            rows += '</tr>';
                            $('#show_item').append(rows);
                            calculateTotal();
            
                        }
                      
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }
                
           });  
        }

    });
     function RemoveSelectItemRow(item_id,v){
       // alert('two');
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }
       
        //alert(sumVal);
        var k=v+1;
        var table = document.getElementById("table");
        var data=parseInt(table.rows[k].cells[7].innerHTML);
        
         
         //var col1=currentRow.find("td:eq(7)").text();
        
        $('#table_row'+item_id).remove();
        calculateTotal();
    }

       function getidInv(id,prc) {
    
     $('#cashInv').toggle(100);
     
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/priceview'; ?>",
            beforeSend: function () {
                $('#prcresInv').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#prcresInv').html(result);
                console.log(prc);
               // alert(prc);
             document.querySelector('[id="cash_amt"]').value = prc;
             document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }


      totalsum=0;
       function savebtn(){
      //alert(sum);
     
      var cash=$('#cash_amt').val();
      var item_id=$('#item_id').val();
      //alert(item_id); 
      for( var i = 0; i < hold_selected_items.length; i++){ 
           id1=hold_selected_items[i];
           if(id1==item_id){
            var cashAmt =parseInt(cash);
            document.querySelector('[id="pric'+id1+'"]').value = cashAmt;
            var qty=$('#quantity'+item_id).val();

            document.getElementById("ttl"+id1).innerHTML = (qty*cashAmt).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

           // $('#cost'+id1+'').append(cashAmt);
           }else{
            var cashAmt1 =$('#pric'+id1+'').val();
            let result = cashAmt1.replace(/,/gi, "");
            var cashAmt =parseInt(result);
           // alert(cashAmt);
           }
       
       // totalsum=totalsum+cashAmt;
        }
         // var table = document.getElementById("table"), totalsum=0;
            
         //    for(var i = 1; i < table.rows.length; i++)
         //    {
               
         //        totalsum = totalsum + parseInt(table.rows[i].cells[7].innerHTML.replace(/,/gi, ""));
         //    }  
          //  alert(sumVal);     
          $('#cashInv').hide(); 
            //   document.getElementById("totalp").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            // console.log(totalsum);
          calculateTotal();
           return totalsum;       
         e.preventDefault(); 
    }
                    </script>