 <?php
  $bmodel = new App\Models\BillingModel();
  $cmodel = new App\Models\ClassesModel();
  $appItems = $cmodel->get_applications_items();
  $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'trans_type' =>$recpt[0]->trans_type_id));
  $invoice_type = $bmodel->get_item_join_table($recpt[0]->trans_number);
  $student_name = "";
  $name_type = "";
if(count($leger_transaction) > 0){
    $amount = $leger_transaction[0]->amount;
    if($leger_transaction[0]->name_type_id == 4){
        $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $itm_details = $bmodel->get_item_name('item_transation_tbl',$where = array('trans_number' =>$recpt[0]->trans_number));
    }
    else if($leger_transaction[0]->name_type_id == 3){
    $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
     $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
      $student_id = $app[0]->id;
       $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
            $name_type = $type_name[0]->name_type;
              $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2));
   }else if($leger_transaction[0]->name_type_id == 1){
        $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        
        $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2,'transation_nature' =>1));
   }else if($leger_transaction[0]->name_type_id == 6){
        $app = $bmodel->get_item_name('other_students_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        
        $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2,'transation_nature' =>1));
   }
    $control_number="";
     if($leger_transaction[0]->name_type_id == 4){
 $control_no = $bmodel->get_item_name('payment_request',$where = array('student_id' =>$app[0]->id,'trans_no'=>$app[0]->id,'trans_type'=>1));

            }else{
    $inv_no = $bmodel->get_item_name('transactions_relation',$where = array('receipt_trans_no' =>$recpt[0]->trans_number));
    $control_no = $bmodel->get_item_name('payment_request',$where = array('student_id' =>$app[0]->id,'trans_no'=>$inv_no[0]->invoice_trans_no));
    }
    if(count($control_no) > 0){
    $control_number = $control_no[0]->reference_no;

    $channel = $bmodel->get_item_name('payment_response',$where = array('reference_no' => $control_number));

    if(count($channel)>0){
     $chann=$control_no[0]->payment_channel;
     $channel_name=$channel[0]->transaction_channel;
     $cus_name=$channel[0]->customer_name;
     if($chann==2){
        $ch="NMB-".$channel_name;
     }else{
        $ch="CRDB-".$channel_name;
     }
 }
    }

    $company_reg = $bmodel->get_table_details('company_tbl');
 //   $pay_dtls = $bmodel->get_item_name('payment_response',$where = array('reference_no' =>$control_number));
   
   
}

$check_rev = $bmodel->get_item_name('receipt_transfer_tbl',$where = array('new_receipt_number' =>$recpt[0]->trans_number));
                      if(count($check_rev) > 0){
                        $ch="Reversal ".$check_rev[0]->reversal_number;
                        $control_number="";
                      }
 ?>
<div class="row">
<div class="col-md-12">
    <!-- <center><b style="font-size:14px"><u>RECEIPT</u></b></center> -->
    <center>
      <div> <img src="<?php  echo base_url('public/company_photos/'.$company_reg[0]->logo_name) ?>" style="background: white;width: 25%;height: 25%" ></div>
 <span class="mt-4"><b><?= $company_reg[0]->company_name; ?> </b></span><br>
            <span class="modify" style="font-size:15px"><?= $company_reg[0]->address; ?></span>
            <div class="mb-3">
                <div><span class="modify" style="font-size:15px">Phone: +<?= $company_reg[0]->phone1; ?></span></div>
                <div><span class="modify" style="font-size:15px">Email: <?= $company_reg[0]->email; ?></span></div>
                <div><span class="modify" style="font-size:15px"> <?= $company_reg[0]->website; ?></span></div>
             
            </div>
   <span class="mt-3"> <b style="font-size:14px"><u>REVERSAL</u></b></span>
    </b>
</center>
    <hr>
    <table class="table table-borderless">
        <tr>
            <th>Reversal Number:</th>
            <td><?= $check_rev[0]->reversal_number; ?></td>
        </tr>
        <tr>
            <th>Reversal Date:</th>
            <td><?=  $check_rev[0]->date_created; ?></td>

        </tr>
        <tr>
            <th>Paid by:</th>
            <td><?= $name_type; ?></td>
        </tr>
        <tr>
            <th>Payer Name:</th>
            <td><?= $student_name; ?></td>
        </tr>
        <tr>
            <th>Reversal Amount:</th>
            <td><?= number_format($check_rev[0]->amount_transfered); ?></td>
        </tr>
        <tr>
           <th>Reversed rct No:</th>
            <td><?=  $check_rev[0]->old_receipt_number; ?></td>
        </tr>
         <tr>
            <th>Receipt Date:</th>
        <td><?= $recpt[0]->trans_date; ?></td>
        </tr>
         <tr>
            <th>Reversal resoan:</th>
            <td><?= $check_rev[0]->reasons; ?></td>
        </tr>
    </table>
    <hr>
</div>
</div>    
 
    <?php
    $pname=array();
    if($control_number!=""){
      $pname = $bmodel->get_item_name('payment_response',$where = array('reference_no' =>$control_number));  
    }
 
    ?>  
<div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
      
        <table>
        <?php
        $leg = $bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$recpt[0]->trans_number,'trans_type_id' =>2));
     $recv = $bmodel->get_item_name('users',$where = array('user_id' =>$leg[0]->updated_by));

        ?>
        <tr>
            <td><i>Received by: <?php echo $recv[0]->first_name." ".$recv[0]->last_name." ".$leg[0]->trans_date ?></i></td>
        </tr>
    </table>  
<!--    </div>-->
    </div>
</div> 
<br>
<center>
    <i><span>Powered by Micro Health Initiative</span></i>
</center>
<script>
function printable_rept(area) {
  var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
  disp_setting += "scrollbars=yes,width=750, height=600, left=80, top=25";
  var content_value = document.getElementById(area).innerHTML;

  var docprint = window.open("", "", disp_setting);
  docprint.document.open();
  docprint.document.write('<html><head><title>MHI</title>');

  // Add a <style> block to set the font family and other print-specific styles
  docprint.document.write('<style>');
  docprint.document.write('@media print {');
  docprint.document.write('  body {');
  docprint.document.write('    font-family: "Times New Roman", sans-serif;');
  docprint.document.write('    font-size: 15px;');
  docprint.document.write('  }');
  docprint.document.write('</style>');

  docprint.document.write('</head><body onLoad="self.print()" style="width:100%;">');

  // Modify content_value to include the colspan attribute
  var modifiedContent = content_value.replace('<td class="colspan-cell">', '<td colspan="2" class="colspan-cell">');
  docprint.document.write(modifiedContent);

  docprint.document.write('</body></html>');
  docprint.document.close();
  docprint.focus();
}

</script>


