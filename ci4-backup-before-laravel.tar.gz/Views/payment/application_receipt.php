 <?php
  $bmodel = new App\Models\BillingModel();
  $cmodel = new App\Models\ClassesModel();
  $appItems = $cmodel->get_applications_items();
  
  $recpt = $bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$leger_transaction[0]->trans_no,'trans_type_id'=>2));
  $invoice_type = $bmodel->get_item_join_table($recpt[0]->trans_number);
  $student_name = "";
  $name_type = "";
if(count($leger_transaction) > 0){
    $amount = $leger_transaction[0]->amount;
    
        $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $itm_details = $bmodel->get_item_name('item_transation_tbl',$where = array('trans_number' =>$recpt[0]->trans_number,'trans_type'=>2));
    
   
    $control_no = $bmodel->get_item_name('payment_request',$where = array('student_id' =>$app[0]->id,'trans_type'=>1,'inv_type'=>1));
    if(count($control_no) > 0){
    $control_number = $control_no[0]->reference_no;

     $channel = $bmodel->get_item_name('payment_response',$where = array('reference_no' => $control_number));
     $chann=$control_no[0]->payment_channel??"";
     $channel_name=$channel[0]->transaction_channel??"";
     $cus_name=$channel[0]->customer_name??"";
     if($chann==2){
        $ch="NMB-".$channel_name;
     }else{
        $ch="CRDB-".$channel_name;
     }

    }
    $company_reg = $bmodel->get_table_details('company_tbl');
 //   $pay_dtls = $bmodel->get_item_name('payment_response',$where = array('reference_no' =>$control_number));
   
   
}else{
    echo "No data found";
}

 ?>
 <div id="printcashdtls">

<div class="row">
<div class="col-md-12">
   
   <center>
      <p> <img src="<?php  echo base_url('public/company_photos/'.$company_reg[0]->logo_name) ?>" style="width: 50%;height: 120px" ></p>
 <span class="mt-4"><b><?= $company_reg[0]->company_name; ?> (EGET)</b></span><br>
            <span class="modify" style="font-size:15px"><?= $company_reg[0]->address; ?></span>
            <div class="mb-3">
                <div><span class="modify" style="font-size:15px">Phone: +<?= $company_reg[0]->phone1; ?></span></div>
                <div><span class="modify" style="font-size:15px">Email: <?= $company_reg[0]->email; ?></span></div>
                <div><span class="modify" style="font-size:15px"> <?= $company_reg[0]->website; ?></span></div>
             
            </div>
   <span class="mt-3"> <b style="font-size:14px"><u>RECEIPT</u></b></span> 
    </b>
</center>
    <hr>
    <table class="table table-borderless">
        <tr>
            <th>Receipt Number:</th>
            <td><?= $leger_transaction[0]->trans_no; ?></td>
        </tr>
        <tr>
            <th>Receipt Date:</th>
            <td><?= $recpt[0]->trans_date; ?></td>
        </tr>
        <tr>
            <th>Paid by:</th>
            <td><?= $name_type; ?></td>
        </tr>
        <tr>
            <th>Payer Name:</th>
            <td><?= $student_name; ?></td>
        </tr>
    </table>
    <hr>
</div>
</div>    
    <div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
        <p class=" d-flex justify-content-center mt-3" style="font-size:18px">RECEIPT DETAILS</p>
        <?php if($leger_transaction[0]->name_type_id == 4){ ?>
            
            <table class="table">
                <thead>
                    <tr>
                        <th>REF TYPE</th>
                        <th>APPL NO</th>
                        <th>AMOUNT</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                   
                    $total = 0;
                    foreach($itm_details as $itm){
                        $total+=$itm->unit_price;
                    ?>
                 <tr>
                    <td>Application</td>
                    <td><?=$leger_transaction[0]->name_id; ?></td>
                    <td><?= number_format($itm->unit_price);?></td>
                </tr>
                <?php } ?>
                 <tr>
                     <td colspan="2"><b>Total</b></td>
                    <th><b><?= number_format($total); ?></b></th>
                </tr>   
            </tbody>
        </table>    
                <?php }  else if($leger_transaction[0]->name_type_id == 1){?>
                    <table class="table">
                    <thead>
                        <tr>
                            <th>REF TYPE</th>
                            <th>REF NUMBER</th>
                            <th>Inv Amount</th>
                            <th>Amount Due</th>
                            <th>Amount Paid</th>
                        </tr>
                    </thead>
                    <tbody>
                   <?php
                            $total = 0;
                            foreach($ledger_invoice as $itm){
                                $invamount = 0;
                                $trans_type = $bmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>$itm->trans_type));
                                $get_invoice = $bmodel->get_item_name('transactions_relation',$where = array('receipt_trans_no' =>$itm->id));
                                $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('id' =>$get_invoice[0]->invoice_trans_no));
                                 $ledger_invoice_ttl = $bmodel->get_total_amount_payed($ledger_invoice[0]->trans_no, 7);
                               // if(count($ledger_invoice_ttl) > 0){
//                                    foreach($ledger_invoice_ttl as $legerttl){
//                                         $invamount +=$legerttl->amount;
//                                    }
                             //   }
                            ?>
                            <tr>
                                <td><?= $trans_type[0]->type_name; ?></td>
                                <td><?= $itm->trans_no; ?></td>
                                <td><?= number_format($ledger_invoice_ttl[0]->amount); ?></td>
                                <td class="text-right"><?= number_format($ledger_invoice_ttl[0]->amount - $itm->amount);?></td>
                                <td class="text-right"><?= number_format($itm->amount);?></td>
                            </tr>
                   <?php } ?>
                 <tr>
                     <td colspan="2"><b>Total</b></td>
                    <th><b></b></th>
                    <th><b></b></th>
                    <th><b><?= number_format($total); ?></b></th>
                </tr>   
            </tbody>
        </table>
       <?php } ?>
    <!--</div>-->
   
    </div>
    </div>   
<div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
        <p class=" d-flex justify-content-center mt-3" style="font-size:18px">PAYMENT DETAILS</p>
        <table class="table">
            <thead>
                <tr>
                    <th>CHANNEL</th>
                    <th>PAYER</th>
                    <th>CTR NO</th>
                    <th>AMOUNT</th>
                </tr>
            </thead>
            <tbody>
                <?php
                   $dbname=session()->get('db_name');
                     $db = \Config\Database::connect($dbname);
                     $query = $db->query('SELECT amount,account_name FROM ledger_transaction_tbl,accounts_tbl where ledger_transaction_tbl.ledger_id = accounts_tbl.id AND transation_nature = 2 AND trans_type=2 AND trans_no='.$recpt[0]->trans_number );
                     $result = $query->getResult();
                     $paytotal = 0;
                     foreach($result as $rsl){
                      $paytotal += $rsl->amount;
                ?>
                <tr>
                    <td><?= ($ch)??"Cash"; ?></td>
                    <td><?= ($cus_name)??$student_name; ?></td>
                    <td><?= ($control_number)??""; ?></td>
                    <td><?= number_format($paytotal); ?></td>
                </tr>
             <?php }
              $get_charges = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_id' =>22,'transation_nature' =>1,'trans_type' =>2));
                  
                   if(count($get_charges)>0){

                   $paytotal=$paytotal-$get_charges[0]->amount;
                ?>
                 <tr>
                     <td colspan="2" class="colspan-cell">Bank charges</td>
                    <th><b></b></th>
                  
                    <th class="text-right">-<?= number_format($get_charges[0]->amount); ?></th>
                </tr>
            <?php }?>
                <tr>
                     <td colspan="3"><b>Total</b></td>
                    <th><b><?= number_format($paytotal); ?></b></th>
                </tr> 
            </tbody>
        </table>  
     <center>    
    <table>
        <?php
     $recv = $bmodel->get_item_name('users',$where = array('user_id' =>$recpt[0]->updated_by));

        ?>
        <tr>
            <td><i>Received by: <?php echo $recv[0]->first_name." ".$recv[0]->last_name." ".$recpt[0]->trans_date ?></i></td>
        </tr>
    </table> 
    </center> 
<!--    </div>-->
    </div>
</div> 

<br>
<center>
    <i><span>Powered by Micro Health Initiative</span></i>
</center>
<script>
  
</script>


