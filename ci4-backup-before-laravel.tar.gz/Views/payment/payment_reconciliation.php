   <?php
                               
$amodel = new App\Models\AdmissionModel();
$bmodel = new App\Models\BillingModel();
$smodel = new App\Models\StudentModel();

?>
 <script type="text/javascript">
        var isRefreshing = false;
     // alert('2');
       
       var baseUrl = '<?php echo base_url(); ?>';
       
      function refresh_payment(ctr, ref, rctn) {
    if (isRefreshing) {
        return; // Exit the function if a request is already ongoing
    }
    isRefreshing = true;
    var data = "ctr=" + ctr + "&ref=" + ref;

    $.ajax({
        type: 'GET',
        url: baseUrl + '/index.php/AdmissionController/make_receipt/', // Ensure baseUrl is defined
        data: data,
        beforeSend: function () {
            $('#refreshBtn').hide();
            $('#loading').html('<center><b><span class="fa fa-spin fa-spinner"></span></b></center>');
        },
        success: function (res) {
            if (res == 1) {
                check_paymentAgain(ctr, rctn);
            } else {
                $('#refreshBtn').show();
                toastr.error('Failed to create receipt');
            }
        },
        error: function () {
            $('#refreshBtn').show();
            toastr.error('Error encountered');
        },
        complete: function () {
            $('#loading').hide();
            isRefreshing = false;
        }
    });
}
      function check_paymentAgain(ctr,rctn){
        var data="ctr="+ctr+"&ref="+rctn;
          $.ajax({
            type: 'GET',
            url: '<?php echo base_url() . '/index.php/AdmissionController/check_receipt/'; ?>',
            data:data,
             beforeSend: function () {
                    $('#loading').html('<center><b><span class="fa fa-spin fa-spinner"></span> </b></center>');
                },
           
            success: function (res) {
            if(res==1){
                  
                 $('#loading').show();
          $('#loading').html('<span class="fa fa-check"></span>');
            }else{
                $('#refreshBtn').show();
                 $('#loading').hide();
           toastr.error('Fail to create receipt');
             }
             },
            error: function (){
                 $('#refreshBtn').show();
                 $('#loading').hide();
                toastr.error('error encounted');
            }
        });
      }
      </script>
                    <div class="card">
                        <div class="card-header" style="height:5px">
                        <h3 class="card-title">Payments received through <span style="color: red"><?= $ref;?></span> </h3>
                        <div class="card-options ">
                            <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                        </div>
                    </div>
                    <hr>
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                     <th>RCT No</th>
                                    <th>RCT Name</th>
                                    <th>trans Date</th>
                                    <th>trans ref</th>
                                   <th>amount</th>
                                    <th>phone</th>
                                    <th>Channel</th>
                                    <th>Received</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i=0;
                                if($status==500){
                                    foreach ($transactions as $trans) {
                                        $i++;
                                       $check_rct = $bmodel->get_item_name('payment_response', $where = array('transaction_receipt' => $trans['receipt_no'],'transaction_date'=>$trans['transaction_date'])); 
                                  if(count($check_rct)>0){
                                     $check=1;
                                       }else{

                                    $check_again = $bmodel->get_item_name('payment_response', $where = array('reference_no' => $ref,'amount_payed'=>$trans['amount'],'transaction_date'=>$trans['transaction_date'])); 
                                    if(count($check_again)>0){
                                     $check=1;
                                    }else{
                                        $check=0;
                                        $rctn=$trans['receipt_no'];
                                        $n_ref=$trans['transaction_ref'];
                                        ?>
                                         <script type="text/javascript">
                                      refresh_payment('<?= $ref?>','<?= $n_ref?>','<?= $rctn?>');
                                         </script>
                                        <?php
                                    }
                                    }
                                   ?>
                                    <tr>
                                    <td><?php echo $i;?></td>
                                    <td><?php echo $trans['receipt_no'];?></td>
                                    <td><?php echo $trans['payer_name'];?></td>
                                    <td><?php echo $trans['transaction_date'];?></td>
                                    <td><?php echo $trans['transaction_ref'];?></td>
                                  
                                    <td class="text-right"><?php echo number_format($trans['amount']);?></td>
                                    <td><?php echo $trans['phone_no'];?></td>
                                    <td><?php echo $trans['transaction_channel'];?></td>
                                    <?php
                                   if($check==1){
                                    ?>
                                  <td class="text-green"><span class="fa fa-check"></span></td>
                                    <?php
                                   }else{
                                    ?>
                                 <td >
                                    <div id="loading"></div>
                                    <div id="refreshBtn">
                                          <span class="fa fa-times"></span>
                                    <!--<a href="javascript:void(0)" onclick="refresh_payment('<?php echo $ref;?>','<?php echo $trans['transaction_ref'];?>','<?php echo $trans['receipt_no'];?>')"  class="btn btn-warning btn-sm"><i class="fa fa-times"></i> Refresh</a>-->
                                    </div>
                                 </td>
                                <?php }?>
                                    </tr>

                                    <?php
                                  }
                                }else{
                                    ?>
                                 <tr>
                                    <td><?php echo $statusDesc;?></td>
                                 </tr>
                                    <?php
                                   }
                              
                                ?>

                                </tbody>
                        </table>
                    </div>
                </div>

    

