 
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>Note Type</th>
                                    <th>Note No.</th>
                                    <th>Note Date</th>
                                    <th>Note Type</th>
                                    <th>Student Name</th>

                                    <th>Amount</th>
                                     <th>sms Status</th>
                                     <th>Trans By</th>
                                     <th>Trans Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $amodel = new App\Models\AdmissionModel();
                                $bmodel = new App\Models\BillingModel();
                                $smodel = new App\Models\StudentModel();
                               $account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));

                              $dbname=session()->get('db_name');
                    $db = \Config\Database::connect($dbname);
                                    foreach($trans as $s){
                            
                            $by = $bmodel->get_item_name('users',$where = array('user_id' =>$s->updated_by));
                                    $invoice_type = $bmodel->get_item_join_table11($s->trans_number,6);
                                    $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type'=>6,'transation_nature'=>2));
                                     //print_r($leger_transaction[0]->name_id);
                                    $student_name = "";
                                    $control_number = "";
                                    $name_type = "";
                                    $totalAmount =0;
                                    $amount=0;
                                    if(count($leger_transaction) > 0){
                                        // $totalAmount +=$leger_transaction[0]->amount;
                                        // $amount = $bmodel->get_total_amount($leger_transaction[0]->name_id,$leger_transaction[0]->trans_no);
                                        $ledgeramount = $bmodel->get_item_name('item_transation_tbl', $where = array('trans_number' => $leger_transaction[0]->trans_no,'trans_type'=>6));
                                        foreach ($ledgeramount as $a) {

                                            $amount = $a->quantity * $a->unit_price;
                                             if($a->item_id==64){
                                            $totalAmount -= $amount;
                                        }else{
                                           $totalAmount += $amount;  
                                        }
                                        }

                                        if($leger_transaction[0]->name_type_id == 4){
                                            echo $leger_transaction[0]->name_id;
                                            echo '<br>';
                             $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                      $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                            $name_type = $type_name[0]->name_type;
//                                     
                                        }else if($leger_transaction[0]->name_type_id == 1){
                                            $admn = $bmodel->get_item_name('students', $where = array('id'=>$leger_transaction[0]->name_id));
                                            $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name;
                                            $student_id=$admn[0]->id;
                                            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                            $name_type = $type_name[0]->name_type;

                                            $cnumber = $bmodel->get_item_name('payment_request', $where = array('student_id'=>$leger_transaction[0]->name_id,'trans_no'=>$s->trans_number)); 

                                            $cnumber = $bmodel->get_item_name('payment_request', $where = array('student_id'=>$leger_transaction[0]->name_id,'trans_no' =>$leger_transaction[0]->trans_no)); 

                                            if(count($cnumber) > 0){
                                                $control_number = $cnumber[0]->reference_no;
                                            }
                                        }
                                    }
                                        
                                   $msg_status = $bmodel->get_item_name('message_groups_tbl', $where = array('trans_number' => $s->trans_number,'message_type'=>11)); 
                                    if(count($msg_status)>0){
                                         $msg_st = $bmodel->get_item_name('messages', $where = array('send_no' => $msg_status[0]->send_number));
                                         if(count($msg_st)>0){
                                             if($msg_st[0]->time_sent==null){
                                           
                                $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_RETURNTRANSFER => 1,
                        CURLOPT_URL => 'http://www.sms.co.tz/api.php?do=dlr&id=' . $msg_st[0]->message_id . '&username=' . SMS_UNAME . '&password=' . SMS_PASSWORD . '&senderid=' . SENDER_ID . '',
                            ));
                     $msg_status = curl_exec($curl);
                     if($msg_status != ""){

                       list($sntdate, $stts, $deldate) = explode(',', $msg_status);

                       $tempsmsdata = array(
                           'sent_status' => 2, //Sent and delivered
                           'time_sent' => $sntdate,
                           'status_description' => $stts,
                           'time_delivered' => $deldate
                       );
                       //print_r($tempsmsdata);
                        $smodel->update_table_details('messages',$where = array('message_id' => $msg_st[0]->message_id),$tempsmsdata);
                        // echo 'updated';
          
                           }
                            $msg_s = $bmodel->get_item_name('messages', $where = array('message_id' => $msg_st[0]->message_id));

                                         $del=$msg_s[0]->status_description;
                                         $time=$msg_s[0]->time_delivered;
                                         $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                                             }else{
                                       $stata='<span style="color:red">Not Sent';
                                             }

                                         }else{
                                          $stata='<span style="color:red">Not Sent';  }

                                         }else{
                                       $stata='<span style="color:red">Not Sent';  
                                     }    
                                    
                                    
                                     $debit = $db->query('SELECT sum(balance) as balance  FROM  ledger_transaction_tbl  
                                                            WHERE trans_no = '.$s->trans_number.' AND ledger_type = 7 and transation_nature = 1 and trans_type = 6'); 
                                     $debit_total = $debit->getResult(); 
                                   //  print_r($debit_total);
                                    $diff = $debit_total[0]->balance; 
                                  
                                  
                                $trans = $bmodel->get_item_name('transaction_use_relation_tbl',$where = array('used_no' =>$s->trans_number,'trans_type' =>6));
                                if(count($trans)>0){
                                    $clss="disabled";
                                }else{
                                     $clss="";
                                }
                                      

                                    if($diff != 0){
                                        $status = "<b style='color:green;'>open</b>";
                                    ?>
                                <!-- <tr onclick="location.href='<?php //echo base_url() .'/index.php/BillingController/invoice_receipt/'.$student_id; ?>'"> -->
                                <tr>
                                    <td><?php echo $invoice_type[0]->type_name??"";?></td>
                                    <td><?php echo $s->trans_number;?></td>
                                    <td><?php echo $s->trans_date ;?></td>
                                    <td><?php echo $name_type;?></td>
                                    <td><?php echo $student_name;?></td>
                                   
                                    <td><?= number_format($totalAmount); ?></td>
                                     <td><?= $stata; ?></td>
                                     <td><?= $by[0]->first_name." ".$by[0]->last_name; ?></td>
                                     <td><?= $s->updated_date; ?></td>
                                    <td><?=  $status; ?></td>
                                    <td>
                                        <a href="javascript:void(0)"  class="btn btn-primary btn-sm invoiceprint" data-bs-toggle="modal" data-bs-target="#invoiceview" onclick="edit_invoice(<?php echo $s->id;?>)"><i class="fa fa-edit"></i> Edit</a>
                                        <a href="javascript:void(0)"  class="btn btn-primary btn-sm invoiceprint" data-bs-toggle="modal" data-bs-target="#viewinvoice" onclick="manage_invoice(<?php echo $s->id;?>)"><i class="fa fa-eye"></i> View</a>
                                        
                                         
                                    </td>
                                    
                                </tr>
                            <?php }else { $status = "<b style='color:red;'>Closed</b>"; ?>
                                <tr>
                                    <td><?php echo $invoice_type[0]->type_name??"";?></td>
                                    <td><?php echo $s->trans_number;?></td>
                                    <td><?php echo $s->trans_date ;?></td>
                                    <td><?php echo $name_type;?></td>
                                    <td><?php echo $student_name;?></td>
                                   
                                    <td><?= number_format($totalAmount); ?></td>
                                     <td><?= $stata; ?></td>
                                     <td><?= $by[0]->first_name." ".$by[0]->last_name; ?></td>
                                     <td><?= $s->updated_date; ?></td>
                                    <td><?=  $status; ?></td>

                                    <td>
                                        <a href="javascript:void(0)"  class="btn btn-primary btn-sm disabled" data-bs-toggle="modal" data-bs-target="#invoiceview" onclick="edit_invoice(<?php echo $s->id;?>)"><i class="fa fa-edit"></i> Edit</a>

                                        <a href="javascript:void(0)"  class="btn btn-primary btn-sm invoiceprint" data-bs-toggle="modal" data-bs-target="#viewinvoice" onclick="manage_invoice(<?php echo $s->id;?>)"><i class="fa fa-eye"></i> View</a>
                                       
                                    </td>
                                </tr>
                            <?php }}?>
                            </tbody>
                        </table>
                    </div>

            <script type="text/javascript">
  $(document).ready(function () {
  $('#myTable').DataTable();
});

  function dalete_creditNote(id){

swal({
            title: "Are you sure?",
            text: "You will not be able to recover this Credit!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
                 $('#viewinvoice').hide(); 

              $.ajax({
                  url: "<?= base_url('/index.php/BillingController/DeleteCreditNote')?>/"+id,
                 error: function() {
                     toastr.error("Something is wrong","error");
                  //  alert('Something is wrong');
                 },
                 success: function(data) {
                      if(data==1){
                      swal("success","Deleted successfuly","success");
                      }else{
                         toastr.error("Sorry!, Something went wrong","error"); 
                      }
                
                 refreshPage();
                      
                 }
              });

            } else {
                
               swal("Cancelled");
            }

          });
  }

  function refreshPage() {
           $('#viewinvoice').modal('hide'); 
            $('#cdtResult').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-all span').html();
          
            $.ajax({
                type: "POST",
                url: "<?php echo base_url() . '/index.php/BillingController/fetch_creditNote'; ?>",
                data: dta,
                success: function (res) {
                    $('#cdtResult').html(res);
                },
                error: function () {
                    $('#cdtResult').html('<div class="alert alert-warning">Fail to retreive credit note.!!</div>');
                }
            });

    };

   </script>