
<?php
   $bmodel = new App\Models\BillingModel();
   $ctype= $bmodel->get_table_details('name_type_tbl');
?>

<div class="section-body mt-4">
    <div class="container-fluid">
             
                <div class="card">
               <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <!-- <th>No.#</th> -->
                                    <th>Rvs No.</th>
                                    <th>Rvs Date</th>
                                    <th>Customer Name</th>
                                    <th>Name Type</th>
                                    <th> Amount</th>
                                    <th>Reversed By</th>
                                    <th>sms Status</th>
                                    <th>Trans Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                 if(count($trans)>0){
                                    foreach($trans as $s){
                                    
                                    $tnc = $bmodel->get_item_name('receipt_transfer_tbl', $where = array('reversal_number' => $s->trans_number));
                                    if(count($tnc)>0){
                                        if($tnc[0]->trans_type!=3){
                                            continue;
                                        }
                                    }else{
                                  $tnc = $bmodel->get_item_name('reverse_deposit_tbl', $where = array('reversal_number' => $s->trans_number));
                                  if(count($tnc)==0){
                                     continue;
                                  }else{
                                 $tnc[0]->new_receipt_number= $tnc[0]->new_deposit_number;
                                  $tnc[0]->trans_type=3;
                                  }
                                         
                                    }
                                   // $invoice_type = $bmodel->get_item_join_table($s->trans_number);
                                    $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type' =>7));
                                  
                                    $student_name = "";
                                    $student_id = "";
                                    $control_number = "";
                                    $name_type = "";
                                    $amount =0;
                                    $chargesb=0;
                                    
                                    if(count($leger_transaction) > 0){
                                   
                                       $amount=$leger_transaction[0]->amount;  
                                       if($leger_transaction[0]->name_type_id == 1){
                                             $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }else if($leger_transaction[0]->name_type_id == 6){
                                             $app = $bmodel->get_item_name('other_students_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }
                                        
                                    

                                    $user = $bmodel->get_item_name('users', $where = array('user_id' => $s->updated_by));

                                     $msg_status = $bmodel->get_item_name('message_groups_tbl', $where = array('trans_number' => $s->trans_number,'message_type'=>9));
                                     if(count($msg_status)>0){
                                         $msg_st = $bmodel->get_item_name('messages', $where = array('send_no' => $msg_status[0]->send_number));
                                         if(count($msg_st)>0){
                                             if($msg_st[0]->time_sent==null && $msg_st[0]->message_id !=""){
                                            ?>
                                         <script type="text/javascript">
                                        
                                             $(function() {
                                         check_sms('<?php echo $msg_st[0]->message_id;?>');
                                              });
                                         </script>
                                         <?php
                                             }
                                          $msg_st = $bmodel->get_item_name('messages', $where = array('message_id' => $msg_st[0]->message_id));
                                         $del=$msg_st[0]->status_description;
                                         $time=$msg_st[0]->time_delivered;
                                         $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                                     }else{
                                         $stata='<span style="color:red">Not Sent'; 
                                     }
                                     }else{
                                       $stata='<span style="color:red">Not Sent';  
                                     }

                                      // $tnc = $bmodel->get_item_name('receipt_transfer_tbl', $where = array('reversal_number' => $s->trans_number));
                                     // print_r($tnc);
                                         $tnc2 = $bmodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $tnc[0]->new_receipt_number,'trans_type_id'=>$tnc[0]->trans_type));

                                ?>
                                <tr>
                                    <td><?php echo $s->trans_number;?></td>
                                    <td><?php echo date('Y-m-d',strtotime($s->trans_date));?></td>
                                     <td><?php echo $student_name;?></td>
                                    <td><?php echo $name_type ?? "";?></td>
                                    <td><?= number_format($amount); ?></td>
                                    <td><?= $user[0]->first_name.' '.$user[0]->last_name; ?></td>
                                      <td><?php echo $stata;?></td>
                                     <td><?php echo date('Y-m-d H:i',strtotime($s->updated_date));?></td>
                                    <td>
                            <?php 
                            if($s->trans_type_id !=7){
                             if($s->updated_by==9){
                                ?>
                             <a href="javascript:void(0)" onclick="manage_rec(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm" disabled style="pointer-events: none; opacity: 0.5;"><i class="fa fa-edit"></i> Edit</a>
                             <?php
                             }else{
                            ?>
                             <a href="javascript:void(0)" onclick="manage_rec(<?php echo $s->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>
                                    <?php }} ?>
                                  
                                <a href="javascript:void(0)" onclick="revesal_receipt(<?php echo $tnc2[0]->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a>
                               
                                    </td>
                                    
                                </tr>
                            <?php }}}else{
                                echo "<tr><td>Currently there is no record</td></tr>";
                            } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
          
        </div>
   
<div class="modal fade" id="viewRiversal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="Reversal_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('Reversal_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>

<script>

    $(document).ready(function () {
      $('#myTable').DataTable();
    });
    
   function check_sms(msgid){
               // alert(msgid);
       var data = "id=" + msgid;
              $.ajax({
            type: 'POST',
           url: '<?php echo base_url() . '/index.php/SystemController/check_sms/'; ?>'+msgid,
            
            success: function (res) {
            
              
            },
            error: function (){
                alert('error encounted');
            }
        });
            }

        function revesal_receipt(inv){
        //alert(inv);
      $('#viewRiversal').modal('show'); 
      $('#Reversal_content').load('index.php/SemisterController/view_revesal_todeposit/'+inv);
        
    }

  </script>