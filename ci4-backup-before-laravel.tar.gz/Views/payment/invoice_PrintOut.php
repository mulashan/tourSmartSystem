<?php
 helper('calc');
  $bmodel = new App\Models\BillingModel();
  $smodel = new App\Models\StudentModel();
  $cmodel = new App\Models\ClassesModel();
  $appItems = $cmodel->get_applications_items();
  $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$trans[0]->trans_number,'trans_type'=>1));
  $ref = $bmodel->get_item_name('payment_request', $where = array('trans_no' => $trans[0]->trans_number, 'student_id' =>$leger_transaction[0]->name_id));
  $student_name = "";
  $name_type = "";
  $source = "";
  $ref="";
  $adm_id ="";
  $hst="";
  $trns="";
    if(count($leger_transaction) > 0){
        $amount = $leger_transaction[0]->amount;
        if($leger_transaction[0]->name_type_id == 4){
            $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
            $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
            $name_type = $type_name[0]->name_type;     
        }else if($leger_transaction[0]->name_type_id == 1){
            $admn = $bmodel->get_item_name('students', $where = array('id'=>$leger_transaction[0]->name_id));
            $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name; 

            $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $leger_transaction[0]->name_id, 'status' => 1));
            if(count($admissn) > 0){
                $adm_id = $admissn[0]->class_id;
                $hst = $admissn[0]->admission_type;
                $trns = $admissn[0]->vehicle_id;
                $class = $admissn[0]->class_id;
                $level = $admissn[0]->level_id; //temporary soln
            }
            $class = $bmodel->get_item_name('classes_tbl', $where = array('id' => $adm_id));
             }else if($leger_transaction[0]->name_type_id == 6){
            $admn = $bmodel->get_item_name('other_students_tbl', $where = array('id'=>$leger_transaction[0]->name_id));
            $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name; 

            $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $leger_transaction[0]->name_id, 'status' => 1));
            $admissn=array();
            // if(count($admissn) > 0){
            //     $adm_id = $admissn[0]->class_id;
            //     $hst = $admissn[0]->admission_type;
            //     $trns = $admissn[0]->vehicle_id;
            // }
           // $class = $bmodel->get_item_name('classes_tbl', $where = array('id' => $adm_id));
             }

            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
            $name_type = $type_name[0]->name_type;
            $installment = $bmodel->get_item_name('installments_tbl', $where = array('tbl_id' => $adm_id));
            $pay =$bmodel->get_item_name('payment_request', $where = array('trans_no' => $trans[0]->trans_number, 'student_id' =>$leger_transaction[0]->name_id));
             if(count($pay) > 0){
                $ref = $pay[0]->reference_no;
            }
            $company_reg = $bmodel->get_table_details('company_tbl');
            if($company_reg[0]->logo_name != ""){
               $source =  base_url('public/company_photos/'.$company_reg[0]->logo_name);
            }
        
    }
    $check= $bmodel->get_item_name('transaction_numbers_tbl',$where=array('trans_number'=>$trans[0]->trans_number,'trans_type_id'=>1));
             $original_date = $check[0]->trans_date;
            $year = date("Y", strtotime($original_date));
?>
<div class="row">
    <div class="col-md-12">
        <center>
            
             <div> <img src="<?php  echo base_url('public/company_photos/'.$company_reg[0]->logo_name) ?>"  style="background: white;width: 25%;height: 25%" ></div>
 <span class="mt-4"><b><?= $company_reg[0]->company_name; ?> (EGET)</b></span><br>
            <span class="modify" style="font-size:15px"><?= $company_reg[0]->address; ?></span>
            <div class="mb-3">
                <div><span class="modify" style="font-size:15px">Phone: +<?= $company_reg[0]->phone1; ?></span></div>
                <div><span class="modify" style="font-size:15px">Email: <?= $company_reg[0]->email; ?></span></div>
                <div><span class="modify" style="font-size:15px"> <?= $company_reg[0]->website; ?></span></div>
             
            </div>
          <h3><b>INVOICE</b></h3>
        </center>
        <table class="table table-condensed">
            <tr>
                <th align="start">Invoice Number:</th>
                <td><?= $trans[0]->trans_number; ?></td>
            </tr>
            <tr>
                <th style="text-align: left;">Invoice Date:</th>
                <td><?= $trans[0]->trans_date; ?></td>
            </tr>
            <tr>
                <th style="text-align: left;">Customer Type:</th>
                <td><?= $name_type; ?></t style="text-align: left;"d>
            </tr>
            <br>
            <tr>
                <th style="text-align: left;">Student Name:</th>
                <td><?= $student_name; ?></td>
            </tr>
            <tr>
                <?php 
                 if(count($admissn)>0){
                ?>
                <th style="text-align: left;">Student Class</th>
                <td><?= count($class) > 0? $class[0]->class_name:''; ?></td>
            <?php }?>
            </tr>
            <tr>
                <th style="text-align: left;">Reg No:</th>
                <td><?= $admn[0]->id; ?></td>
            </tr>
            <tr>
                <?php 
                 if(count($admissn)>0){
                ?>
                <th style="text-align: left;">Admission No:</th>
                <td><?= count($admissn) > 0?$admissn[0]->id:''; ?></td>
                 <?php }?>
            </tr>
        </table>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <p>INVOICED ITEMS</p>
        <table class="table table-condensed" width="80%">
            <thead> 
                <tr>
                    <th>Item</th>
                    <th>Item Name</th>
                    <th  style="text-align:right">Qty</th>
                    <th  style="text-align:right">Price</th>
                    <th  style="text-align:right">Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $student_id=$admn[0]->id;
                $lvtbl = $bmodel->get_item_name('class_level_tbl', $where = array('id' => $level));
                $trans_numbers=array();
                $trans_numbers[]=array($trans[0]->trans_number);
                  $singleArray = array_values(array_column($trans_numbers, 0));
                 $installments = $bmodel->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$lvtbl[0]->academic_type));
                
                    $dbname=session()->get('db_name');
                    $db = \Config\Database::connect($dbname);
                    
                    $total =0;
                    $amount = 0;
                    $uniform=0;
                    $tea=0;
                    $lunch=0;
                     $new2=0;
                     $gradu=0;
                     $openingbalance=0;
                    $query = $db->query('SELECT item_id,item_name,item_group,trans_number,quantity,unit_price,invoice_type_id FROM item_transation_tbl,items_tbl,invoice_type_transaction where item_transation_tbl.item_id = items_tbl.id AND invoice_type_transaction.trans_no=item_transation_tbl.trans_number AND transaction_type_id = 1 AND trans_type=1 AND trans_number='.$trans[0]->trans_number);
                    $result = $query->getResult();  //

                    foreach($result as $itm){
                         $query2 = $db->query('SELECT amount FROM ledger_transaction_tbl where (ledger_type = 3 OR ledger_type = 4) AND trans_type=1 AND trans_no='.$trans[0]->trans_number);
                         $result2 = $query2->getResult();

                         $amount = $itm->quantity * $itm->unit_price;
                       if($itm->item_group==7){
                        $total -= $amount;
                          }else if($itm->invoice_type_id==8){
                        $openingbalance+=$amount;
                          }
                          else{
                            $total += $amount;
                          }
                        
                       

                       

                ?>
                    <tr>
                     <td><?= $itm->item_id; ?></td>
                     <td><?= $itm->item_name; ?></td>
                     <td align="right"><?= $itm->quantity; ?></td>
                     <td align="right"><?= number_format($itm->unit_price); ?></td>
                     <td align="right"><?= number_format($amount); ?></td>
                 </tr>
            <?php } ?>
                    <tr align="center">
                         <td><b>TOTAL</b></td>

                         <td colspan="3"></td>

                        <td colspan="3" align="right"><b><?php echo number_format($total); ?></b></td>
                    </tr>
            </tbody>
        </table>

        <table class="table table-condensed">
            
            <p class=" d-flex justify-content-start mt-3">PAYMENT INSTRUCTION</p>
            <p>Lipia Kupitia CRDB bank Kumbukumbu Namba  <b> <?= $ref; ?></b></p>
            <?php
            $lg = $bmodel->get_item_name('invoice_type_transaction', $where = array('trans_no' => $trans[0]->trans_number, 'transaction_type_id' => 1));
            if($lg[0]->invoice_type_id!=2){

            }else{

              if(count($installments)==0){
                    return;
                 }
                $results=findCalc($student_id,$dbname,$year);
            ?>
            <p>ALLOWED INSTALLMENTS</p>
            <thead>
                <tr>
                     

                    <th>Term</th>
                    <th>Installments</th>
                    <th>Due Date</th>
                 <th>Paid</th>
                    <th style="text-align:right;">Balance</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                
             
                  $lvtbl = $bmodel->get_item_name('class_level_tbl', $where = array('id' => $level));
                $trans_numbers=array();
                $trans_numbers[]=array($trans[0]->trans_number);
                  $singleArray = array_values(array_column($trans_numbers, 0));
                 $installments = $bmodel->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$lvtbl[0]->academic_type));
                   // $installments = $bmodel->get_table_details('school_terms_tbl');
                   
                    $ttlAmount = 0;
                     $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                      $ddate="";
                    foreach ($installments as $r) {
                        $paid_amount=0;
                         $installmenttotal[$r->id] = 0;
                         $installmentname[$r->id] = $r->term_name; 
                         $installmentid[$r->id] = $r->id;
                         $installmentDate[$r->id] = date('d-m-Y',strtotime($r->start_date));
                        $classTerm = $bmodel->get_item_name('installments_tbl', $where = array('tbl_id' => $adm_id, 'istallment_name' => $r->id, 'installment_type' => 1));
                        if(count($classTerm) > 0){
                            $installmenttotal[$r->id] += $classTerm[0]->amount;
                        }
                        $hstlTerm = $bmodel->get_item_name('installments_tbl', $where = array('tbl_id' => $hst, 'istallment_name' => $r->id, 'installment_type' => 2));
                        if(count($hstlTerm) > 0){
                            $installmenttotal[$r->id] += $hstlTerm[0]->amount;
                        }
                        $transTerm = $bmodel->get_item_name('installments_tbl', $where = array('tbl_id' => $trns, 'istallment_name' => $r->id, 'installment_type' => 4));
                        if(count($transTerm) > 0){
                            $installmenttotal[$r->id] += $transTerm[0]->amount;
                        }
                    
                    $i++;
                     $ment=0;

                      if($i==1){
                   $openingbalance=$results[0]['openingbalance'];
                       $ment=$results[0]['ment'];
                        $mbalance=$results[0]['mbalance'];
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                  
                     }
                      if($i==2){
                         $ment=$results[1]['ment'];
                        $mbalance=$results[1]['mbalance'];
                        $paid_amount=$results[1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     }
                   if($i==3){

                    $ment=$results[2]['ment'];
                        $mbalance=$results[2]['mbalance'];
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     }
                      if($i==4){

                    $ment=$results[3]['ment'];
                        $mbalance=$results[3]['mbalance'];
                        $paid_amount=$results[3]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     }
                   
                ?>  
                <tr>
                    <td><?= $r->term_name; ?></td>
                    <td style="text-align:right;"><?= number_format($ment); ?></td>
                    <td style="text-align:right;"><?= date('d-M-Y',strtotime($r->due_date)); ?></td>
                    <td style="text-align:right;"><?= number_format($paid_amount); ?></td>
                    <td align="right"><?= number_format($mbalance); ?></td>
                </tr>
                <?php  }?>  
                <tr>
                    <td><b>Total</b></td>
                    <td align="right"><b><?= number_format($tments); ?></b></td>                    

                    <td colspan="4" align="right"><b><?//= number_format($tments); ?></b></td>
                </tr>      
            </tbody>
            <?php
            }
            ?>
        </table>

    </div>
     
      <center><div class="mt-4"><i><b>Kindly note, All school Fees are Non-refundable.</i></b></div></center>
    <center><div class="mt-1"><i><b>Powered by Micro Health Initiative</i></b></div></center>
</div>