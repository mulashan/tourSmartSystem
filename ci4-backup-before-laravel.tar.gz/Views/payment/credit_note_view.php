 <?php
$amodel = new App\Models\AdmissionModel();
$bmodel = new App\Models\BillingModel();
$account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));
?>
<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<style type="text/css">
    tr:hover {
cursor: pointer;

}

    .help-icon {
    display: inline-block;
    position: relative;
    font-size: 13px; /* Adjust the size as needed */
    vertical-align: super;
    line-height: 1;
}

.icon1 {
    display: inline-block;
    width: 20px;
    height: 20px;
    background-color: #00BFFF;
    color: white;
    border-radius: 50%;
    text-align: center;
    line-height: 20px;
    font-size: 14px;
    font-weight: bold;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Hover effect */
.icon1:hover {
    background-color: #2980b9;
}
</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Billing</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Credit Note</li>
                     <li class="help-icon">
                    <a href="#" onclick="tg_help()" style="margin-left:8px"><span class="icon1">?</span></a>
                   </li>
                </ol>
            </div>
            
             <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active"
                 data-toggle="tab" href="#inv-all">Credit Note List</a></li>
                 <li class="nav-item"><a class="nav-link" 
                  data-toggle="tab" href="#inv-add">New credit Note</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#inv-all">Credit Note List</a></li>
                <li></li><li></li>
                 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#inv-add">New credit Note</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="inv-all">
                <div class="card">
                    <div class="d-flex justify-content-center mt-3">
                       <form id="cResult" class="form-inline">
                             Credit Note date:
                         <div class="input-group ms-3 me-3">
                            <button type="button" class="btn btn-default pull-right daterange-all" id="daterange-all">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                        <button type="submit" class="btn btn-primary">Create</button>
                     
              <div class="input-group ms-3">
                
                <input type="text" class="form-control" name="payer_name" id="search_name"   placeholder="Search Student Name" aria-label="Student Name" aria-describedby="button-st">
                <button class="btn btn-outline-success" type="button" id="button-y">
                    <span>
                        <i class="fa fa-calendar" aria-hidden="true"></i>
                    </span></button>
                <button class="btn btn-outline-primary" type="button" id="button-st" onclick="searchnamebtn()"><i class="fa fa-search" aria-hidden="true"></i></button>
            </div>
                       </form>
                    </div>

                    <hr>
                &nbsp;
                <center>
                    <div id="cdtResult"></div>
                </center>
                </div>
            </div>
            <!---///////////////////////New invoice------------------>
            <div class="tab-pane" id="inv-add">

                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="card">
                            <div class="card-header"  style="height:5px">
                                <h3 class="card-title">Credit Note Details</h3>
                                <div class="card-options ">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                                <hr>
                            <div class="card-body">
                                <form class="form-horizontal" id="invoicebtn">
                                    <div id="feedback"></div>
                                   <div class="row">
                                    <div class="col-md-6">
                                         <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Note Type</label>
                                            <div class="col-sm-8">
                                              <?php
                                                 $cty= $bmodel->get_table_details('invoice_types_tbl');
                                                  ?>
                                                <select class="form-control" name="admission_type" id="admission_type">
                                                    <option value="3">General</option>
                                                    <?php foreach($cty as $type): ?>
                                                    <option value="<?= $type->id ?>"><?= $type->type_name; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                          </div>
                                        <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Note Date</label>
                                            <div class="col-sm-8">
                                              <input type="date" id="invoice_date" name="invoice_date" value="<?php echo date('Y-m-d');?>" max="<?php echo date('Y-m-d');?>" class="form-control">
                                            </div>
                                          </div>
                                           <input type="hidden" id="payer_id" name="payer_id" value="">
                                          <!-- <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Noted To<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                               <select class="form-control" name="paid_by" id="paid_by">
                                                    <option value="">Select Noted To</option>
                                                    <option value="1">Student</option>
                                                   <option value="5">Parent/Guardian</option>
                                                </select>
                                            </div>
                                          </div> -->
                                         <!--<input type="hidden" name="paid_by" value="1">-->
                                         <!--  <div class="form-group row" id="payer_name_row" style="display: none;">
                                            <label for="payerame" class="col-sm-4 col-form-label">Name<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                                <div class="input-group mb-3">
                                                    <input type="hidden" id="payer_id" name="payer_id" value="">
                                                    <input type="text" class="form-control" name="payer_name" id="payer_name"   placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2">
                                                    <button class="btn btn-outline-primary" type="button" id="button-addon2" onclick="search_payer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                          </div> -->
                                          <div id="payer_details"></div>
                                         <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Customer Type<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                               <?php
                                                    $ctype= $bmodel->get_table_details('name_type_tbl');
                                                  ?>
                                                <select class="form-control" name="customer_type" id="customer_type">
                                                    <option value="">Select Customer Type</option>
                                                    <?php foreach($ctype as $type): ?>
                                                    <option value="<?= $type->id ?>"><?= $type->name_type; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                          </div>
                                          <div class="form-group row" id="select_invoice" style="display:none;">
                                            <label for="payerame" class="col-sm-4 col-form-label">Select Customer<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" name="customer_name or Id"  id="customer_name" placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2">
                                                    <button class="btn btn-outline-primary" type="button" id="button-addon2" onclick="search_customer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                          </div>
                                        <div id="customer_details"></div>
                                    </div>   
                                    <div class="col-md-6">
                                       <div id="customer_loaded"></div> 
                                       <div id="Name_loaded"></div>
                                       <div id="Invoice_loaded"></div>
                                    </div>
                                </div>
                                 <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Charged Items<span class="text-danger">*</span></label>
                            <div class="col-sm-6">
                            <select class="form-select form-control" id="js-example-data-ajax" style="width:100%;height: 15px;"></select>
                        </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"></div>
                            <div class="col-md-9">
                                <div class="card">
                                    <p Class=" d-flex justify-content-center mt-3">CHARGED ITEMS</p>
                                    <table class="table table-hover table-vcenter mb-0 text-nowrap" id="table">
                                    <thead>
                                            <tr>
                                                <th>No#</th>
                                                <th>Item Name</th>
                                                <th>Attribute</th>
                                                 <th>Size</th>
                                                <th>UOM</th>
                                                 <th>Qty</th>
                                                <th>Price
                                                  <div  class="cust_popup" id="cashInv" style="display: none">
                                                    <h6>Change price</h6>
                                                <div id="prcresInv"></div>
                                             </div>
                                                </th>
                                                 
                                                <th>Total</th>
                                                <th>Action</th>
                                            </tr>
                                    </thead>
                                    <tbody id="show_item">

                                    </tbody>
                                    </table>
                                    <table>
                                        <tr>
                                        <th class="col-sm-8"></th>
                                        <th colspan=4 id="totalp">
                                        <!-- <span id="totalp" style="margin-left:400px;"></span> -->
                                        </th>
                                        </tr>
                                        </table>
                                </div>
                            </div>
                        </div><br>
                              <div class="form-group row">
                                <label class="col-md-2 col-form-label">Account Receivable<span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <select name="account" id="account" class="form-control" required="required">
                                        <option value="">--Select Account Receivable--</option>
                                        <?php foreach ($account as $ac): ?>
                                            <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                            </div>
                        
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-8">
                               
                                <button type="submit" id="admit_student" class="btn btn-primary float-right">Create</button>
                            </div>
                        </div>
                        </form>
                            </div>
                        </div>
                        
                    </div>
                </div>
            
            </div>
        </div>
    </div>
</div>
<!-- ------View invoice modal------- -->
<div class="modal fade" id="invoiceview" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5>View Credit Note Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="view_details">
      </div>
    </div>
  </div>
</div>

<!-- ------manage invoice modal------- -->
<div class="modal fade" id="viewinvoice" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"  style="z-index: 1400;">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5>Credit Note Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewinvoice_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printJS('invoicePrint_content', 'html')"><i class="fa fa-print"></i> Print</button> -->
        <!-- <button type="button" class="btn btn-primary"  data-toggle="modal" data-target="#invoiceprint" onclick="invoice_print()"><i class="fa fa-print"></i> Print</button> -->
        <button type="button" class="btn btn-primary"  data-toggle="modal" onclick="invoice_print()"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>

<!-- ------invoice print modal------ -->
<div class="modal fade" id="invoiceprint" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="z-index: 1600;">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-body" id="invoicePrint_content">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('invoicePrint_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
<!--------------help model---------------------------------->
<div class="modal fade" id="view_help" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
     <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div id="loading_spinner">
            <center><b><span class="fa fa-spin fa-spinner"></span> Loading...</b></center>
        </div>
        <iframe id="help_frame" src="" style="height: 750px;"></iframe>
    </div>
  </div>
</div>
<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
   
    var hold_selected_items = []; // hold all selected items
function tg_help() {
    $('#help_frame').attr('src', '');
    $('#loading_spinner').show(); // Show the loading spinner
    $('#view_help').modal('show');
    $('#help_frame').on('load', function() {
        $('#loading_spinner').hide(); // Hide the loading spinner once the content is loaded
    });
    $('#help_frame').attr('src', 'https://support.advaensure.co.tz/article/2-How-To-Setup-NHIF-Signatures');
}
    $(document).ready(function(){
        
         $('#js-example-data-ajax').select2({
            ajax: {
                url: "<?= base_url('load_accomodation'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            },
             escapeMarkup: function (markup) {
                        return markup; // Don't escape HTML
                        },
                        templateResult: function (data) {
                        return data.text; // Render the full HTML in 'text'
                        },
        });

        $('#js-example-data-ajax').on('select2:select', function (e) {
            selectedItems();
        });
        //var prc; 


        function selectedItems(){  
            var rows = '';
           var itemData = 'item_selected='+$('#js-example-data-ajax').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Accomodationdata1')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }else{
                        var len  = data.length;
                        
                        for (var i = 0; i <len; i++ ){
                            hold_selected_items.push(data[i]['id']);// push all selected items
                            var prc = data[i]['iprice'];
                            price= prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
                            var name = data[i]['iname'];
                            var size = data[i]['isize'];
                            var attribute = data[i]['iattribute'];
                            var iid = data[i]['id'];
                            //var qty = window.prompt("Enter quantity");
                            //var tprice = qty*prc;
                           
                            
                            rows += '<tr id="table_row'+ iid +'">';

                           rows+='<td><input type="hidden" name="iid[]" value="'+iid+'">'+ iid +'</td>';
                             rows+='<td>'+ name +'</td>';
                            //rows += '<td>'+ name +'</td>';
                            rows += '<td>'+ attribute +'</td>';
                            rows += '<td>'+ size +'</td>';
                            rows += '<td>'+ 1 +'</td>';
                            rows += '<td><input type="text" value="'+1+'" style="border:none;cursor:pointer;width:20px;text-align:right;" id="quantity'+iid+'" name="quantity'+iid+'" readonly></td>';
                            // rows += '<td><input type="hidden"  name="price'+iid+'" value="'+prc+'">'+ prc +'</td>';
                            rows += '<td><a class="cost" id="costInv' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getidInv(' +iid+ ','+prc+')"><input type="text" value="'+prc+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" name="price'+iid+'" id="pric'+iid+'" readonly></a></td>';
                            rows += '<td id="ttl'+iid+'">'+price+'</td>';
                            //rows += '<td><input type="text" name="tprice" id="tprice'+iid+'" style="width:85px; border:none; background-color:rgb(240,240,240)" readonly></td>';
                            rows += '<td><a href="javascript:RemoveSelectItemRow('+iid+','+i+');" class="btn btn-danger btn">X</a></td>';
                            
                            rows += '</tr>';
                            $('#show_item').append(rows);
                            var table = document.getElementById("table"), totalsum=0;
            
                                for(var i = 1; i < table.rows.length; i++)
                                {
                                   
                                    totalsum = totalsum + parseInt(table.rows[i].cells[7].innerHTML.replace(/,/gi, ""));
                                } 
                               
                     document.getElementById("totalp").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
                        }
                      
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }
                
           });  
        }

    });
    var sumVal=0;   
   
    function manage_invoice(inv){
        // alert(inv)
       $('#viewinvoice').modal('show'); 
       $('#viewinvoice_content').load('view_note/'+inv);
    }

    function edit_invoice(invID){
        $('#view_details').load('credit_note_details/'+invID);
    }

    function invoice_print(){
        $('#invoiceprint').modal('show');
    }
    // $('#invoicePrint_content').load('print_invoice/'+inv);

    function printable_rept(area) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=700, height=600, left=100, top=25";
        var content_vlue = document.getElementById(area).innerHTML;

        var docprint = window.open("", "", disp_setting);
        docprint.document.open();
        docprint.document.write('<html><head><title>MHI</title><link rel="stylesheet" href="<?php echo base_url() . 'syst_assets/'; ?>bootstrap/css/bootstrap.css">');
        $('#ReptHeader').load('<?php echo base_url() . 'index.php/Gp_ctrl/load_printable_header'; ?>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }

    function invoice_receipt(student_id,trans_no){

        // window.location.href = `http://localhost/econnect/receipt`
        
        // window.location.href= "<?php echo base_url() . '/receipt'; ?>" + "?id="+student_id;
        window.location.href= "<?php echo base_url() . '/index.php/BillingController/invoice_receipt'; ?>/"+student_id+"/"+trans_no;

        // prepare_invoice_student(student_id);

    }
 $("#paid_by").change(function(){
        $('#payer_name_row').show();
        $('#payer_details').html('');
    });
    $("#customer_type").change(function(){
        $('#select_invoice').show();
        if($(this).val() == 4){
            $('#applicationlist').show();
            $('#invoicelist').hide();
        }else{
           $('#invoicelist').show(); 
           $('#applicationlist').hide();
        }
    });
    function search_payer(){
       if($('#paid_by').val() == "") {
           swal("warning","Please Select Paid By","warning");
       }else if($('#payer_name').val() == ""){
          swal("warning","Please Enter Payer Name","warning"); 
       }else{
            var paydata = 'paid_by=' + $('#paid_by').val() + "&payer_name=" + $('#payer_name').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/search_payer'; ?>',
                beforeSend: function () {
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#customer_loaded').html(result); 
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
       
    }
    var ids;
    function select_payer(id,nametype,payer_name){
      // alert(id+'/'+nametype+'/'+payer_name) 
       var payer = nametype +'_' +id;
      // alert(payer);
        $('#payer_id').val(payer);
        var payerdata = "payer=" + payer;
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillingController/get_payer_details'; ?>',
            data: payerdata,
            success: function (res) {
               
                $('#payer_details').html(res);
                $('#payer_name_row').hide();
                $('#customer_loaded').html('');

            },
            error: function (){
                alert('error encounted');
            }
        });
    }

     function RemoveSelectItemRow(item_id,v){
        alert('two');
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }
       
        //alert(sumVal);
        var k=v+1;
        var table = document.getElementById("table");
        var data=parseInt(table.rows[k].cells[7].innerHTML);
        
         
         //var col1=currentRow.find("td:eq(7)").text();
        
        $('#table_row'+item_id).remove();
    }
// $("#account").change(function(){
//     var items="";
//     var accounts=$('#account').val();
//     var amount_ttl=sumVal;
//     //alert("acc= "+accounts+"ttl="+amount_ttl);
//     items = {account_receivable: accounts, amount: amount_ttl};
//     receivable_total_balance.push(items);
//     alert(items);
//     });

   $('#invoicebtn').submit(function(e){
    //alert($(this).serialize()+"&sid="+ids+"&amount="+sumVal+'&'+$("#header_form").serialize());
        // alert($(this).serialize()+'&receivable_total_balance=' + JSON.stringify(receivable_total_balance));
        // return;
        $.ajax({
            beforeSend: function () {
                  $('#admit_student').prop("disabled", true);
                  $('#feedback').append('<div class="alert alert-primary alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button><i class="fa fa-spinner fa-spin"></i>Preparing Control Number Please wait..</div>');
            },
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/save_note_transaction'; ?>/'+ids,
            data: $(this).serialize()+"&sid="+ids+"&amount="+sumVal+'&'+$("#header_form").serialize(),
            success:function(res){
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                    Swal.fire({
                    title: "successful", 
                    html: data['statusDesc'], 
                    icon: "success"
                  }).then((result) => {
                  if (result.isConfirmed) {
                    location.reload();
                  }
                });
                }else{
                    $('#admit_student').prop("disabled", false);
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button> New Credit note, not created successfully</div>');
                }
            },
            error:function(res){
                $('#admit_student').prop("disabled", false);
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt create New Credit Note.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
            }
        });

        e.preventDefault();
    });
   // function clicked(id){
   //  alert("yes welcome");
   //   alert($(this).serialize());

   // }

   function search_customer(){
       if($('#customer_type').val() == "") {
           swal("warning","Please Select Customer Type","warning");
       }else if($('#customer_name').val() == ""){
          swal("warning","Please Enter Customer Name","warning"); 
       }else{
            var paydata = 'type=' + $('#customer_type').val() + "&cust_name=" + $('#customer_name').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/search_customer_invoice'; ?>',
                beforeSend: function () {
                    $('#Name_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#Name_loaded').html(result); 
                },
                error: function () {
                    $('#Name_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
          }
     function prepare_invoice_student(id){
         ids=id;
        // alert(ids);
        var paydata = 'type=' + $('#customer_type').val()+'&id=' + id;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/loadCustomer'; ?>',
                beforeSend: function () {
                    $('#Invoice_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (res) {
                     var data = JSON.parse(res);

               select_payer(data['parent'],5,data['fullname']);
                // $('#customer_details').html(res);
                $('#select_invoice').hide();
                $('#Name_loaded').html('');
                $('#Invoice_loaded').html('');
            },
            error: function (){
                alert('error encounted');
            }
      });
    }
     function RemoveSelectItemRow(item_id){
     
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }
        var cashAmt1 =$('#pric'+item_id+'').val();
        // let cashAmt = cashAmt1.replace(/,/gi, "");
        //    alert(cashAmt);
        // totalsum=totalsum-parseInt(cashAmt);
        $('#table_row'+item_id).remove();
        var table = document.getElementById("table"), totalsum=0;
            
            for(var i = 1; i < table.rows.length; i++)
            {
               
                totalsum = totalsum + parseInt(table.rows[i].cells[7].innerHTML.replace(/,/gi, ""));
            } 
        document.getElementById("totalp").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
          // return totalsum;
        
    }
     

     var total=0;
    
   
    resetReceiptData();
   function resetReceiptData(){
        $('#payer_details').empty();
        $('#payer_name').val('');
        $('#account').val('');
        $('#paid_by').val('');
        $('#customer_type').val('');
         $('#customer_name').val('');
        $('#select_invoice').hide();
        $('#customer_loaded').empty();
        $('#Name_loaded').empty();
        $('#Invoice_loaded').empty();
        $('#itm_invoice1').empty();
        $('#itm_invoice').empty();
        $('#amount_due').val(0);
   }

    function manage_receipt(inv){
        //alert(inv);
      $('#invoiceprint').modal('show'); 
      $('#invoicePrint_content').load('view_receipt/'+inv);
    }

    function getidInv(id,prc) {
    
     $('#cashInv').toggle(100);
     
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/priceview'; ?>",
            beforeSend: function () {
                $('#prcresInv').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#prcresInv').html(result);
                console.log(prc);
             document.querySelector('[id="cash_amt"]').value = prc;
             document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }
    totalsum=0;
       function savebtn(){
      //alert(sum);
     
      var cash=$('#cash_amt').val();
      var item_id=$('#item_id').val();
      //alert(item_id); 
      for( var i = 0; i < hold_selected_items.length; i++){ 
           id1=hold_selected_items[i];
           if(id1==item_id){
            var cashAmt =parseInt(cash);
            document.querySelector('[id="pric'+id1+'"]').value = cashAmt;
            // document.querySelector('[id="pric'+id1+'"]').value = cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            document.getElementById("ttl"+id1).innerHTML = cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

           // $('#cost'+id1+'').append(cashAmt);
           }else{
            var cashAmt1 =$('#pric'+id1+'').val();
            let result = cashAmt1.replace(/,/gi, "");
        
            var cashAmt =parseInt(result);
           // alert(cashAmt);
           }
       
       // totalsum=totalsum+cashAmt;
        }
         var table = document.getElementById("table"), totalsum=0;
            
            for(var i = 1; i < table.rows.length; i++)
            {
               
                totalsum = totalsum + parseInt(table.rows[i].cells[7].innerHTML.replace(/,/gi, ""));
            }  
          //  alert(sumVal);     
          $('#cashInv').hide(); 
              document.getElementById("totalp").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
           return totalsum;       
         e.preventDefault(); 
    }
     $('#cResult').submit(function (e) {
             if (!$('#daterange-all span').html()) {
            $('#cdtResult').html('Please specify valid date.');
        } else {
            $('#cdtResult').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-all span').html();
          
            $.ajax({
                type: "POST",
                url: "<?php echo base_url() . '/index.php/BillingController/fetch_creditNote'; ?>",
                data: dta,
                success: function (res) {
                    $('#cdtResult').html(res);
                },
                error: function () {
                    $('#cdtResult').html('<div class="alert alert-warning">Fail to retreive credit note.!!</div>');
                }
            });

}
        e.preventDefault();
    });

     function searchnamebtn(){
            var name=$('#search_name').val();
            var  year=$('#button-y').html();
            // alert(year);
            if(name.length >=3){
                $('#cdtResult').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
                var dta="name="+name+"&year="+year;
           // toastr.success(name.length);
             $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/index.php/AdmissionController/fetch_invoice_byname'; ?>/6",
                data: dta,
                success: function (res) {
                    $('#cdtResult').html(res);
                },
                error: function () {
                    $('#cdtResult').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
        }else{
            if(name.length==0){
               $('#cdtResult').html(''); 
            }else{
               $('#cdtResult').html('<div class="alert alert-info">Search atleat 3 characters</div>'); 
            }
        
        }
        }

</script>    
