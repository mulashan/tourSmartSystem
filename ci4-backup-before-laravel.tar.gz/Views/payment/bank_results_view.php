
<?php
   $bmodel = new App\Models\BillingModel();
   $ctype= $bmodel->get_table_details('name_type_tbl');
?>

<div class="section-body mt-4">
    <div class="container-fluid">
             
                <div class="card">
               <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>Ledger</th>
                                    <th>Control No</th>
                                    <th>Ctr type</th>
                                    <th>Trans Date</th>
                                    <th>Trans type</th>
                                    <th>Trans No</th>
                                    <th>Invoice Type</th>
                                    <th>Student Name</th>
                                    <th>Amount</th>
                                    <th>Paid</th>
                                     <th>sms Status</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                 if(count($trans)>0){
                            foreach($trans as $s){

                                 if($s->payment_channel==2){
                                  $channel="NMB";
                                 }if($s->payment_channel==3){
                                    $channel="CRDB";
                                 }
                                 //student name below
                                if($s->inv_type==1){
                                 $name=$bmodel->get_item_name('students_application_tbl',$where = array('id' => $s->student_id));
                                 $inv_name="Application";
                                 $app=6;
                                }else{
                                    $app=0;
                                   $name_type_id=$bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $s->trans_no,'trans_type'=>$s->trans_type));
                                   if(count($name_type_id)==0){
                                       continue;
                                   }
                                   if($name_type_id[0]->name_type_id==6){
                                $name=$bmodel->get_item_name('other_students_tbl',$where = array('id' => $s->student_id));
                                   }else{
                                  $name=$bmodel->get_item_name('students',$where = array('id' => $s->student_id));
                                     }
                                  $inv_name=$s->type_name;
                                }

                                //payment status below
                                 if($s->payment_status==0){
                                    $status="<span style='color:red'>Unpaid</span>";
                                 }elseif($s->payment_status==1){
                                     $status="<span style='color:green'>Paid</span>";
                                 }elseif($s->payment_status==3){
                                     $status="<span style='color:red'>Cancelled</span>";
                                 }elseif($s->payment_status==2){
                                     $status="<span style='color:Indigo'><b>Partial</b></span>";
                                 }
                                   
                                   //invoice type below
                                 $type=$bmodel->get_item_name('transaction_types_tbl',$where = array('type_id' => $s->transaction_type_id));
                                 
                                  //partial/fixed type below
                                 if($s->allow_partial==1){
                                  $allow="FLEXIBLE";
                                 }else{
                                    $allow="FIXED";
                                 }
                              //check amount payed below
                 ///*************sum rcpt*******************************
         $inv_no = $bmodel->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $s->trans_no));
            $amount_paid=0;
            foreach($inv_no as $no){
                $charges=0;
                $rcpt_am = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2));
            
                if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                    // echo 'rct='.$am->amount;
                    // echo '</br>'; 
                  $amount_paid=$amount_paid+$am->amount;
              }
                }
            }
            
            $reltn = $bmodel->get_item_name('transactions_relation',$where = array('invoice_trans_no' =>$s->trans_no));
           $amount_transfered=0;
           foreach($reltn as $r){
              $transfer = $bmodel->get_item_name('receipt_transfer_tbl',$where = array('old_receipt_number' =>$r->receipt_trans_no));  
              if(count($transfer)>0){
               $amount_transfered=$amount_transfered+$transfer[0]->amount_transfered;
               
              }
              $amount_paid=$amount_paid-$amount_transfered;
           }
           
       ///*********************************************
            $paid=$bmodel->get_item_name('payment_response',$where = array('reference_no' => $s->reference_no));

                                 if(count($paid)>0){
                                    $a_paid=0;
                                    foreach($paid as $p){
                                $a_paid= $a_paid+ $p->amount_payed;
                                    }
                                   
                                 }else{
                                    $a_paid=0;
                                 }
                            // $a_paid=$a_paid-$amount_transfered;    
             $inv_amount = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $s->trans_no,'ledger_type'=>7,'transation_nature'=>2,'trans_type'=>1));
             if(count($inv_amount)>0){
            if(($inv_amount[0]->amount + $s->charges) <=$amount_paid){
             $status="<span style='color:green'>Paid</span>";
            }elseif(($inv_amount[0]->amount +$s->charges) >$amount_paid && $a_paid >0){
           $status="<span style='color:Indigo'><b>Partial</b></span>";
            }
        }else{
          $status="<span style='color:Indigo'><b>No Invoice</b></span>";  
        }
                          

                                 //checking sms status
                                 if($s->transaction_type_id==3){
                                  $inv_type=5;
                                 }else{
                                 $inv_type=$s->transaction_type_id;
                                     }

                                     if($app==6){
                                        $msg_status = $bmodel->get_item_name('message_groups_tbl', $where = array('trans_number' => $s->student_id,'message_type'=>$app));
                                    }else{
                        $msg_status = $bmodel->get_item_name('message_groups_tbl', $where = array('trans_number' => $s->trans_no,'message_type'=>$inv_type));
                              }
                                     if(count($msg_status)>0){
                                         $msg_st = $bmodel->get_item_name('messages', $where = array('send_no' => $msg_status[0]->send_number));
                                         if(count($msg_st)>0){
                                            ?>
                                         <script type="text/javascript">
                                        
                                         //     $(function() {
                                         // check_sms('<?php echo $msg_st[0]->message_id;?>');
                                         //      });
                                         // </script>
                                         <?php
                                         $msg_s = $bmodel->get_item_name('messages', $where = array('message_id' => $msg_st[0]->message_id));

                                         $del=$msg_s[0]->status_description;
                                         $time=$msg_s[0]->time_delivered;
                                         $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                                     }else{
                                         $stata='<span style="color:red">Not Sent'; 
                                     }
                                     }else{
                                       $stata='<span style="color:red">Not Sent';  
                                     }
                                ?>
                                <tr>
                                    <td><?php echo $channel;?></td>
                                    <td><?php echo $s->reference_no;?></td>
                                    <td><?php echo $allow;?></td>
                                    <td><?php echo date('Y-m-d H:i',strtotime($s->date_created));?></td>
                                     <td><?php echo $type[0]->type_name;?></td>
                                     <td><?php echo $s->trans_no;?></td>
                                      <td><?php echo $inv_name;?></td>
                                     <td><?php echo $name[0]->full_name??"";?></td>
                                   <td><?= number_format($s->amount+$s->charges); ?></td>
                                   <td><b><?= number_format($a_paid); ?></b></td>
                                   <td><?php echo $stata;?></td>
                                     <td><?php echo $status;?></td>
                                     
                                    <td>
                                         <a href="javascript:void(0)" onclick="manage_payments('<?php echo $s->reference_no;?>')"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a>
                                         <a href="javascript:void(0)" onclick="check_payment('<?php echo $s->reference_no;?>')"  class="btn btn-primary btn-sm"><i class="fa fa-check"></i> Check payment</a>
                                    </td>
                                    
                                </tr>
                            <?php }}else{
                                echo "<tr><td>Currently there is no record</td></tr>";
                            } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
          
        </div>
   
<div class="modal fade" id="pay_details" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="payments_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('payments_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="editreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="editreceipt_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="edit_rept()"><i class="fa fa-print"></i> Edit</button> -->
      </div>
    </div>
  </div>
</div>
<script>

    $(document).ready(function () {
      $('#myTable').DataTable();
    });
    
    function printable_rept(area) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=700, height=600, left=100, top=25";
        var content_vlue = document.getElementById(area).innerHTML;

        var docprint = window.open("", "", disp_setting);
        docprint.document.open();
        docprint.document.write('<html><head><title>MHI</title><link rel="stylesheet" href="<?php echo base_url() . 'syst_assets/'; ?>bootstrap/css/bootstrap.css">');
        $('#ReptHeader').load('<?php echo base_url() . 'index.php/Gp_ctrl/load_printable_header'; ?>');
        docprint.document.write('</head><body onLoad="self.print()" style="width:100%; font-size:10px;text-shadow:0 1px 1px rgba(0,0,0,.1);">');
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();

        // var ns = $('noscript').clone();
        // nw.document.write(ns.html())
    }

    function manage_payments(inv){
        //alert(inv);
      $('#pay_details').modal('show'); 
      $('#payments_content').load('<?php echo base_url() . '/index.php/BillingController/view_pyment_details'; ?>/'+inv);
    }
    function check_sms(msgid){
               // alert(msgid);
              $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/SystemController/check_sms/'; ?>'+msgid,
           
            success: function (res) {
            
             },
            error: function (){
                alert('error encounted');
            }
        });
            }

    function check_payment(ref){
   //  toastr.success('show '+ref);
        $('#editreceipt').modal('show'); 
       $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/check_reconciliation/'; ?>'+ref,
             beforeSend: function () {
                    $('#editreceipt_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> Please wait...</b></center>');
                },
           
            success: function (res) {
            
            $('#editreceipt_content').html(res);
             },
            error: function (){
                toastr.error('error encounted');
            }
        });
    }
  </script>