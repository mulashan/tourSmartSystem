        <?php
                               
        $amodel = new App\Models\AdmissionModel();
        $bmodel = new App\Models\BillingModel();
        $smodel = new App\Models\StudentModel();
      
    //  print_r($trans);
         ?>
           
           <button type="button" class="btn btn-primary mb-3 btnp" style="float:right;" onclick="createControl()" id="message_sent"><i class=""></i>Create control Number</button> 
            <!--<button type="button" class="btn btn-primary mb-3 btnp" style="float:right;" onclick="createReceipt()" id="message_sent"><i class=""></i>Create Receipt</button>-->

          <label>
              Receipt date <input type="date" name="admission_date" value="<?php echo date('Y-m-d')?>" id="admission_date" class='form-control'>
          </label> 
          <form id="control_form" class="">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTableb">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <td> <input type="checkbox" name="" value="" onclick="Allcheckbox()" id="Allselected"> All</td>
                                     <th>Student Name</th>
                                     <th>Level</th>
                                     <th>Class</th>
                                    <th>Invoice No.</th>
                                    <th>Invoice Type</th>
                                    <th>Invoice Date</th>
                                    <th>Inv Amount</th>
                                    <th>Balance</th>
                                     <th>Phone</th>
                                        <th>Payed</th><th></th> <th></th><th></th>
                                     <th>Account</th><th></th><th></th>
                                   
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $j=0;
                                  $holid_student=array();
                                $account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 9));

                               foreach ($trans as $k) {
                                 $pay = $bmodel->get_item_name('payment_request',$where = array('student_id' => $k->student_id,'trans_no'=>$k->trans_no,'trans_type'=>1));
                                 if(count($pay)>0){
                                    continue;
                                 }

                                $j++;
                               
                               $level = $amodel->get_student_details('class_level_tbl', $where = array('id' => $k->level_id));
                               $class = $amodel->get_student_details('classes_tbl', $where = array('id' => $k->class_id)); 
                               $inv_trans = $amodel->get_student_details('invoice_type_transaction', $where = array('trans_no' => $k->trans_no,'transaction_type_id'=>1)); 
                                $inv_type = $amodel->get_student_details('invoice_types_tbl', $where = array('id' => $inv_trans[0]->invoice_type_id)); 
                                $transac = $amodel->get_student_details('transaction_numbers_tbl', $where = array('trans_type_id' => 1,'trans_number'=>$k->trans_no));

                                $get_rct = $bmodel->get_item_name('transactions_relation',$where = array('invoice_trans_no' =>$k->trans_no));
                                $paid_amount=0;
                                $due=0;
                                foreach($get_rct as $gt){
                                $leger = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$gt->receipt_trans_no,'ledger_type'=> 7,'trans_type' =>2,'transation_nature' =>1));
                                  $paid_amount=$paid_amount+$leger[0]->amount;
                                }
                                $due=$k->amount - $paid_amount;
                                $row="black";
                                if($due <=0){
                                    continue;
                                }
                                 $holid_student[]=array($k->trans_no);

                                  $get_student_parent = $bmodel->get_item_name('parents_students_tbl',$where = array('student_id' =>$k->student_id));
                                  $pinfo=0;
                                  $phone="";
                                  if(count($get_student_parent)>0){
                                    foreach($get_student_parent as $ps){
                                $get_parent = $bmodel->get_item_name('parents_tbl',$where = array('id' =>$ps->parent_id, 'bill_account'=>1)); 
                            if(count($get_parent)>0){
                              $pinfo=$get_parent[0]->id;
                              $phone=$get_parent[0]->phone1;
                                }
                             }
                                 
                                 }
                                   ?>
                                   <input type="hidden" name="balance<?php echo $k->trans_no; ?>" value="<?php echo $due; ?>">
                                   <input type="hidden" name="student_id<?php echo $k->trans_no; ?>" value="<?php echo $k->student_id; ?>">
                                  <tr style="color: <?php echo $row;?>;" onclick="selectRow('<?php   echo $k->trans_no; ?>')" id="<?php echo $k->trans_no; ?>">
                                      <td><?= $j;?>.</td>
                                      <td>  <input type="checkbox" name="selected[]" value="<?php echo $k->trans_no; ?>" onclick="checkbox('<?php echo $k->trans_no; ?>')" id="selected<?php echo $k->trans_no; ?>"></td>
                                      <td><?= $k->full_name;?></td>
                                      <td><?= $level[0]->level_name;?></td>
                                      <td><?= $class[0]->class_name;?></td>
                                      <td><?= $k->trans_no;?></td>
                                    <td><?= $inv_type[0]->type_name;?></td>
                                    <td><?= $transac[0]->trans_date;?></td>
                                    <td><?= number_format($k->amount);?></td>
                                    <td><?= number_format($due);?></td>
                                    <td>
                                     <?php if($phone==""){
                                        echo "<span class='text-red'>No parents billings informations</span>";
                                     }else{
                                         echo $phone;
                                    ?>
                                      <input type="hidden" name="phone" value="<?=$phone;?>">
                                      <input type="hidden" name="pid" value="<?=$pinfo;?>">
                                       
                                    <?php }?>
                                    <td  colspan="4">
                                         <input type="text" name="payed<?=$k->trans_no;?>" id="payed<?=$k->trans_no;?>" class="form-control" value="0" onkeyup="AmtCalc('<?=$k->trans_no;?>','<?=$due;?>')">
                                    </td>
                                    </td>
                                     <td colspan="3"><select class="form-control form-select" name="account<?=$k->trans_no;?>">
                                         <option value="0">-choose-</option>
                                       <?php
                                       foreach($account as $ac){
                                       ?>
                                        <option value="<?=$ac->id;?>"><?=$ac->account_name;?></option>
                                     <?php
                                       }
                                         ?>
                                    
                                     </select></td>
                                  </tr> 
                                   <?php
                               }
                               ?>
                             
                            </tbody>
                        </table>

                    </div>
               </form>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
                <script type="text/javascript">
        $(document).ready(function() {
        checkSelected();
        });
               function selectRow(id){
         var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {
    row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {

    row.style.backgroundColor = 'black';
      row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        }
       checkSelected();
      }
      function checkbox(id){
        var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {

    row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {
    row.style.backgroundColor = 'black';
      row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        } 
         checkSelected();
      }
function Allcheckbox(){
        var values=<?php echo json_encode($holid_student);?>;
        //alert(values.length);
        var rememberAll = document.getElementById("Allselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
            if(rememberAll.checked){
     remember.checked=true;  
      if (row) {
    
    row.style.backgroundColor = 'black';
    row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=false; 
      
       if (row) {
      row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }  
        }
        }
         checkSelected();
      }
function checkSelected(){
        var j=0;
        var values=<?php echo json_encode($holid_student);?>;
        //alert(values.length);
        var rememberAll = document.getElementById("Allselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
            if(remember.checked){
           j++;
       }else{
     
        }
        }
       // alert(j);
        if(j>0){
            $('#message_sent').prop("disabled", false);
        }else{
            $('#message_sent').prop("disabled", true);
        }
      }

     function createControl() {
        $('#message_sent').prop("disabled", true);
          var data= $('#control_form').serialize()+'&'+$('#header_form').serialize();
              // alert(data);
              // return;
            $.ajax({
                 beforeSend: function () {
                   Swal.fire({
              title: 'Please wait...',
              html: '<span class="text-danger">Generating Control Number...</span>',
              icon: 'info',
              allowOutsideClick: false,
              showConfirmButton: false,
              timerProgressBar: true,
              onBeforeOpen: () => {
                Swal.showLoading();
              }
            });
                  
            },
                type: "POST",
              url: '<?php echo base_url() . '/index.php/AdmissionController/create_controlno_group'; ?>',
                data: data,
                success: function (res) {
                    refreshPage();
                    if(res){
                      
                         swal('success','Created successfuly','success');
                         
                    }else{
                        swal('error','something went wrong','error'); 
                    }
                
                },
                error: function () {
                    alert('something went wrong');
                    refreshPage();
                }
            });
        };
       
       function refreshPage(){
            Swal.close();
            
         $('#invoice_balances').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "class=" + $('#class option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&status="+$('#status option:selected').val() +"&yearb="+$('#yearb option:selected').val();
           // alert(dta);
         $.ajax({
                type: "POST",
              url: "<?php echo base_url() . '/index.php/AdmissionController/fetch_invoice_balances'; ?>",
                data: dta,
                success: function (res) {
                    $('#invoice_balances').html(res);
                },
                error: function () {
                    $('#invoice_balances').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
      }

function AmtCalc(trn,due){
    var input=$("#payed"+trn).val().replace(/,/gi, "");
   
    if(due < parseInt(input)){
 
   input = Number(String(input).slice(0, -1));
   $("#payed"+trn).val(parseInt(input).toLocaleString());
    toastr.warning('Please do not exceed the amount due!','Warning');
//   alert('Please do not exceed the amount due');
    }else{
    if(input !=""){
     $("#payed"+trn).val(parseInt(input).toLocaleString());
    }else{
       $("#payed"+trn).val(0);  
    }
}
}

    function createReceipt() {
        $('#message_sent').prop("disabled", true);
          var data= $('#control_form').serialize()+'&'+$('#header_form').serialize()+'&admission_date='+$('#admission_date').val();
               //alert(data);
              // return;
            $.ajax({
                 beforeSend: function () {
                   Swal.fire({
              title: 'Please wait...',
              html: '<span class="text-danger">Generating Receipts...</span>',
              icon: 'info',
              allowOutsideClick: false,
              showConfirmButton: false,
              timerProgressBar: true,
              onBeforeOpen: () => {
                Swal.showLoading();
              }
            });
                  
            },
                type: "POST",
              url: '<?php echo base_url() . '/index.php/BillingController/create_receipts_group'; ?>',
                data: data,
                success: function (res) {
                    refreshPage();
                    if(res){
                      
                         swal('success','Created successfuly','success');
                         
                    }else{
                        swal('error','something went wrong','error'); 
                    }
                
                },
                error: function () {
                    alert('something went wrong');
                    refreshPage();
                }
            });
        };
         
                </script>