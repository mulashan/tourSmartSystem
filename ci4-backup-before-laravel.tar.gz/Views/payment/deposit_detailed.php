 <?php
  $bmodel = new App\Models\BillingModel();
  $cmodel = new App\Models\ClassesModel();
  $appItems = $cmodel->get_applications_items();
  $dbname=session()->get('db_name');
  $db = \Config\Database::connect($dbname);
   
  $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'trans_type' =>3));

  $invoice_type = $bmodel->get_item_join_table($recpt[0]->trans_number);
  $student_name = "";
  $name_type = "";
if(count($leger_transaction) > 0){
    $amount = $leger_transaction[0]->amount;
  if($leger_transaction[0]->name_type_id == 3){
        $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 9,'trans_type' =>3));
   }else if($leger_transaction[0]->name_type_id == 1){
        $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        
        $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 9,'trans_type' =>3));
   }
    $control_no = $bmodel->get_item_name('payment_request',$where = array('student_id' =>$app[0]->id,'trans_type'=>3,'trans_no'=>$recpt[0]->trans_number));
    // print_r($recpt[0]->trans_number);
    // print_r($control_no);
    //      return;
    $adreq = $bmodel->get_item_name('deposit_receipt_tbl', $where = array('deposit_number' => $recpt[0]->trans_number,));
    if(count($control_no)==0 && count($adreq)>0){
      $control_no = $bmodel->get_item_name('payment_request', $where = array('trans_no' => $adreq[0]->invoice_number,'trans_type'=>1)); 
  
         }
         $control_number='';
         
    if(count($control_no) > 0){
    $control_number = $control_no[0]->reference_no;

    $channel = $bmodel->get_item_name('payment_response',$where = array('reference_no' => $control_number,'transaction_date'=>$recpt[0]->trans_date));
    if(count($channel)>0){
   $chann=$control_no[0]->payment_channel;
   $channel_name=$channel[0]->transaction_channel;
     $cus_name=$channel[0]->customer_name;
     if($chann==2){
        $ch="NMB-".$channel_name;
     }else{
        $ch="CRDB-".$channel_name;
     }
    }
  
     
    }
    $company_reg = $bmodel->get_table_details('company_tbl');
 //   $pay_dtls = $bmodel->get_item_name('payment_response',$where = array('reference_no' =>$control_number));
   
   
}

 ?>
 <div id="att-list">
<div class="row">
<div class="col-md-12">
    <!-- <center><b style="font-size:14px"><u>RECEIPT</u></b></center> -->
    <center>
      <div> <img src="<?php  echo base_url('public/company_photos/'.$company_reg[0]->logo_name) ?>" style="width: 50%;height: 120px; background: white;" ></div>
 <span class="mt-4"><b><?= $company_reg[0]->company_name; ?></b></span><br>
            <span class="modify" style="font-size:15px"><?= $company_reg[0]->address; ?></span>
            <div class="mb-3">
                <div><span class="modify" style="font-size:15px">Phone: +<?= $company_reg[0]->phone1; ?></span></div>
                <div><span class="modify" style="font-size:15px">Email: <?= $company_reg[0]->email; ?></span></div>
                <div><span class="modify" style="font-size:15px"> <?= $company_reg[0]->website; ?></span></div>
             
            </div>
   <span class="mt-3"> <b style="font-size:14px"><u>DEPOSIT</u></b></span>
    </b>
</center>
    <hr>
    <table class="table table-borderless">
        <tr>
            <th>Deposit Number:</th>
            <td><?= $recpt[0]->trans_number; ?></td>
        </tr>
        <tr>
            <th>Deposit Date:</th>
            <td><?= $recpt[0]->trans_date; ?></td>
        </tr>
        <tr>
            <th>Deposited by:</th>
            <td><?= $name_type; ?></td>
        </tr>
        <tr>
            <th> Name:</th>
            <td><?= $student_name; ?></td>
        </tr>
    </table>
    
</div>
</div>    
<hr>
    <div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
        <p class=" d-flex justify-content-center mt-3">DEPOSIT DETAILS</p>
        <?php if($leger_transaction[0]->name_type_id == 4){ ?>
            
            <table class="table">
                <thead>
                    <tr>
                        <th>REF TYPE</th>
                        <th>REF NUMBER</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                   
                    $total = 0;
                    foreach($itm_details as $itm){
                        $total+=$itm->unit_price;
                    ?>
                <tr>
                    <td><?php echo $invoice_type[0]->type_name??"";?></td>
                    <td><?= $student_id; ?></td>
                    <td><?= number_format($itm->unit_price);?></td>
                </tr>
                <?php } ?>
                 <tr>
                     <td colspan="2"><b>Total</b></td>
                    <th><b><?= number_format($total); ?></b></th>
                </tr>   
            </tbody>
        </table>    
                <?php }  else if($leger_transaction[0]->name_type_id == 1){?>
                    <table class="table">
                    <thead>
                        <tr>
                          
                            <th>DEPOSIT FOR</th>
                            <th>QTY</th>
                            <th class="text-right">PRICE</th>
                            <th class="text-right">Amount</th>
                          
                        </tr>
                    </thead>
                    <tbody>
                   <?php
                  // print_r($recpt);
                            $total = 0;
                            $i=0;
                             $amount = 0;
                            $query = $db->query('SELECT item_transation_tbl.item_id,item_name,account_name,trans_number,quantity,unit_price FROM item_transation_tbl,items_tbl,items_ledgers_tbl,accounts_tbl where item_transation_tbl.item_id = items_tbl.id AND items_ledgers_tbl.item_id = items_tbl.id AND item_transation_tbl.trans_type = 3 AND accounts_tbl.id = items_ledgers_tbl.account_id AND trans_number="'.$recpt[0]->trans_number.'"');
                        $result = $query->getResult();
                       $get_charges = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_id' =>22,'transation_nature' =>1,'trans_type' =>3));
                       $charged=0;
                       if(count($get_charges)>0){
                        $charged=$get_charges[0]->amount;
                       }
                         foreach($result as $itm){

                                  $amount = $itm->quantity * $itm->unit_price;
                                  $total += $amount;
                            
                         
                            ?>
                            <tr>
                                
                             <td class="text-left"><?= $itm->item_name; ?></td>
                                
                               <td class="text-center"><?= $itm->quantity; ?></td>
                             <td class="text-right"><?= number_format($itm->unit_price-$charged); ?></td>
                             <td class="text-right"><?= number_format($amount-$charged); ?></td>
                            </tr>
                   <?php 
                 $i++;
               } 
               ?>
                 <tr>
                     <td class="text-center"><b>Total</b></td>
                    
                    <th><b></b></th>
                    <th><b></b></th>
                    <th class="text-right"><b><?= number_format($total-$charged); ?></b></th>
                </tr>   
            </tbody>
        </table>
       <?php } ?>
    <!--</div>-->
    </div>
    </div>   
    <?php
      $channel = $bmodel->get_item_name('payment_response',$where = array('reference_no' => $control_number));

    if(count($channel)>0){
     $chann=$control_no[0]->payment_channel;
     $channel_name=$channel[0]->transaction_channel;
     $cus_name=$channel[0]->customer_name;
     if($chann==2){
        $ch="NMB-".$channel_name;
     }else{
        $ch="CRDB-".$channel_name;
     }
 }
    ?>
<div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
        <p class=" d-flex justify-content-center mt-3">PAYMENT DETAILS</p>
        <table class="table">
            <thead>
                <tr>
                    <th>PAYMENT CHANNEL</th>
                    <th>Ref</th>
                    <th class="text-right">Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php
                   
                     $query = $db->query('SELECT amount,account_name FROM ledger_transaction_tbl,accounts_tbl where ledger_transaction_tbl.ledger_id = accounts_tbl.id AND transation_nature = 2 AND trans_type=3 AND trans_no="'.$recpt[0]->trans_number.'"');
                     $result = $query->getResult();
                     $paytotal = 0;
                     foreach($result as $rsl){
                      $paytotal += $rsl->amount;
                ?>
                <tr>
                    <td><?= ($ch)??$rsl->account_name; ?></td>
                    <td><?= ($control_number)??""; ?></td>
                    <td class="text-right"><?= number_format($rsl->amount); ?></td>
                </tr>
             <?php 

                }
         $get_charges = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_id' =>22,'transation_nature' =>1,'trans_type' =>3));
                  
                            $charges=0;
                          
             if(count($get_charges)>0){

               $paytotal=$paytotal-$get_charges[0]->amount;
                   if($get_charges[0]->amount >0){
                ?>
                 <tr>
                     <td colspan="1" class="colspan-cell">Bank charges</td>
                    <th><b></b></th>
                  
                    <th class="text-right">-<?= number_format($get_charges[0]->amount); ?></th>
                </tr>
            <?php }}?>
                <tr>
                     <td ><b>Total</b></td>
                     <td ></td>
                    <th class="text-right"><b><?= number_format($paytotal); ?></b></th>
                </tr> 
            </tbody>
        </table>    
<!--    </div>-->
    </div>
</div> 
 <center><div class="mt-4 foot"><i>Powered by Micro Health Initiative</i></div></center>
 </div>
 <noscript>
    <style>
        .table-condensed{
            padding-bottom: 20px; 
        }
        table.table{
            width:80%;
            border-collapse:collapse;
            margin-left: auto;
            margin-right: auto;
           
        }
        table.table td,table.table th{
            border:1px solid;
          
        }
        .mt-1,.mt-4,.mt-2,.modify,.mb{
            font-size: 15px;
            padding-bottom: 20px;
        }
        .line{
            padding-bottom: 80px;
          border-bottom: 1px solid black; 
          width: 120px;  
        }
        .kindly{
            padding-top: 20px;
        padding-bottom: 0px;
        }
        .foot{
           padding-top: 20px;  
        }
        .text-right{
            text-align: right; 
        }
   .text-center{
            text-align: center; 
        }
        .table-borderless{
            border:none;
            margin: 0;

        }
         table.table-borderless td,table.table-borderless th{
            border:none;

          
        }
    /*.print-line {
      border-top: 10px solid black;
      margin: 10px 0;
    }
  */
    </style>
</noscript>
<script>

</script>


