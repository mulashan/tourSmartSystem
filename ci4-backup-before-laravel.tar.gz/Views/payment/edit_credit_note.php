  <link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<style type="text/css">

     .invoice > .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }

 </style>
 <?php
  $bmodel = new App\Models\BillingModel();
  $amodel = new App\Models\AdmissionModel();
  $cmodel = new App\Models\ClassesModel();
  $smodel = new App\Models\StudentModel();
  $appItems = $cmodel->get_applications_items();
  $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>6,'transation_nature'=>2));
  //echo $inv[0]->trans_number;
  $student_name = "";
  $name_type = "";
  $ref="";
  $amount = 0;
  $account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));
if(count($leger_transaction) > 0){
    $amount = $leger_transaction[0]->amount;
    if($leger_transaction[0]->name_type_id == 4){
        $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;     
    }else if($leger_transaction[0]->name_type_id == 1){
        $admn = $bmodel->get_item_name('students', $where = array('id'=>$leger_transaction[0]->name_id));
        //print_r($admn);
        $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name; 
        $parent = $smodel->gettable_billingdata($admn[0]->id);
        // $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $leger_transaction[0]->name_id));
        $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $leger_transaction[0]->name_id, 'status' => 1));
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;

        $pay = $bmodel->get_item_name('payment_request',$where = array('student_id' => $admn[0]->id,'trans_no'=>$inv[0]->trans_number));

        if(count($pay) > 0){
            $ref = $pay[0]->reference_no;
            $amount1 = $pay[0]->amount;
        }else{
            //echo $admn[0]->id;
            $pay2 = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_type' =>6,'trans_no'=>$inv[0]->trans_number,'transation_nature'=>1));
            
            $amount1 = $pay2[0]->amount;
           
            $id = $leger_transaction[0]->name_id;
            $no = $leger_transaction[0]->trans_no;
            $ref = "<b>Not Created</b> <br>".
            "<div id='control'><a href='javascript:void(0)' onclick='Create_ControlNumber($amount,$id,$no)'  class='btn btn-primary '>Create Control No</a></div>
            ";
        }
    }
}
$sno=$inv[0]->trans_number;
$name_id=$leger_transaction[0]->name_id;
 ?>
<div class="row">
    <div id="feedback"></div>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Invoice Information</h5>
            </div>
            </hr>

            <div class="card-body">
            
                <input type="hidden" name="student_id" id="studentid" value="<?= $inv[0]->trans_number;?>">
                <table class="table table-borderless">
                    <tr>
                        <th>Credit Note Number:</th>
                        <td><?= $inv[0]->trans_number; ?></td>
                    </tr>
                    <tr>
                        <th>Credit Note Date:</th>
                        <td><?= $inv[0]->trans_date; ?></td>
                    </tr>
                    <tr>
                        <th>Customer Type:</th>
                        <td><?= $name_type; ?></td>
                    </tr>
                    <tr>
                        <th>Student Name:</th>
                        <td><?= $student_name; ?></td>
                    </tr>
                    <tr>
                        <th>Registration No:</th>
                        <td><?= $admn[0]->student_id; ?></td>
                    </tr>
                    <tr>
                        <th>Class Admission N0:</th>
                        <td><?= $admn[0]->student_id.'-'.$admissn[0]->academic_year.'-'.$admissn[0]->class_id; ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Payment Information</h5>
            </div>
            </hr>

            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Control  Number:</th>
                        <td id="controlNo"><?= $ref; ?> </td>
                    </tr>
                    <tr>
                        <th>Amount:</th>
                        <td><?= number_format($amount1); ?></td>
                    </tr>
                    <tr>
                        <th>Phone No:</th>
                        <td><?= count($parent)>0?$parent[0]->phone1:'';?></td>
                    </tr>
                    <?php
                       $m = $bmodel->get_item_name('messages',$where = array('reference_no' => $ref,'message_type' => 3));
                       $msg = "";
                         if(count($m) > 0){
                            $msg = $m[0]->message;
                            $msg= str_replace(array("\r","\n"),' ',$msg);
                   ?>
                    <tr>
                        <th>Invoice MSG:</th>
                        <td><textarea class="form-control" name="msg" readonly><?= $msg; ?></textarea></td>
                    </tr>
                    <tr id="invoicetmsg">
                       <th >Message status:</th>
                        <td id="newstatus">
                           <?php if( $m[0]->sent_status == 1) {?>
                           <i>Sent date:<?php echo date("d-m-Y H:i:s",$m[0]->created_at); ?> 
                             <br>Status: <?php echo $m[0]->status_description; ?>
                             <span class="pull-right">
                             <button type="button" onclick="checksmsstatus('<?php echo $m[0]->message_id; ?>','invoicetmsg')" class="btn btn-success btn-sm pull-left"><i class="fa fa-refresh"></i></button>
                                         &nbsp;&nbsp;<button type="button" onclick='PaymntResndSMSform("PaymntResndForm","invoicetmsg")' class='btn btn-primary btn-sm'>Resend</button></span>
                             <script>
                                $(function() {
                                    checksmsstatus('<?php echo $m[0]->message_id; ?>','invoicetmsg');
                                 });
                             </script>
                             <?php }elseif( $m[0]->sent_status == 2){ ?>
                                  <i>Sent Date:<?php echo $m[0]->time_sent; ?> 
                                  <br>Status: <?php echo $m[0]->status_description; ?>
                                  <br>Delivered Date:<?php echo $m[0]->time_delivered; ?>       
                             <?php } ?> 
                        </td>            
                    </tr>
                                
                     <?php }else{ ?>
                    <tr>
                        <th>Invoice MSG:</th>
                        <td><textarea class="form-control" name="msg" readonly><?= $msg ="Kumb No: ".$ref.",Kiasi:TZS ".number_format($amount).", Mwanafunzi: ".$student_name.".". "Tafadhali Fanya Malipo Kupitia NMB.";?></textarea> </td>
                    </tr>
                    <tr >
                       <th>Message status:</th>
                        <td>
                            <i class="text-warning">Not Sent</i>
                        </td>   
                    </tr>
                     <?php } ?>
                    <!-- <tr>
                        <th>Message Status:</th>
                        <td></td>
                    </tr> -->
                    <tr>
                        <th></th>
                        <td>
                            <a href="javascript:void(0)" onclick="resendSMS('<?= count($parent)>0?$parent[0]->phone1:'';?>','<?= $msg; ?>','3','<?= $ref; ?>')"  class="btn btn-primary "><i class="fa fa-rotate-left"></i> Resend SMS</a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
   
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card  invoice">
            <div class="card-header">
                <h5>Charged Items</h5>
            </div>
            </hr>

            <div class="card-body">
                <form class="form-horizontal" id="add_Item">
                    <div class="form-group row mb-5">
                        <label class="col-sm-2 col-form-label">Add Charged Items<span class="text-danger">*</span></label>
                        <div class="col-sm-6">
                            <select class="form-select form-control" id="itemselect" style="width:100%;"></select>
                        </div>
                        <div class="col-sm-2">
                            <input type="number" id="qtty" class="form-control">
                            <input type="hidden" name="transNo" value="<?= $inv[0]->trans_number; ?>">
                            <input type="hidden" name="nameid" value="<?= $leger_transaction[0]->name_id;?>">
                        </div>
                        <div class="col-sm-2">
                            <button type="submit" class="btn btn-primary" id="add_invoiceItem"><i class="fa fa-plus"></i> Add Item</button>
                        </div>
                    </div>
                   
                </form>
                <p class=" d-flex justify-content-start mt-3 ms-3"><b>CHARGED ITEMS</b></p>
                <table class="table" id="mytable">
                    <thead>
                        <tr>
                            <th>Item Id</th>
                            <th>Item Name</th>
                            <th>Trans Comment</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th>Amount</th>
                            <th>Ledger</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="invoiceItem">
                         
                         <?php
                        $dbname=session()->get('db_name');
                    $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;
                        $query = $db->query('SELECT item_transation_tbl.item_id,item_name,account_name,trans_number,quantity,unit_price FROM item_transation_tbl,items_tbl,items_ledgers_tbl,accounts_tbl where item_transation_tbl.item_id = items_tbl.id AND items_ledgers_tbl.item_id = items_tbl.id AND item_transation_tbl.trans_type = 6 AND accounts_tbl.id = items_ledgers_tbl.account_id AND trans_number='.$inv[0]->trans_number);
                        $result = $query->getResult();

                        foreach($result as $itm){
                            $dat = $amodel->get_trans_type($inv[0]->trans_number);
                             $query2 = $db->query('SELECT type_name,amount FROM ledger_transaction_tbl,account_types_tbl where ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_transaction_tbl.trans_type = 6 AND (ledger_type = 3 OR ledger_type = 4) AND trans_no='.$inv[0]->trans_number);
                             $result2 = $query2->getResult();
                             $amount = $itm->quantity * $itm->unit_price;
                             if($itm->item_id==64){
                            $total -= $amount;
                             }else{
                            $total += $amount;
                             }
                            ?>
                         <tr>
                             <td><?= $itm->item_id; ?></td>
                             <td><?= $itm->item_name; ?></td>
                             <td></td>
                             <td><?= $itm->quantity; ?></td>
                             <td>
                                <div  class="cust_popup" id="cash<?php echo $itm->item_id;?>" style="display: none">
                                    <h6>Change price</h6>
                                <div id="prcres<?php echo $itm->item_id;?>"></div>
                                     
                               </div>
                                 <a class="cost2" id="cost<?= $itm->item_id; ?>" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getid(<?= $itm->item_id; ?>,<?php echo $itm->unit_price;?>,<?=$inv[0]->trans_number;?>)"><input type="text" value="<?=number_format($itm->unit_price); ?>" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:70px;text-align:right;" id="prc<?php echo $itm->item_id;?>" readonly></a>
                             </td>
                             <td id="ttotal<?php echo $itm->item_id;?>" class="text-center">
                                <?=number_format($itm->unit_price); ?>
                             </td>
                             <td><?= $itm->account_name; ?></td>
                             <td>
                                <a href="javascript:void(0)" class="btn-danger btn-sm"><i class="fa fa-trash"  onclick="Remove_item(this,<?= $itm->item_id;?>,<?= $admn[0]->id;?>,<?= $inv[0]->trans_number;?>)" ></i></a>
                            </td>
                         </tr>
                    <?php } ?>
                            <tr>
                                <td colspan="5"></td>
                                <td colspan="3"><b id="item_total"> <input type="text" value="<?=number_format($total); ?>" style="border:none;cursor:pointer;width:70px;text-align:right;" id="total" readonly></b></td>
                            </tr>
                    </tbody>
                </table>

            </div>

             <?php
              $account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));
              $que = $db->query('SELECT ledger_id,account_name,amount FROM ledger_transaction_tbl,accounts_tbl where ledger_transaction_tbl.ledger_type = accounts_tbl.account_type_id AND ledger_transaction_tbl.ledger_id = accounts_tbl.id AND ledger_transaction_tbl.trans_type = 6 AND ledger_type = 7 AND trans_no='.$inv[0]->trans_number);
                $acc = $que->getResult();

               
            ?>
                     <br>
                        <div class="form-group row">
                                 <div class="col-md-3">

                                 </div>
                                <label class="col-md-2 col-form-label">Account Receivable<span class="text-danger">*</span></label>
                             

                                <div class="col-md-5">
                                    <select name="account_edit" id="account_edit" class="form-control" required="required">
                                        
                                        <?php foreach ($account as $ac): ?>
                                            <?php
                                        if($ac->id==$acc[0]->ledger_id){
                                            ?>
                                        <option value="<?= $ac->id; ?>" selected><?= $ac->account_name; ?></option>
                                        <?php
                                           }else{
                                            ?>
                                            <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                        <?php } endforeach ?>
                                    </select>
                                </div>
                            </div>

                             <div class="form-group row">
                                 <div class="col-md-3">

                                 </div>
                                <label class="col-md-2 col-form-label">Amount<span class="text-danger"></span></label>
                              <div class="col-md-5">

                                 <!--------------popup---------------------->
                                <div  class="cust_popup" id="receivablePopup" style="display: none">
                                    <h6>Change Receivable</h6>
                                <div id="receivableAmount"></div>
                                     
                               </div>
                               <!------------------------------------>
                             <a class="cost2" id="receivable" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="changeReceivable(<?=$acc[0]->amount?>)"><input type="text" value="<?=number_format($acc[0]->amount); ?>" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:70px;text-align:right;" id="receivableId" readonly></a>
                              </div>
                              </div>

        </div>


                <button type="button" class="btn btn-primary float-right" onclick="UpdateInvoice(<?= $inv[0]->trans_number;?>,<?= $leger_transaction[0]->name_id;?>)"><i class="fa fa-save"></i> Update</button>
    </div>
</div>

<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script>
    calculateTotalAmount();
    $(document).ready(function(){

        $('#itemselect').select2({
            ajax: {
                url: "<?= base_url('load_data'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

        $('#itemselect').on('select2:select', function (e) {
            selectedItems();
        });
             
        function selectedItems(){  
            var rows = '';
           var itemData = 'item_selected='+$('#itemselect').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Itemdata')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }  
           });  
        }

    });
    var id = $('#studentid').val();
  //  $('#invoicePrint_content').load('print_invoice/'+id);
    // function printable_rept(inv){
    //     // alert('hello')
    //   $('#invoiceprint').modal('show'); 
    //   $('#invoicePrint_content').load('print_invoice/'+inv);
    // }


     function PaymntResndSMSform(formId,divhtml) {
          $.ajax({
            beforeSend: function () {
                $('#'+ divhtml).html('<i class="fa fa-spinner fa-spin"></i> Sending Message..');
            },
            type: "POST",
            url: '<?php //echo base_url() . '/index.php/StudentController/resend_sms'; ?>',
            data: $('#'+formId).serialize(),
            success: function (result) {
              //  alert(result);
                $('#'+ divhtml).html(result);             
            },
            error: function () {
                $('#'+divhtml).html('Sorry! Something went wrong.');
            }
        });
    }
    function checksmsstatus(id,divhtml){
     var data = "id=" + id;
         $.ajax({
            beforeSend: function () {
                $('#'+divhtml).html('<i class="fa fa-spinner fa-spin"></i> Checking sms status..');
            },
            type: "POST",
            url: '<?php echo base_url() . '/index.php/StudentController/check_sms'; ?>',
            data: data,
            success: function (result) {
                // $('#notsent').remove();
                $('#'+divhtml).html(result);             
            },
            error: function () {
                $('#'+divhtml).html('Sorry! Something went wrong.');
            }
        });
    }

    $('#add_invoiceItem').click(function(e){
        e.preventDefault();
        var items = $('#invoiceItem');
        var data = "item=" + $('#itemselect').val() + "&quantity=" + $('#qtty').val()+ '&id=' + $('input[name=nameid]').val()+ '&trans=' + $('input[name=transNo]').val();
         alert(data);
        // return;
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/add_credit_note_item'; ?>',
            data: data,
            dataType: "json", 
            success: function(res){
                console.log(res)
                items.html('');
                var total = 0;
                res.data.forEach((r,idx) => {
                    total+=(r.quantity * r.unit_price)
                    items.append(`
                            <tr>
                             <td>${r.item_id }</td>
                             <td>${r.item_name}</td>
                             <td></td>
                             <td>${r.quantity}</td>
                             <td>${r.unit_price }</td>
                             <td>${r.quantity * r.unit_price}</td>
                             <td>${res.ledger[0].type_name}</td>
                             <td>
                             <a href="javascript:void(0)"  class="btn-danger btn-sm"><i class="fa fa-trash" onclick="Remove_item(this,${r.item_id },${r.trans_number})"></i></a>
                            </td>
                         </tr>
                        `)

                    if((res.data.length-1) ===idx){
                    items.append(`
                        <tr>
                                <td colspan="5"></td>
                                <td colspan="3"><b id="item_total">${total}</b></td>
                            </tr>
                        `)
                    }
                })
                $('#item_total').html(total)
                $('#qtty').val('');
                $('#itemselect').val('');
                $('#accounts').val('');
            }
        });
    });

    function resendSMS(phone,msg,type,ref){
        var message = escape(msg);
        var data = 'phn=' + phone + '&msg=' + msg + '&type=' + type + '&ref=' + ref;

        // alert(data);
        // return;
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/SMSsender/'; ?>' + phone +'/'+ message +'/' + type +'/' + ref,
            success: function(res){
                console.log(res)
               
            }
        });
    }

    function Create_ControlNumber(total,stdID,transNo)
    {
        var data = 'total=' + total + '&id=' + stdID + '&no=' + transNo;
        // alert(data)
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/recreate_control_number/'; ?>' + total +'/'+ stdID +'/' + transNo,
            success: function(res){
                console.log(res)
               $('#controlNo').html(res);
            }
        });   
    }

    function Remove_item(root,itemID,stdID,transNo){
        var data = 'item=' + itemID + '&student=' + stdID + '&transNo=' + transNo;
         alert(data);
         $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/Remove_creditNoteItem'; ?>',
            data: data,
            success: function(){

                root.parentElement.parentElement.parentElement.remove();
            
            calculateTotalAmount(); 
            }
        });
    }

    function UpdateInvoice(transNo,nameID)
    {
        var data = 'trans=' + transNo + '&sID=' + nameID;
         // alert(data);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/update_invoice'; ?>',
            data: data,
            success: function (res) {
                console.log(res);
                var data = JSON.parse(res);

                if(data['status'] == "0"){
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            }
        });
    }
        var sumVal=0; 
        var prc;  
function getid(id,prc,sno) {
    //alert('here');
     $('#cash'+id).toggle(100);
     
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/ivoice_popup'; ?>/"+id,
            beforeSend: function () {
                $('#prcres'+id).html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#prcres'+id).html(result);
                console.log(prc);
             document.querySelector('[id="cash_amt'+id+'"]').value = prc;
             document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }
       function savebtn(){
        
        var sno=<?php echo $sno;?>;
        var nameID=<?php echo $name_id;?>;
     // alert(nameID);
        totalsum=0;
      
      var item_id=$('#item_id').val();
      var cash=parseInt($('#cash_amt'+item_id).val());
      //alert(cash);
     //  var price=$("#ttotal"+item_id).val();
     //  var number = parseInt(price.replace(/,/g, ""));
     //  var sum=parseInt(<?php echo $total;?>);
     // if(item_id==64){
     //  sum=(sum+number)-cash;
     //  }else{
     //     sum=(sum+cash)-number;
     //  }
       //alert(sum);
       var data = 'trans=' + sno + '&sID=' + nameID + '&itemID=' + item_id + '&cash=' + cash;
         // alert(data);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/update_credit_note_item'; ?>',
            data: data,
            success: function (res) {
                console.log(res);
                var data = JSON.parse(res);

                if(res){
                  document.querySelector('[id="prc'+item_id+'"]').value = cash.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                 document.getElementById("ttotal"+item_id).innerHTML = cash.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                     $('#cash'+item_id).hide();
                     calculateTotalAmount(); 
                   //$('#invoiceprint').modal('hide'); 
                }else{
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Item Price Not Updated</div>');
                }
            }
        }); 
    }
    
    function calculateTotalAmount() {
     
var table = document.getElementById("mytable"), totalsum=0;
           //alert(table.rows[1].cells[5].innerHTML); 
            for(var i = 1; i < table.rows.length-1; i++)
            {
               
                totalsum = totalsum + parseInt(table.rows[i].cells[5].innerHTML.replace(/,/gi, ""));

            }
           // alert(totalsum);
  document.querySelector('[id="total"]').value = totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

 function changeReceivable(prc) {
     var price=$('#receivableId').val().replace(/,/gi, "");
    // alert(price);
     $('#receivablePopup').toggle(100);
     
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/recevable_edit'; ?>/"+id,
            beforeSend: function () {
                $('#receivableAmount').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#receivableAmount').html(result);
                //console.log(prc);
             document.querySelector('[id="receivable_amount"]').value = price;
            // document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }

    function editReceivable(){
    var amount=parseInt($('#receivable_amount').val());
   // alert(amount);
    var sno=<?php echo $sno;?>;
        var nameID=<?php echo $name_id;?>;
  var data = 'trans=' + sno + '&sID=' + nameID + '&amount=' + amount+'&trans_type='+6;
//alert(data);
 $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/update_receivable'; ?>',
            data: data,
            success: function (res) {
                console.log(res);
                var data = JSON.parse(res);

                if(res){
                  document.querySelector('[id="receivableId"]').value = amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                  toastr.success("Receivable Updated successfully.", "success");
                     $('#receivablePopup').hide(); 
                   
                }else{
                   // $('#feedback').html('');
             toastr.error("Failed to update receivable.", "error"); 

                }
            }
        }); 
    }

</script>    
   