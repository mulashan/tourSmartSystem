  <style type="text/css">

     .invoice > .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }

 
 </style>
 <?php
  $bmodel = new App\Models\BillingModel();
  $amodel = new App\Models\AdmissionModel();
  $cmodel = new App\Models\ClassesModel();
  $smodel = new App\Models\StudentModel();
  $appItems = $cmodel->get_applications_items();
  $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>6,'transation_nature'=>2));
  $student_name = "";
  $name_type = "";
  $ref="";
  $amount = 0;
if(count($leger_transaction) > 0){
    $amount = $leger_transaction[0]->amount;
    if($leger_transaction[0]->name_type_id == 4){
        $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;     
    }else if($leger_transaction[0]->name_type_id == 1){
        $admn = $bmodel->get_item_name('students', $where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name; 
        $parent = $smodel->gettable_billingdata($admn[0]->id);
        // $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $leger_transaction[0]->name_id));
        $admissn = $bmodel->get_item_name('admission_tbl', $where = array('student_id' => $leger_transaction[0]->name_id, 'status' => 1));
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;

        $pay = $bmodel->get_item_name('payment_request',$where = array('student_id' => $admn[0]->id,'trans_no'=>$inv[0]->trans_number));

        if(count($pay) > 0){
            $ref = $pay[0]->reference_no;
            $amount_request = $pay[0]->amount;
        }else{
            // echo $admn[0]->id; 
            // echo '/'; 
            // echo $inv[0]->trans_number; 
            $ref = "<b>Not Created</b>";
             $pay2 = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no'=>$inv[0]->trans_number,'transation_nature'=>1,'trans_type'=>6));
            
            $amount_request = $pay2[0]->amount;
        }
    }
}
 ?>
<div class="row">
    <div id="feedback"></div>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Credit Note Information</h5>
            </div>
            </hr>

            <div class="card-body">
                <!-- <input type="hidden" name="student_id" id="studentid" value="<?php //$admissn[0]->id;?>"> -->
                <input type="hidden" name="student_id" id="studentid" value="<?= $inv[0]->trans_number;?>">
                <table class="table table-borderless">
                    <tr>
                        <th>Note Number:</th>
                        <td><?= $inv[0]->trans_number; ?></td>
                    </tr>
                    <tr>
                        <th>Note Date:</th>
                        <td><?= $inv[0]->trans_date; ?></td>
                    </tr>
                    <tr>
                        <th>Customer Type:</th>
                        <td><?= $name_type; ?></td>
                    </tr>
                    <tr>
                        <th>Student Name:</th>
                        <td><?= $student_name; ?></td>
                    </tr>
                    <tr>
                        <th>Registration No:</th>
                        <td><?= $admn[0]->student_id; ?></td>
                    </tr>
                    <tr>
                        <th>Class Admission N0:</th>
                        <td><?= $admn[0]->student_id.'-'.$admissn[0]->academic_year.'-'.$admissn[0]->class_id; ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <?php
    $dbname=session()->get('db_name');
    $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;
                        $query = $db->query('SELECT item_transation_tbl.item_id,item_name,account_name,trans_number,quantity,unit_price FROM item_transation_tbl,items_tbl,items_ledgers_tbl,accounts_tbl where item_transation_tbl.item_id = items_tbl.id AND items_ledgers_tbl.item_id = items_tbl.id AND item_transation_tbl.trans_type = 6 AND accounts_tbl.id = items_ledgers_tbl.account_id AND trans_number='.$inv[0]->trans_number);
                        $result = $query->getResult();

                        foreach($result as $itm){
                            $dat = $amodel->get_trans_type($inv[0]->trans_number);
                             $query2 = $db->query('SELECT type_name,amount FROM ledger_transaction_tbl,account_types_tbl where ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_transaction_tbl.trans_type = 6 AND (ledger_type = 3 OR ledger_type = 4) AND trans_no='.$inv[0]->trans_number);
                             $result2 = $query2->getResult();
                             $amount = $itm->quantity * $itm->unit_price;
                             if($itm->item_id==64){
                            $total -= $amount;
                             }else{
                            $total += $amount;
                             }
                         }
    ?>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Payment History</h5>
            </div>
            </hr>

            <div class="card-body">
                <table class="table" id="paytable">
                    <thead>
                                <tr>
                                    
                                    <th>Receipt No.</th>
                                    <th>Receipt Date</th>
                                   <th class="text-right">Receipt Amount</th>
                                    <th>Received By</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                //echo $inv[0]->trans_number;
                                $ttamount =0;
                                $trans = $bmodel->get_item_name('transaction_use_relation_tbl',$where = array('used_no' =>$inv[0]->trans_number,'trans_type' =>6));
                                $clss="";
                               if(count($trans)>0){
                                $clss="disabled";
                                    foreach($trans as $s){
                                    $number = $bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$s->receipt_no,'trans_type_id'=>2));
                                    
                                   // $invoice_type = $bmodel->get_item_join_table($s->trans_number);
                                    $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->receipt_no,'trans_type' =>2,'ledger_type' =>7));
                                    $student_name = "";
                                    $student_id = "";
                                    $control_number = "";
                                    $name_type = "";
                                    $amount =0;
                                    
                                    if(count($leger_transaction) > 0){
                                        $total_amount = $bmodel->get_total_amount_credit($s->receipt_no,7);
                                        if(count($total_amount) > 0)
                                            foreach($total_amount as $tv){
                                             $amount += $tv->amount;   
                                            }
                                            
                                         $ttamount=$ttamount +$s->amount;
                                        if($leger_transaction[0]->name_type_id == 4){
                                            $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                                            $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                            $student_id = $app[0]->id;
                                            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                            $name_type = $type_name[0]->name_type;
                                            
                                        }
                                        else if($leger_transaction[0]->name_type_id == 3){
                                             $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }else if($leger_transaction[0]->name_type_id == 1){
                                             $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }
                                        
                                    

                                    $user = $bmodel->get_item_name('users', $where = array('user_id' => $number[0]->updated_by));
                                ?>
                                <tr>
                                    <td><?php echo $s->receipt_no;?></td>
                                    <td><?php echo date('Y-m-d',strtotime($number[0]->trans_date));?></td>
                                      <td class="text-right"><?= number_format($s->amount); ?></td>
                                    <td><?= $user[0]->first_name.' '.$user[0]->last_name; ?></td>
                                     
                                    <td>
                                    <a href="javascript:void(0)" onclick="manage_receipt(<?php echo $number[0]->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i></a>
                                    </td>
                                    
                                </tr>
                            <?php }}}else{
                                echo "<tr><td>Currently there is no record</td></tr>";
                            } ?>
                            <tr><td><b>Total</b></td><td></td><td class="text-right"><b><?php echo number_format($ttamount);?></b></td></tr>
                             <tr><td><b>Amount Due</b></td><td></td><td class="text-right"><b><?php echo number_format($total-$ttamount);?></b></td></tr>
                            </tbody>
                        </table>
            </div>
        </div>
    </div>
   
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card  invoice">
            <div class="card-header">
                <h5>Charged Items</h5>
            </div>
            </hr>

            <div class="card-body">
                <p class=" d-flex justify-content-start mt-3 ms-3"><b>CHARGED ITEMS</b></p>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Item Id</th>
                            <th>Item Name</th>
                            <th>Trans Comment</th>
                            <th>Qty</th>
                            <th class="text-right">Price</th>
                            <th class="text-right">Amount</th>
                            <th>Ledger</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="">
                        <?php
                      $dbname=session()->get('db_name');
                    $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;
                        $query = $db->query('SELECT item_transation_tbl.item_id,item_name,account_name,trans_number,quantity,unit_price FROM item_transation_tbl,items_tbl,items_ledgers_tbl,accounts_tbl where item_transation_tbl.item_id = items_tbl.id AND items_ledgers_tbl.item_id = items_tbl.id AND item_transation_tbl.trans_type = 6 AND accounts_tbl.id = items_ledgers_tbl.account_id AND trans_number='.$inv[0]->trans_number);
                        $result = $query->getResult();

                        foreach($result as $itm){
                            $dat = $amodel->get_trans_type($inv[0]->trans_number);
                             $query2 = $db->query('SELECT type_name,amount FROM ledger_transaction_tbl,account_types_tbl where ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_transaction_tbl.trans_type = 1 AND (ledger_type = 3 OR ledger_type = 4) AND trans_no='.$inv[0]->trans_number);
                             $result2 = $query2->getResult();
                             $amount = $itm->quantity * $itm->unit_price;
                             if($itm->item_id==64){
                            $total -= $amount;
                             }else{
                            $total += $amount;
                             }
                            ?>
                         <tr>
                             <td><?= $itm->item_id; ?></td>
                             <td><?= $itm->item_name; ?></td>
                             <td></td>
                             <td><?= $itm->quantity; ?></td>
                             <td class="text-right"><?= number_format($itm->unit_price); ?></td>
                             <td class="text-right"><?= number_format($amount); ?></td>
                             <td><?=$itm->account_name; ?></td>
                         </tr>
                    <?php } ?>
                            <tr>
                                <td></td> <td></td> <td></td> <td></td> <td></td>
                                <td class="text-right"><b><?php echo number_format($total); ?></b></td>
                            </tr>
                    </tbody>
                </table>

            </div>

        </div>

<!--------------------------------------------------------------------------------------->
<div class="row">
 <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Credit note message</h5>
            </div>
            </hr>

            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    
                    <tr>
                        <th>Amount:</th>
                        <td><?= number_format($amount_request); ?></td>
                    </tr>
                    <tr>
                        <th>Phone No:</th>
                        <td><?= count($parent)>0?$parent[0]->phone1:'';?></td>
                    </tr>
                    <?php
                       $mtype = $bmodel->get_item_name('message_groups_tbl',$where = array('trans_number' => $inv[0]->trans_number,'message_type' => 11));
                       $msg = "";
                         if(count($mtype) > 0){
                          $m = $bmodel->get_item_name('messages',$where = array('send_no' => $mtype[0]->send_number,'message_type' => 11));  
                          if(count($m)>0){
                               $msg = $m[0]->message;
                         
                           
                   ?>
                    <tr>
                        <th>Credit Note MSG:</th>
                        <td><textarea class="form-control" name="msg" readonly><?= $msg; ?></textarea></td>
                    </tr>
                    <tr id="invoicetmsg">
                       <th >Message status:</th>
                        <td id="newstatus">
                           <?php if( $m[0]->sent_status == 1) {?>
                           <i>Sent date:<?php echo date("d-m-Y H:i:s",$m[0]->created_at); ?> 
                             <br>Status: <?php echo $m[0]->status_description; ?>
                             <span class="pull-right">
                             <button type="button" onclick="checksmsstatus('<?php echo $m[0]->message_id; ?>','invoicetmsg')" class="btn btn-success btn-sm pull-left"><i class="fa fa-refresh"></i></button>
                                         &nbsp;&nbsp;<button type="button" onclick='PaymntResndSMSform("PaymntResndForm","invoicetmsg")' class='btn btn-primary btn-sm'>Resend</button></span>
                             <script>
                                $(function() {
                                    checksmsstatus('<?php echo $m[0]->message_id; ?>','invoicetmsg');
                                 });
                             </script>
                             <?php }elseif( $m[0]->sent_status == 2){ ?>
                                  <i>Sent Date:<?php echo $m[0]->time_sent; ?> 
                                  <br>Status: <?php echo $m[0]->status_description; ?>
                                  <br>Delivered Date:<?php echo $m[0]->time_delivered; ?>       
                             <?php } ?> 
                        </td>            
                    </tr>
                                
                     <?php  }else{
                               $msg = "";
                          }
                     }else{ ?>
                    <tr>
                        <th>Credit Note MSG:</th>
                        <td><textarea class="form-control" name="msg" readonly><?= $msg ="Kumb No: ".$ref.",Kiasi:TZS ".number_format($total).", Mwanafunzi: ".$student_name.".". "Tafadhali Fanya Malipo Kupitia NMB.";?></textarea> </td>
                    </tr>
                    <tr >
                       <th>Message status:</th>
                        <td>
                            <i class="text-warning">Not Sent</i>
                        </td>   
                    </tr>
                     <?php } ?>

 
                </table>
            </div>
        </div>
    </div>
<!---------------------------------------------------------------------------------------->
       <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Accounts Receivable</h5>
            </div>
            </hr>
           <div class="card-body">
                <table class="table">
                    <!-- <th colspan="8"><p class=" d-flex justify-content-start mt-3"><b>ACCOUNT RECEIVABLES</b></p></th> -->
                    <tbody>
                        <?php 
                            $accnt = $db->query('SELECT ledger_transaction_tbl.id,ledger_id,ledger_type,amount,name_id,account_name,type_name 
                            FROM ledger_transaction_tbl,accounts_tbl,account_types_tbl 
                            WHERE ledger_transaction_tbl.ledger_id = accounts_tbl.id AND ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_type = 7 AND trans_type=6 AND trans_no='.$inv[0]->trans_number);
                            $results  = $accnt->getResult();
                            foreach ($results as $ac){

                        ?>
                        <tr>
                            <td><?= $ac->ledger_id; ?></td>
                            <td><?= $ac->account_name; ?></td>
                            <td colspan="3"></td>
                            <td><?= number_format($ac->amount);?></td>
                            <td><?= $ac->type_name; ?></td>
                            <td></td>
                        </tr>
                    <?php } ?>
                            <tr>
                                <td colspan="5"></td>
                                <td colspan="3"><b><?php echo number_format($total); ?></b></td>
                            </tr>
                    </tbody>
                </table>

            </div>
        </div>
        </div>

    </div>
    <?php
     if($clss==""){
        $msg="";
        ?>
        <div class="tooltip-container mt-4">
  <button type="button" class="btn btn-danger mb-3 pull-left <?= $clss;?>" onclick="dalete_creditNote(<?php echo $inv[0]->id;?>)" ><i class="fa fa-trash"></i> Delete</button>
  </div>
        <?php
     }else{
         $msg="You can no longer delete this transaction because there are related transactions already. Please delete related transactions first.";
         ?>
 <div class="tooltip-container mt-4" data-tooltip="<?php echo $msg;?>">
  <button type="button" class="btn btn-danger mb-3 tooltip-button pull-left <?= $clss;?>" onclick="dalete_creditNote(<?php echo $inv[0]->id;?>)" data-toggle="tooltip" data-tooltip="<?php echo $msg;?>"><i class="fa fa-trash"></i> Delete</button>
  </div>
         <?php
     }

    ?>

    
</div>


<script>
    var id = $('#studentid').val();
    $('#invoicePrint_content').load('print_note/'+id);
    // function printable_rept(inv){
    //     // alert('hello')
    //   $('#invoiceprint').modal('show'); 
    //   $('#invoicePrint_content').load('print_invoice/'+inv);
    // }


     function PaymntResndSMSform(formId,divhtml) {
          $.ajax({
            beforeSend: function () {
                $('#'+ divhtml).html('<i class="fa fa-spinner fa-spin"></i> Sending Message..');
            },
            type: "POST",
            url: '<?php //echo base_url() . '/index.php/StudentController/resend_sms'; ?>',
            data: $('#'+formId).serialize(),
            success: function (result) {
              //  alert(result);
                $('#'+ divhtml).html(result);             
            },
            error: function () {
                $('#'+divhtml).html('Sorry! Something went wrong.');
            }
        });
    }
    function checksmsstatus(id,divhtml){
     var data = "id=" + id;
         $.ajax({
            beforeSend: function () {
                $('#'+divhtml).html('<i class="fa fa-spinner fa-spin"></i> Checking sms status..');
            },
            type: "POST",
            url: '<?php echo base_url() . '/index.php/StudentController/check_sms'; ?>',
            data: data,
            success: function (result) {
                // $('#notsent').remove();
                $('#'+divhtml).html(result);             
            },
            error: function () {
                $('#'+divhtml).html('Sorry! Something went wrong.');
            }
        });
    }

    function resendSMS(phone,msg,type,ref){
        var data = 'phn=' + phone + '&msg=' + msg + '&type=' + type + '&ref=' + ref;
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/SMSsender/'; ?>' + phone +'/'+ msg +'/' + type +'/' + ref,
            success: function(){
               
            }
        });
    }

    function Remove_item(root,itemID,stdID,transNo,classID,hostelID,transID){
        var data = 'item=' + itemID + '&student=' + stdID + '&transNo=' + transNo + '&class=' + classID + '&hostel=' + hostelID + '&transport=' + transID;
        // alert(data);
         $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/Remove_invoicedItem'; ?>',
            data: data,
            success: function(){

                root.parentElement.parentElement.remove();

            }
        });
    }

    function UpdateInvoice(transNo,nameID)
    {
        var data = 'trans=' + transNo + '&sID=' + nameID;
         // alert(data);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/update_invoice'; ?>',
            data: data,
            success: function (res) {
                var data = JSON.parse(res);

                if(data['status'] == "0"){
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            }
        });
    }
   
</script>    
   