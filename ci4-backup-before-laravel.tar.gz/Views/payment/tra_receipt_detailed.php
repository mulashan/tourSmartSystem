<div id="GenralRcptHistPrint">
    <?php
        
         
         echo '<center><img src="' . base_url('public/assets/images/tra/TRA_logo.bmp').'" style="width: 30%;height: 60px;"></center>';
         echo '<center><h6>'.$dtls[0]->NAME .'<br>';
         echo 'Address:'.$dtls[0]->ADDRESS  .',';
         echo $dtls[0]->REGION  .',';
         echo $dtls[0]->STREET .'<br>';
         echo 'TEL:'.$dtls[0]->MOBILE .'<br>';
         echo 'TIN:'.$dtls[0]->tinNum .'<br> ';
         echo 'VRN:'.$dtls[0]->custVRN .'<br>';
         echo 'SerialNo:'.$dtls[0]->serialNum .'<br>';
         echo 'UIN:'.$dtls[0]->UIN .'<br>';
         echo 'TAX OFFICE:'.$dtls[0]->TAXOFFICE  .'<br></h6></center>';
        $id_type = 'NIL';
   
        ?>
    <br>
    <table class="table table-condensed" style="width:100%;font-size: 10px">
            <td>Customer Name:</td>
            <td colspan="2"><?php echo $customer_name; ?></td>
        </tr> 
        <tr>
            <td>Customer ID Type:</td>
            <td colspan="2"><?php echo $id_type; ?></td>
        </tr> 
        <tr>
            <td>Customer ID:</td>
            <td colspan="2"><?php echo ""; ?></td>
        </tr> 
        <tr>
            <td>Customer Mobile:</td>
            <td colspan="2">n/a</td>
        </tr> 
         <tr>
            <td colspan="3">&nbsp;</td>
        </tr>
        <tr>
            <td>Receipt No:</td>
            <td colspan="2"><?php if($vfd_datas[0]->GC==0){
               echo $vfd_datas[0]->receipt_number; 
            }else{
            echo $vfd_datas[0]->GC; } ?></td>
        </tr>
        <tr>
            <td>Z Number:</td>
            <td colspan="2"><?php echo date('Ymd', strtotime($vfd_datas[0]->date_created)); ?></td>
        </tr>
        <tr>
            <td>Rec Date:</td>
            <td colspan="2"><?php echo date('d-m-Y', strtotime($vfd_datas[0]->date_created)); ?></td>
        </tr>
        <tr>
            <td>Rec Time:</td>
            <td colspan="2"><?php echo date('H:i:s', strtotime($vfd_datas[0]->date_created)); ?></td>
        </tr>
        <tr>
            <td colspan="3">&nbsp;</td>
        </tr>
        <tr>
            <td><b>Description</b></td>
             <td><b>Qty</b></td>
            <td><b>Amount</b></td>
        </tr>
                <?php
      
        $vatAmt = 0*$amount/118;
        $sub_tot=$amount-$vatAmt;
        echo '<tr>
                <td>School fees</td>
                <td>1</td>
                <td>' . number_format($amount, 2) . '</td>
            </tr>';
            
          ?>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
         <?php
             echo '<tr><td><b>TOTAL EXCL OF TAX:</b></td><td></td><td><b>' . number_format($sub_tot,2) . '</b></td></tr>';
             
             if($vatAmt != 0){
               echo '<tr style="font-size: 9px"><td><b>TAX A-18%:</b></td><td></td><td><b>' . number_format($vatAmt,2) . '</b></td></tr>'; 
             }
             echo '<tr><td><b>TOTAL TAX:</b></td><td></td><td><b>' . number_format($vatAmt,2) . '</b></td></tr>'; 
             echo '<tr><td><b>TOTAL INCL OF TAX:</b></td><td></td><td><b>' . number_format($sub_tot + $vatAmt,2) . '</b></td></tr>'; 
         
      //if print receipt
         //   echo $vfd_datas[0]->QRCODE_NAME;
        ?>

        <tr>
            <td colspan="3">&nbsp;</td>
        </tr>
       
       
    </table>
    <hr>
      <center><b>RECEIPT VERIFICATION CODE</b><br><?php if($vfd_datas[0]->QR_code !=0){ echo $vfd_datas[0]->QR_code;}else{ echo '15AEB001';} ?></center><br><center><img src="<?php echo base_url('public/qrcodes/'.$vfd_datas[0]->QRCODE_NAME); ?>" width='70' height='70'></center>
        
    <hr>
    <!-- <center><h6>*** END OF LEGAL RECEIPT ***</h6></center> -->
   
</div>
    <hr>
    <br>
    <div class="watermark" style="position: absolute;color: lightgray;opacity: 0.3;font-size: 4em;width: 40%;top: 90%;text-align: center;z-index: 0;"><center>Reprinted</center></div>
	 <div  style="width:100%;">
            
            <center>
                <i>Powered by <b>MHI</b><br>
                    www.microhealthinitiative.org</i>
            </center>
	</div>
</div>
<span class="pull-right">
    <button class="btn btn-warning btn-sm" onclick="$('#recptHist').modal('toggle')">Close</button>
    <button class="btn btn-primary btn-sm" onclick="printReceiptHist()"><span class="fa fa-print"></span> Print</button>
</span>
<iframe id="ifrmHistPrint" width="0px" height="0px"></iframe>
<br>
<script>
  
    
    function printReceiptHist(area) {
        try {
            var oIframe = document.getElementById('ifrmHistPrint');
            var oContent = document.getElementById("GenralRcptHistPrint").innerHTML;
            var oDoc = (oIframe.contentWindow || oIframe.contentDocument);
            if (oDoc.document)
                oDoc = oDoc.document;
            oDoc.write('<head><title>Receipt</title>');
            oDoc.write('</head><body onload="this.focus(); this.print();">');
            oDoc.write(oContent + '</body>');
            oDoc.close();
        } catch (e) {
            self.print();
        }
    }

  

</script>
