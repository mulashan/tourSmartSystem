 <?php
  $bmodel = new App\Models\BillingModel();
  $cmodel = new App\Models\ClassesModel();
  $appItems = $cmodel->get_applications_items();
 
$company_reg = $bmodel->get_table_details('company_tbl');
// $sname = $bmodel->get_item_name('students',$where = array('id' =>$recpt[0]->student_id));
///////////////////////////////////
 if($recpt[0]->inv_type==1){
     $sname=$bmodel->get_item_name('students_application_tbl',$where = array('id' => $recpt[0]->student_id));
     
    }else{
      
       $name_type_id=$bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $recpt[0]->trans_no,'trans_type'=>$recpt[0]->trans_type));
       if($name_type_id[0]->name_type_id==6){
    $sname=$bmodel->get_item_name('other_students_tbl',$where = array('id' => $recpt[0]->student_id));
       }else{
      $sname=$bmodel->get_item_name('students',$where = array('id' => $recpt[0]->student_id));
         }
  
    }
///////////////////////////////////
$pdetails = $bmodel->get_item_name('payment_response',$where = array('reference_no' =>$recpt[0]->reference_no));
 ?>
<div class="row">
<div class="col-md-12">
    <!-- <center><b style="font-size:14px"><u>RECEIPT</u></b></center> -->
    <center>
      <p> <img src="<?php  echo base_url('public/company_photos/'.$company_reg[0]->logo_name) ?>" style="width: 45%;height: 120px;background: white;" ></p>
 <span class="mt-4"><b><?= $company_reg[0]->company_name; ?> </b></span><br>
            <span class="modify"><?= $company_reg[0]->address; ?></span>
            <div class="mb-3">
                <div><span class="modify">Phone: +<?= $company_reg[0]->phone1; ?></span></div>
                <div><span class="modify">Email: <?= $company_reg[0]->email; ?></span></div>
                <div><span class="modify"> <?= $company_reg[0]->website; ?></span></div>
             
            </div>
   <!-- <span class="mt-3"> <b style="font-size:14px"><u>RECEIPT</u></b></span> -->
    </b>
</center>
    <hr>
    <center>
  <div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
        <h5 class="d-flex justify-content-center mt-3"><b><u>Control Number Details</u></b></h5>
           
 <table class="table table-borderless">
        <tr>
            <th>Control Number:</th>
            <td><?= $recpt[0]->reference_no; ?></td>
        </tr>
        <tr>
            <th>Student Name:</th>
            <td><?= $sname[0]->full_name; ?></td>
        </tr>
        <tr>
            <th>Amount To Pay:</th>
            <td><?= number_format($recpt[0]->amount); ?></td>
        </tr>
        <tr>
            <th>Charges:</th>
            <td><?= number_format($recpt[0]->charges); ?></td>
        </tr>
        <tr>
            <th>Date Created:</th>
            <td><?= $recpt[0]->date_created; ?></td>
        </tr>
    </table>
    </div>
</div> 

<div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
        <h5 class=" d-flex justify-content-center mt-3"><b><u>Payments Details</u></b></h5>
           
 <table class="table table-borderless">
                 <thead>
                    <tr>
                        <th>Payment Date</th>
                        <th>Rct No</th>
                        <th>Payer Name</th>
                        <th>Account</th>
                        <th>Amount</th>
                        <!-- <th>Channel</th> -->
                    </tr>
                </thead>
                <tbody>
                     <?php
                if(count($pdetails)>0){
                    $sum=0;
                 ?>
                    <?php
                   foreach($pdetails as $dt){
                    $sum=$sum+=$dt->amount_payed;
                    ?>
                
             <tr>
            <td><?= $dt->transaction_date; ?></td>
            <td><?= $dt->transaction_receipt; ?></td>
            <td><?= $dt->customer_name; ?></td>
            <td><?= $dt->account_no; ?></td>
            <td><?= number_format($dt->amount_payed); ?></td>
            <!-- <td><?= $dt->transaction_channel; ?></td> -->
           </tr>
           
         <?php
     }
     ?>
              <tr>
              <td colspan="2"><b>Total</b></td>
                    <th><b></b></th>
                    <th><b></b></th>
                    <th class="text-right"><b><?= number_format($sum); ?></b></th>
                </tr>
                <?php
                  $reltn = $bmodel->get_item_name('transactions_relation',$where = array('invoice_trans_no' =>$recpt[0]->trans_no));
           $amount_transfered=0;
           foreach($reltn as $r){
              $transfer = $bmodel->get_item_name('receipt_transfer_tbl',$where = array('old_receipt_number' =>$r->receipt_trans_no));  
              if(count($transfer)>0){
               $amount_transfered=$amount_transfered+$transfer[0]->amount_transfered;  
              
                  ?>
                  <tr>
              <td colspan="2"><b>Reversal</b></td>
                    <th><b></b></th>
                    <th><b></b></th>
                    <th class="text-right"><b><?= number_format($amount_transfered) ?></b></th>
                </tr> 
                  <?php
              }
              
           }
                ?>
                 <tr>
              <td colspan="2"><b>Remain</b></td>
                    <th><b></b></th>
                    <th><b></b></th>
                    <th class="text-right"><b><?= number_format($recpt[0]->amount+$recpt[0]->charges-$sum + $amount_transfered); ?></b></th>
                </tr>
     <?php
         }else{

            ?>
          <tr>
            <th class="text-danger text-center">No any Payment Made</th>
           
        </tr>
            <?php
            
           }
         
        ?>
          
  </tbody>
</table>
    </div>
</div> 
<p class="text-center"><i>Powered by MHI</i></p>
</center>
<script>
function edit_controlnumber_name(ref,stname){
     var dt='ref='+ref+'&student_name='+stname;
    // alert(dt);
            $.ajax({
                type: "POST",
               url: '<?php echo base_url() . '/index.php/AdmissionController/updateControlnumber_name'; ?>',
                data: dt,
                 error: function() {
                    toastr.error('Something is wrong','error');
                 },
                 success: function(data) {
                     if(data==1){
                        
                    toastr.success("Updated successfully.", "success");
                    }else{
                       toastr.error("Failed to update.", "error");  
                    }
                   // $('#changeDate').hide();
                      
                 }
              });

           }
</script>


