<?php
     $bmodel = new App\Models\BillingModel();
     $smodel = new App\Models\StudentModel();
    $dbname=session()->get('db_name');
    $db = \Config\Database::connect($dbname);

     if($ctype == 3){
         $names= $db->query('SELECT * FROM others_tbl 
                          WHERE `id` = \''.$search.'\' OR`customer_name`LIKE \'%'.$search.'%\'');
     }elseif($ctype == 2){
         $names= $db->query('SELECT * FROM supplier_tbl 
                          WHERE `supplier_id` = \''.$search.'\' OR`supplier_name`LIKE \'%'.$search.'%\' OR`supplier_name`LIKE \'%'.$search.'%\' OR`supplier_id`LIKE \'%'.$search.'%\'');
     }elseif($ctype == 4){
         $names= $db->query('SELECT * FROM students_application_tbl 
                          WHERE `id` = \''.$search.'\' OR`first_name`LIKE \'%'.$search.'%\' OR`last_name`LIKE \'%'.$search.'%\' OR`full_name`LIKE \'%'.$search.'%\'');
     }
     elseif($ctype == 1){
         $names= $bmodel->search_student($search);
     }else{
         return 'No such customer type';
     }
     $result = $names->getResult();
        
      if(count($result) == 0 && $ctype == 1){
        //echo $search;
            $name_parts = explode(" ", $search);
            if(count($name_parts)==3){
                $first_name = $name_parts[0];
                $middle_name = $name_parts[1];
                $last_name = $name_parts[2];
                $names= $db->query('SELECT * FROM students 
                          WHERE `middle_name` LIKE \'%'.$middle_name.'%\' AND `first_name` LIKE \'%'.$first_name.'%\' AND `last_name` LIKE \'%'.$last_name.'%\'');
            $result = $names->getResult();
            }else if(count($name_parts)==2){
                $first_name = $name_parts[0];
                $middle_name = $name_parts[1];
                $names= $db->query('SELECT * FROM students 
                          WHERE `middle_name` LIKE \'%'.$middle_name.'%\' AND `first_name` LIKE \'%'.$first_name.'%\'');
            $result = $names->getResult();
                  }
                 }
               // print_r($result);return;
if(count($result) > 0){ 
    $rsl = $result;
    if($ctype !=2){
   
$parentid = $db->query('SELECT parent_id FROM parents_students_tbl WHERE student_id = '.$rsl[0]->id.'');
$pid_result = $parentid->getResult();
if(count($pid_result)>0){
   $parent = $db->query('SELECT first_name,last_name,full_name FROM parents_tbl WHERE id = '.$pid_result[0]->parent_id.'');
   $p_result = $parent->getResult();
}
    }


    if($ctype == 4){
 ?>
        <table class="table table-hover">
            <thead>
                 <tr>
                    <th>App Id</th>
                    <th>Applicant Name</th>
                    <!-- <th>Parent</th> -->
                    <th>total</th>
                    <th></th>
                </tr>
        </thead> 
            <tbody> 
            <?php foreach ($rsl as $s) { 
                $total = $db->query('SELECT sum(unit_price) as total FROM temp_item_transation_tbl 
                               WHERE student_id = '.$s->id.' AND bill_status = 0');
                $total_price = $total->getResult();
            ?>     
                <tr>
                   <td><?= $s->id; ?></td>
                   <td><?= $s->first_name.' '.$s->middle_name.' '.$s->last_name; ?></td>
                   <td><a data-bs-toggle="collapse" href="#invoiceDetailed" aria-expanded="false" aria-controls="invoiceDetailed" style="color:#5F6468;"><?= number_format($total_price[0]->total);?></a></td>
                   <td><button class="btn btn-primary btn-sm pull-right" onclick="prepare_invoice('<?= $s->id; ?>')"><i class="fa fa-plus" aria-hidden="true"></i> Add</button></td>
               </tr>
           <?php } ?>
            </tbody>   
        </table>  
       <div class="collapse" id="invoiceDetailed">
                <?php
                $inv = $bmodel->get_item_name('temp_item_transation_tbl',$where = array('student_id' =>$rsl[0]->id,'bill_status'=>0));
                 if(count($inv) > 0){
                     ?>
                     <center><h6>Pending Bills</h6></center>
                     <table class="table">
                         <thead>
                            <tr>
                                <td>Sn</td>
                                <td>Description</td>
                                <td>Control No</td>
                                <td>Total</td>
                                </tr>
                         </thead>
                         <tbody>
                             <?php
                     $sn=1;
                     $total = 0;
                     foreach($inv as $in){
                        $itm = $bmodel->get_item_name('items_tbl',$where = array('id' =>$in->item_id));
                         echo '<tr><td>'.$sn++.'</td>';
                         echo '<td>'.$itm[0]->item_name.'</td>';
                         echo '<td>'.$in->reference_no.'</td>';
                         echo '<td>'.number_format($in->unit_price).'</td></tr>';
                         $total+=$in->unit_price;
                     }
                     ?>
                   </tbody>
                 </table>
               <?php  } ?>
        </div>
<?php }else if($ctype == 1){ ?>
    <table class="table table-hover">
            <thead>
                 <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Class</th>
                    <th>Stream</th>
                    <th></th>
                </tr>
        </thead> 
        <tbody>
            <?php foreach ($rsl as $s) {
                 $std = $smodel->gettable_stdetail($s->id);
                $credit = $db->query('SELECT sum(amount) as credit FROM  ledger_transaction_tbl  
                               WHERE name_id = '.$s->id.'  AND name_type_id ='.$ctype.' AND transation_nature = 1 and trans_type = 1');
                $debit = $db->query('SELECT sum(amount) as debit FROM  ledger_transaction_tbl  
                                       WHERE name_id = '.$s->id.' AND ledger_type = 7 and name_type_id ='.$ctype.' AND transation_nature = 1 and trans_type = 2');
                $credit_total = $credit->getResult(); 
                $debit_total = $debit->getResult(); 
                $diff =$credit_total[0]->credit - $debit_total[0]->debit;
                if(count($std)>0){
            ?>
            <tr>
                   <td><?= $s->student_id; ?></td>
                   <td><?= $s->first_name.' '.$s->middle_name.' '.$s->last_name; ?></td>
                   <td><?= $s->gender; ?></td>
                   <td><?= $std[0]->class_name; ?></td>
                   <td><?= $std[0]->stream_name; ?></td>
                   <!-- <td><?= number_format($diff);?></a></td> -->
                   <td><button class="btn btn-primary btn-sm pull-right" onclick="prepare_invoice_student('<?= $s->id; ?>',event)"><i class="fa fa-plus" aria-hidden="true"></i> Add</button></td>
               </tr>
           <?php }
          else{
              echo '<tr>';
                echo '<td>'.$s->id.'</td>';
                echo '<td>'.$s->full_name.'</td>';
                echo '<td style="color:red">No Invoice</td>';
                echo '</tr>';
          }
       } ?>
        </tbody>
      </table>
<?php }else if($ctype == 3){ ?>
    <table class="table table-hover">
            <thead>
                 <tr>
                    <th>Id</th>
                    <th>Customer Name</th>
                    <th>Phone</th>
                    <th>Tin</th>
                    <th></th>
                </tr>
        </thead> 
        <tbody>
            <?php 
        if(count($result)>0){
            foreach ($rsl as $s) {
             
            ?>
            <tr>
                   <td><?= $s->id; ?></td>
                   <td><?= $s->customer_name; ?></td>
                   <td><?= $s->customer_phone; ?></td>
                   <td><?= $result[0]->customer_tin; ?></td>
                  <?php
                    if($receipt_type==2){
                  ?>
                   <td><button class="btn btn-primary btn-sm pull-right" onclick="prepare_sales_receipt('<?= $s->id; ?>')"><i class="fa fa-plus" aria-hidden="true"></i> Add</button></td>
                    <?php
                    }else{
                  ?>
                    <td><button class="btn btn-primary btn-sm pull-right" onclick="prepare_invoice_student('<?= $s->id; ?>',event)"><i class="fa fa-plus" aria-hidden="true"></i> Add</button></td>
                   <?php } ?> 
               </tr>
           <?php }
               }  else{
              echo '<tr>';
                echo '<td colspan="2" style="color:red">Not Found</td>';
                echo '</tr>';
          }
       ?>
        </tbody>
      </table>
<?php } else if($ctype == 2){ 
   ?>

<table class="table table-hover">
            <thead>
                 <tr>
                    <th>Id</th>
                    <th>Supplier Name</th>
                    <th>Phone</th>
                    
                    <th></th>
                </tr>
        </thead> 
        <tbody>
              <?php 
        if(count($result)>0){
            foreach ($rsl as $s) {
             
            ?>
            <tr>
                   <td><?= $s->supplier_id; ?></td>
                   <td><?= $s->supplier_name; ?></td>
                   <td><?= $s->supplier_phone; ?></td>
                   
                  <?php
                    if($receipt_type==2){
                  ?>
                   <td><button class="btn btn-primary btn-sm pull-right" onclick="prepare_sales_receipt('<?= $s->supplier_id; ?>')"><i class="fa fa-plus" aria-hidden="true"></i> Add</button></td>
                    <?php
                    }else{
                  ?>
                    <td><button class="btn btn-primary btn-sm pull-right" onclick="prepare_invoice_student('<?= $s->supplier_id; ?>',event)"><i class="fa fa-plus" aria-hidden="true"></i> Add</button></td>
                   <?php } ?> 
               </tr>
           <?php }
               }  else{
              echo '<tr>';
                echo '<td colspan="2" style="color:red">Not Found</td>';
                echo '</tr>';
          }
       ?>
        </tbody>
      </table>
   <?php
}

 }
else{
       echo "<span style='color:red'>No any data Found</span>";

}
?>

 
