<?php
 $dbname=session()->get('db_name');
    $db = \Config\Database::connect($dbname);
    $query = $db->query('SELECT item_id,item_name,trans_number,quantity,unit_price FROM item_transation_tbl,items_tbl where item_transation_tbl.item_id = items_tbl.id AND trans_number='.$inv[0]->trans_number);
    $result = $query->getResult();
    foreach($result as $itm){
         $query2 = $db->query('SELECT type_name,amount FROM ledger_transaction_tbl,account_types_tbl where ledger_transaction_tbl.ledger_type = account_types_tbl.id AND (ledger_type = 3 OR ledger_type = 4) AND trans_no='.$inv[0]->trans_number);
         $result2 = $query2->getResult();
        ?>
     <tr>
         <td><?= $itm->item_id; ?></td>
         <td><?= $itm->item_name; ?></td>
         <td></td>
         <td><?= $itm->quantity; ?></td>
         <td><?= $itm->unit_price; ?></td>
         <td><?= $result2[0]->amount; ?></td>
         <td><?= $result2[0]->type_name; ?></td>
         <td><a href="javascript:void(0)" onclick="delete_item()"  class="btn-danger btn-sm"><i class="fa fa-trash"></i></a></td>
         <td></td>
     </tr>
<?php } ?>

