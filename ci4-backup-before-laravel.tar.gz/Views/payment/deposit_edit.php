   <?php
 $bmodel = new App\Models\BillingModel();
  $cmodel = new App\Models\ClassesModel();

  $ctype= $bmodel->get_table_details('name_type_tbl');
  $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$deposit[0]->trans_number,'trans_type' =>3));
  $invoice_type = $bmodel->get_item_join_table($deposit[0]->trans_number);
  $student_name = "";
  $name_type = "";
if(count($leger_transaction) > 0){
    $amount = $leger_transaction[0]->amount;
    if($leger_transaction[0]->name_type_id == 4){
        $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $itm_details = $bmodel->get_item_name('item_transation_tbl',$where = array('trans_number' =>$recpt[0]->trans_number));
    }
    else if($leger_transaction[0]->name_type_id == 3){
        $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2));
   }else if($leger_transaction[0]->name_type_id == 1){
        $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name1 = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
         $type_name2 = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[1]->name_type_id));
        $name_type = $type_name1[0]->name_type;
        $name_type2 = $type_name2[0]->name_type;
        
        $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$deposit[0]->trans_number,'ledger_type'=> 13,'trans_type' =>3));
   }
    $control_no = $bmodel->get_item_name('payment_request',$where = array('student_id' =>$app[0]->id));
    if(count($control_no) > 0){
    $control_number = $control_no[0]->reference_no;
    }
    $company_reg = $bmodel->get_table_details('company_tbl');
 //   $pay_dtls = $bmodel->get_item_name('payment_response',$where = array('reference_no' =>$control_number));
   // echo $leger_transaction[0]->name_id;
   // echo "</br>";
   $name_type_id= $leger_transaction[0]->name_type_id;
   $student_id= $leger_transaction[0]->name_id;
   $name_type_id2= $leger_transaction[1]->name_type_id;
   if($leger_transaction[1]->name_type_id==5){
     $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[1]->name_id));
        $student_name2 = $app[0]->first_name.' '.$app[0]->last_name; 
   }else{
    $student_name2 = $student_name;
   }
   // $inv_no = $bmodel->get_item_name('transactions_relation',$where = array('receipt_trans_no'=>$leger_transaction[0]->trans_no));
   // $invo=$inv_no[0]->invoice_trans_no;
   // $rct=$deposit[0]->trans_number;
}
 $total = 0;
$i=0;
foreach($ledger_invoice as $itm){
    $total+=$itm->amount;

  }
  //echo $total;
       $dbname=session()->get('db_name');
        $db = \Config\Database::connect($dbname);
        // $query = $db->query('SELECT * FROM ledger_transaction_tbl WHERE ledger_id = 6 AND ledger_type = 7 AND trans_type = 1 AND transation_nature = 2 AND name_type_id = 1');
        //    $resulted = $query->getResult();
        //     foreach($resulted as $rs){
        //      //echo $rs->trans_no.'</br>';
        //      $trans_date = '2023-01-09 08:00';
               
        //         $upup = $bmodel->updateUpdate($rs->trans_no,$trans_date);
               
        //     }

      $query = $db->query('SELECT amount,account_name,accounts_tbl.id FROM ledger_transaction_tbl,accounts_tbl where ledger_transaction_tbl.ledger_id = accounts_tbl.id AND transation_nature = 2 AND trans_type=3 AND trans_no="'.$deposit[0]->trans_number.'"');
                     $result = $query->getResult();
                     $paytotal = 0;
                     foreach($result as $rsl){
                   $accounted=$rsl->account_name;
                   $ac_id=$rsl->id;
                  // echo $accounted;
                     }
   ?>
    <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="card">
                            <div class="card-header"  style="height:5px">
                                <h3 class="card-title">Edit Deposit Details</h3>
                                <div class="card-options">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                                <hr>
                            <div class="card-body">
                                <form class="form-horizontal" id="depositform" onsubmit="event.preventDefault();">
                                    <div id="feedback"></div>
                                   <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Deposit Date</label>
                                            <div class="col-sm-8">
                                              <input type="date" id="invoice_date" name="invoice_date" value="<?php echo date('Y-m-d',strtotime($deposit[0]->trans_date));?>" class="form-control">
                                            </div>
                                          </div>
                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Deposited By<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                               <select class="form-control" name="paid_by" id="paid_b">
                                                   <option value="<?=$name_type_id2;?>" selected><?php echo $name_type2;?></option>
                                                    <option value="1">Student</option>
                                                    <option value="5">Parent/Guardian</option>
                                                </select>
                                            </div>
                                          </div>
                                         <!-- <input type="hidden" name="paid_by" value="1"> -->
                                          <div class="form-group row" id="payer_name_row" style="">
                                            <label for="payerame" class="col-sm-4 col-form-label">Name<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                                <div class="input-group mb-3">
                                                    <input type="hidden" id="payer_id1" name="payer_id" value="">
                                                    <input type="text" class="form-control" name="payer_name" id="payer_name1"  value="<?=$student_name2;?>" placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2">
                                                    <button class="btn btn-outline-primary" type="button" id="button-addon3" onclick="search_payer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                          </div>
                                          <div id="payer_details"></div>
                                         <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Customer Type<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                               <?php
                                                    $ctype= $bmodel->get_table_details('name_type_tbl');
                                                  ?>
                                                <select class="form-control" name="customer_typ" id="customer_typ2">
                                                     <option value="<?=$name_type_id;?>"><?=$name_type;?></option>
                                                    <?php foreach($ctype as $type): ?>
                                                    <option value="<?= $type->id ?>"><?= $type->name_type; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                          </div>
                                          <div class="form-group row" id="select_invoice1" style="">
                                            <label for="payerame" class="col-sm-4 col-form-label">Select Customer<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" name="customer_name or Id"  id="customer_name1" placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2" value="<?=$student_name;?>">
                                                    <button class="btn btn-outline-primary" type="button" id="button-addon2" onclick="search_customer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                          </div>
                                        <div id="customer_details"></div>
                                    </div>   
                                    <div class="col-md-6">
                                       <div id="customer_loaded"></div> 
                                       <div id="Name_loaded"></div>
                                       <div id="Invoice_loaded"></div>
                                    </div>
                                </div>
                                 <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Charged Items<span class="text-danger">*</span></label>
                            <div class="col-sm-6">
                            <select class="form-select form-control" id="js-example-data-ajax" style="width:100%;height: 15px;"></select>
                        </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"></div>
                            <div class="col-md-9">
                                <div class="card">
                                    <p Class=" d-flex justify-content-center mt-3">CHARGED ITEMS</p>
                                    <table class="table table-hover table-vcenter mb-0 text-nowrap" id="table">
                                    <thead>
                                            <tr>
                                                <th>No#</th>
                                                <th>Item Name</th>
                                                <th>Attribute</th>
                                                 <th>Size</th>
                                                <th>UOM</th>
                                                 <th>Qty</th>
                                                <th>Price</th>
                                                
                                                <th>Total</th>
                                                <th>Action</th>
                                            </tr>
                                    </thead>
                                    <tbody id="show_item">

                                        <div  class="cust_popup" id="cash" style="display: none">
                                    <h6>Change price</h6>
                                <div id="prcres"></div>
                                </div>
                            
                                    </tbody>
                                    </table>
                                    <table>
                                        <tr>
                                        <th class="col-sm-8"></th>
                                        <th colspan=5 id="totalp">
                                        <!-- <span id="totalp" style="margin-left:400px;"></span> -->
                                        </th>
                                        </tr>
                                        </table>
                                </div>
                                </form>
                            </div>
                        </div><br>
        <!-----------*******************************----------------------------------------------------------------------------->
                          <?php
                                    $acc = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 9));
                                ?>
                                
                                <div  class="cust_popup" id="cash_pop" style="display: none">
                                   <div id="resultshere"></div>
                               </div>  
                                <hr>
                                <div class="row">
                                    <!-- <div class="col-md-6">
                                     
                                     <button type="button" class="btn btn-primary" onclick="tg_patacct()"  >Account</button>
                                   <button type="button" class="btn btn-primary">Cheque</button>
                                    </div> -->
                                    <div class="col-md-12">
                                        <form id="payment_panel">
                                            <?php foreach($acc as $ap):?>
                                                  <div class="form-group row" id="ledgerRow<?= $ap->id?>" style="display: none;" >
                                                    <label for="staticEmail" class="col-sm-1 col-form-label"><?= $ap->id; ?> </label>
                                                    <label for="staticEmail" class="col-sm-3  col-form-label"><?= $ap->account_name; ?> Ledger</label>
                                                    <div class="offset-md-6 col-sm-1">
                                                      <input type="text" readonly class="form-control-plaintext" id="ledger_payed<?= $ap->id?>" value="900">
                                                    </div>
                                                    <div class="col-sm-1">
                                                        <div id="legerRata<?= $ap->id?>">
                                                        </div>    
                                                        <label style="margin-top: 10px;"><i  onclick="removePayment('<?= $ap->id?>')" class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="delete"></i></label>
                                                    </div>   
                                                   </div>
                                            <?php endforeach; ?>
                                             <div class="form-group row"  >
                                                <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label">Amount Due</label>
                                                <div class="offset-md-6 col-sm-1">
                                                  <input type="text" readonly class="form-control-plaintext" id="amount_due" value="0">
                                                </div>
                                                <div class="col-sm-1">
                                                </div>   
                                              </div>
                                           <!--  <div class="form-group row" style="display: none;" id="change_row" >
                                                <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label">Change</label>
                                                <div class="offset-md-6 col-sm-1">
                                                  <input type="text" readonly class="form-control-plaintext" id="amount_change" value="">
                                                </div>
                                                <div class="col-sm-1">
                                                </div>   
                                              </div>
                                         -->
                                        </form>       
                                    </div>
                                    <div class="col-md-2">
                                         <button type="button" class="btn btn-primary pull-left" onclick="tg_dep()"> Add Payment</button>
                                     </div>
                                </div> <br><br><br>
        <!---------------------------------------------------------------------------------------->
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-8">
                               
                                <button type="submit" id="admit_student" onclick="send_deposit()" class="btn btn-primary float-right">Update</button>
                            </div>
                        </div>
                        
                            </div>
                        </div>

    <script type="text/javascript">
     var hold_selected_items = []; // hold all selected items
     var item_list = [];
     selectedDeposit();
     ids=<?php echo $student_id;?>;
     trans="<?php echo $deposit[0]->trans_number;?>";
    $(document).ready(function(){
         
         $('#js-example-data-ajax').select2({
            ajax: {
                url: "<?php echo base_url() . '/index.php/AccomodationController/load_diposit_data'; ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

        $('#js-example-data-ajax').on('select2:select', function (e) {
            selectedItems();
        });
        //var prc; 
        function selectedItems(){  
            var rows = '';
           var itemData = 'item_selected='+$('#js-example-data-ajax').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Accomodationdata1')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }else{
                        var len  = data.length;
                        
                        for (var i = 0; i <len; i++ ){
                            hold_selected_items.push(data[i]['id']);// push all selected items
                            var prc = data[i]['iprice'];
                            price= prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
                            var name = data[i]['iname'];
                            var size = data[i]['isize'];
                            var attribute = data[i]['iattribute'];
                            var iid = data[i]['id'];
                            //var qty = window.prompt("Enter quantity");
                            //var tprice = qty*prc;
                           
                            
                            rows += '<tr id="table_row'+ iid +'">';

                           rows+='<td><input type="hidden" name="iid[]" value="'+iid+'">'+ iid +'</td>';
                             rows+='<td><input type="hidden" name="price'+iid+'" value="'+prc+'">'+ name +'</td>';
                            //rows += '<td>'+ name +'</td>';
                            rows += '<td>'+ attribute +'</td>';
                            rows += '<td>'+ size +'</td>';
                            rows += '<td>'+ 1 +'</td>';
                            rows += ' <td><input type="hidden" name="prco'+iid+'" id="prco'+iid+'" value="'+prc+'">'+1+'</td>';
                            rows += '<td><a class="cost2" id="cost' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getid(' +iid+ ','+prc+')"><input type="text" value="'+prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" id="prc'+iid+'" readonly></a>\
                        </td>';
                            rows += '<td class="text-right" style="text-align:right" id="total'+iid+'">'+prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>';
                            
                            //rows += '<td><input type="text" name="tprice" id="tprice'+iid+'" style="width:85px; border:none; background-color:rgb(240,240,240)" readonly></td>';
                            rows += '<td><a href="javascript:RemoveSelectItemRow('+iid+','+i+');" class="btn btn-danger btn">X</a></td>';
                            
                            rows += '</tr>';
                            $('#show_item').append(rows);
                        }
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }
                
           });  
        }

    });
    var sumVal=0;   
function getid(id,prc) {
     $('#cash').toggle(100);
      
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/priceview'; ?>",
            beforeSend: function () {
                $('#prcres').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#prcres').html(result);
                console.log(prc);
             document.querySelector('[id="cash_amt"]').value = prc;
             document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }
       function savebtn(){
    // alert('yes');
        totalsum=0;
      var cash=$('#cash_amt').val();
      var item_id=$('#item_id').val();
     // alert(item_id); 
      for( var i = 0; i < hold_selected_items.length; i++){ 
           id1=hold_selected_items[i];
           if(id1==item_id){
            var cashAmt =parseInt(cash);
            document.querySelector('[id="prco'+id1+'"]').value = cashAmt;
            document.querySelector('[id="prc'+id1+'"]').value = cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            document.getElementById("total"+id1).innerHTML = cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

           // $('#cost'+id1+'').append(cashAmt);
           }else{
            var cashAmt1 =$('#prc'+id1+'').val();
            let result = cashAmt1.replace(/,/gi, "");
        
            var cashAmt =parseInt(result);
           // alert(cashAmt);
           }
       
        totalsum=totalsum+cashAmt;
        }       
          $('#cash').hide(); 
             document.getElementById("totalp").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
             $('#amount_due').val(totalsum.toLocaleString()); 
            return totalsum;       
         e.preventDefault(); 
    }
    function manage_invoice(inv){
        // alert(inv)
      // $('#viewinvoice').modal('show'); 
       $('#viewinvoice_content').load('view_invoice/'+inv);
    }

    function edit_invoice(invID){
        $('#view_details').load('invoice_details/'+invID);
    }

    function invoice_print(){
        $('#invoiceprint').modal('show');
    }
    // $('#invoicePrint_content').load('print_invoice/'+inv);

    function printable_rept(area) {
       // alert('yy');
         var _c = $('#att-list').html();
        var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=800,height=600')
        nw.document.write(_c)
        nw.document.write('<html><head><title>MHI</title><link rel="stylesheet" href="<?php echo base_url() . 'syst_assets/'; ?>bootstrap/css/bootstrap.css">')
        nw.document.write(ns.html())
        //nw.document.close()
        nw.print()
    }

    function invoice_receipt(student_id,trans_no){

        // window.location.href = `http://localhost/econnect/receipt`
        
        // window.location.href= "<?php echo base_url() . '/receipt'; ?>" + "?id="+student_id;
        window.location.href= "<?php echo base_url() . '/index.php/BillingController/invoice_receipt'; ?>/"+student_id+"/"+trans_no;

        // prepare_invoice_student(student_id);

    }
 $("#paid_by").change(function(){
        $('#payer_name_row').show();
        $('#payer_details').html('');
    });
    $("#customer_type").change(function(){
        $('#select_invoice').show();
        if($(this).val() == 4){
            $('#applicationlist').show();
            $('#invoicelist').hide();
        }else{
           $('#invoicelist').show(); 
           $('#applicationlist').hide();
        }
    });
    function search_payer(){
       if($('#paid_by').val() == "") {
           swal("warning","Please Select Paid By","warning");
       }else if($('#payer_name').val() == ""){
          swal("warning","Please Enter Payer Name","warning"); 
       }else{
            var paydata = 'paid_by=' + $('#paid_by').val() + "&payer_name=" + $('#payer_name').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/search_payer'; ?>',
                beforeSend: function () {
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#customer_loaded').html(result); 
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
       
    }
    var ids;
    function select_payer(id,nametype,payer_name){
       
       var payer = nametype +'_' +id;
        $('#payer_id').val(payer);
        var payerdata = "payer=" + payer;
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillingController/get_payer_details'; ?>',
            data: payerdata,
            success: function (res) {
               
                $('#payer_details').html(res);
                $('#payer_name_row').hide();
                $('#customer_loaded').html('');

            },
            error: function (){
                alert('error encounted');
            }
        });
    }
//     $(document).ready(function(){
   
//     // code to read selected table row cell data (values).
//     $("#table").on('click','.btn',function(){
         
//          var currentRow=$(this).closest("tr"); 
         
//          var col1=currentRow.find("td:eq(7)").text(); 
//           //sum=totalAmounts();
//           //sum=sumval;
//          var data=col1;
//          //alert(data);
//         sumVal=sumVal-data;
//         document.getElementById("totalp").innerHTML = "Total = " + sumVal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
//          console.log(sumVal);
         
//     });
// });
    function RemoveSelectItemRow(item_id){
        var p= $("#prco"+item_id+"").val();
       // alert(p);
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }
         $('#table_row'+item_id).remove();
        
        totalsum=totalsum-p;
         document.getElementById("totalp").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            //return totalsum;       
         e.preventDefault();
       
    }
// $("#account").change(function(){
//     var items="";
//     var accounts=$('#account').val();
//     var amount_ttl=sumVal;
//     //alert("acc= "+accounts+"ttl="+amount_ttl);
//     items = {account_receivable: accounts, amount: amount_ttl};
//     receivable_total_balance.push(items);
//     alert(items);
//     });

   function send_deposit(){
   //$('#finishReceipt').prop("disabled", true);
        var allvariables2 = $("#depositform").serialize() + '&sid='+ids + '&'+ $("#payment_panel").serialize()+'&'+$("#header_form").serialize()+'&trans='+trans;
        alert(allvariables2);
        $.ajax({
            beforeSend: function () {
                  $('#admit_student').prop("disabled", true);
                  $('#feedback').append('<div class="alert alert-primary alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button><i class="fa fa-spinner fa-spin"></i>Preparing Control Number Please wait..</div>');
            },
            type: 'POST',
         //   url: 'save_invoice_created/'+ids,
         url: '<?php echo base_url() . '/index.php/AdmissionController/update_deposit_transaction/'; ?>'+ids,
            data: allvariables2,
            success:function(res){
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#admit_student').prop("disabled", false);
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button> New deposit not created successfully</div>');
                }
            },
            error:function(res){
                $('#admit_student').prop("disabled", false);
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt create New Deposit.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
            }
        });

        e.preventDefault();
    }
   // function clicked(id){
   //  alert("yes welcome");
   //   alert($(this).serialize());

   // }

   function search_customer(){
       if($('#customer_type').val() == "") {
           swal("warning","Please Select Customer Type","warning");
       }else if($('#customer_name').val() == ""){
          swal("warning","Please Enter Customer Name","warning"); 
       }else{
            var paydata = 'type=' + $('#customer_type').val() + "&cust_name=" + $('#customer_name').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/search_customer_invoice'; ?>',
                beforeSend: function () {
                    $('#Name_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#Name_loaded').html(result); 
                },
                error: function () {
                    $('#Name_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
          }
     function prepare_invoice_student(id){
         ids=id;
        var paydata = 'type=' + $('#customer_type').val()+'&id=' + id;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/loadCustomer'; ?>',
                beforeSend: function () {
                    $('#Invoice_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (res) {
               
                $('#customer_details').html(res);
                $('#select_invoice').hide();
                $('#Name_loaded').html('');
                $('#Invoice_loaded').html('');
            },
            error: function (){
                alert('error encounted');
            }
      });
    }
    
     
    $(document).ready(function(){
   
    // code to read selected table row cell data (values).
    $("#table").on('click','.btn',function(){
         
         var currentRow=$(this).closest("tr"); 
         
         var col1=currentRow.find("td:eq(7)").text(); 
          sumVal=totalAmounts();
          //sum=sumval;
         var data=col1;
         sumVal=sumVal-data;
         //remain=sum;
         //alert(remain);
        // document.getElementById("remained").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         document.getElementById("totalp").innerHTML = "Total = " + sumVal;
         console.log(sumVal);
         
    });
});
     var total=0;
    
    function totalAmounts(id){
        $('#ttl' + id).empty();
        var prc = $('input[name=price' + id+']').val();

        var qty = $('input[name=quantity' + id+']').val();
        var calc = prc*qty; 
        
            
            $('#ttl' + id).append(calc);
            
            var table = document.getElementById("table"), sumVal=0;
            
            for(var i = 1; i < table.rows.length; i++)
            {
                sumVal = sumVal + parseInt(table.rows[i].cells[7].innerHTML);
            }
            //remain=sumVal;
            document.getElementById("totalp").innerHTML = "Total = " + sumVal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(sumVal);
            return sumVal;
    }
resetReceiptData();
   function resetReceiptData(){
        $('#payer_details').empty();
        $('#payer_name').val('');
        $('#account').val('');
        $('#paid_by').val('');
        $('#customer_type').val('');
         $('#customer_name').val('');
        $('#select_invoice').hide();
        $('#customer_loaded').empty();
        $('#Name_loaded').empty();
        $('#Invoice_loaded').empty();
        $('#itm_invoice1').empty();
        $('#itm_invoice').empty();
        $('#amount_due').val(0);
   }
     function tg_cash() {
        $('#cash_pop').toggle(100);
    }
      $('#admit_student').prop("disabled", true);
    function csh_proc1() {
       // totalsum=0;
       // alert(totalsum);
        //return 1;
         var cashAmt = parseInt($('#cash_amt1').val());
        // var change;
        amountdue = totalsum - cashAmt;
        totalsum=amountdue;
         var ledger = $('#ledger option:selected').val();
         item_list.push(ledger);
            $('#ledgerRow'+ledger).show();
             $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
             var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" id="amount'+ledger+'" name="amount'+ledger+'" value="'+ cashAmt +'">';
            $('#legerRata'+ledger).append(data);
             $('#amount_due').val(amountdue.toLocaleString()); 
             if (amountdue == 0) {
            $('#admit_student').prop("disabled", false);;
        } else {
            $('#admit_student').prop("disabled", true);;
        }

        // if(amountdue >= 0){
        //     $('#change_row').hide();
        //    $('#amount_due').val(amountdue.toLocaleString()); 
        // }else{
        //    change = amountdue * -1;
        //    amountdue = 0;
        //    $('#amount_due').val(amountdue);
        //    $('#change_row').show();
        //   // $('#amount_change').val(change.toLocaleString());
        // }
       // amountpayed += cashAmt;
       // AmtCalc();
        tg_cash();
           console.log(totalsum);
         e.preventDefault();
    };
    function removePayment(lg){
        var amount=parseInt($('#amount'+lg).val());
        //alert(totalsum);
        //amountdue = total;
        totalsum=amountdue;
        //alert(amount);
        $('#amount_due').val(amountdue.toLocaleString()); 
       $('#ledgerRow'+lg).hide();
       $('#ledger_payed'+lg).html('');
       $('#legerRata'+lg).html('');
       
        
             if (amountdue == 0) {
            $('#admit_student').prop("disabled", false);
        } else {
            $('#admit_student').prop("disabled", true);
        }
       // AmtCalc();
    }
      
    function tg_dep() {
     $('#cash_pop').toggle(100);
      
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/discountView'; ?>",
            beforeSend: function () {
                $('#prcres').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#resultshere').html(result);
               // console.log(prc);
             //document.querySelector('[id="cash_amt"]').value = prc;
             //document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }
          $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });
   $('#Rept1Result').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#receipt').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn span').html();
           // alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/deposit2'; ?>',
                  url: "<?php echo base_url() . '/index.php/BillingController/deposit2'; ?>",
                data: dta,
                success: function (res) {
                    $('#receipt').html(res);
                },
                error: function () {
                    $('#receipt').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });
  
 function selectedDeposit(){  
    //alert('gogo');
            var rows = '';
           var itemData = 'item_selected='+2;
           var trans="<?php echo $deposit[0]->trans_number;?>";
           //alert(trans);
           $.ajax({  
                method:"POST", 
                 url: "<?php echo base_url() . '/index.php/AccomodationController/load_deposit_data'; ?>/"+trans,
               // url:"<?= base_url('/load_Accomodationdata1')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }else{
                        var len  = data.length;
                        
                        for (var i = 0; i <len; i++ ){
                            hold_selected_items.push(data[i]['id']);// push all selected items
                            var prc = data[i]['iprice'];
                            price= prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
                            var name = data[i]['iname'];
                            var size = data[i]['isize'];
                            var attribute = data[i]['iattribute'];
                            var iid = data[i]['id'];
                            //var qty = window.prompt("Enter quantity");
                            //var tprice = qty*prc;
                           
                            
                            rows += '<tr id="table_row'+ iid +'">';

                           rows+='<td><input type="hidden" name="iid[]" value="'+iid+'">'+ iid +'</td>';
                             rows+='<td><input type="hidden" name="price'+iid+'" value="'+prc+'">'+ name +'</td>';
                            //rows += '<td>'+ name +'</td>';
                            rows += '<td>'+ attribute +'</td>';
                            rows += '<td>'+ size +'</td>';
                            rows += '<td>'+ 1 +'</td>';
                            rows += ' <td><input type="hidden" name="prco'+iid+'" id="prco'+iid+'" value="'+prc+'">'+1+'</td>';
                            rows += '<td><a class="cost2" id="cost' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getid(' +iid+ ','+prc+')"><input type="text" value="'+prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" id="prc'+iid+'" readonly></a>\
                        </td>';
                            rows += '<td class="text-right" style="text-align:right" id="total'+iid+'">'+prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>';
                            
                            //rows += '<td><input type="text" name="tprice" id="tprice'+iid+'" style="width:85px; border:none; background-color:rgb(240,240,240)" readonly></td>';
                            rows += '<td><a href="javascript:RemoveSelectItemRow('+iid+','+i+');" class="btn btn-danger btn">X</a></td>';
                            
                            rows += '</tr>';
                            $('#show_item').append(rows);
                        }
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }
                
           });  
        }
        appendRow();
     function appendRow(){
      var cashAmt = <?php echo $total; ?>;

        var change;
        amountdue =0;
        var ledger = <?=$ac_id;?>;
            $('#ledgerRow'+ledger).show();
            $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
            var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" name="amount'+ledger+'" value="'+ cashAmt +'">';
           // $('#legerRata'+ledger).append(data);
        if(amountdue >= 0){
            $('#change_row').hide();
           $('#amount_due').val(amountdue.toLocaleString()); 
        }else{
           change = amountdue * -1;
           amountdue = 0;
           $('#amount_due').val(amountdue);
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
       // amountpayed += cashAmt;
        //AmtCalc();
        //tg_cash();
       
        //e.preventDefault();  
    }
  </script>