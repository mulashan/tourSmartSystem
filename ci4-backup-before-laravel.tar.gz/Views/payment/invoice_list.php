<div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>Invoice Type</th>
                                    <th>Invoice No.</th>
                                    <th>Invoice Date</th>
                                    <th>Customer Type</th>
                                    <th>Student Name</th>
                                    <!-- <th>Student Reg No</th> -->
                                    <!-- <th>Class</th> -->
                                    <th>Control No.</th>
                                    <th>Control Type</th>
                                    <th>sms Status</th>
                                    <th>Amount</th>
                                     <th>Trans By</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                               
                                $amodel = new App\Models\AdmissionModel();
                                $bmodel = new App\Models\BillingModel();
                                $smodel = new App\Models\StudentModel();
                               $account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 7));

                                $dbname=session()->get('db_name');
                                $db = \Config\Database::connect($dbname);
                                //print_r($trans);return;
                                    foreach($trans as $s){
                                     $by = $bmodel->get_item_name('users',$where = array('user_id' =>$s->updated_by));

                                    $invoice_type = $bmodel->get_item_join_table11($s->trans_number,1);
                                    $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type'=>1));
                                     //print_r($leger_transaction);
                                    $student_name = "";
                                    $control_number = "";
                                    $class_name = "";
                                    $stream_name = "";
                                    $name_type = "";
                                    $totalAmount =0;
                                    $amount=0;
                                   // print_r($leger_transaction);
                                    if(count($leger_transaction) > 0){
                                        // $totalAmount +=$leger_transaction[0]->amount;
                                        // $amount = $bmodel->get_total_amount($leger_transaction[0]->name_id,$leger_transaction[0]->trans_no);
                             $ledgeramount = $bmodel->get_item_name('item_transation_tbl', $where = array('trans_number' => $leger_transaction[0]->trans_no,'trans_type'=>1));
                                        foreach ($ledgeramount as $a) {
                               $item = $bmodel->get_item_name('items_tbl', $where = array('id' => $a->item_id));
                                            $amount = $a->quantity * $a->unit_price;
                                             if($item[0]->item_group==7){
                                            $totalAmount -= $amount;
                                        }else{
                                           $totalAmount += $amount;  
                                        }
                                        }

                                        if($leger_transaction[0]->name_type_id == 4){
                                            echo $leger_transaction[0]->name_id;
                                            echo '<br>';
                             $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                      $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name;  
                                            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                            $name_type = $type_name[0]->name_type;
                                             $class_data = $bmodel->get_class_data($leger_transaction[0]->name_id, esc($year));
                                            if($class_data>0){
                                                $class_name = $class_data[0]->class_name .'('.$class_data[0]->stream_name .')'; 
                                            
                                            }

                                        }else if($leger_transaction[0]->name_type_id == 1){
                                            $admn = $bmodel->get_item_name('students', $where = array('id'=>$leger_transaction[0]->name_id));
                                            if(count($admn)>0){
                                            $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name;
                                            $class_data = $bmodel->get_class_data($leger_transaction[0]->name_id, esc($year));
                                            // print_r($year);
                                            // return;
                                            if(isset($class_data) && !empty($class_data)){
                                                $class_name = $class_data[0]->class_name .'('.$class_data[0]->stream_name .')';   
                                            }
                                            $student_id=$admn[0]->id;
                                            }else{
                                                echo $leger_transaction[0]->name_id;
                                                $student_id="";
                                            }
                                          }else if($leger_transaction[0]->name_type_id == 6){
                                            $admn = $bmodel->get_item_name('other_students_tbl', $where = array('id'=>$leger_transaction[0]->name_id));
                                            $student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name;
                                            $class_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name;
                                            $student_id=$admn[0]->id;
                                             $class_data = $bmodel->get_class_data($leger_transaction[0]->name_id, esc($year));
                                            if($class_data>0){
                                                $class_name = $class_data[0]->class_name .'('.$class_data[0]->stream_name .')'; 
                                            }
                                          }
                                            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                            $name_type = $type_name[0]->name_type;

                                            $cnumber = $bmodel->get_item_name('payment_request', $where = array('student_id'=>$leger_transaction[0]->name_id,'trans_no'=>$s->trans_number)); 

                                             $ctype="";
                                            if(count($cnumber) > 0){
                                                $control_number = $cnumber[0]->reference_no;

                                                if($cnumber[0]->allow_partial==0){
                                                    $ctype="FIXED";
                                                }else{
                                                   $ctype="FLEXIBLE";  
                                                }
                                            }
                                        
                                    }
                                        
                                        
                                    
                             $msg_status = $bmodel->get_item_name('message_groups_tbl', $where = array('trans_number' => $s->trans_number,'message_type'=>1));
                                     if(count($msg_status)>0){
                                         $msg_st = $bmodel->get_item_name('messages', $where = array('send_no' => $msg_status[0]->send_number));
                                         
                            if(count($msg_st)>0){

                        ///here we go
                      if($msg_st[0]->time_sent==null && $msg_st[0]->message_id!=""){
                             $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_RETURNTRANSFER => 1,
                        CURLOPT_URL => 'http://www.sms.co.tz/api.php?do=dlr&id=' . $msg_st[0]->message_id . '&username=' . SMS_UNAME . '&password=' . SMS_PASSWORD . '&senderid=' . SENDER_ID . '',
                    ));
                    $msg_status = curl_exec($curl);
                    // echo $msg_status;
                    if($msg_status != ""){

                       list($sntdate, $stts, $deldate) = explode(',', $msg_status);

                       $tempsmsdata = array(
                           'sent_status' => 2, //Sent and delivered
                           'time_sent' => $sntdate,
                           'status_description' => $stts,
                           'time_delivered' => $deldate
                       );
                       //print_r($tempsmsdata);
                        $smodel->update_table_details('messages',$where = array('message_id' => $msg_st[0]->message_id),$tempsmsdata);
                        // echo 'updated';
          
                      }
                                }
                        
                                            ?>
                                         <!-- <script type="text/javascript">
                                        
                                             $(function() {
                                         check_sms('<?php echo $msg_st[0]->message_id;?>');
                                              });
                                         </script> -->
                                         <?php
                                          $msg_s = $bmodel->get_item_name('messages', $where = array('message_id' => $msg_st[0]->message_id));

                                         $del=$msg_s[0]->status_description;
                                         $time=$msg_s[0]->time_delivered;
                                         $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                                     }else{
                                         $stata='<span style="color:red">Not Sent'; 
                                     }
                                     }else{
                                       $stata='<span style="color:red">Not Sent';  
                                     }

                                     $debit = $db->query('SELECT sum(balance) as balance  FROM  ledger_transaction_tbl  
                                                            WHERE name_id = '.$student_id.' AND trans_no = '.$s->trans_number.' AND ledger_type = 7 and name_type_id ='.$type_name[0]->id.' AND transation_nature = 2 and trans_type = 1'); 
                                     $debit_total = $debit->getResult(); 
                                    // print_r($debit_total);
                                     
                                    $diff = $debit_total[0]->balance; 

                                    if($diff > 0){
                                        $status = "<b style='color:green;'>open</b>";
                                         }else { 
                                            $status = "<b style='color:red;'>Closed</b>";
                                     }
                                    ?>
                                
                                <tr>
                                    <td><?php echo $invoice_type[0]->type_name??"";?></td>
                                    <td><?php echo $s->trans_number;?></td>
                                    <td><?php echo $s->trans_date ;?></td>
                                    <td><?php echo $name_type;?></td>
                                    <td><?php echo $student_name;?></td>
                                    <!-- <td><?php //echo $class_name;?></td> -->
                                    <td><?= $control_number;?></td>
                                    <td><?= $ctype;?></td>
                                    <td><?= $stata;?></td>
                                    <td><?= number_format($totalAmount); ?></td>
                                     <td><?=  $by[0]->first_name.' '.$by[0]->last_name; ?></td>
                                    <td><?= $status; ?></td>
                                    <td>
                                        <a href="javascript:void(0)"  class="btn btn-primary btn-sm invoiceprint" data-bs-toggle="modal" data-bs-target="#invoiceview" onclick="edit_invoice('<?php echo $s->id . '/' . $year; ?>')"><i class="fa fa-edit"></i> Edit</a>
                              <a href="javascript:void(0)" 
   class="btn btn-primary btn-sm invoiceprint" 
   data-bs-toggle="modal" 
   data-bs-target="#viewinvoice" 
   onclick="manage_invoice('<?php echo $s->id . '/' . $year; ?>')">
   <i class="fa fa-eye"></i> View
</a>


                                       
                                    </td>
                                    
                                </tr>
                          
                            <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <script type="text/javascript">

            function check_sms(msgid){
                //alert(msgid);
            var data = "id=" + msgid;
              $.ajax({
            type: 'POST',
          url: '<?php echo base_url() . '/index.php/SystemController/check_sms/'; ?>'+msgid,
            data: data,
            success: function (res) {
            
              
            },
            error: function (){
                alert('error encounted');
            }
        });
            }
                    $('#myTable').DataTable();

         function delete_invoice(inv_id){
           // alert(inv_id);
         swal({
            title: "Delete Invoice",
            text: 'Are you sure?',
           
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Ok",
            cancelButtonText: "Cancell",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
            var data = 'inv_id=' + inv_id+'&'+$("#header_form").serialize(); 
          //  alert(data);
              $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/AdmissionController/delete_invoice'; ?>',
            data: data,
            success: function (res) {
              var data = JSON.parse(res);
              if(data['status'] == "1"){
            swal("Deleted successfuly");
             location.reload();
            }
            },
            error: function (){
                alert('error encounted');
            }
        });
            } else {
              swal("Cancelled");
            }

          });
                    }
                </script>