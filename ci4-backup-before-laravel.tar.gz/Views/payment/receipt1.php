
<?php
   $bmodel = new App\Models\BillingModel();
   $ctype= $bmodel->get_table_details('name_type_tbl');
   // $parent=$bmodel->get_parent($stid);
   $parent=$bmodel->get_item_name('parents_tbl', $where = array('student_id' => $stid, 'bill_account' => 1));
   $student=$bmodel->get_item_name('students', $where = array('id' => $stid));
   $student_name=$student[0]->full_name;
   $parent_name=$parent[0]->first_name." ".$parent[0]->last_name;
   $parent_id = $parent[0]->id;
   $std_id = $student[0]->id;
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Billing</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">Eden Garden</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Receipts</li>
                </ol>
            </div>
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link " id="Class-tab" data-toggle="tab" href="#rcpt-all">Receipts List</a></li>
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#rcpt-add">New Receipt</a></li>
            </ul>
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane  active" id="rcpt-add">
                 <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header"  style="height:5px">
                                <h3 class="card-title">New Receipt</h3>
                                <div class="card-options ">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                                <hr>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Paid By</label>
                                            <div class="col-sm-8">
                                               <select class="form-control" name="paid_by" id="paid_by">
                                                    <option value="">Select Paid By</option>
                                                    <option value="1">Student</option>
                                                    <option value="5">Parent/Guardian</option>
                                                </select>
                                            </div>
                                          </div>

                                          <div class="form-group row" id="payer_name_row" style="display:none;">
                                            <label for="payerame" class="col-sm-4 col-form-label">Payer Name</label>
                                            <div class="col-sm-8">
                                                <div class="input-group mb-3">
                                                    <input type="hidden" id="payer_id" name="payer_id" value="">
                                                    <input type="text" class="form-control" name="payer_name" id="payer_name"   placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2">
                                                </div>
                                            </div>
                                          </div>
                                          <div id="payer_details"></div>
                                         <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Customer Type</label>
                                            <div class="col-sm-8">
                                               <?php
                                                    $ctype= $bmodel->get_table_details('name_type_tbl');
                                                  ?>
                                                <select class="form-control" name="customer_type" id="customer_type">
                                                    <option value="1">Student</option>
                                                </select>
                                            </div>
                                          </div>
                                       
                                        
                                    </div>   
                                    <div class="col-md-6">
                                       <div id="customer_loaded"></div> 
                                      <!--  <div id="Name_loaded"></div>
                                       <div id="Invoice_loaded"></div> -->
                                    </div>
                                </div>
                                 <div class="row">
                                     <div class="col-md-12">
                                         
                                         <br>
                                     </div>
                                 </div> 
                                <hr>
                                <div class="row">
                                    <div class="col-md-12">
                                        
                                        <form id="receipt_form"> 
                                        <div id="invoicelist">
                                            <h6>Invoice List</h6>
                                        <table class="table table-borderless" >
                                            <thead>
                                                <tr>
                                                    <th>Invoice No</th>
                                                    <th>Invoice Date</th>
                                                    <th>Invoice Name</th>
                                                    <th>Invoice Amount</th>
                                                    <th>Amount Due</th>
                                                    <th>Amount To Pay</th>
                                                </tr>
                                            </thead>
                                            <tbody id="itm_invoice">
                                            </tbody>
                                            <tfoot>
                                                <tr id="itm_invoicefooter"></tr>
                                            </tfoot>
                                        </table>
                                        </div>
                                        </form>    
                                    </div>
                                </div>
                               
                                <!-- <div class="row mt-4"> -->
                                <?php
                                    $acc = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 9));
                                ?>
                                <div class="cust_popup" id="account" style="display: none">
                                    <form method="POST" id="acct_proc">
                                        <b>CHARGE ACCOUNT</b><i style="color: red" id="saveError"></i><br/>
                                        ACCOUNT NAME
                                        <input class="form-control" id="acc_name" type="text" onkeyup="SearchAccount()" autocomplete="off">
                                        <input id="acc_no" type="hidden">
                                        <div id="schResults"></div>
                                        <br>
                                        AMOUNT
                                        <input class="form-control" id="acc_amt" type="number" autocomplete="off"><br>
                                        <button type="submit" id="svAccnt" class="btn btn-primary pull-right">Save</button>&nbsp;
                                    </form>
                                    <button class="btn btn-warning" style="display:none" id="removeAcct">Remove Account</button>
                                    <button class="btn btn-warning" onclick="tg_acct()">Cancel</button>
                                </div>
                                <div  class="cust_popup" id="cash" style="display: none">
                                    <h6>Receive Cash</h6>
                                     <form id="csh_proc" method="POST">
                                         <select class="form-control" name="ledger" id="ledger" required="">
                                             <option value="">Select ledger</option>
                                            <?php foreach($acc as $ac):?>
                                                 <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                             <?php endforeach; ?>
                                         </select><br>
                                         <input class="form-control" name="cash_amt" id="cash_amt" type="number" required="" ><br>
                                         <button class="btn btn-warning" onclick="tg_cash()">Cancel</button>
                                         <button type="submit" class="btn btn-primary pull-right">Save</button>&nbsp;
                                     </form>
                                   <button class="btn btn-sm btn-warning" style="display:none" id="removeCash">Remove Cash</button>&nbsp;
                               </div>  
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                     
                                    </div>
                                    <div class="col-md-12">
                                        <form id="payment_panel">
                                            <?php foreach($acc as $ap):?>
                                                  <div class="form-group row" id="ledgerRow<?= $ap->id?>" style="display: none;" >
                                                    <label for="staticEmail" class="col-sm-1 col-form-label"><?= $ap->id; ?> </label>
                                                    <label for="staticEmail" class="col-sm-3  col-form-label"><?= $ap->account_name; ?> Ledger</label>
                                                    <div class="offset-md-6 col-sm-1">
                                                      <input type="text" readonly class="form-control-plaintext" id="ledger_payed<?= $ap->id?>" value="900">
                                                    </div>
                                                    <div class="col-sm-1">
                                                        <div id="legerRata<?= $ap->id?>">
                                                        </div>    
                                                        <label style="margin-top: 10px;"><i  onclick="removePayment('<?= $ap->id?>')" class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="delete"></i></label>
                                                    </div>   
                                                   </div>
                                            <?php endforeach; ?>
                                             <div class="form-group row"  >
                                                <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label">Amount Due</label>
                                                <div class="offset-md-6 col-sm-1">
                                                  <input type="text" readonly class="form-control-plaintext" id="amount_due" value="0">
                                                </div>
                                                <div class="col-sm-1">
                                                </div>   
                                              </div>
                                            <div class="form-group row" style="display: none;" id="change_row" >
                                                <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label">Change</label>
                                                <div class="offset-md-6 col-sm-1">
                                                  <input type="text" readonly class="form-control-plaintext" id="amount_change" value="">
                                                </div>
                                                <div class="col-sm-1">
                                                </div>   
                                              </div>
                                        </form>       
                                    </div>
                                    <div class="col-md-2">
                                         <button type="button" class="btn btn-primary pull-left" onclick="tg_cash()"> Add Payment</button>
                                     </div>
                                </div> 
                            </div>

                            <div class="card-footer">
                               
                                <button type="button" id="finishReceipt" class="btn btn-primary pull-right" onclick="finish_receipt()">Finish</button>
                            </div>
                        </div>
                    </div>
                </div>
            
        </div>
    </div>
</div>
<div class="modal fade" id="viewreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save</button>-->
      </div>
    </div>
  </div>
</div>
<script>
    $('#rcpt-all').load('receipt');

    var student_id="<?php echo $std_id; ?>";
    var trans_no="<?php echo $tno; ?>";
    prepare_invoice_student(student_id,trans_no);
    var allvariables = "";
    var total=0;
    var amountdue =0;
    var amountpayed =0;
    var item_list = [];
    var k =0;
    var totalinv = 0;
    $('#finishReceipt').prop("disabled", true);
    function manage_receipt(inv){
      $('#viewreceipt').modal('show'); 
      $('#viewreceipt_content').load('view_receipt/'+inv);
    }
    
    
   function tg_cash() {
        $('#cash').toggle(100);
    }
    $("#csh_proc").submit(function (e) {
        var cashAmt = parseInt($('#cash_amt').val());
        var change;
        amountdue = total - cashAmt;
        var ledger = $('#ledger option:selected').val();
            $('#ledgerRow'+ledger).show();
            $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
            var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" name="amount'+ledger+'" value="'+ cashAmt +'">';
            $('#legerRata'+ledger).append(data);
        if(amountdue >= 0){
            $('#change_row').hide();
           $('#amount_due').val(amountdue.toLocaleString()); 
        }else{
           change = amountdue * -1;
           amountdue = 0;
           $('#amount_due').val(amountdue);
           $('#change_row').show();
           $('#amount_change').val(change.toLocaleString());
        }
        amountpayed += cashAmt;
        AmtCalc();
        tg_cash();
       
        e.preventDefault();
    });

    function finish_receipt(){
        var allvariables2 = $("#receipt_form").serialize() + '&bill_payer='+$('#payer_id').val() + '&'+ $("#payment_panel").serialize();
        // alert(allvariables2);
         $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillingController/process_receipt'; ?>',
            data: allvariables2,
            success: function (res) {
              var data = JSON.parse(res);
              if(data['status'] == "1"){
                swal({
                    title: "successful", 
                    text: data['description'], 
                    type: "success"
                  },
                function(){ 
                   // location.reload();
                    window.location.href= "<?php echo base_url() . '/receipt'; ?>"
                }
             );
            }
            },
            error: function (){
                alert('error encounted');
            }
        });
    }
    //here by---------------------------------------------------------------------
    $("#paid_by").change(function(){
      var parent="<?php echo $parent_name; ?>";
      var student="<?php echo $student_name; ?>";

      var pID = '<?php echo $parent_id; ?>';
      var sID = '<?php echo $std_id; ?>';

      var payer = '';

      //alert(student);
        if($(this).val()==1){
            payer = 1 +'_' +sID;
         $('#payer_name').val(student);
         $('#payer_id').val(payer);
          $('#payer_name_row').show();
          $('#payer_details').html('');   
        }else{
            payer = 5 +'_' +pID;
            $('#payer_name').val(parent);
            $('#payer_id').val(payer);
             $('#payer_name_row').show();
             $('#payer_details').html('');
        }
        
        
    });
        
   
    function prepare_invoice_student(student_id,trans_no){ 
           var paydata = 'id=' + student_id+'&trans_no='+trans_no;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/create_invoices_student'; ?>',
                data: paydata,
                success: function (result) {
                    $('#Invoice_loaded').html(''); 
                    var data = JSON.parse(result); 
                    var mydata= Object.keys(data).length;
                    var name_type = $('#customer_type').val() +'_'+ student_id;

                    for( var i = 0; i < mydata; i++){
                        k++;
                        item_list.push(k);
                        var unit_price = parseInt(data[i]['balance']);
                        total += unit_price;
                        var invoice_amount = parseInt(data[i]['amount']);
                        totalinv +=invoice_amount;
                        amountdue = total - amountpayed;
                        var itm = '<tr id="row'+ k +'"><input type="hidden"  name="student[]"  value="'+name_type+'">'+
                                      '<td><input type="hidden"  name="trans_no'+name_type+'" value="'+data[i]['trans_no']+'">' + data[i]['trans_no']  +'</td>'+
                                       '<td>' + data[i]['trans_date']  +'</td>'+
                                       '<td>' + data[i]['full_name'] +'</td>'+
                                       '<td>' + invoice_amount.toLocaleString()  +'</td>'+
                                       '<td>' + unit_price.toLocaleString()  +'</td>'+
                                       '<td><input type="number" class="form-control qty" onkeyup="AmtCalc()" id="amounttopay'+k+'"  value="'+unit_price+'" name="amount'+name_type+'" style="width:100px;"></td>' +
                                       '</tr>';
                               
                       $('#itm_invoice').append(itm);
                       $('#itm_invoicefooter').html('<td colspan="3">Total</td><td>'+ totalinv.toLocaleString() +'</td><td>'+ total.toLocaleString() +'</td><td id="receipt_calc">'+ total.toLocaleString() +'</td>');
                       $('#Name_loaded').html(''); 
                       $('#select_invoice').hide();
                       //$('#receipt_calc').html(total.toLocaleString());
                       $('#amount_due').val(amountdue.toLocaleString());
                   }
                },
                error: function () {
                    $('#itm_invoice').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
      });
    }
     function AmtCalc() {
        total = 0;
        for (var j in item_list) {
           total += parseInt($('#amounttopay' + item_list[j]).val());  
        }
        amountdue = total - amountpayed;
        if(amountdue >= 0){
          $('#amount_due').val(amountdue.toLocaleString());
        }else{
          $('#amount_due').val(0);  
        }
        if (amountdue <= 0) {
            $('#finishReceipt').prop("disabled", false);;
        } else {
            $('#finishReceipt').prop("disabled", false);
        }
        $('#receipt_calc').html(total.toLocaleString());
        
    }
    function RemoveSelectItemRow(looper){
        for( var i = 0; i < item_list.length; i++){ 
            if ( item_list[i] == looper) {                 
                item_list.splice(i, 1); 
            }
        }
       $('#row'+looper).remove();
        AmtCalc();
		
    }
    function removePayment(lg){
       $('#ledgerRow'+lg).hide();
       $('#ledger_payed'+lg).html('');
       $('#legerRata'+lg).html('');
        AmtCalc();
    }
 
</script>