<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css')?>"/>
<style type="text/css">
    tr:hover {
cursor: pointer;

}
 
</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Billing</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">  <?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Deposits</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#inv-all">Deposit List</a></li>
                 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#inv-ctr">Deposit Control</a></li>
                   <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#rcpt-reves">Reversal list</a></li>
                 <li class="nav-item"><a class="nnav-lik" data-toggle="tab" href="#inv-add">New Deposit</a></li>
                 
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#inv-all">Deposit List</a></li>
                <li></li><li></li>
                 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#inv-ctr">Deposit Control</a></li>
                 <li></li>
                 <li class="nav-item"><a class="nav-lik" data-toggle="tab" href="#inv-add">New Deposit</a></li>
                 
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="inv-all">
                <div class="d-flex justify-content-center">
                    <form id="Rept1Result" class="form-inline">
                         Deposit date:
                         <div class="input-group ms-3 me-3">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                      
                        
                        <button type="submit" class="btn btn-primary">Create</button>
                       
                        <div class="input-group ms-3">
                
                <input type="text" class="form-control" name="payer_name" id="search_name"   placeholder="Search Student Name" aria-label="Student Name" aria-describedby="button-st">
                <button class="btn btn-outline-success" type="button" id="button-y">
                    <span>
                        <i class="fa fa-calendar" aria-hidden="true"></i>
                    </span></button>
                <button class="btn btn-outline-primary" type="button" id="button-st" onclick="searchnamebtn()"><i class="fa fa-search" aria-hidden="true"></i></button>
            </div> 
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="receipt"></div>
                </center>
                
                            <?php
                            $amodel = new App\Models\AdmissionModel();
                                $bmodel = new App\Models\BillingModel();
                               $account = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 13));
                                $dbname=session()->get('db_name');
                                $db = \Config\Database::connect($dbname);
                            ?>
                            
                            
            </div>

            <div class="tab-pane" id="inv-ctr">
                <div class="d-flex justify-content-center">
                    <form id="Rept1Result_ctr" class="form-inline">
                         Control Number date:
                         <div class="input-group ms-3 me-3">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn-ctr">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                      
                        </select>
                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="receipt_ctr"></div>
                </center>
                    
            </div>

            <!--reverse pannel --->
            <div class="tab-pane" id="rcpt-reves">
               <div class="d-flex justify-content-center">
                <div id="messageDisplayArea2"></div>
                    <form id="Rept1ResultReves" class="form-inline">
                         Reverse date:
                         <div class="input-group ms-3 me-3">
                         <button type="button" class="btn btn-default pull-right daterange-all" id="daterange-all">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                      
                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="receipt_revese"></div>
                </center>
            </div>
            <!---///////////////////////New invoice------------------>
            <div class="tab-pane" id="inv-add">
          
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="card">
                            <div class="card-header"  style="height:5px">
                     <ol class="breadcrumb page-breadcrumb">
                        <li class="card-title">Deposit Details</li>
                    <li class="help-icon">
                    <a href="#" onclick="tg_help()" style="margin-left:8px"><span class="icon1">?</span></a>
                   </li>
               </ol>
                                <div class="card-options ">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                                <hr>
                            <div class="card-body">
                                <form class="form-horizontal" id="depositform" onsubmit="event.preventDefault();">
                                    <div id="feedback"></div>
                                   <div class="row">
                                    <div class="col-md-6">

                                        
                                       <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Deposit Type</label>
                                            <div class="col-sm-8">
                                              <?php
                                                 $cty= $bmodel->get_table_details('invoice_types_tbl');
                                                  ?>
                                                <select class="form-control" name="deposit_type" id="deposit_type">
                                                    <option value="6">General</option>
                                                    <?php foreach($cty as $type): ?>
                                                    <option value="<?= $type->id ?>"><?= $type->type_name; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                          </div>
                                  
                                  <?php 
                                  $pj = $amodel->get_student_details('projects_tbl', $where = array('status' => 1));
                                  ?>
                                <div class="form-group row" id="showProject" style="display:none">
                                <label class="col-md-4 col-form-label">Projects<span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <select name="project" id="project" class="form-control" required="required">
                                        <option value="0">-Select project-</option>
                                        <?php foreach ($pj as $ac): ?>
                                            <option value="<?= $ac->id; ?>"><?= $ac->project_name; ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                            </div>

                                        <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Deposit Date</label>
                                            <div class="col-sm-8">
                                              <input type="date" id="invoice_date" name="invoice_date" value="<?php echo date('Y-m-d');?>" class="form-control" max="<?php echo date('Y-m-d');?>">
                                            </div>
                                          </div>
                                         
                                         <input type="hidden" name="paid_by" value="5" id="paid_by"> 
                                          <div class="form-group row" id="payer_name_row" style="display: none;">
                                            <label for="payerame" class="col-sm-4 col-form-label">Name<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                                <div class="input-group mb-3">
                                                    <input type="hidden" id="payer_id" name="payer_id" value="1">
                                                    <input type="text" class="form-control" name="payer_name" id="payer_name"   placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2">
                                                    <button class="btn btn-outline-primary" type="button" id="button-addon2" onclick="search_payer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                          </div>
                                          <div id="payer_details"></div>
                                         <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Customer Type<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                               <?php
                                                    $ctype= $bmodel->get_table_details('name_type_tbl');
                                                  ?>
                                                <select class="form-control" name="customer_type" id="customer_type">
                                                    <option value="">Select Customer Type</option>
                                                    <?php foreach($ctype as $type): ?>
                                                    <option value="<?= $type->id ?>"><?= $type->name_type; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                          </div>
                                          <div class="form-group row" id="select_invoice" style="display:none;">
                                            <label for="payerame" class="col-sm-4 col-form-label">Select Customer<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" name="customer_name or Id"  id="customer_name" placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2">
                                                    <button class="btn btn-outline-primary" type="button" id="button-addon2" onclick="search_customer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                          </div>
                                        <div id="customer_details"></div>
                                    </div>   
                                    <div class="col-md-6">
                                       <div id="customer_loaded"></div> 
                                       <div id="Name_loaded"></div>
                                       <div id="Invoice_loaded"></div>
                                    </div>
                                </div>
            <!----other receipt btn------------>
           <div  class="cust_popup" id="other_rec_popup" style="display: none;margin-left: 130px;">
          <div id="display_receipt">
              
          </div>
          </div>
          <!-----------end other rct bth--------------->
                                 <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Charged Items<span class="text-danger">*</span></label>
                            <div class="col-sm-6">
                            <select class="form-select form-control" id="js-example-data-ajax" style="width:100%;height: 15px;"></select>
                        </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"></div>
                            <div class="col-md-9">
                                <div class="card">
                                    <p Class=" d-flex justify-content-center mt-3">CHARGED ITEMS</p>
                                    <table class="table table-hover table-vcenter mb-0 text-nowrap" id="table">
                                    <thead>
                                            <tr>
                                                <th>No#</th>
                                                <th>Item Name</th>
                                                <th>Attribute</th>
                                                 <th>Size</th>
                                                <th>UOM</th>
                                                 <th>Qty</th>
                                                <th>Price</th>
                                                
                                                <th>Total</th>
                                                <th>Action</th>
                                            </tr>
                                    </thead>
                                    <tbody id="show_item">
                                        <div  class="cust_popup" id="cash" style="display: none">
                                    <h6>Change price</h6>
                                <div id="prcres"></div>
                                     
                               </div>

                               
                                    </tbody>
                                    </table>
                                    <table>
                                        <tr>
                                        <th class="col-sm-8"></th>
                                        <th colspan=5 id="totalp">
                                        <!-- <span id="totalp" style="margin-left:400px;"></span> -->
                                        </th>
                                        </tr>
                                        </table>
                                </div>
                                </form>
                            </div>
                        </div><br>
        <!-----------*******************************----------------------------------------------------------------------------->
                          <?php
                                    $acc = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 9));
                                ?>
                                
                                <div  class="cust_popup" id="cash_pop" style="display: none">
                                   <div id="resultshere"></div>
                               </div>  
                                <hr>
                                <div class="row">
                                    <!-- <div class="col-md-6">
                                     
                                     <button type="button" class="btn btn-primary" onclick="tg_patacct()"  >Account</button>
                                   <button type="button" class="btn btn-primary">Cheque</button>
                                    </div> -->
                                    <div class="col-md-12">
                                        <form id="payment_panel">
                                            <?php foreach($acc as $ap):?>
                                                  <div class="form-group row" id="ledgerRow<?= $ap->id?>" style="display: none;" >
                                                    <label for="staticEmail" class="col-sm-1 col-form-label"><?= $ap->id; ?> </label>
                                                    <label for="staticEmail" class="col-sm-3  col-form-label"><?= $ap->account_name; ?> Ledger</label>
                                                    <div class="offset-md-6 col-sm-1">
                                                      <input type="text" readonly class="form-control-plaintext" id="ledger_payed<?= $ap->id?>" value="900">
                                                    </div>
                                                    <div class="col-sm-1">
                                                        <div id="legerRata<?= $ap->id?>">
                                                        </div>    
                                                        <label style="margin-top: 10px;"><i  onclick="removePayment('<?= $ap->id?>')" class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="delete"></i></label>
                                                    </div>   
                                                   </div>
                                            <?php endforeach; ?>
                                             <div class="form-group row"  >
                                                <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label">Amount Due</label>
                                                <div class="offset-md-6 col-sm-1">
                                                  <input type="text" readonly class="form-control-plaintext" id="amount_due" value="0">
                                                </div>
                                                <div class="col-sm-1">
                                                </div>   
                                              </div>
                                           <!--  <div class="form-group row" style="display: none;" id="change_row" >
                                                <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label">Change</label>
                                                <div class="offset-md-6 col-sm-1">
                                                  <input type="text" readonly class="form-control-plaintext" id="amount_change" value="">
                                                </div>
                                                <div class="col-sm-1">
                                                </div>   
                                              </div>
                                         -->
                                        </form>       
                                    </div>
                                    <!-- <div class="col-md-2">
                                         <button type="button" class="btn btn-primary pull-left" onclick="tg_dep()"> Add Payment</button>
                                     </div>
                                     <div class="col-md-2" id="use_receipt">
                                         <button type="button" class="btn btn-primary pull-left" id="other_receipt" onclick="otherReceipt()">Reverse</button>
                                    </div> -->
                             <div class="form-group row">
                           
                            <div class="col-md-8">
                              <button type="button" class="btn btn-primary pull-left me-3" onclick="tg_dep()"> Add Payment</button>

                                <button type="button" class="btn btn-primary pull-left me-3" id="other_receipt" onclick="otherReceipt()">Use other receipt</button>

                                <button type="button" class="btn btn-primary pull-left me-3" id="reverse_deposit" onclick="reverseDeposit()">Reverse Deposit</button>
                            </div>
                        </div>
                                </div> <br><br><br>
        <!---------------------------------------------------------------------------------------->
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-8">
                               <button type="submit" id="student_control_number" onclick="send_deposit(2)" class="btn btn-primary float-right">Create Control Number</button>

                                <button type="submit" id="admit_student" onclick="send_deposit(1)" class="btn btn-primary float-right me-3">Create Deposit</button>
                            </div>
                        </div>
                        
                            </div>
                        </div>
                        
                    </div>
                </div>
            
            </div>
        </div>
    </div>
</div>
<!-- ------View invoice modal------- -->


<!-- ------manage invoice modal------- -->


<!-- ------invoice print modal------ -->

<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
<script>
     function manage_deposit(inv){
        //alert(inv);
      $('#viewreceipt').modal('show'); 
      $('#viewreceipt_content').load('index.php/BillingController/view_deposit/'+inv);
    }
     function manage_deposi(inv){
        //alert(inv);
      $('#viewreceiptxl').modal('show'); 
      $('#viewreceipt_contentxl').load('index.php/BillingController/deposit_edit/'+inv);
    }
    var hold_selected_items = []; // hold all selected items
     var item_list = [];
    $(document).ready(function(){
        
         $('#js-example-data-ajax').select2({
            ajax: {
                url: "<?php echo base_url() . '/index.php/AccomodationController/load_diposit_data'; ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            },
             escapeMarkup: function (markup) {
                        return markup; // Don't escape HTML
                        },
                        templateResult: function (data) {
                        return data.text; // Render the full HTML in 'text'
                        },
        });

        $('#js-example-data-ajax').on('select2:select', function (e) {
            selectedItems();
        });
        //var prc; 
        function selectedItems(){  
            var rows = '';
           var itemData = 'item_selected='+$('#js-example-data-ajax').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Accomodationdata1')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }else{
                        var len  = data.length;
                        
                        for (var i = 0; i <len; i++ ){
                            hold_selected_items.push(data[i]['id']);// push all selected items
                            var prc = data[i]['iprice'];
                            totalsum=prc;
                            price= prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
                            var name = data[i]['iname'];
                            var size = data[i]['isize'];
                            var attribute = data[i]['iattribute'];
                            var iid = data[i]['id'];
                            //var qty = window.prompt("Enter quantity");
                            //var tprice = qty*prc;
                            document.getElementById("totalp").innerHTML = "Total = " + prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

                            $('#amount_due').val(prc.toLocaleString()); 
                             if (prc > 0) {
                              $('#student_control_number').prop("disabled", false);

                                 }
                            rows += '<tr id="table_row'+ iid +'">';

                           rows+='<td><input type="hidden" name="iid[]" value="'+iid+'">'+ iid +'</td>';
                             rows+='<td><input type="hidden" name="price'+iid+'" value="'+prc+'">'+ name +'</td>';
                            //rows += '<td>'+ name +'</td>';
                            rows += '<td>'+ attribute +'</td>';
                            rows += '<td>'+ size +'</td>';
                            rows += '<td>'+ 1 +'</td>';
                            rows += ' <td><input type="hidden" name="prco'+iid+'" id="prco'+iid+'" value="'+prc+'">'+1+'</td>';
                            rows += '<td><a class="cost2" id="cost' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getid(' +iid+ ','+prc+')"><input type="text" value="'+prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" id="prc'+iid+'" readonly></a>\
                        </td>';
                            rows += '<td class="text-right" style="text-align:right" id="total'+iid+'">'+prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</td>';
                            
                            //rows += '<td><input type="text" name="tprice" id="tprice'+iid+'" style="width:85px; border:none; background-color:rgb(240,240,240)" readonly></td>';
                            rows += '<td><a href="javascript:RemoveSelectItemRow('+iid+','+i+');" class="btn btn-danger btn">X</a></td>';
                            
                            rows += '</tr>';
                            $('#show_item').append(rows);
                        }
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }
                
           });  
        }

    });
    var sumVal=0;   
function getid(id,prc) {
     $('#cash').toggle(100);
      
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/priceview'; ?>",
            beforeSend: function () {
                $('#prcres').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#prcres').html(result);
                console.log(prc);
             document.querySelector('[id="cash_amt"]').value = prc;
             document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }
       function savebtn(){
       // alert('yes');
        totalsum=0;
      var cash=$('#cash_amt').val();
      var item_id=$('#item_id').val();
      //alert(item_id); 
      for( var i = 0; i < hold_selected_items.length; i++){ 
           id1=hold_selected_items[i];
           if(id1==item_id){
            var cashAmt =parseInt(cash);
            document.querySelector('[id="prco'+id1+'"]').value = cashAmt;
            document.querySelector('[id="prc'+id1+'"]').value = cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            document.getElementById("total"+id1).innerHTML = cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

           // $('#cost'+id1+'').append(cashAmt);
           }else{
            var cashAmt1 =$('#prc'+id1+'').val();
            let result = cashAmt1.replace(/,/gi, "");
        
            var cashAmt =parseInt(result);
           // alert(cashAmt);
           }
       
        totalsum=totalsum+cashAmt;
        }       
          $('#cash').hide(); 
             document.getElementById("totalp").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
             $('#amount_due').val(totalsum.toLocaleString()); 
             //alert(totalsum);
             if (totalsum > 0) {
         
            $('#student_control_number').prop("disabled", false);

        } else {
            
            $('#student_control_number').prop("disabled", true);
        }
            return totalsum;       
         e.preventDefault(); 
    }
    function manage_invoice(inv){
        // alert(inv)
      // $('#viewinvoice').modal('show'); 
       $('#viewinvoice_content').load('view_invoice/'+inv);
    }

    function edit_invoice(invID){
        $('#view_details').load('invoice_details/'+invID);
    }

    function invoice_print(){
        $('#invoiceprint').modal('show');
    }
    // $('#invoicePrint_content').load('print_invoice/'+inv);

    function printable_rept(area) {
       // alert('yy');
         var _c = $('#att-list').html();
        var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=800,height=600')
        nw.document.write(_c)
        nw.document.write('<html><head><title>MHI</title><link rel="stylesheet" href="<?php echo base_url() . 'syst_assets/'; ?>bootstrap/css/bootstrap.css">')
        nw.document.write(ns.html())
        //nw.document.close()
        nw.print()
    }

    function invoice_receipt(student_id,trans_no){

        // window.location.href = `http://localhost/econnect/receipt`
        
        // window.location.href= "<?php echo base_url() . '/receipt'; ?>" + "?id="+student_id;
        window.location.href= "<?php echo base_url() . '/index.php/BillingController/invoice_receipt'; ?>/"+student_id+"/"+trans_no;

        // prepare_invoice_student(student_id);

    }
 $("#paid_by").change(function(){
        $('#payer_name_row').show();
        $('#payer_details').html('');
    });
    $("#customer_type").change(function(){
        $('#select_invoice').show();
        if($(this).val() == 4){
            $('#applicationlist').show();
            $('#invoicelist').hide();
        }else{
           $('#invoicelist').show(); 
           $('#applicationlist').hide();
        }
    });
    function search_payer(){
       if($('#paid_by').val() == "") {
           swal("warning","Please Select Paid By","warning");
       }else if($('#payer_name').val() == ""){
          swal("warning","Please Enter Payer Name","warning"); 
       }else{
            var paydata = 'paid_by=' + $('#paid_by').val() + "&payer_name=" + $('#payer_name').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/search_payer'; ?>',
                beforeSend: function () {
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#customer_loaded').html(result); 
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
       
    }
    var ids;
    function select_payer(id,nametype){
       
       var payer = nametype +'_' +id;
        $('#payer_id').val(payer);
        var payerdata = "payer=" + payer;
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillingController/get_payer_details'; ?>',
            data: payerdata,
            success: function (res) {
               
                $('#payer_details').html(res);
                $('#payer_name_row').hide();
                $('#customer_loaded').html('');

            },
            error: function (){
                alert('error encounted');
            }
        });
    }
//     $(document).ready(function(){
   
//     // code to read selected table row cell data (values).
//     $("#table").on('click','.btn',function(){
         
//          var currentRow=$(this).closest("tr"); 
         
//          var col1=currentRow.find("td:eq(7)").text(); 
//           //sum=totalAmounts();
//           //sum=sumval;
//          var data=col1;
//          //alert(data);
//         sumVal=sumVal-data;
//         document.getElementById("totalp").innerHTML = "Total = " + sumVal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
//          console.log(sumVal);
         
//     });
// });
    function RemoveSelectItemRow(item_id){
        var p= $("#prco"+item_id+"").val();
       // alert(p);
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }
         $('#table_row'+item_id).remove();
        
        totalsum=totalsum-p;
         document.getElementById("totalp").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(totalsum);
            //return totalsum;       
         e.preventDefault();
       
    }
// $("#account").change(function(){
//     var items="";
//     var accounts=$('#account').val();
//     var amount_ttl=sumVal;
//     //alert("acc= "+accounts+"ttl="+amount_ttl);
//     items = {account_receivable: accounts, amount: amount_ttl};
//     receivable_total_balance.push(items);
//     alert(items);
//     });

   function send_deposit(id){
   //$('#admit_student').prop("disabled", true);
    if($('#customer_type').val()==""){
      swal("warning","Please Select Customer Type","warning");
    }else{
        var allvariables2 = $("#depositform").serialize() + '&sid='+ids + '&'+ $("#payment_panel").serialize()+'&'+$("#header_form").serialize()+'&status='+id;
        // alert(allvariables2);
        //   return;
        $.ajax({
            beforeSend: function () {
                  $('#admit_student').prop("disabled", true);
                  $('#student_control_number').prop("disabled", true);
                  $('#feedback').append('<div class="alert alert-primary alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button><i class="fa fa-spinner fa-spin"></i>Preparing Control Number Please wait..</div>');
            },
            type: 'POST',
        
        url: '<?php echo base_url() . '/index.php/AdmissionController/save_deposit_transaction_items/'; ?>'+ids,
            data: allvariables2,
            success:function(res){
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                      swal("success",data['statusDesc'],"success");
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else if(data['status'] == 1){
                    swal("success",data['statusDesc'],"success");
                    setTimeout(function(){
                        window.location.reload();
                    },1500)
                }
                else{
                    $('#admit_student').prop("disabled", true);
                    $('#student_control_number').prop("disabled", true);

                    swal("error","Sory, something went wrong!","error");
                    setTimeout(function(){
                        window.location.reload();
                    },1500)
                }
            },
            error:function(res){
                $('#admit_student').prop("disabled", false);
                $('#student_control_number').prop("disabled", false);
                swal("error","Sory, something went wrong!","error");
                setTimeout(function(){
                        window.location.reload();
                    },1500)
            }
        });

        e.preventDefault();
    }
    }
   // function clicked(id){
   //  alert("yes welcome");
   //   alert($(this).serialize());

   // }

   function search_customer(){
       if($('#customer_type').val() == "") {
           swal("warning","Please Select Customer Type","warning");
       }else if($('#customer_name').val() == ""){
          swal("warning","Please Enter Customer Name","warning"); 
       }else{
            var paydata = 'type=' + $('#customer_type').val() + "&cust_name=" + $('#customer_name').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/search_customer_invoice'; ?>',
                beforeSend: function () {
                    $('#Name_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#Name_loaded').html(result); 
                },
                error: function () {
                    $('#Name_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
          }
     function prepare_invoice_student(id){
         ids=id;
        var paydata = 'type=' + $('#customer_type').val()+'&id=' + id;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/loadCustomer'; ?>',
                beforeSend: function () {
                    $('#Invoice_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (res) {
                 var data = JSON.parse(res);
                 select_payer(data['parent'],5);
                  //alert(data['parent']);
                  //alert(res.fullname);
                $('#customer_details').html(data['fullname']);
                $('#select_invoice').hide();
                $('#Name_loaded').html('');
                $('#Invoice_loaded').html('');
            },
            error: function (){
                alert('error encounted');
            }
      });
    }
    
     
    $(document).ready(function(){
   
    // code to read selected table row cell data (values).
    $("#table").on('click','.btn',function(){
         
         var currentRow=$(this).closest("tr"); 
         
         var col1=currentRow.find("td:eq(7)").text(); 
          sumVal=totalAmounts();
          //sum=sumval;
         var data=col1;
         sumVal=sumVal-data;
         //remain=sum;
         //alert(remain);
        // document.getElementById("remained").innerHTML = "Remain = " + remain.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
         document.getElementById("totalp").innerHTML = "Total = " + sumVal;
         console.log(sumVal);
         
    });
});
     var total=0;
    
    function totalAmounts(id){
        $('#ttl' + id).empty();
        var prc = $('input[name=price' + id+']').val();

        var qty = $('input[name=quantity' + id+']').val();
        var calc = prc*qty; 
        
            
            $('#ttl' + id).append(calc);
            
            var table = document.getElementById("table"), sumVal=0;
            
            for(var i = 1; i < table.rows.length; i++)
            {
                sumVal = sumVal + parseInt(table.rows[i].cells[7].innerHTML);
            }
            //remain=sumVal;
            document.getElementById("totalp").innerHTML = "Total = " + sumVal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(sumVal);
            return sumVal;
    }
resetReceiptData();
   function resetReceiptData(){
        $('#payer_details').empty();
        $('#payer_name').val('');
        $('#account').val('');
       
        $('#customer_type').val('');
         $('#customer_name').val('');
        $('#select_invoice').hide();
        $('#customer_loaded').empty();
        $('#Name_loaded').empty();
        $('#Invoice_loaded').empty();
        $('#itm_invoice1').empty();
        $('#itm_invoice').empty();
        $('#amount_due').val(0);
   }
     function tg_cash() {
        $('#cash_pop').toggle(100);
    }
      $('#admit_student').prop("disabled", true);
      $('#student_control_number').prop("disabled", true);

    function csh_proc1() {
       // totalsum=0;
        //alert(totalsum);
        //return 1;
         var cashAmt = parseInt($('#cash_amt1').val());
        // var change;
        amountdue = totalsum - cashAmt;
        totalsum=amountdue;
         var ledger = $('#ledger option:selected').val();
         item_list.push(ledger);
            $('#ledgerRow'+ledger).show();
             $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
             var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" id="amount'+ledger+'" name="amount'+ledger+'" value="'+ cashAmt +'">';
            $('#legerRata'+ledger).append(data);
             $('#amount_due').val(amountdue.toLocaleString()); 
             if (amountdue == 0) {
            $('#admit_student').prop("disabled", false);
            $('#student_control_number').prop("disabled", false);

        } else {
            $('#admit_student').prop("disabled", true);
            $('#student_control_number').prop("disabled", true);
        }
  if (totalsum > 0) {
         
            $('#student_control_number').prop("disabled", false);

        } else {
            
            $('#student_control_number').prop("disabled", true);
        }
        
        tg_cash();
           console.log(totalsum);
         e.preventDefault();
    };
    function removePayment(lg){
        var amount=parseInt($('#amount'+lg).val());
        amountdue = parseInt(totalsum + amount);
        totalsum=amountdue;
        //alert(amount);
       $('#ledgerRow'+lg).hide();
       $('#ledger_payed'+lg).html('');
       $('#legerRata'+lg).html('');
       
        $('#amount_due').val(amountdue.toLocaleString()); 
             if (amountdue == 0) {
            $('#admit_student').prop("disabled", false);
            $('#student_control_number').prop("disabled", false);

        } else {
            $('#admit_student').prop("disabled", true);
            $('#student_control_number').prop("disabled", true);
        }
       // AmtCalc();
    }
      
    function tg_dep() {
     $('#cash_pop').toggle(100);
      
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/discountView'; ?>",
            beforeSend: function () {
                $('#prcres').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#resultshere').html(result);
               // console.log(prc);
             //document.querySelector('[id="cash_amt"]').value = prc;
             //document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }
          $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                   ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                                         'This Year': [moment().startOf('year'), moment().endOf('year')],
                                        'Last Year': [moment().subtract(1, 'year').startOf('month'), moment().subtract(1, 'year').endOf('year')],
                                    }
                                }, cb);
                                cb(start, end);

                            });
   $('#Rept1Result').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#receipt').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn span').html();
           // alert(dta);
            $.ajax({
                type: "POST",
               // url: '<?php echo base_url() . '/deposit2'; ?>',
                  url: "<?php echo base_url() . '/index.php/BillingController/deposit2'; ?>",
                data: dta,
                success: function (res) {
                    $('#receipt').html(res);
                },
                error: function () {
                    $('#receipt').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });

                 $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn-ctr span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn-ctr').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                   ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                                         'This Year': [moment().startOf('year'), moment().endOf('year')],
                                        'Last Year': [moment().subtract(1, 'year').startOf('month'), moment().subtract(1, 'year').endOf('year')],
                                    }
                                }, cb);
                                cb(start, end);

                            });
   $('#Rept1Result_ctr').submit(function (e) {
             if (!$('#daterange-btn-ctr span').html()) {
            $('#RecptResult_ctr').html('Please specify valid date.');
        } else {
            $('#receipt_ctr').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn-ctr span').html();
           // alert(dta);
            $.ajax({
                type: "POST",
               // url: '<?php echo base_url() . '/deposit2'; ?>',
                  url: "<?php echo base_url() . '/index.php/BillingController/deposit3'; ?>",
                data: dta,
                success: function (res) {
                    $('#receipt_ctr').html(res);
                },
                error: function () {
                    $('#receipt_ctr').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });

   function otherReceipt(){
         $('#other_rec_popup').toggle(100);
         $('#display_receipt').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');

            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/SemisterController/load_receipt'; ?>',
                beforeSend: function () {
                    $('#display_receipt').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                
                success: function (result) {
                  $('#display_receipt').html(result); 
                },
                error: function () {
                    $('#display_receipt').html('<p class="text-red">Sorry Something went wrong</p>');
               }
            });
        }
function closePopup_transfer() {
        event.preventDefault();
  var popup = document.getElementById('other_rec_popup');
  popup.style.display = 'none'; // Set display to 'none' to hide the popup
  //alert('yes');
}
function save_amount() {
 $('#other_rec_popup').toggle(100);
 var receipt_number =$('#receipt_number').val();
 var reason =$('#reason').val();
 
  var cashAmt = parseInt($('#i_amount').val());
        // var change;
        amountdue = totalsum - cashAmt;
        totalsum=amountdue;
         var ledger = $('#from_ledger').val();
         item_list.push(ledger);
            $('#ledgerRow'+ledger).show();
             $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
             var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" id="amount'+ledger+'" name="amount'+ledger+'" value="'+ cashAmt +'"><input type="hidden" id="receipt_number'+ledger+'" name="receipt_number'+ledger+'" value="'+ receipt_number +'"><input type="hidden" id="reason'+ledger+'" name="reason'+ledger+'" value="'+ reason +'"><input type="hidden" id="transfer'+ledger+'" name="transfer'+ledger+'" value="'+ cashAmt +'">';
            $('#legerRata'+ledger).append(data);
             $('#amount_due').val(amountdue.toLocaleString()); 
             if (amountdue == 0) {
            $('#admit_student').prop("disabled", false);
            $('#student_control_number').prop("disabled", false);

        } else {
            $('#admit_student').prop("disabled", true);
            $('#student_control_number').prop("disabled", true);
        }
  if (totalsum > 0) {
         
            $('#student_control_number').prop("disabled", false);

        } else {
            
            $('#student_control_number').prop("disabled", true);
        }
        
      closePopup_transfer();
           console.log(totalsum);
         e.preventDefault();
}

$('#Rept1ResultReves').submit(function (e) {
             if (!$('#daterange-all span').html()) {
            $('#receipt_revese').html('Please specify valid date.');
        } else {
            $('#receipt_revese').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-all span').html();
            //alert(dta);
            //return;
            $.ajax({
                type: "POST",
                  url: '<?php echo base_url() . '/index.php/SemisterController/load_reversal_todeposit'; ?>',
                 data: dta,
                success: function (res) {
                    $('#receipt_revese').html(res);
                },
                error: function () {
                    $('#receipt_revese').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });
function searchnamebtn(){
            var name=$('#search_name').val();
            var  year=$('#button-y').html();
            // alert(year);
            if(name.length >=3){
                $('#receipt').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
                var dta="name="+name+"&year="+year;
           // toastr.success(name.length);
             $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/index.php/AdmissionController/fetch_invoice_byname'; ?>/3",
                data: dta,
                success: function (res) {
                    $('#receipt').html(res);
                },
                error: function () {
                    $('#receipt').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
        }else{
            if(name.length==0){
               $('#cdtResult').html(''); 
            }else{
               $('#cdtResult').html('<div class="alert alert-info">Search atleat 3 characters</div>'); 
            }
        
        }
        }

        $("#deposit_type").change(function(){
    if($("#deposit_type").val()==7){
        $('#showProject').show();
    }else{
     $('#showProject').hide();
    }
       
    });

 function reverseDeposit(){
         $('#other_rec_popup').toggle(100);
         $('#display_receipt').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');

            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/SemisterController/load_deposit_toreverse'; ?>',
                beforeSend: function () {
                    $('#display_receipt').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                
                success: function (result) {
                  $('#display_receipt').html(result); 
                },
                error: function () {
                    $('#display_receipt').html('<p class="text-red">Sorry Something went wrong</p>');
               }
            });
        }

        function save_amount3(e) {
 $('#other_rec_popup').toggle(100);
 var receipt_number =$('#deposit_number').val();
 var reason =$('#reason').val();
 
  var cashAmt = parseInt($('#i_amount').val());
        // var change;
        amountdue = totalsum - cashAmt;
        totalsum=amountdue;
         var ledger = $('#from_ledger').val();
         item_list.push(ledger);
            $('#ledgerRow'+ledger).show();
             $('#ledger_payed'+ledger).val(cashAmt.toLocaleString());
             var data ='<input type="hidden" name="pay_ledger[]" value="'+ ledger +'"><input type="hidden" id="amount'+ledger+'" name="amount'+ledger+'" value="'+ cashAmt +'"><input type="hidden" id="deposit_number'+ledger+'" name="deposit_number'+ledger+'" value="'+ receipt_number +'"><input type="hidden" id="reason'+ledger+'" name="reason'+ledger+'" value="'+ reason +'"><input type="hidden" id="transfer'+ledger+'" name="reverse_deposit'+ledger+'" value="'+ cashAmt +'">';
            $('#legerRata'+ledger).append(data);
             $('#amount_due').val(amountdue.toLocaleString()); 
             if (amountdue == 0) {
            $('#admit_student').prop("disabled", false);
            $('#student_control_number').prop("disabled", false);

        } else {
            $('#admit_student').prop("disabled", true);
            $('#student_control_number').prop("disabled", true);
        }
  if (totalsum > 0) {
         
            $('#student_control_number').prop("disabled", false);

        } else {
            
            $('#student_control_number').prop("disabled", true);
        }
        
      closePopup_transfer();
           console.log(totalsum);
         e.preventDefault();
}
</script>    