
<div class="row">
    <div class="card">
        <center>
            <table class="table table-borderless mt-3">
               <tr>
                <th>Supplier Id:</th>
                <td><?= $suppliers[0]->supplier_id;?></td>
                </tr>
                <tr>
                <th>Supplier Name:</th>
                <td><?= $suppliers[0]->supplier_name;?></td>
                 </tr>
                 <tr>
                 <th>Supplier Address:</th>
                  <td><?= $suppliers[0]->supplier_address;?></td>
                   </tr>
                   <tr>
                    <th>Supplier Email:</th>
                    <td><?= $suppliers[0]->supplier_email;?></td>
                    </tr>
                    <tr>
                    <th>Phone Number:</th>
                    <td><?= $suppliers[0]->supplier_phone;?></td>
                     </tr>
                                      <tr>
                                        <th>Updated By:</th>
                                        <td><?= $suppliers[0]->first_name;?></td>
                                    </tr>
                                      <tr>
                                        <th>Updated Date:</th>
                                        <td><?= $suppliers[0]->updated_date;?></td>
                                    </tr>

                                     <tr>
                                        <th>Supplier Status:</th>
                                        <td><?php if($suppliers[0]->status === '1'){
                                            echo '<div class="text-success">Active</div>';
                                        }else{
                                             echo '<div class="text-danger">Inactive</div>';
                                        }?></td>
                                    </tr>
                                     
                                </table>
                            </center>

                        </div>
                       
                       
              <!-----*********************------------------>
    </div>