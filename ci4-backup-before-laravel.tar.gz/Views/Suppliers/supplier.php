<style type="text/css"> 

    #results { padding:5px; border:1px solid; background:#ccc; }

</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Suppliers</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Supplier</li>
                </ol>
            </div>
            <div id="largeScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#supplier-all">Supplier List</a></li>
                 <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#supplier-add">New Supplier</a></li>
            </ul>
             </div>

             <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#supplier-all">Voucher List</a></li>
                <li></li><li></li>
                  <li class="nav-item d-none d-sm-block"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#supplier-add">New Voucher</a></li>
            </ul>
             </div>

        </div>
    </div>
</div>

<div class="section-body mt-4">
        <div class="container-fluid">
            <div class="tab-content">
            <div class="tab-pane" id="supplier-add">
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="card card-lg">
                            <div class="card-header"  style="height:5px">
                                <h3 class="card-title">Supplier Details</h3>
                                <div class="card-options ">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                                <hr>
                            <div class="card-body">
                                <form class="form-horizontal" id="savesupplier">
                                <div id="supplierarea"></div>
                                   <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Supplier Name<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                              <input type="text" id="supp_name" name="supp_name" class="form-control" required>
                                            </div>
                                          </div>

                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Supplier Address<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                              <input type="text" id="supp_address" name="supp_address" class="form-control" required>
                                            </div>
                                          </div>
                                      </div>
                                      <div class="col-md-6">
                                            <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Supplier Phone<span class="text-danger"></span></label>
                                            <div class="col-sm-8">
                                              <input type="text" id="supp_phone" name="supp_phone" class="form-control" placeholder="+255-xxx-xxx-xxx" value="+255" size="20" minlength="9" maxlength="13" autocomplete="off" data-inputmask="'mask': '+999999999999'" >
                                            </div>
                                          </div>

                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Supplier Email<span class="text-danger"></span></label>
                                            <div class="col-sm-8">
                                               <input type="email" name="supp_email" class="form-control" >
                                            </div>
                                          </div>
                                       
                                          
                                    </div>   
                                   
                                </div>
                        
                         <div class="form-group row">
                            <div class="col-md-8">
                                <button type="submit" id="create_new_supplier" class="btn btn-primary" style="float: right;">Create</button>
                            </div>
                        </div>
                        </form>
                    </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            
            

             <div class="tab-pane active" id="supplier-all">
                <div class="card">
                    <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable">
                            <thead>
                                <tr>
                                    <th>#Supplier Id</th>
                                    <th>Supplier Name</th>
                                    <th>Address</th>
                                    <th>Phone</th>
                                    <th>Updated By</th>
                                    <th>Updated Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody style="padding:1px;">
                            <?php $id = 0; foreach ($supplierinfo as $supp):$id++;?>
                                <tr>
                                    <td><?= $id; ?></td>
                                    <td><?= $supp->supplier_name; ?></td>
                                    <td><?= $supp->supplier_address; ?></td>
                                    <td><?= $supp->supplier_phone; ?></td>
                                    <td><?= $supp->first_name." ".$supp->last_name; ?></td>
                                    <td><?= $supp->updated_date; ?></td>
                                    <td><?php if($supp->sstatus == '1'){
                                    echo '<div class="text-success">Active</div>';
                                    }else{
                                    echo '<div class="text-danger">Inactive</div>';
                                    } ?></td>
                                <td><button type="button" class="btn btn-primary btn-sm passingsupplierID" data-id="<?=$supp->supplier_id; ?>"><i class="fa fa-edit"></i> Edit</button>
                                  <button type="button" class="btn btn-primary btn-sm passingsuppID" data-id="<?=$supp->supplier_id;?>"><i class="fa fa-eye"></i> View</button></td>
                                </tr>
                           <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
</div>

<div class="modal fade" id="myviewModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Supplier Information</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Viewsupplier"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>


<!-- Modal to update Supplier Information-->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Edit Supplier Information</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Updtesupplier"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>

<script type="text/javascript">
    $('#savesupplier').submit(function(e){
         // alert($(this).serialize());
        $.ajax({
            type: "POST",
            url: "<?= base_url('/register_supplier') ?>",
            data: $(this).serialize()+'&'+$("#header_form").serialize(),
            //alert(data);
            success: function (res) {
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                    
                    $("#savesupplier")[0].reset();
                    $('#supplierarea').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#supplierarea').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            },
            error: function () {
                $('#supplierarea').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button><strong>Sorry! Something went wrong!</strong> Couldnt Save Supplier.</div>');
            }
        });


        e.preventDefault();
    });
    

    //function to View Bill data
 $(".passingsuppID").click(function () {
        var data = 'supplier_id=' + $(this).attr('data-id');
        // $("#idkl").val( ids );
        $('#myviewModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?= base_url('/get_supplier_data')?>",
            data: data,
            beforSend: function()
            {
                $('#Viewsupplier').html();
            },
            success: function(res){
                $('#Viewsupplier').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });

 //////////////////////// function to update supplier /////////////////
    $(".passingsupplierID").click(function () {   
        var data = 'ids=' + $(this).attr('data-id');
        // $("#idkl").val( ids );
        $('#myModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?= base_url('/getSingle_supplier_data')?>",
            data: data,
            beforSend: function()
            {
                $('#Updtesupplier').html();
            },
            success: function(res){
                $('#Updtesupplier').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });



</script>