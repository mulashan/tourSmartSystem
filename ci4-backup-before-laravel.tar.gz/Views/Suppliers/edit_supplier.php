
<div id="updatesupplier"></div>
<form id="updateSupplier">
    <input type="hidden" class="form-control" name="supp_id" id="supp_id" value="<?= $suppl[0]->supplier_id;?>">
    <div class="form-group row">
        <label class="col-md-4 col-form-label">Supplier Name</label>
        <div class="col-md-7">
            <input type="text" name="sname" id="sname" value="<?= $suppl[0]->supplier_name;?>" class="form-control form-control-sm" >
        </div>
    </div>
     <div class="form-group row">
        <label class="col-md-4 col-form-label">Supplier Address</label>
        <div class="col-md-7">
            <input type="text" name="saddress" id="saddress" value="<?= $suppl[0]->supplier_address;?>" class="form-control form-control-sm" >
        </div>
    </div>
     <div class="form-group row">
        <label class="col-md-4 col-form-label">Supplier Phone</label>
        <div class="col-md-7">
            <input type="text" name="sphone" id="sphone" value="<?= $suppl[0]->supplier_phone;?>" class="form-control form-control-sm" >
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-4 col-form-label">Supplier Email</label>
        <div class="col-md-7">
            <input type="text" name="semail" id="semail" value="<?= $suppl[0]->supplier_email;?>" class="form-control form-control-sm" >
        </div>
    </div>
     <div class="form-group row">
        <label class="col-md-4 col-form-label">Supplier Status</label>
        <div class="col-md-7">
            <select id="sstatus" name="sstatus" class="form-select me-4 form-control form-control-sm">
                    <option value="<?= $suppl[0]->sstatus;?>">
                        <?php if($suppl[0]->sstatus == '0')
                        {
                        echo'Inactive';
                        }else{
                         echo'Active';
                        }
                         ?>    
                        </option>
                    <option value="0">Inactive</option>
                    <option value="1">Active</option>
            </select>
        </div>
    </div>
    
    <div class="form-group row">
        <label class="col-md-4 col-form-label"></label>
        <div class="col-md-7">
            <button type="submit" class="btn btn-primary float-right">Update</button>

        </div>
    </div>
</form>

<script type="text/javascript">
    
    $('#updateSupplier').submit(function (e) {
        $.ajax({
            type: 'POST',
            url: '<?= base_url('/updatesupplierData') ?>',
            data: $(this).serialize(),
            success: function (res) {
                $('#updatesupplier').html(res);
                setTimeout(function(){
                     window.location.reload();
                },1000)
            },
            error: function () {
                $('#updatesupplier').html('<div class="alert alert-danger">Error! Couldn\'t update Supplier Info.</div>');
            }
        });
        //alert($(this).serialize());
        e.preventDefault();
    });
</script>