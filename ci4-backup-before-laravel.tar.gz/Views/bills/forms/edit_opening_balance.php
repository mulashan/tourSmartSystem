<?php
//print_r($data);
$bmodel = new App\Models\BillingModel();
   $amodel = new App\Models\AdmissionModel();
$bank1 = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 9));
$lg1 = $amodel->get_student_details('ledger_transaction_tbl', $where = array('trans_no' => $data[0]->trans_number,'trans_type'=>$data[0]->trans_type_id,'transation_nature'=>2));
// $account1 = $amodel->get_student_details('accounts_tbl', $where = array('id' => $lg1[0]->ledger_id));


$bank = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 8));
$lg = $amodel->get_student_details('ledger_transaction_tbl', $where = array('trans_no' => $data[0]->trans_number,'trans_type'=>$data[0]->trans_type_id,'transation_nature'=>1));
// $account= $amodel->get_student_details('accounts_tbl', $where = array('id' => $lg[0]->ledger_id));
?>

                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="card card-lg">
                            <div class="card-header"  style="height:5px">
                                <h3 class="card-title">Edit Opening Balance Details</h3>
                                <div class="card-options ">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                                <hr>
                    <div class="card-body">
                    <form class="form-horizontal" id="Opening_details_edit" >
                         <div id="feedback"></div>
                         <div class="row">
                            <div class="col-md-6">
                                
                       

                             <div class="form-group row">
                             	<input type="hidden" name="trans" value="<?= $data[0]->trans_number;?>">
                            <label for="inputpaidBy" class="col-sm-4 col-form-label"> Date</label>
                                <div class="col-sm-8">
                                <input type="date" id="open_date" name="open_date" value="<?php echo date('Y-m-d',strtotime($data[0]->trans_date));?>" class="form-control" required>
                                </div>
                                </div>

                                 <div class="form-group row" >
                                <label class="col-md-4 col-form-label"> Bank Ledger<span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <select name="debit_bank" id="debit_bank" class="form-control" required="required">
                              
                                        <?php foreach ($bank1 as $ac): ?>
                                        	<?php
                                         if($lg1[0]->ledger_id==$ac->id){
                                         	?>
                                  <option value="<?= $ac->id; ?>" selected><?= $ac->account_name; ?></option>
                                         	<?php
                                         }else{
                                        	?>
                                            <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                        <?php
                                        } 

                                    endforeach ?>
                                    </select>
                                </div>
                            </div>


                                     <div class="form-group row">
                                    <label for="inputpaidBy" class="col-sm-4 col-form-label">Amount<span class="text-danger">*</span></label>
                                <div class="col-sm-8">
                                <input type="text" id="amount" name="amount" class="form-control" value="<?php echo $lg1[0]->amount;?>" required>
                              </div>
                                </div>

                                   <div class="form-group row">
                                    <label for="inputpaidBy" class="col-sm-4 col-form-label">Description<span class="text-danger">*</span></label>
                                <div class="col-sm-8">
                                <textarea class="form-control" id="desc" name="desc" rows="5"><?= $data[0]->trans_desc;?></textarea>
                              </div>
                                </div>

                            <div class="form-group row" >
                                <label class="col-md-4 col-form-label">Equity Ledger<span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <select name="credit_bank" id="credit_bank" class="form-control" required="required">
                                        <?php foreach ($bank as $ac): ?>
                                        	<?php
                                         if($lg[0]->ledger_id==$ac->id){
                                         	?>
                                  <option value="<?= $ac->id; ?>" selected><?= $ac->account_name; ?></option>
                                         	<?php
                                         }else{
                                        	?>
                                            <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                        <?php
                                        } 

                                    endforeach ?>
                                    </select>
                                </div>
                            </div>

                   
            </div>   
                                   
        </div>

                    <!-- Here starts the form for accounts payable  -->
                        <!-- Here it ends the payable accounts --> 
                         <div class="form-group row">
                            <div class="col-md-8">
                                <button type="submit" id="create_bill" class="btn btn-primary float-right">Update</button>
                            </div>
                        </div>
                        </form>
                            </div>
                        </div>
                        
                    </div>
                </div>
            <script type="text/javascript">
            	
            	$('#Opening_details_edit').submit(function(e){ 
        
        var form_data = $(this).serialize()+'&'+$("#header_form").serialize();
        // alert(form_data);
       $.ajax({
            method: 'POST',
           url: '<?php echo base_url() . '/index.php/BillController/update_opening_balances'; ?>',
            data: form_data,
           
            success:function(res){
            
                var data = JSON.parse(res);
                if(data['status'] == "1"){
                    swal('success','updated successfully!','success');
                    setTimeout(function(){
                        window.location.reload();
                    },1500)
                }else{
                 //   $('#create_bill').prop("disabled", true);
                    swal('error','Sorry! Something went wrong!','error');
                }
            },
            error:function(res){
                swal('error','Sorry! Something went wrong!','error');
                setTimeout(function(){
            //window.location.reload();
                },1000)
            }
        });

        e.preventDefault();
    
    });
            </script>
