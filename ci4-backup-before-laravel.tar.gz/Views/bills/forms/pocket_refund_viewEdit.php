<style>
input[type="checkbox"] {
  transform: scale(1); /* Adjust the scale as needed */
-webkit-transform: scale(1.5); /* For Safari */
 border-color: red;
        }

    </style>

 <?php
 helper('age');
  $amodel = new App\Models\AdmissionModel();
 $smodel = new App\Models\StudentModel();
$remodel = new App\Models\ReportsModel();
 $bmodel = new App\Models\BillingModel();
  
  $cmodel = new App\Models\ClassesModel();
 $report = new App\Models\ReportsModel();
  $student = $smodel->gettable_data('students', $where = array('status' => 1));
    $admission = $smodel->gettable_data('admission_tbl', $where = array('status' => 1,'admission_type' => 0));
    $prc = $smodel->gettable_data('price_tbl', $where = array('item_id' => 65));
   
 ?>
                <div class="card">
                   <form id="list_form">
                        <div class="table-responsive mt-3">
                            <input type="hidden" name="year" value="<?php echo $year;?>">
                           
                             <?php if(count($bd_val)>0){ ?>
                                <div class="form-group row" id="all_input" style="display:none;">
                              <div class="col-md-6 form-group row">
                                <label for="inputpaidBy" class="col-sm-2 col-form-label"> Amount</label>
                            <div class="col-sm-4">
                                 <input type="text" id="allinput_id" value="" class="form-control" onkeyup="AllCalc()">
                         </div>
                         </div>
                        
                        <div class="col-md-6">
                            <div id="bank_details"></div>
                            </div>
                            </div>
                             <button type="button" id="saveRefund" onclick="createRefund()" class="btn btn-primary btn-lg pull-right me-5"><i class="fa fa-plus"> </i> Add</button>
                               <?php }?>
                            <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable2">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                       
                                        <th>Permit No.</th>
                                      
                                       <th>Student Name</th>
                                        <th>DoB</th>
                                        <th>Age</th>
                                        <th>Level</th>
                                        <th>Class</th>
                                        <th>Stream</th>
                                        <th>Hostel Name</th>
                                        <th>P/Balance</th>
                                        
                                        <th>Pay</th>
                                      
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $holid_student=array();
                                    $item_list = array();
                                    if(count($bd_val)>0){
                                    $sn = 0;
                                    
                                    foreach ($bd_val as $adm){

                                     $used = $amodel->get_student_details('pocket_money_transaction_tbl', $where = array('student_id' => $adm->student_id,'academic_year'=>$year,'transaction_no'=>$vouch_number));
                                     if(count($used)>0){
                                        continue;
                                     }

                                     $std = $amodel->get_student_details('students', $where = array('id' => $adm->student_id));
                                      if(count($std)==0){
                                            continue;
                                        }
                                         $holid_student[]=array($adm->student_id);
                                        $room = $amodel->get_student_details('classes_tbl', $where = array('id' => $adm->class_id));
                                        $strm = $amodel->get_student_details('streams_tbl', $where = array('id' => $adm->stream_id));
                                        $user = $amodel->get_student_details('users', $where = array('user_id' => $adm->admitted_by));
                                        $level = $amodel->get_student_details('class_level_tbl', $where = array('id' => $adm->level_id));
                                        $pid = $amodel->get_student_details('boarding_tbl', $where = array('student_id' => $adm->student_id,'academic_year'=>$year));
         if(count($pid)==0){
        continue;
            }else{
             $pid=1;
            }

                                $pid2 = $amodel->get_student_details('boarding_tbl', $where = array('student_id' => $adm->student_id,'academic_year'=>$year));

                                        if($pid2[0]->hostel==0){
                                         $hostelname='';
                                        }else{
                                        $hostel=$amodel->get_student_details('hostel_tbl', $where = array('id' => $pid2[0]->hostel));
                                           $hostelname=$hostel[0]->hostel_name;
                                    }

                              $col='';
                               $dbal = $remodel->refund_pocket_money($adm->student_id);
                                 if(count($dbal)>0){
                                    $collected=0;
                                    $used_amount=0;
                                    $bamount=0;
                                   foreach($dbal as $bal){

                                  $check_y=$amodel->get_student_details_byYear('transaction_numbers_tbl', $where = array('trans_number' => $bal->trans_no,'trans_type_id'=>3,'status'=>1), $year);
                                 if(count($check_y)>0){
                                    $collected+=$bal->amount;
                                 }
                                 }

                 $check_used = $amodel->get_student_details('pocket_money_transaction_tbl', $where = array('student_id' => $adm->student_id,'academic_year'=>$year));

                    if(count($check_used)>0){
                     foreach($check_used as $used){     
                   $used_amount+=$used->amount_given;  
                     }
                     }
                   $bamount=$collected-$used_amount;   
                    
                 if($bamount==0){
                   continue;
                   } 
                 $sn++;
                 $item_list[] = array($sn);

                   ?>

                            <input type="hidden" name="voucher[]" value="<?=$sn;?>">
                        <input type="hidden" name="trans_type<?=$sn;?>" value="3">
                        
                            <input type="hidden" name="student<?=$sn;?>" value="<?=$adm->student_id;?>">
                          
                                        <tr style="<?php echo "";?>" id="<?php echo $adm->student_id; ?>">
                                             <td><?= $sn;?></td>
                                            
                                            <td><?= $pid2[0]->permit_id;?></td>
                                        
                                     <td><?= $std[0]->first_name.' '.$std[0]->middle_name.' '.$std[0]->last_name;?></td>
                                            <td><?= $std[0]->birth_date;?></td>
                                            <td><?= findAge($std[0]->birth_date);?>
                                        </td>
                                            <td><?= $level[0]->level_name;?></td>
                                            <td><?= $room[0]->class_name;?></td>
                                            <td><?= $strm[0]->stream_name;?></td>
                                            <td><?= $hostelname;?></td>
                                            <td class="text-right" id="bal<?= $sn;?>"><?= number_format($bamount);?></td>
                                          
                                              <td>
                                               <input type="text" class="form-control" style="width:100px;" id="amount<?= $sn;?>" onkeyup="AmtCalc('<?= $sn;?>')" value="" name="amount<?= $sn;?>">  
                                            </td>
                                        </tr>
                                    
                                <?php }
                                }}
                                ?>
                                </tbody>
                            </table>
                        </div>
                       
                    </form>
                </div>
               

<script type="text/javascript">
     $("#all_input").show();
       refreshCalc();
       
         function AllCalc(){
       // alert(i);
             var total=0;
            var amount=0;
            var balance=0;
           
            var input=$("#allinput_id").val().replace(/,/gi, "");
           
            if(input==""){
                input=0;
            }

             //var remember = document.getElementById("Allselected");
            
            
            
         var values=<?php echo json_encode($item_list);?>;
          for( var i = 0; i < values.length; i++){ 
          var id=values[i];

            var bal= $("#bal"+id).html().replace(/,/gi, "");
          if(parseInt(input) > parseInt(bal)){
           var myAmount = Number(String(input).slice(0, -1));
            //alert(myAmount);
           $("#amount"+id).val(myAmount.toLocaleString());
           toastr.info("Please enter amount less or equal to " + bal);

           // $("#amount"+id).val(parseInt(input).toLocaleString());
         // alert(id);
           amount=$("#amount"+id).val().replace(/,/gi, "");
           if(amount !=""){
            total=total+parseInt(amount);
           }

            }else{
            $("#amount"+id).val(parseInt(input).toLocaleString());
         // alert(id);
           amount=$("#amount"+id).val().replace(/,/gi, "");
           if(amount !=""){
            total=total+parseInt(amount);
           }
           
            }
        }
          //alert(total);
          
          balance= $("#balance").html().replace(/,/gi, "");
          balance=parseInt(balance)-total;
          // alert(balance);
          $("#after").html(balance.toLocaleString());
          $("#thispay").html(total.toLocaleString());
      
      
  }
          function AmtCalc(i){
       // alert(i);
             var total=0;
            var amount=0;
            var balance=0;
            var bal= $("#bal"+i).html().replace(/,/gi, "");
            var input=$("#amount"+i).val().replace(/,/gi, "");
           
            if(input==""){
                input=0;
            }

             
            
            if(parseInt(input) > parseInt(bal)){
           var myAmount = Number(String(input).slice(0, -1));
            //alert(myAmount);
           $("#amount"+i).val(myAmount.toLocaleString());
           toastr.info("Please enter amount less or equal to " + bal);
            }else{
            $("#amount"+i).val(parseInt(input).toLocaleString());
            
         var values=<?php echo json_encode($item_list);?>;
          for( var i = 0; i < values.length; i++){ 
          var id=values[i];
         // alert(id);
          
           amount=$("#amount"+id).val().replace(/,/gi, "");
           if(amount !=""){
            total=total+parseInt(amount);
           }
           
            }
          //alert(total);
          
          balance= $("#balance").html().replace(/,/gi, "");
          balance=parseInt(balance)-total;
          // alert(balance);
          $("#after").html(balance.toLocaleString());
          $("#thispay").html(total.toLocaleString());
      }
      }

      function refreshCalc(){
       var bank_id=$('#bank_id').val();
       //alert(bank_id);
       $('#bank_details').load("<?php echo base_url() . '/index.php/BillController/bank_payments'; ?>/"+bank_id);

         var total=0;
            var amount=0;
            var balance=0;
         var values=<?php echo json_encode($item_list);?>;
          for( var i = 0; i < values.length; i++){ 
          var id=values[i];
         // alert(id);
           amount=$("#amount"+id).val().replace(/,/gi, "");
           if(amount !=""){
            total=total+parseInt(amount);
           }
           
            }
          //alert(total);
          
          balance= $("#balance").html().replace(/,/gi, "");
          balance=parseInt(balance)-total;
           //alert(balance);
          $("#after").html(balance.toLocaleString());
          $("#thispay").html(total.toLocaleString());
      }
      
      function createRefund(){
        var payed= $("#thispay").html();
         if(payed==0){
       toastr.error("Please! This payment amount is 0");
       }else{
     var data= $("#list_form").serialize()+"&"+$("#voucher_form").serialize()+"&"+$("#header_form").serialize()+'&trans='+$('#trans').val();
       // alert(data);
       //  return;
     
     $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillController/update_refund_pocketMoney'; ?>',
            data: data,
            success: function (res) {
              var data = JSON.parse(res);
              if(data['status'] == "1"){
                //$("#voucher_type").change();
              //  $("#bank").change();
                 $('#all_list').html('');
                 refresh_refund();
                 
             swal("success",data['description'],"success");
              //refreshCalc();
            }else{
             swal("error","Failed to create Payment","error");    
            }
            },
            error: function (){
                alert('error encounted');
            }
        });

       }
      }

      function refresh_refund() {
            var trans_no =$('#trans').val();
           var data = 'trans_no=' + trans_no+'&trans_type='+5+'&vocher='+1;
           //alert(dta);
           // return;
            $.ajax({
                type: "POST",
               url: "<?= base_url('/index.php/BillController/get_edit_approval_data')?>",
                 data: data,
                success: function (res) {
                     $('#Viewapproval').html(res);
                },
                error: function () {
                    $('#Viewapproval').html('<div class="alert alert-warning">Fail to retreive results.!!</div>');
                }
            });

  
    };
</script>