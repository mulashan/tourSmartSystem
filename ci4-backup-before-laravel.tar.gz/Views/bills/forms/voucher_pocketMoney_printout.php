

 <?php
 $amodel = new App\Models\AdmissionModel();
  $billmodel = new App\Models\BillModel();
  $bmodel = new App\Models\BillingModel();
  $cmodel = new App\Models\ClassesModel();
  $appItems = $cmodel->get_applications_items();
  $remodel =new App\Models\ReportsModel();
  $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'trans_type' =>5));
  //$invoice_type = $bmodel->get_item_join_table($recpt[0]->trans_number);
  $student_name = "";
  $name_type = "";
if(count($leger_transaction) > 0){
    $amount = $leger_transaction[0]->amount;
    if($leger_transaction[0]->name_type_id == 4){
        $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $itm_details = $bmodel->get_item_name('item_transation_tbl',$where = array('trans_number' =>$recpt[0]->trans_number));
    }
    else if($leger_transaction[0]->name_type_id == 3){
    $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
     $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
      $student_id = $app[0]->id;
       $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
            $name_type = $type_name[0]->name_type;
              $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2));
   }else if($leger_transaction[0]->name_type_id == 1){
        $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        
        $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2,'transation_nature' =>1));
   }else if($leger_transaction[0]->name_type_id == 2){
        $app = $bmodel->get_item_name('supplier_tbl',$where = array('supplier_id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->supplier_name; 
        $student_id = $app[0]->supplier_id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        
       
   }else if($leger_transaction[0]->name_type_id == 7){
        $app = $bmodel->get_item_name('users',$where = array('user_id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->user_id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        
       
   }
  
    $company_reg = $bmodel->get_table_details('company_tbl');
 //   $pay_dtls = $bmodel->get_item_name('payment_response',$where = array('reference_no' =>$control_number));
   
   
}

 ?>
<div class="row">
<div class="col-md-12">
    <!-- <center><b style="font-size:14px"><u>RECEIPT</u></b></center> -->
    <center>
      <div> <img src="<?php  echo base_url('public/company_photos/'.$company_reg[0]->logo_name) ?>" style="background: white;width: 25%;height: 25%" ></div>
 <span class="mt-4"><b><?= $company_reg[0]->company_name; ?></b></span><br>
            <span class="modify" style="font-size:15px"><?= $company_reg[0]->address; ?></span>
            <div class="mb-3">
                <div><span class="modify" style="font-size:15px">Phone: +<?= $company_reg[0]->phone1; ?></span></div>
                <div><span class="modify" style="font-size:15px">Email: <?= $company_reg[0]->email; ?></span></div>
                <div><span class="modify" style="font-size:15px"> <?= $company_reg[0]->website; ?></span></div>
             
            </div>
   <span class="mt-3"> <b style="font-size:14px"><u>Pocket Money</u></b></span>
    </b>
</center>
    <hr>
    <table class="table table-borderless">
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <th>Payment Number:</th>
            <td class="text-right"><?= $recpt[0]->trans_number; ?></td>
           <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <th>Payment Date:</th>
            <td class="text-right"><?= date('d/m/Y',strtotime($recpt[0]->trans_date)); ?></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <th>Name Type:</th>
            <td class="text-right"><?= $name_type; ?></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <th>Payee Name:</th>
            <td class="text-right"><?= $student_name; ?></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <th>Amount</th>
            <td class="text-right"><?=  number_format($amount); ?></td>
           <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
    </table>
    <hr>
</div>
</div>    
    <div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
        <p class=" d-flex justify-content-center mt-3" style="font-size:18px">PAYMENT DETAILS</p>
       
                <?php ?>
                    <table class="table">
                    <thead>
                        <tr>
                            <th>TYPE</th>
                          
                            <th>NAME</th>
                            <th>BALANCE</th>
                            <th>Paid</th>
                            <th>Signature</th>
                        </tr>
                    </thead>
                    <tbody>
                   <?php
                        $total =0;
                        $amount = 0;
                        //echo $inv[0]->trans_number;
                         // $v_transaction = $billmodel->get_item_name('voucher_relation_tbl',$where = array('payment_no' =>$recpt[0]->trans_number));
                         //print_r($v_transaction);
                         $pocketMoney = $billmodel->get_item_name('pocket_money_transaction_tbl',$where = array('transaction_no' =>$recpt[0]->trans_number,));
                          $total_given=0; 
                foreach ($pocketMoney as $value) {
                             
                $dbal = $remodel->refund_pocket_money($value->student_id);
                     $collected=0;
                     $usedAmount=0;
                    foreach($dbal as $pmn){
                         $check_y=$amodel->get_student_details_byYear('transaction_numbers_tbl', $where = array('trans_number' => $pmn->trans_no,'trans_type_id'=>3,'status'=>1), $value->academic_year);
                        // $check_y=$billmodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $pmn->trans_no,'trans_type_id'=>3,'status'=>1,'trans_desc !='=>""));
                         if(count($check_y)>0){
                            $collected+=$pmn->amount;

                            }
                            }

                    $check_used = $bmodel->get_item_name('pocket_money_transaction_tbl', $where = array('student_id' => $value->student_id,'academic_year'=>$value->academic_year));

                 if(count($check_used)>0){
                      foreach($check_used as $used){
                     $usedAmount+=$used->amount_given;    
                                
                      }
                      }
                       $balance1=$collected-$usedAmount;
                         $balance=$value->p_balance;
                         $total_given+=$value->amount_given;

                          $apps = $bmodel->get_item_name('students',$where = array('id'=>$value->student_id));
                       $sname = $apps[0]->full_name;

                       // $balance = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$value->trans_used,'trans_type'=>3,'transation_nature'=>2));
                        
                       //   $total=$total+$value->amount_given;
                            ?>
                            <tr>
                                <td>P/Money</td>
                             
                                 <td><?=$sname??""?></td>
                            <td><?= number_format($balance)??""; ?></td>
                                <td><?= number_format($value->amount_given)??""; ?></td>
                             <td class="black" style="border-bottom: 1px solid black;"></td>
                            </tr>
                   <?php 
                     }
                $dbname=session()->get('db_name');
                   
                   ?>
                 <tr>
                     <td colspan="3"><b>Total</b></td>
                    <!-- <th><b></b></th>
                    <th><b></b></th> -->
                    <th class="text-right"><b><?= number_format($total_given); ?></b></th>
                </tr>   
            </tbody>
        </table>
      
   
    </div>
    </div> 
    <?php
   
 
    ?>  
<div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
       
        <table>
        <?php
        $leg = $bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$recpt[0]->trans_number,'trans_type_id' =>5));
     $recv = $bmodel->get_item_name('users',$where = array('user_id' =>$leg[0]->updated_by));

      $app_numb = $bmodel->get_item_name('approval_numbers',$where = array('trans_no' =>$recpt[0]->trans_number,'trans_type' =>5));
      $approved = $bmodel->get_item_name('approval_history',$where = array('app_no' =>$app_numb[0]->app_id,'hstatus' =>1));

        ?>
        
        <tr>
            <td><i>Prepared by: <?php echo $recv[0]->first_name." ".$recv[0]->last_name." ".$leg[0]->updated_date ?></i></td>
        </tr>
        <?php 
        if(count($approved)>0){
      $user_name = $bmodel->get_item_name('users',$where = array('user_id' =>$approved[0]->user));
        ?>
        <tr>
            <td><i>Approved by: <?php echo $user_name[0]->first_name." ".$user_name[0]->last_name." ".$approved[0]->hist_date ?></i></td>
        </tr>
        <?php
          }
        ?>
    </table>  

    </div>
</div> 
<br>
<center>
    <i><span>Powered by Micro Health Initiative</span></i>
</center>
<script>
function printable_rept(area) {
  var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
  disp_setting += "scrollbars=yes,width=750, height=600, left=80, top=25";
  var content_value = document.getElementById(area).innerHTML;

  var docprint = window.open("", "", disp_setting);
  docprint.document.open();
  docprint.document.write('<html><head><title>MHI</title>');

  // Add a <style> block to set the font family and other print-specific styles
  docprint.document.write('<style>');
  docprint.document.write('@media print {');
  docprint.document.write('  body {');
  docprint.document.write('    font-family: "Times New Roman", sans-serif;');
  docprint.document.write('    font-size: 15px;');
  docprint.document.write('  }');
  nw.document.write('.black { border-bottom: 1px solid black; }'); 

  docprint.document.write('</style>');

  docprint.document.write('</head><body onLoad="self.print()" style="width:100%;">');

  // Modify content_value to include the colspan attribute
  var modifiedContent = content_value.replace('<td class="colspan-cell">', '<td colspan="2" class="colspan-cell">');
  docprint.document.write(modifiedContent);

  docprint.document.write('</body></html>');
  docprint.document.close();
  docprint.focus();
}

</script>



