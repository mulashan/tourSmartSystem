<?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\AdmissionModel();
 $remodel = new App\Models\ReportsModel();
 //echo $thedate;
   $bank = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 9,'id'=>$from));

           $s='01-01-2020';
            $today=date("Y-m-d");
            $end =strtotime($today);
            $std = strtotime($s);
            $dis="none"; 

     $balanceto=0;
   if($to !=0){
    $dis="";   
   $tobank = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 9,'id'=>$to));

        
             
            // echo date('Y-m-d',$end);
            $before2 = $imodel->getSingle_view3($to,date('Y-m-d', $std),date('Y-m-d', $end));
            //print_r($before);
          
            foreach($before2 as $bt){
              if($bt->transation_nature==2){
                $balanceto=$balanceto+$bt->amount;
              }else{
              //  echo $balanceb;
               $balanceto=$balanceto-$bt->amount;
              }
             }
          }


  //calculating balance before the date----
            
            // echo date('Y-m-d',$end);
            $before = $imodel->getSingle_view3($from,date('Y-m-d', $std),date('Y-m-d', $end));
            //print_r($before);
            $balanceb=0;
            foreach($before as $bf){
              if($bf->transation_nature==2){
                $balanceb=$balanceb+$bf->amount;
              }else{
              //  echo $balanceb;
               $balanceb=$balanceb-$bf->amount;
              }
             }
             
           //-------end calculation----------
                       
 ?>
         
                 <table class="table table-hover table-vcenter mb-0 text-nowrap">
                   <tr>
                     <td></td>
                     <td>Bal Before</td>
                     <td>Transfer</td>
                     <td>Bal After</td>
                   </tr>
                   <tbody id="detail">
                    <tr>
                     <td>From: <?= $bank[0]->account_name;?></td>
                     <td class="text-right" id="bal_before"><?php echo number_format($balanceb);?></td>
                     <td class="text-right" id="transfer_from">0</td>
                     <td class="text-right" id="balance_from"><?php echo number_format($balanceb);?></td>
                   </tr>
                   <tr style="display: <?= $dis;?>;">
                     <td>To: <?= $tobank[0]->account_name??"";?></td>
                     <td class="text-right" id="bal_after"><?php echo number_format($balanceto);?></td>
                     <td class="text-right" id="transfer_to">0</td>
                     <td class="text-right" id="balance_to"><?php echo number_format($balanceto);?></td>
                   </tr>
                   </tbody>
                 </table>

                 <div id="save_btn" style="display:none;">
                    <button type="button" id="saveRefund" onclick="createTransfer()" class="btn btn-primary btn-lg pull-right me-5 mt-3"><i class=""> </i> Create</button>
                 </div>