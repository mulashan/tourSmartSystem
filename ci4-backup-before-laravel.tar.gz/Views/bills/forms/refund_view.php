    <?php
 $bmodel = new App\Models\BillingModel();
 $bill = new App\Models\BillModel();
?>                            <form id="list_form">
                   <?php
                  $list_type="";
                  $bill_type=0;
                    if(count($list)>0){
                        if($list[0]->trans_type==4){
                            $bill_type=4;
                            $list_type="Bills List";
                        }else{
                          $list_type="Refund List";   
                        }
                   ?>
                                <div class="pull-right mt-3 mb-3">
                                        <button type="button" class="btn btn-primary pull-left me-3" id="create" onclick="createRefund()"> Create</button>
                                        
                                        </div>
                        <?php }?>
                               <div class="card">

                                    <p Class=" d-flex justify-content-center mt-3"> <?php
                                    echo $list_type;
                                   ?></p>

                                    <table class="table table-hover table-vcenter mb-0 text-nowrap" id="table">
                                    <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Type</th>
                                                <th>Trans type</th>
                                                 <?php
                                            if($bill_type==4){
                                               ?>
                                             <th>Bill Ref</th>
                                             <th>Due date</th>
                                               <?php
                                                }
                                                ?>
                                                <th>Trans date</th>
                                                <th>Trans No</th>
                                                 <th>Name</th>
                                                <th>Amount</th>
                                                 <th>Balance</th>
                                                <th>Pay</th>
                                                 
                                                
                                            </tr>
                                    </thead>
                                    <tbody id="show_item">
                                        <?php
                                        $item_list = array();
                                        $i=0;
                                        if(count($list)>0){
                                    foreach ($list as $st) {
                            if($st->trans_type==6){
                                 $trans_type="Credit Note";
                            $trans=$bill->get_all_credits($st->trans_no);
                            if(count($trans)==0){
                                continue;
                            }
                            $st->invoice_type_id=$trans[0]->invoice_type_id;
                            $st->type_name=$trans[0]->type_name;
                            $st->amount=$trans[0]->amount;
                            $st->balance=$trans[0]->balance;

                             }else if($st->trans_type==2) {
                        // $trans=$bill->get_student_overpayment($st->name_id);
                                if($receipt==1){
                                $trans_type="Receipt"; 
                                }else{
                                $trans_type="Overpayment"; 
                                } 

                         
                             }else if($st->trans_type==4){
                             $trans_type="Bill";
                             if($st->name_type_id==2){
                             $trans=$bill->get_item_name('supplier_tbl',$where = array('supplier_id'=>$st->name_id,));
                             $st->full_name=$trans[0]->supplier_name;

                             }else if($st->name_type_id==1){
                             $trans=$bill->get_item_name('students',$where = array('id'=>$st->name_id,));
                             $st->full_name=$trans[0]->full_name;

                             }else if($st->name_type_id==5){
                                
                             }else{

                             }
                            

                             }else{
                            continue;
                             }
                                 //if(count($trans)>0){
                                     $i++;
                                    $item_list[] = array($i);
                                   
                                   
                                    ?>
                                    
                            <input type="hidden" name="voucher[]" value="<?=$i;?>">
                        <input type="hidden" name="trans_type<?=$i;?>" value="<?=$st->trans_type;?>">
                         <input type="hidden" name="isreceipt<?=$i;?>" value="<?=$receipt;?>">
                            <input type="hidden" name="trans_no<?=$i;?>" value="<?=$st->trans_no;?>">
                            <input type="hidden" name="student_id<?=$i;?>" value="<?=$st->name_id;?>">
                            <input type="hidden" name="name_type_id<?=$i;?>" value="<?=$st->name_type_id;?>">
                             <input type="hidden" name="invoice_type<?=$i;?>" value="<?=$st->invoice_type_id;?>">
                            
                                <tr id="">
                                 <td><?=$i;?>.</td>
                                 <td><?=$st->type_name;?></td>
                                 
                                 <td><?=$trans_type;?></td>
                                  <?php
                                  if($st->trans_type==4){
                                   ?>
                                 <td><?=$st->bill_reference;?></td>
                                 <td><?=$st->due_date;?></td>
                                   <?php
                                    }
                                    ?>
                                 <td><?=$st->trans_date;?></td>
                                 <td><?=$st->trans_no;?></td>
                                 <td><?=$st->full_name;?></td>
                                 <td class="text-right"><?=number_format($st->amount);?></td>
                                 <td class="text-right" id="bal<?= $i;?>"><?=number_format($st->balance);?></td>
                                 <td>
                                    <input type="text" class="form-control" style="width:100px;" id="amount<?= $i;?>" onkeyup="AmtCalc('<?= $i;?>')" value="" name="amount<?= $i;?>"></td>
                             </tr>
                                <?php
                                // }
                                  ?>
                                 
                                  <?php
                                     }
                                 }else{
                                    echo "<tr><td>No any transaction found</td><tr>";
                                 }
                                       
                                        ?>
                                     
                                    </tbody>
                                    </table>
                                    <table>
                                        <tr>
                                        <th class="col-sm-8"></th>
                                 
                                        </tr>
                                        </table>
                                       <!--  <div class="pull-left mt-3 mb-3">
                                        <button type="button" class="btn btn-primary pull-left me-3 ms-4" id="credit" onclick="credit()"> Use Credit</button>
                                        <button type="button" class="btn btn-primary pull-left" id="overpayment" onclick="overpayment()"> Use OverPayment</button>
                                        </div> -->
                                </div>
                                 </form>

      <script type="text/javascript">
       refreshCalc();
          function AmtCalc(i){
        // alert(0);
             var total=0;
            var amount=0;
            var balance=0;
            var bal= $("#bal"+i).html().replace(/,/gi, "");
            var input=$("#amount"+i).val().replace(/,/gi, "");
            //alert(input+"/"+bal);
            if(input==""){
                input=0;
            }
            if(parseInt(input) > parseInt(bal)){
           var myAmount = Number(String(input).slice(0, -1));
            //alert(myAmount);
           $("#amount"+i).val(myAmount.toLocaleString());
           toastr.info("Please enter amount less or equal to " + bal);
            }else{
            $("#amount"+i).val(parseInt(input).toLocaleString());
            
         var values=<?php echo json_encode($item_list);?>;
          for( var i = 0; i < values.length; i++){ 
          var id=values[i];
         // alert(id);
           amount=$("#amount"+id).val().replace(/,/gi, "");
           if(amount !=""){
            total=total+parseInt(amount);
           }
           
            }
          //alert(total);
          
          balance= $("#balance").html().replace(/,/gi, "");
          balance=parseInt(balance)-total;
          // alert(balance);
          $("#after").html(balance.toLocaleString());
          $("#thispay").html(total.toLocaleString());
      }
      }

      function refreshCalc(){
         var total=0;
            var amount=0;
            var balance=0;
         var values=<?php echo json_encode($item_list);?>;
          for( var i = 0; i < values.length; i++){ 
          var id=values[i];
         // alert(id);
           amount=$("#amount"+id).val().replace(/,/gi, "");
           if(amount !=""){
            total=total+parseInt(amount);
           }
           
            }
          //alert(total);
          
          balance= $("#balance").html().replace(/,/gi, "");
          balance=parseInt(balance)-total;
          // alert(balance);
          $("#after").html(balance.toLocaleString());
          $("#thispay").html(total.toLocaleString());
      }
      
      function createRefund(){
        var payed= $("#thispay").html();
        var customer_type=$('#customer_type').val();
        var bank=$('#bank').val();
        if(customer_type=="" || bank==""){
            if(customer_type==""){
       toastr.error("Please select paid to");
        }else{
        toastr.error("Please select bank");    
        }
        }else if(payed==0){
       toastr.error("Please! This payment amount is 0");
       }else{
     var data= $("#list_form").serialize()+"&"+$("#voucher_form").serialize()+"&"+$("#header_form").serialize();
     
     $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillController/process_refund_payments'; ?>',
            data: data,
            success: function (res) {
              var data = JSON.parse(res);
              if(data['status'] == "1"){
                //$("#voucher_type").change();
              //  $("#bank").change();
                 $('#all_list').html('');
             swal("success",data['description'],"success");
            }else{
             swal("error","Failed to create Payment","error");    
            }
            },
            error: function (){
                alert('error encounted');
            }
        });

       }
      }
      </script>