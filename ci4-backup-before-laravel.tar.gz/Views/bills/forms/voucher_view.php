

 <?php
  $billmodel = new App\Models\BillModel();
  $bmodel = new App\Models\BillingModel();
  $cmodel = new App\Models\ClassesModel();
  $appItems = $cmodel->get_applications_items();
  $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'trans_type' =>5));
  //$invoice_type = $bmodel->get_item_join_table($recpt[0]->trans_number);
  $student_name = "";
  $name_type = "";
if(count($leger_transaction) > 0){
    $amount = $leger_transaction[0]->amount;
    if($leger_transaction[0]->name_type_id == 4){
        $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $itm_details = $bmodel->get_item_name('item_transation_tbl',$where = array('trans_number' =>$recpt[0]->trans_number));
    }
    else if($leger_transaction[0]->name_type_id == 3){
    $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
     $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
      $student_id = $app[0]->id;
       $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
            $name_type = $type_name[0]->name_type;
              $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2));
   }else if($leger_transaction[0]->name_type_id == 1){
        $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        
        $ledger_invoice = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'ledger_type'=> 7,'trans_type' =>2,'transation_nature' =>1));
   }else if($leger_transaction[0]->name_type_id == 2){
        $app = $bmodel->get_item_name('supplier_tbl',$where = array('supplier_id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->supplier_name; 
        $student_id = $app[0]->supplier_id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        
       
   }else if($leger_transaction[0]->name_type_id == 7){
        $app = $bmodel->get_item_name('users',$where = array('user_id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->user_id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        
       
   }
  
    $company_reg = $bmodel->get_table_details('company_tbl');
 //   $pay_dtls = $bmodel->get_item_name('payment_response',$where = array('reference_no' =>$control_number));
   
   $vch = $billmodel->get_item_name('voucher_relation_tbl',$where = array('payment_no' =>$recpt[0]->trans_number));
   $v_type = $billmodel->get_item_name('voucher_types_tbl',$where = array('id' =>$vch[0]->voucher_type));

}

 ?>
 
<div class="row">
<div class="col-md-12">
    <!-- <center><b style="font-size:14px"><u>RECEIPT</u></b></center> -->
    <center>
      <div> <img src="<?php  echo base_url('public/company_photos/'.$company_reg[0]->logo_name) ?>" style="background: white;width: 25%;height: 25%" ></div>
 <span class="mt-4"><b><?= $company_reg[0]->company_name; ?></b></span><br>
            <span class="modify" style="font-size:15px"><?= $company_reg[0]->address; ?></span>
            <div class="mb-3">
                <div><span class="modify" style="font-size:15px">Phone: +<?= $company_reg[0]->phone1; ?></span></div>
                <div><span class="modify" style="font-size:15px">Email: <?= $company_reg[0]->email; ?></span></div>
                <div><span class="modify" style="font-size:15px"> <?= $company_reg[0]->website; ?></span></div>
             
            </div>
   <span class="mt-3"> <b style="font-size:14px"><u>PAYMENT VOUCHER</u></b></span>
    </b>
</center>
    <hr>
    <table class="table table-borderless">
        <tr>
            <th>voucher Number:</th>
            <td><?= $recpt[0]->trans_number; ?></td>
        </tr>
        <tr>
            <th>voucher Date:</th>
            <td><?= $recpt[0]->trans_date; ?></td>
        </tr>
        <tr>
            <th>Name Type:</th>
            <td><?= $name_type; ?></td>
        </tr>
        <tr>
            <th>Payee Name:</th>
            <td><?= $student_name; ?></td>
        </tr>
    </table>
    <hr>
</div>
</div>    
    <div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
        <p class=" d-flex justify-content-center mt-3" style="font-size:18px">PAYMENT DETAILS</p>
       
                <?php ?>
                    <table class="table">
                    <thead>
                        <tr>
                            <th>TYPE</th>
                            <th>TRANS NO</th>
                            <th>NAME</th>
                            <th>Amount</th>
                            <th>BALANCE</th>
                            <th>Amount Paid</th>
                        </tr>
                    </thead>
                    <tbody>
                   <?php
                        $total =0;
                        $amount = 0;
                        //echo $inv[0]->trans_number;
                         $v_transaction = $billmodel->get_item_name('voucher_relation_tbl',$where = array('payment_no' =>$recpt[0]->trans_number));
                         //print_r($v_transaction);
                          if($v_transaction[0]->trans_type==0){
                            $v_transaction[0]->trans_type=5;
                            $v_transaction[0]->trans_no=$v_transaction[0]->payment_no;
                         }
                          if($v_transaction[0]->trans_type==2){
                         $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type,'ledger_id'=>$leger_transaction[0]->ledger_id));
                         if($leger_transaction[0]->ledger_id==21){
                        $trans_type="Overpayment";
                         }else{
                         $trans_type="Receipt";
                         }
                          }else if($v_transaction[0]->trans_type==4){

                            $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type,'ledger_id'=>$leger_transaction[0]->ledger_id));
                            $trans_type="Bill";
                          }else if($v_transaction[0]->trans_type==0){

                            $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>5));
                            $trans_type="Sms Recharge";
                          }
                          else{
                          $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type)); 
                          if(count($bala_amount)==0){
                             $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>5));  
                          }
                          $traType = $billmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>$v_transaction[0]->trans_type));  
                          $trans_type=$traType[0]->type_name;
                          }
                         

                        $paid = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'trans_type'=>5,'transation_nature'=>2));
                         
                         
                        $invType = $billmodel->get_item_name('invoice_type_transaction',$where = array('trans_no' =>$v_transaction[0]->trans_no,'transaction_type_id'=>$v_transaction[0]->trans_type));
                        if(count($invType)==0){
                          $invType = $billmodel->get_item_name('invoice_type_transaction',$where = array('trans_no' =>$v_transaction[0]->trans_no,'transaction_type_id'=>5));  
                        }

                        // $invTypeName = $billmodel->get_item_name('invoice_types_tbl',$where = array('id' =>$invType[0]->invoice_type_id));

                        //  $transType = $billmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>5));

                        //  $transNumber = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$v_transaction[0]->trans_no,'trans_type_id'=>$v_transaction[0]->trans_type));
                        //  $total=$paid[0]->amount;
                           if(isset($invType) && !empty($invType)){
                        $invTypeName = $billmodel->get_item_name('invoice_types_tbl',$where = array('id' =>$invType[0]->invoice_type_id));

                         $transType = $billmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>5));

                         $transNumber = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$v_transaction[0]->trans_no,'trans_type_id'=>$v_transaction[0]->trans_type));
                         $type_names=$invTypeName[0]->type_name??"";
                        $trans_date= $transNumber[0]->trans_date??"";
                        }
                        else{
                         $transNumber = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$v_transaction[0]->trans_no,'trans_type_id'=>$v_transaction[0]->trans_type));
                            $type_names="Payroll";
                       $trans_date= $transNumber[0]->trans_date??""; 
                        }
                            ?>
                            <tr>
                                <td><?= $type_names; ?></td>
                              <td class=""><?= $v_transaction[0]->trans_no??""; ?></td>
                                 <td><?=$student_name??""?></td>
                                <td><?= number_format($bala_amount[0]->amount)??""; ?></td>
                                <td><?= number_format($paid[0]->balance)??""; ?></td>
                            <td class="text-right"><?= number_format($paid[0]->amount)??""; ?></td>
                            </tr>
                   <?php 
                $dbname=session()->get('db_name');
                   
                   ?>
                 <tr>
                     <td colspan="3"><b>Total</b></td>
                    <th><b></b></th>
                    <th><b></b></th>
                    <th class="text-right"><b><?= number_format($total); ?></b></th>
                </tr>   
            </tbody>
        </table>
      
   
    </div>
    </div> 
    <?php
   
 
    ?>  
<div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
        <p class=" d-flex justify-content-center mt-3" style="font-size:18px">PAYMENT BANK</p>
        <table class="table">
            <thead>
                <tr>
                    <th>BANK</th>
                    <th>Description</th>
                   <th class="text-right">AMOUNT</th>
                </tr>
            </thead>
            <tbody>
                <?php
                
                    $ledger2 = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'trans_type'=>5,'transation_nature'=>1));
                   $ledger22=$billmodel->get_item_name('accounts_tbl',$where = array('id' =>$ledger2[0]->ledger_id));
                ?>
                <tr>
                    <td><?=$ledger22[0]->account_name??""?></td>
                    <td><?=$v_transaction[0]->reason??""?></td>
                    
                    <td class="text-right"><?=number_format($ledger2[0]->amount)??""?></td>
                  </tr>
           
                
            </tbody>
        </table>   
           <p class=" d-flex justify-content-center mt-3" style="font-size:14px">.</p>
        <table>
        <?php
        $leg = $bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$recpt[0]->trans_number,'trans_type_id' =>5));
     $recv = $bmodel->get_item_name('users',$where = array('user_id' =>$leg[0]->updated_by));

        ?>
        
        <tr>
            <td><i>Refunded by: <?php echo $recv[0]->first_name." ".$recv[0]->last_name." ".$leg[0]->trans_date ?></i></td>
        </tr>
    </table>  

    </div>
</div> 
<br>
<center>
    <i><span>Powered by Micro Health Initiative</span></i>
</center>
<script>
function printable_rept(area) {
  var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
  disp_setting += "scrollbars=yes,width=750, height=600, left=80, top=25";
  var content_value = document.getElementById(area).innerHTML;

  var docprint = window.open("", "", disp_setting);
  docprint.document.open();
  docprint.document.write('<html><head><title>MHI</title>');

  // Add a <style> block to set the font family and other print-specific styles
  docprint.document.write('<style>');
  docprint.document.write('@media print {');
  docprint.document.write('  body {');
  docprint.document.write('    font-family: "Times New Roman", sans-serif;');
  docprint.document.write('    font-size: 15px;');
  docprint.document.write('  }');
  docprint.document.write('</style>');

  docprint.document.write('</head><body onLoad="self.print()" style="width:100%;">');

  // Modify content_value to include the colspan attribute
  var modifiedContent = content_value.replace('<td class="colspan-cell">', '<td colspan="2" class="colspan-cell">');
  docprint.document.write(modifiedContent);

  docprint.document.write('</body></html>');
  docprint.document.close();
  docprint.focus();
}

</script>



