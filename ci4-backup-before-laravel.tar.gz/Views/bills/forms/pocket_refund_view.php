<style>
input[type="checkbox"] {
  transform: scale(1); /* Adjust the scale as needed */
-webkit-transform: scale(1.5); /* For Safari */
 border-color: red;
        }

    </style>
 <?php
 helper('age');
  $amodel = new App\Models\AdmissionModel();
 $smodel = new App\Models\StudentModel();
$remodel = new App\Models\ReportsModel();
 $bmodel = new App\Models\BillingModel();
  
  $cmodel = new App\Models\ClassesModel();
 $report = new App\Models\ReportsModel();
  $student = $smodel->gettable_data('students', $where = array('status' => 1));
    $admission = $smodel->gettable_data('admission_tbl', $where = array('status' => 1,'admission_type' => 0));
    $prc = $smodel->gettable_data('price_tbl', $where = array('item_id' => 65));
   
 ?>
                <div class="card">
                   <form id="list_form">
                        <div class="table-responsive mt-3">
                            <input type="hidden" name="year2" value="<?php echo $year;?>">
                           
                             <?php if(count($bd_val)>0){ ?>
                                <!-- <div class="mt-1">
                                <input type="checkbox" name="" value="" id="Allselected" style="width:30px">
                                <span class="me-3">All Students</span>
                                </div> -->
                             <button type="button" id="saveRefund" onclick="createRefund()" class="btn btn-primary btn-lg pull-right me-5"><i class=""> </i> Create</button>
                               <?php }?>
                            <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable2">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                       
                                        <th>Permit No.</th>
                                        <th>Permit. Date</th>
                                       <th>Student Name</th>
                                        <th>DoB</th>
                                        <th>Age</th>
                                        <th>Level</th>
                                        <th>Class</th>
                                        <th>Stream</th>
                                        <th>Hostel Name</th>
                                        <th>P/Balance</th>
                                        
                                        <th>Pay</th>
                                      
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $holid_student=array();
                                    $item_list = array();
                                    if(count($bd_val)>0){
                                    $sn = 0;
                                    //print_r($bd_val);
                                    foreach ($bd_val as $adm){
                                     $std = $amodel->get_student_details('students', $where = array('id' => $adm->student_id));
                                      if(count($std)==0){
                                            continue;
                                        }
                                        // if($std[0]->status !=2){
                                        //     continue;
                                        // }
                                     
                                        //print_r($bd_val);
                                    
                                        $holid_student[]=array($adm->student_id);
                                        $room = $amodel->get_student_details('classes_tbl', $where = array('id' => $adm->class_id));
                                        $strm = $amodel->get_student_details('streams_tbl', $where = array('id' => $adm->stream_id));
                                        $user = $amodel->get_student_details('users', $where = array('user_id' => $adm->admitted_by));
                                        $level = $amodel->get_student_details('class_level_tbl', $where = array('id' => $adm->level_id));
                                        $pid = $amodel->get_student_details('boarding_tbl', $where = array('student_id' => $adm->student_id,'academic_year'=>$year));
         if(count($pid)==0){
        $pid=0;
          // $ino = "";
        $tkens = $smodel->get_max_id('boarding_tbl','permit_id');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        
$date = new DateTime($adm->date_joined); // Your initial date
$date->add(new DateInterval('P11M'));
$enddate= $date->format('Y-m-d');
          $data = [
                    'student_id' => $adm->student_id,
                    'academic_year' => $adm->academic_year,
                    'permit_id' => $ino,
                    'admission_type' => $adm->adimit_for,
                    'hostel' => $adm->hostel_id,
                    'month' => 11,
                    'start_date' => $adm->date_joined,
                    'end_date' =>$enddate,
                      'created_date' =>  $adm->date_joined,
                    'created_by' =>3,
                    'status ' => 1
                   
                ];
                $save= $amodel->SaveDetails('boarding_tbl',$data);
            }else{
             $pid=1;
            }
                                $pid2 = $amodel->get_student_details('boarding_tbl', $where = array('student_id' => $adm->student_id,'academic_year'=>$year));

                                        if($pid2[0]->hostel==0){
                                         $hostelname='';
                                        }else{
                                        $hostel=$amodel->get_student_details('hostel_tbl', $where = array('id' => $pid2[0]->hostel));
                                           $hostelname=$hostel[0]->hostel_name;
                                    }

                             // $dbal = $remodel->refund_pocket_money('ledger_transaction_tbl', $where = array('name_id' => $adm->student_id,'name_type_id'=>1,'trans_type'=>3,'trans_item'=>65));
                             $dbal = $remodel->refund_pocket_money($adm->student_id);
                             //print_r($dbal);
                            //   echo $adm->student_id;
                            //              echo ",";

                                 $col='';
                                 if(count($dbal)>0){
                                      echo $adm->student_id;
                                         echo ",";
                                    $collected=0;
                                    $used_amount=0;
                                    $bamount=0;
                                   foreach($dbal as $bal){

                                 $check_y=$amodel->get_student_details_byYear('transaction_numbers_tbl', $where = array('trans_number' => $bal->trans_no,'trans_type_id'=>3,'status'=>1), $year);
                                 if(count($check_y)>0){
                                    $collected+=$bal->amount;
                                 }
                                 }

                 $check_used = $amodel->get_student_details('pocket_money_transaction_tbl', $where = array('student_id' => $adm->student_id,'academic_year >='=>$year));

                    if(count($check_used)>0){
                     foreach($check_used as $used){     
                   $used_amount+=$used->amount_given;  
                     }
                     }
                   $bamount=$collected-$used_amount;   
                    
                 if($bamount==0){
                   continue;
                   } 
                 $sn++;
                 $item_list[] = array($sn);

                   ?>

                            <input type="hidden" name="voucher[]" value="<?=$sn;?>">
                        <input type="hidden" name="trans_type<?=$sn;?>" value="3">
                         <input type="hidden" name="isreceipt<?=$sn;?>" value="0">
                            <!-- <input type="hidden" name="trans_no<?=$sn;?>" value="<?=$sn;?>"> -->
                            <input type="hidden" name="student_id" value="<?=$staff_id;?>">
                            <input type="hidden" name="student<?=$sn;?>" value="<?=$adm->student_id;?>">
                            <input type="hidden" name="name_type_id" value="7">
                             <input type="hidden" name="invoice_type<?=$sn;?>" value="9">
                                <input type="hidden" name="p_balance<?=$sn;?>" value="<?=$bamount?>">
                                        <tr style="<?php echo "";?>" id="<?php echo $adm->student_id; ?>">
                                             <td><?= $sn;?></td>
                                            
                                            <td><?= $pid2[0]->permit_id;?></td>
                                        <td><?= $pid2[0]->created_date;?></td>
                                   
                                            <td><?= $std[0]->first_name.' '.$std[0]->middle_name.' '.$std[0]->last_name;?></td>
                                            <td><?= $std[0]->birth_date;?></td>
                                            <td><?= findAge($std[0]->birth_date);?>
                                        </td>
                                            <td><?= $level[0]->level_name;?></td>
                                            <td><?= $room[0]->class_name;?></td>
                                            <td><?= $strm[0]->stream_name;?></td>
                                            <td><?= $hostelname;?></td>
                                            <td class="text-right" id="bal<?= $sn;?>"><?= number_format($bamount);?></td>
                                          
                                              <td>
                                               <input type="text" class="form-control" style="width:100px;" id="amount<?= $sn;?>" onkeyup="AmtCalc('<?= $sn;?>')" value="" name="amount<?= $sn;?>">  
                                            </td>
                                        </tr>
                                    
                                <?php }
                                }}
                                ?>
                                </tbody>
                            </table>
                        </div>
                       
                    </form>
                </div>
               

<script type="text/javascript">
     $("#all_input").show();
       refreshCalc();
         function AllCalc(){
       // alert(i);
             var total=0;
            var amount=0;
            var balance=0;
           
            var input=$("#allinput_id").val().replace(/,/gi, "");
           
            if(input==""){
                input=0;
            }

             //var remember = document.getElementById("Allselected");
            
            
            
         var values=<?php echo json_encode($item_list);?>;
          for( var i = 0; i < values.length; i++){ 
          var id=values[i];

            var bal= $("#bal"+id).html().replace(/,/gi, "");
          if(parseInt(input) > parseInt(bal)){
           var myAmount = Number(String(input).slice(0, -1));
            //alert(myAmount);
           $("#amount"+id).val(myAmount.toLocaleString());
           toastr.info("Please enter amount less or equal to " + bal);

           // $("#amount"+id).val(parseInt(input).toLocaleString());
         // alert(id);
           amount=$("#amount"+id).val().replace(/,/gi, "");
           if(amount !=""){
            total=total+parseInt(amount);
           }

            }else{
            $("#amount"+id).val(parseInt(input).toLocaleString());
         // alert(id);
           amount=$("#amount"+id).val().replace(/,/gi, "");
           if(amount !=""){
            total=total+parseInt(amount);
           }
           
            }
        }
          //alert(total);
          
          balance= $("#balance").html().replace(/,/gi, "");
          balance=parseInt(balance)-total;
          // alert(balance);
          $("#after").html(balance.toLocaleString());
          $("#thispay").html(total.toLocaleString());
      
      
  }
          function AmtCalc(i){
       // alert(i);
             var total=0;
            var amount=0;
            var balance=0;
            var bal= $("#bal"+i).html().replace(/,/gi, "");
            var input=$("#amount"+i).val().replace(/,/gi, "");
           
            if(input==""){
                input=0;
            }

             
            
            if(parseInt(input) > parseInt(bal)){
           var myAmount = Number(String(input).slice(0, -1));
            //alert(myAmount);
           $("#amount"+i).val(myAmount.toLocaleString());
           toastr.info("Please enter amount less or equal to " + bal);
            }else{
            $("#amount"+i).val(parseInt(input).toLocaleString());
            
         var values=<?php echo json_encode($item_list);?>;
          for( var i = 0; i < values.length; i++){ 
          var id=values[i];
         // alert(id);
          
           amount=$("#amount"+id).val().replace(/,/gi, "");
           if(amount !=""){
            total=total+parseInt(amount);
           }
           
            }
          //alert(total);
          
          balance= $("#balance").html().replace(/,/gi, "");
          balance=parseInt(balance)-total;
          // alert(balance);
          $("#after").html(balance.toLocaleString());
          $("#thispay").html(total.toLocaleString());
      }
      }

      function refreshCalc(){
         var total=0;
            var amount=0;
            var balance=0;
         var values=<?php echo json_encode($item_list);?>;
          for( var i = 0; i < values.length; i++){ 
          var id=values[i];
         // alert(id);
           amount=$("#amount"+id).val().replace(/,/gi, "");
           if(amount !=""){
            total=total+parseInt(amount);
           }
           
            }
          //alert(total);
          
          balance= $("#balance").html().replace(/,/gi, "");
          balance=parseInt(balance)-total;
           //alert(balance);
          $("#after").html(balance.toLocaleString());
          $("#thispay").html(total.toLocaleString());
      }
      
      function createRefund(){
        var payed= $("#thispay").html();
        var customer_type=$('#customer_type').val();
        var bank=$('#bank').val();
        if(customer_type=="" || bank==""){
            if(customer_type==""){
       toastr.error("Please select paid to");
        }else{
        toastr.error("Please select bank");    
        }
        }else if(payed==0){
       toastr.error("Please! This payment amount is 0");
       }else{
     var data= $("#list_form").serialize()+"&"+$("#voucher_form").serialize()+"&"+$("#header_form").serialize();
        //alert(data);
       // return;
     
     $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillController/process_refund_pocketMoney'; ?>',
            data: data,
            dataType: 'json',
            success: function (res) {
              if(res.status=== 1){

                 $('#all_list').html('');
                 refresh_refund();
                 
                swal("Success", res.description, "success");
              refreshCalc();
            }else{
             swal("error","Failed to create Payment","error");    
            }
            },
            error: function (){
                alert('error encounted');
            }
        });

       }
      }

      function refresh_refund() {
            
            $('#all_list2').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "class=" + $('#class option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&year="+$('#year option:selected').val()+ "&hostel="+$('#hostel option:selected').val()+'&staff_id='+$('#staff_id').val();
           //alert(dta);
           // return;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/get_pocket_money_list'; ?>',
                 data: dta,
                success: function (res) {
                    $('#all_list2').html(res);
                },
                error: function () {
                    $('#all_list2').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

  
    };
</script>