  <style type="text/css">

     .invoice > .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }
  

 </style>
 <?php
 helper('age');
  $amodel = new App\Models\AdmissionModel();
  $billmodel = new App\Models\BillModel();
  $remodel =new App\Models\ReportsModel();
  $suppliermodel = new App\Models\SupplierModel();
  $leger_transaction = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>$inv[0]->trans_type_id));
  $supplier_name = "";
  $name_type = "";
  $ref="";
  $amount = 0;
  $phone="";

  if($leger_transaction[0]->name_type_id==1){
$suppl = $billmodel->get_item_name('students', $where = array('id'=>$leger_transaction[0]->name_id));
$student_parent = $billmodel->get_item_name('parents_students_tbl', $where = array('student_id'=>$leger_transaction[0]->name_id));
$parent=$billmodel->get_item_name('parents_tbl', $where = array('id'=>$student_parent[0]->parent_id));

$name = $suppl[0]->full_name;
$phone=$parent[0]->phone1;
  }else if($leger_transaction[0]->name_type_id==2){
$suppl = $billmodel->get_item_name('supplier_tbl', $where = array('supplier_id'=>$leger_transaction[0]->name_id));
$name = $suppl[0]->supplier_name;
  }else if($leger_transaction[0]->name_type_id == 7){
        $app = $billmodel->get_item_name('users',$where = array('user_id'=>$leger_transaction[0]->name_id));
        $name = $app[0]->first_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->user_id;
        $type_name = $billmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $phone=$app[0]->phone_no;
       
   }
       else if($leger_transaction[0]->name_type_id == 8){

      $app = $billmodel->get_institution_name($leger_transaction[0]->name_id);
     $name = $app->institution_name; 
     $student_id = $app->institution_id;
     $type_name = $billmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
     $name_type = $type_name[0]->name_type;
                                        }
  else{
$name="";
  }
  
  
  $name_type_id = $billmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
  $billref = $billmodel->get_item_name('transaction_other_details_tbl',$where = array('transaction_no'=>$inv[0]->trans_number));
    

     $rlt = $billmodel->get_item_name('voucher_relation_tbl', $where = array('payment_no' => $inv[0]->trans_number));
            
            $v_type = $billmodel->get_item_name('voucher_types_tbl', $where = array('id' => $rlt[0]->voucher_type));

$del_over=0;
$del_trans=0;
 ?>
 

<div class="row">
<!-------------------- Bill Information starts here  ------------------>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Payee Information</h5>
            </div>
            </hr>

            <div class="card-body">
                
                <input type="hidden" name="trans" id="trans" value="<?= $inv[0]->trans_number;?>">
                <table class="table table-borderless">
                    <tr>
                        <th>Pay Voucher No:</th>
                        <td><?= $inv[0]->trans_number; ?></td>
                    </tr>
                     <tr>
                        <th>Voucher Type:</th>
                        <td><?= $v_type[0]->voucher_type_name??"";?></td>
                    </tr>
                    <tr>
                        <th>Voucher Date:</th>
                        <td>
                            
                            <div  class="cust_popup" id="change1" style="display: none">
                                    <h6>Change Date</h6>
                               <input type="date" name="date" id="tdate1" class="form-control" value="<?= date("Y-m-d",strtotime($inv[0]->trans_date))?>">
                               <div class="mt-3">
                               <button class="btn btn-danger pull-left" onclick="cancelbtn(1)">Cancel</button>
                               <button class="btn btn-primary pull-right" onclick="saveDate('<?= $inv[0]->trans_number; ?>',1)">Change</button>
                               </div>
                               </div>

                            
                   <a class="cost2" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="updatesupplier(1)">
                         <input type="text" value="<?= $inv[0]->trans_date??""; ?>" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:140px;text-align:left;" id="" readonly>
                      </a>
                        </td>
                    </tr>
                     <tr>
                        <th>Payee:</th>
                        <td>
         <?php
       $supp=$billmodel->get_item_name('users',$where = array('status' =>1,'user_type'=>3));
        ?>             
          <div class="cust_popup text-left" id="change4" style="display: none;">
                <h6>Change Payee</h6>
            <div id="fdbk">
            <select class="form-control form-select mb-3" id="supplier_id">
                    <?php 
                  foreach($supp as $acc){
                    ?>
                    <option value="<?= $acc->user_id;?>" <?php if($acc->user_id==$leger_transaction[0]->name_id){ echo "selected"; }?> ><?= $acc->first_name.' '.$acc->last_name;?></option>
                <?php }?>
                </select>
              <button class="btn btn-warning" onclick="cancelbtn(4)">Cancel</button>
             <button type="submit" class="btn btn-primary pull-right" onclick="saveDate('<?= $inv[0]->trans_number; ?>',4)">Save</button>&nbsp;
            </div>
                 
           </div>
                            <a class="cost2" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="updatesupplier(4)">
                         <input type="text" value="<?= $name??""; ?>" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:120px;text-align:left;" id="" readonly>
                      </a>

                        </td>
                    </tr>
                    <tr>
                        <th>Name Type:</th>
                        <td><?= $name_type_id[0]->name_type; ?></td>
                    </tr> 
                    
                    <tr>
                        <th> Phone no:</th>
                        <td><?= $phone??""; ?></td>
                    </tr>
                   
                </table>
            </div>
    </div>
</div>
 <!-------------------- Payment History starts here  ------------------>

    <?php
   // $databaseName=session()->get('school');
     $dbname=session()->get('db_name');
    $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;
                        $query = $db->query('SELECT item_transation_tbl.item_id,item_name,account_name,trans_number,quantity,unit_price FROM item_transation_tbl,items_tbl,items_ledgers_tbl,accounts_tbl where item_transation_tbl.item_id = items_tbl.id AND items_ledgers_tbl.item_id = items_tbl.id AND item_transation_tbl.trans_type = 4 AND accounts_tbl.id = items_ledgers_tbl.account_id AND trans_number='.$inv[0]->trans_number);
                        $result = $query->getResult();

                        foreach($result as $itm){
                            $dat = $billmodel->get_trans_type($inv[0]->trans_number);
                             $query2 = $db->query('SELECT type_name,amount FROM ledger_transaction_tbl,account_types_tbl where ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_transaction_tbl.trans_type = 4 AND (ledger_type = 10) AND trans_no='.$inv[0]->trans_number);
                             $result2 = $query2->getResult();
                             $amount = $itm->amount;
                           
                            $total += $amount;
                             }

          ?>
     <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Related Transactions</h5>
            </div>
            </hr>

            <div class="card-body">

                 <!-- image attachment pop up -->
      <div class="cust_popup_lg" id="Attchmnt2" style="display:none">
                    <a href="javascript:void(0)" class="pull-left" onclick="CloseAttachmnt2()"><i class="fa fa-times"></i></a>
                  <div id="ViewAttachment" class=""></div>
                    <br>                   
                    <!-- <a href="javascript:void(0)" class="btn btn-danger btn-xs pull-right" onclick="DeleteAttachmnt()">Delete</a> -->
                </div>
                <table class="table" id="paytable">
                    <thead>
                                <tr>
                                    
                                    <th>Trans Type</th>
                                    <th>Trans No</th>
                                   <th class="">Date</th>
                                    <th>Amount</th>
                                    <th>Trans by</th>
                                    <th width="100px">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                          <?php

                          $receipt=array();
                          $delete=0;
                          $pocketMoney = $billmodel->get_item_name('pocket_money_transaction_tbl',$where = array('transaction_no' =>$inv[0]->trans_number,));
                          $control = $billmodel->get_item_name('control_number_charges_payments_tbl',$where = array('trans_no' =>$inv[0]->trans_number,));

                           $v_transaction = $billmodel->get_item_name('voucher_relation_tbl',$where = array('payment_no' =>$inv[0]->trans_number)); 
                          if(count($pocketMoney)>0 || count($control)>0){
                               $delete=1;
                             echo "<tr><td></td>
                             <td colspan='3'>No related transactions</td></tr>";
                             }else if($v_transaction[0]->trans_type==0){
                                  echo "<tr><td></td>
                             <td colspan='3'>No related transactions</td></tr>";
                             }else if($v_transaction[0]->voucher_type==8){
                                  echo "<tr><td></td>
                             <td colspan='3'>No related transactions</td></tr>";
                             }
                             else{
                          
                         //print_r($v_transaction);
                          
                          if($v_transaction[0]->trans_type==2){

                         $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type,'ledger_id'=>$leger_transaction[0]->ledger_id));

                          $receipt = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type,'ledger_type'=>9));

                         if($leger_transaction[0]->ledger_id==21){
                        $trans_type="Overpayment";
                         }else{
                         $trans_type="Receipt";
                         $receipt=array();
                         }
                        
                         $trans_type2="Receipt";
                        

                          }else{
                          $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type)); 
                          $traType = $billmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>$v_transaction[0]->trans_type));  
                          $trans_type=$traType[0]->type_name;
                             }

                        $transNumber = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$v_transaction[0]->trans_no,'trans_type_id'=>$v_transaction[0]->trans_type));
                        $traBy = $billmodel->get_item_name('users',$where = array('user_id' =>$transNumber[0]->updated_by));

                           ?>
                            <tr>
                                <td><?=$trans_type??""?></td>
                                <td><?=$v_transaction[0]->trans_no??""?></td>
                                 <td><?=date('Y-m-d',strtotime($transNumber[0]->trans_date))??""?></td>
     <td class="text-right"><?=format_number_with_decimals($bala_amount[0]->amount)??""?></td>
                            <td><?=$traBy[0]->first_name." ".$traBy[0]->last_name??""?></td>
                            <td class="text-left">
                                <?php
                               if($v_transaction[0]->trans_type==2){
                                ?>
                              <button type="button" class="btn btn-primary btn-sm"  onclick="manage_receipt('<?=$transNumber[0]->id;?>')"><i class="fa fa-eye"></i> </button> 
                                 <?php
                               }else if($v_transaction[0]->trans_type==4){

                          $billattch = $billmodel->get_item_name('transaction_attachments_tbl',$where = array('transaction_number'=>$v_transaction[0]->trans_no));
                                ?>
                             <button type="button" class="btn btn-primary btn-sm"  onclick="manage_bill('<?=$inv[0]->id;?>')"><i class="fa fa-eye"></i> </button>
                             <?php
                             if(count($billattch)>0){
                             ?>
                          <button type="button" class="btn btn-primary btn-sm"  onclick="view_attachement('<?=$billattch[0]->image_attachment;?>')"><i class="fa fa-arrow-up"></i> </button>
                               <?php
                           }
                                  }
                               else{
                                ?>
                                <button type="button" class="btn btn-primary btn-sm"  onclick="manage_credit('<?=$transNumber[0]->trans_number;?>')"><i class="fa fa-eye"></i> </button>
                            <?php } ?>
                            </td>
                            </tr>
                            <?php 
                           if(count($receipt)>0){
                            ?>
                      <tr>
                                <td><?=$trans_type2??""?></td>
                                <td><?=$receipt[0]->trans_no??""?></td>
                                <td><?=date('Y-m-d',strtotime($transNumber[0]->trans_date))??""?></td>
         <td class="text-right"><?=format_number_with_decimals($receipt[0]->amount)??""?></td>
                            <td><?=$traBy[0]->first_name." ".$traBy[0]->last_name??""?></td>
                            <td>
                                <button type="button" class="btn btn-primary btn-sm"  onclick="manage_receipt('<?=$transNumber[0]->id;?>')"><i class="fa fa-eye"></i> </button>
                            </td>
                            </tr>
                            <?php
                           }
                       }
                            ?>
                           
                        </tbody>
                </table>
             </div>
     </div>
 </div>
</div>
</div>

<!-------------------- Charged Items starts here --------------------->
<div class="row">
    <div class="col-md-12">
        <div class="card  invoice">
            <div class="card-header">
                <h5>Payment Details</h5>
                
            </div>
            <div id="addDetails" class="mt-3">
                
            </div>
            </hr>

            <div class="card-body">
                          <div class="table-responsive">
                <table class="table">
                    <thead>
                        <?php 
                        if(count($pocketMoney)==0 && $v_transaction[0]->trans_type!=0 && count($control)==0 ){
                            
                            ?>
                        <tr>
                          
                            <th>Trans Type</th>
                              <th>Type</th>
                            <th>Trans Date</th>
                            <th class="">Trans No</th>
                            <th>Name</th>
                            <th class="text-center">Amount</th>
                            
                            <th>Balance</th>
                            <th>Paid</th>
                           
                            <th></th>
                        </tr>
                         <?php 
                           }else if($v_transaction[0]->trans_type==0){
                            $delete=3;
                            ?>
                             <tr>
                          
                            <th>Trans Type</th>
                              <th>Type</th>
                            <th>Trans Date</th>
                            <th class="">Trans No</th>
                            <th>Name</th>
                            <th class="text-center">Amount</th>
                            
                            <th>Balance</th>
                           
                            <th></th>
                        </tr>
                            <?php
                            }else if(count($pocketMoney)>0){
                         
                            ?>
                             <input type="hidden" name="staff_id" id="staff_id" value="<?= $leger_transaction[0]->name_id;?>">
                             <script type="text/javascript">
                                $(function() {
                                 load_class_list();
                             });
                             </script>
                              <tr>
                                     
                                    <th>#</th>
                                     <th>Student Name</th>
                                    <th>DOB</th>
                                    <th>Age</th>
                                    <th>Level</th>
                                    <th>Class</th>
                                    <th>Stream</th>
                                    <th>Hostel</th>
                                    <th class="text-right">P/money Bal</th>
                                    <th class="text-right">Paid</th>
                                  
                                    <th></th>
                         </tr>
                         <?php 
                     }else if(count($control) >0){
                          $delete=1;
                         ?>
                         <input type="hidden" name="staff_id" id="staff_id" value="<?= $leger_transaction[0]->name_id;?>">
                             <script type="text/javascript">
                                $(function() {
                                 load_control_list();
                             });
                             </script>
                         <tr>
                                     
                        <th>#</th>
                          <th>Rct No.</th>
                            <th>inv type.</th>
                            <th>trans. Date</th>
                           <th>Student Name</th>
                            <th>control No</th>
                          
                            <th class="text-right">charged</th>
                            
                            <th class="text-right">Paid</th>
                      
                            <th></th>
                         </tr>
                         <?php
                           }
                         ?>
                    </thead>
                    <tbody id="">
                        <?php
                       // $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;
                         if(count($pocketMoney)==0  && $v_transaction[0]->trans_type!=0 && count($control)==0){
                            $delete=2;
                              if($v_transaction[0]->trans_type==5 && $v_type[0]->id==6){
                                   $delete=5;
                            }  
                        //echo $inv[0]->trans_number;
                         $v_transaction = $billmodel->get_item_name('voucher_relation_tbl',$where = array('payment_no' =>$inv[0]->trans_number,));
                         //print_r($v_transaction);
                          
                          
                          if($v_transaction[0]->trans_type==2){
                          $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type,'ledger_id'=>$leger_transaction[0]->ledger_id));
                         if($leger_transaction[0]->ledger_id==21){

                            $t=2;
                            $del_over=1;
                             $del_trans=$v_transaction[0]->trans_no;
                        $trans_type="Overpayment";
                         }else{
                            $del_over=0;
                             $del_trans=$v_transaction[0]->trans_no;
                            $t=2;
                         $trans_type="Receipt";
                         }
                          }else{
                            $del_over=$v_transaction[0]->trans_type;
                            $del_trans=$v_transaction[0]->trans_no;
                            $t=6;
                          $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type,'transation_nature'=>1)); 
                          $traType = $billmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>$v_transaction[0]->trans_type));  
                          $trans_type=$traType[0]->type_name;

                          }
                         
                  
                        $paid = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>5,'transation_nature'=>2));

                        $invType = $billmodel->get_item_name('invoice_type_transaction',$where = array('trans_no' =>$v_transaction[0]->trans_no,'transaction_type_id'=>$v_transaction[0]->trans_type));

if(count($invType)==0){
    $invType = $billmodel->get_item_name('invoice_type_transaction',$where = array('trans_no' =>$v_transaction[0]->trans_no,'transaction_type_id'=>5));
}   if(isset($invType) && !empty($invType)){
                        $invTypeName = $billmodel->get_item_name('invoice_types_tbl',$where = array('id' =>$invType[0]->invoice_type_id));

                         $transType = $billmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>5));

                         $transNumber = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$v_transaction[0]->trans_no,'trans_type_id'=>$v_transaction[0]->trans_type));
                       $trans_date= $transNumber[0]->trans_date??"";
                        $type_names= $invTypeName[0]->type_name??"";
                        
}
     else{

                         $transNumber = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$v_transaction[0]->trans_no,'trans_type_id'=>$v_transaction[0]->trans_type));
                           if($v_transaction[0]->voucher_type==8){
                             $type_names='Salary Advance';
                           }else{
                            $type_names="Payroll";

                           }
                       $trans_date= $transNumber[0]->trans_date??""; 
                        }
                           ?>
                         <tr>
                            
                             <td><?=$trans_type?? ""; ?></td>
                             <td><?= $type_names?? ""; ?></td>
                             <td><?=$trans_date?? ""; ?></td>
                             <td class=""><?= $v_transaction[0]->trans_no??""; ?></td>
                            <td><?= $name??""; ?></td>
                            <td><?= format_number_with_decimals($bala_amount[0]->amount)??""; ?>
                                
                                <!----popup here --->
            <div class="cust_popup text-left" id="refundPopup" style="display: none;">
            <h6>Change Amount</h6>
            <div id="popup_details"></div>
             <input type="hidden" name="refund" id="refund_id" value="1">
             <input type="hidden" name="refund_trans_type" id="refund_trans_type" value="<?= $t;?>">
             <input type="hidden" name="old_trans_no" id="old_trans_no" value="<?= $v_transaction[0]->trans_no?>">
            </div>
                            </td>
                            <td>
                          <?= format_number_with_decimals($paid[0]->balance)??""; ?></td>
                            <td>

                      <a class="cost2" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="edit_amount_refund('<?= $t;?>','<?= $v_transaction[0]->trans_no??""; ?>','<?= $inv[0]->trans_number;?>',' <?= $paid[0]->amount; ?>')">
                         <input type="text" value="<?= format_number_with_decimals($paid[0]->amount)??""; ?>" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" id="" readonly>
                        
                                </a>
                                <!-- <?= format_number_with_decimals($paid[0]->amount)??""; ?></td> -->

                         </tr>
                     <?php }else if($v_transaction[0]->trans_type==0 && count($control)==0){
                          $invType = $billmodel->get_item_name('invoice_type_transaction',$where = array('trans_no' =>$v_transaction[0]->payment_no,'transaction_type_id'=>5));
                         // echo $v_transaction[0]->trans_no;
                        //print_r($invType);

                        $invTypeName = $billmodel->get_item_name('invoice_types_tbl',$where = array('id' =>$invType[0]->invoice_type_id));
                        $recharge_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_type' =>5,'trans_no'=>$v_transaction[0]->payment_no));
                        $sms_balance = $billmodel->get_item_name('messages_balances',$where = array('balance !=' =>""));
                         $transNumber = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$v_transaction[0]->payment_no,'trans_type_id'=>5));
                        ?>
                     <tr>
                            
                              <td><?= "Sms Recharge"; ?></td>
                               <td><?= $invTypeName[0]->type_name??""; ?></td>
                             <td><?= $transNumber[0]->trans_date??""; ?></td>
                             <td class=""><?= $v_transaction[0]->payment_no??""; ?></td>
                            <td><?= $name??""; ?>
                                
             <!----popup here --->
            <div class="cust_popup text-left" id="smsPopup" style="display: none;">
            <h6>Change Amount</h6>
            <div id="sms_details"></div>
              <input type="hidden" name="refund" id="refund_id" value="2">
            </div>
            <!----popup here --->
                            </td>
                            <td>

                                 <a class="cost2" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="edit_amount_sms('<?= $inv[0]->trans_number;?>',' <?= $recharge_amount[0]->amount; ?>')">
                         <input type="text" value="<?= format_number_with_decimals($recharge_amount[0]->amount)??""; ?>" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" id="" readonly>
                        
                                </a>
                                </td>
                            <td><?= format_number_with_decimals($sms_balance[0]->balance)??""; ?></td>
                           
                             </tr>
                    <?php
                     }else if(count($pocketMoney)>0){

                  $total_given=0;
                      $k=0;
                       foreach($pocketMoney as $pm){
                     $dbal = $remodel->refund_pocket_money($pm->student_id);
                     $collected=0;
                     $usedAmount=0;
                    foreach($dbal as $pmn){
                      $check_y=$amodel->get_student_details_byYear('transaction_numbers_tbl', $where = array('trans_number' => $pmn->trans_no,'trans_type_id'=>3,'status'=>1), $pm->academic_year);
                                 if(count($check_y)>0){
                            $collected+=$pmn->amount;

                            }
                            }
                                 
                        
                         $student = $billmodel->get_item_name('students',$where = array('id' =>$pm->student_id));
                         $adms = $billmodel->get_item_name('admission_tbl',$where = array('student_id' =>$pm->student_id,'academic_year'=>$pm->academic_year));
                         $level=$billmodel->get_item_name('class_level_tbl',$where = array('id' =>$adms[0]->level_id));
                         $class=$billmodel->get_item_name('classes_tbl',$where = array('id' =>$adms[0]->class_id));
                        $stream=$billmodel->get_item_name('streams_tbl',$where = array('id' =>$adms[0]->stream_id));
                         $hostel=$billmodel->get_item_name('hostel_tbl',$where = array('id' =>$adms[0]->hostel_id));
                            
                             $check_used = $billmodel->get_item_name('pocket_money_transaction_tbl', $where = array('student_id' => $pm->student_id,'academic_year'=>$pm->academic_year));

                                if(count($check_used)>0){
                                  foreach($check_used as $used){
                                 $usedAmount+=$used->amount_given;    
                                
                                  }
                                 }
                         $balance=$collected-$usedAmount;
                         $total_given+=$pm->amount_given;
                         $k++;
                        ?>
                       <tr>
                            
                              <td><?=$k; ?></td>
                              <td><?= $student[0]->full_name??""; ?></td>
                               <td><?= $student[0]->birth_date??""; ?></td>
                               <td><?= findAge($student[0]->birth_date)??""; ?></td>
                             <td><?php echo $level[0]->level_name;?></td>
                            <td><?php echo $class[0]->class_name;?></td>
                            <td>
                                 <div class="cust_popup text-left" id="cash<?php echo $pm->student_id;?>" style="display: none;">
                                    <h6>Change Amount</h6>
                                <div id="prcres<?php echo $pm->student_id;?>"></div>
                                     
                               </div>
                                <?php echo $stream[0]->stream_name;?></td>
                             <td><?php echo $hostel[0]->hostel_name;?></td>
                            <td class="text-right"><?php echo format_number_with_decimals(($balance));?></td>
                            <td class="text-right">
                               

                                <a class="cost2" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="edit_amount('<?= $pm->student_id;?>','<?= $inv[0]->trans_number;?>','<?=$pm->amount_given;?>')">
                            <input type="text" value="<?=format_number_with_decimals($pm->amount_given); ?>" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:70px;text-align:right;" id="amount<?php echo $pm->student_id;?>" readonly>
                        
                                </a>    
                                </td>
                           
                            <td>
                                <a href="javascript:void(0)" class="btn-danger btn-sm"><i class="fa fa-trash"  onclick="Remove_item('<?= $pm->student_id;?>','<?= $inv[0]->trans_number;?>','<?=$pm->amount_given;?>')" ></i></a>
                            </td>
                         </tr>
                     <?php 
                       
                       }
                    ?>
                  <tr>
                      <td colspan="8"></td>
                      <td><b>Total</b></td>
                      <td class="text-right"><b><?= format_number_with_decimals($total_given)??""; ?></b></td>
                  </tr>
                   
                    <?php
                     }else if(count($control)>0){
                        $n=0;
                        $total_charged=0;
                        foreach($control as $p){
                        $invtbl=$billmodel->get_item_name('invoice_type_transaction',$where = array('trans_no' =>$p->inv_no)); 
                         $invType=$billmodel->get_item_name('invoice_types_tbl',$where = array('id' =>$invtbl[0]->invoice_type_id));
                          $trans=$billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$p->rct_no,'trans_type_id'=>2));

                          if($p->name_type_id==1){
                         $names=$billmodel->get_item_name('students',$where = array('id' =>$p->student_id));
                          }
                          if($p->name_type_id==4){
                         $names=$billmodel->get_item_name('students_application_tbl',$where = array('id' =>$p->student_id));   
                          }
                    $ctr=$billmodel->get_item_name('payment_request',$where = array('trans_no' => $p->inv_no,'student_id'=>$p->student_id,'trans_type'=>1));
                     $charges=$billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $p->rct_no,'ledger_id'=>22,'trans_type'=>2));   
                      $n++;
                      $total_charged+=$p->amount;
                    ?>
                  <tr>
                            
                      <td><?=$n; ?></td>
                      <td><?= $p->rct_no??""; ?></td>
                       <td><?= $invType[0]->type_name??""; ?></td>
                       <td><?= $trans[0]->trans_date??""; ?></td>
                       <td><?= $names[0]->full_name??""; ?></td>
                       <td><?= $ctr[0]->reference_no??""; ?></td>
                       <td class="text-right"><?= format_number_with_decimals($charges[0]->amount)??""; ?>
                           
                           <div class="cust_popup text-left" id="cash<?php echo $p->student_id;?>" style="display: none;">
                                    <h6>Change Amount</h6>
                                <div id="prcres<?php echo $p->student_id;?>"></div>
                                     
                               </div>
                       </td>
                       <td class="text-right">
                            <a class="cost2" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="edit_amount('<?= $p->student_id;?>','<?= $inv[0]->trans_number;?>','<?=$p->amount;?>')">
                            <input type="text" value="<?=format_number_with_decimals($p->amount); ?>" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:70px;text-align:right;" id="amount<?php echo $p->student_id;?>" readonly>
                        
                                </a>
                       </td>
                       <td>
                                <a href="javascript:void(0)" class="btn-danger btn-sm"><i class="fa fa-trash"  onclick="Remove_item('<?= $p->student_id;?>','<?= $inv[0]->trans_number;?>','<?=$p->amount;?>')" ></i></a>
                            </td>
                        </tr>
                    <?php
                     }
                     }
                     ?>
                    
                    </tbody>
                </table>

            </div>
            </div>

        </div>

        <!--------$name="AUGUST MARTIN NJAU";---------- here payment information 
           
starts---->
        <?php $bill = $billmodel->billdata($inv[0]->trans_number,$inv[0]->trans_type_id); ?>
        <?php  $Initiator= $billmodel->get_initiator_name($bill[0]->app_id); ?>
        <div class="row">
        <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Approval History</h5>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               
                <label>Approval Status:</label>
                <?php 
                //$id_trans = $inv[0]->trans_number;
                $checker = 0;
               foreach($Initiator as $dat){
                if($dat->user_role =='3' && $dat->hstatus=='1')
                {
                    $checker =1;
                }
                elseif($dat->user_role =='3' && $dat->hstatus=='2'){
                    $checker =2;
                }
               }
                if($checker ==1)
                {
                     echo  '<label style="color:green;">  &nbsp;&nbsp; <strong>Approved! </strong></label>';
                 }
                 elseif($checker ==2){
                     echo  '<label style="color:red;">  &nbsp;&nbsp; Rejected! </label>';
                 }
                 else{
                echo'<label style="color:red;">  &nbsp;&nbsp; Pending! </label>';
                 }

                
                 ?>
                <div id="feedback"></div>
            </div>
            </hr>
        
     <?php $hist_data = $billmodel->getdatabill($bill[0]->app_id); ?>
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Entry Date:</th>
                        <th>Comment:</th>
                        <th>Name:</th>
                        <th>User Role:</th>
                        <!-- <th>Status:</th> -->
                    </tr>
                    <?php foreach($hist_data as $in): ?>
                    <tr>
                        <td><strong><?=$in->hist_date; ?></strong></td>
                        <td class="text-primary"><?= $in->comment; ?></td>
                        <td>
                            <?= $in->first_name.' '.$in->last_name; ?>
                        </td>
                        <td><?php if($in->user_role == '1'){
                            echo "Initiator";
                        }elseif($in->user_role == '2'){
                            echo "Checker";
                        }elseif($in->user_role == '3'){
                            echo "Approver";
                        }else{

                        } ?></td>
                        <td></td>
                    </tr>
                       <?php endforeach; ?>
                </table>
            </div>
        </div>
    </div>

        <!------------------ here accounts receivable ------------------->
        <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Effected ledgers</h5>
            </div>
            </hr>
           <div class="card-body">
                <table class="table" style="border:1px solid black;">
                   <tr style="border:1px solid black;">
                       <th style="border:1px solid black;">Ledger name</th>
                       <th style="border:1px solid black;">Debit</th>
                       <th style="border:1px solid black;">Credit</th>
                   </tr>
                    <tbody style="border:1px solid black;">
                        <?php 
                          
                    $ledger1 = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>5,'transation_nature'=>2));
                    $ledger2 = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>5,'transation_nature'=>1));
                    $ledger11=$billmodel->get_item_name('accounts_tbl',$where = array('id' =>$ledger1[0]->ledger_id));

                    $ledger22=$billmodel->get_item_name('accounts_tbl',$where = array('id' =>$ledger2[0]->ledger_id));
                    $accounts1=$billmodel->get_item_name('accounts_tbl',$where = array('account_type_id' =>$ledger11[0]->account_type_id));
                    $accounts2=$billmodel->get_item_name('accounts_tbl',$where = array('account_type_id' =>9));

                        ?>
                        <tr style="border:1px solid black;">

                          <td style="border:1px solid black;">
            <div class="cust_popup text-left" id="popup_account2" style="display: none;">
                <h6>Change Account</h6>
            <div id="fdbk2">
                <select class="form-control form-select mb-3" id="bankId2">
                    <?php 
                  foreach($accounts1 as $acc){
                    ?>
                    <option value="<?= $acc->id;?>" <?php if($acc->id ==$ledger11[0]->id){ echo "selected";}?>><?= $acc->account_name;?></option>
                <?php }?>
                </select>
              <button class="btn btn-warning" onclick="cancelAccPopup(2)">Cancel</button>
             <button type="submit" class="btn btn-primary pull-right" onclick="changeAccount('<?= $inv[0]->trans_number;?>',2)">Save</button>&nbsp;
            </div>
                 
           </div> 

                             <a class="cost2" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="edit_account('2','<?= $ledger11[0]->id;?>','<?= $inv[0]->trans_number;?>')">
                            <input type="text" value="<?=$ledger11[0]->account_name; ?>" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;text-align:left;" readonly>
                        
                                </a>    
                              <!-- <?=$ledger11[0]->account_name; ?>   -->
                            </td>  
                          <td class="text-right" style="border:1px solid black;"><?=format_number_with_decimals($ledger1[0]->amount)??""?></td>  
                          <td style="border:1px solid black;"><?=""?></td>  
                        </tr>
                        <tr style="border:1px solid black;">

                          <td style="border:1px solid black;">

                    <!---cust popup ------>
        <div class="cust_popup text-left" id="popup_account1" style="display: none;">
        <h6>Change Account</h6>
        <div id="fdbk1">
            <?php
            //print_r($accounts2);
            ?>
        <select class="form-control form-select mb-3" id="bankId1">
        <?php 

        foreach($accounts2 as $acc){
        ?>
        <option value="<?= $acc->id;?>" <?php if($acc->id ==$ledger22[0]->id){ echo "selected";}?>><?= $acc->account_name;?></option>
        <?php }?>
        </select>
        <button class="btn btn-warning" onclick="cancelAccPopup(1)">Cancel</button>
        <button type="submit" class="btn btn-primary pull-right" onclick="changeAccount('<?= $inv[0]->trans_number;?>',1)">Save</button>&nbsp;
        </div>

     </div>
     <!---cust popup ------>

                            <a class="cost2" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="edit_account('1','<?= $ledger22[0]->id;?>','<?= $inv[0]->trans_number;?>')">
                            <input type="text" value="<?=$ledger22[0]->account_name; ?>" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;text-align:left;" readonly>
                        
                                </a>
                                <!-- <?=$ledger22[0]->account_name; ?> -->
                                 </td> 
                          <td style="border:1px solid black;"><?=""?></td>   
                          <td class="text-right" style="border:1px solid black;"><?=format_number_with_decimals($ledger2[0]->amount)??""?></td>  
                          
                        </tr>
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;"><b>Total</b></td> 
                          <td class="text-right" style="border:1px solid black;"><b><?=format_number_with_decimals($ledger1[0]->amount)??""?><b></td>   
                          <td class="text-right" style="border:1px solid black;"><b><?=format_number_with_decimals($ledger2[0]->amount)??""?></b></td>  
                          
                        </tr>

                        
                    </tbody>
                </table>

            </div>
        </div>
</div>
</div>
</div>
<!----------------------------- supporting documents --------------------------->
<input type="hidden" name="bank_id" value="<?= $ledger22[0]->id;?>" id="bank_id">
<div class="row">
 <div class="col-md-6">
        <div class="card invoice">
            
        </div>
    </div>
</div>
<div class="row">
    <?php if($vocher!=1){?>
<div class="col-md-12">
   
    <button type="button" class="btn btn-success  float-right ml-3 ApprovalId" data-id="<?= $inv[0]->trans_number; ?>">Approve</button>
    <button type="button" class="btn btn-warning  float-right RejectId" data-id="<?= $inv[0]->trans_number; ?>">Reject</button>
  

</div>
  <?php }?>

</div>
<!-----------------for msg------------------>
<div class="col-md-6">
            <div class="card msg">
             <div class="card-header">
                <h5>Message Information</h5>
            </div>
            <hr>
           <?php
           $paid = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>5,'transation_nature'=>2));
           $bll=$inv;
            $msg_grp = $billmodel->get_item_name('message_groups_tbl',$where = array('message_type'=>14,'trans_number'=>$bll[0]->trans_number));
          $msg = "";
          $status='';
          if(count($msg_grp)>0){
              $m = $billmodel->get_item_name('messages',$where = array('send_no'=>$msg_grp[0]->send_number));
                       
                         if(count($m) > 0){
                            $msg = $m[0]->message;
                            $msg= str_replace(array("\r","\n"),' ',$msg);
                          if($m[0]->sent_status == 1) {
                           $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description;
                          }elseif($m[0]->sent_status == 2){
                            $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description." <br>Delivered Date: ".$m[0]->time_delivered;
                          }
                        }
                    }
             if($msg==""){
if($v_transaction[0]->voucher_type==8){
   $status="<span class='text-red'>Not Sent</span>";
         $msg = "Voucher ".$bll[0]->trans_number." to ".$name." for ".format_number_with_decimals($paid[0]->amount)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
}else{
            $status="<span class='text-red'>Not Sent</span>";
         $msg = "Voucher ".$bll[0]->trans_number." to ".$name." for ".format_number_with_decimals($paid[0]->amount)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
                }}

              // print_r($bll);
                   ?>
                
          
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Message:</th>
                        <td id="msg"><?= $msg; ?> </td>
                    </tr>
                    <tr>
                        <th>Status:</th>
                        <td id="msg"><?= $status; ?> </td>
                    </tr>
                    

                </table>
            </div>
            </div>
            <div class="col-md-1">
                <?php
                 if($delete==1){
                ?>
        <button type="button" class="btn btn-danger  float-left" onclick='deletePayment("<?= $inv[0]->trans_number; ?>",1)'>Delete</button> 
              <?php } ?>
               <?php
                 if($delete==3){
                ?>
        <button type="button" class="btn btn-danger  float-left" onclick='deletePayment("<?= $inv[0]->trans_number; ?>",3)'>Delete</button> 
              <?php } ?>

              <?php
                 if($delete==2){
                ?>
        <button type="button" class="btn btn-danger  float-left" onclick='deletePayment("<?= $inv[0]->trans_number; ?>",2)'>Delete</button> 
              <?php } ?>
                                        <?php
                 if($delete==5){
                ?>
        <button type="button" class="btn btn-danger  float-left" onclick='deletepayrollPayment("<?= $inv[0]->trans_number; ?>","<?=$paid[0]->amount?>","<?=$leger_transaction[0]->name_id;?>","<?=$ledger11[0]->id?>")'>Delete</button> 
              <?php } ?>
             </div>
        </div>
         <div class="col-md-6">
            <?php
if(isset($advances) && !empty($advances)){
            ?>
            <div class="card">
            <div class="card invoice">
              <div class="card-header">
                <h5>Repayment Schedule</h5>
            </div>
            </div>
            <div class="card-body">
                 <table class="table" style="border:1px solid black;">
                       <tr style="border:1px solid black;">
                       <th style="border:1px solid black;">Payroll Year</th>
                       <th style="border:1px solid black;">Payroll Month</th>
                       <th style="border:1px solid black;">Amount</th>
                   </tr>
                   
                    <tbody style="border:1px solid black;">
                        <?php 
                        $total_advance=0;
                          foreach ($advances as $data){
                               $total_advance+=$data->advance_amount;
                        ?>
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;"><?=$data->payroll_year??""?></td>  
                           <td style="border:1px solid black;"><?=$data->month??""?></td>  
                          <td class="text-right" style="border:1px solid black;"><?=format_number_with_decimals($data->advance_amount)??""?></td>  
                         
                        </tr>
       <?php
   }
       ?>

                        
                    </tbody>
                    <tfoot>
                        <tr style="border:1px solid black;">
                        <td style="border:1px solid black;" colspan="2" class="fw-bolid"><b>Total</b></td>
                        <td class="text-right fw-bold" style="border:1px solid black;"><?= format_number_with_decimals($total_advance);?></td>
                        </tr>
                    </tfoot>
                </table>
                
            </div>
            <?php
        }?>
        </div>
        </div>
<!-----------------end for msg------------------>

  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Add Comment</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <!-- <div id="Viewrejected"></div> -->
          <form class="form-group" id="RejectComment">
              <div class="form-group">
                  <textarea class="form-control" name="comment" id="comment">
                      
                  </textarea>
              </div>
              <button type="button" class="btn btn-primary" id="savecomment">Submit</button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="viewreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="close_rept()">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('viewreceipt_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
<!-- ------manage invoice modal------- -->
<div class="modal fade" id="viewinvoice" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"  style="z-index: 1400;">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5>Credit Note Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewinvoice_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
       
        <button type="button" class="btn btn-primary"  data-toggle="modal" onclick="invoice_print()"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="view_voucher" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" onclick="close_printout()"aria-label="Close"></button>
      </div>
      <div class="modal-body" id="voucher_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="close_printout()">Close</button>
          <button type="button" class="btn btn-primary" onclick="printable_voucher2('voucher_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>



   <script type="text/javascript">
    var transId='<?php echo $inv[0]->id;?>';
 

    function CloseAttachmnt2() {
        $('#Attchmnt2').hide(100);
       
    }
       function displayImage(image_attachment)
       {
         $('#Attchmnt2').show(100);
        $('#ViewAttachment').html('<iframe src="<?php echo base_url() . '../public/transaction_files/'; ?>' + image_attachment + '" style="width:100%;height:500px"></iframe>');
                
       }
       //////////////////// for approved bill response ///////////////////////

     
       /////////////////// for rejected bill response ////////////////////////////
       

 function CloseAttachmnt2() {
        $('#Attchmnt2').hide(100);
       
    }
       function view_attachement(image_attachment)
       {
       // alert(2);
         $('#Attchmnt2').show(100);
        $('#ViewAttachment').html('<iframe src="<?php echo base_url() . '../public/transaction_files/'; ?>' + image_attachment + '" style="width:100%;height:500px"></iframe>');
                
       }

       function Remove_item(stId,tn,amount){
           var confirmation = confirm("Are you sure you want to delete this item?");
        if (!confirmation) {
            //e.preventDefault(); // Prevents the deletion if the user cancels
            return;
        }
       //alert(stId+'/'+tn+'/'+amount);
       var data='student_id='+stId+'&trans_number='+tn+'&amount='+amount;
        $.ajax({
            type: "GET",
            url: "<?= base_url('/index.php/BillController/delete_approval_data')?>",
            data: data,
           success: function(res){
            if(res==1){
         toastr.warning('Please! delete the entire voucher');
            }else{
            toastr.success('Deleted Successfully');
                $('#Viewapproval').html(res);
            }
                 
            },
            error: function ()
            {
         toastr.error('Sorry!, Something went wrong');
            }
        });
       }


       function edit_amount(id,tn,amount) {
     var price=amount;
     
   //  alert(price);
     //$('#cash'+id).toggle(50);
     $('#cash'+id).css('width', '300px').toggle(100);
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/ivoice_popup'; ?>/"+id,
            beforeSend: function () {
                $('#prcres'+id).html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#prcres'+id).html(result);
               // console.log(prc);
             document.querySelector('[id="cash_amt'+id+'"]').value = price;
             document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }

function savebtn(){
      var refund=$('#refund_id').val();
     // alert(refund);
      if(refund==1){
     save_updated_refund();
           }else if(refund==2){
       save_updated_sms();     
           }
           else{
          var tn='<?php echo $inv[0]->trans_number;?>';
          var stId=$('#item_id').val();
          var amount=parseInt($('#cash_amt'+stId).val());

    $('#prcres'+stId).html('<span class="fa fa-spin fa-spinner"></span>Updating...');
     
         var data='student_id='+stId+'&trans_number='+tn+'&amount='+amount;
         //alert(data);
        $.ajax({
            type: "GET",
            url: "<?= base_url('/index.php/BillController/edit_approval_data')?>",
            data: data,
           success: function(res){
             $('#cash'+stId).hide();
            if(res==1){
         toastr.warning('Please! Enter amount greater than 0');
            }else{
            toastr.success('Edited Successfully');
                $('#Viewapproval').html(res);
            }
                 
            },
            error: function ()
            {
         toastr.error('Sorry!, Something went wrong');
            }
        });
    }
       }

function edit_account(nature,accId,tn){

 $('#popup_account'+nature).toggle(100);

}
function cancelAccPopup(n){
$('#popup_account'+n).hide();
}

function changeAccount(tn,n){
 var ledger_id=$('#bankId'+n).val();
 //alert(tn+'-/-'+ledger_id);
  $('#fdbk'+n).html('<span class="fa fa-spin fa-spinner"></span>Updating...');
     
    var data='acc_id='+ledger_id+'&trans_number='+tn+'&trans_type='+5+'&n='+n;
         //alert(data);
        $.ajax({
            type: "GET",
            url: "<?= base_url('/index.php/BillController/edit_ledger_account')?>",
            data: data,
           success: function(res){
            $('#popup_account'+n).hide();
            if(res==1){
         toastr.warning('Please! Enter amount greater than 0');
            }else{
            toastr.success('Edited Successfully');
                $('#Viewapproval').html(res);
            }
                 
            },
            error: function ()
            {
         toastr.error('Sorry!, Something went wrong');
            }
        });
}

 function edit_amount_refund(type,old_tn,new_tn,amount) {
     var price=parseInt(amount);
     id=new_tn;
    // alert(price);
     //$('#cash'+id).toggle(50);
     $('#refundPopup').css('width', '300px').toggle(100);
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/ivoice_popup'; ?>/"+id,
            beforeSend: function () {
                $('#popup_details').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#popup_details').html(result);
               // console.log(prc);
              //  alert(price);
             document.querySelector('[id="cash_amt'+id+'"]').value =price;
             document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }

    function save_updated_refund(){
     var tn='<?php echo $inv[0]->trans_number;?>';
          var nwtn=$('#item_id').val();
          var refund_trans_type=$('#refund_trans_type').val();
           var old_trans_no=$('#old_trans_no').val();
          var amount=parseInt($('#cash_amt'+nwtn).val());

    $('#popup_details').html('<span class="fa fa-spin fa-spinner"></span>Updating...');
     
         var data='trans_type='+refund_trans_type+'&old_trans_no='+old_trans_no+'&trans_number='+tn+'&amount='+amount;
         // alert(data);
         // return;
        $.ajax({
            type: "GET",
            url: "<?= base_url('/index.php/BillController/edit_refund_data')?>",
            data: data,
           success: function(res){
             $('#refundPopup').hide();
            if(res==1){
         toastr.warning('Please! Enter amount greater than 0');
            }else{
            toastr.success('Edited Successfully');
                $('#Viewapproval').html(res);
            }
                 
            },
            error: function ()
            {
         toastr.error('Sorry!, Something went wrong');
            }
        });
    }

function edit_amount_sms(tn,amount){

     var price=parseInt(amount);
     id=tn;
    // alert(price);
     //$('#cash'+id).toggle(50);
     $('#smsPopup').css('width', '300px').toggle(100);
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/ivoice_popup'; ?>/"+id,
            beforeSend: function () {
                $('#sms_details').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#sms_details').html(result);
               // console.log(prc);
              //  alert(price);
             document.querySelector('[id="cash_amt'+id+'"]').value =price;
             document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
}

function save_updated_sms(){
    var tn='<?php echo $inv[0]->trans_number;?>';
        
          var amount=parseInt($('#cash_amt'+tn).val());

    $('#sms_details').html('<span class="fa fa-spin fa-spinner"></span>Updating...');
     
         var data='trans_number='+tn+'&amount='+amount;
          //alert(data);
         // return;
        $.ajax({
            type: "GET",
            url: "<?= base_url('/index.php/BillController/edit_sms_data')?>",
            data: data,
           success: function(res){
             $('#smsPopup').hide();
            if(res==1){
         toastr.warning('Please! Enter amount greater than 0');
            }else{
            toastr.success('Edited Successfully');
                $('#Viewapproval').html(res);
            }
                 
            },
            error: function ()
            {
         toastr.error('Sorry!, Something went wrong');
            }
        });
}

function load_class_list(){
  //  alert("yes");
    
    $('#addDetails').load('<?= base_url('/index.php/BillController/load_class_choices')?>');
}

function load_control_list(){
  //  alert("yes");
    
    $('#addDetails').load('<?= base_url('/index.php/BillController/load_control_choices')?>');
}

function updatesupplier(n){
    $('#change'+n).toggle(100);
   }
function cancelbtn(n){
         // $('#changeDate'+n).hide();
          $('#change'+n).hide();
     }

   function saveDate(tn,n){
        if(n==3){
           var dt=$('#ref').val();
        }else if(n==4){
            var dt=$('#supplier_id').val();
        }
        else{
            var dt=$('#tdate'+n).val();
        }
         
            $.ajax({
               url: '<?php echo base_url() . '/index.php/BillController/update_transDate'; ?>/'+tn+'/'+dt+'/'+5+'/'+n,
                 error: function() {
                    toastr.error('Something is wrong','error');
                 },
                 success: function(res) {
                     if(res !=1){
                        
                    toastr.success("Updated successfully.", "success");
                     $('#Viewapproval').html(res);
                    }else{
                       toastr.error("Failed to update.", "error");  
                    }
                   $('#change'+n).hide();
                      
                 }
              });
          }


          function deletePayment(inv_id,j){
           // alert(inv_id);
         swal({
            title: "Delete Payment",
            text: 'Are you sure?',
           
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Ok",
            cancelButtonText: "Cancell",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
                
                if(j==1){
                var myurl='<?php echo base_url() . '/index.php/BillController/delete_payments'; ?>';    
                }else if(j==2){
                    var del_over="<?php echo $del_over;?>";
                    var del_trans="<?php echo $del_trans;?>";
             var myurl='<?php echo base_url() . '/index.php/BillController/delete_refund'; ?>/'+del_over+'/'+del_trans;  
                }else if(j==3){
             var myurl='<?php echo base_url() . '/index.php/BillController/delete_sms_charges'; ?>';  
                }
                else{
                    return;
             // var myurl='<?php echo base_url() . '/index.php/BillController/delete_payments'; ?>'+j;  
                }
            var data = 'trans=' + inv_id+'&'+$("#header_form").serialize(); 
          //  alert(data);
              $.ajax({
            type: 'POST',
            url: myurl,
            data: data,
            success: function (res) {
              var data = JSON.parse(res);
              if(data['status'] == "1"){
                             swal({
               title: "The payment deleted successfuly",
                        type: "success",
                 confirmButtonText: "OK",
        closeOnConfirm: true
            },
            function(){
           
                window.location.reload();
    }            );
            }else{
             swal("error","Deletion failed","error");   
            }
            },
            error: function (){
                alert('');
                    swal("error","Error encounted","error");
            }
        });
            } else {
              swal("Cancelled");
            }

          });
                    }
                    
    function deletepayrollPayment(trans_no,paid_amount,staff_id,ledger_id){
    $('#delete_btn').prop("disabled", true);
   swal({
        title: "Are you sure?",
        text: "You will not be able to recover this payment details!",
        type: "warning",
        customClass: 'swal-wide',
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes, delete!",
        cancelButtonText: "No, cancel!",
        closeOnConfirm: false,
        closeOnCancel: false,
        height: '200px'
    }, function (isConfirm) {
        if (isConfirm) {
  $.ajax({
    method: 'POST',
    url: '<?php echo base_url() . '/delete-payroll_payment'; ?>',
 data: { trans_no:trans_no,paid_amount:paid_amount,staff_id:staff_id,ledger_id:ledger_id},
    dataType: 'json',
    beforeSend: function () {
swal({
    title: "Please wait...",
    text: "<i class='fa fa-spin fa-spinner'></i> Deleting payment, please wait...",
    html: true,
    showConfirmButton: false,
    allowOutsideClick: false
});
        },
    success: function(data){
        // swal.close();
        if(data['status'] == "1"){ 
        $('#delete_btn').prop("disabled", false);   
      swal({
               title: "The payment deleted successfuly",
                        type: "success",
                 confirmButtonText: "OK",
        closeOnConfirm: true
            },
            function(){
           
                window.location.reload();
    }            );

        } else {
            $('#delete_btn').prop("disabled", false);
            swal("Warning", data['description'], "warning");
        }
    },
    error: function(xhr, status, error){
         //swal.close();
        $('#delete_btn').prop("disabled", false);
        swal("Error", "Something went wrong while Deleting payroll.", "error");
    }
});

 }  else {
            swal("Cancelled", "The  payment is safe", "info");
            $('#delete_btn').prop("disabled", false);
        }
    });

}

   </script>



    
    

