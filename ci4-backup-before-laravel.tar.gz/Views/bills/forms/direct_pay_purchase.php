<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css');?>"/>
<div class="card-body">
                    <form class="form-horizontal" id="billbtn" enctype="multipart/form-data">
                         <div id="feedback"></div>
                         <div class="row">
                            <div class="col-md-6">

                    <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Paid To<span class="text-danger">*</span></label>
                    <div class="col-sm-8">
                    <select name="billto" class="form-select form-control" id="load_suppl" style="width:100%;height: 15px;"></select>
                    </div>
                    </div>
                     <div class="form-group row" id="payer_name_row" style="display: none;">
                     <label  class="col-sm-4 col-form-label">Name<span class="text-danger">*</span></label>
                                         
                     </div>
                    
            
            </div>   
                                   
        </div>
  
<div class="form-group row">
<label class="col-sm-2 col-form-label">Charged Items<span class="text-danger">*</span></label>
<div class="col-sm-6">
<select class="form-select form-control" id="js-example-data-ajax" style="width:100%;height: 15px;"></select>
</div>
</div>

                     <div class="row">
                            <div class="col-md-2"></div>
                            <div class="col-md-9">
                                <div class="card">
                                    <p Class=" d-flex justify-content-center mt-3">CHARGED ITEMS</p>
                                    <table class="table table-hover table-vcenter mb-0 text-nowrap" id="table">
                                    <thead>
                                            <tr>
                                                <th>No#</th>
                                                <th>Ledger</th>
                                                <th>Item Name</th>
                                                <!-- <th>Attribute</th>
                                                 <th>Size</th>
                                                <th>UOM</th> -->
                                                 <th>Qty</th>
                                                <th>Last Price
                                                  <div  class="cust_popup" id="cashInv" style="display: none">
                                                    <h6>Change price</h6>
                                                <div id="prcresInv"></div>
                                             </div>
                                                </th>
                                                 
                                                <th>Total</th>
                                                <th style="text-align:right">Balance</th>
                                                <th>Action</th>
                                            </tr>
                                    </thead>
                                    <tbody id="show_item">

                                    </tbody>
                                    </table>
                                    <table>
                                        <tr>
                                        <th class="col-sm-6"></th>
                                        <th id="totalp" colspan="3">
                                        <!-- <span id="totalp" style="margin-left:400px;"></span> -->
                                        </th>
                                        </tr>
                                        </table>
                                </div>
                            </div>
                        </div><br>
                    <!-- Here starts the form for accounts payable  -->

                         <div class="form-group row" style="margin-left: 20px;">
                                                       <!-- pdf file here starts -->

                
                            <label class="col-md-2 col-form-label">Attach File<span class="text-danger"></span></label>
                            <div class="col-md-4" style="padding-top:10px;">

                            <input type="file" id="imageinput" name="uploadFiles[]" class="form-control" multiple accept=".pdf, .doc, .xls, .docx, .xlsx, .jpg, .jpeg, .png"  onchange="previewFile(event)" >
                           </div>
                       


                            <label class="col-md-2 col-form-label">Approval Comment<span class="text-danger">*</span></label>
                            <div class="col-md-4 mt-3">
                            <input type="text" name="bill_comment" id="bllcmt" value="Please Approve!" required class="form-control">
                           </div>
                               
                            <div class="preview-container" id="previewContainer"></div>

                           </div>

                            <div id="file-preview-container" onclick="removeattachment()">
                           </div>
                        <!-- Here it ends the payable accounts --> 
                         <div class="form-group row">
                            <div class="col-md-8">
                                <button type="submit" id="create_bill" class="btn btn-primary float-right">Create</button>
                            </div>
                        </div>
                        </form>
                            </div>

 <script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
 <script type="text/javascript">

    var hold_selected_items = [];
       $(document).ready(function(){
        
         $('#js-example-data-ajax').select2({
            ajax: {
                url: "<?= base_url('/index.php/AccomodationController/load_purchase_data'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            },
            escapeMarkup: function (markup) {
                        return markup; // Don't escape HTML
                        },
                        templateResult: function (data) {
                        return data.text; // Render the full HTML in 'text'
                        },
        });

        $('#js-example-data-ajax').on('select2:select', function (e) {
            selectedItems();
        });
        //var prc; 
        function selectedItems(){  
            var rows = '';
           var itemData = 'item_selected='+$('#js-example-data-ajax').val()+'&selected_items_array='+hold_selected_items;
           //alert(itemData);
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_Accomodationdata1')?>",   
                data:itemData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    }else{
                        var len  = data.length;
                        
                        for (var i = 0; i <len; i++ ){
                            hold_selected_items.push(data[i]['id']);// push all selected items
                            var prc = data[i]['last_price'];
                            price= prc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); 
                            var name = data[i]['iname'];
                            var ledger = data[i]['account_name'];
                            var avg_cost = data[i]['avg_cost'];
                            var item_balance = data[i]['item_balance'];
                            var iid = data[i]['id'];
                            //var qty = window.prompt("Enter quantity");
                            //var tprice = qty*prc;
                           
                            
                            rows += '<tr id="table_row'+ iid +'">';

                           rows+='<td><input type="hidden" name="iid[]" value="'+iid+'">'+ iid +'</td>';
                             rows+='<td>'+ ledger +'</td>';
                             rows+='<td>'+ name +'</td>';
                            //rows += '<td>'+ name +'</td>';
                            // rows += '<td>'+ attribute +'</td>';
                            // rows += '<td>'+ size +'</td>';
                            // rows += '<td>'+ 1 +'</td>';
                            rows += '<td><input type="text" value="'+1+'" style="border:none;cursor:pointer;width:40px;text-align:right;" id="quantity'+iid+'" name="quantity'+iid+'" onkeyup="changeQuantity('+iid+')"></td>';
                            // rows += '<td><input type="hidden"  name="price'+iid+'" value="'+prc+'">'+ prc +'</td>';
                            rows += '<td><a class="cost" id="costInv' +iid+'" href="javascript:void(0);" style="text-decoration-style:dotted" onclick="getidInv(' +iid+ ','+prc+')"><input type="text" value="'+prc+'" style="border:none;cursor:pointer;color:blue;border-bottom:1px dotted blue;width:60px;text-align:right;" name="price'+iid+'" id="pric'+iid+'" readonly></a></td>';
                            rows += '<td id="ttl'+iid+'">'+price+'</td>';
                            rows+='<td style="text-align:right">'+ item_balance +'</td>';              rows += '<td><a href="javascript:RemoveSelectItemRow('+iid+','+i+');" class="btn btn-danger btn">X</a></td>';
                            
                            rows += '</tr>';
                            $('#show_item').append(rows);
                            calculateTotal();
            
                        }
                      
                    }
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }
                
           });  
        }

    });
document.addEventListener('DOMContentLoaded', function () {
        const imageInput = document.getElementById('imageinput');
        const previewContainer = document.getElementById('previewContainer');
        const uploadedFiles = [];

        imageInput.addEventListener('change', function (event) {
            previewContainer.innerHTML = ''; // Clear previous previews
            uploadedFiles.length = 0; // Clear the array

            const files = event.target.files;

            for (const file of files) {
                const reader = new FileReader();

                reader.onload = function (e) {
                    const previewImage = document.createElement('div');
                    previewImage.className = 'preview-image';

                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.alt = 'Image Preview';
                    img.style.width = '100%';
                    img.style.height = '100%';

                    const removeButton = document.createElement('div');
                    removeButton.className = 'remove-button';
                    removeButton.innerHTML = 'X';

                    removeButton.addEventListener('click', function () {
                        previewContainer.removeChild(previewImage);
                        
                        // Remove the corresponding file from the array
                        const index = uploadedFiles.indexOf(file);
                        if (index !== -1) {
                            uploadedFiles.splice(index, 1);
                        }
                    });

                    previewImage.appendChild(img);
                    previewImage.appendChild(removeButton);
                    previewContainer.appendChild(previewImage);

                    // Add the file to the array
                    uploadedFiles.push(file);
                };

                reader.readAsDataURL(file);
            }
        });

        // Add the array of files to the FormData object when submitting the form
        document.getElementById('uploadForm').addEventListener('submit', function (event) {
            const formData = new FormData(this);

            for (const file of uploadedFiles) {
                formData.append('images[]', file);
            }

           
        });
    });



function isImageFile(file) {
    // Check if the file type is an image
    return file.type.startsWith('image/jpeg/jpg/png/gif');
}

   ///////////////////here load expense ledgers starts here///////////////
    var hold_selected_accounts = []; // hold all selected items
      ///////////////////######## Here is For Budget Ledger ##############
     /////////////// function to save all the Bill Details ///////////////

      $('#billbtn').submit(function(e){ 
        
        if(!$('#load_suppl').val() >0){
           swal('Warning','Please select paid to!','warning');
           return
        }
       // alert($('#load_suppl').val());
        // return;
        var form_data = new FormData($('#billbtn')[0]);
        var headerform = $("#header_form").serializeArray();
        var voucher=$("#voucher_form").serializeArray();
        $.each(headerform,function(index,field){
            form_data.append(field.name,field.value);
        });
        $.each(voucher,function(index,field){
            form_data.append(field.name,field.value);
        });

        form_data.append('account_payable',$("#acc_payable").val());
        form_data.append('bill_no',$("#billNo").val());
        form_data.append('due_date',$("#due_date").val());

        $.ajax({
            method: 'POST',
        url: '<?php echo base_url() . '/index.php/BillController/save_directPay_purchase'; ?>',            
          data: form_data,
            contentType: false,
            processData: false,
            success:function(res){
             $('#create_bill').prop("disabled", true);
                var data = JSON.parse(res);
                if(data['status'] == "1"){

                     swal("success",data['description'],"success");

                    
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#create_bill').prop("disabled", false);
                    swal("warning",data['description'],"warning");
                 
                }
            },
            error:function(res){
                $('#create_bill').prop("disabled", false);
                 swal("warning",data['description'],"warning");

                            }
        });

        e.preventDefault();
    
    });
      ////////////// function to load bill to supplier ///////////////
        $(document).ready(function(){
        // fetch_data();
         $('#load_suppl').select2({
            ajax: {
                url: "<?= base_url('load_supplier'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });
     });

 $("#capture-btn").click(function () {
            $('#capture').show();

            });
   function RemoveSelectItemRow(item_id,v){
       // alert('two');
        for( var i = 0; i < hold_selected_items.length; i++){ 
    
            if ( hold_selected_items[i] == item_id) {                 
                hold_selected_items.splice(i, 1); 
            }
        
        }
        
        $('#table_row'+item_id).remove();
        calculateTotal();
    }

 function changeQuantity(iid){
   
    var qty=$('#quantity'+iid).val();
    var price=$('#pric'+iid).val();
    var ttl=qty*price;
    $('#ttl' + iid).html(ttl.toLocaleString()); 

   calculateTotal();
    
 }
function calculateTotal(){
 var totalsum=0;
     $('input[name="iid[]"]').each(function(){
    var iiid = $(this).val();

    totalsum = totalsum + parseInt($('#ttl' + iiid).html().replace(/,/gi, ""));
   // console.log('iid =', iiid);
});
    document.getElementById("totalp").innerHTML = "Total = " + totalsum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
   
}


function getidInv(id,prc) {
    
     $('#cashInv').toggle(100);
     
       $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/StaffController/priceview'; ?>",
            beforeSend: function () {
                $('#prcresInv').html('<span class="fa fa-spin fa-spinner"></span>');
            },
            success: function (result) {
                $('#prcresInv').html(result);
                console.log(prc);
               // alert(prc);
             document.querySelector('[id="cash_amt"]').value = prc;
             document.querySelector('[id="item_id"]').value = id;
            },
            error: function () {
                alert('Sorry! An Error encoutered!');
            }
        });
       
    }
    totalsum=0;
       function savebtn(){
      //alert(sum);
     
      var cash=$('#cash_amt').val();
      var item_id=$('#item_id').val();
      //alert(item_id); 
      for( var i = 0; i < hold_selected_items.length; i++){ 
           id1=hold_selected_items[i];
           if(id1==item_id){
            var cashAmt =parseInt(cash);
            document.querySelector('[id="pric'+id1+'"]').value = cashAmt;
            // document.querySelector('[id="pric'+id1+'"]').value = cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            document.getElementById("ttl"+id1).innerHTML = cashAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

           // $('#cost'+id1+'').append(cashAmt);
           }else{
            var cashAmt1 =$('#pric'+id1+'').val();
            let result = cashAmt1.replace(/,/gi, "");
            var cashAmt =parseInt(result);
           // alert(cashAmt);
           }
       
       // totalsum=totalsum+cashAmt;
        }
        $('#cashInv').hide(); 
         calculateTotal();   
   
    }
    </script>