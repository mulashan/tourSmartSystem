<?php
//print_r($trans);
?>
<style type="text/css">
    table {
            width: 100%; /* Adjust this as needed */
            /*table-layout: fixed; /* Makes column widths fixed */
        }
         td {
          
            word-wrap: break-word; /* Ensures long text wraps */
        }
</style>

 <?php
if(count($trans)>0){
    ?>
     <div class="form-group row" id="all_input" style="display:none;">
                              
                         <div class="col-md-6"></div>
                        <div class="col-md-6">
                           
                            <div id="bank_details1"></div>
                          
                            </div>
                            </div>

     <div class="pull-right mt-3 mb-3">
    <button type="button" class="btn btn-primary pull-left me-3" id="controlPay" onclick="createRefund()"><span class="fa fa-plus"></span> Add</button>
    
    </div>
     <?php
       }
    ?>
<div class="card">
   
     <form id="data_form">

                <table class="table"  id="myTable2">
                                <thead>
                                    <tr>
                                        <th>#.</th>
                                       
                                        <th>
                                           <input type="checkbox" name="" value="" onclick="AllCalc()" id="Allselected"> All
                                        </th>
                                        <th>Rct No.</th>
                                        <th>inv type.</th>
                                        <th>trans. Date</th>
                                       <th>Student Name</th>
                                        <th>control No</th>
                                      
                                        <th>charged</th>
                                        
                                        <th>Pay</th>
                                      
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                      <?php
                      $sn=0;
                   
                      // return;
                      $item_list=array();
                      foreach ($trans as $kv) {
                      	
                      	
                      $sn++;
                    $item_list[] = array($sn);
                      ?>

                    <input type="hidden" name="voucher[]" value="<?=$sn;?>">
                        <input type="hidden" name="trans_type<?=$sn;?>" value="2">
                           <input type="hidden" name="trans_no<?=$sn;?>" value="<?=$kv['trans_number'];?>">
                            <input type="hidden" name="inv_no<?=$sn;?>" value="<?=$kv['trans_no'];?>">
                            <input type="hidden" name="student_id<?=$sn;?>" value="<?=$kv['student_id'];?>">
                            <input type="hidden" name="name_type_id<?=$sn;?>" value="<?=$kv['name_type_id'];?>">
                        
                            

                    <tr onclick="selectRow('<?php echo $sn; ?>')" id="<?php echo $sn; ?>">
                     	<td><?= $sn;?></td>
                        <td>  
                            <input type="checkbox" name="selected[]" value="<?php echo $sn; ?>" onclick="selectRow('<?php echo $sn; ?>')" id="selected<?php echo $sn; ?>"></td>
                     	<td><?= $kv['trans_number']?></td>
                     	<td><?= $kv['invoice_type']?></td>
                     	<td><?= $kv['trans_date']?></td>
                     	<td  style=""><?= $kv['name']?></td>
                     	<td><?= $kv['control']?></td>
                     	<td class="text-right" id="bal<?= $sn;?>"><?= number_format($kv['amount']);?></td>
                     	<td> <input type="text" class="form-control" style="width:100px;" id="amount<?= $sn;?>" onkeyup="AmtCalc('<?= $sn;?>')" value="" name="amount<?= $sn;?>"></td>
                     </tr>
                      <?php
                      }
                      ?>
                 </tbody>
             </table>

      </form>
    </div>

    <script type="text/javascript">
     $("#all_input").show();
     // $("#allinput_id").val('');
       refreshCalc();
       
       function AllCalc(){
       // alert(i);
             var total=0;
            var amount=0;
            var balance=0;
           
           var rememberAll = document.getElementById("Allselected");
           
     var values=<?php echo json_encode($item_list);?>;
          for( var i = 0; i < values.length; i++){ 
          var id=values[i];
           var bal=0; 
             var row = document.getElementById(id);  
              var remember = document.getElementById("selected"+id);
            if(rememberAll.checked){
            remember.checked=true; 
            if (row) {
    
            row.style.backgroundColor = 'black';
            row.style.color = 'white';
            } else {
            console.error("Invalid row ID");
            }  
           bal= $("#bal"+id).html().replace(/,/gi, "");
    
            }else{
           remember.checked=false; 
            if (row) {
      row.style.backgroundColor = 'white';
      row.style.color = 'black';
        } else {
        console.error("Invalid row ID");
        } 

            }
            
        
            $("#amount"+id).val(parseInt(bal).toLocaleString());
         // alert(id);
           amount=$("#amount"+id).val().replace(/,/gi, "");
           if(amount !=""){
            total=total+parseInt(amount);
           }
           
            
        }
          //alert(total);
          
          balance= $("#balance").html().replace(/,/gi, "");
          balance=parseInt(balance)-total;
          // alert(balance);
          $("#after").html(balance.toLocaleString());
          $("#thispay").html(total.toLocaleString());
      
      
  }

  function selectRow(id){
          var total=0;
            var amount=0;
            var balance=0;
            var bal=0; 

         var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {
    row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      bal= $("#bal"+id).html().replace(/,/gi, "");

       if (row) {

    row.style.backgroundColor = 'black';
      row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        }

 $("#amount"+id).val(parseInt(bal).toLocaleString());
 // alert(id);
     var values=<?php echo json_encode($item_list);?>;
          for( var i = 0; i < values.length; i++){ 
          var id=values[i];
   amount=$("#amount"+id).val().replace(/,/gi, "");
   if(amount !=""){
    total=total+parseInt(amount);
   }
}

       balance= $("#balance").html().replace(/,/gi, "");
          balance=parseInt(balance)-total;
          // alert(balance);
          $("#after").html(balance.toLocaleString());
          $("#thispay").html(total.toLocaleString());
      
      }

          function AmtCalc(i){
       // alert(i);
             var total=0;
            var amount=0;
            var balance=0;
            var bal= $("#bal"+i).html().replace(/,/gi, "");
            var input=$("#amount"+i).val().replace(/,/gi, "");
           
            if(input==""){
                input=0;
            }

             
            
            if(parseInt(input) > parseInt(bal)){
           var myAmount = Number(String(input).slice(0, -1));
            //alert(myAmount);
           $("#amount"+i).val(myAmount.toLocaleString());
           toastr.info("Please enter amount less or equal to " + bal);
            }else{
            $("#amount"+i).val(parseInt(input).toLocaleString());
            
         var values=<?php echo json_encode($item_list);?>;
          for( var i = 0; i < values.length; i++){ 
          var id=values[i];
         // alert(id);
          
           amount=$("#amount"+id).val().replace(/,/gi, "");
           if(amount !=""){
            total=total+parseInt(amount);
           }
           
            }
          //alert(total);
          
          balance= $("#balance").html().replace(/,/gi, "");
          balance=parseInt(balance)-total;
          // alert(balance);
          $("#after").html(balance.toLocaleString());
          $("#thispay").html(total.toLocaleString());
      }
      }

      function refreshCalc(){
       var bank_id=$('#bank_id').val();
       //alert(bank_id);
       $('#bank_details1').load("<?php echo base_url() . '/index.php/BillController/bank_payments'; ?>/"+bank_id);

         var total=0;
            var amount=0;
            var balance=0;
         var values=<?php echo json_encode($item_list);?>;
          for( var i = 0; i < values.length; i++){ 
          var id=values[i];
         // alert(id);
           amount=$("#amount"+id).val().replace(/,/gi, "");
           if(amount !=""){
            total=total+parseInt(amount);
           }
           
            }
          //alert(total);
          
          balance= $("#balance").html().replace(/,/gi, "");
          balance=parseInt(balance)-total;
           //alert(balance);
          $("#after").html(balance.toLocaleString());
          $("#thispay").html(total.toLocaleString());
      }
      
      function createRefund(){
        var payed= $("#thispay").html();
         if(payed==0){
       toastr.error("Please! This payment amount is 0");
       }else{
     var data= $("#data_form").serialize()+"&"+$("#header_form").serialize()+'&trans='+$('#trans').val();
        
     
     $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillController/update_controlCharges'; ?>',
            data: data,
            success: function (res) {
              var data = JSON.parse(res);
              if(data['status'] == "1"){
                //$("#voucher_type").change();
              //  $("#bank").change();
               //  $('#all_list').html('');
                 refresh_refund();
                 
             swal("success",data['description'],"success");
              //refreshCalc();
            }else{
             swal("error","Failed to create Payment","error");    
            }
            },
            error: function (){
                alert('error encounted');
            }
        });

       }
      }

      function refresh_refund() {
         var trans_no =$('#trans').val();
           var data = 'trans_no=' + trans_no+'&trans_type='+5+'&vocher='+1;
           //alert(dta);
           // return;
            $.ajax({
                type: "POST",
               url: "<?= base_url('/index.php/BillController/get_edit_approval_data')?>",
                 data: data,
                success: function (res) {
                     $('#Viewapproval').html(res);
                },
                error: function () {
                    $('#Viewapproval').html('<div class="alert alert-warning">Fail to retreive results.!!</div>');
                }
            });

  
    };
</script>