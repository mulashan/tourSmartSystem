

 <?php
  $billmodel = new App\Models\BillModel();
  $bmodel = new App\Models\BillingModel();
  $cmodel = new App\Models\ClassesModel();
  $appItems = $cmodel->get_applications_items();
  $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$recpt[0]->trans_number,'trans_type' =>8));
  //$invoice_type = $bmodel->get_item_join_table($recpt[0]->trans_number);
  $student_name = "";
  $name_type = "";
   $amount = 0;
if(count($leger_transaction) > 0){
    $amount = $leger_transaction[0]->amount;
  if($leger_transaction[0]->name_type_id == 7){
        $app = $bmodel->get_item_name('users',$where = array('user_id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->user_id;
        $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        
       
   }
  
    $company_reg = $bmodel->get_table_details('company_tbl');
 //   $pay_dtls = $bmodel->get_item_name('payment_response',$where = array('reference_no' =>$control_number));
   
   $vch = $billmodel->get_item_name('voucher_relation_tbl',$where = array('payment_no' =>$recpt[0]->trans_number));
   $v_type = $billmodel->get_item_name('voucher_types_tbl',$where = array('id' =>$vch[0]->voucher_type));

}

 ?>
<div class="row">
<div class="col-md-12">
    <!-- <center><b style="font-size:14px"><u>RECEIPT</u></b></center> -->
    <center>
      <div> <img src="<?php  echo base_url('public/company_photos/'.$company_reg[0]->logo_name) ?>" style="background: white;width: 25%;height: 25%" ></div>
 <span class="mt-4"><b><?= $company_reg[0]->company_name; ?></b></span><br>
            <span class="modify" style="font-size:15px"><?= $company_reg[0]->address; ?></span>
            <div class="mb-3">
                <div><span class="modify" style="font-size:15px">Phone: +<?= $company_reg[0]->phone1; ?></span></div>
                <div><span class="modify" style="font-size:15px">Email: <?= $company_reg[0]->email; ?></span></div>
                <div><span class="modify" style="font-size:15px"> <?= $company_reg[0]->website; ?></span></div>
             
            </div>
   <span class="mt-3"> <b style="font-size:14px"><u>INTER BANK TRANSFER</u></b></span>
    </b>
</center>
    <hr>
    <table class="table table-borderless">
        <tr>
            <th>Transfer Number:</th>
            <td><?= $recpt[0]->trans_number; ?></td>
        </tr>
        <tr>
            <th>Transfer Date:</th>
            <td><?= $recpt[0]->trans_date; ?></td>
        </tr>
        <tr>
            <th>Name Type:</th>
            <td><?= $name_type; ?></td>
        </tr>
        <tr>
            <th>Transfer By:</th>
            <td><?= $student_name; ?></td>
        </tr>
    </table>
    <hr>
</div>
</div>    
    
    <?php
   
 
    ?>  
<div class="row">
    <div class="col-md-12">
        <!--<div class="card">-->
        <p class=" d-flex justify-content-center mt-3" style="font-size:18px"> TRANSFER DETAILS</p>
        <table class="table">
            <thead>
                <tr>
                    <th>FROM</th>
                    <th>TO</th>
                     <th >Description</th>
                    <th>Amount</th>
                  
                </tr>
            </thead>
            <tbody>
                <?php
                
                    $from= $billmodel->get_item_name('accounts_tbl',$where = array('id' =>$leger_transaction[0]->ledger_id,));
                    $to= $billmodel->get_item_name('accounts_tbl',$where = array('id' =>$leger_transaction[1]->ledger_id,));
                     $res= $billmodel->get_item_name('transfer_payment_tbl',$where = array('transfer_no' =>$recpt[0]->trans_number,));
                ?>
                <tr>
                    <td><?=$from[0]->account_name??""?></td>
                    <td><?=$to[0]->account_name??""?></td>
                   <td><?=$res[0]->reason??""?></td>
                    <td class=""><?=number_format($leger_transaction[0]->amount)??""?></td>
                     
                  </tr>
           
                
            </tbody>
        </table>   
           <p class=" d-flex justify-content-center mt-3" style="font-size:14px">.</p>
        <table>
        <?php
        $leg = $bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$recpt[0]->trans_number,'trans_type_id' =>8));
     $recv = $bmodel->get_item_name('users',$where = array('user_id' =>$leg[0]->updated_by));

        ?>
        
        <tr>
            <td><i>Refunded by: <?php echo $recv[0]->first_name." ".$recv[0]->last_name." ".$leg[0]->trans_date ?></i></td>
        </tr>
    </table>  

    </div>
</div> 
<br>
<center>
    <i><span>Powered by Micro Health Initiative</span></i>
</center>
<script>
function printable_rept(area) {
  var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
  disp_setting += "scrollbars=yes,width=750, height=600, left=80, top=25";
  var content_value = document.getElementById(area).innerHTML;

  var docprint = window.open("", "", disp_setting);
  docprint.document.open();
  docprint.document.write('<html><head><title>MHI</title>');

  // Add a <style> block to set the font family and other print-specific styles
  docprint.document.write('<style>');
  docprint.document.write('@media print {');
  docprint.document.write('  body {');
  docprint.document.write('    font-family: "Times New Roman", sans-serif;');
  docprint.document.write('    font-size: 15px;');
  docprint.document.write('  }');
  docprint.document.write('</style>');

  docprint.document.write('</head><body onLoad="self.print()" style="width:100%;">');

  // Modify content_value to include the colspan attribute
  var modifiedContent = content_value.replace('<td class="colspan-cell">', '<td colspan="2" class="colspan-cell">');
  docprint.document.write(modifiedContent);

  docprint.document.write('</body></html>');
  docprint.document.close();
  docprint.focus();
}

</script>



