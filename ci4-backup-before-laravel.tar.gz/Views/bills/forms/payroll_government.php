<style>
input.form-control {
    pointer-events: auto !important;
    background-color: white !important;
    z-index: 9999 !important;
    position: relative !important;
}
input.private {
       border-color: #808080;
}
.input-error {
    border: 3px solid red !important;
    animation: shake 0.3s ease-in-out 0s 2;
}

@keyframes shake {
    0% { transform: translateX(0); }
    25% { transform: translateX(-4px); }
    50% { transform: translateX(4px); }
    75% { transform: translateX(-4px); }
    100% { transform: translateX(0); }
}
.row-selected2 td {
    background-color: black !important;
    color: white !important;
    border: 1px solid white !important;
}
</style>
      <div id="submit_msg"></div>  
      <div id="submit_status"></div>  
      <div id="submit_error"></div>  
<form id="government_pay">
 <h6>Payroll List</h6>
<table class="table table-borderless">
    <thead>
        <tr>
            <th><input type="checkbox" id="selectAll2">ALL</th>
            <th>PAYROLL NO.</th>
            <th>LEDGER NAME</th>
            <th>PAYROLL DATE</th>
            <th>YEAR</th>
            <th>MONTH</th>
            <th>AMOUNT</th>
            <th>BALANCE</th>
            <th>AMOUNT TO PAY</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        if (isset($payroll)){
            $total_amount = 0;
            $total_balance = 0;
            $total_paye = 0;
                 foreach ($payroll as $index => $info){ 
                $total_amount += $info->amount;
                $total_balance += $info->balance;
        ?>
            <tr>
                <td><input type="checkbox" name="topay" class="private" value=""></td>
                <td><?= $info->payroll_id; ?></td>
                <td><?= $legers->account_name; ?></td>
                <td><?= $info->payroll_date; ?></td>
                <td><?=$info->payroll_year;?></td>
                <td><?=$info->month;?></td>
                <td><?= number_format($info->amount);?></td>
                <td><?= number_format($info->balance); ?></td>

<td>
     <input type="hidden" name="ledger_key[]" value="<?= $info->id; ?>">
     <input type="hidden" name="balance_before[]" value="<?= $info->balance; ?>">
     <input type="hidden" name="amount_before[]" value="<?= $info->amount; ?>">
     <input type="hidden" name="payroll_no[]" value="<?= $info->trans_no; ?>">
     <input type="hidden" name="ledger_id" value="<?= $info->ledger_id; ?>">
     <input type="hidden" name="transaction_type" value="<?= $info->trans_type; ?>">
     <input type="hidden" name="ledger_type" value="<?= $info->ledger_type; ?>">
     <input type="hidden" name="name_type_id" value="<?= $info->name_type_id; ?>">
     <input type="hidden" name="transation_nature" value="<?= $info->transation_nature; ?>">
     <input type="hidden" name="year[]" value="<?= $info->payroll_year; ?>">
     <input type="hidden" name="payroll_id[]" value="<?= $info->payroll_id; ?>">
     <input type="hidden" name="institution_id" value="<?= $info->institution_id; ?>">
     <input type="hidden" name="ledger_name" value="<?= esc($legers->institution_name); ?>">
     <input type="hidden" name="bank_id" value="<?= esc($bank_type); ?>">
  <input type="text" style="width:150px;" name="topay_gvm[]" id="topay_gvm<?= $index; ?>" 
         class="private form-control" value="" onkeyup="govern_pay(this,<?= $info->balance; ?>)">
  <div class="input-error-message text-danger" style="display:none;"></div>
</td>


            </tr>
        <?php 

    }}
    else{
        echo '
        <tr><td colspan="7"><b>No data found!</b></td></tr>';
    }?>
    </tbody>
  
    <tfoot class="text-center bg-muted">
        <tr>
            <td colspan="6"><b>TOTAL</b></td>
            <td><b><?= number_format($total_amount);?></b></td>
            <td><b><?= number_format($total_balance); ?></b></td>
            <td><b><div id="totalpay_gvm">0</div></b></td>
            <input type="hidden" name="totalpay_gvm_value" id="totalpay_gvm_value" value="0">
            <input type="hidden" name="total_balance" id="total_balance" value="<?=$total_balance;?>">
        </tr>
    </tfoot>

</table>

       <div class="form-group row" style="margin-left: 20px;">
                                                       <!-- pdf file here starts -->

                
                            <label class="col-md-6 col-form-label">Attach File<span class="text-danger"></span></label>
                            <div class="col-md-6" style="padding-top:10px;">
         <input type="file" id="imageinput" name="uploadFiles[]" class="form-control"  style="width:250px" multiple accept=".pdf, .doc, .xls, .docx, .xlsx, .jpg, .jpeg, .png"  onchange="previewFile(event)" >
                           </div>
                       


                            <label class="col-md-6 col-form-label">Approval Comment<span class="text-danger">*</span></label>
                            <div class="col-md-6 mt-3">
                            <input type="text" name="bill_comment" style="width:250px" id="bllcmt" value="Please Approve!" required class="form-control">
                           </div>
                               
                            <div class="preview-container" id="previewContainer"></div>

                           </div>

                            <div id="file-preview-container" onclick="removeattachment()">
                           </div>
                        <!-- Here it ends the payable accounts --> 
                         <div class="form-group row">
                            <div class="col-md-12  float-right">
                                <button type="submit" id="create_bill" class="btn btn-primary">Create</button>
                            </div>
                        </div>


                        </form>


<script>
$('#government_pay').submit(function (e) {
    e.preventDefault();

    let amoun_entered = false;
    $('input[name="topay_gvm[]"]').each(function () {
        if ($(this).val().trim() !== '' && parseFloat($(this).val()) > 0) {
            amoun_entered = true;
            return false;
        }
    });

    if (!amoun_entered) {
        swal({
            title: "Info",
            text: "Please enter at least one value in the 'Amount to Pay' field before submitting.",
            type: "warning"
        });
        return false;
    }

    var formData = $(this).serialize();
    $.ajax({
        type: "POST",
        url: '<?= base_url().'/pay-goverment'; ?>',
        data: formData,
       dataType: 'json',
        beforeSend: function () {
            swal({
                title: "Processing...",
                text: "Loading, please wait...",
                type: "info",
               showConfirmButton: false,
                timerProgressBar: true,
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
        },

        success: function (res) {
               if(res['status'] == "1"){ 
               swal({
               title: "Completed",
                 text: "Payments sent successfully.",
                        type: "success",
                 confirmButtonText: "OK",
        closeOnConfirm: true
            },
            function(){
           
                window.location.reload();
    }            );
        }else{

            swal({
                title: "Error!",
                text: "Failed to send payments. Please try again.",
                type: "error"
            });   
        }},

        error: function () {
            swal({
                title: "Error!",
                text: "Failed to send payments. Please try again.",
                type: "error"
            });
        }
    });
});

$(document).ready(function () {
    $("#selectAll2").on("change", function () {
        let isChecked = $(this).prop("checked");
        $("tbody input.private[type=checkbox]").prop("checked", isChecked).trigger("change");
    });
    $("tbody").on("change", "input.private[type=checkbox]", function () {
        let row = $(this).closest("tr");
        let balance = parseFloat(row.find("input[name='balance_before[]']").val());

        if ($(this).prop("checked")) {
            row.addClass("row-selected2");
            row.find("input[name='topay_gvm[]']").val(balance);
        } else {
            row.removeClass("row-selected2");
            row.find("input[name='topay_gvm[]']").val("");
        }

        updateTotalPay();
    });
    $("tbody").on("keyup", "input[name='topay_gvm[]']", function () {
        updateTotalPay();
    });
    function updateTotalPay() {
        let total = 0;
        $("input[name='topay_gvm[]']").each(function () {
            let val = parseFloat($(this).val().replace(/,/g, "")) || 0;
            total += val;
        });
        $("#totalpay_gvm").text(total.toLocaleString());
        $("#totalpay_gvm_value").val(total);
          $("#thispay").html(total.toLocaleString());
        
    }
});

</script>

