  
  <?php
 $bmodel = new App\Models\BillingModel();

 ?>
  <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable">
                            <thead>
                                <tr>
                                    <th>Recon no</th>
                                    <th>ledger</th>
                                    <th>Recon Date</th>
                                    <th>Begin Bal</th>
                                    <th>End Bal</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>total Cleared</th>
                                    <th>Trans Date</th>
                                    <th>Trans By</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody style="padding:1px;">
                          <?php
                          if(count($recon_data)>0){
                            foreach($recon_data as $r){
                        $trans_by = $bmodel->get_item_name('users',$where = array('user_id' =>$r->trans_by));
                        $lg = $bmodel->get_item_name('accounts_tbl',$where = array('id' =>$r->account_id));
                                ?>
                               <tr>
                   <td><?= $r->recon_number;?></td>
                   <td><?= $lg[0]->account_name;?></td>
                   <td><?= $r->recon_date;?></td>
                    <td><?= number_format($r->begin_balance);?></td>
                     <td><?= number_format($r->end_balance);?></td>
                       <td><?= $r->start_date;?></td>
                       <td><?= $r->end_date;?></td>
                       <td><?= number_format($r->total_cleared);?></td>
                       <td><?= $r->trans_date;?></td>
                       <td><?= $trans_by[0]->first_name." ".$trans_by[0]->last_name;?></td>
                       <td>
                           <!--<a href="javascript:void(0)" onclick="manage_rec(<?php echo $r->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>-->
                               
                             <a href="javascript:void(0)" onclick="manage_receipt(<?php echo $r->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a>
                       </td>
                               </tr>
                                <?php
                            }
                          }else{
                            ?>
                            <tr>
                                <td>No Any Data Available</td>
                            </tr>

                            <?php
                          }
                          ?>
                            </tbody>
                        </table>
                    </div>

    <div class="modal fade" id="viewModalR" role="dialog">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <!-- <h5 class="modal-title justify-content-center" id="staticBackdropLabel">Reconciliation Details</h5> -->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="View_reconciliation"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
           <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('View_reconciliation')"><i class="fa fa-print"></i> Print</button>
        </div>
      </div>
      
    </div>
  </div>

        <script type="text/javascript">
                        
        function manage_receipt(id){
           // alert(id);
           $('#View_reconciliation').html('<span class="fa fa-spinner fa-spin"></span>Retreiving results..');

          var data ="id="+id;
            $('#viewModalR').modal('show');
            $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/BillController/view_reconciliation'; ?>",
            data: data,
           success: function(res){
                $('#View_reconciliation').html(res);

            },
            error: function ()
            {
         $('#View_reconciliation').html('<span class="text-red">Sorry, Something went wrong</span>');
            }
        });
          }
        </script>