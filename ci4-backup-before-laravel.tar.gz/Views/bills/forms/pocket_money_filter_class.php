 
<?php
 helper('age');
  $amodel = new App\Models\AdmissionModel();
  $billmodel = new App\Models\BillModel();
  $remodel =new App\Models\ReportsModel();
  $suppliermodel = new App\Models\SupplierModel();

  ?>
 <!-----class pocket money selection options---------->
                <div class="col-md-12" id="class_selection" style="display:'';">
                <div class="d-flex justify-content-center mb-3">
                    <form id="formResult" class="form-inline">
                     <div class="me-3">
                             Academic year: 
                           <select id="year" name="year" class="form-select form-control">
                            <?php
                           $cyear=date("Y");
                           $startY=2023;
                           for ($year=$cyear+1; $year >=$startY ; $year--) { 
                               ?>
                              <option value="<?= $year;?>" <?php if($year==$cyear){ echo "selected"; } ?> ><?= $year;?></option>
                               <?php
                           }
                            ?>
                     
                    </select>
                        </div>
                        
                        <div class="me-3">
                             Level: 
                            <select class="form-control form-select" name="classlevel" id="classlevel">
                                <option value="0">All</option>
                                <?php
                               $l = $remodel->get_levels();
                              foreach($l as $le){
                               echo '<option value="' . $le->id . '">' . $le->level_name . '</option>'; 
                              }

                               ?>
                            </select>
                        </div>

                         <div class="me-3">
                             Class: 
                            <select class="form-control form-select" name="class" id="class">
                                <option value="0">All</option>
                                <?php
                               $c = $remodel->get_classes1();
                              foreach($c as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->class_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                      
                         <div class="me-3">
                             Stream: 
                            <select class="form-control form-select" name="stream" id="stream">
                                <option value="0">All</option>
                                <?php
                               $s = $remodel->get_stream1();
                              foreach($s as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->stream_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                         <div class="me-3">
                             Hostel: 
                             <select class="form-control form-select" name="hostel" id="hostel">
                                <option value="0">All</option>
                              <?php
                               $hostels = $amodel->get_student_details('hostel_tbl', $where = array('status' => 1));
                              foreach($hostels as $h){
                               echo '<option value="' . $h->id . '">' . $h->hostel_name . '</option>'; 
                              }

                               ?>   
                             </select>

                         </div>

                        <button type="submit" class="btn btn-primary">Load</button>

                     </form>

                </div>
                 
                         </div>
             <!----end-class pocket money selection options---------->
              <center>
                  <div id="all_listed"></div>
             </center>

    <script type="text/javascript">
        
        $('#formResult').submit(function (e) {
          var trans_no =$('#trans').val();   
        $('#all_listed').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "class=" + $('#class option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&year="+$('#year option:selected').val()+ "&hostel="+$('#hostel option:selected').val()+'&staff_id='+$('#staff_id').val()+'&trans_no='+trans_no;
          // alert(dta);
           // return;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/get_pocket_money_listEdit'; ?>',
                 data: dta,
                success: function (res) {
                    $('#all_listed').html(res);
                },
                error: function () {
                    $('#all_listed').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });
    </script>