<?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\AdmissionModel();
 $remodel = new App\Models\ReportsModel();
 //echo $thedate;
   $bank = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 9,'id'=>$id));


  //calculating balance before the date----
            $s='01-01-2020';
            $today=date("Y-m-d");
            $end =strtotime($today);
            $std = strtotime($s);
             
            // echo date('Y-m-d',$end);
            $before = $imodel->getSingle_view3($id,date('Y-m-d', $std),date('Y-m-d', $end));
            //print_r($before);
            $balanceb=0;
            foreach($before as $bf){
              if($bf->transation_nature==2){
                $balanceb=$balanceb+$bf->amount;
              }else{
              //  echo $balanceb;
               $balanceb=$balanceb-$bf->amount;
              }
             }
             
           //-------end calculation----------
                          
 ?>
                  <div class="form-group row">
                    <label for="inputpaidBy" class="col-sm-6 col-form-label">Current: <?= $bank[0]->account_name;?> Bal</label>
                     <label for="inputpaidBy" class="col-sm-6 col-form-label" id="balance"> <?php echo number_format($balanceb);?></label>

                      <label for="inputpaidBy" class="col-sm-6 col-form-label">This Payment</label>
                       <label for="inputpaidBy" class="col-sm-6 col-form-label" id="thispay">0</label>
                       <label for="inputpaidBy" class="col-sm-6 col-form-label">Balance After</label>
                       <label for="inputpaidBy" class="col-sm-6 col-form-label" id="after"><?php echo number_format($balanceb);?></label>
                    
                </div>