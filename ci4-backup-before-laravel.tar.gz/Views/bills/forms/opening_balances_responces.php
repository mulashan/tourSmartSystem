  <?php    
$billmodel = new App\Models\BillingModel();
$smodel = new App\Models\StudentModel();
 ?>
 <div class="section-body mt-4">
    <div class="container-fluid">
        <div class="card">
  <div class="table-responsive mt-3">
     <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th> Date</th>
                                    <th> Trans No</th>
                                    <th>Bank Ledger</th>
                                    <th>Amount</th>
                                    <th>Description</th>
                                    <th>Equity Ledger</th>
                                    
                                    <th>Updated By</th>
                                    
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                        <!--########################### Filtered data#######################--->

                               <?php 
                            $i=0;
                               foreach($open_data as $open){
                               $i++;
                        $checkLedger1 = $billmodel->get_item_name('ledger_transaction_tbl',$where=array('trans_no'=>$open->trans_number,'trans_type'=>9,'transation_nature'=>1));
                         $checkLedger2 = $billmodel->get_item_name('ledger_transaction_tbl',$where=array('trans_no'=>$open->trans_number,'trans_type'=>9,'transation_nature'=>2));

                          $account1 = $billmodel->get_item_name('accounts_tbl',$where=array('id'=>$checkLedger1[0]->ledger_id));

                           $account2 = $billmodel->get_item_name('accounts_tbl',$where=array('id'=>$checkLedger2[0]->ledger_id));


                           $updator = $billmodel->get_item_name('users',$where=array('user_id'=>$open->updated_by));

                     
                        ?>
                                         
                            <tr>
                                   <td><?= $i; ?>.</td>
                                   <td><?= $open->trans_date; ?></td>
                                   <td><?= $open->trans_number; ?></td>
                                   <td><?= $account2[0]->account_name; ?></td>
                                   <td><?= number_format($checkLedger2[0]->amount); ?></td>
                                   <td><?= $open->trans_desc; ?></td>
                                   <td><?=$account1[0]->account_name; ?></td>
                                   
                                   <td><?= $updator[0]->first_name; ?></td>
                                  
                                  <td>
                                <button type="button" class="btn btn-primary btn-sm passingbillID" data-id="<?=$open->id; ?>"><i class="fa fa-edit"></i> Edit</button>
                                
                                <!-- <button type="button" class="btn btn-primary btn-sm passingBillViewId" data-id="<?=$open->trans_number;?>"><i class="fa fa-eye"></i> View</button> -->
                             
                              </td>
                               </tr>
                           <?php } ?> 
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
<script type="text/javascript">
    $(document).ready(function () {
  $('#myTable').DataTable();
});
        ////////function to View Bill data///////////////
 $(".passingBillViewId").click(function () {
        var data = 'trans_no=' + $(this).attr('data-id');
        // $("#idkl").val( ids );
        $('#myviewModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?php echo base_url() . '/index.php/BillController/view_opening_balance'; ?>",
            data: data,
            beforSend: function()
            {
                $('#Viewbill').html();
            },
            success: function(res){
                $('#Viewbill').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });


    ///////////////////// code to update bill information //////////
    $(".passingbillID").click(function () {   
        var data = 'id=' + $(this).attr('data-id');
        // $("#idkl").val( ids );
        $('#myModal').modal('show');

        $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/BillController/edit_opening_balance'; ?>",
            data: data,
            beforSend: function()
            {

                $('#Updtebill').html();
            },
            success: function(res){
                $('#Updtebill').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
</script>