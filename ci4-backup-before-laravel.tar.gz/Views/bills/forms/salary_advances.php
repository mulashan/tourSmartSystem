<!-- <link rel="stylesheet" href="<?php //echo base_url('public/assets/plugins/select2/select2.css');?>"/> -->
<style>
    input.form-control {
    pointer-events: auto !important;
    background-color: white !important;
    z-index: 9999 !important;
    position: relative !important;
    width: 200px !important;
}
button, input[type="submit"], .btn {
  position: relative; 
  z-index: 9999 !important;
  pointer-events: auto !important;
}

</style>
<div class="card-body">
                    <form class="form-horizontal" id="advance_btn" enctype="multipart/form-data">
<div class="row">
    <input type="hidden" name="staffs_id" value="<?=esc($staff_id);?>">
    <input type="hidden" name="bank_id" value="<?=esc($bank_ids);?>">
    <input type="hidden" id="totalsum_raw" name="total_amount">
                        <!-- <div class="col-md-2"></div> -->
                        <div class="col-md-12">
                        <div class="card" style="width:750px;">
                            <h5 Class=" d-flex justify-content-center mt-3">Repayment Schedule</h5>

                        <div class="form-group row">
                            <div class="mr-4">
                                                <table class="table  table-borderless">
                                                  <tbody>
        <tr>
            <td>
                 <div class="text-center">
                <label class="col-form-label">Payroll Year<span class="text-danger">*</span></label>
</div>
            </td>
            <td>
 <div class="text-center">
                <label class="col-form-label">Payroll month<span class="text-danger">*</span></label>

            </div>
        </td>
            <td>
                 <div class="text-center">
                <label class="col-form-label">Amount<span class="text-danger">*</span></label>
            </div>
            </td>
            <td>+</td>
        </tr>
                                                   
                                                    
                                                        <tr>
                                                            <td>
                        <div class="text-center">
                   <select id="year" name="year" style="width:100%;" class="payroll-select form-control form-control-sm align-items-center year-dropdown form-select form-select-sm w-100" required>
                     <option value="" selected disabled >--please Select--</option>
                                    <?php
                                    $initial_year=2023;
                                    $current_year=date('Y');
                                    $final_year=$current_year+1;
                                    for ($initial_year; $initial_year <=$final_year ; $initial_year++) {          
                                        if($initial_year == $current_year){
echo '<option value="'.$initial_year. '"selected>' . $initial_year . '</option>';
                                        }else{
                                    ?>
                                   
                                    <option value="<?=$initial_year;?>" ><?=$initial_year;?></option>
                                  <?php

                                       }}
                                    ?>
         
                          </select>
                           <div class="invalid-feedback">Payroll Year required.</div>
                               </div>
                                                            </td>
                                                            <td>
                                             <div class="text-center">
               
                 <select id="month" name="month" style="width:100%;" class="payroll-select form-control form-control-sm align-items-center year-dropdown form-select form-select-sm w-100" required>

                         <option value="" selected disabled >--please Select--</option>
             <?php             
                                if(isset($months)){
                              foreach($months as $info){
                                 if($info->is_current==1){
                                    echo '<option value="'.$info->month_id. '"selected>' . $info->month . '</option>';   

                                 } else{      

                                   echo '<option value="'.$info->month_id. '">' . $info->month . '</option>';   
                                }}
                           
                              }
                               ?>                    
                 </select>
                  <div class="invalid-feedback">Payroll Month required.</div>
                                                </div>
                    
                                           
                                                            </td>
                                                            <td>
                                                               <div class="text-center"> 
        <!-- <input type="text" class="form-control" name="advance_amount" id="advance_amount" onkeyup="advance_pay(this)"> -->
        <input type="text"  class="form-control" name="advance_amount" oninput="advance_pay(this)"  id="advance_amount"  autocomplete="off">
<div class="input-error-message text-danger small"></div>

        </div>
                                                                    
                                                               </td>
                                                            <td>
                 <button type="button" id="click_advance" class="btn btn-primary"><i class="fa fa-plus"></i></button>
                                                            </td>
                                                          
                                                        </tr>
                                                    </tbody>
                                                </table>
                                             <div class="advance_status">
                                                 
                                             </div><div class="amount_status">
                                                 
                                             </div>
                                                <hr>

                <table class="table table-hover table-vcenter mb-0 text-nowrap" style="">
                <thead>
                    <tr>
                        
                        <th>Payroll year</th>
                        <th>Payroll month</th>
                        <th class="text-right">Amount</th>                     
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody id="show_advances" style="">
                
                </tbody>
                <tfoot>
                     <tr> 
                    <td colspan="2"></td>
                    
                    <td class="text-right" style="font-size: 18px;">TOTAL = <span id="totalsum0">0</span></td>
                    <input type="hidden" id="totalsum0_input" name="totalsum0">
                    <td></td>
                 </tr>
                </tfoot>
               
                    </table>
                      <div class="form-group row" style="margin-left: 20px;">
                                                       <!-- pdf file here starts -->

                
                            <label class="col-md-6 col-form-label">Attach File<span class="text-danger"></span></label>
                            <div class="col-md-6" style="padding-top:10px;">
         <input type="file" id="imageinput" name="uploadFiles[]" class="form-control"  style="width:250px" multiple accept=".pdf, .doc, .xls, .docx, .xlsx, .jpg, .jpeg, .png"  onchange="previewFile(event)" >
                           </div>
                       


                            <label class="col-md-6 col-form-label">Approval Comment<span class="text-danger">*</span></label>
                            <div class="col-md-6 mt-3">
                            <input type="text" name="bill_comment" style="width:250px" id="bllcmt" value="Please Approve!" required class="form-control">

                           </div>
                               
                            <div class="preview-container" id="previewContainer"></div>

                           </div>
</div>
           </div>
            </div>

                        </div><br>
                        <div class="form-group row">
                            <div class="col-md-8">
                                <button type="submit" id="create_advance" class="btn btn-primary float-right">Create</button>
                            </div>
                        </div>
                        </form>
                            </div>

 <script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script>
 <script type="text/javascript">
document.addEventListener('DOMContentLoaded', function () {
        const imageInput = document.getElementById('imageinput');
        const previewContainer = document.getElementById('previewContainer');
        const uploadedFiles = [];

        imageInput.addEventListener('change', function (event) {
            previewContainer.innerHTML = ''; // Clear previous previews
            uploadedFiles.length = 0; // Clear the array

            const files = event.target.files;

            for (const file of files) {
                const reader = new FileReader();

                reader.onload = function (e) {
                    const previewImage = document.createElement('div');
                    previewImage.className = 'preview-image';

                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.alt = 'Image Preview';
                    img.style.width = '100%';
                    img.style.height = '100%';

                    const removeButton = document.createElement('div');
                    removeButton.className = 'remove-button';
                    removeButton.innerHTML = 'X';

                    removeButton.addEventListener('click', function () {
                        previewContainer.removeChild(previewImage);
                        
                        // Remove the corresponding file from the array
                        const index = uploadedFiles.indexOf(file);
                        if (index !== -1) {
                            uploadedFiles.splice(index, 1);
                        }
                    });

                    previewImage.appendChild(img);
                    previewImage.appendChild(removeButton);
                    previewContainer.appendChild(previewImage);

                    // Add the file to the array
                    uploadedFiles.push(file);
                };

                reader.readAsDataURL(file);
            }
        });

        // Add the array of files to the FormData object when submitting the form
        document.getElementById('uploadForm').addEventListener('submit', function (event) {
            const formData = new FormData(this);

            for (const file of uploadedFiles) {
                formData.append('images[]', file);
            }

            // Now you can submit the form with the updated FormData
            // (e.g., using fetch or XMLHttpRequest)
            
            // Uncomment the following line to prevent the default form submission
            // event.preventDefault();
        });
    });



function isImageFile(file) {
    // Check if the file type is an image
    return file.type.startsWith('image/jpeg/jpg/png/gif');
}

   ///////////////////here load expense ledgers starts here///////////////
    var hold_selected_accounts = []; // hold all selected items
   $(document).ready(function(){
        // fetch_data();
    //alert(hold_selected_accounts);
         $('#expenseledger').select2({
            ajax: {
                url: "<?= base_url('load_accounts'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

           $('#expenseledger').on('select2:select', function (e) {
            selectedAccounts();
            });

        function selectedAccounts(){  
            var rows = '';
           var accountData = 'accounts_selected='+$('#expenseledger').val()+'&selected_accounts_array='+hold_selected_accounts;
           //alert(accountData);
           // return;
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_accountdata1')?>",   
                data:accountData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    } 
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }
                
           }); 

        }
          });



  function RemoveSelectItemRow(id,v){
        for( var i = 0; i < hold_selected_accounts.length; i++){ 
    
            if ( hold_selected_accounts[i] == id) {                 
                hold_selected_accounts.splice(i, 1); 
            }
        }
        //alert(sumVal);
var k=v+1;
        var table = document.getElementById("table");
        var data=parseInt(table.rows[k].cells[5].innerHTML);
         //var col1=currentRow.find("td:eq(7)").text();
        
        $('#table_row'+id).remove();
    }
    ///////////////////######## Here is For Budget Ledger ##############//////////////////
        $(document).ready(function(){
         $('#incomeledger').select2({
            ajax: {
                url: "<?= base_url('load_payable'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

     });

var account_ttl = 0;

$('#click_advance').click(function (evt) {
    evt.preventDefault();
    var monthId = $('#month').val();
    var year = $('#year').val();
    var ttl = parseFloat($('#advance_amount').val().replace(/,/g, '')) || 0;
    var descr = $('#description').val() || 'Advance';

    if (!monthId || !year || !ttl) {
        $('.amount_status').show();
        $('.amount_status').html('<span class="alert alert-warning">Please enter all fields correctly</span>');
        return;
    }

    $.ajax({
        type: 'POST',
        data: { payroll_month: monthId },
        url: '<?php echo base_url() . "/fetch_payroll_month"; ?>',
        beforeSend: function () {
            $('.advance_status').html('<span class="spinner-border spinner-border-sm"></span> Loading item, please wait....');
            $('.amount_status').hide();
        },
        success: function (response) {
            let lData = JSON.parse(response);
            if (!Array.isArray(lData)) {
                lData = [lData];
            }

            for (let i = 0; i < lData.length; i++) {
                let monthName = lData[i]['month'];
                let monthID = lData[i]['month_id'];
                let uniqueRowId = `${monthID}_${year}`;
                let formattedAmount = ttl.toLocaleString();

                if ($("#row_" + uniqueRowId).length) {
                    $('.advance_status').show();
                    $('.advance_status').html('<span class="alert alert-warning"><i class="fa fa-warning"></i> This payroll month and year have already been added.</span>');
                    return;
                }

                account_ttl += ttl;

                $('#show_advances').append(`
                    <tr id="row_${uniqueRowId}">
                        <input type="hidden" name="ttl[]" value="${ttl}">
                        <td>
                            <input type="hidden" name="payroll_year[]" value="${year}">
                            ${year}
                        </td>
                        <td>
                            <input type="hidden" name="payroll_month[]" value="${monthID}">
                            ${monthName}
                        </td>
                        <td class="text-right">
                            <input type="hidden" name="amount[]" value="${ttl}">
                            ${formattedAmount}
                        </td>
                        <td>
                            <button type="button" onclick="RemoveRow('${uniqueRowId}', ${ttl})" class="btn btn-danger btn-sm"><i class='fa fa-trash'></i></button>
                        </td>
                    </tr>
                `);
            }

            $("#totalsum0").html(account_ttl.toLocaleString());
            $("#totalsum0_input").val(account_ttl); 
            $("#thispay").html(account_ttl.toLocaleString());
            $("#totalsum_raw").val(account_ttl);
            $('.advance_status').hide();
            $('.amount_status').hide();
            $("#advance_amount").val('');
        },
        error: function () {
            alert("Failed to fetch payroll month.");
        }
    });
});

function RemoveRow(id, amount) {
    $('#row_' + id).remove();
    account_ttl -= amount;
    $("#totalsum0").html(account_ttl.toLocaleString());
    $("#thispay").html(account_ttl.toLocaleString());
}


    //function to load the payable accounts
     $(document).ready(function(){
        // fetch_data();
         $('#acc_payable').select2({
            ajax: {
                url: "<?= base_url('load_acc_payable'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });
     });


      ////////////// function to load bill to supplier ///////////////
        $(document).ready(function(){
        // fetch_data();
         $('#load_suppl').select2({
            ajax: {
                url: "<?= base_url('load_supplier'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });
     });


 
    
        $("#capture-btn").click(function () {
            $('#capture').show();

            });

                    $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });

    ///////////////////// for Filtering Bill date/////////////////////////
      $('#BillResult').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#billresponse').html('Please specify valid date.');
        } else {
            $('#bill').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn span').html() + "&approval="+$('#approval').val();
            // alert(dta);
            // return;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/billfilterdata'; ?>',

                data: dta,
                success: function (res) {
                    $('#bill').html(res);
                },
                error: function () {
                    $('#bill').html('<div class="alert alert-warning">Fail to retreive Bill.!!</div>');
                }
            });

            }
        e.preventDefault();
    });
        
        $("#bill_type").change(function(){
    if($("#bill_type").val()==7){
        $('#showProject').show();
    }else{
     $('#showProject').hide();
    }
       
    });  
    $('.payroll-select').select2(); 

function advance_pay(elem) {
    const $errorDiv = $(elem).next(".input-error-message");

    // Remember cursor position
    const selectionStart = elem.selectionStart;
    const oldLength = elem.value.length;

    // Keep only valid characters (digits and one dot)
    let rawValue = elem.value.replace(/,/g, '').replace(/[^\d.]/g, '');
    const parts = rawValue.split('.');

    // Allow only one decimal point
    if (parts.length > 2) {
        rawValue = parts[0] + '.' + parts[1];
    }

    const inputVal = parseFloat(rawValue) || 0;

     // Format only if not empty or invalid
    let formatted = '';
    if (rawValue !== '') {
        const [intPart, decPart] = rawValue.split('.');
        formatted = Number(intPart).toLocaleString(undefined, { maximumFractionDigits: 0 });
        if (decPart !== undefined) formatted += '.' + decPart.substring(0, 2); // limit to 2 decimals
    }

    elem.value = formatted;

    // Restore cursor near where user was typing
    const newLength = elem.value.length;
    elem.selectionEnd = selectionStart + (newLength - oldLength);

    // Recalculate total (with decimals)
    let total = 0;
    $('input[name="advance_amount"]').each(function () {
        const val = $(this).val().replace(/,/g, '');
        total += parseFloat(val) || 0;
    });

    $("#advance_amount").html(
        total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })
    );
}

$('#advance_btn').submit(function(e){ 
    e.preventDefault();
    var form_data = new FormData(this); 
    $('#create_advance').prop("disabled", true);

  $.ajax({
    method: 'POST',
    url: '<?php echo base_url() . '/save-advances'; ?>',
    data: form_data,
    contentType: false,
    processData: false,
    dataType: 'json',
    
    success: function(data){
        if(data['status'] == "1"){
            swal("Success", data['description'], "success");
            setTimeout(function(){
                window.location.reload();
            }, 3000);
        } else {
            $('#create_advance').prop("disabled", false);
            swal("Warning", data['description'], "warning");
        }
    },
    error: function(xhr, status, error){
        $('#create_advance').prop("disabled", false);
        swal("Error", "Something went wrong while saving advances.", "error");
    }
});

});

    </script>