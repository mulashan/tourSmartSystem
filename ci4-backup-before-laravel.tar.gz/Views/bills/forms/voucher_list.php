
<?php
   $bmodel = new App\Models\BillingModel();
   $billmodel = new App\Models\BillModel();
   $smodel = new App\Models\StudentModel();
   $ctype= $bmodel->get_table_details('name_type_tbl');
?>

<div class="section-body mt-4">
    <div class="container-fluid">
             
                <div class="card">
               <div class="table-responsive mt-3">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable2">
                            <thead>
                                <tr>
                                    <!-- <th>No.#</th> -->
                                    <th>No.</th>
                                    <th>Voucher Date</th>
                                    <th>Type</th>
                                    <th>Paid To</th>
                                    <th> Amount</th>
                                    <th>Initiated By</th>
                                    <th>sms Status</th>
                                    <!-- <th>Trans By</th> -->
                                     <th>Trans Date</th>
                                    <th>Approval</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                 if(count($trans)>0){
                                    // print_r($trans);
                                    // return;
                                    foreach($trans as $s){
                                    $student_name = "";
                                    $student_id = "";
                                    $control_number = "";
                                    $name_type = "";
                                    $amount =0;

                                   $rlt = $bmodel->get_item_name('voucher_relation_tbl', $where = array('payment_no' => $s->trans_number));
                                   // echo''.$s->name_id;
                                   // print_r($trans);
                                   if(count($rlt)==0){
                                  continue;
                                   }
                                   $vtype = $bmodel->get_item_name('voucher_types_tbl', $where = array('id' => $rlt[0]->voucher_type));

       $leger_transaction = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type' =>5,'ledger_type'=>9,'creater_status'=>0));
                                         //print_r($leger_transaction);
                                          if(count($leger_transaction)==0){
                                            continue;
                                          }
                                         $amount =$leger_transaction[0]->amount??"";
                                          if($leger_transaction[0]->name_type_id == 4){
                                            $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                                            $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                            $student_id = $app[0]->id;
                                            $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                            $name_type = $type_name[0]->name_type;
                                            
                                        }
                                         else if($leger_transaction[0]->name_type_id == 3){
                                             $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }else if($leger_transaction[0]->name_type_id == 1){
                                             $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }else if($leger_transaction[0]->name_type_id == 7){
                                             $app = $bmodel->get_item_name('users',$where = array('user_id'=>$leger_transaction[0]->name_id));
                                             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
                                             $student_id = $app[0]->user_id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }
                                              else if($leger_transaction[0]->name_type_id == 8){
                                        
                                              $app = $billmodel->get_institution_name($leger_transaction[0]->name_id);
                                             $student_name = $app->institution_name; 
                                             $student_id = $app->institution_id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }    
                                        else if($leger_transaction[0]->name_type_id == 2){
                                             $app = $bmodel->get_item_name('supplier_tbl',$where = array('supplier_id'=>$leger_transaction[0]->name_id));
                                             $student_name = $app[0]->supplier_name; 
                                             $student_id = $app[0]->supplier_id;
                                             $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                                             $name_type = $type_name[0]->name_type;
                                        }
                                         $user = $bmodel->get_item_name('users', $where = array('user_id' => $s->updated_by));
                                                                $ap_status="";
                                     $appstatus = $bmodel->get_item_name('approval_numbers', $where = array('trans_no' => $s->trans_number,'trans_type'=>$s->trans_type_id));
                                      
                                      $edit="";
                                     if(count($appstatus)>0){
                                     $approval = $billmodel->get_item_name_desc('approval_history', $where = array('app_no' => $appstatus[0]->app_id),"hist_id");
                                     //print_r($approval);
                                     // if($s->trans_number==23){
                                     //  print_r($approval);
                                     // }
                                     
                                     if(count($approval)>0){
                                        if($approval[0]->hstatus==1){
                                        $edit= 'disabled style="pointer-events: none; opacity: 0.5;"';
                                          $ap_status="<div class='text-success'>Approved</div>";  
                                        }elseif ($approval[0]->hstatus==2) {
                                        $ap_status="<div class='text-danger'>Rejected</div>";
                                        }elseif ($approval[0]->hstatus==3) {
                                             $ap_status="<div class='text-danger'>Pending</div>";
                                        }
                                        
                                     }
                                 }
                                          
               //for msg status
                     //start for sms <!----->
                               $msg_status = $billmodel->get_item_name('message_groups_tbl', $where = array('trans_number' => $s->trans_number,'message_type'=>14));
                                     if(count($msg_status)>0){
                                         $msg_st = $billmodel->get_item_name('messages', $where = array('send_no' => $msg_status[0]->send_number));
                                         
                            if(count($msg_st)>0){

         ///here we go
                      if($msg_st[0]->time_sent==null && $msg_st[0]->message_id!=""){
                 $senderid=constant('SENDER_ID_' . session()->get('db_id'));
                             $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_RETURNTRANSFER => 1,
                        CURLOPT_URL => 'http://www.sms.co.tz/api.php?do=dlr&id=' . $msg_st[0]->message_id . '&username=' . SMS_UNAME . '&password=' . SMS_PASSWORD . '&senderid='.$senderid,
                    ));
                    $msg_status = curl_exec($curl);
                    // print_r($msg_status);
                    // return;
                    // echo $msg_status;
                    if($msg_status != ""){

                       list($sntdate, $stts, $deldate) = explode(',', $msg_status);

                       $tempsmsdata = array(
                           'sent_status' => 2, //Sent and delivered
                           'time_sent' => $sntdate,
                           'status_description' => $stts,
                           'time_delivered' => $deldate
                       );
                       //print_r($tempsmsdata);
                        $smodel->update_table_details('messages',$where = array('message_id' => $msg_st[0]->message_id),$tempsmsdata);
                        // echo 'updated';
          
                                }
                                }
                        
                             ?>
                                         
                 <?php
                  $msg_s = $billmodel->get_item_name('messages', $where = array('message_id' => $msg_st[0]->message_id));

                 $del=$msg_s[0]->status_description;
                 $time=$msg_s[0]->time_delivered;
                 $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                   if($vtype[0]->id==6 && $approval[0]->hstatus==3){
                    $stata='';
                 }
             }else{
                 $stata='<span style="color:red">Not Sent'; 
                  if($vtype[0]->id==6 && $approval[0]->hstatus==3){
                    $stata='';
                 }
             }
             }else{
               $stata='<span style="color:red">Not Sent';  
                if($vtype[0]->id==6 && $approval[0]->hstatus==3){
                    $stata='';
                 }
             }
       //end for sms status
                                     
                          
                                  ?>
                                 <tr>
                                    <td><?php echo $s->trans_number;?></td>
                                    <td><?php echo date('Y-m-d',strtotime($s->trans_date));?></td>
                                <td><?php echo $vtype[0]->voucher_type_name;?></td>
                                <td><?php echo $student_name;?></td>
                    <td><?php echo format_number_with_decimals($amount);?></td>
                                <td><?= $user[0]->first_name.' '.$user[0]->last_name; ?></td>
                                <td><?php echo $stata;?></td>
                                <td><?php echo date('Y-m-d H:i:s',strtotime($s->updated_date));?></td>
                                <td><?php echo $ap_status;?></td>
                                
                                <td>
                                      <a href="javascript:void(0)" onclick="edit_voucher('<?php echo $s->trans_number;?>','5')"  class="btn btn-primary btn-sm" <?php echo $edit;?>><i class="fa fa-edit"></i> Edit</a>
                                      <a href="javascript:void(0)" onclick="view_voucher('<?php echo $s->trans_number;?>','5')"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a>
                                </td>
                                </tr>
                                  <?php
                                    }
                                  }
                                ?>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>


 <!-- Modal to View Approval Information -->

  <div class="modal fade" id="myviewModal" role="dialog">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Voucher Information</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Viewapproval"></div>

        </div>
        <div class="modal-footer">
           
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
           <button type="button" class="btn btn-primary" onclick="printable_voucher()"><i class="fa fa-print"></i> Print</button>
        </div>
      </div>
      
    </div>
  </div>


        <script>

    $(document).ready(function () {
      $('#myTable2').DataTable();
    });

    function printable_voucher(){
     $('#view_voucher').modal('show');

    }

function printable_voucher2(area){
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
  disp_setting += "scrollbars=yes,width=750, height=600, left=80, top=25";
  var content_value = document.getElementById(area).innerHTML;

  var docprint = window.open("", "", disp_setting);
  docprint.document.open();
  docprint.document.write('<html><head><title>MHI</title>');

  // Add a <style> block to set the font family and other print-specific styles
  docprint.document.write('<style>');
  docprint.document.write('@media print {');
  docprint.document.write('  body {');
  docprint.document.write('    font-family: "Times New Roman", sans-serif;');
  docprint.document.write('    font-size: 15px;');
  docprint.document.write('  }');
  docprint.document.write('</style>');

  docprint.document.write('</head><body onLoad="self.print()" style="width:100%;">');

  // Modify content_value to include the colspan attribute
  var modifiedContent = content_value.replace('<td class="colspan-cell">', '<td colspan="2" class="colspan-cell">');
  docprint.document.write(modifiedContent);

  docprint.document.write('</body></html>');
  docprint.document.close();
  docprint.focus();
    }

    function view_voucher(trans_no,trans_type) {
        var data = 'trans_no=' + trans_no+'&trans_type='+trans_type+'&vocher='+1;
            $('#Viewapproval').html('');
        $('#myviewModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?= base_url('/get_approval_data')?>",
            data: data,
              beforeSend: function()
            {
                $('#Viewapproval').html('<span class="fa fa-spin fa-spinner"></span>Loading approval data...');
            },
            success: function(res){
                $('#Viewapproval').html(res);
                 
            },
            error: function ()
            {
 $('#Viewapproval').html('<div class="alert alert-warning">Fail to retreive Data.!!</div>');

            }
        });
    };

     function edit_voucher(trans_no,trans_type) {
        var data = 'trans_no=' + trans_no+'&trans_type='+trans_type+'&vocher='+1;
$('#Viewapproval').html('');
        $('#myviewModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?= base_url('/index.php/BillController/get_edit_approval_data')?>",
            data: data,
           beforeSend: function()
            {
                $('#Viewapproval').html('<span class="fa fa-spin fa-spinner"></span>Loading approval data...');
            },
            success: function(res){
                $('#Viewapproval').html(res);
                 
            },
            error: function ()
            {
 $('#Viewapproval').html('<div class="alert alert-warning">Fail to retreive Data.!!</div>');
            }
        });
    };



</script>