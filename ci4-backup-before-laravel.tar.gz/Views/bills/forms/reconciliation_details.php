
<?php


  $bmodel = new App\Models\BillingModel();
  $billmodel = new App\Models\BillModel();
  $account_id=$recon_data[0]->account_id;
   $acct = $bmodel->get_item_name('accounts_tbl', $where = array('id'=>$account_id));
   $account_name=$acct[0]->account_name;
 // $trans = $bmodel->get_item_name('transaction_numbers_tbl', $where = array('reconciled'=>$recon_data[0]->recon_number));

?>
<center>
<div class="container">
<?php
helper('student');
  $bmodel = new App\Models\BillingModel();
  $billmodel = new App\Models\BillModel();
  $account_id=$recon_data[0]->account_id;
   $acct = $bmodel->get_item_name('accounts_tbl', $where = array('id'=>$account_id));
   $account_name=$acct[0]->account_name;
 // $trans = $bmodel->get_item_name('transaction_numbers_tbl', $where = array('reconciled'=>$recon_data[0]->recon_number));
$sdate=$recon_data[0]->start_date;
$edate=$recon_data[0]->end_date;

   $totalDebitUncleared=0;
 $unchecked_number=array();
  $unchecked = $bmodel->get_item_name('reconciliation_tbl', $where = array('recon_number <='=>$recon_data[0]->recon_number,'account_id'=>$account_id));
  foreach($unchecked as $un){
    $unchecked_number[]=array($un->recon_number);

  }
  $unchecked_number = array_column($unchecked_number, 0);

  //print_r($unchecked_number);
  //return;
?>
<div id='content'>
<center>
<div class="container">
  <h6><b>Reconciliation Details</b></h6>
  <h6><?php echo $account_name?>, Period Ending  <?=date('d-m-Y',strtotime($recon_data[0]->end_date ))?></h6>
  <hr style="color:black;" class="line">

</div>
</center>

<div class="container">
    <table class="table table-condensed table-centre">
      
            <thead>
                <tr>
                     

<th class="text-left" style="border-bottom: 1px solid black;">Type</th>
<th class="text-left" style="border-bottom: 1px solid black;">Date</th>
<th class="text-left" style="border-bottom: 1px solid black;">trans No</th>
<th class="text-left" style="border-bottom: 1px solid black;">Name</th>
<th class="text-left" style="border-bottom: 1px solid black;">Clr</th>
<th class="text-center" style="border-bottom: 1px solid black;">Amount</th>
<th class="text-center" style="border-bottom: 1px solid black;">Balance</th>
                </tr>
            </thead>
            <tbody>

         <tr>
                    <td>Begining Balance</td>
                     <td style="text-align:right;"></td>
                    <td style="text-align:right;"></td>
                    <td style="text-align:right;"></td>
                    <td style="text-align:right;"></td>
                    <td style="text-align:right;"></td>
                    <td align="right"><?= number_format($recon_data[0]->begin_balance); ?></td>
                </tr>

                <tr>
                    <td colspan="7"><b>Cleared Transactions</b></td>
                </tr>

                <tr>
                    <td></td>
                 <td colspan="6"><b>Payment Vouchers, Charges and Other Debits</b></td>
                </tr>

                <?php
                $totalPayments=0;
               $trans = $billmodel->get_reconciled_payments(1,$account_id,$recon_data[0]->recon_number);
               if(count($trans)>0){
                foreach($trans as $s){
       $student_name=capture_name($s->name_id, $s->name_type_id,$s->trans_type,$s->trans_no); 
    $totalPayments=$totalPayments-$s->amount;
         ?>
         <tr>
                    <td><?= $s->type_name;?></td>
                     <td style="text-align:left;"><?= date('Y-m-d',strtotime($s->trans_date));?></td>
                    <td style="text-align:center;"><?= $s->trans_number;?></td>
                    <td style="text-align:left;"><?= $student_name;?></td>
                    <td style="text-align:center;">X</td>
                    <td style="text-align:right;"><?= number_format($s->amount*-1);?></td>
                    <td align="right" ><?= number_format($totalPayments); ?></td>
                </tr>


         <?php         

                }
               }
                ?>
                 <tr>
                    <td></td>
                 <td colspan="4">Total Payment Vouchers, Charges and Other Debits</td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPayments); ?></td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPayments); ?></td>
                </tr>

                   <tr>
                    <td></td>
                 <td colspan="6"><b>Receipts, Deposits and Other Credits</b></td>
                </tr>

                   <?php
        /////////////////////deposit and credits ///////////////////////////
                $totalDebitCredit=0;
               $trans = $billmodel->get_reconciled_payments(2,$account_id,$recon_data[0]->recon_number);
               if(count($trans)>0){
                foreach($trans as $s){
         ////////////////////////////////////////////////////////////
         $student_name=capture_name($s->name_id, $s->name_type_id,$s->trans_type,$s->trans_no);
         ////////////////////////////////////////////////////////////  
        $totalDebitCredit=$totalDebitCredit+$s->amount;
         ?>
         <tr>
                    <td><?= $s->type_name;?></td>
                     <td style="text-align:left;"><?= date('Y-m-d',strtotime($s->trans_date));?></td>
                    <td style="text-align:center;"><?= $s->trans_number;?></td>
                    <td style="text-align:left;"><?= $student_name;?></td>
                    <td style="text-align:center;">X</td>
                    <td style="text-align:right;"><?= number_format($s->amount);?></td>
                    <td align="right" ><?= number_format($totalDebitCredit); ?></td>
                </tr>


         <?php         

                }
               }
                ?>
                  <tr>
                    <td></td>
                 <td colspan="4">Total Receipts, Deposits and Other Credits</td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalDebitCredit); ?></td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalDebitCredit); ?></td>
                </tr>

                 <tr>
                    <td></td>
                 <td colspan="4">Total Cleared Transaction</td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPayments +$totalDebitCredit); ?></td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPayments +$totalDebitCredit); ?></td>
                </tr>

                <tr>
                    <!-- <td></td> -->
                 <td colspan="5">Cleared Balance</td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPayments +$totalDebitCredit); ?></td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($recon_data[0]->begin_balance + $totalPayments +$totalDebitCredit); ?></td>
                </tr>

                  <tr>
                    <!-- <td></td> -->
                 <td colspan="7"><b>Uncleared Transactions</b></td>
                </tr>

                <tr>
              <td></td>
                <td colspan="6"><b>Payment Vouchers, Charges and Other Debits</b></td>
                </tr>

                 <?php
        /////////////////////deposit and credits ///////////////////////////
                $totalPaymentsUncleared=0;
             
                 $trans = $billmodel->get_payments_uncleared(1,$account_id,date('Y-m-d H:i', strtotime($sdate)),date('Y-m-d H:i', strtotime($edate)),$unchecked_number);

                if(count($trans)>0){
                foreach($trans as $s){
         ////////////////////////////////////////////////////////////
         $student_name=capture_name($s->name_id, $s->name_type_id,$s->trans_type,$s->trans_no);
         ////////////////////////////////////////////////////////////  
        $totalPaymentsUncleared=$totalPaymentsUncleared-$s->amount;
         ?>
         <tr>
                    <td><?= $s->type_name;?></td>
                     <td style="text-align:left;"><?= date('Y-m-d',strtotime($s->trans_date));?></td>
                    <td style="text-align:center;"><?= $s->trans_number;?></td>
                    <td style="text-align:left;"><?= $student_name;?></td>
                    <td style="text-align:center;"></td>
                    <td style="text-align:right;"><?= number_format($s->amount*-1);?></td>
                    <td align="right" ><?= number_format($totalPaymentsUncleared); ?></td>
                </tr>
             <?php         

                }
               }
                ?>
                 <tr>
                    <td></td>
                 <td colspan="4">Total Unclered Payment Vouchers, Charges and Other Debits</td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPaymentsUncleared); ?></td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPaymentsUncleared); ?></td>
                </tr>

                <tr>
                    <td></td>
                 <td colspan="6"><b>Receipts, Deposits and Other Credits</b></td>
                </tr>

                                 <?php
        /////////////////////deposit and credits ///////////////////////////
             

                 $trans2 = $billmodel->get_payments_uncleared(2,$account_id,date('Y-m-d H:i', strtotime($sdate)),date('Y-m-d H:i', strtotime($edate)),$unchecked_number);
                 // $mydata=array(
                 //  'account_id'=>$account_id,
                 //  'sdate'=>date('Y-m-d H:i', strtotime($sdate)),
                 //  'edate'=>date('Y-m-d H:i', strtotime($edate)),
                 //  'tno'=>$recon_data[0]->recon_number,
                 // );
                 //   print_r($mydata);
                 //   return;
                if(count($trans2)>0){
                foreach($trans2 as $s){
         ////////////////////////////////////////////////////////////
         $student_name=capture_name($s->name_id, $s->name_type_id,$s->trans_type,$s->trans_no);
         ////////////////////////////////////////////////////////////  
        $totalDebitUncleared=$totalDebitUncleared+$s->amount;
         ?>
         <tr>
                    <td><?= $s->type_name;?></td>
                     <td style="text-align:left;"><?= date('Y-m-d',strtotime($s->trans_date));?></td>
                    <td style="text-align:center;"><?= $s->trans_number;?></td>
                    <td style="text-align:left;"><?= $student_name;?></td>
                    <td style="text-align:center;"></td>
                    <td style="text-align:right;"><?= number_format($s->amount);?></td>
                    <td align="right" ><?= number_format($totalDebitUncleared); ?></td>
                </tr>
             <?php         

                }
               }
                ?>

                 <tr>
                    <td></td>
                 <td colspan="4">Total Uncleared Receipts, Deposits and Other Credits</td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalDebitUncleared); ?></td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalDebitUncleared); ?></td>
                </tr>
                  <tr>
                    <td></td>
                 <td colspan="4">Total Uncleared Transaction</td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPaymentsUncleared +$totalDebitUncleared); ?></td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalDebitUncleared +$totalPaymentsUncleared); ?></td>
                </tr>

                 <tr>
                    <!-- <td></td> -->
                 <td colspan="5">Register Balance as of <?=date('d-m-Y',strtotime($recon_data[0]->end_date ))?></td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPayments +$totalDebitCredit +$totalPaymentsUncleared +$totalDebitUncleared); ?></td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($recon_data[0]->begin_balance + $totalPayments +$totalDebitCredit +$totalPaymentsUncleared +$totalDebitUncleared); ?></td>
                </tr>


            </tbody>
        </table>
    
</div>
</div>

<script type="text/javascript">
    function printable_rept(area) {
  var _c = $('#content').html(); // Getting content from the 'content' div
  var nw = window.open('', '_blank', 'width=900');

  nw.document.write('<html><head><title>MHI</title></head><body>');

  // Adding custom styles for printing
nw.document.write('<style>');

nw.document.write('@media print {');
// nw.document.write('.container { height: 50%; display: block;}');

nw.document.write('<hr style="height:2px; background-color:black; border:none;">');
nw.document.write('span { padding: 10px; }'); // Add padding to the spans
nw.document.write('body {');
nw.document.write('font-family: "Times New Roman", sans-serif;');
nw.document.write('font-size: 13px;');
nw.document.write('}');

nw.document.write('table {');
nw.document.write(' margin: 0 auto;');
nw.document.write('border-collapse: collapse;');
nw.document.write('font-size: 12px;');
nw.document.write('width: 90%;');
nw.document.write('margin-top: 7px;');
nw.document.write('margin-bottom: 7px;');
nw.document.write('margin-left: 20px;');
nw.document.write('}');
nw.document.write('h6 {font-size: 18px;padding-bottom:0px}');

// nw.document.write('.border {');
// nw.document.write('border: 1px solid black;'); 
// nw.document.write('padding: 5px;');

// nw.document.write('}');
nw.document.write('}');
nw.document.write('</style>');


  nw.document.write(_c);
  nw.document.write('</body></html>');
  nw.print();
}
</script>
  <h6><b>Reconciliation Details</b></h6>
  <h6><?php echo $account_name?>, Period Ending  <?=date('d-m-Y',strtotime($recon_data[0]->end_date ))?></h6>
  <hr style="color:black;">

</div>
</center>

<div class="container">
    <table class="table table-condensed table-centre">
      
            <thead>
                <tr>
                     

                    <th class="text-left">Type</th>
                    <th class="text-left">Date</th>
                    <th class="text-left">trans No</th>
                    <th class="text-left">Name</th>
                 <th class="text-left">Clr</th>
                    <th class="text-center">Amount</th>
                    <th class="text-center">Balance</th>
                </tr>
            </thead>
            <tbody>

         <tr>
                    <td>Begining Balance</td>
                     <td style="text-align:right;"></td>
                    <td style="text-align:right;"></td>
                    <td style="text-align:right;"></td>
                    <td style="text-align:right;"></td>
                    <td style="text-align:right;"></td>
                    <td align="right"><?= number_format($recon_data[0]->begin_balance); ?></td>
                </tr>

                <tr>
                    <td colspan="7"><b>Cleared Transactions</b></td>
                </tr>

                <tr>
                    <td></td>
                 <td colspan="6"><b>Payment Vouchers, Charges and Other Debits</b></td>
                </tr>

                <?php
                $totalPayments=0;
               $trans = $billmodel->get_reconciled_payments(1,$account_id,$recon_data[0]->recon_number);
               if(count($trans)>0){
                foreach($trans as $s){
         ////////////////////////////////////////////////////////////
           if($s->name_type_id == 4){
            $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$s->name_id));
            $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
            $student_id = $app[0]->id;
          }
        else if($s->name_type_id == 3){
             $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$s->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }else if($s->name_type_id == 1){
             $app = $bmodel->get_item_name('students',$where = array('id'=>$s->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }elseif($s->name_type_id==2){
         $app = $bmodel->get_item_name('supplier_tbl', $where = array('supplier_id' => $s->name_id));
         $student_name=$app[0]->supplier_name??"";
             }
        else if($s->name_type_id == 6){
             $app = $bmodel->get_item_name('other_students_tbl',$where = array('id'=>$s->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }else if($s->name_type_id == 7){
             $app = $bmodel->get_item_name('users',$where = array('user_id'=>$s->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
            
            
        }
        elseif($s->name_type_id==5){
                             
       $pad = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $s->trans_no,'trans_type' => $s->trans_type,'name_type_id' => 1));
      
       if(count($pad)>0){
       $std =$bmodel->get_item_name('students', $where = array('id' => $pad[0]->name_id));
     
      $student_name=$std[0]->full_name??"";
    }else{
      //$fullname="";
       $std = $bmodel->get_item_name('students_application_tbl', $where = array('id' => $s->name_id));
     $student_name=$std[0]->full_name??"";
      }
    }else{
        $student_name="";
    }
         ////////////////////////////////////////////////////////////  
    $totalPayments=$totalPayments-$s->amount;
         ?>
         <tr>
                    <td><?= $s->type_name;?></td>
                     <td style="text-align:left;"><?= date('Y-m-d',strtotime($s->trans_date));?></td>
                    <td style="text-align:center;"><?= $s->trans_number;?></td>
                    <td style="text-align:left;"><?= $student_name;?></td>
                    <td style="text-align:center;">X</td>
                    <td style="text-align:right;"><?= number_format($s->amount*-1);?></td>
                    <td align="right" ><?= number_format($totalPayments); ?></td>
                </tr>


         <?php         

                }
               }
                ?>
                 <tr>
                    <td></td>
                 <td colspan="4">Total Payments</td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPayments); ?></td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPayments); ?></td>
                </tr>

                   <tr>
                    <td></td>
                 <td colspan="6"><b>Deposit and Credits</b></td>
                </tr>

                   <?php
        /////////////////////deposit and credits ///////////////////////////
                $totalDebitCredit=0;
               $trans = $billmodel->get_reconciled_payments(2,$account_id,$recon_data[0]->recon_number);
               if(count($trans)>0){
                foreach($trans as $s){
         ////////////////////////////////////////////////////////////
           if($s->name_type_id == 4){
            $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$s->name_id));
            $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
            $student_id = $app[0]->id;
          }
        else if($s->name_type_id == 3){
             $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$s->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }else if($s->name_type_id == 1){
             $app = $bmodel->get_item_name('students',$where = array('id'=>$s->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }elseif($s->name_type_id==2){
         $app = $bmodel->get_item_name('supplier_tbl', $where = array('supplier_id' => $s->name_id));
         $student_name=$app[0]->supplier_name??"";
             }
        else if($s->name_type_id == 6){
             $app = $bmodel->get_item_name('other_students_tbl',$where = array('id'=>$s->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }else if($s->name_type_id == 7){
             $app = $bmodel->get_item_name('users',$where = array('user_id'=>$s->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
            
            
        }
        elseif($s->name_type_id==5){
                             
       $pad = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $s->trans_no,'trans_type' => $s->trans_type,'name_type_id' => 1));
      
       if(count($pad)>0){
       $std =$bmodel->get_item_name('students', $where = array('id' => $pad[0]->name_id));
     
      $student_name=$std[0]->full_name??"";
    }else{
      //$fullname="";
       $std = $bmodel->get_item_name('students_application_tbl', $where = array('id' => $s->name_id));
     $student_name=$std[0]->full_name??"";
      }
    }else{
        $student_name="";
    }
         ////////////////////////////////////////////////////////////  
    $totalDebitCredit=$totalDebitCredit+$s->amount;
         ?>
         <tr>
                    <td><?= $s->type_name;?></td>
                     <td style="text-align:left;"><?= date('Y-m-d',strtotime($s->trans_date));?></td>
                    <td style="text-align:center;"><?= $s->trans_number;?></td>
                    <td style="text-align:left;"><?= $student_name;?></td>
                    <td style="text-align:center;">X</td>
                    <td style="text-align:right;"><?= number_format($s->amount);?></td>
                    <td align="right" ><?= number_format($totalDebitCredit); ?></td>
                </tr>


         <?php         

                }
               }
                ?>
                  <tr>
                    <td></td>
                 <td colspan="4">Total Deposit and Credits</td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalDebitCredit); ?></td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalDebitCredit); ?></td>
                </tr>

                 <tr>
                    <td></td>
                 <td colspan="4">Total Cleared Transaction</td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPayments +$totalDebitCredit); ?></td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPayments +$totalDebitCredit); ?></td>
                </tr>

                <tr>
                    <td></td>
                 <td colspan="4">Cleared Balance</td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($totalPayments +$totalDebitCredit); ?></td>
                 <td align="right" style="border-top: 2px solid black;"><?= number_format($recon_data[0]->begin_balance + $totalPayments +$totalDebitCredit); ?></td>
                </tr>

            </tbody>
        </table>
    
</div>