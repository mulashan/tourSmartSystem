 
<?php
 helper('age');
  $amodel = new App\Models\AdmissionModel();
  $billmodel = new App\Models\BillModel();
  $remodel =new App\Models\ReportsModel();
  $suppliermodel = new App\Models\SupplierModel();

  ?>
 <!-----class pocket money selection options---------->
                <div class="col-md-12 mb-3" id="class_selection" style="display:'';">
             <div class="d-flex justify-content-center">
                    <form id="chargesDate" class="form-inline">
                          Charges date:
                         <div class="input-group ms-1 me-3">
                         <button type="button" class="btn btn-default pull-right daterange-a1" id="daterange-a1">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                      
                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>
                                 </div>
                 
                         </div>
             <!----end-class pocket money selection options---------->
              <center>
                  <div id="all_listed"></div>
             </center>

    <script type="text/javascript">

$("#chargesDate").submit(function (e) {
  if (!$('#daterange-a1 span').html()) {
           // $('#RecptResult').html('Please specify valid date.');
        alert("please specify valid date");
        } else {
            $('#all_listed').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-a1 span').html()+"&trans="+$('#trans').val();
         // alert(dta);
          //return;
             $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillController/control_number_charges_edit'; ?>',
                 data: dta,
                success: function (res) {
                    $('#all_listed').html(res);
                },
                error: function () {
                    alert('error');
                    $('#all_listed').html('<div class="alert alert-warning">Fail to retreive results.!!</div>');
                }
            });

        }
 e.preventDefault();
 });

          $(function () {  
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-a1 span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('.daterange-a1').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                                         'This Year': [moment().startOf('year'), moment().endOf('year')],
                                        'Last Year': [moment().subtract(1, 'year').startOf('month'), moment().subtract(1, 'year').endOf('year')],
                                    }
                                }, cb);
                                cb(start, end);

                            }); 
    </script>