  <style type="text/css">

     .invoice > .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }

 </style>
 <?php
  $billmodel = new App\Models\BillModel();
  $suppliermodel = new App\Models\SupplierModel();
  $leger_transaction = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>4));
  $supplier_name = "";
  $name_type = "";
  $ref="";
  $amount = 0;

  $suppl = $billmodel->get_item_name('supplier_tbl', $where = array('supplier_id'=>$leger_transaction[0]->name_id));
  $supplier_name = $suppl[0]->supplier_name;
  $name_type_id = $billmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
  $billref = $billmodel->get_item_name('transaction_other_details_tbl',$where = array('transaction_no'=>$inv[0]->trans_number));
  $billattch = $billmodel->get_item_name('transaction_attachments_tbl',$where = array('transaction_number'=>$inv[0]->trans_number));
 ?>
<div class="row">
    <div id="feedback"></div>
<!-------------------- Bill Information starts here  ------------------>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Bill Information</h5>
            </div>
            </hr>

            <div class="card-body">
                
                <input type="hidden" name="supplier_name" id="supplierid" value="<?= $inv[0]->trans_number;?>">
                <table class="table table-borderless">
                    <tr>
                        <th>Bill Number:</th>
                        <td><?= $inv[0]->trans_number; ?></td>
                    </tr>
                     <tr>
                        <th>Bill Reference:</th>
                        <td><?= $billref[0]->bill_reference;?></td>
                    </tr>
                    <tr>
                        <th>Bill Date:</th>
                        <td><?= $inv[0]->trans_date; ?></td>
                    </tr>
                     <tr>
                        <th>Due Date:</th>
                        <td><?= $billref[0]->due_date;?></td>
                    </tr>
                    <tr>
                        <th>Name Type:</th>
                        <td><?= $name_type_id[0]->name_type; ?></td>
                    </tr> 
                    <tr>
                        <th>Supplier Name:</th>
                        <td><?= $supplier_name; ?></td>
                    </tr>
                    <tr>
                        <th>Supplier Id:</th>
                        <td><?= $suppl[0]->supplier_id; ?></td>
                    </tr>
                
                </table>
            </div>
    </div>
</div>
 <!-------------------- Payment History starts here  ------------------>

    <?php
   // $databaseName=session()->get('school');
     $dbname=session()->get('db_name');
    $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;
                        $query = $db->query('SELECT item_transation_tbl.item_id,item_name,account_name,trans_number,quantity,unit_price FROM item_transation_tbl,items_tbl,items_ledgers_tbl,accounts_tbl where item_transation_tbl.item_id = items_tbl.id AND items_ledgers_tbl.item_id = items_tbl.id AND item_transation_tbl.trans_type = 4 AND accounts_tbl.id = items_ledgers_tbl.account_id AND trans_number='.$inv[0]->trans_number);
                        $result = $query->getResult();

                        foreach($result as $itm){
                            $dat = $billmodel->get_trans_type($inv[0]->trans_number);
                             $query2 = $db->query('SELECT type_name,amount FROM ledger_transaction_tbl,account_types_tbl where ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_transaction_tbl.trans_type = 4 AND (ledger_type = 10) AND trans_no='.$inv[0]->trans_number);
                             $result2 = $query2->getResult();
                             $amount = $itm->amount;
                           
                            $total += $amount;
                             }
          ?>
     <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Payment History</h5>
            </div>
            </hr>

            <div class="card-body">
                <table class="table" id="paytable">
                    <thead>
                                <tr>
                                    
                                    <th>Rcpt No.</th>
                                    <th>Receipt Date</th>
                                   <th class="text-right">Receipt Amount</th>
                                    <th>Received By</th>
                                    <th width="100px">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                <?php
                $ttamount =0;
                $trans = $billmodel->get_item_name('transactions_relation',$where = array('invoice_trans_no' =>$inv[0]->trans_number));
                if(count($trans)>0){
                foreach($trans as $s){
                $number = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$s->receipt_trans_no,'trans_type_id'=>4));
                $leger_transaction = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->receipt_trans_no,'ledger_type'=> 10,'trans_type' =>4,'transation_nature' =>2));
                        $supplier_name = "";
                        $supplier_id = "";
                        $control_number = "";
                        $name_type = "";
                        $amount =0;
                        $i=0;
                         if(count($leger_transaction) > 0){
                        // $total_amount = $bmodel->get_invoice_amount_payed($s->receipt_trans_no,9);
                        foreach($leger_transaction as $itm){
                        $get_invoice = $billmodel->get_item_name('transactions_relation',$where = array('receipt_trans_no' =>$itm->trans_no));
                        if($get_invoice[$i]->invoice_trans_no==$inv[0]->trans_number){
                                     
                        $amount = $itm->amount;
                        }
                                  //$i++;
                         $ttamount+=$amount;
                        }
                       
                        if($leger_transaction[0]->name_type_id == 2){
                        $suppl = $billmodel->get_item_name('supplier_tbl',$where = array('supplier_id'=>$leger_transaction[0]->name_id));
                        $supplier_name = $suppl[0]->supplier_name; 
                        $supplier_id = $suppl[0]->supplier_id;
                        $supplier_phone = $suppl[0]->supplier_phone;
                        $type_name = $billmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                        $name_type = $type_name[0]->name_type;    
                                        }
                            $user = $billmodel->get_item_name('users', $where = array('user_id' => $number[0]->updated_by));
                                ?>

                                <tr>
                                    <td><?= $s->receipt_trans_no;?></td>
                                    <td><?= date('Y-m-d',strtotime($number[0]->trans_date));?></td>
                                      <td class="text-right"><?= number_format($amount); ?></td>
                                    <td><?= $user[0]->first_name.' '.$user[0]->last_name; ?></td>
                                     
                                    <td>
                                    <a href="javascript:void(0)" onclick="manage_receipt(<?php echo $number[0]->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i></a>
                                     <a href="javascript:void(0)" onclick="delete_receipt(<?php echo $number[0]->id;?>)"  class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                    </td>
                                    
                                </tr>
                            <?php }}}else{
                                echo "<tr><td>Currently there is no record</td></tr>";
                            } ?>
                            <tr><td><b>Total</b></td><td></td><td class="text-right"><b><?php echo number_format($ttamount);?></b></td></tr>
                             <tr><td><b>Amount Due</b></td><td></td><td class="text-right"><b><?php echo number_format($ttamount);?></b></td></tr>
                        </tbody>
                </table>
             </div>
     </div>
 </div>
</div>
</div>

<!-------------------- Charged Items starts here --------------------->
<div class="row">
    <div class="col-md-12">
        <div class="card  invoice">
            <div class="card-header">
                <h5>Charged Ledgers</h5>
            </div>
            </hr>

            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Ledger Id</th>
                            <th>Ledger Name</th>
                            <th>Expense Description</th>
                            <th class="text-right">Amount</th>
                            <th>Budget Ledger</th>

                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="">
                        <?php

                        $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;

                        $query = $db->query('SELECT ledger_transaction_tbl.ledger_id,trans_no,ledger_transaction_tbl.id,amount,trans_desc FROM ledger_transaction_tbl,transaction_numbers_tbl where  ledger_transaction_tbl.trans_no = transaction_numbers_tbl.trans_number AND ledger_transaction_tbl.trans_type= transaction_numbers_tbl.trans_type_id AND transaction_numbers_tbl.trans_type_id = 4 AND ledger_transaction_tbl.trans_item != 0  AND transaction_numbers_tbl.trans_number='.$inv[0]->trans_number);
                        $result = $query->getResult();
                        foreach($result as $itm){
                            $dat = $billmodel->get_trans_type($inv[0]->trans_number);
                            $acc = $billmodel->get_item_name('accounts_tbl',$where = array('id' =>$itm->ledger_id));
                             
                             $amount = $itm->amount;
                           $total += $amount;
                               
                         $budget = $billmodel->get_budget_name($itm->id);
                         // print_r($budget);
                            ?>
                         <tr>
                             <td><?= $itm->ledger_id; ?></td>
                             <td><?= $acc[0]->account_name; ?></td>
                             <td><?=$budget[0]->description??""; ?></td>
                             <td class="text-right"><?= number_format($itm->amount); ?></td>
                            <td><?= $budget[0]->account_name; ?></td>

                         </tr>
                    <?php }  ;?>
                            <tr>
                                <td></td><td></td> <td></td>
                                <td class="text-right"><b><?php echo number_format($total); ?></b></td>
                            </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!------------------ here Approval information starts---->
      <?php $bill = $billmodel->billdata($inv[0]->trans_number,$inv[0]->trans_type_id); ?>
 <?php  $Initiator= $billmodel->bill_response($bill[0]->app_id); ?>
<div class="row">
 <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Approval History</h5>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              
                <label>Approval Status: </label>
                 <?php 
                //$id_trans = $inv[0]->trans_number;
                $checker = 0;
               foreach($Initiator as $dat){
                if($dat->user_role == '3' && $dat->hstatus =='1')
                {
                    $checker =1;
                }
                elseif($dat->user_role =='3' && $dat->hstatus =='2'){
                    $checker =2;
                }
                 elseif($dat->user_role =='3' && $dat->hstatus =='3'){
                    $checker =3;
                }
               
               }
                if($checker == 1)
                {
                     echo  '<label style="color:green;">  &nbsp;&nbsp; Approved! </label>';
                 }
                  elseif($checker == 2){
                     echo  '<label style="color:red;">  &nbsp;&nbsp; Rejected! </label>';
                 }
                 else{
                echo'<label style="color:red;">  &nbsp;&nbsp; Pending! </label>';
                 }

                
                 ?>
            </div>
            </hr>

       <?php $bill = $billmodel->billdata($inv[0]->trans_number,$inv[0]->trans_type_id); ?>
     <?php $hist_data = $billmodel->getdatabill($bill[0]->app_id); ?>
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>approval Date:</th>
                        <th>Comment:</th>
                        <th>Name:</th>
                        <th>User Role:</th>
                    </tr>
                <?php foreach($hist_data as $in): ?>
                    <tr>
                        <td><strong><?=$in->hist_date; ?></strong></td>
                        <td class="text-primary"><?= $in->comment; ?></td>
                        <td>
                            <?= $in->first_name.' '.$in->last_name; ?>
                        </td>
                        <td><?php if($in->user_role == '1'){
                            echo "Initiator";
                        }elseif($in->user_role == '2'){
                            echo "Checker";
                        }elseif($in->user_role == '3'){
                            echo "Approver";
                        } ?></td>
                    </tr>
                 <?php endforeach; ?>
                </table>
            </div>
        </div>
    </div>

    <!-- image attachment pop up -->
      <div class="cust_popup_lg" id="Attchmnt2" style="display:none">
                    <a href="javascript:void(0)" class="pull-right" onclick="CloseAttachmnt2()"><i class="fa fa-times"></i></a>
                  <div id="ViewAttachment"></div>
                    <br>                   
                    <!-- <a href="javascript:void(0)" class="btn btn-danger btn-xs pull-right" onclick="DeleteAttachmnt()">Delete</a> -->
                </div>


           <!------------------ here accounts receivable ------------------->
        <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Accounts Payable</h5>
            </div>
            </hr>
           <div class="card-body">
                <table class="table">
                    <!-- <th colspan="8"><p class=" d-flex justify-content-start mt-3"><b>ACCOUNT RECEIVABLES</b></p></th> -->
                    <tbody>
                        <?php 
                            $accnt = $db->query('SELECT ledger_transaction_tbl.id,ledger_transaction_tbl.ledger_id,ledger_transaction_tbl.ledger_type,ledger_transaction_tbl.amount,ledger_transaction_tbl.name_id,accounts_tbl.account_name,account_types_tbl.type_name 
                            FROM ledger_transaction_tbl,accounts_tbl,account_types_tbl 
                            WHERE ledger_transaction_tbl.ledger_id = accounts_tbl.id AND ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_transaction_tbl.ledger_type = 6 AND ledger_transaction_tbl.trans_type=4 AND ledger_transaction_tbl.trans_no='.$inv[0]->trans_number);
                            $results  = $accnt->getResult();
                    
                        ?>
                        <tr>
                            <td><?= $results[0]->ledger_id; ?></td>
                            <td><?= $results[0]->account_name; ?></td>
                            <td colspan="3"></td>
                            <td colspan="5"><b><?php echo number_format($total); ?>
                            <td><?= $results[0]->type_name; ?></td>
                        </tr>
                        
                            <tr>
                                <td colspan="5"></td>
                                <td colspan="3"><b><?php echo number_format($total); ?></b></td>
                            </tr>
                    </tbody>
                </table>

            </div>
        </div>
</div>
</div>
<!------------------ here Approval information starts---->
<div class="row">
 <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Supporting Documents</h5>
            </div>
            </hr>
            <?php  $Initiator= $billmodel->get_initiator_name($inv[0]->trans_number); ?>
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                <?php foreach($billattch as $transnumber ): ?>
                        <tr>
                    <th>file attached: </th>
                      <td>
                        <!-- <a href="javascript:void(0)" alter="file" onclick="displayImage('<?=$transnumber->image_attachment; ?>')"><?=$transnumber->image_attachment; ?></a> -->
                    <button type="button" class="btn btn-primary" onclick="displayImage('<?=$transnumber->image_attachment; ?>')">
                      View <?=$transnumber->image_attachment; ?>
                    </button>
                      </td>
                    
                   </tr> 
                <?php endforeach; ?> 
                </table>
            </div>
        </div>
    </div>

    <!-----------------for msg------------------>
<div class="col-md-6">
            <div class="card msg">
             <div class="card-header">
                <h5>Message Information</h5>
            </div>
            <hr>
           <?php
           $bll=$inv;
            $msg_grp = $billmodel->get_item_name('message_groups_tbl',$where = array('message_type'=>13,'trans_number'=>$bll[0]->trans_number));
          $msg = "";
           $phone = "";
          $status='';
          if(count($msg_grp)>0){
              $m = $billmodel->get_item_name('messages',$where = array('send_no'=>$msg_grp[0]->send_number));
                       
                         if(count($m) > 0){
                            $msg = $m[0]->message;
                             $phone = $m[0]->phone_no;
                            $msg= str_replace(array("\r","\n"),' ',$msg);
                          if($m[0]->sent_status == 1) {
                           $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description;
                          }elseif($m[0]->sent_status == 2){
                            $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description." <br>Delivered Date: ".$m[0]->time_delivered;
                          }
                        }
                    }
             if($msg==""){
            $status="<span class='text-red'>Not Sent</span>";
         $msg = "Bill ".$bll[0]->trans_number." to ".$supplier_name." for ".number_format($total)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
                }

              // print_r($bll);
                   ?>
                
          
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <?php
                     if($phone !=""){
                    ?>
                <tr>
                        <th>Phone:</th>
                        <td id="phone"><?= $phone; ?> </td>
                    </tr>
                <?php }?>
                    <tr>
                        <th>Message:</th>
                        <td id="msg"><?= $msg; ?> </td>
                    </tr>
                    <tr>
                        <th>Status:</th>
                        <td id="msg"><?= $status; ?> </td>
                    </tr>
                    

                </table>
            </div>
            </div>
        </div>
<!-----------------end for msg------------------>
</div>

    
   <script type="text/javascript">
      function CloseAttachmnt2() {
        $('#Attchmnt2').hide(100);
       
    }
       function displayImage(image_attachment)
       {
         $('#Attchmnt2').show(100);
        $('#ViewAttachment').html('<iframe src="<?php echo base_url() . '../public/transaction_files/'; ?>' + image_attachment + '" style="width:100%;height:500px"></iframe>');
                
       }
   </script>

    
    

