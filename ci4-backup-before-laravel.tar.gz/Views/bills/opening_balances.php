<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css');?>"/>
<style type="text/css">
    tr:hover {
cursor: pointer;

}

            .preview-container {
            display: flex;
            flex-wrap: wrap;
        }

        .preview-image {
            width: 100px;
            height: 100px;
            margin: 5px;
            position: relative;
        }

        .remove-button {
            position: absolute;
            top: 0;
            right: 0;
            cursor: pointer;
            background-color: red;
            color: white;
            padding: 3px;
            border-radius: 50%;
            display: none;
        }

        .preview-image:hover .remove-button {
            display: block;
        }
 
</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Opening Balances</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                $bmodel = new App\Models\BillingModel();
                   $amodel = new App\Models\AdmissionModel();
                $bank1 = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 9));
                $bank = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 8));
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Opening Balances</li>
                </ol>
            </div>
        <div id="largeScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#bills-all">Opening Balances List</a></li>
                 <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#bill-add">New Opening Balances</a></li>
            </ul>
        </div>

             <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#bills-all">Opening Balances List</a></li>
                <li></li><li></li>
                  <li class="nav-item d-none d-sm-block"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#bill-add">New Opening Balances</a></li>
            </ul>
             </div>
           
        </div>
    </div>
</div>

<div class="section-body mt-4">
        <div class="container-fluid">
            <div class="tab-content">

         <div class="tab-pane active" id="bills-all">
               <div class="d-flex justify-content-center">
                <div id="messageDisplayArea"></div>
                    <form id="BillResult" class="form-inline">
                         Date:
                         <div class="input-group ms-3 me-3">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                          
                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="opening_list"></div>
                </center>
            </div>


            <div class="tab-pane" id="bill-add">
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="card card-lg">
                            <div class="card-header"  style="height:5px">
                                <h3 class="card-title">Opening Balance Details</h3>
                                <div class="card-options ">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                                <hr>
                    <div class="card-body">
                    <form class="form-horizontal" id="Opening_details_form" >
                         <div id="feedback"></div>
                         <div class="row">
                            <div class="col-md-6">
                                
                       

                             <div class="form-group row">
                            <label for="inputpaidBy" class="col-sm-4 col-form-label"> Date</label>
                                <div class="col-sm-8">
                                <input type="date" id="open_date" name="open_date" value="<?php echo date('Y-m-d');?>" class="form-control" required>
                                </div>
                                </div>

                                 <div class="form-group row" >
                                <label class="col-md-4 col-form-label"> Bank Ledger<span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <select name="debit_bank" id="debit_bank" class="form-control" required="required">
                                        <option value="">-Select-</option>
                                        <?php foreach ($bank1 as $ac): ?>
                                            <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                            </div>


                                     <div class="form-group row">
                                    <label for="inputpaidBy" class="col-sm-4 col-form-label">Amount<span class="text-danger">*</span></label>
                                <div class="col-sm-8">
                                <input type="text" id="amount" name="amount" class="form-control" required>
                              </div>
                                </div>

                                   <div class="form-group row">
                                    <label for="inputpaidBy" class="col-sm-4 col-form-label">Description<span class="text-danger">*</span></label>
                                <div class="col-sm-8">
                                <textarea class="form-control" id="desc" name="desc" rows="5">Opening Balances</textarea>
                              </div>
                                </div>

                            <div class="form-group row" >
                                <label class="col-md-4 col-form-label">Equity Ledger<span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <select name="credit_bank" id="credit_bank" class="form-control" required="required">
                                        <option value="">-Select-</option>
                                        <?php foreach ($bank as $ac): ?>
                                            <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                            </div>

                   
            </div>   
                                   
        </div>

                    <!-- Here starts the form for accounts payable  -->
                        <!-- Here it ends the payable accounts --> 
                         <div class="form-group row">
                            <div class="col-md-8">
                                <button type="submit" id="create_bill" class="btn btn-primary float-right">Create</button>
                            </div>
                        </div>
                        </form>
                            </div>
                        </div>
                        
                    </div>
                </div>
            
            </div>

             
            </div>
        </div>
        </div>
    </div>

  <!-- Modal to View All Customer Information -->

  <div class="modal fade" id="myviewModal" role="dialog">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Bill Information</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Viewbill"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <!-- Modal to update Customer Information-->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <!--<h5 class="modal-title" id="staticBackdropLabel">Edit Bill Information</h5>-->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Updtebill"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script><script type="text/javascript">


   ///////////////////here load expense ledgers starts here///////////////
    var hold_selected_accounts = []; // hold all selected items
   $(document).ready(function(){
      });



var account_ttl=0; 
$('#saveleger').click(function(evt){
     //$('#itemsbdy').empty();
    //alert($(this).serialize());
        var data = 'accountid=' + $('#expenseledger').val()+'&incomeid='+$('#incomeledger').val();
        //alert(data);
        //var incomelg = $('#payable-data-ajax').val();
        var ttl =$('#amount').val();
        var descr =$('#description').val();
        // var amnt =$('#amount').val()

  $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/BillController/fetch_expense_ledgers'; ?>',
            success: function(response){
                console.log(response);
                var lData = JSON.parse(response);
                var len = lData.length;
                //alert(account_ttl);
                for(var i = 0; i < len; i++){
                    
                    account_ttl = account_ttl + parseInt(ttl);
                    
                    var aid = lData[i]['id'];
                    var ledger_type = lData[i]['account_type_id'];
                    //var description = descr;
                     
                     //var qua='quantity'+aid+'';

                    //$('#total').val(amnt);

                    $('#show_ledger').append('<tr id="row_'+ lData[i]['id'] +'"><input type="hidden" name="ttl" value="'+ttl+'">'+
                        '<td><div class="text-left"><input type="hidden" name="aid[]" value="'+lData[i]['id']+'">'+lData[i]['id']+'</div></td>\
                        <td><div class="text-left">'+lData[i]['account_name']+'</div></td>\
                        <td><input type="hidden" name="type_name'+lData[i]['id']+'" value="'+$('#expenseledger').val()+'"></td>\
                        <td><input type="hidden" name="incmeledger'+lData[i]['id']+'" value="'+$('#incomeledger').val()+'"></td>\
                        <td></td>\
                        <td><div class="text-left"><input type="hidden" name="description'+lData[i]['id']+'" value="'+descr+'">'+descr+'</div></td>\
                        <td><div class="text-center"><input type="hidden" name="ttl'+lData[i]['id']+'" value="'+ttl+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</div></td>\
                        <td><div class="text-left"><input type="hidden" name="payable_name'+lData[i]['id']+'" value="'+lData[i]['payable_id']+'">'+lData[i]['payable_name']+'</td>\
                        </div></td>\
                        <td>\
                            <div class="text-left"><a href="javascript:RemoveRow('+lData[i]['id']+','+ttl+');" class="btn btn-danger">x</a></div>\
                        </td>\
                    </tr>');
                }
            
            //accountledgers = {aid:aid, amount: ttl,description:desc};
            //billdetails.push(accountledgers);
            document.getElementById("totalsum0").innerHTML = "Total = " + account_ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(account_ttl);
           // alert(account_ttl);
            return account_ttl;
            }
        });


        evt.preventDefault();
   });

    ////////////////// function to remove single row //////////////////////



     /////////////// function to save all the Bill Details ///////////////

      $('#Opening_details_form').submit(function(e){ 
        
        var form_data = $(this).serialize()+'&'+$("#header_form").serialize();
        // alert(form_data);
       $.ajax({
            method: 'POST',
           url: '<?php echo base_url() . '/index.php/BillController/save_opening_balances'; ?>',
            data: form_data,
           
            success:function(res){
            // $('#create_bill').prop("disabled", true);
                var data = JSON.parse(res);
                if(data['status'] == "1"){
                    swal('success','Saved successfully!','success');
                    setTimeout(function(){
                        window.location.reload();
                    },1500)
                }else{
                 //   $('#create_bill').prop("disabled", true);
                    swal('error','Sorry! Something went wrong!','error');
                }
            },
            error:function(res){
                swal('error','Sorry! Something went wrong!','error');
                setTimeout(function(){
            //window.location.reload();
                },1000)
            }
        });

        e.preventDefault();
    
    });
      ////////////// function to load bill to supplier ///////////////
        $(document).ready(function(){
        // fetch_data();
         $('#load_suppl').select2({
            ajax: {
                url: "<?= base_url('load_supplier'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });
     });


 
$(function () {
var start = moment();
var end = moment();
function cb(start, end) {
$('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
}
$('#daterange-btn').daterangepicker({
startDate: start,
endDate: end,
ranges: {
 'Today': [moment(), moment()],
'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
'Last 7 Days': [moment().subtract(6, 'days'), moment()],
'Last 30 Days': [moment().subtract(29, 'days'), moment()],
'This Month': [moment().startOf('month'), moment().endOf('month')],
'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
 'This Year': [moment().startOf('year'), moment().endOf('year')],
'Last Year': [moment().subtract(1, 'year').startOf('month'), moment().subtract(1, 'year').endOf('year')]
}
}, cb);
cb(start, end);

});

    ///////////////////// for Filtering Bill date/////////////////////////
      $('#BillResult').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#billresponse').html('Please specify valid date.');
        } else {
            $('#opening_list').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn span').html();
            // alert(dta);
            // return;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillController/fetch_opening_balances'; ?>',
                //url: '<?php echo base_url() . '/billfilterdata'; ?>',

                data: dta,
                success: function (res) {
                    $('#opening_list').html(res);
                },
                error: function () {
                    $('#opening_list').html('<div class="alert alert-warning">Fail to retreive Bill.!!</div>');
                }
            });

            }
        e.preventDefault();
    });
                     
    </script>