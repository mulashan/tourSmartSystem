  <link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css');?>"/>
  <style type="text/css">

     .invoice > .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }

 </style>

<div class="row">
 <!-------------------- Bill Information starts here  ------------------>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Bill Information</h5>
            </div>
            </hr>
            <div class="card-body">
                <?php
               // print_r($bll);
                ?>
                
                <input type="hidden" name="supplier_name" id="supplierid" value="<?= $bll[0]->trans_number;?>">
                <table class="table table-borderless">
                    <tr>
                        <th>Bill Number:</th>
                        <td><?= $bll[0]->trans_number; ?></td>
                    </tr>
                     <tr>
                        <th>Bill Reference:</th>
                        <td><?= $bll[0]->bill_reference;?></td>
                    </tr>
                    <tr>
                        <th>Bill Date:</th>
                        <td><?= $bll[0]->trans_date; ?></td>
                    </tr>
                     <tr>
                        <th>Due Date:</th>
                        <td><?= $bll[0]->due_date;?></td>
                    </tr>
                    <tr>
                        <th>Name Type:</th>
                        <td><?= $bll[0]->name_type; ?></td>
                    </tr> 
                    <tr>
                        <th>Supplier Name:</th>
                        <td><?= $bll[0]->supplier_name; ?></td>
                    </tr>
                    <tr>
                        <th>Supplier Id:</th>
                        <td><?=$bll[0]->supplier_id; ?></td>
                    </tr>
                </table>
            </div>
    </div>
</div>


 <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Payment History</h5>
            </div>
            </hr>

            <div class="card-body">
                <table class="table" id="paytable">
                    <thead>
                                <tr>
                                    
                                    <th>Rcpt No.</th>
                                    <th>Receipt Date</th>
                                   <th class="text-right">Receipt Amount</th>
                                    <th>Received By</th>
                                    <th width="100px">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                <?php
                $dbname=session()->get('db_name');
                    $db = \Config\Database::connect($dbname);
                  $billmodel = new App\Models\BillModel();
                $ttamount =0;
                $trans = $billmodel->get_item_name('transactions_relation',$where = array('invoice_trans_no' =>$bll[0]->trans_number));
                if(count($trans)>0){
                foreach($trans as $s){
                $number = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$s->receipt_trans_no,'trans_type_id'=>4));
                $leger_transaction = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->receipt_trans_no,'ledger_type'=> 10,'trans_type' =>4,'transation_nature' =>2));
                        $supplier_name = "";
                        $supplier_id = "";
                        $control_number = "";
                        $name_type = "";
                        $amount =0;
                        $i=0;
                         if(count($leger_transaction) > 0){
                        // $total_amount = $bmodel->get_invoice_amount_payed($s->receipt_trans_no,9);
                        foreach($leger_transaction as $itm){
                        $get_invoice = $billmodel->get_item_name('transactions_relation',$where = array('receipt_trans_no' =>$itm->trans_no));
                        if($get_invoice[$i]->invoice_trans_no==$inv[0]->trans_number){
                                     
                        $amount = $itm->amount;
                        }
                                  //$i++;
                         $ttamount+=$amount;
                        }
                       
                        if($leger_transaction[0]->name_type_id == 2){
                        $suppl = $billmodel->get_item_name('supplier_tbl',$where = array('supplier_id'=>$leger_transaction[0]->name_id));
                        $supplier_name = $suppl[0]->supplier_name; 
                        $supplier_id = $suppl[0]->supplier_id;
                        $supplier_phone = $suppl[0]->supplier_phone;
                        $type_name = $billmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
                        $name_type = $type_name[0]->name_type;
                                            
                                        }
                            $user = $billmodel->get_item_name('users', $where = array('user_id' => $number[0]->updated_by));
                                ?>

                                <tr>
                                    <td><?= $s->receipt_trans_no;?></td>
                                    <td><?= date('Y-m-d',strtotime($number[0]->trans_date));?></td>
                                      <td class="text-right"><?= number_format($amount); ?></td>
                                    <td><?= $user[0]->first_name.' '.$user[0]->last_name; ?></td>
                                     
                                    <td>
                                    <a href="javascript:void(0)" onclick="manage_receipt(<?php echo $number[0]->id;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i></a>
                                     <a href="javascript:void(0)" onclick="delete_receipt(<?php echo $number[0]->id;?>)"  class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                    </td>
                                    
                                </tr>
                            <?php }}}else{
                                echo "<tr><td>Currently there is no record</td></tr>";
                            } ?>
                            <tr><td><b>Total</b></td><td></td><td class="text-right"><b><?php echo number_format($ttamount);?></b></td></tr>
                             <tr><td><b>Amount Due</b></td><td></td><td class="text-right"><b><?php echo number_format($ttamount);?></b></td></tr>
                        </tbody>
                </table>
             </div>
     </div>
 </div>
</div>
</div>

<!-------------------- Charged Items starts here --------------------->
<div class="row">
    <div class="col-md-12">
        <div class="card  invoice">
            <div class="card-header">
                <h5>Charged Ledgers</h5>
            </div>
            </hr>
    <!--################## start of expense list################### -->
            <form class="form-horizontal" id="updatebill" enctype="multipart/form-data">
                
                   <input type="hidden" name="trans_nu" id="tra_nu" value="<?=$bll[0]->trans_number; ?>" required class="form-control">
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Expense Leger<span class="text-danger">*</span></label>
                            <div class="col-md-3">
                            <select name="expnsledger" class="form-select form-control" id="expnsledger" style="width:100%;height: 15px;"></select>
                           </div>

                            <label class="col-md-2 col-form-label">Description<span class="text-danger">*</span></label>
                            <div class="col-md-4">
                            <input type="text" name="description" id="descript"  class="form-control">
                           </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Amount<span class="text-danger">*</span></label>
                            <div class="col-md-3">
                            <input type="text" name="amount" id="amnt"  class="form-control">
                           </div>

                              <label class="col-md-2 col-form-label">Budget Leger<span class="text-danger">*</span></label>
                                <div class="col-md-4">
                                <select name="incmledger" class="form-select form-control" id="incmledger"  style="width:100%;height: 15px;"></select>
                                </div>

                            <div class="col-md-1">
                            <button type="button" class="btn btn-primary" id="storeleger"><i class="fa fa-plus"></i></button>
                            </div>
                        </div> 
                        <!--################## end of expense list################### -->
            <div class="card-body">
                <table class="table">
                         <thead>
                        <tr>
                            <th>#Ledger Id</th>
                            <th>Ledger Name</th>
                            <th>Expense Description</th>
                            <th class="tex-left">Amount</th>
                            <th>Budget Ledger</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="show_ledgers">
                         <?php
                        $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;

                        $query = $db->query('SELECT ledger_transaction_tbl.ledger_id,account_name,trans_no,amount,type_name,trans_desc FROM ledger_transaction_tbl,accounts_tbl,account_types_tbl,transaction_numbers_tbl where  ledger_transaction_tbl.ledger_id = accounts_tbl.id AND ledger_transaction_tbl.trans_no = transaction_numbers_tbl.trans_number AND accounts_tbl.account_type_id = account_types_tbl.id AND ledger_transaction_tbl.trans_type = 4 AND ledger_transaction_tbl.trans_item != 0  AND trans_no='.$bll[0]->trans_number);
                        $result = $query->getResult();
                        foreach($result as $itm){
                            $dat = $billmodel->get_trans_type($bll[0]->trans_number);

                             $query2 = $db->query('SELECT type_name,amount FROM ledger_transaction_tbl,account_types_tbl where ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_transaction_tbl.trans_type = 4 AND (ledger_transaction_tbl.ledger_type = 10)
                             AND ledger_transaction_tbl.trans_item != 0  AND trans_no='.$bll[0]->trans_number);
                             $result2 = $query2->getResult();
                             $amount = $itm->amount;
                           $total += $amount;
                               
                         $budget = $billmodel->get_budget_name($bll[0]->trans_number);
                     }
                            ?>

                    </tbody>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                         <td id="totalamount" style="font-size: 18px;"></td>
                        <td class="text-right"><b></b></td>
                        </tr>

                </table>
              

        <!------------------ here Approval information starts---->
   <?php 
   //print_r($bll);
   $bill = $billmodel->billdata($bll[0]->trans_number,$bll[0]->trans_type); ?>
 <?php  $Initiator= $billmodel->bill_response($bill[0]->app_id); ?>
<div class="row">
 <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Approval History</h5>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              
                <label>Approval Status: </label>
                 <?php 
                //$id_trans = $inv[0]->trans_number;
                $checker = 0;
               foreach($Initiator as $dat){
                if($dat->user_role == '3' && $dat->hstatus =='1')
                {
                    $checker =1;
                }
                elseif($dat->user_role =='3' && $dat->hstatus =='2'){
                    $checker =2;
                }
                 elseif($dat->user_role =='3' && $dat->hstatus =='3'){
                    $checker =3;
                }
               
               }
                if($checker == 1)
                {
                     echo  '<label style="color:green;">  &nbsp;&nbsp; Approved! </label>';
                 }
                  elseif($checker == 2){
                     echo  '<label style="color:red;">  &nbsp;&nbsp; Rejected! </label>';
                 }
                 else{
                echo'<label style="color:red;">  &nbsp;&nbsp; Pending! </label>';
                 }

                
                 ?>
            </div>
            </hr>

     <?php
     $bill = $billmodel->billdata($bll[0]->trans_number,$bll[0]->trans_type); 
      $billattch = $billmodel->get_item_name('transaction_attachments_tbl',$where = array('transaction_number'=>$bll[0]->trans_number));
       ?>
     <?php $hist_data = $billmodel->getdatabill($bill[0]->app_id); ?>
            <div class="card-body">
                
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>approval Date:</th>
                        <th>Comment:</th>
                        <th>Name:</th>
                        <th>User Role:</th>
                    </tr>
                <?php foreach($hist_data as $in): ?>
                    <tr>
                        <td><strong><?=$in->hist_date; ?></strong></td>
                        <td class="text-primary"><?= $in->comment; ?></td>
                        <td>
                            <?= $in->first_name.' '.$in->last_name; ?>
                        </td>
                        <td><?php if($in->user_role == '1'){
                            echo "Initiator";
                        }elseif($in->user_role == '2'){
                            echo "Checker";
                        }elseif($in->user_role == '3'){
                            echo "Approver";
                        } ?></td>
                    </tr>
                 <?php endforeach; ?>
                </table>
            </div>
        </div>
    </div>
    <!------------------ here accounts receivable ------------------->
        <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Accounts Payable</h5>

            </div>
           
            </hr>
           <div class="card-body">
                <table class="table">
                    <!-- <th colspan="8"><p class=" d-flex justify-content-start mt-3"><b>ACCOUNT RECEIVABLES</b></p></th> -->
                    <tbody>
                        <?php 
                            $accnt = $db->query('SELECT ledger_transaction_tbl.id,ledger_transaction_tbl.ledger_id,ledger_transaction_tbl.ledger_type,ledger_transaction_tbl.amount,ledger_transaction_tbl.name_id,accounts_tbl.account_name,account_types_tbl.type_name 
                            FROM ledger_transaction_tbl,accounts_tbl,account_types_tbl 
                            WHERE ledger_transaction_tbl.ledger_id = accounts_tbl.id AND ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_transaction_tbl.ledger_type = 6 AND ledger_transaction_tbl.trans_type=4 AND ledger_transaction_tbl.trans_no='.$bll[0]->trans_number);
                            $results  = $accnt->getResult();
                    
                        ?>
                        <tr>
                            <td><?= $results[0]->ledger_id; ?></td>
                            <td><?= $results[0]->account_name; ?></td>
                            <td colspan="3"></td>
                            <td colspan="5"><b><?php echo number_format($results[0]->amount); ?></b></td>
                            <td><?= $results[0]->type_name; ?></td>
                        </tr>
                        
                            <tr>
                                <td colspan="5"></td>
                                <td colspan="3"><b><?php echo number_format($results[0]->amount); ?></b></td>
                            </tr>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
    </div>
    <label class="col-md-2 col-form-label">Update Attachment<span class="text-danger"></span></label>
    <button type="submit" id="savbill" class="btn btn-primary float-right">Update</button>
        <div id="fdbck"></div>
        </form>
        <form id="upldimage" enctype="multipart/form-data">
            <div class="responsed"></div>
            <div id="responsed"></div>
            <input type="file" name="uploadFiles[]" id="uploadFiles[]" multiple>
            <input type="hidden" name="transactionno" id="transactionno" value="<?=$bll[0]->trans_number; ?>">
            <button type="button" class="btn btn-outline-primary" onclick="UploadImage()">Upload</button>
            
        </form>
        </div>
             <?php  $Initiator= $billmodel->get_initiator_name($bll[0]->trans_number); ?>
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                <?php foreach($billattch as $transnumber ): ?>
                        <tr>
                    <th>file attached: </th>
                      <td>
                    <button type="button" class="btn btn-primary" onclick="displayImage('<?=$transnumber->image_attachment; ?>')">
                      View <?=$transnumber->image_attachment; ?>
                    </button>
                     <a href="javascript:void(0)" class="fa fa-trash btn btn-danger" onclick="DeleteAttachement('<?=$transnumber->id; ?>','<?=$transnumber->image_attachment; ?>')"></a>
                      </td>
                    
                   </tr> 
                <?php endforeach; ?> 
                </table>
            </div>
<!-----------------for msg------------------>
<div class="col-md-6">
            <div class="card msg">
             <div class="card-header">
                <h5>Message Information</h5>
            </div>
            <hr>
           <?php
            $msg_grp = $billmodel->get_item_name('message_groups_tbl',$where = array('message_type'=>13,'trans_number'=>$bll[0]->trans_number));
          $msg = "";
          $status='';
          $phone = "";
          if(count($msg_grp)>0){
              $m = $billmodel->get_item_name('messages',$where = array('send_no'=>$msg_grp[0]->send_number));
                       
                         if(count($m) > 0){
                            $msg = $m[0]->message;
                            $phone = $m[0]->phone_no;
                            $msg= str_replace(array("\r","\n"),' ',$msg);
                          if($m[0]->sent_status == 1) {
                           $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description;
                          }elseif($m[0]->sent_status == 2){
                            $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description." <br>Delivered Date: ".$m[0]->time_delivered;
                          }
                        }
                    }
             if($msg==""){
            $status="<span class='text-red'>Not Sent</span>";
         $msg = "Bill ".$bll[0]->trans_number." to ".$bll[0]->supplier_name." for ".number_format($results[0]->amount)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
                }

              // print_r($bll);
                   ?>
                
          
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <?php
                     if($phone !=""){
                    ?>
                <tr>
                        <th>Phone:</th>
                        <td id="phone"><?= $phone; ?> </td>
                    </tr>
                <?php }?>
                    <tr>
                        <th>Message:</th>
                        <td id="msg"><?= $msg; ?> </td>
                    </tr>
                    <tr>
                        <th>Status:</th>
                        <td id="msg"><?= $status; ?> </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <a href="javascript:void(0)" onclick="resendSMS('<?= $msg; ?>','13','<?= $bll[0]->trans_number; ?>','<?= $bll[0]->name_id; ?>')"  class="btn btn-primary "><i class="fa fa-rotate-left"></i> Resend SMS</a>
                        </td> 
                    </tr>

                </table>
            </div>
            </div>
        </div>
<!-----------------end for msg------------------>

</div> <!-- end tag for row -->

<script type="text/javascript">


function DeleteAttachement(image_id,image_attachment) {
     
        if (confirm('Are you sure?')) {
            var deleteattach = "attch_id=" + image_id + "&attch_name=" +image_attachment;
            //alert(deleteattach);
           // return;
            $.ajax({
                url: '<?php echo base_url() . '/index.php/BillController/removeattachment'; ?>',
                type: "POST",
                data: deleteattach,
                success: function (res) {
                    $('.responsed').html('<div class="alert alert-success">Document Deleted Successfully!</div>');

                    setTimeout(function(){
                        window.location.reload();
                    },1000);
                },
                error: function () {
                    alert('Fail to Delete Image attachment');
                }
            });
        }
    }

function UploadImage()
{
var formdata = new FormData($('#upldimage')[0]);
$.ajax({
    type:'POST',
    url:'<?= base_url('BillController/doUploadImage');  ?>',
    data:formdata,
    processData:false,
    contentType:false,
    success:function(response){
      var data = JSON.parse(response);
                if(data['status'] == "1"){
                    //alert(data['description']);
                     $('#responsed').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>' + data['description'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000);
                }else{
                    
                    $('#responsed').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['description'] + '</div>');
                }
            },
            error:function(response){
               
                $('#responsed').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldn\'t upload File.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                setTimeout(function(){
            //window.location.reload();
                },1000);
            }

});
}

var hold_selected_accounts = []; // hold all selected items
$(document).ready(function(){
      fetch_present_ledgers();
     //alert(hold_selected_accounts);
         $('#expnsledger').select2({
            ajax: {
                url: "<?= base_url('load_accounts'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

      $('#expnsledger').on('select2:select', function (e) {
            //selectedAccounts();
            });

            function selectedAccounts(){  
            var rows = '';
            var accountData = 'accounts_selected='+$('#expnsledger').val()+'&selected_accounts_array='+hold_selected_accounts;
           //alert(accountData);
           // return;
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_accountdata1')?>",   
                data:accountData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    } 
                   
                },
                error:function(data){
                    //alert(data);
                    alert("Oops Sorry! Something went wrong");
                }
                
           }); 

        }
   });

   //////////////// for income ledgers/////////////////////////
      $(document).ready(function(){
         $('#incmledger').select2({
            ajax: {
                url: "<?= base_url('load_payable'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

     });
 var account_ttl;
function fetch_present_ledgers(){
     account_ttl=0;
     $('#show_ledgers').empty();
    //alert($(this).serialize());
        var data = 'trans_id=' +<?= $bll[0]->trans_number ?>;
        //alert(data);
        //var incomelg = $('#payable-data-ajax').val();
       
        // var amnt =$('#amount').val()

  $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/BillController/fetch_expens_ldgrs'; ?>',
            success: function(response){
                console.log(response);
                var lData = JSON.parse(response);
                var len = lData.length;
                //alert(account_ttl);
                for(var i = 0; i < len; i++){
                    var ttl = lData[i]['ttl'];
                    account_ttl = account_ttl + parseInt(ttl);
                    
                    var aid = lData[i]['expense_id'];
                    var lid = lData[i]['id'];
                    var ledger_type = lData[i]['account_type_id'];
                    var descr = lData[i]['description'];
                    //var description = descr;
                     
                     //var qua='quantity'+aid+'';

                    //$('#total').val(amnt);

                    $('#show_ledgers').append('<tr id="row_'+ lData[i]['expense_id'] +'"><input type="hidden" name="ttl1" value="'+ttl+'">'+
                        '<td><div class="text-left"><input type="hidden" name="aid1[]" value="'+lData[i]['expense_id']+'">'+lData[i]['expense_id']+'</div></td>\
                        <td><div class="text-left">'+lData[i]['account_name']+'</div></td>\
                        <td><div class="text-left"><input type="hidden" name="description1'+lData[i]['expense_id']+'" value="'+descr+'">'+descr+'</div></td>\
                        <td><div class="text-center"><input type="hidden" name="ttl1'+lData[i]['expense_id']+'" value="'+ttl+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</div></td>\
                        <td><div class="text-left"><input type="hidden" name="payable_name1'+lData[i]['expense_id']+'" value="'+lData[i]['payable_id']+'">'+lData[i]['payable_name']+'</td>\
                        </div></td>\
                        <td>\
                            <div class="text-left"><a href="javascript:RemoveRowUpdate('+lid+','+account_ttl+');" class="btn btn-danger">x</a></div>\
                        </td>\
                    </tr>');
                }
            
            //accountledgers = {aid:aid, amount: ttl,description:desc};
            //billdetails.push(accountledgers);
            document.getElementById("totalamount").innerHTML = "Total = " + account_ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(account_ttl);
           // alert(account_ttl);
            return account_ttl;
            }
        });

   };

// it store the added data rows on update
$('#storeleger').click(function(evt){
   
     //$('#itemsbdy').empty();
    //alert($(this).serialize());
        var data = 'accountid=' + $('#expnsledger').val()+'&incomeid='+$('#incmledger').val();
        //alert(data);
        //var incomelg = $('#payable-data-ajax').val();
        var ttl =$('#amnt').val();
        var descr =$('#descript').val();
        // var amnt =$('#amount').val()

  $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/BillController/fetch_expense_ledgers'; ?>',
            success: function(response){
                console.log(response);
                var lData = JSON.parse(response);
                var len = lData.length;
                //alert(account_ttl);
                for(var i = 0; i < len; i++){
                    
                    account_ttl = account_ttl + parseInt(ttl);
                    
                    var aid = lData[i]['id'];
                    var ledger_type = lData[i]['account_type_id'];
                    //var description = descr;
                     
                     //var qua='quantity'+aid+'';

                    //$('#total').val(amnt);

                    $('#show_ledgers').append('<tr id="row_'+ lData[i]['id'] +'"><input type="hidden" name="ttl" value="'+ttl+'">'+'<input type="hidden" name="account_ttl" value="'+account_ttl+'">'+
                        '<td><div class="text-left"><input type="hidden" name="aid[]" value="'+lData[i]['id']+'">'+lData[i]['id']+'</div></td>\
                        <td><div class="text-left">'+lData[i]['account_name']+'</div></td>\
                        <td><div class="text-left"><input type="hidden" name="description'+lData[i]['id']+'" value="'+descr+'">'+descr+'</div></td>\
                        <td><div class="text-center"><input type="hidden" name="ttl'+lData[i]['id']+'" value="'+ttl+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</div></td>\
                        <td><div class="text-left"><input type="hidden" name="payable_name'+lData[i]['id']+'" value="'+lData[i]['payable_id']+'">'+lData[i]['payable_name']+'</td>\
                        </div></td>\
                        <td>\
                            <div class="text-left"><a href="javascript:RemoveRow('+lData[i]['id']+','+account_ttl+');" class="btn btn-danger">x</a></div>\
                        </td>\
                    </tr>');
                }
            
            //accountledgers = {aid:aid, amount: ttl,description:desc};
            //billdetails.push(accountledgers);
            document.getElementById("totalamount").innerHTML = "Total = " + account_ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(account_ttl);
           // alert(account_ttl);
            return account_ttl;
            }
        });


        evt.preventDefault();
   });

    //////////////// function to remove single row //////////////////////
   function RemoveRow(id,ttl){
         //alert(ttl);
         account_ttl=account_ttl - parseInt(ttl);
            document.getElementById("totalamount").innerHTML = "Total = " + account_ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(account_ttl);
           // return totalsum;
         $('#row_'+id).remove();         
    }

        function RemoveRowUpdate(lid,account_ttl){
       // var id = $(this).attr('data-id');
        //alert (account_ttl);
      
           swal({
            title: "Are you sure?",
            text: "You will not be able to recover this item!",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url('index.php/BillController/delete_expense_data')?>/'+lid+'/'+account_ttl,
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                  fetch_present_ledgers();
                    swal("Deleted!", "The bill is up to date already. You may close the bill..", "success");

                    
                 }
              });

            } else {
               swal("Cancelled");
            }

          });
       }

   
  $('#updatebill').submit(function(evt){
    // var form_data = new FormData($('#updatebill')[0]);
    //  alert(form_data); 
    //    return;
    var transa_id = 'transac_id=' +<?= $bll[0]->trans_number ?>;
    var descr =$('#descript').val();
      var form_data = $('#updatebill').serialize()+transa_id+descr; 
       //alert(form_data); 
        $.ajax({
            method: 'POST',
            url: 'updt_bill',
            data: form_data,
            success:function(res){
                var data = JSON.parse(res);
                if(data['status'] == "1"){
                    //alert(data['description']);
                     $('#fdbck').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>' + data['description'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000);
                }else{
                    
                    $('#fdbck').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['description'] + '</div>');
                }
            },
            error:function(res){
               
                $('#fdbck').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldn\'t Create Bill.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                setTimeout(function(){
            //window.location.reload();
                },1000);
            }
        });

        evt.preventDefault();
    
    });

   function resendSMS(msg,type,trno,billto){
        var message = escape(msg);
        var data = 'trno=' + trno+'&msg='+msg+'&type='+type+'&'+$("#header_form").serialize()+'&billto='+billto;
        // alert(data);
         var response=1;
          //alert(data);
         // return;
         swal({
            title: "Are you sure?",
            text: "To resend this message >"+msg,
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, resend!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },
          function(isConfirm) {
            if (isConfirm) {
               
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillController/resendApprovalSms'; ?>',
             data:data,
            success: function(res){
                //console.log(res)
                swal('success','Message sent successfully','success');
               
            },
             error:function(res){
               swal('error','Message not sent','error');
            }
        });
    }else{
        swal('Cancelled');
    }}
    );
    }
</script>