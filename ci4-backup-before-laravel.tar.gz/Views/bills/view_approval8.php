  <style type="text/css">

     .invoice > .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }
  

 </style>
 <?php
 helper('age');
  $billmodel = new App\Models\BillModel();
  $remodel =new App\Models\ReportsModel();
  $suppliermodel = new App\Models\SupplierModel();
  $leger_transaction = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>$inv[0]->trans_type_id));
  //print_r($leger_transaction);
  $supplier_name = "";
  $name_type = "";
  $ref="";
  $amount = 0;
  $phone="";

  if($leger_transaction[0]->name_type_id==1){
$suppl = $billmodel->get_item_name('students', $where = array('id'=>$leger_transaction[0]->name_id));
$student_parent = $billmodel->get_item_name('parents_students_tbl', $where = array('student_id'=>$leger_transaction[0]->name_id));
$parent=$billmodel->get_item_name('parents_tbl', $where = array('id'=>$student_parent[0]->parent_id));

$name = $suppl[0]->full_name;
$phone=$parent[0]->phone1;
  }else if($leger_transaction[0]->name_type_id==2){
$suppl = $billmodel->get_item_name('supplier_tbl', $where = array('supplier_id'=>$leger_transaction[0]->name_id));
$name = $suppl[0]->supplier_name;
  }else if($leger_transaction[0]->name_type_id == 7){
        $app = $billmodel->get_item_name('users',$where = array('user_id'=>$leger_transaction[0]->name_id));
        $name = $app[0]->first_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->user_id;
        $type_name = $billmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $phone=$app[0]->phone_no;
       
   }
  else{
$name="";
  }
  
  
  $name_type_id = $billmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
  $billref = $billmodel->get_item_name('transaction_other_details_tbl',$where = array('transaction_no'=>$inv[0]->trans_number));
    

     $rlt = $billmodel->get_item_name('voucher_relation_tbl', $where = array('payment_no' => $inv[0]->trans_number));
            
            $v_type = $billmodel->get_item_name('voucher_types_tbl', $where = array('id' => $rlt[0]->voucher_type));


 ?>
<div class="row">
<!-------------------- Bill Information starts here  ------------------>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Transfer Information</h5>
            </div>
            </hr>

            <div class="card-body">
                
                <input type="hidden" name="supplier_name" id="supplierid" value="<?= $inv[0]->trans_number;?>">
                <table class="table table-borderless">
                    <tr>
                        <th>Transfer No:</th>
                        <td><?= $inv[0]->trans_number; ?></td>
                    </tr>
                     
                    <tr>
                        <th>Transfer Date:</th>
                        <td><?= $inv[0]->trans_date; ?></td>
                    </tr>
                     <tr>
                        <th>Transfered by:</th>
                        <td><?= $name; ?></td>
                    </tr>
                    <tr>
                        <th>Name Type:</th>
                        <td><?= $name_type_id[0]->name_type; ?></td>
                    </tr> 
                    
                    <tr>
                        <th> Phone no:</th>
                        <td><?= $phone??""; ?></td>
                    </tr>
                   
                </table>
            </div>
    </div>
</div>
 <!-------------------- Payment History starts here  ------------------>

    <?php
   // $databaseName=session()->get('school');
     $dbname=session()->get('db_name');
    $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;
                        $query = $db->query('SELECT item_transation_tbl.item_id,item_name,account_name,trans_number,quantity,unit_price FROM item_transation_tbl,items_tbl,items_ledgers_tbl,accounts_tbl where item_transation_tbl.item_id = items_tbl.id AND items_ledgers_tbl.item_id = items_tbl.id AND item_transation_tbl.trans_type = 4 AND accounts_tbl.id = items_ledgers_tbl.account_id AND trans_number='.$inv[0]->trans_number);
                        $result = $query->getResult();

                        foreach($result as $itm){
                            $dat = $billmodel->get_trans_type($inv[0]->trans_number);
                             $query2 = $db->query('SELECT type_name,amount FROM ledger_transaction_tbl,account_types_tbl where ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_transaction_tbl.trans_type = 4 AND (ledger_type = 10) AND trans_no='.$inv[0]->trans_number);
                             $result2 = $query2->getResult();
                             $amount = $itm->amount;
                           
                            $total += $amount;
                             }
          ?>
     <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Related Transactions</h5>
            </div>
            </hr>

            <div class="card-body">

                 <!-- image attachment pop up -->
      <div class="cust_popup_lg" id="Attchmnt2" style="display:none">
                    <a href="javascript:void(0)" class="pull-left" onclick="CloseAttachmnt2()"><i class="fa fa-times"></i></a>
                  <div id="ViewAttachment" class=""></div>
                    <br>                   
                    <!-- <a href="javascript:void(0)" class="btn btn-danger btn-xs pull-right" onclick="DeleteAttachmnt()">Delete</a> -->
                </div>
                <table class="table" id="paytable">
                    <thead>
                                <tr>
                                    
                                    <th>Trans Type</th>
                                    <th>Trans No</th>
                                   <th class="">Date</th>
                                    <th>Amount</th>
                                    <th>Trans by</th>
                                    <th width="100px">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                          <?php
                          $receipt=array();
                          $pocketMoney = $billmodel->get_item_name('pocket_money_transaction_tbl',$where = array('transaction_no' =>$inv[0]->trans_number,)); 
                           $v_transaction = $billmodel->get_item_name('voucher_relation_tbl',$where = array('payment_no' =>$inv[0]->trans_number)); 
                          if(count($pocketMoney)>0){
                             echo "<tr><td></td>
                             <td colspan='3'>No related transactions</td></tr>";
                             }else if($v_transaction[0]->trans_type==0){
                                  echo "<tr><td></td>
                             <td colspan='3'>No related transactions</td></tr>";
                             }else if($inv[0]->trans_type_id==8){
                                  echo "<tr><td></td>
                             <td colspan='3'>No related transactions</td></tr>";
                             }
                             else{
                          
                         //print_r($v_transaction);
                          
                          if($v_transaction[0]->trans_type==2){

                         $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type,'ledger_id'=>$leger_transaction[0]->ledger_id));

                          $receipt = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type,'ledger_type'=>9));

                         if($leger_transaction[0]->ledger_id==21){
                        $trans_type="Overpayment";
                         }else{
                         $trans_type="Receipt";
                         $receipt=array();
                         }
                        
                         $trans_type2="Receipt";
                        

                          }else{
                          $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type)); 
                          $traType = $billmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>$v_transaction[0]->trans_type));  
                          $trans_type=$traType[0]->type_name;
                             }

                        $transNumber = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$v_transaction[0]->trans_no,'trans_type_id'=>$v_transaction[0]->trans_type));
                        $traBy = $billmodel->get_item_name('users',$where = array('user_id' =>$transNumber[0]->updated_by));
                           
                           ?>
                            <tr>
                                <td><?=$trans_type??""?></td>
                                <td><?=$v_transaction[0]->trans_no??""?></td>
                                 <td><?=date('Y-m-d',strtotime($transNumber[0]->trans_date))??""?></td>
                            <td class="text-right"><?=number_format($bala_amount[0]->amount)??""?></td>
                            <td><?=$traBy[0]->first_name." ".$traBy[0]->last_name??""?></td>
                            <td class="text-left">
                                <?php
                               if($v_transaction[0]->trans_type==2){
                                ?>
                              <button type="button" class="btn btn-primary btn-sm"  onclick="manage_receipt('<?=$transNumber[0]->id;?>')"><i class="fa fa-eye"></i> </button> 
                                 <?php
                               }else if($v_transaction[0]->trans_type==4){

                          $billattch = $billmodel->get_item_name('transaction_attachments_tbl',$where = array('transaction_number'=>$v_transaction[0]->trans_no));
                                ?>
                             <button type="button" class="btn btn-primary btn-sm"  onclick="manage_bill('<?=$inv[0]->id;?>')"><i class="fa fa-eye"></i> </button>
                             <?php
                             if(count($billattch)>0){
                             ?>
                          <button type="button" class="btn btn-primary btn-sm"  onclick="view_attachement('<?=$billattch[0]->image_attachment;?>')"><i class="fa fa-arrow-up"></i> </button>
                               <?php
                           }
                                  }
                               else{
                                ?>
                                <button type="button" class="btn btn-primary btn-sm"  onclick="manage_credit('<?=$transNumber[0]->trans_number;?>')"><i class="fa fa-eye"></i> </button>
                            <?php } ?>
                            </td>
                            </tr>
                            <?php 
                           if(count($receipt)>0){
                            ?>
                      <tr>
                                <td><?=$trans_type2??""?></td>
                                <td><?=$receipt[0]->trans_no??""?></td>
                                <td><?=date('Y-m-d',strtotime($transNumber[0]->trans_date))??""?></td>
                            <td class="text-right"><?=number_format($receipt[0]->amount)??""?></td>
                            <td><?=$traBy[0]->first_name." ".$traBy[0]->last_name??""?></td>
                            <td>
                                <button type="button" class="btn btn-primary btn-sm"  onclick="manage_receipt('<?=$transNumber[0]->id;?>')"><i class="fa fa-eye"></i> </button>
                            </td>
                            </tr>
                            <?php
                           }
                       }
                            ?>
                           
                        </tbody>
                </table>
             </div>
     </div>
 </div>
</div>
</div>

<!-------------------- Charged Items starts here --------------------->
<div class="row">
    <div class="col-md-12">
        <div class="card  invoice">
            <div class="card-header">
                <h5>Payment Details</h5>
                
            </div>
            </hr>

            <div class="card-body">
                <table class="table">
                    <thead>
                        
                        <tr>
                          
                            <th>Trans Type</th>
                             
                            <th>Trans Date</th>
                            <th class="">Trans No</th>
                           <th class="text-center">Amount</th>
                            
                            <th>From</th>
                            <th>To</th>
                             <th>initiated by</th>
                            <th></th>
                        </tr>
                       
                    </thead>
                    <tbody id="">
                        <?php
                       // $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;
                        $type = $billmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>$inv[0]->trans_type_id,));
                        $trans_type=$type[0]->type_name;

                        $lgt = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_type' =>$inv[0]->trans_type_id,'trans_no'=>$inv[0]->trans_number));

                         $from= $billmodel->get_item_name('accounts_tbl',$where = array('id' =>$lgt[0]->ledger_id,));
                         $to= $billmodel->get_item_name('accounts_tbl',$where = array('id' =>$lgt[1]->ledger_id,));
                          $user= $billmodel->get_item_name('users',$where = array('user_id' =>$inv[0]->updated_by,));
                         
                         ?>
                         <tr>
                            
                             <td><?=$trans_type?? ""; ?></td>
                             
                             <td><?= $inv[0]->trans_date??""; ?></td>
                             <td class=""><?= $inv[0]->trans_number??""; ?></td>
                         <td><?= number_format($lgt[0]->amount)??""; ?></td>
                            <td><?= $from[0]->account_name??""; ?></td>
                            <td><?= $to[0]->account_name??""; ?></td>
                            <td><?= $user[0]->first_name.' '.$user[0]->last_name??""; ?></td>

                         </tr>
                     <?php 
                        
                     ?>
                    </tbody>
                </table>

            </div>

        </div>

        <!--------$name="AUGUST MARTIN NJAU";---------- here payment information 
           
starts---->
        <?php $bill = $billmodel->billdata($inv[0]->trans_number,$inv[0]->trans_type_id); ?>
        <?php  $Initiator= $billmodel->get_initiator_name($bill[0]->app_id); ?>
        <div class="row">
        <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Approval History</h5>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               
                <label>Approval Status:</label>
                <?php 
                //$id_trans = $inv[0]->trans_number;
                $checker = 0;
               foreach($Initiator as $dat){
                if($dat->user_role =='3' && $dat->hstatus=='1')
                {
                    $checker =1;
                }
                elseif($dat->user_role =='3' && $dat->hstatus=='2'){
                    $checker =2;
                }
               }
                if($checker ==1)
                {
                     echo  '<label style="color:green;">  &nbsp;&nbsp; <strong>Approved! </strong></label>';
                 }
                 elseif($checker ==2){
                     echo  '<label style="color:red;">  &nbsp;&nbsp; Rejected! </label>';
                 }
                 else{
                echo'<label style="color:red;">  &nbsp;&nbsp; Pending! </label>';
                 }

                
                 ?>
                <div id="feedback"></div>
            </div>
            </hr>
        
     <?php $hist_data = $billmodel->getdatabill($bill[0]->app_id); ?>
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Entry Date:</th>
                        <th>Comment:</th>
                        <th>Name:</th>
                        <th>User Role:</th>
                        <!-- <th>Status:</th> -->
                    </tr>
                    <?php foreach($hist_data as $in): ?>
                    <tr>
                        <td><strong><?=$in->hist_date; ?></strong></td>
                        <td class="text-primary"><?= $in->comment; ?></td>
                        <td>
                            <?= $in->first_name.' '.$in->last_name; ?>
                        </td>
                        <td><?php if($in->user_role == '1'){
                            echo "Initiator";
                        }elseif($in->user_role == '2'){
                            echo "Checker";
                        }elseif($in->user_role == '3'){
                            echo "Approver";
                        }else{

                        } ?></td>
                        <td></td>
                    </tr>
                       <?php endforeach; ?>
                </table>
            </div>
        </div>
    </div>

        <!------------------ here accounts receivable ------------------->
        <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Effected ledgers</h5>
            </div>
            </hr>
           <div class="card-body">
                <table class="table" style="border:1px solid black;">
                   <tr style="border:1px solid black;">
                       <th style="border:1px solid black;">Ledger name</th>
                       <th style="border:1px solid black;">Debit</th>
                       <th style="border:1px solid black;">Credit</th>
                   </tr>
                    <tbody style="border:1px solid black;">
                        <?php 
                          
                    $ledger1 = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>8,'transation_nature'=>2));
                    $ledger2 = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>8,'transation_nature'=>1));
                    $ledger11=$billmodel->get_item_name('accounts_tbl',$where = array('id' =>$ledger1[0]->ledger_id));

                    $ledger22=$billmodel->get_item_name('accounts_tbl',$where = array('id' =>$ledger2[0]->ledger_id));
                        ?>
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;"><?=$ledger11[0]->account_name??""?></td>  
                          <td class="text-right" style="border:1px solid black;"><?=number_format($ledger1[0]->amount)??""?></td>  
                          <td style="border:1px solid black;"><?=""?></td>  
                        </tr>
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;"><?=$ledger22[0]->account_name??""?></td> 
                          <td style="border:1px solid black;"><?=""?></td>   
                          <td class="text-right" style="border:1px solid black;"><?=number_format($ledger2[0]->amount)??""?></td>  
                          
                        </tr>
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;">Total</td> 
                          <td class="text-right" style="border:1px solid black;"><?=number_format($ledger1[0]->amount)??""?></td>   
                          <td class="text-right" style="border:1px solid black;"><?=number_format($ledger2[0]->amount)??""?></td>  
                          
                        </tr>

                        
                    </tbody>
                </table>

            </div>
        </div>
</div>
</div>
</div>
<!----------------------------- supporting documents --------------------------->
<div class="row">
 <div class="col-md-6">
        <div class="card invoice">
            
        </div>
    </div>
</div>
<div class="row">
    <?php if($vocher!=1){?>
<div class="col-md-12">
   
    <button type="button" class="btn btn-success  float-right ml-3 ApprovalId" data-id="<?= $inv[0]->trans_number; ?>">Approve</button>
    <button type="button" class="btn btn-warning  float-right RejectId" data-id="<?= $inv[0]->trans_number; ?>">Reject</button>
  

</div>
  <?php }?>

</div>
<!-----------------for msg------------------>
<div class="col-md-6">
            <div class="card msg">
             <div class="card-header">
                <h5>Message Information</h5>
            </div>
            <hr>
           <?php
           $paid = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>5,'transation_nature'=>2));
           $bll=$inv;
            $msg_grp = $billmodel->get_item_name('message_groups_tbl',$where = array('message_type'=>14,'trans_number'=>$bll[0]->trans_number));
          $msg = "";
          $status='';
          if(count($msg_grp)>0){
              $m = $billmodel->get_item_name('messages',$where = array('send_no'=>$msg_grp[0]->send_number));
                       
                         if(count($m) > 0){
                            $msg = $m[0]->message;
                            $msg= str_replace(array("\r","\n"),' ',$msg);
                          if($m[0]->sent_status == 1) {
                           $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description;
                          }elseif($m[0]->sent_status == 2){
                            $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description." <br>Delivered Date: ".$m[0]->time_delivered;
                          }
                        }
                    }
             if($msg==""){
            $status="<span class='text-red'>Not Sent</span>";
         $msg = "Voucher ".$bll[0]->trans_number." to ".$name." for ".number_format($paid[0]->amount)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
                }

              // print_r($bll);
                   ?>
                
          
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Message:</th>
                        <td id="msg"><?= $msg; ?> </td>
                    </tr>
                    <tr>
                        <th>Status:</th>
                        <td id="msg"><?= $status; ?> </td>
                    </tr>
                    

                </table>
            </div>
            </div>
        </div>
<!-----------------end for msg------------------>

  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Add Comment</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <!-- <div id="Viewrejected"></div> -->
          <form class="form-group" id="RejectComment">
              <div class="form-group">
                  <textarea class="form-control" name="comment" id="comment">
                      
                  </textarea>
              </div>
              <button type="button" class="btn btn-primary" id="savecomment">Submit</button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="viewreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="close_rept()">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('viewreceipt_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
<!-- ------manage invoice modal------- -->
<div class="modal fade" id="viewinvoice" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"  style="z-index: 1400;">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5>Credit Note Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewinvoice_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printJS('invoicePrint_content', 'html')"><i class="fa fa-print"></i> Print</button> -->
        <!-- <button type="button" class="btn btn-primary"  data-toggle="modal" data-target="#invoiceprint" onclick="invoice_print()"><i class="fa fa-print"></i> Print</button> -->
        <button type="button" class="btn btn-primary"  data-toggle="modal" onclick="invoice_print()"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="view_voucher" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" onclick="close_printout()"aria-label="Close"></button>
      </div>
      <div class="modal-body" id="voucher_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="close_printout()">Close</button>
          <button type="button" class="btn btn-primary" onclick="printable_voucher2('voucher_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>

   <script type="text/javascript">
    var transId='<?php echo $inv[0]->id;?>';
 $('#voucher_content').load('<?= base_url('/index.php/BillController/view_voucher')?>/'+transId);
 function close_printout(){
    $('#view_voucher').modal('hide');
 }
 function manage_bill(inv){
        //alert(inv);
      $('#viewreceipt').modal('show');
       $('#viewreceipt_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      $('#viewreceipt_content').load('<?= base_url('/index.php/BillController/view_voucher')?>/'+inv);
    }

    function manage_receipt(inv){
        //alert(inv);
      $('#viewreceipt').modal('show');
       $('#viewreceipt_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      $('#viewreceipt_content').load('<?= base_url('/view_receipt')?>/'+inv);
    }

    function manage_credit(inv){
        //alert(inv);
         $('#viewreceipt').modal('show');
       $('#viewreceipt_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      $('#viewreceipt_content').load('<?= base_url('/print_note')?>/'+inv);
      // $('#viewinvoice').modal('show'); 
      //  $('#viewinvoice_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      // $('#viewinvoice_content').load('<?= base_url('/view_note')?>/'+inv);
    }

    function CloseAttachmnt2() {
        $('#Attchmnt2').hide(100);
       
    }
       function displayImage(image_attachment)
       {
         $('#Attchmnt2').show(100);
        $('#ViewAttachment').html('<iframe src="<?php echo base_url() . '../public/transaction_files/'; ?>' + image_attachment + '" style="width:100%;height:500px"></iframe>');
                
       }
       //////////////////// for approved bill response ///////////////////////

       $(".ApprovalId").click(function(){
          var type='<?php echo $inv[0]->trans_type_id;?>';
        var data = "trans_number="+$(this).attr('data-id')+'&type='+type;
       // alert(data);
        $.ajax({
           
            type:"GET",
            url:"<?= base_url('/send_approved_data')?>",
            data:data,

            success: function (res){
                $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Congratulations!</strong> Bill Approved Successfully<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                  setTimeout(function(){
                        window.location.reload();
                    },1000)
               
            },
            error:function () {
                $('#feedback').html('<div class="alert alert-danger">Error! Couldn\'t Save data.</div>');
            }
        });
       });

       /////////////////// for rejected bill response ////////////////////////////
       $(".RejectId").click(function(){ 
         $('#myModal').modal('show');
        var type='<?php echo $inv[0]->trans_type_id;?>';
        var dat = "trans_number="+$(this).attr('data-id')+'&type='+type;
        //alert(data);
        $('#savecomment').click(function(){
        var data = "comment="+$('#comment').val()+"&"+dat;
            //alert(data);
      
         $.ajax({

            type:"GET",
            url:"<?= base_url('/send_rejected') ?>",
            data:data,
            success: function(res){
                 $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Congratulations! Bill Rejected Successfully</strong></div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                 
            },
            error: function ()
           {
            $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldn\'t Reject Bill.</strong></div>');
                // setTimeout(function(){
                // window.location.reload();
                // },1000)
            }
  });
         });
       });

 function CloseAttachmnt2() {
        $('#Attchmnt2').hide(100);
       
    }
       function view_attachement(image_attachment)
       {
       // alert(2);
         $('#Attchmnt2').show(100);
        $('#ViewAttachment').html('<iframe src="<?php echo base_url() . '../public/transaction_files/'; ?>' + image_attachment + '" style="width:100%;height:500px"></iframe>');
                
       }
   </script>

    
    

