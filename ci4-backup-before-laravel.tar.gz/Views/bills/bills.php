<link rel="stylesheet" href="<?php echo base_url('public/assets/plugins/select2/select2.css');?>"/>
<style type="text/css">
    tr:hover {
cursor: pointer;

}

            .preview-container {
            display: flex;
            flex-wrap: wrap;
        }

        .preview-image {
            width: 100px;
            height: 100px;
            margin: 5px;
            position: relative;
        }

        .remove-button {
            position: absolute;
            top: 0;
            right: 0;
            cursor: pointer;
            background-color: red;
            color: white;
            padding: 3px;
            border-radius: 50%;
            display: none;
        }

        .preview-image:hover .remove-button {
            display: block;
        }
 
</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Bill</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                $bmodel = new App\Models\BillingModel();
                   $amodel = new App\Models\AdmissionModel();
                $pj = $amodel->get_student_details('projects_tbl', $where = array('status' => 1));
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Bill</li>
                </ol>
            </div>
            <div id="largeScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#bills-all">Bills List</a></li>
                 <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#bill-add">New Bill</a></li>
            </ul>
            </div>
            
             <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#bills-all">Bills List</a></li>
                <li></li><li></li>
                  <li class="nav-item d-none d-sm-block"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#bill-add">New Bill</a></li>
            </ul>
             </div>
           
        </div>
    </div>
</div>

<div class="section-body mt-4">
        <div class="container-fluid">
            <div class="tab-content">

         <div class="tab-pane active" id="bills-all">
               <div class="d-flex justify-content-center">
                <div id="messageDisplayArea"></div>
                    <form id="BillResult" class="form-inline">
                         Bill date:
                         <div class="input-group ms-3 me-3">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                           <div class="me-3">
                             Approval status: 
                            <select class="form-control form-select" name="approval" id="approval">
                                <option value="4">All</option>
                                <?php 
                                $billmodel = new App\Models\BillModel();
                                // $this->billmodel = new BillModel;
                                $sts = $billmodel->get_appr_status();
                                 ?>
                                 <?php foreach($sts as $st){ ?>
                                    <option value="<?=$st->id; ?>"><?= $st->status_name; ?></option>
                                 <?php }?>
                             
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="bill"></div>
                </center>
            </div>


            <div class="tab-pane" id="bill-add">
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="card card-lg">
                            <div class="card-header"  style="height:5px">
                                <h3 class="card-title">Bills Details</h3>
                                <div class="card-options ">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                                <hr>
                    <div class="card-body">
                    <form class="form-horizontal" id="billbtn" enctype="multipart/form-data">
                         <div id="feedback"></div>
                         <div class="row">
                            <div class="col-md-6">
                                 <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Bill Type</label>
                                            <div class="col-sm-8">
                                              <?php
                                                 $cty= $bmodel->get_table_details('invoice_types_tbl');
                                                  ?>
                                                <select class="form-control" name="bill_type" id="bill_type">
                                                    <option value="3">General</option>
                                                    <?php foreach($cty as $type): ?>
                                                    <option value="<?= $type->id ?>"><?= $type->type_name; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                          </div>

                                 <div class="form-group row" id="showProject" style="display:none">
                                <label class="col-md-4 col-form-label">Projects<span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <select name="project" id="project" class="form-control" required="required">
                                        <option value="0">-Select project-</option>
                                        <?php foreach ($pj as $ac): ?>
                                            <option value="<?= $ac->id; ?>"><?= $ac->project_name; ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                            </div>
                             <div class="form-group row">
                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Bill Date</label>
                                <div class="col-sm-8">
                                <input type="date" id="bill_date" name="bill_date" value="<?php echo date('Y-m-d');?>" class="form-control" required>
                                </div>
                                </div>

                                     <div class="form-group row">
                                    <label for="inputpaidBy" class="col-sm-4 col-form-label">Bill Ref No</label>
                                <div class="col-sm-8">
                                <input type="text" id="billNo" name="bill_no" class="form-control" required>
                              </div>
                                </div>

                    <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Due Date</label>
                    <div class="col-sm-8">
                        <input type="date" id="due_date" name="due_date" value="<?php echo date('Y-m-d');?>" class="form-control" required>
                    </div>
                    </div>

                    <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Bill To<span class="text-danger">*</span></label>
                    <div class="col-sm-8">
                    <select name="billto" class="form-select form-control" id="load_suppl" style="width:100%;height: 15px;"></select>
                    </div>
                    </div>
                     <div class="form-group row" id="payer_name_row" style="display: none;">
                     <label  class="col-sm-4 col-form-label">Name<span class="text-danger">*</span></label>
                                         
                     </div>
                    <div id="payer_details"></div>
            <div id="customer_details"></div>
            </div>   
                                   
        </div>
  
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<lable>Expense </lable> <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-9">
                        <div class="card" style="width:750px;">
                            <p Class=" d-flex justify-content-center mt-3">EXPENSE LIST</p>

                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Expense Leger<span class="text-danger">*</span></label>
                            <div class="col-md-3">
                            <select name="expenseledger" class="form-select form-control" id="expenseledger" style="width:100%;height: 15px;"></select>
                           </div>

                            <label class="col-md-2 col-form-label">Description<span class="text-danger">*</span></label>
                            <div class="col-md-4">
                            <input type="text" name="description" id="description" required class="form-control">
                           </div>
                       </div>
                       <div class="form-group row">
                            <label class="col-md-2 col-form-label">Amount<span class="text-danger">*</span></label>
                            <div class="col-md-3">
                            <input type="text" name="amount" id="amount" required class="form-control">
                           </div>

                              <label class="col-md-2 col-form-label">Budget Leger<span class="text-danger">*</span></label>
                                <div class="col-md-4">
                                <select name="incomeledger" class="form-select form-control" id="incomeledger" required style="width:100%;height: 15px;"></select>
                                </div>

                            <div class="col-md-1">
                            <button type="button" class="btn btn-primary" id="saveleger"><i class="fa fa-plus"></i></button>
                            </div>
                        </div> 


                <table class="table table-hover table-vcenter mb-0 text-nowrap" style="">
                <thead>
                    <tr>
                        
                        <th>#Bill No</th>
                        <th>Charged Leger</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>Bill Description</th>
                        <th>AMount</th>
                        <th>Budget Leger</th>                        
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody id="show_ledger" style="">
                
                </tbody>
                <tr>
                    <td></td> 
                    <td></td> 
                    <td></td> 
                    <td colspan="3"></td>
                    
                    <td id="totalsum0" style="font-size: 18px;"></td>
                 </tr>
                    </table>
           </div>
            </div>
                        </div><br>

                    <!-- Here starts the form for accounts payable  -->

                         <div class="form-group row" style="margin-left: 20px;">
                            <label class="col-md-2 col-form-label">Accounts Payable<span class="text-danger">*</span></label>
                            <div class="col-md-4">
                            <select name="acc_payable" class="form-select form-control" id="acc_payable" style="width:100%;height: 15px;"></select>
                           </div>

                            <label class="col-md-2 col-form-label">Bill description<span class="text-danger">*</span></label>
                            <div class="col-md-4">
                            <input type="text" name="descr0" id="descr0" required class="form-control">
                           </div>
                           <!-- pdf file here starts -->

                
                            <label class="col-md-2 col-form-label">Attach File<span class="text-danger"></span></label>
                            <div class="col-md-4" style="padding-top:10px;">

                            <input type="file" id="imageinput" name="uploadFiles[]" class="form-control" multiple accept=".pdf, .doc, .xls, .docx, .xlsx, .jpg, .jpeg, .png"  onchange="previewFile(event)" >
                           </div>
                       


                            <label class="col-md-2 col-form-label">Approval Comment<span class="text-danger">*</span></label>
                            <div class="col-md-4 mt-3">
                            <input type="text" name="bill_comment" id="bllcmt" value="Please Approve!" required class="form-control">
                           </div>
                               
                            <div class="preview-container" id="previewContainer"></div>

                           </div>

                            <div id="file-preview-container" onclick="removeattachment()">
                           </div>
                        <!-- Here it ends the payable accounts --> 
                         <div class="form-group row">
                            <div class="col-md-8">
                                <button type="submit" id="create_bill" class="btn btn-primary float-right">Create</button>
                            </div>
                        </div>
                        </form>
                            </div>
                        </div>
                        
                    </div>
                </div>
            
            </div>

             <div class="tab-pane" id="bills-all">
                <div class="card">
                  
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>

  <!-- Modal to View All Customer Information -->

  <div class="modal fade" id="myviewModal" role="dialog">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Bill Information</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Viewbill"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <!-- Modal to update Customer Information-->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Edit Bill Information</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Updtebill"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
<script src="<?php echo base_url('public/assets/plugins/select2/select2.js')?>"></script><script type="text/javascript">


    document.addEventListener('DOMContentLoaded', function () {
        const imageInput = document.getElementById('imageinput');
        const previewContainer = document.getElementById('previewContainer');
        const uploadedFiles = [];

        imageInput.addEventListener('change', function (event) {
            previewContainer.innerHTML = ''; // Clear previous previews
            uploadedFiles.length = 0; // Clear the array

            const files = event.target.files;

            for (const file of files) {
                const reader = new FileReader();

                reader.onload = function (e) {
                    const previewImage = document.createElement('div');
                    previewImage.className = 'preview-image';

                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.alt = 'Image Preview';
                    img.style.width = '100%';
                    img.style.height = '100%';

                    const removeButton = document.createElement('div');
                    removeButton.className = 'remove-button';
                    removeButton.innerHTML = 'X';

                    removeButton.addEventListener('click', function () {
                        previewContainer.removeChild(previewImage);
                        
                        // Remove the corresponding file from the array
                        const index = uploadedFiles.indexOf(file);
                        if (index !== -1) {
                            uploadedFiles.splice(index, 1);
                        }
                    });

                    previewImage.appendChild(img);
                    previewImage.appendChild(removeButton);
                    previewContainer.appendChild(previewImage);

                    // Add the file to the array
                    uploadedFiles.push(file);
                };

                reader.readAsDataURL(file);
            }
        });

        // Add the array of files to the FormData object when submitting the form
        document.getElementById('uploadForm').addEventListener('submit', function (event) {
            const formData = new FormData(this);

            for (const file of uploadedFiles) {
                formData.append('images[]', file);
            }

            // Now you can submit the form with the updated FormData
            // (e.g., using fetch or XMLHttpRequest)
            
            // Uncomment the following line to prevent the default form submission
            // event.preventDefault();
        });
    });



function isImageFile(file) {
    // Check if the file type is an image
    return file.type.startsWith('image/jpeg/jpg/png/gif');
}

   ///////////////////here load expense ledgers starts here///////////////
    var hold_selected_accounts = []; // hold all selected items
   $(document).ready(function(){
        // fetch_data();
    //alert(hold_selected_accounts);
         $('#expenseledger').select2({
            ajax: {
                url: "<?= base_url('load_accounts'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

           $('#expenseledger').on('select2:select', function (e) {
            selectedAccounts();
            });

        function selectedAccounts(){  
            var rows = '';
           var accountData = 'accounts_selected='+$('#expenseledger').val()+'&selected_accounts_array='+hold_selected_accounts;
           //alert(accountData);
           // return;
           $.ajax({  
                method:"POST", 
                url:"<?= base_url('/load_accountdata1')?>",   
                data:accountData,
                dataType: "json",  
                success:function(data){ 
                    if(data == 1){
                        alert('The Item Already Selected');
                    } 
                   
                },
                error:function(data){
                    // alert(data);
                    alert("Oops Sorry! Something went wrong");
                }
                
           }); 

        }
          });



  function RemoveSelectItemRow(id,v){
        for( var i = 0; i < hold_selected_accounts.length; i++){ 
    
            if ( hold_selected_accounts[i] == id) {                 
                hold_selected_accounts.splice(i, 1); 
            }
        }
        //alert(sumVal);
        var k=v+1;
        var table = document.getElementById("table");
        var data=parseInt(table.rows[k].cells[5].innerHTML);
         //var col1=currentRow.find("td:eq(7)").text();
        
        $('#table_row'+id).remove();
    }
    ///////////////////######## Here is For Budget Ledger ##############//////////////////
        $(document).ready(function(){
         $('#incomeledger').select2({
            ajax: {
                url: "<?= base_url('load_payable'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });

     });

var account_ttl=0; 
$('#saveleger').click(function(evt){
     //$('#itemsbdy').empty();
    //alert($(this).serialize());
        var data = 'accountid=' + $('#expenseledger').val()+'&incomeid='+$('#incomeledger').val();
        //alert(data);
        //var incomelg = $('#payable-data-ajax').val();
        var ttl =$('#amount').val();
        var descr =$('#description').val();
        // var amnt =$('#amount').val()

  $.ajax({
            type: 'GET',
            data: data,
            url: '<?php echo base_url() . '/index.php/BillController/fetch_expense_ledgers'; ?>',
            success: function(response){
                console.log(response);
                var lData = JSON.parse(response);
                var len = lData.length;
                //alert(account_ttl);
                for(var i = 0; i < len; i++){
                    
                    account_ttl = account_ttl + parseInt(ttl);
                    
                    var aid = lData[i]['id'];
                    var ledger_type = lData[i]['account_type_id'];
                    //var description = descr;
                     
                     //var qua='quantity'+aid+'';

                    //$('#total').val(amnt);

                    $('#show_ledger').append('<tr id="row_'+ lData[i]['id'] +'"><input type="hidden" name="ttl" value="'+ttl+'">'+
                        '<td><div class="text-left"><input type="hidden" name="aid[]" value="'+lData[i]['id']+'">'+lData[i]['id']+'</div></td>\
                        <td><div class="text-left">'+lData[i]['account_name']+'</div></td>\
                        <td><input type="hidden" name="type_name'+lData[i]['id']+'" value="'+$('#expenseledger').val()+'"></td>\
                        <td><input type="hidden" name="incmeledger'+lData[i]['id']+'" value="'+$('#incomeledger').val()+'"></td>\
                        <td></td>\
                        <td><div class="text-left"><input type="hidden" name="description'+lData[i]['id']+'" value="'+descr+'">'+descr+'</div></td>\
                        <td><div class="text-center"><input type="hidden" name="ttl'+lData[i]['id']+'" value="'+ttl+'">'+ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')+'</div></td>\
                        <td><div class="text-left"><input type="hidden" name="payable_name'+lData[i]['id']+'" value="'+lData[i]['payable_id']+'">'+lData[i]['payable_name']+'</td>\
                        </div></td>\
                        <td>\
                            <div class="text-left"><a href="javascript:RemoveRow('+lData[i]['id']+','+ttl+');" class="btn btn-danger">x</a></div>\
                        </td>\
                    </tr>');
                }
            
            //accountledgers = {aid:aid, amount: ttl,description:desc};
            //billdetails.push(accountledgers);
            document.getElementById("totalsum0").innerHTML = "Total = " + account_ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(account_ttl);
           // alert(account_ttl);
            return account_ttl;
            }
        });


        evt.preventDefault();
   });

    ////////////////// function to remove single row //////////////////////
   function RemoveRow(id,ttl){
         //alert(ttl);
         account_ttl=account_ttl - parseInt(ttl);
            document.getElementById("totalsum0").innerHTML = "Total = " + account_ttl.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            console.log(account_ttl);
           // return totalsum;
         $('#row_'+id).remove();         
    }

    //function to load the payable accounts
     $(document).ready(function(){
        // fetch_data();
         $('#acc_payable').select2({
            ajax: {
                url: "<?= base_url('load_acc_payable'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });
     });

     /////////////// function to save all the Bill Details ///////////////

      $('#billbtn').submit(function(e){ 
        //alert($(this).serialize()+'&'+$("#header_form").serialize()+'&account_payable='+$("#acc_payable").val()+'&payable_name='+'payable_name');
        //$(this).serialize()+'&'+$("#header_form").serialize()+'&account_payable='+$("#acc_payable").val()
        // alert($('#billbtn').serialize());
        // return;
        var form_data = new FormData($('#billbtn')[0]);
        var headerform = $("#header_form").serializeArray();
        $.each(headerform,function(index,field){
            form_data.append(field.name,field.value);
        });
        form_data.append('account_payable',$("#acc_payable").val());
        form_data.append('bill_no',$("#billNo").val());
        form_data.append('due_date',$("#due_date").val());
        
        $.ajax({
            method: 'POST',
            url: 'save_bill',
            data: form_data,
            contentType: false,
            processData: false,
            success:function(res){
                 $('#create_bill').prop("disabled", true);
                var data = JSON.parse(res);
                if(data['status'] == "1"){
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['description'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#create_bill').prop("disabled", false);
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['description'] + '</div>');
                }
            },
            error:function(res){
                $('#create_bill').prop("disabled", false);
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldn\'t Create Bill.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                setTimeout(function(){
            //window.location.reload();
                },1000)
            }
        });

        e.preventDefault();
    
    });
      ////////////// function to load bill to supplier ///////////////
        $(document).ready(function(){
        // fetch_data();
         $('#load_suppl').select2({
            ajax: {
                url: "<?= base_url('load_supplier'); ?>",
                type: "POST",
                //delay: 250,
                dataType: 'json',
                data: function(params){
                    return {
                        query: params.term
                    };
                },
                processResults: function(response){
                    return {
                        results: response.data,
                    };
                },
                cache: true
            }
        });
     });


 
    
        $("#capture-btn").click(function () {
            $('#capture').show();

            });

                    $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });

    ///////////////////// for Filtering Bill date/////////////////////////
      $('#BillResult').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#billresponse').html('Please specify valid date.');
        } else {
            $('#bill').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn span').html() + "&approval="+$('#approval').val();
            // alert(dta);
            // return;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/billfilterdata'; ?>',

                data: dta,
                success: function (res) {
                    $('#bill').html(res);
                },
                error: function () {
                    $('#bill').html('<div class="alert alert-warning">Fail to retreive Bill.!!</div>');
                }
            });

            }
        e.preventDefault();
    });
        
        $("#bill_type").change(function(){
    if($("#bill_type").val()==7){
        $('#showProject').show();
    }else{
     $('#showProject').hide();
    }
       
    });              
    </script>