<?php
 $bmodel = new App\Models\BillingModel();
 $remodel = new App\Models\ReportsModel();
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Payments</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                $bmodel = new App\Models\BillingModel();
                   $amodel = new App\Models\AdmissionModel();
                $pj = $amodel->get_student_details('projects_tbl', $where = array('status' => 1));
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Pay Voucher</li>
                </ol>
            </div>
            <div id="largeScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#voucher-all">Voucher List</a></li>
                 <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#voucher-add">New Voucher</a></li>
            </ul>
            </div>

             <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#voucher-all">Voucher List</a></li>
                <li></li><li></li>
                  <li class="nav-item d-none d-sm-block"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#voucher-add">New Voucher</a></li>
            </ul>
             </div>
           
        </div>
    </div>
</div>
<?php
 $cty= $bmodel->get_table_details('voucher_types_tbl');
  ?>
<div class="section-body mt-4">
        <div class="container-fluid">
        	<div class="tab-content">
              <div class="tab-pane active" id="voucher-all">
               <div class="d-flex justify-content-center">
                <div id="messageDisplayArea"></div>
                    <form id="voucherResult" class="form-inline">
                         Voucher date:
                         <div class="input-group ms-3 me-3">
                            <button type="button" class="btn btn-default pull-right daterange-all" id="daterange-all">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                           
                        <button type="submit" class="btn btn-primary">Create</button>

              <div class="input-group ms-3">
    <input type="text" class="form-control" name="payer_name" id="search_name" placeholder="Search Supplier Name" 
        aria-label="Student Name" aria-describedby="button-st" style="width: 180px;"> 
    <input type="hidden" id="search_id" value="0">
    <select class="form-control form-select" style="width: 100px;" id="voucher_select"> 
       <?php foreach($cty as $type): ?>
        <option value="<?= $type->id ?>"><?= $type->voucher_type_name; ?></option>
        <?php endforeach; ?>
    </select>
    
    <button class="btn btn-outline-success" type="button" id="button-y">
        <span>
            <i class="fa fa-calendar" aria-hidden="true"></i>
        </span>
    </button>
    
    <button class="btn btn-outline-primary" type="button" id="button-st" onclick="searchnamebtn()">
        <i class="fa fa-search" aria-hidden="true"></i>
    </button>
</div>

                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="voucher_list"></div>
                </center>
            </div>
              
              <div class="tab-pane" id="voucher-add">
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="card card-lg">
                            <div class="card-header"  style="height:5px">
                                <h3 class="card-title">Voucher Details</h3>
                                <div class="card-options ">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                                <hr>
                              <div class="card-body">
                    <form class="form-horizontal" id="voucher_form">
                    	 <div id="feedback"></div>
                    	  <div class="row">
                            <div class="col-md-6">
                         <div class="form-group row">
                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Voucher Date</label>
                                <div class="col-sm-8">
                                <input type="date" id="voucher_date" name="voucher_date" value="<?php echo date('Y-m-d');?>" class="form-control" required>
                                </div>
                                </div>
                            	 <div class="form-group row">
                                <label for="inputpaidBy" class="col-sm-4 col-form-label">Bank</label>
                                  <div class="col-sm-8">
                                              <?php
                                                  $acc = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 9));
                                                  ?>
                                                <select class="form-control" name="bank" id="bank">
                                                	  <option value="">-Select -</option>
                                                    
                                                    <?php foreach($acc as $type): ?>
                                                    <option value="<?= $type->id ?>"><?= $type->account_name; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                 <div id="errormsg" style="color:red"></div>
                                            </div>
                                          </div>
                                      <div class="form-group row" id="voucherTypeId" style="display:none;">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Voucher Type</label>
                                            <div class="col-sm-8">
                                              
                                <select class="form-control" name="voucher_type" id="voucher_type">
                                      <option value="">-Select -</option>
                                    <?php foreach($cty as $type): ?>
                                    <option value="<?= $type->id ?>"><?= $type->voucher_type_name; ?></option>
                                    <?php endforeach; ?>
                                        </select>
                                            </div>
                                          </div>
                                          
                                           <div class="form-group row" id="payTypeRow" style="display:none;">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Pay Type</label>
                                            <div class="col-sm-8">
                                              
                                <select class="form-control" name="pay_type" id="pay_type">
                                      <option value="">-select-</option>
                                      <option value="1">Expenses</option>
                                      <option value="2">Purchases</option>
                                        </select>
                                            </div>
                                          </div>
                         <!---------------choosing type for refund---------->
                            <div class="form-group row" id="creditOver" style="display:none;">
                            <label for="inputpaidBy" class="col-sm-4 col-form-label"> Type</label>
                                 <div class="col-sm-8 d-flex align-items-center">
                            <select class="form-control mr-2" name="type" id="type5" aria-describedby="button2">
                                <option value="0">All</option>
                                <option value="2">Overpayment</option>
                                <option value="6">Credit Note</option>
                            </select>
                            <button class="btn btn-outline-primary" type="button" id="button2" onclick="load_bill(5)">
                                <i class="" aria-hidden="true">Load</i>
                            </button>
                            </div>

                                </div>

                        <!---------------choosing type for refund---------->
                         <div class="form-group row" id="billTypeDiv" style="display:none;">
                            <label for="inputpaidBy" class="col-sm-4 col-form-label"> Type</label>
                             <div class="col-sm-8 d-flex align-items-center">
                            <select class="form-control mr-2" name="billtype" id="billtype1" aria-describedby="button3">
                                <option value="0">All</option>
                                <!-- <option value="2">Overpayment</option>
                                <option value="6">Credit Note</option> -->
                            </select>
                            <button class="btn btn-outline-primary" type="button" id="button3" onclick="load_bill(1)">
                                <i class="" aria-hidden="true">Load</i>
                            </button>
                            </div>

                                </div>

                     <!---------------choosing type for refund---------->
                     <div class="form-group row" id="name_selected" style="display:none;">
                                <label for="inputpaidBy" class="col-sm-4 col-form-label"> Paid To</label>
                            <div class="col-sm-8 d-flex align-items-center" id="display_name">
                         </div>
                         <input type="hidden" name="staff_id" id="staff_id" value="">
                    </div>
                     

                    <!------start sms provider name ----------->
        <div class="form-group row" id="sms_supplier_div" style="display:none;">
                        
            <label for="inputpaidBy" class="col-sm-4 col-form-label"> Supplier</label>

            <div class="col-sm-8 d-flex align-items-center"> 
            <input type="text" class="form-control" name="sms_supplier_name" id="sms_supplier_name"   placeholder="Search Supplier Name" aria-label="Supplier Name" aria-describedby="button-addon5">

            <button class="btn btn-outline-primary" type="button" id="button-addon5" onclick="search_supplier()">
              <i class="fa fa-search" aria-hidden="true"></i>
            </button>
        </div>
         </div>

                     <div class="form-group row" id="expense_ledger" style="display:none;">
                         <?php 
                       $expenseL = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 10));
                             ?>
                        <label for="inputpaidBy" class="col-sm-4 col-form-label"> Expense Ledger</label>
                         <div class="col-sm-8 d-flex align-items-center">
                          <select class="form-control form-select" id="expense_select">
                            <option value="">-select-</option>
                           <?php
                          foreach($expenseL as $ex){
                            ?>
                         <option value="<?php echo $ex->id;?>"><?= $ex->account_name;?></option>
                        <?php
                          }
                         ?>      
                         </select>
                     </div>

                     </div>
                     <!-----end- sms provider name ----------->

                     <!---------------choosing type for pocket money---------->

                              <div class="form-group row" id="matronDiv" style="display:none;">
                                <label for="inputpaidBy" class="col-sm-4 col-form-label"> Paid To</label>
                                

                                    <div class="col-sm-8 d-flex align-items-center">
                                                    
                                        <input type="text" class="form-control" name="matron" id="matron_id"   placeholder="Search staff name" aria-label="staff name" aria-describedby="matron-button">
                                           <button class="btn btn-outline-primary" type="button" id="matron-button" onclick="search_matron()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                     <!---------------choosing type for pocket money---------->
                     <!-- ==============================salary advances================================== -->
          <div class=" ml-4 form-group row" id="staff_name_selected" style="display:none;">
                                                   <!-- <div class=" col-md-12"> -->
                                <div class=""  id="display_staff_name">
                                    
                                </div>
                         <!-- </div> -->
                         <input type="hidden" name="staff_id" id="staff_id" value="">
                    </div>
                    <div class="col-md-12">
                        <div id="staff_data"></div>
                        
                    </div>
                      <div class="form-group row" id="salary_advance" style="display:none;">
                                <label for="inputpaidBy" class="col-sm-4 col-form-label"> Staff Name:</label>
                                

                                    <div class="col-sm-8 d-flex align-items-center">
                                                    
                                        <input type="text" class="form-control" name="staff_salary" id="staff_salary"   placeholder="Search staff name" aria-label="staff name" aria-describedby="salary-button">
                                           <button class="btn btn-outline-primary" type="button" id="salary-button" onclick="search_staff_salary()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                             <div class="col-md-12" id="repayment_schedule" style="display:none;">
                                        <div class="d-flex justify-content-center mb-3">
 
                                            </div>

                                        </div>
                    <!-- ===============================================salary advances================== -->
                     <!-- =================================payroll================================================ -->
                        <div class="form-group row" id="payroll" style="display:none;">
                                        <div class="row mb-3 text-center">
          <label for="year" class="col-sm-4 col-form-label">Payroll Year:<span class="text-danger">*</span></label>
                  <div class="col-sm-8 d-flex align-items-center">
                   <select id="year2" name="year" style="width:300px;" class="payroll-select form-control form-control-sm align-items-center year-dropdown" required>
                     <option value="0" selected>-- All --</option>
                                       <?php
                                    $initial_year=2023;
                                    $current_year=date('Y');
                                    $final_year=$current_year+1;
                                    for ($initial_year; $initial_year <=$final_year ; $initial_year++) { 
                                
                                    ?>
                        <?php if($initial_year == $current_year){?>
                                    <option value="<?=$initial_year;?>" selected><?=$initial_year;?></option>
                                    <?php
                                           }else{
                                    ?>
                                    <option value="<?=$initial_year;?>" ><?=$initial_year;?></option>
                                    <?php
                                        }
                                    ?>

                                    <?php

                                       }
                                    ?>
         
                          </select>
                           <div class="invalid-feedback">Payroll Year required.</div>
                               </div>
                                   </div>
                        <div class="row mb-3 text-center">
          <label for="month" style='color: black; font-weight: normal;' class="col-sm-4 col-form-label">Payroll Month:<span class="text-danger">*</span></label>
                  <div class="col-sm-8 d-flex align-items-center">
                 <select id="month" name="month" style="width:300px;" class="payroll-select form-control" required>

                         <option value="" selected disabled >--please Select--</option>
                        <?php  
                                if(isset($months)){
                                     echo '<option value="0"selected> -- All -- </option>';
                              foreach($months as $info){
                                if($info->is_current==1){
                                    echo '<option value="'.$info->month_id. '"selected>' . $info->month . '</option>';     
                                }
                                else{
                                   echo '<option value="'.$info->month_id. '">' . $info->month . '</option>';   
                                }
                           
                              }}
                               ?>                      
                 </select>
                  <div class="invalid-feedback">Payroll Month required.</div>
                                                </div>
                    
                                            </div>
                                            <div class="row mb-3 text-center">
                                <label for="payroll_pay" class="col-sm-4 col-form-label"> Payment Type:</label>
                                

                                    <div class="col-sm-8 d-flex align-items-center">
                                                    
                                 <select class="form-control payroll-select" style="width:300px;" id="payroll_pay">
                                    <?php
                                   $ids = [7, 8];
                    $paytype = $bmodel->get_paytype_name('name_type_tbl',$ids);
                                    ?>
                            <option value="" disabled selected>--select--</option>
                           <?php
                           if(isset($paytype)){
                          foreach($paytype as $p_type){
                            ?>
                         <option value="<?php echo $p_type->id;?>"><?= $p_type->name_type;?></option>
                        <?php
                          }}
                         ?>      
                         </select>
                     </div>
                 </div>
                          <div id="government_legers" class="row mb-3 text-center">
                     
 <label for="gov_ledger" class="col-sm-4 col-form-label"> Pay to:</label>
        <div class="col-sm-8 d-flex align-items-center">
                                                    
                                 <select class="form-control payroll-select" style="width:300px;" id="gov_ledger">
                            <option value="" disabled selected>--select--</option>
                           <?php
                           if(isset($legers)){
                          foreach($legers as $leger){
                            ?>
                         <option value="<?php echo $leger->id;?>"><?= $leger->institution_name;?></option>
                        <?php
                          }}
                         ?>      
                         </select>
                                                      </div>
                                                  
                                              </div>
                                                   <div class="mt-4 ml-5 col-md-12">
                                                      <div id="waitmsg"></div>
                                                <div id="government_payroll"></div>
                                                <div id="staff_payroll"></div>
                                                </div>
                                              
                                            </div>
                     <!-- =================================payroll================================================ -->
                       
                       <!---------------put reason---------------------->
                         <div class="form-group row" id="reasonDiv" style="display:none;">
                            <label for="inputpaidBy" class="col-sm-4 col-form-label"> Description</label>
                      <div class="col-sm-8 d-flex align-items-center">
                           <textarea class="form-control" name="reason" placeholder="Write a description here"></textarea>
                            </div>

                         </div>
                         <div class="form-group row" id="all_input" style="display:none;">
                                <label for="inputpaidBy" class="col-sm-4 col-form-label"> Amount</label>
                            <div class="col-sm-8 d-flex align-items-center">
                                 <input type="text" id="allinput_id" value="" class="form-control" onkeyup="AllCalc()">
                         </div>
                        
                    </div>

                        <div id="payer_details"></div>
                               
                             </div>
                           
                           <!-- <div class="col-md-1">another side</div> -->
                            <div class="col-md-6">
                                 <div id="payment_details"></div>
                                 <div class="form-group row mt-5" id="payer_name_row" style="display: none;">
                                            <!-- <label for="payerame" class="col-sm-4 col-form-label">Name<span class="text-danger">*</span></label> -->
                                            <div class="col-sm-6">
                                                <div class="input-group mb-3">
                                                    
                                                    <input type="text" class="form-control" name="payer_name" id="payer_name"   placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2">
                                                    <button class="btn btn-outline-primary" type="button" id="button-addon2" onclick="search_payer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                         
                                         <div class="col-sm-6">
                                                <div class="input-group mb-3">
                                                    
                                                    <input type="text" class="form-control" name="receipt_number" id="receipt_number"   placeholder="Search Receipt Number" aria-label="receipt number" aria-describedby="button-addon3">
                                                    <button class="btn btn-outline-primary" type="button" id="button-addon3" onclick="search_receipt()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>

                                          </div>

                                          
                     <div id="customer_loaded"></div> 

                    
                            </div>
                    <!---button added here=======-->
                    <div class="col-md-8"></div>
                <div class="pull-right col-md-4">
                     <button type="button" id="smsRecharge" onclick="createSmsRecharge()" class="btn btn-primary btn-lg" style="display:none;"><i class=""> </i> Create</button>
                 </div>
                     <!---button added here=======-->
                        </div>
                         </div>
                        

                       <div class="row mt-3">
                        	<!-- <div class="card-body"> -->
                            <div class="col-md-12">
                              <div class="form-group row">
                          <center>
                          	<div id="all_list"></div>
                          </center>
                          

                              </div>
                          </div>
                      <!-- </div> -->
                      </div>

                    </form>
                 <!-----class pocket money selection options---------->
                <div class="col-md-12" id="class_selection" style="display:none;">
                <div class="d-flex justify-content-center mb-3">
                    <form id="Rept1Result" class="form-inline">
                     <div class="me-3">
                             Academic year: 
                           <select id="year" name="year" class="form-select form-control">
                      <!-- JavaScript loop to generate year options -->
                      <script>
                        const currentYear = new Date().getFullYear();
                        const startYear = 2023; // Change this to set a different start year
                        for (let year = currentYear+1; year >= startYear; year--) {
                            if(year==currentYear){
                            document.write(`<option value="${year}" selected>${year}</option>`);
                            }else{
                            document.write(`<option value="${year}">${year}</option>`);    
                            }
                        
                        }
                      </script>
                    </select>
                        </div>
                        
                        <div class="me-3">
                             Level: 
                            <select class="form-control form-select" name="classlevel" id="classlevel">
                                <option value="0">All</option>
                                <?php
                               $l = $remodel->get_levels();
                              foreach($l as $le){
                               echo '<option value="' . $le->id . '">' . $le->level_name . '</option>'; 
                              }

                               ?>
                            </select>
                        </div>

                         <div class="me-3">
                             Class: 
                            <select class="form-control form-select" name="class" id="class">
                                <option value="0">All</option>
                                <?php
                               $c = $remodel->get_classes1();
                              foreach($c as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->class_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                      
                         <div class="me-3">
                             Stream: 
                            <select class="form-control form-select" name="stream" id="stream">
                                <option value="0">All</option>
                                <?php
                               $s = $remodel->get_stream1();
                              foreach($s as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->stream_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                         <div class="me-3">
                             Hostel: 
                             <select class="form-control form-select" name="hostel" id="hostel">
                                <option value="0">All</option>
                              <?php
                               $hostels = $amodel->get_student_details('hostel_tbl', $where = array('status' => 1));
                              foreach($hostels as $h){
                               echo '<option value="' . $h->id . '">' . $h->hostel_name . '</option>'; 
                              }

                               ?>   
                             </select>

                         </div>

                        <button type="submit" class="btn btn-primary">Load</button>

                     </form>

                </div>
                 
                         </div>
             <!----end-class pocket money selection options---------->
             <!-----control number added here---------------------->
                     <div class=" col-md-12 form-group row mt-1" id="chargesDiv" style="display:none;">
                     <div class="d-flex justify-content-center">
                    <form id="chargesDateRange" class="form-inline">
                          Charges date:
                         <div class="input-group ms-1 me-3">
                         <button type="button" class="btn btn-default pull-right daterange-all" id="daterange-all">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                      
                        <button type="submit" class="btn btn-primary">Load</button>
                        
                    </form>
                                 </div>
                                 </div>
                        <!----end----control number added here------------>

                       <div class="row mt-3">
                            <!-- <div class="card-body"> -->
                            <div class="col-md-12">
                              <div class="form-group row">
                          <center>
                            <div id="all_list2"></div>
                          </center>
                          

                              </div>
                          </div>
                      <!-- </div> -->
                      </div>
                </div>

                      </div>
                    </div>
                </div>

            
        	   </div>
        	</div>
        </div>

       
        <script type="text/javascript">
             const selectElement = document.getElementById('bank');
               
        $("#voucher_type").change(function(){

            $("#all_input").hide();
             $('#staff_name_selected').hide();
              $('#display_name').html("");
               $('#customer_loaded').html('');
                 $("#class_selection").hide();
                 $("#all_list").html('');
                 $("#all_list2").html('');
                  $("#matronDiv").hide();
                   $("#creditOver").hide(); 
                   $("#reasonDiv").hide(); 
                   $("#billTypeDiv").hide(); 
                   $("#sms_supplier_div").hide(); 
                    $("#chargesDiv").hide();
                    $("#payer_name_row").hide();
                    $("#payroll").hide();
                    $("#government_legers").hide();
                    $("#salary_advance").hide();
                    $("#repayment_schedule").hide();
                    $("#staff_data").hide();
                     $("#payTypeRow").hide();
                    
                var bank_type=$("#bank").val();
                //alert(bank_type);
                
                if(bank_type==""){
                 //alert('Please select bank');
                   $("#creditOver").hide(); 
                   $("#payer_name_row").hide();
                    $("#reasonDiv").hide(); 
             document.getElementById("errormsg").innerHTML = "Choose Bank"; 
               selectElement.style.borderColor = 'red';
                $(this).val('').trigger('change');
                }else{
               document.getElementById("errormsg").innerHTML = ""; 
               selectElement.style.borderColor = '';
                 
                var voucher_type=$("#voucher_type").val();
            //    alert(voucher_type);
             if(voucher_type==5){
                   $("#payer_name_row").show();  
            document.getElementById('payer_name').placeholder = 'Search Customer Name';
            document.getElementById('receipt_number').placeholder = 'Search Receipt Number';
                   $("#creditOver").show(); 
                   $("#reasonDiv").show(); 
                   $("#billTypeDiv").hide();
                }else if(voucher_type==1){
                 $("#payer_name_row").show();
             document.getElementById('payer_name').placeholder = 'Search Supplier Name';
             document.getElementById('receipt_number').placeholder = 'Search Bill Number';
                 $("#creditOver").hide(); 

                  $("#reasonDiv").show(); 
                  $("#billTypeDiv").show(); 
                }else if(voucher_type==3){
                    
                  $("#payer_name_row").hide();
                  $("#creditOver").hide(); 
                  $("#reasonDiv").hide(); 
                  $("#billTypeDiv").hide(); 
                 // $("#class_selection").show(); 
                  $("#matronDiv").show();

                }else if(voucher_type==4){
                    
                 $("#sms_supplier_div").show(); 
             
                }
                else if(voucher_type==7){
                    
               $("#sms_supplier_div").show(); 
             
                } 
                 else if(voucher_type==6){                
               $("#payroll").show(); 
             
                } else if(voucher_type==2){
            $("#payer_name_row").hide();  
            $("#payTypeRow").show();  

             
                }
                else if(voucher_type==8){
            $("#payer_name_row").hide();  
            $("#salary_advance").show();  
             
                }
                else{
                   $("#payer_name_row").hide();
                }
    }
    });

     function load_bill(id){

        if($("#type"+id).val()==""){
      //$("#paidTo").hide();
        }else{
    // alert(0);
     
         var type=$("#type"+id).val();
        
       var id=0;
        
        var voucher_type=$('#voucher_type option:selected').val();
         // alert(voucher_type);
          $('#all_list').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
          if(voucher_type==1){
           $('#all_list').load("<?php echo base_url() . '/index.php/BillController/billpay/'; ?>"+id);
          }else if(voucher_type==5){
            $('#all_list').load("<?php echo base_url() . '/index.php/BillController/refund/'; ?>"+id+"/"+type); 
          }else{

          }

        }

    };


$("#bank").change(function(){
     document.getElementById("errormsg").innerHTML = ""; 
     selectElement.style.borderColor = '';
        
      	var bank_type=$("#bank").val();
        if(bank_type==""){
        $('#payment_details').html('');
        $("#creditOver").hide(); 
         $("#reasonDiv").hide(); 
        $("#payer_name_row").hide();
        $('#voucherTypeId').hide();
        $("voucher_type").val('').trigger('change');
        }else{

       $('#payment_details').html('<span class="fa fa-spinner fa-spin"></span> Please wait..');
      
         $('#payment_details').load("<?php echo base_url() . '/index.php/BillController/bank_payments'; ?>/"+bank_type);
         $('#voucherTypeId').show();
     }
   
    });


 $("#voucherResult").submit(function (e) {

     
     if (!$('#daterange-all span').html()) {
           // $('#RecptResult').html('Please specify valid date.');
        alert("please specify valid date");
        } else {
            $('#voucher_list').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-all span').html();
         // alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url().'/index.php/BillController/voucher_list'; ?>',
                data: dta,
                success: function (res) {
                    $('#voucher_list').html(res);
                },
                error: function () {
                    alert('error');
                    $('#voucher_list').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

        }
 e.preventDefault();
 });

 function search_receipt(){
    var myurl="";
     var voucher_type=$("#voucher_type").val();
    $('#customer_loaded').show();
      if($('#receipt_number').val() == ""){
          swal("warning","Please Enter Name","warning"); 
       }else{
          var type=$("#type").val();
           
            //alert(paydata);
            if(voucher_type==1){
                 var paydata = 'paid_by=' + '2' + "&receipt_number=" + $('#receipt_number').val()+'&type='+0;
            myurl='<?php echo base_url() . '/index.php/BillController/search_receipt'; ?>';
            }else if(voucher_type==5){
                 var paydata = 'paid_by=' + '1' + "&receipt_number=" + $('#receipt_number').val()+'&type='+0;
            myurl='<?php echo base_url() . '/index.php/BillController/search_receipt'; ?>';
            }
           // alert(paydata);
            $.ajax({
                type: "POST",
                url: myurl,
                beforeSend: function () {
                   $('#all_list').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
                },
                data: paydata,
                success: function (result) {
                  $('#all_list').html(result); 
                },
                error: function () {
                    $('#all_list').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
       
    }

  function search_payer(){
    var myurl="";
     var voucher_type=$("#voucher_type").val();
    $('#customer_loaded').show();
      if($('#payer_name').val() == ""){
          swal("warning","Please Enter Name","warning"); 
       }else{
          var type=$("#type").val();
           
           // alert(paydata);
            if(voucher_type==1){
                 var paydata = 'paid_by=' + '2' + "&payer_name=" + $('#payer_name').val()+'&type='+0;
            myurl='<?php echo base_url() . '/index.php/BillController/search_customer'; ?>';
            }else if(voucher_type==5){
            var paydata = 'paid_by=' + '1' + "&payer_name=" + $('#payer_name').val()+'&type='+0;
            myurl='<?php echo base_url() . '/index.php/BillController/search_customer'; ?>';
            }
            $.ajax({
                type: "POST",
                url: myurl,
                beforeSend: function () {
                   $('#all_list').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
                },
                data: paydata,
                success: function (result) {
                  $('#all_list').html(result); 
                },
                error: function () {
                    $('#all_list').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
       
    }
     function select_payer(event,id,nametype,payer_name){
         event.preventDefault(); 
      var voucher_type=$("#voucher_type").val();
       var type=$("#type").val();
       var selected=$('#selection option:selected').val();
        
        
         // alert(voucher_type);
        $("#payer_name_row").hide();
        $('#customer_loaded').hide();
          $('#all_list').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
        if(voucher_type==1){
           $('#all_list').load("<?php echo base_url() . '/index.php/BillController/billpay/'; ?>"+id+"/"+type);
          }else if(voucher_type==5){
            $('#all_list').load("<?php echo base_url() . '/index.php/BillController/refund/'; ?>"+id+"/"+type); 
          }else{

          }
    }
      
       $("#classlevel").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#class").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });

        $("#class").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            //url: 'class_list',
             url: '<?php echo base_url() . '/index.php/StudentController/get_stream_details'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#stream").empty();
                $("#stream").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    $("#stream").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
   });
$("#level").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#classb").empty();
                $("#classb").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#classb").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });

        $("#classb").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            //url: 'class_list',
             url: '<?php echo base_url() . '/index.php/StudentController/get_stream_details'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#streamb").empty();
                $("#streamb").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    $("#streamb").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });

$('#Rept1Result').submit(function (e) {
            
            $('#all_list2').html('<span class="fa fa-spinner fa-spin"></span> Retreiving report..');
            var dta = "class=" + $('#class option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&year="+$('#year option:selected').val()+ "&hostel="+$('#hostel option:selected').val()+'&staff_id='+$('#staff_id').val();
           //alert(dta);
           // return;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/ReportsController/get_pocket_money_list'; ?>',
                 data: dta,
                success: function (res) {
                    $('#all_list2').html(res);
                },
                error: function () {
                    $('#all_list2').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


        e.preventDefault();
    });

function search_matron(){
   var matron_name=$("#matron_id").val();
    $('#customer_loaded').show(); 
    $('#customer_loaded').html(matron_name); 

     if($('#matron_id').val() == ""){
        $('#customer_loaded').html("<span class='text-red'>Please enter staff name</span>"); 
       }else{
        var dta = "matron_name=" + matron_name;

         $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillController/search_staff'; ?>',
                beforeSend: function () {
                   $('#customer_loaded').html('<span class="fa fa-spinner fa-spin"></span> Loading results..');
                },
                data: dta,
                success: function (result) {
                  $('#customer_loaded').html(result); 
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
       }
}

function select_staff(user_id,staf_name,e){
 //alert(staf_name);
    $('#matronDiv').hide();
    $('#staff_id').val(user_id);
    $('#name_selected').show();
    $('#display_name').html(staf_name);
  $('#customer_loaded').html('');
  $("#class_selection").show(); 
 e.preventDefault();
}

function search_supplier(){
 var supplier_name=$("#sms_supplier_name").val();
    $('#customer_loaded').show(); 
    //$('#customer_loaded').html(matron_name); 

     if($('#sms_supplier_name').val() == ""){
        $('#customer_loaded').html("<span class='text-red'>Please enter supplier name</span>"); 
       }else{
        var dta = "supplier_name=" + supplier_name;
        //alert(dta);
         $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillController/search_supplier'; ?>',
                beforeSend: function () {
                   $('#customer_loaded').html('<span class="fa fa-spinner fa-spin"></span> Loading results..');
                },
                data: dta,
                success: function (result) {
                  $('#customer_loaded').html(result); 
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
       }   
}

function select_supplier(id,name,bal,e){
   // alert(name);
    var voucher_type=$("#voucher_type").val();
    var balance=bal.toLocaleString();
     $('#customer_loaded').html(''); 
     // $('#supplier_id').val(id);
     if(voucher_type ==7){
   $("#sms_supplier_div").html(''+
    '<input type="hidden" name="supplier_id" id="supplier_id" value="'+id+'">'+
    '<div class="form-group row"><lable class="col-sm-4 col-form-label">Supplier Name</lable><div class="col-sm-8 d-flex align-items-center">'+name+'</div>'+

       '<lable class="col-sm-4 col-form-label">Sms Balance</lable><div class="col-sm-8 d-flex align-items-center">'+balance+'</div>'+

           '<lable class="col-sm-4 col-form-label mt-3">Recharge Amount</lable><div class="col-sm-8 d-flex align-items-center mt-3"><input type="text" class="form-control" name="recharge_amount" id="recharge_amount" onkeyup="AmountCalc('+bal+')"></div>'+
          '</div>'); 
   $('#expense_ledger').show();
}else{
     $("#sms_supplier_div").html(''+
    '<input type="hidden" name="supplier_id" id="supplier_id" value="'+id+'">'+
    '<div class="form-group row"><lable class="col-sm-4 col-form-label">Supplier Name</lable><div class="col-sm-8 d-flex align-items-center">'+name+'</div>');
     $("#chargesDiv").show();
}
   $("#reasonDiv").show(); 
   

   e.preventDefault();
}

function AmountCalc(bal){
        //alert(bal);
             var total=0;
            var amount=0;
            var balance=0;
            
            var input=$("#recharge_amount").val().replace(/,/gi, "");
           
            if(input==""){
                input=0;
            }

            $("#recharge_amount").val(parseInt(input).toLocaleString());
            total=total+parseInt(input);
         
          //alert(total);
          
          balance= $("#balance").html().replace(/,/gi, "");
          balance=parseInt(balance)-total;
          // alert(balance);
          $("#after").html(balance.toLocaleString());
          $("#thispay").html(total.toLocaleString());
      
      }

     $("#expense_select").change(function(){
    var ex=$("#expense_select").val();
     if(ex!=""){
   $("#smsRecharge").show();
        }else{
      $("#smsRecharge").hide();
        }
    });

    function createSmsRecharge(){
        var payed= $("#thispay").html();
    if(payed==0){
       toastr.error("Please! This payment amount is 0");
       }else{

 var data= $("#voucher_form").serialize()+"&"+$("#header_form").serialize()+"&expense_ledger="+$("#expense_select").val();
        //alert(data);
         $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillController/process_sms_recharge'; ?>',
            data: data,
            success: function (res) {
              var data = JSON.parse(res);
              if(data['status'] == "1"){
               
                 // $('#all_list').html('');
                 // refresh_refund();
                 
             swal("success",data['description'],"success");
              refreshCalcalculation();
            }else{
             swal("error","Failed to create Payment","error");    
            }
            },
            error: function (){
                alert('error encounted');
            }
        });

    }
     }

     function refreshCalcalculation(){
       window.location.reload();
     }

     
     $("#chargesDateRange").submit(function (e) {

     
     if (!$('#daterange-all span').html()) {
           // $('#RecptResult').html('Please specify valid date.');
        alert("please specify valid date");
        } else {
            $('#all_list2').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-all span').html();
         // alert(dta);
          //return;
             $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillController/control_number_charges_list'; ?>',
                 data: dta,
                success: function (res) {
                    $('#all_list2').html(res);
                },
                error: function () {
                    alert('error');
                    $('#all_list2').html('<div class="alert alert-warning">Fail to retreive results.!!</div>');
                }
            });

        }
 e.preventDefault();
 });


function searchnamebtn(){
            var name=$('#search_name').val();
            var  year=$('#button-y').html();
            var voucher_type=$("#voucher_select").val();

            // alert(year);
            if(name.length >=3){
                $('#voucher_list').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
                var dta="name="+name+"&year="+year+'&voucher_type='+$("#voucher_select").val()+'&search_id='+$('#search_id').val();
               // alert(dta);
           // toastr.success(name.length);
             $.ajax({
                type: "POST",
                 url: "<?php echo base_url() . '/index.php/BillController/fetch_voucher_byname'; ?>/5",
                data: dta,
                success: function (res) {
                    $('#voucher_list').html(res);
                },
                error: function () {
                    $('#voucher_list').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
        }else{
            if(name.length==0){
               $('#voucher_list').html(''); 
            }else{
               $('#voucher_list').html('<div class="alert alert-info">Search atleat 3 characters</div>'); 
            }
        
        }
        }

$("#voucher_select").change(function(){
     var voucher_type=$("#voucher_select").val();
     //alert(voucher_type);
      if(voucher_type==1){
        $('#search_id').val(2);
         document.getElementById('search_name').placeholder = 'Search Supplier Name';
        }
        else if(voucher_type==2){
         d$('#search_id').val(2);
         document.getElementById('search_name').placeholder = 'Search Supplier Name';
        }
        else if(voucher_type==3){
            $('#search_id').val(7);
         document.getElementById('search_name').placeholder = 'Search Staff Name';
        }
        else if(voucher_type==4){
            $('#search_id').val(2);
         document.getElementById('search_name').placeholder = 'Search Supplier Name';
        }
     else if(voucher_type==5){
        $('#search_id').val(1);
         document.getElementById('search_name').placeholder = 'Search Student Name';
        }

        else if(voucher_type==6){
            $('#search_id').val(7);
         document.getElementById('search_name').placeholder = 'Search Staff Name';
        }
        else if(voucher_type==7){
            $('#search_id').val(2);
         document.getElementById('search_name').placeholder = 'Search Supplier Name';
        }


     });

$("#payroll_pay").change(function(e) {
    e.preventDefault();
    var pay_type = $("#payroll_pay").val();
    var year = $("#year").val();
    var month = $("#month").val();
var bank_type=$("#bank").val();
    if (pay_type == 8) {
        $("#government_legers").show();
        $('#waitmsg').html('');
        $('#staff_payroll').html('');
        $('#government_payroll').html('');
    } else {
        $("#government_legers").hide();
        $.ajax({
            type: "POST",
            url: '<?= base_url().'/pay-payroll'; ?>',
            data: { pay_type: pay_type, year: year, month: month,bank_type:bank_type },
            beforeSend: function () {
                $('#waitmsg').html('<span class="spinner-border spinner-border-sm"></span> Loading please wait..');
                $('#government_payroll').html('');
                $('#staff_payroll').html('');
            },
            success: function (res) {
                $('#staff_payroll').html(res);
                $('#government_payroll').html('');
                $('#waitmsg').html('');
            },
            error: function () {
                $('#staff_payroll').html('<div class="alert alert-warning">Fail to Load data.!!</div>');
                $('#government_payroll').html('');
                $('#waitmsg').html('');
            }
        });
    }
});

$("#gov_ledger").change(function(e){
    e.preventDefault();
     $('#staff_payroll').html('');
     var pay_type=$("#payroll_pay").val();
     var year=$("#year").val();
     var month=$("#month").val();
     var gov_ledger=$("#gov_ledger").val();
     var bank_type=$("#bank").val();
$.ajax({
    type: "POST",
    url: '<?php echo base_url().'/pay-payroll'; ?>',
    data: { pay_type: pay_type, year:year, month:month,gov_ledger:gov_ledger,bank_type:bank_type},
    beforeSend: function () {
        $('#waitmsg').html('<span class="spinner-border spinner-border-sm"></span> Loading please wait..');
        $('#government_payroll').html('');
        $('#staff_payroll').html('');
    },
    success: function (res) {
        $('#staff_payroll').html('');
        $('#government_payroll').html(res);
        $('#waitmsg').html('');
    },
    error: function () {
        $('#staff_payroll').html('');
        $('#government_payroll').html('<div class="alert alert-warning">Fail to Load data.!!</div>');
        $('#waitmsg').html('');
    }
});

     });
$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    $('.payroll-select').select2();
});



function govern_pay(elem, balance) {
    const values = elem.value.replace(/,/g, '');
    const $errorDiv = $(elem).next(".input-error-message");

    if (parseFloat(values) > parseFloat(balance)) {
        $errorDiv
            .html('Please Enter amount less or equal to ' + parseFloat(balance).toLocaleString())
            .fadeIn();

        $(elem).addClass("input-error");
        elem.value = "";
        elem.focus();
        setTimeout(function () {
            $errorDiv.fadeOut();
            $(elem).removeClass("input-error");
        }, 3000);

        return;
    }
    let inputVal = values === "" ? 0 : values;
    elem.value = parseInt(inputVal).toLocaleString();
    let total = 0;
    $('input[name="topay_gvm[]"]').each(function () {
        let val = $(this).val().replace(/,/g, '');
        if (val === "") val = 0;
        total += parseInt(val);
    });

    $("#totalpay_gvm").html(total.toLocaleString());
    $("#thispay").html(total.toLocaleString());
    $('#totalpay_gvm_value').val(total);
}
function search_staff_salary(){
   var staff_name=$("#staff_salary").val();
    $('#customer_loaded').show(); 
    $('#customer_loaded').html(staff_name); 

     if($('#staff_salary').val() == ""){
        $('#customer_loaded').html("<span class='text-red'>Please enter staff name</span>"); 
       }else{
        var dta = staff_name;
         $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/get-search_staffs'; ?>',
                beforeSend: function () {
                   $('#customer_loaded').html('<span class="fa fa-spinner fa-spin"></span> Loading results..');
                },
                data: {data:dta},
                success: function (result) {
                  $('#customer_loaded').html(result); 
                },
                error: function (xhr, status, error) {
                    $('#customer_loaded').html('<div class="alert alert-danger" role="alert">' +
            '<strong>Error:</strong> Unable to load staff data.<br>' +
            'Status: ' + xhr.status + ' ' + xhr.statusText + '<br>' +
            'Details: ' + error +
        '</div>');;
               }
            });
       }
}
function choose_staff(user_id, staf_name, event) {
  event.preventDefault();
  $('#staff_id').val(user_id);
  $('#salary_advance').hide();
  $('#staff_name_selected').show();
  $('#customer_loaded').html('');
  $('#repayment_schedule').show();
  $('#staff_data').show();
  var bank_type=$("#bank").val();
           $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/get-staff_data'; ?>',
                beforeSend: function () {
                   $('#staff_data').html('<span class="fa fa-spinner fa-spin"></span> Loading results..');
                },
                data: {user_id:user_id},
                success: function (result) {

                  $('#display_staff_name').html(result);
                 $('#staff_data').load("<?php echo base_url(); ?>/get-salary_advances/" + user_id+ '/'+bank_type); 
                 $('#staff_name').val('');

                },
                error: function (xhr, status, error) {
                    $('#staff_data').html('<div class="alert alert-danger" role="alert">' +
            '<strong>Error:</strong> Unable to load staff data.<br>' +
            'Status: ' + xhr.status + ' ' + xhr.statusText + '<br>' +
            'Details: ' + error +
        '</div>');;
               }
            });
}



$("#pay_type").change(function(){
$('#all_list').html('');
   if($("#pay_type").val()==1){
  $('#all_list').load("<?php echo base_url() . '/index.php/BillController/directPay'; ?>");
   }else if($("#pay_type").val()==2){
$('#all_list').load("<?php echo base_url() . '/index.php/BillController/directPay_purchase'; ?>");
   }else{
    $("#pay_type").change();
   }
});

        </script>

