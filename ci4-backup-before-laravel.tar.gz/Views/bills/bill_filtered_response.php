  <?php    
$billmodel = new App\Models\BillingModel();
$smodel = new App\Models\StudentModel();
 ?>
 <div class="section-body mt-4">
    <div class="container-fluid">
        <div class="card">
  <div class="table-responsive mt-3">
     <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable">
                            <thead>
                                <tr>
                                    <th>#Bill.No</th>
                                    <th>Bill Date</th>
                                    <th>Bill From</th>
                                    <th>Bill Ref</th>
                                    <th>Due date</th>
                                    <th>Bill Description</th>
                                    <th>Amount</th>
                                    <th>Updated By</th>
                                    <th>Sms status</th>
                                    <th>Approval</th>
                                    
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                        <!--########################### Filtered data#######################--->

                               <?php 
                            // print_r($billfilter);
                               foreach($billfilter as $bill):
                               if($bill->hstatus == '3'){
                                $checkapp = $billmodel->get_item_name('approval_history',$where=array('app_no'=>$bill->app_no,'hstatus'=>1));
                              
                                if(count($checkapp)>0){
                                    continue;
                                }elseif($bill->hstatus == '3'){
                                 $checkapp = $billmodel->get_item_name('approval_history',$where=array('app_no'=>$bill->app_no,'hstatus'=>2));
                              
                                if(count($checkapp)>0){
                                    continue;
                                }
                                }
                               } 
                              $trans = $billmodel->get_item_name('approval_numbers',$where=array('app_id'=>$bill->app_no));
                              $lgtr=$billmodel->get_item_name('ledger_transaction_tbl',$where=array('trans_no'=>$trans[0]->trans_no,'trans_item'=>0,'trans_type'=>4));
                              $billref = $billmodel->get_item_name('transaction_other_details_tbl',$where = array('transaction_no'=>$trans[0]->trans_no));
                              $tra_date=$billmodel->get_item_name('transaction_numbers_tbl',$where=array('trans_number'=>$trans[0]->trans_no,'trans_type_id'=>4));
                              if(count($tra_date)==0){
                                continue;
                              }
                              $suppname=$billmodel->get_item_name('supplier_tbl',$where=array('supplier_id'=>$trans[0]->name));
                              $updator = $billmodel->get_item_name('users',$where=array('user_id'=>$bill->user));

       //start for sms <!----->
                               $msg_status = $billmodel->get_item_name('message_groups_tbl', $where = array('trans_number' => $trans[0]->trans_no,'message_type'=>13));
                                     if(count($msg_status)>0){
                                         $msg_st = $billmodel->get_item_name('messages', $where = array('send_no' => $msg_status[0]->send_number));
                                         
                            if(count($msg_st)>0){

         ///here we go
                      if($msg_st[0]->time_sent==null && $msg_st[0]->message_id!=""){
                             $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_RETURNTRANSFER => 1,
                        CURLOPT_URL => 'http://www.sms.co.tz/api.php?do=dlr&id=' . $msg_st[0]->message_id . '&username=' . SMS_UNAME . '&password=' . SMS_PASSWORD . '&senderid=' . SENDER_ID . '',
                    ));
                    $msg_status = curl_exec($curl);
                    // echo $msg_status;
                    if($msg_status != ""){

                       list($sntdate, $stts, $deldate) = explode(',', $msg_status);

                       $tempsmsdata = array(
                           'sent_status' => 2, //Sent and delivered
                           'time_sent' => $sntdate,
                           'status_description' => $stts,
                           'time_delivered' => $deldate
                       );
                       //print_r($tempsmsdata);
                        $smodel->update_table_details('messages',$where = array('message_id' => $msg_st[0]->message_id),$tempsmsdata);
                        // echo 'updated';
          
                                }
                                }
                        
                             ?>
                                         
                 <?php
                  $msg_s = $billmodel->get_item_name('messages', $where = array('message_id' => $msg_st[0]->message_id));

                 $del=$msg_s[0]->status_description;
                 $time=$msg_s[0]->time_delivered;
                 $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
             }else{
                 $stata='<span style="color:red">Not Sent'; 
             }
             }else{
               $stata='<span style="color:red">Not Sent';  
             }
       //end for sms status
                                 
                                ?>
                               
                               <tr>
                                   <td><?= $trans[0]->trans_no; ?></td>
                                   <td><?= $tra_date[0]->trans_date; ?></td>
                                   <td><?= $suppname[0]->supplier_name??""; ?></td>
                                   <td><?=$billref[0]->bill_reference; ?></td>
                                   <td><?=$billref[0]->due_date; ?></td>
                                   <td><?= $tra_date[0]->trans_desc; ?></td>
                                   <td style="float: right;"><?= number_format($lgtr[0]->amount); ?></td>
                                   <td><?= $updator[0]->first_name; ?></td>
                                   <td><?= $stata; ?></td>

                                   <td><?php
                                    if($bill->hstatus == '1'){
                                     echo "<div class='text-success'>Approved</div>";
                                     }elseif($bill->hstatus == '3'){
                                    echo "<div class='text-danger'>Pending</div>";

                                     }
                                     elseif($bill->hstatus == '2'){
                                    echo "<div class='text-danger'>Rejected</div>";

                                     }
                                        ?></td>
                                    <td>
                                        <?php
                                    if($bill->hstatus == '1'){
                                     echo "<div class='text-danger'>Closed</div>";
                                     }elseif($bill->hstatus == '3'){
                                    echo "<div class='text-success'>Open</div>";

                                     }
                                     elseif($bill->hstatus == '2'){
                                    echo "<div class='text-danger'>Closed</div>";

                                     }
                                        ?>
                                    </td>
                                   
                                   <td>
                                    <?php if($bill->hstatus == '1'): ?>

                                     <?php else: ?>
                                    <button type="button" class="btn btn-primary btn-sm passingbillID" data-id="<?=$trans[0]->trans_no; ?>"><i class="fa fa-edit"></i> Edit</button>
                                <?php endif; ?>

                                  <button type="button" class="btn btn-primary btn-sm passingBillViewId" data-id="<?=$trans[0]->trans_no;?>"><i class="fa fa-eye"></i> View</button>
                             
                              </td>
                               </tr>
                           <?php endforeach; ?> 
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
<script type="text/javascript">
    $(document).ready(function () {
  $('#myTable').DataTable();
});
        ////////function to View Bill data///////////////
 $(".passingBillViewId").click(function () {
        var data = 'trans_no=' + $(this).attr('data-id');
        // $("#idkl").val( ids );
        $('#myviewModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?= base_url('/get_bill_data')?>",
            data: data,
            beforSend: function()
            {
                $('#Viewbill').html();
            },
            success: function(res){
                $('#Viewbill').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });


    ///////////////////// code to update bill information //////////
    $(".passingbillID").click(function () {   
        var data = 'id=' + $(this).attr('data-id');
        // $("#idkl").val( ids );
        $('#myModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?= base_url('/getSingle_bill_data')?>",
            data: data,
            beforSend: function()
            {
                $('#Updtebill').html();
            },
            success: function(res){
                $('#Updtebill').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
</script>