<style type="text/css">
    .btn-title {
            position: relative;
            display: inline-block;
            cursor: pointer;
            color: white;
        }
        .btn-title::before {
            content: attr(title);
            color: white;
            position: absolute;
            top: -20px; /* Adjust the distance as needed */
            left: 83%;
            transform: translateX(-50%);
            background-color: red;
            padding: 7px 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            display: block; /* Always display the title */
        }

    .help-icon {
    display: inline-block;
    position: relative;
    font-size: 13px; /* Adjust the size as needed */
    vertical-align: super;
    line-height: 1;
}

.icon1 {
    display: inline-block;
    width: 20px;
    height: 20px;
    background-color: #00BFFF;
    color: white;
    border-radius: 50%;
    text-align: center;
    line-height: 20px;
    font-size: 14px;
    font-weight: bold;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Hover effect */
.icon1:hover {
    background-color: #2980b9;
}
.icon2 {
    display: inline-block;
    width: 20px;
    height: 20px;
    background-color: #00BFFF;
    color: white;
    border-radius: 50%;
    text-align: center;
    line-height: 20px;
    font-size: 10px;
    font-weight: bold;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Hover effect */
.icon2:hover {
    background-color: #2980b9;
}

</style>

<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Payment</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">Eden Garden</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Payment</li>
                    <li class="help-icon">
                    <a href="#" onclick="tg_help()" style="margin-left:8px"><span class="icon1">?</span></a>
                   </li>
                </ol>

            </div>
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#recipt-all">Payment List</a>
                 <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#recipt-add">New Payment</a></li>
            </ul>
        </div>
    </div>
</div>


 <div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
           <div class="tab-pane active" id="recipt-all">
               <div class="d-flex justify-content-center">
                <div id="messageDisplayArea"></div>
                    <form id="ReceiptResult" class="form-inline">
                         Payment date:
                         <div class="input-group ms-3 me-3">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="receipt"></div>
                </center>
            </div>
            <!--   <center>
             <button class="btn btn-primary btn-sm" onclick="printable('Rept1ResultViewResults')"><span class="fa fa-print"></span> Print</button>
            </center> -->
           
     <!--------------------------code placed here----------------------->
      <div class="tab-pane" id="recipt-add">
                 <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header mt-1"  style="height:5px">
                                <h3 class="card-title">New Payment <?php //echo "this is new receipt" . $_GET['id'];?></h3>
                                <div class="card-options ">
                                    <button class="btn" onclick="resetReceiptData()"><i class="fa fa-refresh"></i> </button>
                                    <!-- <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a> -->
                                </div>
                            </div>
                                <hr>
                            <div class="card-body" id="receiptData">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Payment Date</label>
                                            <div class="col-sm-8">
                                              <input type="date" id="receipt_date" name="receipt_date" value="<?php echo date('Y-m-d');?>" max="<?php echo date('Y-m-d');?>" class="form-control">
                                            </div>
                                          </div>
                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Paid By<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                               <select class="form-control" name="paid_by" id="paid_by">
                                                    <option value="">Select SUpplier</option>
                                                    <option value="1">supplier</option>
                                                   <!--  -->
                                                </select>
                                            </div>
                                          </div>

                                    <div class="form-group row" id="payer_name_row" style="display:none;">
                                            <label for="payername" class="col-sm-4 col-form-label">Supplier Name<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                                <div class="input-group mb-3">
                                                    <input type="hidden" id="payer_id" name="payer_id" value="">
                                                    <input type="text" class="form-control" name="payer_name" id="payer_name"   placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2">
                                                    <button class="btn btn-outline-primary" type="button" id="button-addon2" onclick="search_payer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                          </div>
                                        <div id="payer_details"></div>
                                        <!--  <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Customer Type<span class="text-danger">*</span></label>
                                        <div class="col-sm-8">   
                                        <select class="form-control" name="customer_type" id="customer_type">
                                                <option value="">Select Customer Type</option>
                                                    
                                                    <option value=""></option>
                                                </select>
                                        </div>
                                          </div> -->
                                          <div class="form-group row" id="select_invoice" style="display:none;">
                                            <label for="payerame" class="col-sm-4 col-form-label">Select Invoice<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" name="customer_name or Id"  id="customer_name" placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2">
                                                    <button class="btn btn-outline-primary" type="button" id="button-addon2" onclick="search_customer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                          </div>
                                        <!--------------show credit note-------->
                                          <div class="form-group row" id="ttlCredit" style="display:none;">
                                                <label for="staticEmail" class="col-sm-4 col-form-label text-green">Total Credit Note</label>
                                                <div class="col-sm-8">
                                                  <input type="text" readonly class="form-control-plaintext text-green" id="credited" value="0">
                                                </div>
                                               <!--  <div class="col-sm-1">
                                                </div>  -->  
                                              </div>

                                 <!-----------show Over payment----------------->
                                          <div class="form-group row" id="payedOver" style="display:none;">
                                                <label for="staticEmail" class="col-sm-4 col-form-label text-green">Total Over payment</label>
                                                <div class="col-sm-8">
                                                  <input type="text" readonly class="form-control-plaintext text-green" id="payover" value="0">
                                                </div>
                                               <!--  <div class="col-sm-1">
                                                </div>  -->  
                                              </div>
                                        <!---------------------------------------------->
                                    </div>   
                                    <div class="col-md-6">
                                       <div id="customer_loaded"></div> 
                                       <div id="Name_loaded"></div>
                                       <div id="Invoice_loaded"></div>
                                    </div>
                                </div>
    
                                <hr>
                                <div class="row">
                                    <div class="col-md-12">
                                        
                                        <form id="receipt_form">
                                            <div id="applicationlist" style="display:none;">
                                             <h6>Application List</h6>
                                            <table class="table" >
                                            <thead>
                                                <tr>
                                                    <th>Student Id</th>
                                                    <th>Student Name</th>
                                                    <th>Item Name</th>
                                                    <th>Quantity</th>
                                                    <th>Amount Due</th>
                                                    <th>Amount To Pay</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="itm_invoice1">
                                            </tbody>
                                        </table>
                                        </div>  
                                        <div id="invoicelist">
                                            <h6>Payment List</h6>
                                        <table class="table table-borderless" >
                                            <thead>
                                                <tr>
                                                    <th>Select</th>
                                                    <th>Payment type</th>
                                                    <th>Payment No</th>
                                                    <th>Payment Date</th>
                                                    <th>Payment Name</th>
                                                    <th>Payment Amount</th>
                                                    <th>Amount Due</th>
                                                    <th>Amount To Pay</th>
                                                </tr>
                                            </thead>
                                            <tbody id="itm_invoice">
                                            </tbody>
                                            <tfoot>
                                                <tr id="itm_invoicefooter"></tr>
                                            </tfoot>
                                        </table>
                                        </div>
                                        </form>    
                                    </div>
                                </div>
                               
                                <div class="cust_popup" id="account" style="display: none">
                                    <form method="POST" id="acct_proc">
                                        <b>CHARGE ACCOUNT</b><i style="color: red" id="saveError"></i><br/>
                                        ACCOUNT NAME
                                        <input class="form-control" id="acc_name" type="text" onkeyup="SearchAccount()" autocomplete="off">
                                        <input id="acc_no" type="hidden">
                                        <div id="schResults"></div>
                                        <br>
                                        AMOUNT
                                        <input class="form-control" id="acc_amt" type="number" autocomplete="off"><br>
                                        <button type="submit" id="svAccnt" class="btn btn-primary pull-right">Save</button>&nbsp;
                                    </form>
                                    <button class="btn btn-warning" style="display:none" id="removeAcct">Remove Account</button>
                                    <button class="btn btn-warning" onclick="tg_acct()">Cancel</button>
                                </div>

                                <div  class="cust_popup" id="cash" style="display: none">
                                    <h6>Receive Cash</h6>
                                     <form id="csh_proc" method="POST">
                                         <select class="form-control" name="ledger" id="ledger" required="">
                                             <option value="">Select ledger</option>
                                                 <option value=""></option>
                                         </select><br>
                                         <input class="form-control" name="cash_amt" id="cash_amt" type="number" required="" ><br>
                                         <button class="btn btn-warning" onclick="close_Popup()">Cancel</button>
                                         <button type="submit" class="btn btn-primary pull-right">Save</button>&nbsp;
                                     </form>
                                   <button class="btn btn-sm btn-warning" style="display:none" id="removeCash">Remove Cash</button>&nbsp;
                               </div>
                                  <!-------credit note popup------------------->
                                <div  class="cust_popup" id="cash_credit" style="display: none; width: 600px;">
                                    <h6 class="text-center">AVAILABLE CREDIT NOTE LIST
                                      <li class="help-icon">
                                    <a href="#" onclick="tg_help()" style="margin-left:8px"><span class="icon1">?</span></a>
                                   </li>
                                    </h6><br>
                              <form id="csh_proc_cr" method="POST" autocomplete="off">

                                      <table class="table" >
                                            <thead>
                                                <tr>
                                                    <th>Type</th>
                                                    <th>Note No</th>
                                                    <th>Credit Amount</th>
                                                    <th>Credit Bal</th>
                                                    <th>Use</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="choose_credit">
                                            </tbody>
                                            <tfoot class="border-less">
                                                <tr id="itm_creditfooter"></tr>
                                            </tfoot>
                                        </table>
                                         <!-------------------------------------------------------->
                                         <!-- <input class="form-control" name="cash_amt_cr" id="cash_amt_cr" type="number" required="" ><br> -->
                                         <button class="btn btn-warning" onclick="closePopup()">Cancel</button>
                                         <button type="submit" class="btn btn-primary pull-right" id="savec">Save</button>&nbsp;
                                     </form>
                                   <button class="btn btn-sm btn-warning" style="display:none" id="removeCash">Remove Cash</button>&nbsp;
                               </div>   
                                  <!-----------------------end popup---------------------------------------> 

                                    <!-------Over payment popup------------------------------------------>
                                <div  class="cust_popup" id="cash_over" style="display: none;width: 500px;">
                                   <h6 class="text-center">OVERPAYMENT LIST
                    <li class="help-icon">
                    <a href="#" onclick="tg_help()" style="margin-left:8px"><span class="icon1">?</span></a>
                   </li></h6><br>
                                     <form id="csh_proc_over" method="POST" autocomplete="off">
                                         <table class="table" >
                                            <thead>
                                                <tr>
                                                   <th>Type</th>
                                                   <th>Trans No</th>
                                                   <th>OverPayment</th>
                                                    <th>Balance</th>
                                                    <th>Use</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="choose_over">
                                            </tbody>
                                            <tfoot class="border-less">
                                                <tr id="itm_overfooter"></tr>
                                            </tfoot>
                                        </table>
                                        <br>
                                        <button class="btn btn-warning" onclick="closePopup_over()">Cancel</button>
                                         <button type="submit" class="btn btn-primary pull-right" id="saveo">Save</button>&nbsp;
                                     </form>
                                   <!-- <button class="btn btn-sm btn-warning" style="display:none" id="remo veCash">Remove Cash</button>&nbsp; -->
                               </div>  

                                  <!-----------------------end over popup--------------------------------------------> 
                                <hr>
                                <div class="row">
                                    <!-- <div class="col-md-6">
                                     
                                     <button type="button" class="btn btn-primary" onclick="tg_patacct()"  >Account</button>
                                   <button type="button" class="btn btn-primary">Cheque</button>
                                    </div> -->
                                    <div class="col-md-12">
                                        <form id="payment_panel">
                                               
                                <div class="form-group row" id="ledgerRow" style="display: none;" >
                                 <label for="staticEmail" class="col-sm-1 col-form-label"></label>
                                 <label for="staticEmail" class="col-sm-3  col-form-label"> Ledger</label>
                                <div class="offset-md-6 col-sm-1">
                                 <input type="text" readonly class="form-control-plaintext" id="ledger_payed" value="900">
                                </div>
                                <div class="col-sm-1">
                                 <div id="legerRata">
                                 </div>    
                                <label style="margin-top: 10px;"><i  onclick="removePayment('')" class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="delete"></i></label>
                                                    </div>   
                                                   </div>

                    <!------------------credit row start here ------------------>
                         <div class="form-group row" id="ledgerRow" style="display: none;" >
                            <label for="staticEmail" class="col-sm-1 col-form-label"></label>
                            <label for="staticEmail" class="col-sm-3  col-form-label"> Ledger</label>
                             <div class="offset-md-6 col-sm-1">
                             <input type="text" readonly class="form-control-plaintext" id="ledger_payed" value="900">
                                </div>
                             <div class="col-sm-1">
                             <div id="legerRata">
                             </div>    
                             <label style="margin-top: 10px;"><i  onclick="removePayment('')" class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="delete"></i></label>
                                </div>   
                                    </div>
                                            <!--<div class="form-group row"  >
                                                <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label">Amount Due</label>
                                                <div class="offset-md-6 col-sm-1">
                                                  <input type="text" readonly class="form-control-plaintext" id="amount_due" value="0">
                                                </div>
                                                <div class="col-sm-1">
                                                </div>   
                                              </div>
                                                -->
                                            <div class="form-group row" style="display: none;" id="change_row">
                                                <label for="staticEmail" class="col-sm-3 offset-md-1 col-form-label text-danger">Over Payment</label>
                                                <div class="offset-md-6 col-sm-1 text-danger">
                                                  <input type="text" readonly class="form-control-plaintext text-danger" id="amount_change" value="" disabled>
                                                </div>
                                                <div class="col-sm-1">
                                                </div>   
                                              </div>
                                        
                                        </form>       
                                    </div>
                                    <div class="col-md-2">
                                         <button type="button" class="btn btn-primary pull-left" onclick="tg_cash()"> Add Payment</button>
                                     </div>
                              
                              <!----credit note button--------------------------------->
                                     <div class="col-md-2" id="seen1">
                                         <button type="button" disabled class="btn btn-primary pull-left" id="another" onclick="tg_cashNote()"> Use Credit Note</button>
                                     </div>
<!-- 
                                <div class="col-md-2" id="new1">
                                <button type="button" class="btn btn-primary pull-left btn-title"  onclick="tg_notification(1)" title="New">
                                   Use Credit Note
                                </button>
                                </div> -->
                         <!----credit note button---end------------------------------>
                        <!----start use Over Payment btn------------------------------>

                                    <div class="col-md-2" id="seen2">
                                         <button type="button" disabled class="btn btn-primary pull-left" id="over-btn" onclick="tg_overpay()"> Use Over Payment</button>
                                    </div>
                                     
                             <!--    <div class="col-md-2" id="new2">
                                <button type="button" class="btn btn-primary pull-left btn-title"  onclick="tg_notification(2)" title="New">
                                    Use Over Payment
                                </button>
                                </div> -->
                    <!----end use Over Payment btn------------------------------>

                                </div> 
                            </div>

                            <div class="card-footer">
                               
                                <button type="button" id="finishReceipt" class="btn btn-primary pull-right" onclick="finish_receipt()">Finish</button>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                </div>
                </div>
            
        </div>

        <script type="text/javascript">
                         
                            $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });

     $('#ReceiptResult').submit(function (e) {
             if (!$('#daterange-btn span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#receipt').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-btn span').html();
            //alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/receiptdata'; ?>',

                data: dta,
                success: function (res) {
                    $('#receipt').html(res);
                },
                error: function () {
                    $('#receipt').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

            }
        e.preventDefault();
    });
      $("#paid_by").change(function(){
    
        $('#payer_name_row').show();
        $('#payer_details').html('');
    });

     function search_payer(){
       if($('#paid_by').val() == "") {
           swal("warning","Please Select Paid By","warning");
       }else if($('#payer_name').val() == ""){
          swal("warning","Please Enter Payer Name","warning"); 
       }else{
            var paydata = 'paid_by=' + $('#paid_by').val() + "&payer_name=" + $('#payer_name').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillController/search_payer'; ?>',
                beforeSend: function () {
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#customer_loaded').html(result); 
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');;
               }
            });
           }
       
    }

    ////////////////// select payerdetails /////////////
    function select_payer(id,payer_name){
       var payer = id;
        $('#payer_id').val(payer);
        var payerdata = "payer=" + payer;
        //alert(payerdata);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillController/get_payer_details'; ?>',
            data: payerdata,
            success: function (res) {
                $('#payer_details').html(res);
                $('#payer_name_row').hide();
                $('#customer_loaded').html('');
            },
            error: function (){
                alert('error encounted');
            }
        });
    }

        </script>