<?php    
$billmodel = new App\Models\BillingModel();
 ?>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="card">
           <div class="table-responsive mt-3">
             <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <!-- <th>No.#</th> -->
                                    <th>Payment No.</th>
                                    <th>Payment Date</th>
                                    <th>Customer Name</th>
                                    <th>Name Type</th>
                                    <th>Amount</th>
                                    <th>Received By</th>
                                    <!--<th>sms Status</th>-->
                                    <th>Trans Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                             <?php foreach($trans as $tr):

                                $suppname = '';
                                $supId = $billmodel->get_item_name('ledger_transaction_tbl',$where =array('trans_no'=>$tr->trans_number,'trans_item'=>0));
                                $name = $billmodel->get_item_name('supplier_tbl',$where = array('supplier_id'=>$supId[0]->name_id));
                                $nametype = $billmodel->get_item_name('name_type_tbl', $where=array('id'=>$supId[0]->name_type_id));
                                $user = $billmodel->get_item_name('users', $where=array('user_id'=>$supId[0]->updated_by));
                                $receiver = $user[0]->first_name .' '.$user[0]->last_name;
                              ?>

                             <tr> 
                             <td><?= $tr->trans_number; ?></td>
                             <td><?= $tr->trans_date; ?></td>
                             <td><?= $name[0]->supplier_name; ?></td>
                             <td><?= $nametype[0]->name_type; ?></td>
                             <td><?= number_format($supId[0]->amount); ?></td>
                             <td><?= $receiver; ?></td>
                             <td><?= $tr->updated_date; ?></td>
                                  <td><a href="javascript:void(0)" onclick="manage_rec(<?php echo $tr->trans_number;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>
                                    <a href="javascript:void(0)" onclick="manage_receipt(<?php echo $tr->trans_number;?>)"  class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a>
                                    </td>
                            </tr>
                             <?php endforeach; ?>  
                            </tbody>
                        </table>
           </div>
        </div>
    </div>
</div>