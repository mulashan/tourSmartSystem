  <style type="text/css">

     .invoice > .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }
  

 </style>
 <?php
 helper('age');
  $billmodel = new App\Models\BillModel();
  $remodel =new App\Models\ReportsModel();
  $suppliermodel = new App\Models\SupplierModel();
  $leger_transaction = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>$inv[0]->trans_type_id));
  $supplier_name = "";
  $name_type = "";
  $ref="";
  $amount = 0;
  $phone="";

  if($leger_transaction[0]->name_type_id==1){
$suppl = $billmodel->get_item_name('students', $where = array('id'=>$leger_transaction[0]->name_id));
$student_parent = $billmodel->get_item_name('parents_students_tbl', $where = array('student_id'=>$leger_transaction[0]->name_id));
$parent=$billmodel->get_item_name('parents_tbl', $where = array('id'=>$student_parent[0]->parent_id));

$name = $suppl[0]->full_name;
$phone=$parent[0]->phone1;
$name_id = $leger_transaction[0]->name_id;
  }else if($leger_transaction[0]->name_type_id==2){
$suppl = $billmodel->get_item_name('supplier_tbl', $where = array('supplier_id'=>$leger_transaction[0]->name_id));
$name = $suppl[0]->supplier_name;
  }else if($leger_transaction[0]->name_type_id == 7){
        $app = $billmodel->get_item_name('users',$where = array('user_id'=>$leger_transaction[0]->name_id));
        $name = $app[0]->first_name.' '.$app[0]->last_name;
        $name_id = $leger_transaction[0]->name_id;
        $student_id = $app[0]->user_id;
        $type_name = $billmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $phone=$app[0]->phone_no;
       
   } elseif($leger_transaction[0]->name_type_id == 8){
    $govern = $billmodel->get_item_name('government_tbl',$where = array('institution_id'=>$leger_transaction[0]->name_id));
        $name = $govern[0]->institution_name;
        $name_id = $leger_transaction[0]->name_id; 

   }
  else{
$name="";
  }
  
  
  $name_type_id = $billmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
  $billref = $billmodel->get_item_name('transaction_other_details_tbl',$where = array('transaction_no'=>$inv[0]->trans_number));
    

     $rlt = $billmodel->get_item_name('voucher_relation_tbl', $where = array('payment_no' => $inv[0]->trans_number));
            
            $v_type = $billmodel->get_item_name('voucher_types_tbl', $where = array('id' => $rlt[0]->voucher_type));


  $v_transaction = $billmodel->get_item_name('voucher_relation_tbl',$where = array('payment_no' =>$inv[0]->trans_number)); 
//   print_r($v_transaction);
//   return;

 ?>
<div class="row">
<!-------------------- Bill Information starts here  ------------------>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Payee Information</h5>
            </div>
            </hr>

            <div class="card-body">
                
                <input type="hidden" name="supplier_name" id="supplierid" value="<?= $inv[0]->trans_number;?>">
                <table class="table table-borderless">
                    <tr>
                        <th>Pay Voucher No:</th>
                        <td><?= $inv[0]->trans_number; ?></td>
                    </tr>
                     <tr>
                        <th>Voucher Type:</th>
                        <td><?= $v_type[0]->voucher_type_name??"";?></td>
                    </tr>
                    <tr>
                        <th>Voucher Date:</th>
                        <td><?= $inv[0]->trans_date; ?></td>
                    </tr>
                     <tr>
                        <th>Payee:</th>
                        <td><?= $name; ?></td>
                    </tr>
                    <tr>
                        <th>Name Type:</th>
                        <td><?= $name_type_id[0]->name_type; ?></td>
                    </tr> 
                    
                    <tr>
                        <th> Phone no:</th>
                        <td><?= $phone??""; ?></td>
                    </tr>
                   
                </table>
            </div>
    </div>
</div>
 <!-------------------- Payment History starts here  ------------------>

    <?php
   // $databaseName=session()->get('school');
     $dbname=session()->get('db_name');
    $db = \Config\Database::connect($dbname);
                        $total =0;
                        $amount = 0;
                        $query = $db->query('SELECT item_transation_tbl.item_id,item_name,account_name,trans_number,quantity,unit_price FROM item_transation_tbl,items_tbl,items_ledgers_tbl,accounts_tbl where item_transation_tbl.item_id = items_tbl.id AND items_ledgers_tbl.item_id = items_tbl.id AND item_transation_tbl.trans_type = 4 AND accounts_tbl.id = items_ledgers_tbl.account_id AND trans_number='.$inv[0]->trans_number);
                        $result = $query->getResult();

                        foreach($result as $itm){
                            $dat = $billmodel->get_trans_type($inv[0]->trans_number);
                             $query2 = $db->query('SELECT type_name,amount FROM ledger_transaction_tbl,account_types_tbl where ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_transaction_tbl.trans_type = 4 AND (ledger_type = 10) AND trans_no='.$inv[0]->trans_number);
                             $result2 = $query2->getResult();
                             $amount = $itm->amount;
                           
                            $total += $amount;
                             }
          ?>
     <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Related Transactions</h5>
            </div>
            </hr>

            <div class="card-body">

                 <!-- image attachment pop up -->
      <div class="cust_popup_lg" id="Attchmnt2" style="display:none">
                    <a href="javascript:void(0)" class="pull-left" onclick="CloseAttachmnt2()"><i class="fa fa-times"></i></a>
                  <div id="ViewAttachment" class=""></div>
                    <br>                   
                    <!-- <a href="javascript:void(0)" class="btn btn-danger btn-xs pull-right" onclick="DeleteAttachmnt()">Delete</a> -->
                </div>
                <table class="table" id="paytable">
                    <thead>
                                <tr>
                                    
                                    <th>Trans Type</th>
                                    <th>Trans No</th>
                                   <th class="">Date</th>
                                    <th>Amount</th>
                                    <th>Trans by</th>
                                    <th width="100px">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                          <?php
                          $receipt=array();
                          $pocketMoney = $billmodel->get_item_name('pocket_money_transaction_tbl',$where = array('transaction_no' =>$inv[0]->trans_number,)); 
                          $control = $billmodel->get_item_name('control_number_charges_payments_tbl',$where = array('trans_no' =>$inv[0]->trans_number,)); 
                           $v_transaction = $billmodel->get_item_name('voucher_relation_tbl',$where = array('payment_no' =>$inv[0]->trans_number)); 
                          if(count($pocketMoney)>0 || count($control)>0){
                             echo "<tr><td></td>
                             <td colspan='3'>No related transactions</td></tr>";
                             }else if($v_transaction[0]->trans_type==0){
                                  echo "<tr><td></td>
                             <td colspan='3'>No related transactions</td></tr>";
                             }
else if($v_transaction[0]->voucher_type==8){
                                  echo "<tr><td></td>
                             <td colspan='3'>No related transactions</td></tr>";
                             }
                             else{
                          
                         //print_r($v_transaction);
                          
                          if($v_transaction[0]->trans_type==2){

                         $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type,'ledger_id'=>$leger_transaction[0]->ledger_id));

                          $receipt = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type,'ledger_type'=>9));

                         if($leger_transaction[0]->ledger_id==21){
                        $trans_type="Overpayment";
                         }else{
                         $trans_type="Receipt";
                         $receipt=array();
                         }
                        
                         $trans_type2="Receipt";
                        

                          }else{
                          $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type)); 
                          
                          if(count($bala_amount)==0){
                             $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>5));  
                          }
                          $traType = $billmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>5));  
                          $trans_type=$traType[0]->type_name;
                             }
                        //  echo $v_transaction[0]->trans_no.'-/-'.$v_transaction[0]->trans_type;
                        //  print_r($traType);
                        // return;
                        $transNumber = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$v_transaction[0]->trans_no,'trans_type_id'=>$v_transaction[0]->trans_type));
                        if(count($transNumber)>0){
                        $traBy = $billmodel->get_item_name('users',$where = array('user_id' =>$transNumber[0]->updated_by));
                        $fullname=$traBy[0]->first_name." ".$traBy[0]->last_name;
                        }else{
                             $transNumber = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$v_transaction[0]->trans_no,'trans_type_id'=>5));
                         $fullname="";   
                        }
                           ?>
                            <tr>
                                <td>   <?=$trans_type??""?></td>
                                <td><?=$v_transaction[0]->trans_no??""?></td>
                                 <td><?=date('Y-m-d',strtotime($transNumber[0]->trans_date))??""?></td>
                            <td class="text-right"><?=number_format($bala_amount[0]->amount)??""?></td>
                            <td><?=$fullname;?></td>
                            <td class="text-left">
                                <?php
                               if($v_transaction[0]->trans_type==2){
                                ?>
                              <button type="button" class="btn btn-primary btn-sm"  onclick="manage_receipt('<?=$transNumber[0]->id;?>')"><i class="fa fa-eye"></i> </button> 
                                 <?php
                               }else if($v_transaction[0]->trans_type==4){

                          $billattch = $billmodel->get_item_name('transaction_attachments_tbl',$where = array('transaction_number'=>$v_transaction[0]->trans_no));
                                ?>
                             <button type="button" class="btn btn-primary btn-sm"  onclick="manage_bill('<?=$inv[0]->id;?>')"><i class="fa fa-eye"></i> </button>
                             <?php
                             if(count($billattch)>0){
                             ?>
                          <button type="button" class="btn btn-primary btn-sm"  onclick="view_attachement('<?=$billattch[0]->image_attachment;?>')"><i class="fa fa-arrow-up"></i> </button>
                               <?php
                           }
                                  }
                               else{

                                ?>
                                <button type="button" class="btn btn-primary btn-sm"  onclick="manage_credit('<?=$transNumber[0]->trans_number;?>')"><i class="fa fa-eye"></i> </button>
                            <?php } ?>
                            </td>
                            </tr>
                            <?php 
                           if(count($receipt)>0){
                            ?>
                      <tr>
                                <td><?=$trans_type2??""?></td>
                                <td><?=$receipt[0]->trans_no??""?></td>
                                <td><?=date('Y-m-d',strtotime($transNumber[0]->trans_date))??""?></td>
                            <td class="text-right"><?=number_format($receipt[0]->amount)??""?></td>
                            <td><?=$fullname?></td>
                            <td>
                                <button type="button" class="btn btn-primary btn-sm"  onclick="manage_receipt('<?=$transNumber[0]->id;?>')"><i class="fa fa-eye"></i> </button>
                            </td>
                            </tr>
                            <?php
                           }
                       }
                            ?>
                           
                        </tbody>
                </table>
             </div>
     </div>
 </div>
</div>
</div>

<!-------------------- Charged Items starts here --------------------->
<div class="row">
    <div class="col-md-12">
        <div class="card  invoice">
            <div class="card-header">
                <h5>Payment Details</h5>
                
            </div>
            </hr>

            <div class="card-body">
                <div class="table-responsive">
                <table class="table">
                    <thead>
                        <?php 
                        if(count($pocketMoney)==0 && $v_transaction[0]->trans_type!=0 &&  count($control)==0){
                            ?>
                        <tr>
                          
                            <th>Trans Type</th>
                              <th>Type</th>
                            <th>Trans Date</th>
                            <th class="">Trans No</th>
                            <th>Name</th>
                            <th class="text-center">Amount</th>
                               <?php
                             if($v_transaction[0]->voucher_type !=8){
                            ?>
                            <th>Balance</th>
                            <th>Paid</th>
                                  <?php
                       }?>
                        </tr>
                         <?php 
                           }else if($v_transaction[0]->trans_type==0){
                            ?>
                             <tr>
                          
                            <th>Trans Type</th>
                              <th>Type</th>
                            <th>Trans Date</th>
                            <th class="">Trans No</th>
                            <th>Name</th>
                              <?php
                             if($v_transaction[0]->voucher_type !=8){
                            ?>
                            <th class="text-center">Amount</th>
                            
                            <th>Balance</th>
                           <?php
                       }?>
                            <th></th>
                        </tr>
                            <?php
                            }else if(count($pocketMoney)>0){
                            ?>
                          <tr>
                                     
                                    <th>#</th>
                                     <th>Student Name</th>
                                    <th>DOB</th>
                                    <th>Age</th>
                                    <th>Level</th>
                                    <th>Class</th>
                                    <th>Stream</th>
                                    <th>Hostel</th>
                                    <th class="text-right">P/money Bal</th>
                                    <th class="text-right">Paid</th>
                                  
                                    <th></th>
                         </tr>
                           <?php
                            } else if(count($control)>0){
                            ?>
                        
                             <tr>
                                     
                                    <th>#</th>
                                      <th>Rct No.</th>
                                        <th>inv type.</th>
                                        <th>trans. Date</th>
                                       <th>Student Name</th>
                                        <th>control No</th>
                                      
                                        <th class="text-right">charged</th>
                                        
                                        <th class="text-right">Paid</th>
                                  
                                        <th></th>
                         </tr>
                         <?php }?>
                    </thead>
                    <tbody id="">
                        <?php
                        $total =0;
                        $amount = 0;
                        $original_amount = 0;
                         if(count($pocketMoney)==0  && $v_transaction[0]->trans_type!=0 && count($control)==0){
                         $v_transaction = $billmodel->get_item_name('voucher_relation_tbl',$where = array('payment_no' =>$inv[0]->trans_number,));                          
                          if($v_transaction[0]->trans_type==2){
                          $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type,'ledger_id'=>$leger_transaction[0]->ledger_id));
                         if(count($bala_amount)>0){
                        $original_amount=$bala_amount[0]->amount;
                         }
                         if($leger_transaction[0]->ledger_id==21){
                        $trans_type="Overpayment";
                         }else{
                         $trans_type="Receipt";
                         }
                          }
                          else{
                          $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>$v_transaction[0]->trans_type)); 
                          if(count($bala_amount)>0 && $bala_amount[0]->name_type_id==7){
                            $transaction_number=$v_transaction[0]->trans_no;
                            $staff_id=$bala_amount[0]->name_id;
                            if($v_transaction[0]->voucher_type==8){
                      $original_amount=$bala_amount[0]->amount;
                            }else{
                         $net_salar = $billmodel->get_staff_netsalary($transaction_number,$staff_id);
                         if(!empty($net_salar)){
                        $original_amount=$net_salar->net_salaries;
                         }else{
                             $original_amount=0;
                         }
                         
                            }
                   
                            
                            
                          }else{
                            $original_amount=$bala_amount[0]->amount ?? 0;
                          }
                          if(count($bala_amount)==0){
                               $bala_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$v_transaction[0]->trans_no,'trans_type'=>5)); 
                          }
                          $traType = $billmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>$v_transaction[0]->trans_type));  
                          $trans_type=$traType[0]->type_name;
                          }
                         
                  
                        $paid = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>5,'transation_nature'=>2));

                        $invType = $billmodel->get_item_name('invoice_type_transaction',$where = array('trans_no' =>$v_transaction[0]->trans_no,'transaction_type_id'=>$v_transaction[0]->trans_type));
                        if(count($invType)==0){
                            $invType = $billmodel->get_item_name('invoice_type_transaction',$where = array('trans_no' =>$v_transaction[0]->trans_no,'transaction_type_id'=>5));
                        }
                     if(isset($invType) && !empty($invType)){
                        $invTypeName = $billmodel->get_item_name('invoice_types_tbl',$where = array('id' =>$invType[0]->invoice_type_id));

                         $transType = $billmodel->get_item_name('transaction_types_tbl',$where = array('type_id' =>5));

                         $transNumber = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$v_transaction[0]->trans_no,'trans_type_id'=>$v_transaction[0]->trans_type));
                         $type_names=$invTypeName[0]->type_name??"";
                        $trans_date= $transNumber[0]->trans_date??"";
                        }
                        else{

                         $transNumber = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$v_transaction[0]->trans_no,'trans_type_id'=>$v_transaction[0]->trans_type));

                           if($v_transaction[0]->voucher_type==8){
                             $type_names='Salary Advance';
                           }else{
                            $type_names="Payroll";

                           }
                       $trans_date= $transNumber[0]->trans_date??""; 
                        }

                           ?>
                         <tr>
                            
                             <td><?=$trans_type?? ""; ?></td>
                             <td><?=$type_names; ?></td>
                             <td><?=$trans_date; ?></td>
                             <td class=""><?= $v_transaction[0]->trans_no??""; ?></td>
                            <td><?= $name??""; ?></td>
                            <td class="text-right"><?= number_format($original_amount)??""; ?></td>
                            <?php
                             if($v_transaction[0]->voucher_type !=8){
                            ?>
                            <td  class="text-right"><?= number_format($paid[0]->balance)??""; ?></td>
                            <td  class="text-right"><?= number_format($paid[0]->amount)??""; ?></td>
                           <?php
                       }?>

                         </tr>
                     <?php }else if($v_transaction[0]->trans_type==0 && count($control)==0){
                          $invType = $billmodel->get_item_name('invoice_type_transaction',$where = array('trans_no' =>$v_transaction[0]->payment_no,'transaction_type_id'=>5));
                         // echo $v_transaction[0]->trans_no;
                        //print_r($invType);

                        $invTypeName = $billmodel->get_item_name('invoice_types_tbl',$where = array('id' =>$invType[0]->invoice_type_id));
                        $recharge_amount = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_type' =>5,'trans_no'=>$v_transaction[0]->payment_no));
                        $sms_balance = $billmodel->get_item_name('messages_balances',$where = array('balance !=' =>""));
                         $transNumber = $billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$v_transaction[0]->payment_no,'trans_type_id'=>5));
                        ?>
                     <tr>
                            
                              <td><?= "Sms Recharge"; ?></td>
                               <td><?= $invTypeName[0]->type_name??""; ?></td>
                             <td><?= $transNumber[0]->trans_date??""; ?></td>
                             <td class=""><?= $v_transaction[0]->payment_no??""; ?></td>
                            <td><?= $name??""; ?></td>
                            <td><?= number_format($recharge_amount[0]->amount)??""; ?></td>
                            <td><?= number_format($sms_balance[0]->balance)??""; ?></td>
                           
                             </tr>
                    <?php
                     }else if(count($pocketMoney)>0){
                      $total_given=0;
                      $k=0;
                       foreach($pocketMoney as $pm){
                     $dbal = $remodel->refund_pocket_money($pm->student_id);
                     $collected=0;
                     $usedAmount=0;
                    foreach($dbal as $pmn){
                        $check_y=$billmodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $pmn->trans_no,'trans_type_id'=>3,'status'=>1,'trans_desc !='=>""));
                                 if(count($check_y)>0){
                            $collected+=$pmn->amount;

                            }
                            }
                                 
                         // $invType = $billmodel->get_item_name('invoice_type_transaction',$where = array('trans_no' =>$pmn->trans_no,'transaction_type_id'=>3));
                          // $invTypeName = $billmodel->get_item_name('invoice_types_tbl',$where = array('id' =>$invType[0]->invoice_type_id));
                          // $trans_type="Deposit";
                        
                         $student = $billmodel->get_item_name('students',$where = array('id' =>$pm->student_id));
                         $adms = $billmodel->get_item_name('admission_tbl',$where = array('student_id' =>$pm->student_id,'academic_year'=>$pm->academic_year));
                         $level=$billmodel->get_item_name('class_level_tbl',$where = array('id' =>$adms[0]->level_id));
                         $class=$billmodel->get_item_name('classes_tbl',$where = array('id' =>$adms[0]->class_id));
                        $stream=$billmodel->get_item_name('streams_tbl',$where = array('id' =>$adms[0]->stream_id));
                         $hostel=$billmodel->get_item_name('hostel_tbl',$where = array('id' =>$adms[0]->hostel_id));
                            
                             $check_used = $billmodel->get_item_name('pocket_money_transaction_tbl', $where = array('student_id' => $pm->student_id,'academic_year'=>$pm->academic_year));

                                if(count($check_used)>0){
                                  foreach($check_used as $used){
                                 $usedAmount+=$used->amount_given;    
                                
                                  }
                                 }
                          $balance0=$collected-$usedAmount;
                         $balance=$pm->p_balance;
                         $total_given+=$pm->amount_given;
                         $k++;
                        ?>
                       <tr>
                            
                              <td><?=$k; ?></td>
                              <td><?= $student[0]->full_name??""; ?></td>
                               <td><?= $student[0]->birth_date??""; ?></td>
                               <td><?= findAge($student[0]->birth_date)??""; ?></td>
                             <td><?php echo $level[0]->level_name;?></td>
                            <td><?php echo $class[0]->class_name;?></td>
                            <td><?php echo $stream[0]->stream_name;?></td>
                             <td><?php echo $hostel[0]->hostel_name;?></td>
                            <td class="text-right"><?php echo number_format(($balance));?></td>
                            <td class="text-right"><?= number_format($pm->amount_given)??""; ?></td>
                           

                         </tr>
                     <?php 
                       
                       }
                    ?>
                  <tr>
                      <td colspan="8"></td>
                      <td><b>Total</b></td>
                      <td class="text-right"><b><?= number_format($total_given)??""; ?></b></td>
                  </tr>
                   
                    <?php
                     }else if(count($control)>0){

                        $n=0;
                        $total_charged=0;
                        foreach($control as $p){
                        $invtbl=$billmodel->get_item_name('invoice_type_transaction',$where = array('trans_no' =>$p->inv_no)); 
                         $invType=$billmodel->get_item_name('invoice_types_tbl',$where = array('id' =>$invtbl[0]->invoice_type_id));
                          $trans=$billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$p->rct_no,'trans_type_id'=>2));

                          if($p->name_type_id==1){
                         $names=$billmodel->get_item_name('students',$where = array('id' =>$p->student_id));
                          }
                          if($p->name_type_id==4){
                         $names=$billmodel->get_item_name('students_application_tbl',$where = array('id' =>$p->student_id));   
                          }
                    $ctr=$billmodel->get_item_name('payment_request',$where = array('trans_no' => $p->inv_no,'student_id'=>$p->student_id,'trans_type'=>1));
                     $charges=$billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $p->rct_no,'ledger_id'=>22,'trans_type'=>2));   
                      $n++;
                      $total_charged+=$p->amount;
                      ?>
                        <tr>
                            
                      <td><?=$n; ?></td>
                      <td><?= $p->rct_no??""; ?></td>
                       <td><?= $invType[0]->type_name??""; ?></td>
                       <td><?= $trans[0]->trans_date??""; ?></td>
                       <td><?= $names[0]->full_name??""; ?></td>
                       <td><?= $ctr[0]->reference_no??""; ?></td>
                       <td class="text-right"><?= number_format($charges[0]->amount)??""; ?></td>
                       <td class="text-right"><?= number_format($p->amount)??""; ?></td>
                        </tr>
                     <?php
                        }
                        ?>
                    <tr>
                      <td colspan="6"></td>
                      <td><b>Total</b></td>
                      <td class="text-right"><b><?= number_format($total_charged)??""; ?></b></td>
                  </tr>
                        <?php
                       }
                     ?>
                    
                    </tbody>
                </table>
</div>
            </div>

        </div>

        <!--------$name="AUGUST MARTIN NJAU";---------- here payment information 
           
starts---->
        <?php $bill = $billmodel->billdata($inv[0]->trans_number,$inv[0]->trans_type_id); ?>
        <?php  $Initiator= $billmodel->get_initiator_name($bill[0]->app_id); ?>
        <div class="row">
        <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Approval History</h5>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               
                <label>Approval Status:</label>
                <?php 
                //$id_trans = $inv[0]->trans_number;
                $checker = 0;
               foreach($Initiator as $dat){
                if($dat->user_role =='3' && $dat->hstatus=='1')
                {
                    $checker =1;
                }
                elseif($dat->user_role =='3' && $dat->hstatus=='2'){
                    $checker =2;
                }
               }
                if($checker ==1)
                {
                     echo  '<label style="color:green;">  &nbsp;&nbsp; <strong>Approved! </strong></label>';
                 }
                 elseif($checker ==2){
                     echo  '<label style="color:red;">  &nbsp;&nbsp; Rejected! </label>';
                 }
                 else{
                echo'<label style="color:red;">  &nbsp;&nbsp; Pending! </label>';
                 }

                
                 ?>
                <div id="feedback"></div>
            </div>
            </hr>
        
     <?php $hist_data = $billmodel->getdatabill($bill[0]->app_id); ?>
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Entry Date:</th>
                        <th>Comment:</th>
                        <th>Name:</th>
                        <th>User Role:</th>
                        <!-- <th>Status:</th> -->
                    </tr>
                    <?php foreach($hist_data as $in): ?>
                    <tr>
                        <td><strong><?=$in->hist_date; ?></strong></td>
                        <td class="text-primary"><?= $in->comment; ?></td>
                        <td>
                            <?= $in->first_name.' '.$in->last_name; ?>
                        </td>
                        <td><?php if($in->user_role == '1'){
                            echo "Initiator";
                        }elseif($in->user_role == '2'){
                            echo "Checker";
                        }elseif($in->user_role == '3'){
                            echo "Approver";
                        }else{

                        } ?></td>
                        <td></td>
                    </tr>
                       <?php endforeach; ?>
                </table>
            </div>
        </div>
    </div>

        <!------------------ here accounts receivable ------------------->
        <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Effected ledgers</h5>
            </div>
            </hr>
           <div class="card-body">
                <table class="table" style="border:1px solid black;">
                   <tr style="border:1px solid black;">
                       <th style="border:1px solid black;">Ledger name</th>
                       <th style="border:1px solid black;">Debit</th>
                       <th style="border:1px solid black;">Credit</th>
                   </tr>
                    <tbody style="border:1px solid black;">
                        <?php 
                          
                    $ledger1 = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>5,'transation_nature'=>2));
                    $ledger2 = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>5,'transation_nature'=>1));
                    $ledger11=$billmodel->get_item_name('accounts_tbl',$where = array('id' =>$ledger1[0]->ledger_id));

                    $ledger22=$billmodel->get_item_name('accounts_tbl',$where = array('id' =>$ledger2[0]->ledger_id));
                        ?>
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;"><?=$ledger11[0]->account_name??""?></td>  
                          <td class="text-right" style="border:1px solid black;"><?=number_format($ledger1[0]->amount)??""?></td>  
                          <td style="border:1px solid black;"><?=""?></td>  
                        </tr>
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;"><?=$ledger22[0]->account_name??""?></td> 
                          <td style="border:1px solid black;"><?=""?></td>   
                          <td class="text-right" style="border:1px solid black;"><?=number_format($ledger2[0]->amount)??""?></td>  
                          
                        </tr>
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;"><b>Total<b></td> 
                          <td class="text-right" style="border:1px solid black;"><b><?=number_format($ledger1[0]->amount)??""?></b></td>   
                          <td class="text-right" style="border:1px solid black;"><b><?=number_format($ledger2[0]->amount)??""?></b></td>  
                          
                        </tr>

                        
                    </tbody>
                </table>

            </div>
        </div>
</div>
</div>
</div>
<!----------------------------- supporting documents --------------------------->
<div class="row">
 <div class="col-md-6">
        <div class="card invoice">
            
        </div>
    </div>
     <div class="col-md-6">
        <div class="card invoice">
            
        </div>
    </div>
</div>
<div class="row">
    <?php if($vocher!=1 && count($advances)==0){?>
<div class="col-md-12">
   
    <button type="button" class="btn btn-success  float-right ml-3 ApprovalId" data-id="<?= $inv[0]->trans_number; ?>">Approve</button>
    <button type="button" class="btn btn-warning  float-right RejectId" data-id="<?= $inv[0]->trans_number; ?>">Reject</button>
  

</div>
  <?php }?>

</div>
<!-----------------for msg------------------>
<div class="col-md-6">
            <div class="card msg">
             <div class="card-header">
                <h5>Message Information</h5>
            </div>
            <hr>
           <?php
           $paid = $billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$inv[0]->trans_number,'trans_type'=>5,'transation_nature'=>2));
           $bll=$inv;

            $msg_grp = $billmodel->get_item_name('message_groups_tbl',$where = array('message_type'=>14,'trans_number'=>$bll[0]->trans_number));
          $msg = "";
          $status='';
          if(count($msg_grp)>0){
              $m = $billmodel->get_item_name('messages',$where = array('send_no'=>$msg_grp[0]->send_number));
                       
                         if(count($m) > 0){
                            $msg = $m[0]->message;
                            $msg= str_replace(array("\r","\n"),' ',$msg);
                          if($m[0]->sent_status == 1) {
                           $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description;
                          }elseif($m[0]->sent_status == 2){
                            $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description." <br>Delivered Date: ".$m[0]->time_delivered;
                          }
                        }
                    }
                      //print_r($bll);
             if($msg==""){
            $status="<span class='text-red'>Not Sent</span>";

         $msg = "Voucher ".$bll[0]->trans_number." to ".$name." for ".number_format($paid[0]->amount)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
                }

              // print_r($bll);
                   ?>
                
          
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Message:</th>
                        <td id="msg"><?= $msg; ?> </td>
                    </tr>
                    <tr>
                        <th>Status:</th>
                        <td id="msg"><?= $status; ?> </td>
                    </tr>
                    

                </table>
            </div>
            </div>
        </div>
        <div class="col-md-6">
            <?php
if(isset($advances) && !empty($advances)){
            ?>
            <div class="card">
            <div class="card invoice">
              <div class="card-header">
                <h5>Repayment Schedule</h5>
            </div>
            </div>
            <div class="card-body">
                                       <table class="table" style="border:1px solid black;">
                                        <thead>
                   <tr style="border:1px solid black;">
                       <th style="border:1px solid black;">Payroll Year</th>
                       <th style="border:1px solid black;">Payroll Month</th>
                       <th style="border:1px solid black;">Amount</th>
                   </tr>
                   </thead>
                    <tbody style="border:1px solid black;">
                        <?php 
                        $total_advance=0;
                          foreach ($advances as $data){
                               $total_advance+=$data->advance_amount;
                        ?>
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;"><?=$data->payroll_year??""?></td>  
                           <td style="border:1px solid black;"><?=$data->month??""?></td>  
                          <td class="text-right" style="border:1px solid black;"><?=number_format($data->advance_amount)??""?></td>  
                         
                        </tr>
       <?php
   }
       ?>

                        
                    </tbody>
                    <tfoot>
                        <tr style="border:1px solid black;">
                        <td style="border:1px solid black;" colspan="2" class="fw-bold"><b>Total</b></td>
                        <td class="text-right fw-bold" style="border:1px solid black;"><?= number_format($total_advance);?></td>
                        </tr>
                    </tfoot>
                </table>
                
            </div>
            <?php
        }?>
        </div>
        </div>
        <div class="row">
    <?php if($vocher!=1 && count($advances)>0){?>
<div class="col-md-12">
   
    <button type="button" class="btn btn-success  float-right ml-3 ApprovalId" data-id="<?= $inv[0]->trans_number; ?>">Approve</button>
    <button type="button" class="btn btn-warning  float-right RejectId" data-id="<?= $inv[0]->trans_number; ?>">Reject</button>
  

</div>
  <?php }?>

</div>
<!-----------------end for msg------------------>

  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Add Comment</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <!-- <div id="Viewrejected"></div> -->
          <form class="form-group" id="RejectComment">
              <div class="form-group">
                  <textarea class="form-control" name="comment" id="comment">
                      
                  </textarea>
              </div>
              <button type="button" class="btn btn-primary" id="savecomment">Submit</button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="viewreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="close_rept()">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('viewreceipt_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
<!-- ------manage invoice modal------- -->
<div class="modal fade" id="viewinvoice" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"  style="z-index: 1400;">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5>Credit Note Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewinvoice_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printJS('invoicePrint_content', 'html')"><i class="fa fa-print"></i> Print</button> -->
        <!-- <button type="button" class="btn btn-primary"  data-toggle="modal" data-target="#invoiceprint" onclick="invoice_print()"><i class="fa fa-print"></i> Print</button> -->
        <button type="button" class="btn btn-primary"  data-toggle="modal" onclick="invoice_print()"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="view_voucher" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" onclick="close_printout()"aria-label="Close"></button>
      </div>
      <div class="modal-body" id="voucher_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="close_printout()">Close</button>
          <button type="button" class="btn btn-primary" onclick="printable_voucher2('voucher_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
    <div class="modal fade" id="paymentModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Print slip</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Viewpayment"></div>

        </div>
        <div class="modal-footer">
           <button type="button" class="btn btn-primary" onclick="printable_voucher()"><i class="fa fa-print"></i> Print</button>
        </div>
      </div>
      
    </div>
  </div>

   <script type="text/javascript">
    var transId='<?php echo $inv[0]->id;?>';
 $('#voucher_content').load('<?= base_url('/index.php/BillController/view_voucher')?>/'+transId);
 function close_printout(){
    $('#view_voucher').modal('hide');
 }
 function manage_bill(inv){
        //alert(inv);
      $('#viewreceipt').modal('show');
       $('#viewreceipt_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      $('#viewreceipt_content').load('<?= base_url('/index.php/BillController/view_voucher')?>/'+inv);
    }

    function manage_receipt(inv){
        //alert(inv);
      $('#viewreceipt').modal('show');
       $('#viewreceipt_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      $('#viewreceipt_content').load('<?= base_url('/view_receipt')?>/'+inv);
    }

    function manage_credit(inv){
        //alert(inv);
         $('#viewreceipt').modal('show');
       $('#viewreceipt_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      $('#viewreceipt_content').load('<?= base_url('/print_note')?>/'+inv);
      // $('#viewinvoice').modal('show'); 
      //  $('#viewinvoice_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      // $('#viewinvoice_content').load('<?= base_url('/view_note')?>/'+inv);
    }

    function CloseAttachmnt2() {
        $('#Attchmnt2').hide(100);
       
    }
       function displayImage(image_attachment)
       {
         $('#Attchmnt2').show(100);
        $('#ViewAttachment').html('<iframe src="<?php echo base_url() . '../public/transaction_files/'; ?>' + image_attachment + '" style="width:100%;height:500px"></iframe>');
                
       }
       //////////////////// for approved bill response ///////////////////////

       $(".ApprovalId").click(function(){
          var type='<?php echo $inv[0]->trans_type_id;?>';
        var data = "trans_number="+$(this).attr('data-id')+'&type='+type;
        $.ajax({
           
            type:"GET",
            url:"<?= base_url('/send_approved_data')?>",
            data:data,

            success: function (res){
                $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Congratulations!</strong> Bill Approved Successfully<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                  setTimeout(function(){
                        window.location.reload();
                    },1000)
               
            },
            error:function () {
                $('#feedback').html('<div class="alert alert-danger">Error! Couldn\'t Save data.</div>');
            }
        });
       });

       /////////////////// for rejected bill response ////////////////////////////
       $(".RejectId").click(function(){ 
         $('#myModal').modal('show');
        var type='<?php echo $inv[0]->trans_type_id;?>';
        var dat = "trans_number="+$(this).attr('data-id')+'&type='+type;
        //alert(data);
        $('#savecomment').click(function(){
        var data = "comment="+$('#comment').val()+"&"+dat;
            //alert(data);
      
         $.ajax({

            type:"GET",
            url:"<?= base_url('/send_rejected') ?>",
            data:data,
            success: function(res){
                 $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Congratulations! Bill Rejected Successfully</strong></div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                 
            },
            error: function ()
           {
            $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldn\'t Reject Bill.</strong></div>');
                // setTimeout(function(){
                // window.location.reload();
                // },1000)
            }
  });
         });
       });

 function CloseAttachmnt2() {
        $('#Attchmnt2').hide(100);
       
    }
       function view_attachement(image_attachment)
       {
       // alert(2);
         $('#Attchmnt2').show(100);
        $('#ViewAttachment').html('<iframe src="<?php echo base_url() . '../public/transaction_files/'; ?>' + image_attachment + '" style="width:100%;height:500px"></iframe>');
                
       }

               function view_payment(name) {
        $('#paymentModal').modal('show');
       var data=name;
        $.ajax({
            type: "POST",
            url: "<?= base_url('/get_slip_data')?>",
            data: {data:data},
            beforSend: function()
            {
                $('#Viewpayment').html();
            },
            success: function(res){
                $('#Viewpayment').html(res);
                 
            },
            error: function ()
            {

            }
        });
    };
   </script>

    
    

