  <style type="text/css">

     .invoice > .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }
  

 </style>
 <?php 
$bmodel = new App\Models\BillingModel();
    $comodel = new App\Models\CompanyModel();
    $smodel=new App\Models\StudentModel;
$classification = $smodel->gettable_data('classification_tbl',$where = array('id >' => 0));
$company = $bmodel->get_table_details('company_tbl');
 helper('results_helper');
?>

<style>
table.emoluments, th.emoluments{
   
    background-color: #d9ead3;
}table.emoluments, td.emoluments{
   
    background-color: #d9ead3;
}
table.social, th.social{
  
    background-color: #d9d9d9;
}
table.social, td.social{
  
    background-color: #d9d9d9;
}
table.tax, th.tax{
    
    background-color: #f9cb9c;
}table.net_salary, th.net_salary{
    
    background-color: #fed966;
}table.net_salary, td.net_salary{
    
    background-color: #fed966;
}
td{
    border: 1px solid black;
}
th{
    border: 1px solid black;
}
table.centa, th.centa{
    text-align: center;
}
table.paysummary, th.paysummary{
    border: 1px solid black;
}
</style>
 <?php
 helper('age');
  $billmodel = new App\Models\BillModel();
  $remodel =new App\Models\ReportsModel();
  $suppliermodel = new App\Models\SupplierModel();
// $v_type = $billmodel->get_item_name('voucher_types_tbl', $where = array('id' => $rlt[0]->voucher_type));
 ?>
<div class="row">
<!-------------------- Bill Information starts here  ------------------>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Payroll Information</h5>
            </div>
            </hr>

            <div class="card-body">
                
                <input type="hidden" name="supplier_name" id="supplierid" value="<?= $inv[0]->trans_number;?>">
                <table class="table table-borderless">
                    <tr>
                        <th>Pay Voucher No:</th>
                        <td><?= $payroll_data[0]->trans_number; ?></td>
                    </tr>
                     <tr>
                        <th>Voucher Type:</th>
                        <td><?=esc($voucher_type);?></td>
                    </tr>
                    <tr>
                        <th>Voucher Date:</th>
                        <td><?= $payroll_data[0]->trans_date; ?></td>
                    </tr>
                     <tr>
                        <th>Payroll Year:</th>
                        <td><?= $payroll_info[0]->payroll_year; ?></td>
                    </tr>
                    <tr>
                        <th>Payroll Month:</th>
                        <td><?= $payroll_info[0]->month; ?></td>
                    </tr> 
                                       
                </table>
            </div>
    </div>
</div>
 <!-------------------- Payment History starts here  ------------------>


</div>
</div>

<!-------------------- Charged Items starts here --------------------->
<div class="row">
    <div class="col-md-12">
        <div class="card  invoice">
            <div class="card-header">
                <h5>Payment Details</h5>
                
            </div>
            </hr>

            <div class="card-body">
           <div class="table-responsive">
        <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; font-family: Arial; font-size: 12px; text-align: right;" id="payroll_view_table">
    <thead>
        <tr>
                           <?php if (isset($company) && !empty($company)) {
                    if($company[0]->classification==1){
                ?>
            <th colspan="6" class="text-center">EMPLOYEE DETAILS</th>
            <?php
        }else{

           ?>
           <th colspan="5" class="text-center">EMPLOYEE DETAILS</th>
           <?php
       }}?>
            <th colspan="4" class="emoluments text-center">EMOLUMENTS</th>
            <th colspan="3" class="social text-center">SOCIAL SECURITY DEDUCTIONS</th>
            <th class="net_salary"></th>
                <?php if(session()->get('db_id')==17){?>
            <th colspan="8" class="tax text-center">TAX & OTHER DEDUCTIONS</th>
        <?php 
    }else{
            ?>
             <th colspan="3" class="tax text-center">TAX & OTHER DEDUCTIONS</th>
            <?php
        }
        ?>
            <th class="net_salary"></th>
           
        </tr>
        <tr>
            <th>S/N</th>
            <th>DEPARTMENT</th>
            <th>JOB TITLE</th>
             <?php if (isset($company) && !empty($company)) {
                    if($company[0]->classification==1){
                ?>
            <th>CLASSFICATION</th>
            <?php
}}
            ?>
            <th>NAMES</th>
            <th>STATUS</th>
            <th class="emoluments">B.SALARY</th>
            <th class="emoluments">OVER TIME</th>
            <th class="emoluments">ALLOWANCE</th>
            <th class="emoluments">GROSS</th>
            <th class="social">PENSION 10%</th>
            <th class="social">NHIF 3%</th>
            <th class="social">TOTAL SOCIAL</th>
            <th class="net_salary">NET BEFORE TAX</th>
            <th class="tax">PAYE</th>
            <th class="tax">HESLB</th>
            <th class="tax">ADVANCES</th>
                             <?php if(session()->get('db_id')==17){?>
           <th class="tax">TUCTA</th>
            <th class="tax">HOUSING</th>
            <th class="tax">OTHER LOANS</th>
            <th class="tax">MAAFA</th>
              <th class="tax">ELECTRICITY</th>
        <?php
    }
    ?>
            <th class="net_salary">NET SALARY</th>
        </tr>
    </thead>
    <tbody>
<?php
    $i=0;
$total_basic_salary = 0;
$total_allowances = 0;
$total_gross_salary = 0;
$total_nssf = 0;
$total_nhif = 0;
$ctotal_social = 0;
$cumulate_nbt=0;
$cumulate_paye=0;
$callowance=0;
$cadvances=0;
$cumulate_net_salary=0;
$wcf=0;
$total_heslb=0;
$total_housing=0;
$total_tucta=0;
$total_maafa=0;
$total_loans=0;
$total_electricity=0;
if(isset($payroll_info) && !empty($payroll_info)):
    foreach($payroll_info as $staffs):
          $row_style = ($staffs->status == 4) ? 'class="text-danger"' : '';
        $i++;
        $housing=$staffs->housing;
$tucta=$staffs->tucta;
$loans=$staffs->other_loans;
$maafa=$staffs->maafa;
$electricity=$staffs->electricity;
     $gross=$staffs->basic_salary + $staffs->allowances;
     $total_social=$staffs->pension+$staffs->nhif;
     $nbt =$gross-$total_social;

$total_basic_salary += $staffs->basic_salary;
$total_allowances += $staffs->allowances;
$total_social=$staffs->pension+$staffs->nhif;
$total_gross_salary += $gross;
$total_nssf += $staffs->pension;
$total_nhif += $staffs->nhif;
$ctotal_social += $total_social;
$total_heslb +=$staffs->heslb;
$cadvances += $staffs->advances;
$cumulate_nbt+=$nbt;
$cumulate_paye+=$staffs->paye;
$callowance+=$staffs->allowances;
$cumulate_net_salary+=$staffs->net_salaries;
$total_electricity+=$electricity;
        ?>

        <tr <?= $row_style; ?>>
  
            <td><?=$i;?></td>
            <td style="text-align: left;"><?=$staffs->dep_name;?></td>
            <td style="text-align: left;"><?=$staffs->job_tittle;?></td>
<?php 
if (isset($company) && !empty($company)) {
    if ($company[0]->classification == 1) {
        $matched = false;
        foreach ($classification as $class) {
            if ($class->id == $staffs->classfication_id) {
                echo "<td class='text-center'>{$class->class_name}</td>";
                $matched = true;
                break;
            }
        }
        if (!$matched) {
            echo "<td class='text-center'> - </td>";
        }
    }
}
?>

            <td style="text-align: left;"><?=$staffs->first_name;?> <?=$staffs->last_name;?></td>
                <?php $status = "<span class='badge badge-{$staffs->status_color}'>{$staffs->status_name}</span>";?>
                                     <td><?=$status;?></td>
            <td class="emoluments"><?=format_number_with_decimals($staffs->basic_salary);?></td>
            <td class="emoluments"><?=format_number_with_decimals(0);?></td>
            <td class="emoluments"><?=format_number_with_decimals($staffs->allowances);?></td>
            <td class="emoluments"><b><?=format_number_with_decimals($gross);?></b></td>
            <td class="social"><?=format_number_with_decimals($staffs->pension);?></td>
            <td class="social"><?=format_number_with_decimals($staffs->nhif);?></td>
            <td class="social"><b><?=format_number_with_decimals($total_social);?></b></td>
            <td class="net_salary"><b><?=format_number_with_decimals($nbt);?></b></td>
            <td><?=format_number_with_decimals($staffs->paye);?></td>
            <td><?=format_number_with_decimals($staffs->heslb);?></td>
            <td ><?=format_number_with_decimals($staffs->advances);?></td>
                      <?php if(session()->get('db_id')==17){?>  
            <td><?=format_number_with_decimals($tucta);?></td>
             <td><?=format_number_with_decimals($housing);?></td>
            <td ><?=format_number_with_decimals($loans);?></td>
            <td ><?=format_number_with_decimals($maafa);?></td>
                <td ><?=format_number_with_decimals($electricity);?></td>
                    <?php
                }
                ?>
            <td class="net_salary"><b><?=format_number_with_decimals($staffs->net_salaries);?></b></td>
        </tr>

        <?php
    endforeach;
endif;
        ?>
          </tbody>
          <tfoot>
        <tr style="font-weight: bold;">
                     <?php if (isset($company) && !empty($company)) {
                    if($company[0]->classification==1){
                ?>
            <td colspan="6" style="text-align: center;">TOTAL</td>
                  <?php
        }else{

           ?>
           <td colspan="5" style="text-align: center;">OVERALL TOTAL</td>
           <?php
}}
           ?>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_basic_salary);?></td>
            <td class="emoluments text-right"><?=format_number_with_decimals(0);?></td>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_allowances);?></td>
            <td class="emoluments text-right"><?=format_number_with_decimals($total_gross_salary);?></td>
            <td class="social text-right"><?=format_number_with_decimals($total_nssf);?></td>
            <td class="social text-right"><?=format_number_with_decimals($total_nhif);?></td>
            <td class="social text-right"><?=format_number_with_decimals($ctotal_social);?></td>
            <td class="net_salary text-right"><?=format_number_with_decimals($cumulate_nbt);?></td>
            <td class="text-right"><?=format_number_with_decimals($cumulate_paye);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_heslb);?></td>
            <td class="text-right"><?=format_number_with_decimals($cadvances);?></td>
                        <?php if(session()->get('db_id')==17){?>
           <td class="text-right"><?=format_number_with_decimals($total_tucta);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_housing);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_loans);?></td>
            <td class="text-right"><?=format_number_with_decimals($total_maafa);?></td>
                    <td class="text-right"><?=format_number_with_decimals($total_electricity);?></td>
                <?php
            }
            ?>
            <td class="net_salary text-right"><?=format_number_with_decimals($cumulate_net_salary)?></td>
            
        </tr>
</tfoot>
</table>
</div>

            </div>
        </div>

        </div>
    </div>

        <!--------$name="AUGUST MARTIN NJAU";---------- here payment information 
           
starts---->
        <?php $bill = $billmodel->billdata($inv[0]->trans_number,$inv[0]->trans_type_id); ?>
        <?php  $Initiator= $billmodel->get_initiator_name($bill[0]->app_id); ?>
        <div class="row">
        <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Approval History</h5>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               
                <label>Approval Status:</label>
                <?php 
                //$id_trans = $inv[0]->trans_number;
                $checker = 0;
               foreach($Initiator as $dat){
                if($dat->user_role =='3' && $dat->hstatus=='1')
                {
                    $checker =1;
                }
                elseif($dat->user_role =='3' && $dat->hstatus=='2'){
                    $checker =2;
                }
               }
                if($checker ==1)
                {
                     echo  '<label style="color:green;">  &nbsp;&nbsp; <strong>Approved! </strong></label>';
                 }
                 elseif($checker ==2){
                     echo  '<label style="color:red;">  &nbsp;&nbsp; Rejected! </label>';
                 }
                 else{
                echo'<label style="color:red;">  &nbsp;&nbsp; Pending! </label>';
                 }

                
                 ?>
                <div id="feedback"></div>
            </div>
            <!-- </hr> -->
        
     <?php $hist_data = $billmodel->getdatabill($bill[0]->app_id); ?>
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Entry Date:</th>
                        <th>Comment:</th>
                        <th>Name:</th>
                        <th>User Role:</th>
                        <!-- <th>Status:</th> -->
                    </tr>
                    <?php foreach($hist_data as $in): ?>
                    <tr>
                        <td><strong><?=$in->hist_date; ?></strong></td>
                        <td class="text-primary"><?= $in->comment; ?></td>
                        <td>
                            <?= $in->first_name.' '.$in->last_name; ?>
                        </td>
                        <td><?php if($in->user_role == '1'){
                            echo "Initiator";
                        }elseif($in->user_role == '2'){
                            echo "Checker";
                        }elseif($in->user_role == '3'){
                            echo "Approver";
                        }else{

                        } ?></td>
                        <td></td>
                    </tr>
                       <?php endforeach; ?>
                </table>
            </div>
        </div>
                  <!-- <div class="card  mt-3"> -->
                 <div class="card invoice mt-3">
             <div class="card-header mt-3">
                <h5>Message Information</h5>
            </div>
     
           <?php
       
            $msg_grp = $billmodel->get_item_name('message_groups_tbl',$where = array('message_type'=>17,'trans_number'=>$payroll_data[0]->trans_number));
          $msg = "";
          $status='';
          if(count($msg_grp)>0){
              $m = $billmodel->get_item_name('messages',$where = array('send_no'=>$msg_grp[0]->send_number));
                       
                         if(count($m) > 0){
                            $msg = $m[0]->message;
                            $msg= str_replace(array("\r","\n"),' ',$msg);
                          if($m[0]->sent_status == 1) {
                           $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description;
                          }elseif($m[0]->sent_status == 2){
                            $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description." <br>Delivered Date: ".$m[0]->time_delivered;
                          }
                        }
                    }
                     //print_r($bll);
             if($msg==""){
            $status="<span class='text-red'>Not Sent</span>";
            if(isset($ledger_data)){
                        $d_total=0;
                       foreach($ledger_data as $data){
                          if($data->transation_nature==1){
                        $d_total+=$data->amount; 
                    }
                }}

         $msg = "Payroll ".$payroll_data[0]->trans_number." for <b>".format_number_with_decimals($d_total)."</b> pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
                }

              // print_r($bll);
                   ?>
                
          
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Message:</th>
                        <td id="msg"><?= $msg; ?> </td>
                    </tr>
                    <tr>
                        <th>Status:</th>
                        <td id="msg"><?= $status; ?> </td>
                    </tr>
                    

                </table>
            </div>
            </div>
            
        <!-- </div> -->
        </div>
  

        <!------------------ here accounts receivable ------------------->
        <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>LEDGER ENTRIES</h5>
            </div>
            </hr>
           <div class="card-body">
                <table class="table" style="border:1px solid black;">
                   <tr style="border:1px solid black;">
                       <th style="border:1px solid black;">Ledger name</th>
                       <th style="border:1px solid black;">Ledger Type</th>
                       <th style="border:1px solid black;">Debit</th>
                       <th style="border:1px solid black;">Credit</th>

                   </tr>
                    <tbody style="border:1px solid black;">

                      <?php
                       if(isset($ledger_data)){
                        $dr_total=0;
                        $cr_total=0;
                       foreach($ledger_data as $data){
                        $cr_amount='';
                        $dr_amount='';
                        if($data->transation_nature==1){
                         $cr_amount=$data->amount;
                        $dr_amount=''; 

                        }else{
                             $cr_amount='';
                        $dr_amount=$data->amount; 
                        }
                        if($cr_amount !=''){
                             $cr_total +=$cr_amount;
                        }
                         if($dr_amount !=''){
                        $dr_total +=$dr_amount;
                    }
                       ?>
              
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;"><?=$data->account_name??""?></td>  
                          <td style="border:1px solid black;"><?=$data->type_name?></td>
                          <td class="text-right" style="border:1px solid black;"><?php 
                          if($dr_amount!=''){
                             echo format_number_with_decimals($dr_amount);
                          }
                         
                      ?></td>  
                          <td  class="text-right" style="border:1px solid black;"><?php
                            if($cr_amount!=''){
                             echo format_number_with_decimals($cr_amount);
                          }
                          ?></td>  
                        </tr>
                                        <?php

                    }}?>
                    </tbody>
                    <tfoot>
                             <tr style="border:1px solid black;">
                          <td style="border:1px solid black;" colspan="2"><b>Total<b></td> 
                          <td class="text-right" style="border:1px solid black;"><b><?=format_number_with_decimals($dr_total)??""?></b></td>   
                          <td class="text-right" style="border:1px solid black;"><b><?=format_number_with_decimals($cr_total)??""?></b></td>  
                          
                        </tr>
                    </tfoot>
                </table>

            </div>
        </div>
</div>
</div>
</div>
<!----------------------------- supporting documents --------------------------->
<div class="row">
      <div class="col-md-6">
  
    </div>
</div>
<div class="row">
    <?php if($vocher!=1 && count($advances)==0){?>
<div class="col-md-12">
   
    <button type="button" class="btn btn-success  float-right ml-3 ApprovalId" data-id="<?= $inv[0]->trans_number; ?>">Approve</button>
    <button type="button" class="btn btn-warning  float-right RejectId" data-id="<?= $inv[0]->trans_number; ?>">Reject</button>
  

</div>
  <?php }?>

</div>
<!-----------------for msg------------------>
<div class="col-md-6">
       
        </div>
 
<!-----------------end for msg------------------>

  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Add Comment</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <!-- <div id="Viewrejected"></div> -->
          <form class="form-group" id="RejectComment">
              <div class="form-group">
                  <textarea class="form-control" name="comment" id="comment">
                      
                  </textarea>
              </div>
              <button type="button" class="btn btn-primary" id="savecomment">Submit</button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="viewreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="close_rept()">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('viewreceipt_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
<!-- ------manage invoice modal------- -->
<div class="modal fade" id="viewinvoice" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"  style="z-index: 1400;">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5>Credit Note Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewinvoice_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printJS('invoicePrint_content', 'html')"><i class="fa fa-print"></i> Print</button> -->
        <!-- <button type="button" class="btn btn-primary"  data-toggle="modal" data-target="#invoiceprint" onclick="invoice_print()"><i class="fa fa-print"></i> Print</button> -->
        <button type="button" class="btn btn-primary"  data-toggle="modal" onclick="invoice_print()"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="view_voucher" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" onclick="close_printout()"aria-label="Close"></button>
      </div>
      <div class="modal-body" id="voucher_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="close_printout()">Close</button>
          <button type="button" class="btn btn-primary" onclick="printable_voucher2('voucher_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
    <div class="modal fade" id="paymentModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Print slip</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Viewpayment"></div>

        </div>
        <div class="modal-footer">
           <button type="button" class="btn btn-primary" onclick="printable_voucher()"><i class="fa fa-print"></i> Print</button>
        </div>
      </div>
      
    </div>
  </div>

   <script type="text/javascript">
    var transId='<?php echo $inv[0]->id;?>';
 $('#voucher_content').load('<?= base_url('/index.php/BillController/view_voucher')?>/'+transId);
 function close_printout(){
    $('#view_voucher').modal('hide');
 }
 function manage_bill(inv){
        //alert(inv);
      $('#viewreceipt').modal('show');
       $('#viewreceipt_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      $('#viewreceipt_content').load('<?= base_url('/index.php/BillController/view_voucher')?>/'+inv);
    }

    function manage_receipt(inv){
        //alert(inv);
      $('#viewreceipt').modal('show');
       $('#viewreceipt_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      $('#viewreceipt_content').load('<?= base_url('/view_receipt')?>/'+inv);
    }

    function manage_credit(inv){
        //alert(inv);
         $('#viewreceipt').modal('show');
       $('#viewreceipt_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      $('#viewreceipt_content').load('<?= base_url('/print_note')?>/'+inv);
      // $('#viewinvoice').modal('show'); 
      //  $('#viewinvoice_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      // $('#viewinvoice_content').load('<?= base_url('/view_note')?>/'+inv);
    }

    function CloseAttachmnt2() {
        $('#Attchmnt2').hide(100);
       
    }
       function displayImage(image_attachment)
       {
         $('#Attchmnt2').show(100);
        $('#ViewAttachment').html('<iframe src="<?php echo base_url() . '../public/transaction_files/'; ?>' + image_attachment + '" style="width:100%;height:500px"></iframe>');
                
       }
       //////////////////// for approved bill response ///////////////////////

       $(".ApprovalId").click(function(){
          var type='<?php echo $inv[0]->trans_type_id;?>';
        var data = "trans_number="+$(this).attr('data-id')+'&type='+type;
        $.ajax({
           
            type:"GET",
            url:"<?= base_url('/send_approved_data')?>",
            data:data,

            success: function (res){
                $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Congratulations!</strong> Bill Approved Successfully<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                  setTimeout(function(){
                        window.location.reload();
                    },1000)
               
            },
            error:function () {
                $('#feedback').html('<div class="alert alert-danger">Error! Couldn\'t Save data.</div>');
            }
        });
       });

       /////////////////// for rejected bill response ////////////////////////////
       $(".RejectId").click(function(){ 
         $('#myModal').modal('show');
        var type='<?php echo $inv[0]->trans_type_id;?>';
        var dat = "trans_number="+$(this).attr('data-id')+'&type='+type;
        //alert(data);
        $('#savecomment').click(function(){
        var data = "comment="+$('#comment').val()+"&"+dat;
            //alert(data);
      
         $.ajax({

            type:"GET",
            url:"<?= base_url('/send_rejected') ?>",
            data:data,
            success: function(res){
                 $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Congratulations! Bill Rejected Successfully</strong></div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                 
            },
            error: function ()
           {
            $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldn\'t Reject Bill.</strong></div>');
                // setTimeout(function(){
                // window.location.reload();
                // },1000)
            }
  });
         });
       });

 function CloseAttachmnt2() {
        $('#Attchmnt2').hide(100);
       
    }
       function view_attachement(image_attachment)
       {
       // alert(2);
         $('#Attchmnt2').show(100);
        $('#ViewAttachment').html('<iframe src="<?php echo base_url() . '../public/transaction_files/'; ?>' + image_attachment + '" style="width:100%;height:500px"></iframe>');
                
       }

               function view_payment(name) {
        $('#paymentModal').modal('show');
       var data=name;
        $.ajax({
            type: "POST",
            url: "<?= base_url('/get_slip_data')?>",
            data: {data:data},
            beforSend: function()
            {
                $('#Viewpayment').html();
            },
            success: function(res){
                $('#Viewpayment').html(res);
                 
            },
            error: function ()
            {

            }
        });
    };

    $(document).ready(function() {
    $('#payroll_view_table').DataTable({
        paging: false,
        searching: true,
        ordering: true,
        info: true,
        pageLength: 1000,
      
     
    });
    $('#payroll_view_table thead th').attr('data-bs-toggle', 'tooltip')
                              .attr('title', 'Click to sort');
$('[data-bs-toggle="tooltip"]').tooltip(); 

});

   </script>

    
    

