  <style type="text/css">

     .invoice > .card-header{

        border-bottom: 2px solid rgb(243, 243, 243) !important;

        border-top: 3px solid #ccc !important;

        height: 10px;

        color: #17a2b8;

    }
  

 </style>
 <?php 
$bmodel = new App\Models\BillingModel();
    $comodel = new App\Models\CompanyModel();
    $smodel=new App\Models\StudentModel;
$classification = $smodel->gettable_data('classification_tbl',$where = array('id >' => 0));
$company = $bmodel->get_table_details('company_tbl');
 helper('results_helper');
?>

<style>
table.emoluments, th.emoluments{
   
    background-color: #d9ead3;
}table.emoluments, td.emoluments{
   
    background-color: #d9ead3;
}
table.social, th.social{
  
    background-color: #d9d9d9;
}
table.social, td.social{
  
    background-color: #d9d9d9;
}
table.tax, th.tax{
    
    background-color: #f9cb9c;
}table.net_salary, th.net_salary{
    
    background-color: #fed966;
}table.net_salary, td.net_salary{
    
    background-color: #fed966;
}
td{
    border: 1px solid black;
}
th{
    border: 1px solid black;
}
table.centa, th.centa{
    text-align: center;
}
table.paysummary, th.paysummary{
    border: 1px solid black;
}
</style>
 <?php
 helper('age');
  $billmodel = new App\Models\BillModel();
  $remodel =new App\Models\ReportsModel();
  $suppliermodel = new App\Models\SupplierModel();
// $v_type = $billmodel->get_item_name('voucher_types_tbl', $where = array('id' => $rlt[0]->voucher_type));
 ?>
<div class="row">
<!-------------------- Bill Information starts here  ------------------>
    <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Overtime Information</h5>
            </div>
            </hr>

            <div class="card-body">
                
                <input type="hidden" name="supplier_name" id="supplierid" value="<?= esc($inv[0]->trans_number);?>">
                <table class="table table-borderless">
                    <?php
                    if(isset($overtime_data) && !empty($overtime_data)){
                        ?>
                    <tr>
                        <th>Pay Voucher No:</th>
                        <td><?= esc($overtime_data[0]->trans_number); ?></td>
                    </tr>
                     <tr>
                        <th>Voucher Type:</th>
                        <td><?=esc($voucher_type);?></td>
                    </tr>
                    <tr>
                        <th>Voucher Date:</th>
                        <td><?= esc($overtime_data[0]->trans_date); ?></td>
                    </tr>
                         <tr>
                        <th>Staff Name:</th>
                        <td><?= esc($overtime_data[0]->first_name); ?> <?= esc($overtime_data[0]->last_name); ?></td>
                    </tr> 
                          <tr>
                        <th>Staff's Basic Salary:</th>
                        <td><?=number_format(esc($overtime_data[0]->basic_salary)); ?></td>
                    </tr> 
                    <?php
                }?>                               
                </table>
            </div>
    </div>
</div>
 <!-------------------- Payment History starts here  ------------------>


</div>
</div>

<!-------------------- Charged Items starts here --------------------->
<div class="row">
    <div class="col-md-12">
        <div class="card  invoice">
            <div class="card-header">
                <h5>Overtime Details</h5>
                
            </div>
            </hr>

            <div class="card-body">
           <div class="table-responsive">
        <table id="Overtime_view_table" class="table table-bordered">
            <thead>
                <tr>
                    <th>SN</th>
                    <th>PAYROLL YEAR</th>
                    <th>PAYROLL MONTH</th>
                    <th>DAY'S NATURE</th>
                    <th>DATE </th>
                    <th>FROM</th>
                    <th>TO</th>
                    <th>TOTAL HOURS</th>
                    <th>RATE</th>
                    <th>AMOUNT</th>
                    <th>PREPARED ON</th>
                </tr>
            </thead>
            <tbody>
                <?php
                 if(isset($overtime_data) && !empty($overtime_data)){
                    $i=0;
                    $total_hrs=0;
                    $total_rate=0;
                    $total_amount=0;
                    foreach($overtime_data as $data){
                        $i++;
                        if($data->nature_day==1){
         $nature='Normal Day';
                        }else if($data->nature_day==2){
$nature='Weekend Day';
                        }else if($data->nature_day==3){
$nature='Public Holiday';
                        }else{
$nature='';
                        }
                         $total_hrs +=$data->total_hours;
                    $total_rate+=$data->rate;
                    $total_amount+=$data->amount;
                ?>
                <tr>
                    <td><?=esc($i)?></td>
                    <td><?=esc($data->payroll_year)?></td>
                    <td><?=esc($data->month)?></td>
                    <td><?=esc($nature)?></td>
                    <td><?=esc($data->overtime_day)?></td>
                    <td><?=esc($data->from_time)?></td>
                    <td><?=esc($data->to_time)?></td>
                    <td class="text-center"><?=number_format(esc($data->total_hours));?></td>
                    <td><?=number_format(esc($data->rate))?></td>
                    <td class="text-right"><?=number_format(esc($data->amount));?></td>
                    <td><?=esc($data->prepared_on)?></td>
      
                </tr>
                <?php
            }
            }
            ?>
            </tbody>
            <tfoot>
                <tr>
                    <td class="text-center fw-bold" colspan="7">TOTAL</td>
                    <td class="text-center fw-bold"><?=number_format(esc($total_hrs));?></td>
                    <td class="text-center fw-bold"><?=number_format(esc($total_rate));?></td>
                    <td class="text-right fw-bold"><?=number_format(esc($total_amount));?></td>
                    <td class="text-center fw-bold"></td>
                </tr>
            </tfoot>


</table>
</div>

            </div>
        </div>

        </div>
    </div>

        <!--------$name="AUGUST MARTIN NJAU";---------- here payment information 
           
starts---->
        <?php $bill = $billmodel->billdata($inv[0]->trans_number,$inv[0]->trans_type_id); ?>
        <?php  $Initiator= $billmodel->get_initiator_name($bill[0]->app_id); ?>
        <div class="row">
        <div class="col-md-6">
        <div class="card invoice">
            <div class="card-header">
                <h5>Approval History</h5>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               
                <label>Approval Status:</label>
                <?php 
                //$id_trans = $inv[0]->trans_number;
                $checker = 0;
               foreach($Initiator as $dat){
                if($dat->user_role =='3' && $dat->hstatus=='1')
                {
                    $checker =1;
                }
                elseif($dat->user_role =='3' && $dat->hstatus=='2'){
                    $checker =2;
                }
               }
                if($checker ==1)
                {
                     echo  '<label style="color:green;">  &nbsp;&nbsp; <strong>Approved! </strong></label>';
                 }
                 elseif($checker ==2){
                     echo  '<label style="color:red;">  &nbsp;&nbsp; Rejected! </label>';
                 }
                 else{
                echo'<label style="color:red;">  &nbsp;&nbsp; Pending! </label>';
                 }

                
                 ?>
                <div id="feedback"></div>
            </div>
            <!-- </hr> -->
        
     <?php $hist_data = $billmodel->getdatabill($bill[0]->app_id); ?>
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Entry Date:</th>
                        <th>Comment:</th>
                        <th>Name:</th>
                        <th>User Role:</th>
                        <!-- <th>Status:</th> -->
                    </tr>
                    <?php foreach($hist_data as $in): ?>
                    <tr>
                        <td><strong><?=$in->hist_date; ?></strong></td>
                        <td class="text-primary"><?= $in->comment; ?></td>
                        <td>
                            <?= $in->first_name.' '.$in->last_name; ?>
                        </td>
                        <td><?php if($in->user_role == '1'){
                            echo "Initiator";
                        }elseif($in->user_role == '2'){
                            echo "Checker";
                        }elseif($in->user_role == '3'){
                            echo "Approver";
                        }else{

                        } ?></td>
                        <td></td>
                    </tr>
                       <?php endforeach; ?>
                </table>
            </div>
        </div>
    </div>
     <div class="col-md-6">
       
                 <div class="card invoice">
             <div class="card-header">
                <h5>Message Information</h5>
            </div>
     
           <?php
       
            $msg_grp = $billmodel->get_item_name('message_groups_tbl',$where = array('message_type'=>17,'trans_number'=>$overtime_data[0]->trans_number));
          $msg = "";
          $status='';
          if(count($msg_grp)>0){
              $m = $billmodel->get_item_name('messages',$where = array('send_no'=>$msg_grp[0]->send_number));
                       
                         if(count($m) > 0){
                            $msg = $m[0]->message;
                            $msg= str_replace(array("\r","\n"),' ',$msg);
                          if($m[0]->sent_status == 1) {
                           $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description;
                          }elseif($m[0]->sent_status == 2){
                            $status="<i>Sent date: " .date('d-m-Y H:i:s',$m[0]->created_at)." 
                             <br>Status: ".$m[0]->status_description." <br>Delivered Date: ".$m[0]->time_delivered;
                          }
                        }
                    }
                     //print_r($bll);
             if($msg==""){
            $status="<span class='text-red'>Not Sent</span>";
            if(isset($ledger_data)){
                        $d_total=0;
                       foreach($ledger_data as $data){
                          if($data->transation_nature==1){
                        $d_total+=$data->amount; 
                    }
                }}

         $msg = "Overtime ".$overtime_data[0]->trans_number." for <b>".number_format($d_total)."</b> pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
                }

              // print_r($bll);
                   ?>
                
          
            <div class="card-body">
                <table class="table table-borderless" id="paytable">
                    <tr>
                        <th>Message:</th>
                        <td id="msg"><?= $msg; ?> </td>
                    </tr>
                    <tr>
                        <th>Status:</th>
                        <td id="msg"><?= $status; ?> </td>
                    </tr>
                    

                </table>
            </div>
            </div>
            
        <!-- </div> -->
        </div>
  

</div>
</div>
<!----------------------------- supporting documents --------------------------->
<div class="row">
      <div class="col-md-6">
  
    </div>
</div>
<div class="row">
    <?php if($vocher!=1 && count($advances)==0){?>
<div class="col-md-12">
   
    <button type="button" class="btn btn-success  float-right ml-3 ApprovalId" data-id="<?= $inv[0]->trans_number; ?>">Approve</button>
    <button type="button" class="btn btn-warning  float-right RejectId" data-id="<?= $inv[0]->trans_number; ?>">Reject</button>
  

</div>
  <?php }?>

</div>
<!-----------------for msg------------------>
<div class="col-md-6">
       
        </div>
        <div class="col-md-6">
            <?php
if(isset($advances) && !empty($advances)){
            ?>
            <div class="card">
            <div class="card invoice">
              <div class="card-header">
                <h5>Repayment Schedule</h5>
            </div>
            </div>
            <div class="card-body">
                                       <table class="table" style="border:1px solid black;">
                                        <thead>
                   <tr style="border:1px solid black;">
                       <th style="border:1px solid black;">Payroll Year</th>
                       <th style="border:1px solid black;">Payroll Month</th>
                       <th style="border:1px solid black;">Amount</th>
                   </tr>
                   </thead>
                    <tbody style="border:1px solid black;">
                        <?php 
                        $total_advance=0;
                          foreach ($advances as $data){
                               $total_advance+=$data->advance_amount;
                        ?>
                        <tr style="border:1px solid black;">
                          <td style="border:1px solid black;"><?=$data->payroll_year??""?></td>  
                           <td style="border:1px solid black;"><?=$data->month??""?></td>  
                          <td class="text-right" style="border:1px solid black;"><?=number_format($data->advance_amount)??""?></td>  
                         
                        </tr>
       <?php
   }
       ?>

                        
                    </tbody>
                    <tfoot>
                        <tr style="border:1px solid black;">
                        <td style="border:1px solid black;" colspan="2" class="fw-bold"><b>Total</b></td>
                        <td class="text-right fw-bold" style="border:1px solid black;"><?= number_format($total_advance);?></td>
                        </tr>
                    </tfoot>
                </table>
                
            </div>
            <?php
        }?>
        </div>
        </div>
        <div class="row">
    <?php if($vocher!=1 && count($advances)>0){?>
<div class="col-md-12">
   
    <button type="button" class="btn btn-success  float-right ml-3 ApprovalId" data-id="<?= $inv[0]->trans_number; ?>">Approve</button>
    <button type="button" class="btn btn-warning  float-right RejectId" data-id="<?= $inv[0]->trans_number; ?>">Reject</button>
  

</div>
  <?php }?>

</div>
<!-----------------end for msg------------------>

  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Add Comment</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <!-- <div id="Viewrejected"></div> -->
          <form class="form-group" id="RejectComment">
              <div class="form-group">
                  <textarea class="form-control" name="comment" id="comment">
                      
                  </textarea>
              </div>
              <button type="button" class="btn btn-primary" id="savecomment">Submit</button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="viewreceipt" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewreceipt_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="close_rept()">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('viewreceipt_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
<!-- ------manage invoice modal------- -->
<div class="modal fade" id="viewinvoice" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"  style="z-index: 1400;">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5>Credit Note Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewinvoice_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printJS('invoicePrint_content', 'html')"><i class="fa fa-print"></i> Print</button> -->
        <!-- <button type="button" class="btn btn-primary"  data-toggle="modal" data-target="#invoiceprint" onclick="invoice_print()"><i class="fa fa-print"></i> Print</button> -->
        <button type="button" class="btn btn-primary"  data-toggle="modal" onclick="invoice_print()"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="view_voucher" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" onclick="close_printout()"aria-label="Close"></button>
      </div>
      <div class="modal-body" id="voucher_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="close_printout()">Close</button>
          <button type="button" class="btn btn-primary" onclick="printable_voucher2('voucher_content')"><i class="fa fa-print"></i> Print</button>
      </div>
    </div>
  </div>
</div>
    <div class="modal fade" id="paymentModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Print slip</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Viewpayment"></div>

        </div>
        <div class="modal-footer">
           <button type="button" class="btn btn-primary" onclick="printable_voucher()"><i class="fa fa-print"></i> Print</button>
        </div>
      </div>
      
    </div>
  </div>

   <script type="text/javascript">
    var transId='<?php echo $inv[0]->id;?>';
 $('#voucher_content').load('<?= base_url('/index.php/BillController/view_voucher')?>/'+transId);
 function close_printout(){
    $('#view_voucher').modal('hide');
 }
 function manage_bill(inv){
        //alert(inv);
      $('#viewreceipt').modal('show');
       $('#viewreceipt_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      $('#viewreceipt_content').load('<?= base_url('/index.php/BillController/view_voucher')?>/'+inv);
    }

    function manage_receipt(inv){
        //alert(inv);
      $('#viewreceipt').modal('show');
       $('#viewreceipt_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      $('#viewreceipt_content').load('<?= base_url('/view_receipt')?>/'+inv);
    }

    function manage_credit(inv){
        //alert(inv);
         $('#viewreceipt').modal('show');
       $('#viewreceipt_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      $('#viewreceipt_content').load('<?= base_url('/print_note')?>/'+inv);
      // $('#viewinvoice').modal('show'); 
      //  $('#viewinvoice_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> wait...</b></center>'); 
      // $('#viewinvoice_content').load('<?= base_url('/view_note')?>/'+inv);
    }

    function CloseAttachmnt2() {
        $('#Attchmnt2').hide(100);
       
    }
       function displayImage(image_attachment)
       {
         $('#Attchmnt2').show(100);
        $('#ViewAttachment').html('<iframe src="<?php echo base_url() . '../public/transaction_files/'; ?>' + image_attachment + '" style="width:100%;height:500px"></iframe>');
                
       }
       //////////////////// for approved bill response ///////////////////////

       $(".ApprovalId").click(function(){
          var type='<?php echo $inv[0]->trans_type_id;?>';
        var data = "trans_number="+$(this).attr('data-id')+'&type='+type;
        $.ajax({
           
            type:"GET",
            url:"<?= base_url('/send_approved_data')?>",
            data:data,

            success: function (res){
                $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Congratulations!</strong> Bill Approved Successfully<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
                  setTimeout(function(){
                        window.location.reload();
                    },1000)
               
            },
            error:function () {
                $('#feedback').html('<div class="alert alert-danger">Error! Couldn\'t Save data.</div>');
            }
        });
       });

       /////////////////// for rejected bill response ////////////////////////////
       $(".RejectId").click(function(){ 
         $('#myModal').modal('show');
        var type='<?php echo $inv[0]->trans_type_id;?>';
        var dat = "trans_number="+$(this).attr('data-id')+'&type='+type;
        //alert(data);
        $('#savecomment').click(function(){
        var data = "comment="+$('#comment').val()+"&"+dat;
            //alert(data);
      
         $.ajax({

            type:"GET",
            url:"<?= base_url('/send_rejected') ?>",
            data:data,
            success: function(res){
                 $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><strong>Congratulations! Bill Rejected Successfully</strong></div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                 
            },
            error: function ()
           {
            $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldn\'t Reject Bill.</strong></div>');
                // setTimeout(function(){
                // window.location.reload();
                // },1000)
            }
  });
         });
       });

 function CloseAttachmnt2() {
        $('#Attchmnt2').hide(100);
       
    }
       function view_attachement(image_attachment)
       {
       // alert(2);
         $('#Attchmnt2').show(100);
        $('#ViewAttachment').html('<iframe src="<?php echo base_url() . '../public/transaction_files/'; ?>' + image_attachment + '" style="width:100%;height:500px"></iframe>');
                
       }

               function view_payment(name) {
        $('#paymentModal').modal('show');
       var data=name;
        $.ajax({
            type: "POST",
            url: "<?= base_url('/get_slip_data')?>",
            data: {data:data},
            beforSend: function()
            {
                $('#Viewpayment').html();
            },
            success: function(res){
                $('#Viewpayment').html(res);
                 
            },
            error: function ()
            {

            }
        });
    };

    $(document).ready(function() {
    $('#Overtime_view_table').DataTable({
        paging: false,
        searching: true,
        ordering: true,
        info: true,
        pageLength: 1000,
      
     
    });
    $('#Overtime_view_table thead th').attr('data-bs-toggle', 'tooltip')
                              .attr('title', 'Click to sort');
$('[data-bs-toggle="tooltip"]').tooltip(); 

});

   </script>

    
    

