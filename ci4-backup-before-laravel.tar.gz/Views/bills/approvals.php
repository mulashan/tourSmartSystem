<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Approvals</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                $this->billmodel = new App\Models\BillModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Approvals</li>
                </ol>
            </div>
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#approval-all">Pending Approval List</a></li>
               
            </ul>
        </div>
    </div>
</div>


<div class="section-body mt-4">
    <div class="container-fluid">
            <div class="tab-content">
            <div class="tab-pane active" id="approval-all">
            <div class="card">
                <div class="table-responsive mt-3">
                    <table class="table table-hover table-bordered table-vcenter mb-0 text-nowrap"  id="myTable">
                        <thead>
                            <tr>
                                <th>App Id.</th>
                                <th>Trans</th>
                                <th>Trans No</th>
                                <th>Trans Type</th>
                                <th>Trans Date</th>
                                <th>Name</th>
                                <th>Name Type</th>
                                <th>AMount</th>
                                <th>Initiator</th>
                                <th>Modified Date</th>
                                <th>Status</th>                               
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody style="padding:1px;">
                     <?php 
                     // echo count($approvals);
                     //  print_r($approvals);
                     //  return;
                     foreach ($approvals as $appr){
                           $approve_amount=$appr->amount;
                //  echo 'Transaction type = '.$appr->trans_type.' trans number = '.$appr->trans_no.'status - '.$appr->hstatus.' = '.' Aproval = '.$appr->comment.'='.$appr->amount.'<br>';
                      if($appr->hstatus == '3'){
                        $checkapp = $this->billmodel->get_item_name('approval_history',$where=array('app_no'=>$appr->app_no,'hstatus'=>1));
                                if(count($checkapp)>0){
                                    continue;
                                }
                    }
                        if($appr->hstatus == '3'){
                        $checkapp = $this->billmodel->get_item_name('approval_history',$where=array('app_no'=>$appr->app_no,'hstatus'=>2));
                         if(count($checkapp)>0){
                                    continue;
                                }
                            }
                         

                            if($appr->name_type_id==1){
                            $name = $this->billmodel->get_item_name('students',$where=array('id'=>$appr->name_id));
                            $names=$name[0]->full_name;
                            }else if($appr->name_type_id==2){
                            $name = $this->billmodel->get_item_name('supplier_tbl',$where=array('supplier_id'=>$appr->name_id));
                             $names=$name[0]->supplier_name;
                            }else if($appr->name_type_id==7){
                                 // echo $appr->name_type_id.'/';
                            $name = $this->billmodel->get_item_name('users',$where=array('user_id'=>$appr->name_id));
                              $names=$name[0]->first_name." ".$name[0]->last_name;
                              // print_r($name);
                              // return;
                            
                            }
                            else if($appr->name_type_id==8){
                                 // echo $appr->name_type_id.'/';
                            $name = $this->billmodel->get_item_name('government_tbl',$where=array('institution_id'=>$appr->name_id));
                              $names=$name[0]->institution_name;
                            
                            }
                            else{
                           $names="";
                            }

                            if($appr->trans_type==1){
                              $tType="Transport Deletion";
                            }else if($appr->trans_type==4){
                              $transTypes = $this->billmodel->get_item_name('invoice_type_transaction',$where=array('transaction_type_id'=>4,'trans_no'=>$appr->trans_no));  
                              if(count($transTypes)>0){
                              $Types = $this->billmodel->get_item_name('invoice_types_tbl',$where=array('id'=>$transTypes[0]->invoice_type_id));
                              $tType=$Types[0]->type_name;
                          }else{
                            $tType=""; 
                          }

                            }else if($appr->trans_type==5){
                    $voucher = $this->billmodel->get_item_name('voucher_relation_tbl',$where=array('payment_no'=>$appr->trans_no));
                    if(count($voucher)==0){
                        continue;
                    }
                     $transTypes = $this->billmodel->get_item_name('voucher_types_tbl',$where=array('id'=>$voucher[0]->voucher_type));
                     $tType=$transTypes[0]->voucher_type_name;
                            }

                            else if($appr->trans_type==8){
                          $tType="Transfer";
                            }
                                       else if($appr->trans_type==10){
                        $voucher = $this->billmodel->get_vouchername($appr->trans_no);
                       
                    if($voucher==""){
                        continue;
                    }else{
                          $tType=$voucher->voucher_type_name;
                          if($voucher->id==6){
                                     $payroll_amount = $this->billmodel->GetApprovalPayroll($appr->trans_no);
                           if(!empty($payroll_amount)){
                  $approve_amount=$payroll_amount->basic_salary+$payroll_amount->allowances;

              }else{
$approve_amount=0;
              }
                          }
                      
                    }
                
        
                            }

                            else{
                      $tType="";
                            }

                             
                        ?>
                          <tr>
                           
                              <td><?= $appr->app_id;?></td>
                              <td><?= $appr->type_name;?></td>
                              <td><?= $appr->trans_no;?></td>
                              <td><?= $tType;?></td>
                              <td><?= $appr->trans_date; ?></td>
                              <td><?= $names; ?></td>
                              <td><?= $appr->name_type; ?></td>
                              <td class="text-right"><?= format_number_with_decimals($approve_amount); ?></td>
                              <td><?= $appr->first_name; ?></td>
                              <td><?=$appr->hist_date; ?></td>
                              <td><?php if($appr->hstatus == '1'){
                                echo "<div class='text-success'>Approved</div>";
                            }elseif($appr->hstatus == '3'){
                          echo "<div class='text-danger'>Pending</div>";

                            }elseif($appr->hstatus == '2'){
                          echo "<div class='text-danger'>Rejected</div>";

                            }
                               ?></td>
                            
                              <td>
                                  <button type="button" class="btn btn-primary btn-sm" data-id="<?=$appr->trans_no;?>" onclick="passingapprviewid('<?=$appr->trans_no;?>','<?=$appr->trans_type;?>')"><i class="fa fa-eye"></i> View</button>
                              </td>
                       
                          </tr>
                        <?php } ?>
                         </tbody>
                </table>
            </div>
        </div>
    </div>
<!-- For new approval-->
    <div class="tab-pane" id="approval-add">
                <div class="row clearfix">
                    <div class="card">
                        <div class="card-header" style="height:5px">
                            <h3 class="card-title">Approval Details</h3>
                            <div class="card-options ">
                                <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                            </div>
                        </div>
                        <hr>
                        <div class="card-body">
                           <!--  -->
                            <!--########## Form for collecting UoM data ##########-->
                            <form class="form-horizontal" id="AddUoM">
                                <div id="uomarea"></div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">approval</label>
                                    <div class="col-md-7">
                                        <input type="text" name="UoMname" id="uom" class="form-control form-control-sm" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label"></label>
                                    <div class="col-md-7">
                                        <button type="submit" name="submit" class="btn btn-primary float-right">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>  
            </div>
</div>
</div>
</div>


  <!-- Modal to View Approval Information -->

  <div class="modal fade" id="myviewModal" role="dialog">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Approval Information</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Viewapproval"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<script type="text/javascript">
    ////////function to View Approval data///////////////
 function passingapprviewid(trans_no,trans_type) {
        var data = 'trans_no=' + trans_no+'&trans_type='+trans_type;
       // alert(data);
        // $("#idkl").val( ids );
                $('#Viewapproval').html('');
        $('#myviewModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?= base_url('/get_approval_data')?>",
            data: data,
              beforeSend: function()
            {
                $('#Viewapproval').html('<span class="fa fa-spin fa-spinner"></span>Loading approval data...');
            },
            success: function(res){
                $('#Viewapproval').html(res);
                 
            },
            error: function ()
            {
 $('#Viewapproval').html('<div class="alert alert-warning">Fail to retreive Data.!!</div>');
            }
        });
    };
</script>
