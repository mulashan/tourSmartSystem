<?php
 $bmodel = new App\Models\BillingModel();
   $bank_accounts = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' =>9));
    $expenses = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' =>10));
    $income = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' =>4));

     $recon_data = $bmodel->get_item_name('reconciliation_tbl',$where = array('recon_number !=' =>""));
?>
<style type="text/css"> 

    #results { padding:5px; border:1px solid; background:#ccc; }

</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Reconciliation</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Reconciliation</li>
                </ol>
            </div>
            <div id="largeScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#reco-all">Reconciliation List</a></li>
                 <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#reco-add">New Reconciliation</a></li>
            </ul>
             </div>

             <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#reco-all">Reconciliation List</a></li>
                <li></li><li></li>
                  <li class="nav-item d-none d-sm-block"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#reco-add">New Reconciliation</a></li>
            </ul>
             </div>

        </div>
    </div>
</div>

<div class="section-body mt-4">
        <div class="container-fluid">
            <div class="tab-content">


             <div class="tab-pane active" id="reco-all">
                <div class="card">
                  
                   <div class="d-flex justify-content-center mt-3 mb-3">
                <div id="messageDisplayArea"></div>
                    <form id="Rept1Result" class="form-inline">
                         Recon date:
                         <div class="input-group ms-3 me-3">
                            <button type="button" class="btn btn-default pull-right daterange-all" id="daterange-all">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                        Bank: 
                        <select class="form-control form-select" name="bankId" id="bankId">
                            <option value="0">All</option>
                            <?php
                           
                          foreach($bank_accounts as $re){
                           echo '<option value="' . $re->id . '">' . $re->account_name . '</option>'; 
                          }

                           ?>
                        </select>
                        <button type="submit" class="btn btn-primary ms-3">Create</button>
                   </form>

                </div>

                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="reconciliation_list"></div>
                </center>

                </div>
            </div>

            <div class="tab-pane" id="reco-add">
                <form id="reconcile_data">
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="card card-lg">
                            <div class="card-header"  style="height:5px">
                                <h3 class="card-title">Reconciliation Details</h3>
                                <div class="card-options ">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                                <hr>
                            <div class="card-body">
                              
                                <div id="supplierarea"></div>

                                   <div class="row" id="reconcile1">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Account<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                    <select class="form-control select-form" id="account" name="account_id" onchange="changeAccount()">
                                            <option value="0">-choose-</option>
                                             <?php 
                                          foreach ($bank_accounts as $bk) {
                                            ?>
                                           <option value="<?= $bk->id;?>"><?= $bk->account_name;?></option>
                                            <?php
                                          }
                                             ?>
                                             
                                              </select>
                                            </div>
                                          </div>
                                          <?php
                                          $start="2022-01-01"
                                          ?>
                                          <input type="hidden"  name="start_date" id="start_date" class="form-control" value="<?php echo date('Y-m-d',strtotime($start))?>" required>
                                       <!--  <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Start Date<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                              <input type="date"  name="start_date" id="start_date" class="form-control" value="<?php echo date('Y-m-d')?>" required>
                                            </div>
                                        </div> -->
                            <div class="form-group row">
                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Last recon Date</label>
                            <div class="col-sm-8">
                              <input type="date" id="lastRecon" name="lastRecon" class="form-control" value="<?php echo date('Y-m-d ');?>" >
                            </div>
                          </div>
                                        <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Statement Date<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                              <input type="date" id="date_statement" name="date_statement" class="form-control" value="<?php echo date('Y-m-d')?>" required>
                                            </div>
                                          </div>
                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Begining Balance<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                              <input type="text" id="beginbalance" name="beginbalance" class="form-control" value="0" onkeyup="AmtCalc2()" readonly>
                                            </div>
                                          </div>
                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Ending Balance<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                              <input type="text" id="endingbalance" name="endingbalance" class="form-control" value="0" onkeyup="AmtCalc()">
                                            </div>
                                          </div>

                                          <!--<div class="form-group row mt-3">-->
                                          <!--<p>Enter any service Charge or interest earned</p>-->
                                          <!--</div>-->

                                      </div>
                                <div class="col-md-6">

                     <!--     <div class="form-group row">
                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Last recon Date</label>
                            <div class="col-sm-8">
                              <input type="date" id="lastRecon" name="lastRecon" class="form-control" value="<?php echo date('Y-m-d ');?>" >
                            </div>
                          </div> -->

                                     
                              </div> 
                        <!--<div class="col-md-6">-->
                        <!--    <div class="form-group row">-->
                        <!--          <label for="inputpaidBy" class="col-sm-4 ol-form-label">Service Charge</label>  -->
                        <!--          <label for="inputpaidBy" class="col-sm-4 col-form-label">Date</label>  -->
                        <!--          <label for="inputpaidBy" class="col-sm-4 col-form-label">Account</label>  -->
                        <!--         </div>-->
                        <!--     <div class="form-group row">-->
                        <!--          <div class="col-sm-4">-->
                        <!--          <input type="text" id="" name="" class="form-control" value="0">-->
                        <!--        </div>-->
                        <!--        <div class="col-sm-4">-->
                        <!--          <input type="date" id="" name="" class="form-control" value="<?= date('Y-m-d')?>">-->
                        <!--        </div>-->
                        <!--        <div class="col-sm-4">-->
                        <!--          <select class="form-control form-select">-->
                        <!--              <option>-select-</option>-->
                        <!--              
                        <!--          </select>-->
                        <!--        </div>-->
                        <!--     </div> -->

                        <!--     <div class="form-group row">-->
                        <!--          <label for="inputpaidBy" class="col-sm-4 ol-form-label">Interest Earned</label>  -->
                        <!--          <label for="inputpaidBy" class="col-sm-4 col-form-label">Date</label>  -->
                        <!--          <label for="inputpaidBy" class="col-sm-4 col-form-label">Account</label>  -->
                        <!--         </div>-->
                        <!--     <div class="form-group row">-->
                        <!--          <div class="col-sm-4">-->
                        <!--          <input type="text" id="" name="" class="form-control" value="0">-->
                        <!--        </div>-->
                        <!--        <div class="col-sm-4">-->
                        <!--          <input type="date" id="" name="" class="form-control" value="<?= date('Y-m-d')?>">-->
                        <!--        </div>-->
                        <!--        <div class="col-sm-4">-->
                        <!--          <select class="form-control form-select">-->
                        <!--              <option>-select-</option>-->
                        <!--            
                        <!--          </select>-->
                        <!--        </div>-->
                        <!--     </div> -->
                        <!--</div>   -->
                                   
                                </div>
                                </div>
            

                <div class="row" id="reconcile2">
                <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                     <div class="form-group row">
                     <label for="inputpaidBy" class="col-sm-12 col-form-label"><b>For Period From</b><b><span id="period_date" class="ms-1">date</span></b></label>
                        </div>
                <div class="form-group row">
                    <label for="inputpaidBy" class="col-sm-8 col-form-label">Payment Vouchers, Charges and Other Debits</label>
                  </div>

                <!-- <div class="form-group row">
                    <label for="inputpaidBy" class="col-sm-8 col-form-label">
                     <input type="checkbox" id="hidebox" name="" class="me-1" value="" onclick="hideAutorecociled1()"> Hide auto reconciled transactions
                 </label>
                </div> -->

                <div class="form-group row">
                                        <div id="loading_area"></div>
                                        <div class="col-sm-12">
                                     <table class="table table-responsive" style="width: 100%;height: 400px;">
                                         <thead>
                                             <tr>
                                     <th><input type="checkbox" name="" value="" onclick="Allcheckbox2()" id="allcheckbox2">ALL</th>
                                   
                                     <th>Trans type</th>
                                    <th>Trans Date</th>
                                      <th>Trans No</th>
                                    <th>Trans Name</th>
                                     <th> Amount</th>
                                    <th>Trans By</th>
                                             </tr>
                                         </thead>
                                        
                                         <tbody id="payments_credits">
                                             
                                         </tbody>
                                     </table>
                                    </div>
                                    </div>

             </div>
             </div>
             </div>

                            <div class="col-md-6">
                             
                            <div class="card">
                                <div class="card-body">
                                        <div class="form-group row">
                                       
                                             <label for="inputpaidBy" class="col-sm-8 col-form-label">
                                                <input type="checkbox" id="hidebox" name="" class="me-1" value="" onclick="hideAutorecociled()"> Hide auto reconciled transactions</label>
                                        </div>

                             <div class="form-group row">
                                  <label for="inputpaidBy" class="col-sm-12 col-form-label">Receipts, Deposits and Other Credits</label>
                                    </div>

                                    <div class="form-group row">
                                        <div id="payments_area1"></div>
                                        <div class="col-sm-12">
                                     <table class="table table-responsive" style="width: 100%;height: 400px;">
                                         <thead>
                                             <tr>
                                     <th><input type="checkbox" name="" value="" onclick="Allcheckbox()" id="allcheckbox">ALL</th>
                                   
                                     <th>Trans type</th>
                                    <th>Trans Date</th>
                                      <th>Trans No</th>
                                    <th>Trans Name</th>
                                    <!-- <th>Name Type</th> -->
                                    <th> Amount</th>
                                    <th>Trans By</th>
                                             </tr>
                                         </thead>
                                        
                                         <tbody id="payments_area">
                                             
                                         </tbody>
                                     </table>
                                    </div>
                                    </div>
                                    </div>
                                </div>

                       <div class="card">
                                <div class="card-body">
                                     <div class="form-group row">
                                       <label for="inputpaidBy" class="col-sm-8 col-form-label text-black"><b>Begining Balance</b></label>
                                        <label for="inputpaidBy" class="col-sm-3 col-form-label text-black"><b><span id="beginbal" style="float:right;">0</span></b></label>
                                        </div>

                                         <div class="form-group row">
                                       <label for="inputpaidBy" class="col-sm-8 col-form-label">Charges and Advance(Manualy Cleared)</label>
                                        <label for="inputpaidBy" class="col-sm-3 col-form-label"><span id="chargesAdvance" style="float:right;">0</span></label>
                                        </div>

                                        <div class="form-group row">
                                       <label for="inputpaidBy" class="col-sm-8 col-form-label">Payments And Credits(Auto Cleared)</label>
                                        <label for="inputpaidBy" class="col-sm-3 col-form-label"><span id="autoCleared" style="float:right;">0</span></label>
                                        </div>

                                        <div class="form-group row">
                                       <label for="inputpaidBy" class="col-sm-8 col-form-label">Payments And Credits(Manualy Cleared)</label>
                                        <label for="inputpaidBy" class="col-sm-3 col-form-label"><span id="manualyCleared" style="float:right;">0</span></label>
                                        <input type="hidden" id="total_charges" value="0" name="total_charges">
                                        <input type="hidden" id="total_notcleared" value="0" name="total_notcleared">
                                        </div>

                                        <div class="form-group row">
                                       <label for="inputpaidBy" class="col-sm-8 col-form-label"><b>TOTAL CLEARED</b></label>
                                        <label for="inputpaidBy" class="col-sm-3 col-form-label"><b><span id="totalcleared" style="float:right;">0</span></b></label>
                                        </div>

                                         <div class="form-group row">
                                       <label for="inputpaidBy" class="col-sm-8 col-form-label">Ending Balance</label>
                                        <label for="inputpaidBy" class="col-sm-3 col-form-label"><span id="endbal" style="float:right;">0</span></label>
                                        </div>

                                        <div class="form-group row">
                                       <label for="inputpaidBy" class="col-sm-8 col-form-label">Difference</label>
                                        <label for="inputpaidBy" class="col-sm-3 col-form-label"><span id="diff" style="float:right;">0</span></label>
                                        </div>
                                        </div>
                                        </div>         
                                </div>
                                </div>
                        
                         <div class="form-group row mt-3">
                             <div class="col-md-8">
                             <button type="button" id="backbtn_area" class="btn btn-primary me-1" onclick="reconcileback(1)" style="float: right;display: none;">Back</button>
                         </div>
                            <div class="col-md-4">
                         <button type="button" id="continuebtn" class="btn btn-primary me-1" onclick="reconcilebtn(1)" style="float: right;">Continue</button>

                         <button type="button" id="reconcilenow" class="btn btn-primary me-1" onclick="reconcilenowbtn()" style="float: right;display: none;">Reconcile Now</button>
                            </div>

                        </div>
                        
                    </div>
                            </div>
                        </div>
                       </form> 
                    </div>
                </div>
            
    </div>
</div>
</div>

<div class="modal fade" id="myviewModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Supplier Information</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Viewsupplier"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>


<!-- Modal to update Supplier Information-->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Edit Supplier Information</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="Updtesupplier"></div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>

<script type="text/javascript">
   
    
 $("#reconcile2").hide();

 function reconcileback(k){
 $("#reconcile1").show();
 $("#reconcile2").hide();
 $("#backbtn_area").hide();
 $("#reconcilenow").hide();
 $("#continuebtn").show();
}
 
    function reconcilebtn(k){
        if($("#account").val() ==0){
       swal('warning','Please select Account to reconcile','warning');
       return;
        }
var all1 = document.getElementById("allcheckbox");
var all2 = document.getElementById("allcheckbox2");
var hide = document.getElementById("hidebox");
all1.checked=false;
all2.checked=false;
hide.checked=false;
$("#endbal").html(0);
$("#autoCleared").html(0);
$("#manualyCleared").html(0);
 $("#totalcleared").html(0);
 $("#chargesAdvance").html(0);
 $("#total_charges").val(0);
 $("#total_notcleared").val(0)

  $("#diff").html(0);

        $("#reconcile1").hide();
       $("#reconcile2").show();
       $("#backbtn_area").show();
        $("#continuebtn").hide();
        $("#reconcilenow").show();
        $('#payments_area').empty();
        $('#payments_credits').empty();

        var endbal=$('#endingbalance').val();
        var beginbalance=$('#beginbalance').val();
        $('#endbal').html(endbal);
        $('#beginbal').html(beginbalance);

        //alert(endbal);
    var start=0;
   var end=100;
    
     var start_date=$("#start_date").val(); 
     var stdate=$("#date_statement").val(); 
     var period=start_date+' to '+stdate;
     //alert(stdate);
     $("#period_date").html(period); 
     var dta="period_date="+stdate+"&account="+$("#account").val()+"&start_date="+$("#start_date").val(); 
       $('#payments_area1').html('<span class="fa fa-spinner fa-spin text-red"></span> please wait...');
       load_payments_credits(start,end,dta);
       $.ajax({
                type: "POST",
               
               url: "<?php echo base_url() . '/index.php/BillController/fetch_payments_reconciliation'; ?>/"+start+"/"+end,
                data: dta,
                success: function (res) {
                    $('#payments_area').append(res);
                    load_payments(end+1,end+100);
                    // $('#myTable2').DataTable();

                 var counted=$("#counted0").val();
               
                

                },
                error: function () {
                    $('#payments_area').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
    }

    function load_payments(start,end){
var counted=$("#counted0").val();
var cl=start-1;
var cleared=$("#clear"+cl).val();
var present_autoclear= $("#autoCleared").html().replace(/,/gi, "");
var new_autocleared=parseInt(present_autoclear)+parseInt(cleared);
  $("#autoCleared").html(new_autocleared.toLocaleString());
//console.log(new_autocleared);
  var notcleared=$("#notcleared"+cl).val();
var present_ttl= $("#total_notcleared").val();
var new_ttl=parseInt(present_ttl)+parseInt(notcleared);
$("#total_notcleared").val(new_ttl);
//console.log(present_ttl+'->new->'+new_ttl);

var nopayment=$("#nopayment"+cl).val();
 if(start >=counted || nopayment==1){
     AutoCalc();
   $('#payments_area1').html('');
    return;
 }
       var start_date=$("#start_date").val(); 
       var stdate=$("#date_statement").val(); 
     //alert(stdate);
     // $("#period_date").html(stdate); 
     var dta="period_date="+stdate+"&account="+$("#account").val()+"&start_date="+$("#start_date").val(); 
    
       $.ajax({
                type: "POST",
               
               url: "<?php echo base_url() . '/index.php/BillController/fetch_payments_reconciliation'; ?>/"+start+"/"+end,
                data: dta,
                success: function (res) {
                    $('#payments_area').append(res);
                    load_payments(end+1,end+100);
                    // $('#myTable2').DataTable();

                 var counted=$("#counted0").val();
               
                

                },
                error: function () {
                    $('#payments_area').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            }); 
       
    }
function paymentCheck(id){
   // alert(id);
    var row = document.getElementById('row'+id);
        
        var remember = document.getElementById("col"+id);
        if(remember.checked){
     remember.checked=true;  

    var amount=$("#amount"+id).val();
     var present_manclear= $("#manualyCleared").html().replace(/,/gi, "");
  var new_mancleared=parseInt(present_manclear)+parseInt(amount);
  $("#manualyCleared").html(new_mancleared.toLocaleString());
     console.log("already checked");
      if (row) {
    row.style.backgroundColor = 'brown';
      row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=false; 

      var amount=$("#amount"+id).val();
     var present_manclear= $("#manualyCleared").html().replace(/,/gi, "");
  var new_mancleared=parseInt(present_manclear)-parseInt(amount);
  $("#manualyCleared").html(new_mancleared.toLocaleString());
      console.log("not checked");
       if (row) {

      row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }  
  }
  AutoCalc();
}

function hideAutorecociled(){
    var rows = document.getElementsByClassName('crdb');
  var remember = document.getElementById("hidebox");
        if(remember.checked){
        for (var i = 0; i < rows.length; i++) {
     rows[i].style.display = "none"; // Hides all elements with the class "crdb"
     }

        }else{
    for (var i = 0; i < rows.length; i++) {
  rows[i].style.display = "table-row"; 
       }

        }
        // row.style.display = "none";
        // row.style.display = "block"; 
}

function AmtCalc(){
    var input=$("#endingbalance").val().replace(/,/gi, "");
    if(input !=""){
     $("#endingbalance").val(parseInt(input).toLocaleString());
    }else{
       $("#endingbalance").val(0);  
    }
}
function AmtCalc2(){
    var input=$("#beginbalance").val().replace(/,/gi, "");
    if(input !=""){
     $("#beginbalance").val(parseInt(input).toLocaleString());
    }else{
       $("#beginbalance").val(0);  
    }
}
  
function AutoCalc() {
     var end_bal= $("#endbal").html().replace(/,/gi, "");
     var begin_bal= $("#beginbal").html().replace(/,/gi, "");

     var manualy_charges= $("#chargesAdvance").html().replace(/,/gi, "");
     var auto_cleared= $("#autoCleared").html().replace(/,/gi, "");
     var man_cleared= $("#manualyCleared").html().replace(/,/gi, "");
  var ttl_cleared=parseInt(auto_cleared)+parseInt(man_cleared)+parseInt(manualy_charges)+parseInt(begin_bal);
  var diff=parseInt(ttl_cleared)-parseInt(end_bal);
  $("#totalcleared").html(ttl_cleared.toLocaleString());
  $("#diff").html(diff.toLocaleString());
  console.log('manualyCleared='+man_cleared+"auto_cleared="+auto_cleared);

  if(diff==0 && parseInt(ttl_cleared) >0){
    $('#reconcilenow').prop("disabled", false);
}else{
    $('#reconcilenow').prop("disabled", true);
}
}

function Allcheckbox(){

    var new_mancleared= parseInt($("#total_notcleared").val());

   var rows = document.getElementsByClassName('notrec');
  var remember = document.getElementById("allcheckbox");

     var checkbox = document.getElementsByClassName('check_box2');
        if(remember.checked){
            remember.checked=true; 
 for (var i = 0; i < rows.length; i++) {
     rows[i].style.backgroundColor = 'brown';
      rows[i].style.color = 'white';
      }

  for (var s = 0; s < checkbox.length; s++) {
  checkbox[s].checked=true; 
  }
$("#manualyCleared").html(new_mancleared.toLocaleString());
    }else{
        remember.checked=false; 
    for (var i = 0; i < rows.length; i++) {
    
     rows[i].style.backgroundColor = 'white';
      rows[i].style.color = 'black'; 
       }

  for (var s = 0; s < checkbox.length; s++) {
  checkbox[s].checked=false; 
  }

$("#manualyCleared").html(0);
 }

 AutoCalc();
}

function load_payments_credits(start,end,dta){
    //alert(dta);
    $('#payments_credits').empty();
$('#loading_area').html('<span class="fa fa-spinner fa-spin text-red"></span> please wait...');

   $.ajax({
                type: "POST",
               
               url: "<?php echo base_url() . '/index.php/BillController/credit_payments_reconciliation'; ?>/"+start+"/"+end,
                data: dta,
                success: function (res) {
                    $('#payments_credits').append(res);
                    credits_payments_continue(end+1,end+100);
                  
                 var counted=$("#allcredit0").val();
               },
                error: function () {
                    $('#payments_credits').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
       }

function credits_payments_continue(start,end){
var counted=$("#allcredit0").val();
var cl=start-1;

var nopayment=$("#nopayment_credit"+cl).val();

//accumulative total
 var notcleared=$("#notcleared_credit"+cl).val();
var present_ttl= $("#total_charges").val();
console.log("present charges="+present_ttl);
var new_ttl=parseInt(present_ttl)+parseInt(notcleared);
$("#total_charges").val(new_ttl);

 if(start >=counted || nopayment==1){
    // AutoCalc();
   $('#loading_area').html('');
    return;
 }
        
       var stdate=$("#date_statement").val(); 
     //alert(stdate);
     // $("#period_date").html(stdate); 
     var dta="period_date="+stdate+"&account="+$("#account").val()+"&start_date="+$("#start_date").val(); 
    
       $.ajax({
                type: "POST",
               url: "<?php echo base_url() . '/index.php/BillController/credit_payments_reconciliation'; ?>/"+start+"/"+end,
                data: dta,
                success: function (res) {
                    $('#payments_credits').append(res);
                    credits_payments_continue(end+1,end+100);
                    // $('#myTable2').DataTable();

                 var counted=$("#allcredit0").val();
               
                  },
                error: function () {
                    $('#payments_credits').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            }); 
       
    }

function creditCheck(id){
     
      var row = document.getElementById('crow'+id);
        
        var remember = document.getElementById("ccol"+id);
        if(remember.checked){
     remember.checked=true;  

    var amount=$("#credit_amount"+id).val();
     var present_charges= $("#chargesAdvance").html().replace(/,/gi, "");
  var new_charges_cleared=parseInt(present_charges)-parseInt(amount);
  $("#chargesAdvance").html(new_charges_cleared.toLocaleString());
     console.log("already checked");
      if (row) {
    row.style.backgroundColor = 'brown';
      row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=false; 

      var amount=$("#credit_amount"+id).val();
     var present_charges= $("#chargesAdvance").html().replace(/,/gi, "");
  var new_charges_cleared=parseInt(present_charges)+parseInt(amount);
  $("#chargesAdvance").html(new_charges_cleared.toLocaleString());
      console.log("amount="+amount+"/present_charges="+present_charges+"/new_charges_cleared="+new_charges_cleared);
       if (row) {

      row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }  
  }
  AutoCalc();
    }

function Allcheckbox2(){

    var new_mancleared= parseInt($("#total_charges").val()) *-1;
    console.log('total_charges='+new_mancleared);

   var rows = document.getElementsByClassName('notrec_credit');
  var remember = document.getElementById("allcheckbox2");

     var checkbox = document.getElementsByClassName('credit_box2');
        if(remember.checked){
            remember.checked=true; 
 for (var i = 0; i < rows.length; i++) {
     rows[i].style.backgroundColor = 'brown';
      rows[i].style.color = 'white';
      }

  for (var s = 0; s < checkbox.length; s++) {
  checkbox[s].checked=true; 
  }
$("#chargesAdvance").html(new_mancleared.toLocaleString());
    }else{
        remember.checked=false; 
    for (var i = 0; i < rows.length; i++) {
    
     rows[i].style.backgroundColor = 'white';
      rows[i].style.color = 'black'; 
       }

  for (var s = 0; s < checkbox.length; s++) {
  checkbox[s].checked=false; 
  }

$("#chargesAdvance").html(0);
 }

 AutoCalc();
}

function reconcilenowbtn(){
    
    // $('#reconcilenow').prop("disabled", true);
     var diff= $("#diff").html().replace(/,/gi, "");
     var ttl= $("#totalcleared").html().replace(/,/gi, "");
     if(parseInt(diff) !=0){
   swal('warning','Difference should be 0 in order to reconcile!','warning');
     }else{
// var data= $("#reconcile_data").serialize()+'&'+$('#header_form').serialize();
var jsonData = {};
var combined=$("#reconcile_data").serializeArray();
$.each(combined, function(i, field) {
    // For checkbox arrays like selected[], handle multiple values
    if (jsonData[field.name]) {
        if (!Array.isArray(jsonData[field.name])) {
            jsonData[field.name] = [jsonData[field.name]];
        }
        jsonData[field.name].push(field.value);
    } else {
        jsonData[field.name] = field.value;
    }
});

//console.log(jsonData);
     //alert(data);
     // return;
     $.ajax({
                type: "POST",
              url: '<?php echo base_url() . '/index.php/BillController/save_reconciliation'; ?>',
                 data: JSON.stringify(jsonData),
                success: function (res) {
                    //$('#Rept1ResultViewResults').html(res);
                    if(res){
                       
                        swal("success","Saved successfully","success");
                        
                    }else{
                         swal("error","Sorry!, something went wrong","error");
                    }
                   window.location.reload();
                },
                error: function () {
                   swal("error","Sorry!, something went wrong","error");
                }
            });
}
}

 $('#beginbalance').val(0);
 $('#endingbalance').val(0)
 const today = new Date();
 
 const month = String(today.getMonth() + 1).padStart(2, '0'); 
const day = String(today.getDate()).padStart(2, '0');
const year = today.getFullYear();
const formattedDate = `${year}-${month}-${day}`;
  $('#lastRecon').val(formattedDate);
  $("#date_statement").val(formattedDate);
$('#account').prop('selectedIndex', 0);

function changeAccount(){
    // alert($('#account').val());
    
    var account=$('#account').val();
    if(account >0){
        var data= "account_id="+account;
    //alert(data);
     $.ajax({
                type: "POST",
              url: '<?php echo base_url() . '/index.php/BillController/check_end_balance'; ?>',
                data: data,
                success: function (res) {
                    
                    if(res){
                        var result=JSON.parse(res);
                        console.log(result);
                     $('#beginbalance').val(result['recon_amount']);
                     $('#lastRecon').val(result['recon_last']);
                     //$('#start_date').val(result['new_startDate']);

                     if(result['readonly']=="0"){
                 document.getElementById('lastRecon').readOnly = false;
                // document.getElementById('start_date').readOnly = false;
                     }else{
                 document.getElementById('lastRecon').readOnly = true; 
                 //document.getElementById('start_date').readOnly = true; 
                   } 
                  
                    }else{
                         swal("error","Sorry!, something went wrong","error");
                    }
                   
                },
                error: function () {
                   swal("error","Sorry!, something went wrong","error");
                }
            });
 }else{
$('#beginbalance').val(0);
 }
}

 $('#Rept1Result').submit(function (e) {
             if (!$('#daterange-all span').html()) {
            $('#RecptResult').html('Please specify valid date.');
        } else {
            $('#reconciliation_list').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-all span').html()+"&bankId="+$('#bankId').val();
           // alert(dta);
            $.ajax({
                type: "POST",
              url: '<?php echo base_url() . '/index.php/BillController/filter_reconciliation_list'; ?>',

                data: dta,
                success: function (res) {
                    $('#reconciliation_list').html(res);
                },
                error: function () {
                    $('#reconciliation_list').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

}
        e.preventDefault();
    });
</script>