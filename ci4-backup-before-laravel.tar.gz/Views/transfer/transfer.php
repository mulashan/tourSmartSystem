<?php  $imodel = new App\Models\ItemsModel(); 
$bmodel = new App\Models\BillingModel();
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Transfer</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Transfer</li>
                </ol>
            </div>
            
            <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#acc-all">Transfer List</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#acc-add">New Transfer</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
           <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#acc-all">Transfer List</a></li>
                <li></li><li></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#acc-add">New Transfer</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="acc-all">
                <div class="card">
                    <div class="table-responsive mt-3">
                       
                       <div class="d-flex justify-content-center">
                <div id="messageDisplayArea"></div>
                    <form id="transferResult" class="form-inline">
                         Transfer date:
                         <div class="input-group ms-3 me-3">
                            <button type="button" class="btn btn-default pull-right daterange-all" id="daterange-all">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                           
                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </form>

                </div>
                
                <hr>
                &nbsp;<p></p>
                <center>
                    <div id="transfer_list"></div>
                </center>

                    </div>
                </div>
            </div>
            <div class="tab-pane" id="acc-add">
                <div class="row clearfix">
                    <div class="card">
                        <div class="card-header"  style="height:5px">
                                <h3 class="card-title">Transfer Details</h3>
                                <div class="card-options ">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                        <hr>
                        <div class="card-body">
                            <form class="form-horizontal" id="transfer_form">
                             <div class="row">
                            <div class="col-md-6">
                         <div class="form-group row">
                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Transfer Date<span class="text-red">*</span></label>
                                <div class="col-sm-8">
                                <input type="date" id="transfer_date" name="transfer_date" value="<?php echo date('Y-m-d');?>" class="form-control" required>
                                </div>

                                </div>
                                 <div class="form-group row">
                                  <label for="inputpaidBy" class="col-sm-4 col-form-label">From<span class="text-red">*</span></label>
                                  <div class="col-sm-8">
                                    <?php
                                    $acc = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 9));
                                        ?>
                                 <select class="form-control" name="bank" id="bank" required="required">
                                      <option value="">-Select -</option>
                                                    
                                         <?php foreach($acc as $type): ?>
                                        <option value="<?= $type->id ?>"><?= $type->account_name; ?></option>
                                             <?php endforeach; ?>
                                                </select>
                                             <div id="errormsg" style="color:red"></div>
                                            </div>
                                          </div>

                                          <div class="form-group row" id="bankto" style="display:none;">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label"> To<span class="text-red">*</span></label>
                                            <div class="col-sm-8">
                                              <?php
                                                 // $cty= $bmodel->get_table_details('voucher_types_tbl');
                                                  ?>
                                        <select class="form-control" name="bank_to" id="bank_to">
                                         <option value="">-Select -</option>
                                                    
                                         <?php foreach($acc as $type): ?>
                                        <option value="<?= $type->id ?>"><?= $type->account_name; ?></option>
                                             <?php endforeach; ?>
                                                    
                                                </select>
                                             <div id="errormsgto" style="color:red"></div>
                                            </div>
                                          </div>
                              <!------------------------------>
                            <div class="form-group row" id="input_amount" style="display:none;">
                                <label for="inputpaidBy" class="col-sm-4 col-form-label"> Amount<span class="text-red">*</span></label>
                            <div class="col-sm-8 d-flex align-items-center">
                        <input type="text" name="amount" id="amount_id" value="" class="form-control" onkeyup="AllCalc()" required="required">
                             </div>
                        
                              </div>

                              <!---------------put reason---------------------->
                         <div class="form-group row" id="reasonDiv" style="display:none;">
                            <label for="inputpaidBy" class="col-sm-4 col-form-label"> Description<span class="text-red">*</span></label>
                          <div class="col-sm-8 d-flex align-items-center">
                           <textarea class="form-control" id="reason" name="reason" placeholder="Write a description here" required="required" onkeyup="writeReason()"></textarea>
                            </div>

                        </div>
                              <!------------------------------>
                            </div>
                        <div class="col-md-6">
                        <div id="payment_details"></div>

                        </div>

                        </div>
                            </form>
                            
                        </div>

                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<!-- ------edit modal------ -->
<script type="text/javascript">
    $("#bank").change(function(){
     // document.getElementById("errormsg").innerHTML = ""; 
     // selectElement.style.borderColor = '';
    $('#input_amount').hide();
    $('#reasonDiv').hide();
    $("#amount_id").val(0);
     $("#bank_to").prop('selectedIndex', 0).trigger('change');
        var bank_type=$("#bank").val();
        if(bank_type==""){
            $('#payment_details').html('');
        //$("#creditOver").hide(); 
         $("#reasonDiv").hide(); 
        //$("#payer_name_row").hide();
       // $('#voucherTypeId').hide();
       // $("voucher_type").val('').trigger('change');
        }else{

       $('#payment_details').html('<span class="fa fa-spinner fa-spin"></span> Please wait..');
      
         $('#payment_details').load("<?php echo base_url() . '/index.php/BillController/bank_transfers'; ?>/"+bank_type+'/'+0);
         $('#bankto').show();
     }
   
    });

 $("#bank_to").change(function(){
    $('#input_amount').hide();
    $('#reasonDiv').hide();
    $("#amount_id").val(0);
     // document.getElementById("errormsg").innerHTML = ""; 
     // selectElement.style.borderColor = '';
       // alert(this.value);
        var bank_to=$("#bank_to").val();
        var bank_from=$("#bank").val();
        if(bank_to==""){
            
        
        }else{
  if(bank_to == bank_from){
     // $("bank_to").val('').trigger('change');
      this.value="";
      document.getElementById("errormsgto").innerHTML = "Please select different bank"; 
       }else{
        document.getElementById("errormsgto").innerHTML = ""; 
       // $('#payment_details').html('<span class="fa fa-spinner fa-spin"></span> Please wait..');
      
         $('#payment_details').load("<?php echo base_url() . '/index.php/BillController/bank_transfers'; ?>/"+bank_from+'/'+bank_to);
         $('#input_amount').show();
         $('#reasonDiv').show();

     }
     }
   
    });

      function AllCalc(){
       // alert(i);
             var total=0;
            var amount=0;
            var balance=0;
           
            var input=$("#amount_id").val().replace(/,/gi, "");
           
            if(input==""){
                input=0;
            }


             //var remember = document.getElementById("Allselected");
      
          amount=parseInt(input);
          var reason=$("#reason").val();
         // alert(rson);
             if(amount > 0 && reason !=""){
             $('#save_btn').show();
             }else{
               $('#save_btn').hide();
             }
           balance_before= $("#bal_before").html().replace(/,/gi, "");
          balance_after= $("#bal_after").html().replace(/,/gi, "");
           if(parseInt(input) > parseInt(balance_before)){
           var myAmount = Number(String(input).slice(0, -1));
            //alert(myAmount);
           $("#amount_id").val(myAmount.toLocaleString());
           toastr.info("Please enter amount less or equal to " + balance_before);
       }else{

          $("#amount_id").val(parseInt(input).toLocaleString());
         
          b_before=parseInt(balance_before)-amount;
          b_after=parseInt(balance_after)+amount;

           //alert(balance);
           $("#transfer_from").html(amount.toLocaleString());
           $("#transfer_to").html(amount.toLocaleString());
           $("#balance_from").html(b_before.toLocaleString());
           $("#balance_to").html(b_after.toLocaleString());
       }
      
      
  }

  function createTransfer(){
    var data=$('#transfer_form').serialize()+"&"+$("#header_form").serialize();
    //alert(data);
   // return;
        $.ajax({
                type: "POST",
                  url: '<?php echo base_url() . '/index.php/BillController/save_transfer_details'; ?>',
                 data: data,
                success: function (res) {
                   var data = JSON.parse(res);
              if(data['status'] == "1"){
                //$("#voucher_type").change();
              //  $("#bank").change();
                 $('#all_list').html('');
                // refresh_refund();
                 
             swal("success",data['description'],"success");
              refresh();
            }else{
             swal("error","Failed to create Payment","error"); 
              refresh();   
            }
                },
                error: function () {
                     swal("error","Failed to create Payment","error"); 
                      refresh();
                }
            });
  }

   function refresh(){
       window.location.reload();
     }

      $("#transferResult").submit(function (e) {

     
     if (!$('#daterange-all span').html()) {
           // $('#RecptResult').html('Please specify valid date.');
        alert("please specify valid date");
        } else {
            $('#transfer_list').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "thedate=" + $('#daterange-all span').html();
         // alert(dta);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url().'/index.php/BillController/transfer_list'; ?>',
                data: dta,
                success: function (res) {
                    $('#transfer_list').html(res);
                },
                error: function () {
                    alert('error');
                    $('#transfer_list').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });

        }
 e.preventDefault();
 });

function writeReason(){
    var input=$("#amount_id").val().replace(/,/gi, "");
     amount=parseInt(input);
     var reason=$("#reason").val();
        if(amount > 0 && reason !=""){
             $('#save_btn').show();
             }else{
               $('#save_btn').hide();
             } 
      }
</script>
<!--shalon mmeta-->
