<?php
               helper('calc');
             $bmodel = new App\Models\BillingModel();
             $report = new App\Models\ReportsModel();
             $amodel = new App\Models\AdmissionModel();
              $smodel = new App\Models\StudentModel();
             $dbname=session()->get('db_name');
             $db = \Config\Database::connect($dbname);
           // $hname=$this->report->get_hostelname($hostel);
            $admission = $amodel->get_student_details('admission_tbl',$where = array('student_id' => $student_id,'status' => 1,'academic_year'=>$year));
              $results=findCalc($student_id,$dbname,$year);

             $period = $bmodel->get_item_name('class_level_tbl', $where = array('id' => $admission[0]->level_id));
           $dateterm = $report->checkTerm_date(date('Y-m-d'),$year,$period[0]->academic_type);
                  //print_r($dateterm);
                    if (is_countable($dateterm) && count($dateterm) > 0) {
                    $term_name=$dateterm[0]->term_name;
                   }else{
                    $dateterm = $report->checkTerm_date2(date('Y-m-d'),$year,$period[0]->academic_type);
                     
                     $term_name=$dateterm[0]->term_name;
                   }
                
                $hst=$admission[0]->hostel_id;
                   //////////////////////////////////////////////
                    $ctrNum="---";
          $tinvoice = $bmodel->get_total_invoice_amount($student_id,$year);
                 if(count($tinvoice)>0)
                 
                 $ctr_num =$bmodel->get_item_name('payment_request',$where=array('student_id'=>$student_id,'trans_no'=>$tinvoice[0]->trans_no,'inv_type'=>0,'trans_type'=>1));
                 if(count($ctr_num)>0){
                    $ctrNum=$ctr_num[0]->reference_no;
                     
                 }
                $total=$tinvoice[0]->amount;
               
                  $dateterm = $report->checkTerm_date(date('Y-m-d'),$year,$period[0]->academic_type);
                 // print_r($dateterm);
                  if (is_countable($dateterm) && count($dateterm) > 0) {
                    $term_name=$dateterm[0]->term_name;
                   }else{
                    $dateterm = $report->checkTerm_date2(date('Y-m-d'),$year,$period[0]->academic_type);
                     
                     $term_name=$dateterm[0]->term_name;
                   }
                  
                   $installments =$bmodel->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$period[0]->academic_type));
                   
                    $ttlAmount = 0;
                     $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                      $ddate="";
                    foreach ($installments as $r) {
                     $i++;
                     if($i==1){
                    $duedate1=$r->due_date;
             
                   $openingbalance=$results[0]['openingbalance'];
                       $ment=$results[0]['ment'];
                       
                        $mbalance=$results[0]['mbalance'];
                    
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[0]['today']==1){
                       $todaybalance=$results[0]['todaybalance']; 
                          }
                     
                    }
                      if($i==2){
        
                         $duedate2=$r->due_date;
           
                         $ment=$results[1]['ment'];
                        
                        $mbalance=$results[1]['mbalance'];
                       
                        $paid_amount=$results[1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[1]['today']==1){
                       $todaybalance=$results[1]['todaybalance']; 
                     }
                     }
                   if($i==3){
                 $duedate3=$r->due_date;
         
                     $ment=$results[2]['ment'];
                       
                        $mbalance=$results[2]['mbalance'];
                       
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[2]['today']==1){
                       $todaybalance=$results[2]['todaybalance'];
                     }
                 }
                     // $tments=$tments+$ment;
                     // $tpaid= $tpaid+$paid_amount;
                     
                      } 
                      $name = $amodel->get_student_details('students',$where = array('id' => $student_id));
                      if($tments - $tpaid >0){
                        $usumbufu="Kamilisha malipo";
                      }else{
                        $usumbufu="";
                      }

                      if($todaybalance <0){
                        $todaybal=0;
                     }else{
                      $todaybal=$todaybalance;  
                     }
                     if(session()->get('db_id')==4){ 

                      $message="Mzazi wa ".$name[0]->first_name.";  Kristo! Baki ya Muhula TZS ".number_format($todaybal)." Baki ya mwaka TZS ".number_format($tments+$openingbalance - $tpaid).". Kamilisha malipo na Mungu akubariki.";
                      }else {
                      $message="Mzazi wa ".$name[0]->first_name."; Baki ya Muhula TZS ".number_format($todaybalance)." Baki ya mwaka TZS ".number_format($tments - $tpaid).". kumb ".$ctrNum." ".$usumbufu."";     
                      }    
                   /////////////////////////////////////////////$ctrNum
                ?>
               
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Message</label>
                <div class="col-sm-8">
                     <textarea cols='35' rows='5' class="form-control form-control-sm" name="message"><?= $message; ?></textarea>
                  <!-- <input type="text" readonly  class="form-control"  value="<?=number_format($todaybalance);?>" > -->
                </div></div>
               <div class="form-group mb-3">
                <div class="col-sm-12">
                    <button class="btn btn-primary float-right" onclick="message_function();" id="send_message">Send</button>
                </div>
            </div>
