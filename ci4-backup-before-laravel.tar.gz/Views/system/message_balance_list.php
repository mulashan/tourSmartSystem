          <?php  
$imodel = new App\Models\ItemsModel();

 $amodel = new App\Models\StudentModel();
 $remodel = new App\Models\ReportsModel();
 ?>
           <style type="text/css">
     a{
        text-decoration: none;
     }
     </style>
<div class="section-body">
    <div class="container-fluid">
       <br><br>
          <!----------------------------------------------------another code here----------------->
 <div class="content-wrapper">
    <section class="content">
        <div class="box box-danger">
           
            <div class="box-body">
          
               
                    <form id="Rept1Result" class="form-inline">

                      <div class="d-flex justify-content-center" style="padding-left: 150px;">
                        <div class="me-3">
                             Level: 
                            <select class="form-control form-select" name="classlevel" id="classlevel" onchange="ShowTerms()">
                                
                                <?php
                               $l = $remodel->get_levels();
                              foreach($l as $le){
                               echo '<option value="' . $le->id . '">' . $le->level_name . '</option>'; 
                              }

                               ?>
                            </select>
                        </div>

                         <div class="me-3">
                             Class: 
                            <select class="form-control form-select" name="class" id="class">
                                <option value="0">All</option>
                                <?php
                               $c = $remodel->get_classes1();
                              foreach($c as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->class_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                      
                         <div class="me-3">
                             Stream: 
                            <select class="form-control form-select" name="stream" id="stream">
                                <option value="0">All</option>
                                <?php
                               $s = $remodel->get_stream1();
                              foreach($s as $cc){
                               echo '<option value="' . $cc->id . '">' . $cc->stream_name . '</option>'; 
                              }

                               ?>
                            </select>
                         </div>
                         </div>
                          <div class="d-flex justify-content-center mt-3" style="padding-left: 150px;">
                         <div class="me-3">
                             Term: 
                            <select class="form-control form-select" name="term" id="terms">

                               </select>
                         </div>
                          <div class="me-3">
                             Status: 
                            <select class="form-control form-select" name="status2" id="status2">
                                <option value="0">All</option>
                                <?php
                               $st = $amodel->getnationalities('student_types_tbl');
                              foreach($st as $cc){
                                if($cc->id==2){
                               echo '<option value="' . $cc->id . '" selected>' . $cc->status_name . '</option>';
                               }else{
                                echo '<option value="' . $cc->id . '" >' . $cc->status_name . '</option>';
                               } 
                              }

                               ?>
                            </select>
                         </div>
                         <button type="submit" class="btn btn-primary">Create</button>
                           </div> 
                    </form>

            
                <hr>
                &nbsp;
                <center>
                    <div id="Rept1ResultViewResults"></div>
                </center>
            <!--   <center>
 <button class="btn btn-primary btn-sm" onclick="printable('Rept1ResultViewResults')"><span class="fa fa-print"></span> Print</button>
</center> -->
            </div>
        </div>
   
<!----------------------------------------------------another code here----------------->
</div>
</div>
<!-- View Modal -->
  <!-- <div id="myModalview" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" > -->
    <div class="modal fade" id="myModalview" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="z-index: 1600;">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content" style="width: 120%">
        <div class="modal-content">
        <div class="modal-header">
         
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
       <div class="modal-body">
          <div id="showLedger"></div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="printable_rept('showLedger')"><i class="fa fa-print"></i> Print</button>
      </div>
      </div>
      
    </div>
  </div>
  </div>

<script type="text/javascript">
   //   resetReceiptData();
   // function resetReceiptData(){
   //      $('#classlevel').val('');
   //        $('#class').val('');
   //        $('#stream').val('');
   // }
   ShowTerms();
   getClasses();
   function getClasses(){
     var clvl = $('#classlevel option:selected').val();
       // alert(clvl); 
         
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                $("#class").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#class").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
   }
      $("#classlevel").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            url: 'class_list',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#class").empty();
                
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                   $("#class").append("<option value='"+id+"'>"+name+"</option>");;
                }
                $("#class").change();
            }
        });
    });

        $("#class").change(function(){
        var clvl = $(this).val(); 
        //alert(clvl); 
         
        $.ajax({
            //url: 'class_list',
             url: '<?php echo base_url() . '/index.php/StudentController/get_stream_details'; ?>',
            type: 'post',
            data: {clvl:clvl},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#stream").empty();
                $("#stream").append("<option value='"+0+"'>All</option>");
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
                    $("#stream").append("<option value='"+id+"'>"+name+"</option>");;
                }
            }
        });
    });
     $(function () {
                                var start = moment();
                                var end = moment();
                                function cb(start, end) {
                                    $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
                                }
                                $('#daterange-btn').daterangepicker({
                                    startDate: start,
                                    endDate: end,
                                    ranges: {
                                        'Today': [moment(), moment()],
                                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                    }
                                }, cb);
                                cb(start, end);

                            });
   $('#Rept1Result').submit(function (e) {
          e.preventDefault();
            var date='<?php echo $date ?>';
            var msg_type='<?php  echo $msg_type; ?>';
           // alert(msg_type);
            $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "class=" + $('#class option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&date="+date + "&msg_type="+ msg_type+"&year="+$('#year option:selected').val()+"&status="+$('#status2 option:selected').val()+"&term="+$('#terms option:selected').val();
          // alert(dta);
            $.ajax({
                type: "POST",
                 url: '<?php echo base_url() . '/index.php/ReportsController/fetch_balance'; ?>',
                data: dta,
                success: function (res) {

                    $('#Rept1ResultViewResults').html(res);
                    if(msg_type==4){
                    $('#birthday').show();    
                }else if(msg_type==3){
                 $('#blc').show();  
                }
                    
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });


       
    });
  
   function ShowTerms(){
         var InputOption = '';
        var data = 'id=' + $('#classlevel option:selected').val()+'&year='+$('#year option:selected').val();
        //alert(data);
        $.ajax({
            type:'POST',
            url: '<?php echo base_url() . '/index.php/SystemController/fetch_terms'; ?>',
            data: data,
            dataType: 'json',
            success:function(data){

                // console.log(data);
                // return;
                var len = data.length;
                $("#terms").empty();
                $("#terms").append("<option value=''>-Choose-</option>");

                // $('#stream').html(data);

                for( var i = 0; i<len; i++){
                 var id = data[i]['id'];
                    var name = data[i]['name'];
                   
                     if(i == 0){
                        InputOption = "<option value='"+id+"' selected>"+name+"</option>";
                    }else{
                        InputOption = "<option value='"+id+"'>"+name+"</option>";
                    }
                    $("#terms").append(InputOption);
                }
                // console.log(sum);

              //  getClass_Charged_items();
            }
        });
    }
   
</script>
