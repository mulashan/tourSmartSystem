<style>
    table {
        table-layout: relative;
        width: 100%;
    }

    th, td {
        word-wrap: break-word;
        word-break: break-word;
        overflow-wrap: break-word;
        white-space: normal; /* Allows text to wrap onto the next line */
    }
</style>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">System Vfd</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Vfd Settings</li>
                </ol>
            </div>
            
              <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#vfd-all">Vfd setting List</a></li>
                    <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#vfd-new">New Vfd setting</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#vfd-all">Vfd setting List</a></li>
                <li></li><li></li>
                    <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#vfd-new">New Vfd setting</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="vfd-all">
               
               
                    <?php 
                       $bmodel = new App\Models\BillingModel();                    
                        $stym = new App\Models\SystemModel();
                
    $vfd=$bmodel->get_item_name('vfd_settings_tbl', $where = array('id !=' => 0,));
                    ?>
                 <div class="card">
                   <div class="table-responsive mt-3" style="overflow-x: auto;">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable">
                            <thead>
                                <tr>
                                    <th>Serial Number</th>
                                    <th>Tin Number</th>
                                    <th>DOC TIN</th>
                                    <th>Cust TIN</th>
                                    <th>vrn</th>
                                    <th>UIN</th>
                                    <th>Name</th>
                                    <th>Address</th>
                                    <th>Region</th>
                                    <th>street</th>
                                    <th>Mobile</th>
                                    <th>Tax office</th>
                                    <th>username</th>
                                    <th>password</th>
                                    <th>licence</th>
                                    <th>server type</th>
                                    <th>url</th>
                                    <th>status</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody >
                      <?php
                if(count($vfd)>0){
                  foreach($vfd as $fd){
                    if($fd->server_type==1){
                        $servertype="Live Server";
                    }else{
                      $servertype="Test Server";  
                    }
                    if($fd->status==1){
                        $status="<span class='text-success'>Active</span>";
                    }else{
                      $status="<span class='text-danger'>Inactive</span>";
                    }
                       ?>
                       <tr>
                      <td><?php echo $fd->serialNum;?></td>
                      <td><?php echo $fd->tinNum;?></td>
                      <td><?php echo $fd->docTin;?></td>
                      <td><?php echo $fd->custTIN ;?></td>
                      <td><?php echo $fd->custVRN;?></td>
                      <td><?php echo $fd->UIN;?></td>
                      <td><?php echo $fd->NAME;?></td>
                      <td><?php echo $fd->ADDRESS;?></td>
                      <td><?php echo $fd->REGION;?></td>
                      <td><?php echo $fd->STREET;?></td>
                      <td><?php echo $fd->MOBILE;?></td>
                      <td><?php echo $fd->TAXOFFICE;?></td>
                      <td><?php echo $fd->username;?></td>
                      <td><?php echo $fd->password;?></td>
                      <td><?php echo $fd->licence;?></td>
                      <td><?php echo $servertype;?></td>
                      <td><?php echo $fd->request_url;?></td>
                      <td><?php echo $status;?></td>
                      </tr>
                       <?php
                        }
                         }
                     ?>  
                         
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <div class="tab-pane" id="vfd-new">
     <!-------------------------------new messages------------------------------------>
                             <div class="card-body">
                                <form class="form-horizontal" id="vfd_data">
                                    <div id="feedback"></div>
                                   <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="acdyr" class="col-sm-4 col-form-label">Serial Number</label>
                                             <div class="col-sm-8">
                                              <input type="text" id="snumber" name="snumber" value="" class="form-control" required="required">
                                            </div>

                                             </div>
                                
                                        <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Tin Number</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="tnumber" name="tnumber" value=""  class="form-control" required="required">
                                            </div>
                                          </div>
                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Customer Tin</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="custTin" name="custTin" value=""  class="form-control" required="required">
                                            </div>
                                          </div>

                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Doc Tin</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="docTin" name="docTin" value=""  class="form-control" required="required">
                                            </div>
                                          </div>

                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Vrn</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="vrn" name="vrn" value=""  class="form-control" required="required">
                                            </div>
                                          </div>

                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Uin</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="uin" name="uin" value=""  class="form-control" required="required">
                                            </div>
                                          </div>
                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Name</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="name" name="name" value=""  class="form-control" required="required">
                                            </div>
                                          </div>

                                           <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Address</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="address" name="address" value=""  class="form-control" required="required">
                                            </div>
                                          </div>

                                           <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Region</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="region" name="region" value=""  class="form-control" required="required">
                                            </div>
                                          </div>

                                           <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Street</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="street" name="street" value=""  class="form-control" required="required">
                                            </div>
                                          </div>

                                           <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Mobile</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="mobile" name="mobile" value=""  class="form-control" required="required">
                                            </div>
                                          </div>

                                           <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Tax office</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="taxoffice" name="taxoffice" value=""  class="form-control" required="required">
                                            </div>
                                          </div>

                                            <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Username</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="username" name="username" value=""  class="form-control" required="required">
                                            </div>
                                          </div>

                                            <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Password</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="password" name="password" value=""  class="form-control" required="required">
                                            </div>
                                          </div>

                                            <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Licence</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="licence" name="licence" value=""  class="form-control" required="required">
                                            </div>
                                          </div>

                                            <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Server Type</label>
                                            <div class="col-sm-8">
                                                <select class="form-control form-select" name="serverType" required="required">
                                                 <option value="1">Live Server</option>
                                                  <option value="2">Test Server</option>
                                             </select>

                                            </div>
                                          </div>

                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Url</label>
                                            <div class="col-sm-8">
                                              <input type="text" id="url" name="url" value=""  class="form-control" required="required">
                                            </div>
                                          </div>

                                          <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">status</label>
                                            <div class="col-sm-8">
                                             <select class="form-control form-select" name="status" required="required">
                                                 <option value="1">Active</option>
                                                  <option value="2">Inactive</option>
                                             </select>
                                            </div>
                                          </div>

                              <!---end balance msg-------------------->
                              <button type="submit" class="btn btn-primary pull-right">Save</button> 
                                          </div>
                                          <div class="col-md-6">
                                      
                                          </div>
                                    </form>

                                          </div>
     <!------------------------------------------------------------------>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="viewDetails" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="view_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
 
  $("#vfd_data").submit(function (e) {
      
       //alert(cashAmt);
        var dta = $("#vfd_data").serialize();
            // alert(dta);
            // return;
            $.ajax({
                type: "POST",
              url: '<?php echo base_url() . '/index.php/SystemController/save_vfd_details'; ?>',

                data: dta,
                success: function (res) {
                    if(res==1){
                       swal('success','saved successfully!','success');
                       location.reload(); 
                    }else{
                    swal('error','sorry!, something went wrong','error');
                    }
                   
                },
                error: function () {
                   swal('error','sorry!, something went wrong','error');
                }
            });
        e.preventDefault();
    });
</script>
