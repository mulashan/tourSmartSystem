<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<?php
              helper('calc');
             $bmodel = new App\Models\BillingModel();
             $smodel = new App\Models\StudentModel();
             $report = new App\Models\ReportsModel();
             $dbname=session()->get('db_name');
            $db = \Config\Database::connect($dbname);
           // $hname=$this->report->get_hostelname($hostel);
            $clname="";
            if($classlevel==0){
                $clname="All Level,";
            }else{
                if(count($cl)>0)
              $clname=$cl[0]->level_name;  
            }
            if($class==0){
                $cname="All Classes";
            }else{
                if(count($cl)>0)
              $cname=$cl[0]->class_name;  
            }
            if($stream==0){
                $str="All Stream";
            }else{
                if(count($cl)>0)
              $str=$cl[0]->stream_name;  
            }
             $period = $bmodel->get_item_name('class_level_tbl', $where = array('id' => $cl[0]->level_id));
                $schoolname=$report->get_schoolname();

                 $dateterm = $report->checkTerm_date(date('Y-m-d'),$year,$period[0]->academic_type);
                  //print_r($dateterm);
                  if (is_countable($dateterm) && count($dateterm) > 0) {
                    $term_name=$dateterm[0]->term_name;
                   }else{
                    $dateterm = $report->checkTerm_date2(date('Y-m-d'),$year,$period[0]->academic_type);
                     
                     $term_name=$dateterm[0]->term_name;
                   }
                ?>
               
            <div id="tobeprinted">
                <form id="message_form" class="form-inline">
              <div class="card">
               <div class="table-responsive mt-3">
                <button type="button" class="btn btn-primary mb-3 btnp" style="float:right;" onclick="send_messages()" id="message_sent"><i class=""></i>send message</button>
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"   id="myTable1">
                           <thead>
                             <tr>
                                <th>#</th>
                                 <td> <input type="checkbox" name="" value="" onclick="Allcheckbox()" id="Allselected"> All</td>
                                 <th>Acdmc yr</th>
                                 <th>Names</th>
                                 <th>Class</th>
                                 <th>Stream</th>
                                 <th>Type</th>
                                 <th>For</th>
                                 <th>Phone</th>
                                 <th>1st term</th>
                                 <th>2nd Term</th>
                                 <?php  if(session()->get('db_id')!=4){?>
                                 <th>3rd Term</th>
                             <?php }?>
                             <th>4th Term</th>
                                 <th>Total</th>
                                 <th>CTR NO</th>
                                 <th>msg status</th>
                                 <th>Sms Cost</th>
                                </tr>
                                <thead>
                                    <tbody>
                                <?php
                            $n=0;
                            $female=0;
                               $male=0;
                               $day=0;
                               $board=0;
                               $streamA=0;
                               $streamB=0;
                               $ne=0;
                               $c=0;
                               $holid_student=array();
                            if(count($cl)>0){
                               
                                foreach($cl as $le){
                                    $n++;
                                  if($le->gender=='Female'){
                                    $female=$female+1;
                                  }
                                  if($le->gender=='Male'){
                                    $male=$male+1;
                                  }
    //////////////////////  
                          
    ////////////////////////////////////////////////////////////////////
                                  $student_id=$le->id;
                              $results=findCalc($student_id,$dbname,$year);
                                  $type=$le->admission_type;
                                  $hst=$le->admission_type;
                                  if($type==3){
                                    $tp='B';
                                    $board++;
                                  }else{
                                     $tp='D';
                                     $day++;
                                  }

                                  if($le->stream_name=='A'){
                                    $streamA=$streamA+1;
                                  }else{
                                     $streamB=$streamB+1;
                                  }
                                  if($le->adimit_for==2){
                                    $new="New Comer";
                                    $ne++;
                                  }else{
                                     $new="Continous";
                                     $c++;
                                  }
                                  // $diff=$this->report->calculateDifference($class,$classlevel,$stream,$student_id);

                              $ctr_number="";
                 $tinvoice = $bmodel->get_total_invoice_amount($student_id,$year);
                 if(count($tinvoice)>0){

                      foreach($tinvoice as $ti){
                    $adms =$bmodel->get_item_name('invoice_type_transaction',$where=array('trans_no'=>$ti->trans_no,'invoice_type_id'=>2));
                    if(count($adms)>0){
                     $ctr =$bmodel->get_item_name('payment_request',$where=array('student_id'=>$student_id,'trans_no'=>$ti->trans_no,'inv_type'=>0,'trans_type'=>1));
                 if(count($ctr)>0){
                    $ctr_number=$ctr[0]->reference_no;
                     
                 }   
                    }
                 }
                $total=$tinvoice[0]->amount;
              //check sms status
             $msg_status = $bmodel->get_item_name_desc('message_groups_tbl', $where = array('trans_number' => $tinvoice[0]->trans_no,'message_type'=>8));
                                     if(count($msg_status)>0){
                                       
                                         $msg_st = $bmodel->get_item_name('messages', $where = array('send_no' => $msg_status[0]->send_number));
                                         
                            if(count($msg_st)>0){

                        ///here we go
                      if($msg_st[0]->time_sent==null){
                             $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_RETURNTRANSFER => 1,
                        CURLOPT_URL => 'http://www.sms.co.tz/api.php?do=dlr&id=' . $msg_st[0]->message_id . '&username=' . SMS_UNAME . '&password=' . SMS_PASSWORD . '&senderid=' . SENDER_ID . '',
                    ));
                    $msg_status = curl_exec($curl);
                    // echo $msg_status;
                       list($err,$er)=explode(',', $msg_status);
               if($err=='ERR'){
          //  echo $err;
            }else{
                    if($msg_status != ""){

                       list($sntdate, $stts, $deldate) = explode(',', $msg_status);

                       $tempsmsdata = array(
                           'sent_status' => 2, //Sent and delivered
                           'time_sent' => $sntdate,
                           'status_description' => $stts,
                           'time_delivered' => $deldate
                       );
                       //print_r($tempsmsdata);
                        $smodel->update_table_details('messages',$where = array('message_id' => $msg_st[0]->message_id),$tempsmsdata);
                       }
                     }
                     }
                    ?>
                                      
                        <?php
                         $msg_s = $bmodel->get_item_name('messages', $where = array('message_id' => $msg_st[0]->message_id));

                              $del=$msg_s[0]->status_description;
                                 $time=$msg_s[0]->time_delivered;
                                $stata='<span style="color:green">'.$del.'</br>'.$time.'</span>';
                                 $row='blue';
                                     }else{
                                         
                                         $stata='<span style="color:red">Not Sent'; 
                                          $row='black';
                                     }
                                     }else{
                                           
                                          $row='black';
                                       $stata='<span style="color:red">Not Sent';  
                                     }
                             /////////end check sms
                
                   
                  $mbalance1=0;
                  $mbalance2=0;
                  $mbalance3=0;
                  $mbalance4=0;
                 
                   $dateterm = $report->checkTerm_date(date('Y-m-d'),$year,$period[0]->academic_type);
                  //print_r($dateterm);
                   if (is_countable($dateterm) && count($dateterm) > 0) {
                    $term_name=$dateterm[0]->term_name;
                   }else{
                    $dateterm = $report->checkTerm_date2(date('Y-m-d'),$year,$period[0]->academic_type);
                     
                     $term_name=$dateterm[0]->term_name;
                   }
                  
                   $installments = $bmodel->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$period[0]->academic_type));
                    
                    $ttlAmount = 0;
                     $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                      $ddate="";
                      //echo count($installments);
                    foreach ($installments as $r) {
                      
                     $i++;
                   
                     if($i==1){

                 $duedate1=$r->due_date;
             
                   $openingbalance=$results[0]['openingbalance'];
                       $ment=$results[0]['ment'];
                        $mbalance1=$ment;
                        $mbalance=$results[0]['mbalance'];
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[0]['today']==1){
                       $todaybalance=$results[0]['todaybalance']; 
                     }
                     }
                      if($i==2){
                       
                          $duedate2=$r->due_date;
           
                         $ment=$results[1]['ment'];
                        $mbalance2=$ment;
                        $mbalance=$results[1]['mbalance'];
                        $paid_amount=$results[1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[1]['today']==1){
                       $todaybalance=$results[1]['todaybalance']; 
                     }
                     }
                   if($i==3){
                  $duedate3=$r->due_date;
         
                     $ment=$results[2]['ment'];
                        $mbalance3=$ment;
                        $mbalance=$results[2]['mbalance'];
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[2]['today']==1){
                       $todaybalance=$results[2]['todaybalance']; 
                     }
                     }

                      if($i==4){
                  $duedate4=$r->due_date;
         
                     $ment=$results[3]['ment'];
                        $mbalance4=$ment;
                        $mbalance=$results[3]['mbalance'];
                        $paid_amount=$results[3]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[3]['today']==1){
                       $todaybalance=$results[3]['todaybalance']; 
                     }
                     }
                     
                     
                      }  
                      if($tments==0){
                        continue;
                      }
                       $holid_student[]=array($le->id);
                  $phone = $db->query('SELECT phone1 FROM parents_tbl,parents_students_tbl WHERE parents_tbl.id = parents_students_tbl.parent_id AND'
               . ' parents_tbl.bill_account = 1  AND parents_students_tbl.student_id ='.$student_id.'');
             $pn = $phone->getResult(); 
               if(count($pn)>0){
                $phone_number=$pn[0]->phone1;
               }else{
                 $phone_number="No Phone Number";
               }        
    ///////////////////////     ///////////////////////////////////////////////////////////////////////////////////
    if($mbalance3>0){
       $message=$le->first_name.", Kumb No: ".$ctr_number.", 1st - ".number_format($mbalance1)."/- kabla ya ".date('Y-m-d',strtotime($duedate1)).", 2nd - ".number_format($mbalance2)."/- kabla ya ".date('Y-m-d',strtotime($duedate2)). ", 3rd- ".number_format($mbalance3)."/- kabla ya ".date('Y-m-d',strtotime($duedate3)).". Ada ".$year.".";  
      
    }else if($mbalance4>0){
       $message=$le->first_name.", Kumb No: ".$ctr_number.", 1st - ".number_format($mbalance1)."/- kabla ya ".date('Y-m-d',strtotime($duedate1)).", 2nd - ".number_format($mbalance2)."/- kabla ya ".date('Y-m-d',strtotime($duedate2)). ", 3rd- ".number_format($mbalance3)."/- kabla ya ".date('Y-m-d',strtotime($duedate3)).", 4th- ".number_format($mbalance4)."/- kabla ya ".date('Y-m-d',strtotime($duedate4)).". Ada ".$year.".";  
      
    }
    else{
       $message=$le->first_name.", Kumb No: ".$ctr_number.", 1st - ".number_format($mbalance1)."/- kabla ya ".date('Y-m-d',strtotime($duedate1)).", 2nd - ".number_format($mbalance2)."/- kabla ya ".date('Y-m-d',strtotime($duedate2)). ". Ada ".$year.".";  
    }
                         
         ?> 
                           <input type="hidden" name="trans<?=$student_id;?>" value="<?=$tinvoice[0]->trans_no;?>"> 
                               <input type="hidden" name="phone<?=$student_id;?>" value="<?=$phone_number;?>"> 
                            <input type="hidden" name="message<?=$student_id;?>" value="<?=$message;?>">   

                                <tr style="color: <?php echo $row;?>;" onclick="selectRow('<?php echo $student_id; ?>')" id="<?php echo $student_id; ?>">
                                      <td style=""><?=$n;?></td>
                                  <td>  <input type="checkbox" name="selected[]" value="<?php echo $student_id; ?>" onclick="checkbox('<?php echo $student_id; ?>')" id="selected<?php echo $student_id; ?>"></td>

                                     <td style=""><?=$le->academic_year;?></td>
                                    <td><?=$le->full_name?></td>
                                    <!-- <td><?=$le->birth_date?></td>
                                    <td><?=(date('Y') - date('Y',strtotime($le->birth_date)))?></td>
                                    <td><?=$le->gender?></td> -->
                                    <td><?=$le->class_name?></td>
                                    <td><?=$le->stream_name?></td>
                                    <td><?=$tp?></td>
                                    <td><?=$new?></td>
                                    <td><?=$phone_number;?></td>
                                 <td class="text-right"><?=number_format($mbalance1)?></span></td>
                                 <td class="text-right"><?=number_format($mbalance2)?></span></td>
                                  <?php  if(session()->get('db_id')!=4){?>
                                 <td class="text-right"><?=number_format($mbalance3)?></span></td>
                             <?php } ?>
                             <?php  if($mbalance4 >0){?>
                                 <td class="text-right"><?=number_format($mbalance4)?></span></td>
                             <?php }else{ ?>
                             <td></td>
                         <?php } ?>
                                 <td class="text-right"><?=number_format($mbalance1+$mbalance2+$mbalance3+$mbalance4)?></span></td>
                                  <td><?=$ctr_number?></td>
                                  <td><?=$stata;?></td>
                                      <td class="text-right">45</td>
                                   </tr>
                               
                                    
                                   <?php
                 }
                                   
                                }

                        }else{
                             echo '<tr>';
                                  
                                    echo '<td colspan="7"> Currently there is no any history.</td>';
                            echo '<tr>';   
                            }
      
          ?>
           <tr>
            <td colspan="14"></td>
            <td><b>Total Cost</b></td>
             <td class="text-right"><b><?php echo number_format(45*$n); ?></b></td>
        </tr>
          </tbody>
           </table>

         </div>
  </div>
  </form>
  </div>

<noscript>
    <style>
        .table-condensed{
            padding-bottom: 20px; 

        }
        table.table{
            border-collapse:collapse;
            border: 1px solid black;
            width:80%;
          
            margin-left: auto;
            margin-right: auto;
/*            page-break-inside: avoid;*/
           
        }
         table.table td{
         border:1px solid black;
           font-size: 12px;
         }
        #myTable td,#myTable th{
            border:1px solid black;
           font-size: 12px;
           }
        h6{
            text-align: center;
        }
        .btnp,.viewbtn{
           display: none;
        }
        #myTable_wrapper .dataTables_filter,
        #myTable_wrapper .dataTables_paginate,
        #myTable_wrapper .dataTables_length {
         display: none;
}
 @media print {
      .table {
        border-collapse: collapse !important;
        border: 1px solid black !important;
      }
      }
      table.toba td{
        font-size: 12px;
      }
        
    </style>
</noscript>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
  <script>
   $(document).ready(function() {
  var table = $("#myTable1").DataTable({
    dom: 'f', // Show only the search input
    paging: false, // Disable pagination
    lengthChange: false, // Disable entries select
  });
});
 function selectRow(id){
         var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {
    row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {

    row.style.backgroundColor = 'black';
      row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        }
      
      }
      function checkbox(id){
        var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {

    row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {
    row.style.backgroundColor = 'black';
      row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        } 
      }
function Allcheckbox(){
        var values=<?php echo json_encode($holid_student);?>;
        //alert(values.length);
        var rememberAll = document.getElementById("Allselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
            if(rememberAll.checked){
     remember.checked=true;  
      if (row) {
    
    row.style.backgroundColor = 'black';
    row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=false; 
      
       if (row) {
      row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }  
        }
        }
      }

     
      function send_messages() {
        $('#message_sent').prop("disabled", true);
          var data= $("#invoicebtn").serialize()+'&'+$('#message_form').serialize()+'&'+$('#header_form').serialize();
              // alert(data);
              // return;
            $.ajax({
                 beforeSend: function () {
                   Swal.fire({
              title: 'Please wait...',
              html: '<span class="text-danger">Sending Message</span>',
              icon: 'info',
              allowOutsideClick: false,
              showConfirmButton: false,
              timerProgressBar: true,
              onBeforeOpen: () => {
                Swal.showLoading();
              }
            });
                  
            },
                type: "POST",
              url: '<?php echo base_url() . '/index.php/BillingController/send_installment_messages'; ?>',
                data: data,
                success: function (res) {
                    refreshPage();
                    if(res){
                      
                         swal('success','Message sent successfuly','success');
                         
                    }else{
                        swal('error','something went wrong','error'); 
                    }
                
                },
                error: function () {
                    alert('something went wrong');
                    refreshPage();
                }
            });
        };
        function refreshPage(){
            Swal.close();
            var msg_type=6;
             var date=$('#invoice_date').val();
         $('#Rept1ResultViewResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
            var dta = "class=" + $('#class option:selected').val()+ "&classlevel="+$('#classlevel option:selected').val()+ "&stream="+$('#stream option:selected').val()+ "&date="+date + "&msg_type="+ msg_type+"&year="+$('#year option:selected').val();
           // alert(dta);
         $.ajax({
                type: "POST",
              url: '<?php echo base_url() . '/index.php/ReportsController/fetch_balance'; ?>',
                data: dta,
                success: function (res) {
                    $('#Rept1ResultViewResults').html(res);
                },
                error: function () {
                    $('#Rept1ResultViewResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
                }
            });
      }

 </script>
