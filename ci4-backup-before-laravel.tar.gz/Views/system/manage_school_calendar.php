<?php
$eventItem = $event[0];
$smsStudentAudience = ! empty($sms_student_audience);
$smsStaffAudience = ! empty($sms_staff_audience);
?>
<div id="updateFeedback"></div>
<form class="form-horizontal" id="UpdateSchoolCalendar">
    <input type="hidden" name="id" value="<?= $eventItem->id; ?>">
    <div class="form-group row">
        <label class="col-md-3 col-form-label">Event Date <span class="text-danger">*</span></label>
        <div class="col-md-8">
            <input type="date" name="event_date" class="form-control form-control-sm" value="<?= esc($eventItem->event_date); ?>" required="required">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label">Event Description <span class="text-danger">*</span></label>
        <div class="col-md-8">
            <textarea name="event_description" rows="4" class="form-control form-control-sm" required="required"><?= esc($eventItem->event_description); ?></textarea>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label">Event Participants <span class="text-danger">*</span></label>
        <div class="col-md-8 pt-2">
            <label class="custom-control custom-checkbox custom-control-inline">
                <input type="checkbox" class="custom-control-input" name="parents" id="edit_parents_participant" value="1" <?= (int) $eventItem->parents === 1 ? 'checked' : ''; ?>>
                <span class="custom-control-label">Parents</span>
            </label>
            <label class="custom-control custom-checkbox custom-control-inline">
                <input type="checkbox" class="custom-control-input" name="students" id="edit_students_participant" value="1" <?= (int) $eventItem->students === 1 ? 'checked' : ''; ?>>
                <span class="custom-control-label">Students</span>
            </label>
            <label class="custom-control custom-checkbox custom-control-inline">
                <input type="checkbox" class="custom-control-input" name="staff" id="edit_staff_participant" value="1" <?= (int) $eventItem->staff === 1 ? 'checked' : ''; ?>>
                <span class="custom-control-label">Staff</span>
            </label>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label">Status <span class="text-danger">*</span></label>
        <div class="col-md-8">
            <select name="status" class="form-control form-control-sm" required="required">
                <option value="1" <?= (int) $eventItem->status === 1 ? 'selected' : ''; ?>>Active</option>
                <option value="2" <?= (int) $eventItem->status !== 1 ? 'selected' : ''; ?>>Inactive</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label">SMS Notification</label>
        <div class="col-md-8 pt-2">
            <label class="custom-control custom-checkbox custom-control-inline">
                <input type="checkbox" class="custom-control-input" name="sms_enabled" id="edit_sms_enabled" value="1" <?= (int) ($eventItem->sms_enabled ?? 0) === 1 ? 'checked' : ''; ?>>
                <span class="custom-control-label">Enable SMS notification</span>
            </label>
        </div>
    </div>

    <div id="editSchoolCalendarSmsArea" style="<?= (int) ($eventItem->sms_enabled ?? 0) === 1 ? '' : 'display:none;'; ?>">
        <div class="form-group row" id="editSchoolCalendarSmsAudienceRow" style="<?= (int) ($eventItem->sms_enabled ?? 0) === 1 ? '' : 'display:none;'; ?>">
            <label class="col-md-3 col-form-label">Send SMS To</label>
            <div class="col-md-8 pt-2">
                <label class="custom-control custom-checkbox custom-control-inline" id="editStudentSmsAudienceOption" style="<?= ((int) $eventItem->parents === 1 || (int) $eventItem->students === 1) ? '' : 'display:none;'; ?>">
                    <input type="checkbox" class="custom-control-input" name="sms_to_students" id="edit_sms_to_students" value="1" <?= $smsStudentAudience ? 'checked' : ''; ?>>
                    <span class="custom-control-label">Students / Parents</span>
                </label>
                <label class="custom-control custom-checkbox custom-control-inline" id="editStaffSmsAudienceOption" style="<?= (int) $eventItem->staff === 1 ? '' : 'display:none;'; ?>">
                    <input type="checkbox" class="custom-control-input" name="sms_to_staff" id="edit_sms_to_staff" value="1" <?= $smsStaffAudience ? 'checked' : ''; ?>>
                    <span class="custom-control-label">Staff</span>
                </label>
            </div>
        </div>

        <div class="form-group row" id="editSchoolCalendarSmsScheduleRow" style="<?= (int) ($eventItem->sms_enabled ?? 0) === 1 ? '' : 'display:none;'; ?>">
            <label class="col-md-3 col-form-label">SMS Schedule <span class="text-danger">*</span></label>
            <div class="col-md-8">
                <div class="alert alert-info py-2">
                    Add one or more dates and times for this SMS. Each schedule will be sent once.
                </div>
                <div id="editSchoolCalendarSmsSchedules">
                    <?php foreach (($sms_schedules ?? []) as $schedule): ?>
                        <div class="border rounded p-2 mb-2 school-calendar-schedule-row">
                            <div class="row align-items-end">
                                <div class="col-md-10">
                                    <label class="mb-1">Schedule date and time</label>
                                    <input
                                        type="datetime-local"
                                        class="form-control form-control-sm"
                                        name="sms_schedule_at[]"
                                        value="<?= esc($schedule['scheduled_at_input'] ?? ''); ?>"
                                    >
                                    <?php if (! empty($schedule['sent_at'])): ?>
                                        <small class="text-success d-block mt-1">Sent at <?= date('d M Y H:i', strtotime($schedule['sent_at'])); ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-2 mt-2 mt-md-0">
                                    <button type="button" class="btn btn-danger btn-sm w-100 remove-school-calendar-schedule">Remove</button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="btn btn-primary btn-sm mt-2" onclick="addSchoolCalendarScheduleRow('edit')">
                    <i class="fa fa-plus"></i> Add Schedule
                </button>
            </div>
        </div>

        <div id="editSchoolCalendarStudentSmsSection" style="<?= $smsStudentAudience ? '' : 'display:none;'; ?>">
            <div class="form-group row">
                <label class="col-md-3 col-form-label">Student/Parent SMS <span class="text-danger">*</span></label>
                <div class="col-md-8">
                    <textarea name="sms_message" id="edit_sms_message" rows="4" class="form-control form-control-sm" placeholder="Write student or parent SMS notification message here"><?= esc($eventItem->sms_message ?? ''); ?></textarea>
                    <small class="text-muted d-block mt-2">
                        Use placeholders: <b>#studentFirstName</b>, <b>#studentFullName</b>, <b>#eventDate</b>, <b>#eventDescription</b>.
                        SMS will follow the schedule dates and times selected above.
                    </small>
                    <small class="text-muted d-block mt-1">
                        SMS message will be charged every 153 characters.
                        Characters like <b>@</b> <b>&lt;</b> <b>&gt;</b> <b>^</b> <b>{</b> <b>}</b> <b>\</b> <b>/</b> <b>%</b> <b>'</b> <b>~</b> take up 2 characters. Please account for this when writing your message.
                    </small>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3 col-form-label">Send Type <span class="text-danger">*</span></label>
                <div class="col-md-8">
                    <select class="form-control form-control-sm" name="send_type" id="edit_send_type">
                        <option value="">Select Type</option>
                        <option value="1" <?= (int) ($eventItem->send_type ?? 0) === 1 ? 'selected' : ''; ?>>Individual</option>
                        <option value="2" <?= (int) ($eventItem->send_type ?? 0) === 2 ? 'selected' : ''; ?>>Group</option>
                    </select>
                </div>
            </div>

            <div id="editGroupSmsControls" style="<?= (int) ($eventItem->send_type ?? 0) === 2 ? '' : 'display:none;'; ?>">
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Group Filters</label>
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-4 mb-2">
                                <label class="mb-1">Academic year</label>
                                <select class="form-control form-control-sm" name="sms_year" id="edit_sms_year">
                                    <?php foreach (($year_options ?? []) as $year): ?>
                                        <option value="<?= $year; ?>" <?= (int) ($eventItem->sms_target_year ?? $current_year ?? date('Y')) === (int) $year ? 'selected' : ''; ?>><?= $year; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-2">
                                <label class="mb-1">Level</label>
                                <select class="form-control form-control-sm" name="sms_level_id" id="edit_sms_level_id">
                                    <option value="0">All</option>
                                    <?php foreach (($levels ?? []) as $level): ?>
                                        <option value="<?= $level->id; ?>" <?= (int) ($eventItem->sms_target_level_id ?? 0) === (int) $level->id ? 'selected' : ''; ?>><?= esc($level->level_name); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-2">
                                <label class="mb-1">Class</label>
                                <select class="form-control form-control-sm" name="sms_class_id" id="edit_sms_class_id">
                                    <option value="0">All</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-2">
                                <label class="mb-1">Stream</label>
                                <select class="form-control form-control-sm" name="sms_stream_id" id="edit_sms_stream_id">
                                    <option value="0">All</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-2">
                                <label class="mb-1">Status</label>
                                <select class="form-control form-control-sm" name="sms_status" id="edit_sms_status">
                                    <option value="0">All</option>
                                    <?php foreach (($student_statuses ?? []) as $status): ?>
                                        <option value="<?= $status->id; ?>" <?= (int) ($eventItem->sms_target_status ?? 2) === (int) $status->id ? 'selected' : ''; ?>><?= esc($status->status_name); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <button type="button" class="btn btn-primary btn-sm mt-2" onclick="loadSchoolCalendarSmsGroup('edit')">Create</button>
                    </div>
                </div>
            </div>

            <div id="editIndividualSmsControls" style="<?= (int) ($eventItem->send_type ?? 0) === 1 ? '' : 'display:none;'; ?>">
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Student Search</label>
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-4 mb-2">
                                <label class="mb-1">Academic year</label>
                                <select class="form-control form-control-sm" name="sms_year_individual" id="edit_sms_year_individual">
                                    <?php foreach (($year_options ?? []) as $year): ?>
                                        <option value="<?= $year; ?>" <?= (int) ($eventItem->sms_target_year ?? $current_year ?? date('Y')) === (int) $year ? 'selected' : ''; ?>><?= $year; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-2">
                                <label class="mb-1">Status</label>
                                <select class="form-control form-control-sm" name="sms_status_individual" id="edit_sms_status_individual">
                                    <option value="0">All</option>
                                    <?php foreach (($student_statuses ?? []) as $status): ?>
                                        <option value="<?= $status->id; ?>" <?= (int) ($eventItem->sms_target_status ?? 2) === (int) $status->id ? 'selected' : ''; ?>><?= esc($status->status_name); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-2">
                                <label class="mb-1">Search Name</label>
                                <div class="input-group">
                                    <input type="text" class="form-control form-control-sm" name="student_search" id="edit_student_search" placeholder="Student name / admission no">
                                    <button type="button" class="btn btn-primary btn-sm" onclick="loadSchoolCalendarSmsIndividual('edit')"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-group row">
                <label class="col-md-3 col-form-label">Student Recipients</label>
                <div class="col-md-8">
                    <div id="editSchoolCalendarSmsRecipients">
                        <?php
                        echo view('system/forms/school_calendar_sms_recipients', [
                            'students' => $sms_students ?? [],
                            'selected_student_ids' => $selected_student_ids ?? [],
                            'mode' => 'edit',
                            'empty_message' => 'Create a group or search a student to load recipients.',
                        ]);
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <div id="editSchoolCalendarStaffSmsSection" style="<?= $smsStaffAudience ? '' : 'display:none;'; ?>">
            <div class="form-group row">
                <label class="col-md-3 col-form-label">Staff SMS <span class="text-danger">*</span></label>
                <div class="col-md-8">
                    <textarea name="staff_sms_message" id="edit_staff_sms_message" rows="4" class="form-control form-control-sm" placeholder="Write staff SMS notification message here"><?= esc($eventItem->staff_sms_message ?? ''); ?></textarea>
                    <small class="text-muted d-block mt-2">
                        Use placeholders: <b>#staffFirstName</b>, <b>#staffFullName</b>, <b>#eventDate</b>, <b>#eventDescription</b>.
                        SMS will follow the schedule dates and times selected above.
                    </small>
                    <small class="text-muted d-block mt-1">
                        SMS message will be charged every 153 characters.
                        Characters like <b>@</b> <b>&lt;</b> <b>&gt;</b> <b>^</b> <b>{</b> <b>}</b> <b>\</b> <b>/</b> <b>%</b> <b>'</b> <b>~</b> take up 2 characters. Please account for this when writing your message.
                    </small>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3 col-form-label">Staff Search</label>
                <div class="col-md-8">
                    <div class="input-group">
                        <input type="text" class="form-control form-control-sm" name="staff_search" id="edit_staff_search" placeholder="Staff name / phone">
                        <button type="button" class="btn btn-primary btn-sm" onclick="loadSchoolCalendarStaff('edit')">
                            <i class="fa fa-search"></i> Load Staff
                        </button>
                    </div>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3 col-form-label">Staff Recipients</label>
                <div class="col-md-8">
                    <div id="editSchoolCalendarStaffRecipients">
                        <?php
                        echo view('system/forms/school_calendar_staff_recipients', [
                            'staffs' => $sms_staffs ?? [],
                            'selected_staff_ids' => $selected_staff_ids ?? [],
                            'mode' => 'edit',
                            'empty_message' => 'Search staff to load recipients.',
                        ]);
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-md-3 col-form-label"></label>
        <div class="col-md-8">
            <button type="button" class="btn btn-danger" onclick="deleteSchoolCalendarEvent('<?= $eventItem->id; ?>')"><i class="fa fa-trash"></i> Delete</button>
            <button type="submit" class="btn btn-primary float-right">Update</button>
        </div>
    </div>
</form>

<script type="text/javascript">
    initSchoolCalendarSmsForm('edit', {
        selectedClassId: <?= (int) ($eventItem->sms_target_class_id ?? 0); ?>,
        selectedStreamId: <?= (int) ($eventItem->sms_target_stream_id ?? 0); ?>,
        preserveRecipients: true,
        preserveAudienceSelection: true
    });

    $('#UpdateSchoolCalendar').submit(function(e){
        $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/update_school_calendar'; ?>',
            data: $(this).serialize(),
            success: function(res){
                var data = JSON.parse(res);
                if (data['status'] == "0") {
                    $('#updateFeedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>' + data['statusDesc'] + '</div>');
                    loadSchoolCalendarResults();
                    setTimeout(function(){
                        $('#editModal').modal('hide');
                    }, 700);
                } else {
                    $('#updateFeedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>' + data['statusDesc'] + '</div>');
                }
            },
            error: function(){
                $('#updateFeedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry! Something went wrong while updating calendar event.</div>');
            }
        });
        e.preventDefault();
    });

    function deleteSchoolCalendarEvent(id) {
        swal({
            title: "Are you sure?",
            text: "This school calendar event will be deleted.",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false
        }, function(isConfirm) {
            if (isConfirm) {
                $.ajax({
                    type: "POST",
                    url: '<?php echo base_url() . '/delete_school_calendar'; ?>',
                    data: 'id=' + id,
                    success: function(res){
                        var data = JSON.parse(res);
                        if (data['status'] == "0") {
                            swal("Deleted!", data['statusDesc'], "success");
                            loadSchoolCalendarResults();
                            setTimeout(function(){
                                $('#editModal').modal('hide');
                            }, 700);
                        } else {
                            swal("Error", "Failed to delete event.", "error");
                        }
                    },
                    error: function(){
                        swal("Error", "Failed to delete event.", "error");
                    }
                });
            } else {
                swal("Cancelled");
            }
        });
    }
</script>
