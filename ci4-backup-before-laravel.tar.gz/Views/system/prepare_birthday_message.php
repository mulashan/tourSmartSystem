<?php
             $bmodel = new App\Models\BillingModel();
             $report = new App\Models\ReportsModel();
              $amodel = new App\Models\AdmissionModel();
              $dbname=session()->get('db_name');
            $db = \Config\Database::connect($dbname);
        
              ?>
       
                <?php
            if(count($cl)>0){
                 $messagex="Happy Birthday# Student first Name. Wishing you a very happy birthday filled with many achievements and success!";
               ?>
              
                <?php
                }
                ?>
              <div class="card">
               <div class="table-responsive mt-3">
                
                        <table class="table table-hover table-vcenter mb-0 text-nowrap table-bordered"   id="">
                           <thead>
                            <tr>
                                <th>#</th>
                                 <th>Names</th>
                                <th>Birth date</th>
                                 <th>Age</th>
                                 <th>Gender</th>
                                 <th>Class</th>
                                 <th>Stream</th>
                                 
                                 <th>Phone</th>
                                 <th>Sms Cost</th>
                                </tr>
                                <thead>
                                    <tbody>
                                <?php
                            $n=0;
                            $female=0;
                               $male=0;
                               $day=0;
                               $board=0;
                               $streamA=0;
                               $streamB=0;
                               $ne=0;
                               $c=0;
                            
                               if(count($cl)>0){
                                foreach($cl as $le){
                                    $n++;
                                
    //////////////////////  ////////////////////////////////////////////////////////////////////////////////
                                  $student_id=$le->id;
                                
                $phone = $db->query('SELECT phone1 FROM parents_tbl,parents_students_tbl WHERE parents_tbl.id = parents_students_tbl.parent_id AND'
               . ' parents_tbl.bill_account = 1  AND parents_students_tbl.student_id ='.$student_id.'');
             $pn = $phone->getResult(); 
               if(count($pn)>0){
                $phone=$pn[0]->phone1;
               }else{
                 $phone="No Phone Number";
               }
    ///////////////////////
       //  $std=$le->student_id; 
                 $name = $amodel->get_student_details('students',$where = array('id' => $student_id));
                     
                      $message="Happy Birthday ".$name[0]->first_name.".  Wishing you a very happy birthday filled with many achievements and success!";   
                   
        ///////////////////////////////////////////////////////////////////////////////////
                         
                              ?> 

                            <input type="hidden" name="student[]" value="<?=$student_id;?>"> 
                            <input type="hidden" name="phone<?=$student_id;?>" value="<?=$phone;?>"> 
                            <input type="hidden" name="message<?=$student_id;?>" value="<?=$message;?>"> 
                                    <tr>
                                    <td><?php echo $n?></td>
                                   <td><?=$le->full_name?></td>
                                   <td style=""><?=$le->birth_date?></td>
                                    <td style=""><?=(date('Y') - date('Y',strtotime($le->birth_date)))?></td> 
                                     <td style=""><?=$le->gender?></td>
                                    <td><?=$le->class_name?></td>
                                    <td><?=$le->stream_name?></td>
                                   
                                    <td><?=$phone;?></td>
                                   <td class="text-center">45</td>
                                   </tr>
                                  
                                   <?php
                                  }
                                ?>
                           <tr>
                           <td></td> <td></td> <td></td> <td></td> <td></td> <td></td> <td>Total</td>
                            <td></td> <td class="text-center"><?php echo number_format($n*45);?></td>
                           </tr>
                                <?php
                                }else{
                                    ?>
                               <tr>
                           <td colspan="7"> Currently there is no any history.</td>
                            
                           </tr>
                                    <?php
                                   }
                                  ?>
          </tbody>
           </table>
 
      </div>

  
  </div>
  <?php
    if(count($cl)>0){

        ?>
  <div class="form-group mb-3">
                <div class="col-sm-12">
                    <button class="btn btn-primary float-right" onclick="message_group_function();" id="send_message">Send Messages</button>
                </div>
            </div>
        <?php }?>

  <script>
   $(document).ready(function() {
     $('#myTable2').DataTable();
  var table = $("#myTable2").DataTable({
    dom: 'f', // Show only the search input
    paging: false, // Disable pagination
    lengthChange: false, // Disable entries select
  });
});

     
  </script>
