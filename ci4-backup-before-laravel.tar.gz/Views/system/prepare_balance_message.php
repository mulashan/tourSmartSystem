<?php
              helper('calc');
             $bmodel = new App\Models\BillingModel();
             $smodel = new App\Models\StudentModel();
             $report = new App\Models\ReportsModel();
              $amodel = new App\Models\AdmissionModel();
             $dbname=session()->get('db_name');
             $db = \Config\Database::connect($dbname);
           // $hname=$this->report->get_hostelname($hostel);
            $clname="";
           if(count($cl)==0){
               return; 
                    }
              if($classlevel==0){
                $clname="All Level,";
            }else{
                if(count($cl)>0)
              $clname=$cl[0]->level_name;  
            }
            if($class==0){
                $cname="All Classes";
            }else{
                if(count($cl)>0)
              $cname=$cl[0]->class_name;  
            }
            if($stream==0){
                $str="All Stream";
            }else{
                if(count($cl)>0)
              $str=$cl[0]->stream_name;  
            }
            //print_r($cl);return;
         $schoolname=$report->get_schoolname();
          $period = $bmodel->get_item_name('class_level_tbl', $where = array('id' => $cl[0]->level_id));
                 $dateterm = $report->checkTerm_date(date('Y-m-d'),$year,$period[0]->academic_type);
                  //print_r($dateterm);
                    if (is_countable($dateterm) && count($dateterm) > 0) {
                    $term_name=$dateterm[0]->term_name;
                   }else{
                    $dateterm = $report->checkTerm_date2(date('Y-m-d'),$year,$period[0]->academic_type);
                     
                     $term_name=$dateterm[0]->term_name;
                   }
                ?>
               
            <div id="tobeprinted">
                <?php
             if(session()->get('db_id')==4){ 
                 $messagex=" Mzazi wa #Student first Name, Kristo! Baki ya Muhula TZS XXX, Baki ya mwaka TZS XXX, Kamilisha malipo na Mungu akubariki.";
             }else{
                $messagex=" #student first name, Malipo ya awamu xxx TZS xxx. Lipa kabla ya tar xx/xx/xxxx. Baki ya mwaka TZS xxx. Kumb no xxx. Asante.";

             }
               ?>
              <div class="card">
               <div class="table-responsive mt-3">
                
                        <table class="table table-hover table-vcenter mb-0 text-nowrap table-bordered"   id="">
                           <thead>
                            <tr>
                                <th>#</th>
                                 <!-- <th>Adm No</th>
                                 <th>Adm Date</th> -->
                                 <td> <input type="checkbox" name="" value="" onclick="Allcheckbox()" id="Allselected"> All</td>
                                 <th>Names</th>
                               <!--   <th>Birth date</th>
                                 <th>Age</th>
                                 <th>Gender</th> -->
                                 <th>Class</th>
                                 <th>Stream</th>
                                 <th>Type</th>
                                 <th>Term</th>
                                 <th>Balance</th>
                                 <th>Phone</th>
                                 <th>Sent</th>
                                 <th>Sms Cost</th>
                                </tr>
                                <thead>
                                    <tbody>
                                <?php
                            $n=0;
                            $female=0;
                               $male=0;
                               $day=0;
                               $board=0;
                               $streamA=0;
                               $streamB=0;
                               $ne=0;
                               $c=0;
                                 $holid_student=array();
                            if(count($cl)>0){
                               
                                foreach($cl as $le){
                                    $n++;
                                  if($le->gender=='Female'){
                                    $female=$female+1;
                                  }
                                  if($le->gender=='Male'){
                                    $male=$male+1;
                                  }
    //////////////////////  ////////////////////////////////////////////////////////////////////////////////
                                  //$holid_student[]=array($le->id);
                                  $student_id=$le->id;
                            $tinvoice = $bmodel->get_total_invoice_amount($student_id,$year);
                                  
                                 if(count($tinvoice)==0){
                                 continue;
                                   }
                            $results=findCalc($student_id,$dbname,$year);
                                  $type=$le->admission_type;
                                  $hst=$le->admission_type;
                                  if($type==3){
                                    $tp='B';
                                    $board++;
                                  }else{
                                     $tp='D';
                                     $day++;
                                  }

                                  if($le->stream_name=='A'){
                                    $streamA=$streamA+1;
                                  }else{
                                     $streamB=$streamB+1;
                                  }
                                  if($le->adimit_for==2){
                                    $new="New Comer";
                                    $ne++;
                                  }else{
                                     $new="Continous";
                                     $c++;
                                  }
                                 
                 $tinvoice = $bmodel->get_total_invoice_amount($student_id,$year);
                 $ctrNum="---";
                 if(count($tinvoice)==0){
                    continue;
                 }
                  $ctr_num =$bmodel->get_item_name('payment_request',$where=array('student_id'=>$student_id,'trans_no'=>$tinvoice[0]->trans_no,'inv_type'=>0,'trans_type'=>1));
                 if(count($ctr_num)>0){
                    $ctrNum=$ctr_num[0]->reference_no;
                     
                 }
                 
                $total=$tinvoice[0]->amount;
               $dateterm = $report->checkTerm_date(date('Y-m-d'),$year,$period[0]->academic_type);
                  //print_r($dateterm);
                   if (is_countable($dateterm) && count($dateterm) > 0) {
                    $term_name=$dateterm[0]->term_name;
                   }else{
                    $dateterm = $report->checkTerm_date2(date('Y-m-d'),$year,$period[0]->academic_type);
                     
                     $term_name=$dateterm[0]->term_name;
                   }
                  
                   $installments =$bmodel->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$period[0]->academic_type));
                   
                     $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                      $ddate="";
                      $mbalance1=0;
                      $mbalance2=0;
                      $mbalance3=0;
                    foreach ($installments as $r) {
                        
                     $i++;
                 
                     if($i==1){
                    $duedate1=$r->due_date;
             
                   $openingbalance=$results[0]['openingbalance'];
                       $ment=$results[0]['ment'];
                       
                        $mbalance=$results[0]['mbalance'];
                        $mbalance1=$mbalance;
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment+$openingbalance;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[0]['today']==1){
                       $todaybalance=$results[0]['todaybalance']; 
                          }
                      if($term==$r->id){
                       $tm=$i;
                      
                      }
                  
                     }
                      if($i==2){
      
                           $duedate2=$r->due_date;
           
                         $ment=$results[1]['ment'];
                        
                        $mbalance=$results[1]['mbalance'];
                        $mbalance2=$mbalance;
                        $paid_amount=$results[1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[1]['today']==1){
                       $todaybalance=$results[1]['todaybalance']; 
                     }
                    if($term==$r->id){
                       $tm=$i;
                      
                      }
                     }
                   if($i==3){

                      $b=1;
                       if($mbalance<0){
                        $b=0;
                       }
         
                     $duedate3=$r->due_date;
         
                     $ment=$results[2]['ment'];
                       
                        $mbalance=$results[2]['mbalance'];
                         $mbalance3=$mbalance; 
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[2]['today']==1){
                       $todaybalance=$results[2]['todaybalance']; 
                     }
                      if($term==$r->id){
                       $tm=$i;
                      
                      }
                      $duedate3=$r->due_date;
                      $tname3=$r->term_name;
                     }
                     
                      if($i==4){

                      $b=1;
                       if($mbalance<0){
                        $b=0;
                       }
         
                     $duedate3=$r->due_date;
         
                     $ment=$results[3]['ment'];
                       
                        $mbalance=$results[3]['mbalance'];
                         $mbalance3=$mbalance; 
                        $paid_amount=$results[3]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[3]['today']==1){
                       $todaybalance=$results[3]['todaybalance']; 
                     }
                      if($term==$r->id){
                       $tm=$i;
                      
                      }
                      $duedate3=$r->due_date;
                      $tname3=$r->term_name;
                     }
                     // $tments=$tments+$ment;
                     // $tpaid= $tpaid+$paid_amount;
                     
                      } 

               $phone = $db->query('SELECT phone1 FROM parents_tbl,parents_students_tbl WHERE parents_tbl.id = parents_students_tbl.parent_id AND'
               . ' parents_tbl.bill_account = 1  AND parents_students_tbl.student_id ='.$student_id.'');
             $pn = $phone->getResult(); 
               if(count($pn)>0){
                $phone=$pn[0]->phone1;
               }else{
                 $phone="No Phone Number";
               }
    ///////////////////////
               $row="black";
       //  $std=$le->student_id; 
    $name = $amodel->get_student_details('students',$where = array('id' => $student_id));
                      if($tments - $tpaid >0){
                        $usumbufu="Kamilisha malipo kuondoa usumbufu";
                      }else{
                        $usumbufu="";
                      }
                      
                      if($todaybalance <0){
                        $todaybal=0;
                     }else{
                      $todaybal=$todaybalance;  
                     }

                      $termSelected =$bmodel->get_item_name('school_terms_tbl',$where=array('id'=>$term));

                      
                        if($tm==1){
                            $newBalance=$mbalance1;
                            if(session()->get('db_id')==4){ 
                              if($newBalance<0){
                                  $newBalance=0;
                              }
                      $message="Mzazi wa ".$name[0]->first_name.";  Kristo! Baki ya Muhula TZS ".number_format($newBalance)." Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kamilisha malipo na Mungu akubariki.";
                      }else{
                         if($mbalance1 >0){
                            $message="Mzazi wa ".$name[0]->first_name.", Malipo ya ada awamu ya kwanza TZS ".number_format($mbalance1).". Lipa kabla ya tarehe ".date('d/m/Y',strtotime($termSelected[0]->due_date)).". Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kumb no ".$ctrNum.". Hii ni ada tu. Asante.";
                        }elseif($mbalance1 <0){
                               $message="Mzazi wa ".$name[0]->first_name.", Hudaiwi malipo ya ada awamu ya kwanza. Unaziada ya  TZS ".number_format($mbalance1).". Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kumb no ".$ctrNum.". Hii ni ada tu. Asante.";
                        }elseif($mbalance1 ==0){
                               $message="Mzazi wa ".$name[0]->first_name.", Hudaiwi malipo ya ada awamu ya kwanza. Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kumb no ".$ctrNum.". Hii ni ada tu. Asante.";
                        }
                      }
                        }elseif ($tm==2) {
                          $newBalance=$mbalance2;
                             if(session()->get('db_id')==4){ 
                              if($newBalance<0){
                                  $newBalance=0;
                              }
                      $message="Mzazi wa ".$name[0]->first_name.";  Kristo! Baki ya Muhula TZS ".number_format($newBalance)." Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kamilisha malipo na Mungu akubariki.";
                      }else{
                          if($mbalance2 >0){
                            $message="Mzazi wa ".$name[0]->first_name.", Malipo ya ada awamu ya pili TZS ".number_format($mbalance2).". Lipa kabla ya tarehe ".date('d/m/Y',strtotime($termSelected[0]->due_date)).". Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kumb no ".$ctrNum.". Hii ni ada tu. Asante.";
                        }elseif($mbalance2 <0){
                               $message="Mzazi wa ".$name[0]->first_name.", Hudaiwi malipo ya ada awamu ya pili. Unaziada ya  TZS ".number_format($mbalance2).". Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kumb no ".$ctrNum.". Hii ni ada tu. Asante.";
                        }elseif($mbalance2 ==0){
                               $message="Mzazi wa ".$name[0]->first_name.", Hudaiwi malipo ya ada awamu ya pili. Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kumb no ".$ctrNum.". Hii ni ada tu. Asante.";
                        }
                      }
                          
                    }elseif ($tm==3) {
                             $newBalance=$todaybalance;
                             $mbalance3=$todaybalance;
                              if($mbalance3 >0){
                            $message="Mzazi wa ".$name[0]->first_name.", Malipo ya ada awamu ya tatu TZS ".number_format($mbalance3).". Lipa kabla ya tarehe ".date('d/m/Y',strtotime($termSelected[0]->due_date)).". Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kumb no ".$ctrNum.". Hii ni ada tu. Asante.";
                        }elseif($mbalance3 <0){
                               $message="Mzazi wa ".$name[0]->first_name.", Hudaiwi malipo ya ada awamu ya tatu. Unaziada ya  TZS ".number_format($mbalance3).". Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kumb no ".$ctrNum.". Hii ni ada tu. Asante.";
                        }elseif($mbalance3 ==0){
                               $message="Mzazi wa ".$name[0]->first_name.", Hudaiwi malipo ya ada awamu ya tatu. Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kumb no ".$ctrNum.". Hii ni ada tu. Asante.";
                        }
                        }elseif ($tm==4) {
                             $newBalance=$todaybalance;
                             $mbalance4=$todaybalance;
                              if($mbalance4 >0){
                            $message="Mzazi wa ".$name[0]->first_name.", Malipo ya ada awamu ya nne TZS ".number_format($mbalance4).". Lipa kabla ya tarehe ".date('d/m/Y',strtotime($termSelected[0]->due_date)).". Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kumb no ".$ctrNum.". Hii ni ada tu. Asante.";
                        }elseif($mbalance4 <0){
                               $message="Mzazi wa ".$name[0]->first_name.", Hudaiwi malipo ya ada awamu ya nne. Unaziada ya  TZS ".number_format($mbalance4).". Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kumb no ".$ctrNum.". Hii ni ada tu. Asante.";
                        }elseif($mbalance4 ==0){
                               $message="Mzazi wa ".$name[0]->first_name.", Hudaiwi malipo ya ada awamu ya nne. Baki ya mwaka TZS ".number_format($tments - $tpaid).". Kumb no ".$ctrNum.". Hii ni ada tu. Asante.";
                        }
                        }

                        
                          
                   
        ///////////////////////////////////////////////////////////////////////////////////
                         if(($tments -$tpaid) >0){
                             $holid_student[]=array($student_id);
                      $sent = $bmodel->get_item_name('messages', $where = array('message_type' => 3,'reference_no'=>$student_id,'phone_no'=>str_replace(' ', '', $phone)));       
                              ?> 

                            <input type="hidden" name="student[]" value="<?=$student_id;?>"> 
                            <input type="hidden" name="balance<?=$student_id;?>" value="<?=$todaybalance;?>"> 
                            <input type="hidden" name="phone<?=$student_id;?>" value="<?=$phone;?>"> 
                            <input type="hidden" name="message<?=$student_id;?>" value="<?=$message;?>"> 
                                    <tr style="color: <?php echo $row;?>;" onclick="selectRow('<?php echo $student_id; ?>')" id="<?php echo $student_id; ?>">
                                    <td><?php echo $n?></td>
                                     <td>  <input type="checkbox" name="selected[]" value="<?php echo $student_id; ?>" onclick="checkbox('<?php echo $student_id; ?>')" id="selected<?php echo $student_id; ?>"></td>
                                    <td><?=$le->full_name?></td>
                                   <td><?=$le->class_name?></td>
                                    <td><?=$le->stream_name?></td>
                                    <td><?=$tp?></td>
                                    <td><?=$termSelected[0]->term_name;?></td>
                                   <td class="text-right"><?=number_format($todaybalance)?></span></td>
                                   <td><?=$phone;?></td>
                                   <td class="text-red text-center"><?= count($sent);?></td>
                                   <td class="text-center">45</td>
                                    <!-- <td><center><a href=\"javascript:void()\" onclick=\"viewBalanceReport('" . $le->student_id . "','" . $le->id. "')\" title=\"View this class\"><span class=\"view\">View</span></a></center></td> -->
                                   
                                   </tr>
                                  
                                   <?php
                                  }else{
                                    $n--;
                                  } 
                                   
                                }
                                ?>
                           <tr> 
                            <td colspan="9"></td>
                            <td>Total</td> 
                            <td class="text-center"><?php echo number_format($n*45);?></td>
                           </tr>
                                <?php

                        }else{
                             echo '<tr>';
                                  
                                    echo '<td colspan="7"> Currently there is no any history.</td>';
                            echo '</tr>';   
                            }
      
          ?>
          </tbody>
           </table>
 
      </div>

  </div>
  </div>
  <div class="form-group mb-3">
                <div class="col-sm-12">
                    <button class="btn btn-primary float-right" onclick="message_group_function();" id="send_message">Send Messages</button>
                </div>
            </div>
<noscript>
    <style>
        .table-condensed{
            padding-bottom: 20px; 

        }
        table.table{
            border-collapse:collapse;
            border: 1px solid black;
            width:80%;
          
            margin-left: auto;
            margin-right: auto;
/*            page-break-inside: avoid;*/
           
        }
         table.table td{
         border:1px solid black;
           font-size: 12px;
         }
        #myTable td,#myTable th{
            border:1px solid black;
           font-size: 12px;
           }
        h6{
            text-align: center;
        }
        .btnp,.viewbtn{
           display: none;
        }
        #myTable_wrapper .dataTables_filter,
        #myTable_wrapper .dataTables_paginate,
        #myTable_wrapper .dataTables_length {
         display: none;
}
 @media print {
      .table {
        border-collapse: collapse !important;
        border: 1px solid black !important;
      }
      }
      table.toba td{
        font-size: 12px;
      }
        
    </style>
</noscript>
  <script>
   $(document).ready(function() {
    checkSelected();
     $('#myTable2').DataTable();
  var table = $("#myTable2").DataTable({
    dom: 'f', // Show only the search input
    paging: false, // Disable pagination
    lengthChange: false, // Disable entries select
  });
});

     function student_print(){
   
       window.onbeforeprint = function() {
    // Hide search box and entries option
    table.search('').draw();
    table.page.len(-1).draw();
  };
  
  
        var _c = $('#tobeprinted').html();
        var ns = $('noscript').clone();
        var nw = window.open('','_blank','width=800,height=600')
        nw.document.write(_c)
        nw.document.write('<html><head><title>MHI</title><link rel="stylesheet" href="<?php echo base_url() . 'syst_assets/'; ?>bootstrap/css/bootstrap.css">')
        nw.document.write(ns.html())
        //nw.document.close()
        nw.print()
  
     }

     function selectRow(id){
         var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {
    row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {

    row.style.backgroundColor = 'black';
      row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        }
        checkSelected();
      
      }
      function checkbox(id){
        var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {

    row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {
    row.style.backgroundColor = 'black';
      row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        } 
        checkSelected();
      }
function Allcheckbox(){
        var values=<?php echo json_encode($holid_student);?>;
        //alert(values.length);
        var rememberAll = document.getElementById("Allselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
            if(rememberAll.checked){
     remember.checked=true;  
      if (row) {
    
    row.style.backgroundColor = 'black';
    row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=false; 
      
       if (row) {
      row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }  
        }
        }
        checkSelected();
      }
   
      function checkSelected(){
        var j=0;
        var values=<?php echo json_encode($holid_student);?>;
        //alert(values.length);
        var rememberAll = document.getElementById("Allselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
            if(remember.checked){
           j++;
       }else{
     
        }
        }
       // alert(j);
        if(j>0){
            $('#send_message').prop("disabled", false);
        }else{
            $('#send_message').prop("disabled", true);
        }
      }
  </script>
 
