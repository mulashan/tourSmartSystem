<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WhatsApp Chat</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; }
        .chat-box { width: 400px; height: 500px; border: 1px solid #ddd; overflow-y: scroll; padding: 10px; }
        .message { margin: 5px 0; padding: 10px; border-radius: 5px; }
        .received { background: #f1f1f1; text-align: left; }
        .sent { background: #dcf8c6; text-align: right; }
    </style>
</head>
<body>

    <h2>WhatsApp Chat</h2>
    <div class="chat-box" id="chat-box"></div>

    <input type="text" id="recipient" placeholder="Recipient Number (e.g. 255712345678)">
    <input type="text" id="message" placeholder="Type a message...">
    <button onclick="sendMessage()">Send</button>

    <script>
        // Connect to WebSocket server
        const socket = new WebSocket('wss://econnect.advaensure.co.tz:8080'); // WebSocket URL

        socket.onopen = function() {
            console.log("WebSocket is connected");
        };

        socket.onmessage = function(event) {
            // Append incoming messages to the chat
            let chatBox = $("#chat-box");
            chatBox.append(`<div class="message received">${event.data}</div>`);
            chatBox.scrollTop(chatBox[0].scrollHeight);
        };

        // Send a message
        function sendMessage() {
            let recipient = $("#recipient").val();
            let message = $("#message").val();
            if (recipient === "" || message === "") return alert("Fill all fields!");

            // Send the message via WebSocket to server
            socket.send(JSON.stringify({ recipient, message }));
            
            // Append the message locally
            let chatBox = $("#chat-box");
            chatBox.append(`<div class="message sent">You: ${message}</div>`);
            chatBox.scrollTop(chatBox[0].scrollHeight);

            $("#message").val(""); // Clear message input
        }
    </script>

</body>
</html>
