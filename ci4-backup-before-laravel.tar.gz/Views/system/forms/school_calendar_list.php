<div class="card">
    <div class="table-responsive mt-3">
        <table class="table table-hover table-vcenter mb-0 text-nowrap" id="myTable">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Event Date</th>
                    <th>Description</th>
                    <th>Participants</th>
                    <th>Status</th>
                    <th>Created By</th>
                    <th>Created Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 0; ?>
                <?php foreach ($events as $event): ?>
                    <?php
                    $i++;
                    $participants = [];
                    if ((int) $event->parents === 1) {
                        $participants[] = 'Parents';
                    }
                    if ((int) $event->students === 1) {
                        $participants[] = 'Students';
                    }
                    if ((int) $event->staff === 1) {
                        $participants[] = 'Staff';
                    }
                    $status = (int) $event->status === 1
                        ? '<span style="color:green">Active</span>'
                        : '<span style="color:red">Inactive</span>';
                    ?>
                    <tr>
                        <td><?= $i; ?>.</td>
                        <td><?= date('d M Y', strtotime($event->event_date)); ?></td>
                        <td style="white-space: normal;"><?= esc($event->event_description); ?></td>
                        <td><?= esc(implode(', ', $participants)); ?></td>
                        <td><?= $status; ?></td>
                        <td><?= esc(trim(($event->first_name ?? '') . ' ' . ($event->last_name ?? ''))); ?></td>
                        <td><?= date('d M Y H:i', strtotime($event->created_date)); ?></td>
                        <td>
                            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                                <button type="button" class="btn btn-primary btn-sm EditEvent" data-id="<?= $event->id; ?>"><i class="fa fa-edit"></i> Edit</button>
                                <button type="button" class="btn btn-primary btn-sm ViewEvent" data-id="<?= $event->id; ?>"><i class="fa fa-eye"></i> View</button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
