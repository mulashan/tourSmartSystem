<?php
$mode = $mode ?? 'add';
$selectedLookup = [];
foreach (($selected_staff_ids ?? []) as $staffId) {
    $selectedLookup[(int) $staffId] = true;
}
?>
<div id="<?= esc($mode); ?>_school_calendar_staff_wrap">
    <?php if (! empty($staffs)): ?>
        <div class="alert alert-info py-2">
            Select the staff members who should receive the event SMS list.
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-sm">
                <thead>
                    <tr>
                        <th style="width: 50px;">
                            <input type="checkbox" id="<?= esc($mode); ?>_select_all_staff">
                        </th>
                        <th>Name</th>
                        <th>Phone</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($staffs as $staff): ?>
                        <tr>
                            <td>
                                <input
                                    type="checkbox"
                                    class="<?= esc($mode); ?>_staff_checkbox"
                                    name="selected_staff[]"
                                    value="<?= (int) $staff->user_id; ?>"
                                    <?= isset($selectedLookup[(int) $staff->user_id]) ? 'checked' : ''; ?>
                                >
                            </td>
                            <td><?= esc(trim($staff->first_name . ' ' . $staff->last_name)); ?></td>
                            <td><?= esc($staff->phone_no ?? ''); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-warning mb-0">
            <?= esc($empty_message ?? 'No staff found.'); ?>
        </div>
    <?php endif; ?>
</div>

<script type="text/javascript">
    $('#<?= esc($mode); ?>_select_all_staff').off('change').on('change', function () {
        $('.<?= esc($mode); ?>_staff_checkbox').prop('checked', $(this).is(':checked'));
    });
</script>
