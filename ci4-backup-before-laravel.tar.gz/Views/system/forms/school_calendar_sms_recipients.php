<?php
$mode = $mode ?? 'add';
$selectedLookup = [];
foreach (($selected_student_ids ?? []) as $studentId) {
    $selectedLookup[(int) $studentId] = true;
}
?>
<div id="<?= esc($mode); ?>_school_calendar_recipients_wrap">
    <?php if (! empty($students)): ?>
        <div class="alert alert-info py-2">
            Select the students who should receive the event SMS list.
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-sm">
                <thead>
                    <tr>
                        <th style="width: 50px;">
                            <input type="checkbox" id="<?= esc($mode); ?>_select_all_students">
                        </th>
                        <th>Name</th>
                        <th>Admission No</th>
                        <th>Class</th>
                        <th>Stream</th>
                        <th>Parent Phone</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $student): ?>
                        <tr>
                            <td>
                                <input
                                    type="checkbox"
                                    class="<?= esc($mode); ?>_student_checkbox"
                                    name="selected_students[]"
                                    value="<?= (int) $student->id; ?>"
                                    <?= isset($selectedLookup[(int) $student->id]) ? 'checked' : ''; ?>
                                >
                            </td>
                            <td><?= esc($student->full_name); ?></td>
                            <td><?= esc($student->admission_number); ?></td>
                            <td><?= esc($student->class_name); ?></td>
                            <td><?= esc($student->stream_name); ?></td>
                            <td><?= esc($student->parent_phone ?? ''); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-warning mb-0">
            <?= esc($empty_message ?? 'No students found.'); ?>
        </div>
    <?php endif; ?>
</div>

<script type="text/javascript">
    $('#<?= esc($mode); ?>_select_all_students').off('change').on('change', function () {
        $('.<?= esc($mode); ?>_student_checkbox').prop('checked', $(this).is(':checked'));
    });
</script>
