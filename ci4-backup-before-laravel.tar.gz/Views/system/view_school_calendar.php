<?php
$eventItem = $event[0];
$participants = [];
if ((int) $eventItem->parents === 1) {
    $participants[] = 'Parents';
}
if ((int) $eventItem->students === 1) {
    $participants[] = 'Students';
}
if ((int) $eventItem->staff === 1) {
    $participants[] = 'Staff';
}
$sendType = (int) ($eventItem->send_type ?? 0) === 2 ? 'Group' : ((int) ($eventItem->send_type ?? 0) === 1 ? 'Individual' : 'N/A');
$hasStudentAudience = ! empty($sms_student_audience);
$hasStaffAudience = ! empty($sms_staff_audience);
$hasAnySmsMessage = trim((string) ($eventItem->sms_message ?? '')) !== '' || trim((string) ($eventItem->staff_sms_message ?? '')) !== '';
$smsRecipients = [];
if ($hasStudentAudience) {
    $smsRecipients[] = 'Students / Parents';
}
if ($hasStaffAudience) {
    $smsRecipients[] = 'Staff';
}
?>

<div class="row">
    <div class="col-md-4"><strong>Event Date</strong></div>
    <div class="col-md-8"><?= date('d M Y', strtotime($eventItem->event_date)); ?></div>
</div>
<hr>
<div class="row">
    <div class="col-md-4"><strong>Event Description</strong></div>
    <div class="col-md-8" style="white-space: normal;"><?= esc($eventItem->event_description); ?></div>
</div>
<hr>
<div class="row">
    <div class="col-md-4"><strong>Participants</strong></div>
    <div class="col-md-8"><?= esc(implode(', ', $participants)); ?></div>
</div>
<hr>
<div class="row">
    <div class="col-md-4"><strong>Status</strong></div>
    <div class="col-md-8"><?= (int) $eventItem->status === 1 ? 'Active' : 'Inactive'; ?></div>
</div>
<hr>
<div class="row">
    <div class="col-md-4"><strong>SMS Notification</strong></div>
    <div class="col-md-8"><?= (int) ($eventItem->sms_enabled ?? 0) === 1 ? 'Enabled' : 'Disabled'; ?></div>
</div>
<?php if ((int) ($eventItem->sms_enabled ?? 0) === 1): ?>
<hr>
<div class="row">
    <div class="col-md-4"><strong>SMS Recipients</strong></div>
    <div class="col-md-8"><?= ! empty($smsRecipients) ? esc(implode(', ', $smsRecipients)) : 'None selected'; ?></div>
</div>
<hr>
<div class="row">
    <div class="col-md-4"><strong>SMS Schedule</strong></div>
    <div class="col-md-8">
        <?php if (! empty($sms_schedules)): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-sm mb-0">
                    <thead>
                        <tr>
                            <th>DATE & TIME</th>
                            <th>STATUS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sms_schedules as $schedule): ?>
                            <tr>
                                <td><?= date('d M Y H:i', strtotime($schedule['scheduled_at'])); ?></td>
                                <td>
                                    <?php if (! empty($schedule['sent_at'])): ?>
                                        Sent at <?= date('d M Y H:i', strtotime($schedule['sent_at'])); ?>
                                    <?php else: ?>
                                        Pending
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            No SMS schedule added
        <?php endif; ?>
    </div>
</div>
<hr>
<?php if ($hasStudentAudience): ?>
    <div class="row">
        <div class="col-md-4"><strong>Student/Parent Send Type</strong></div>
        <div class="col-md-8"><?= esc($sendType); ?></div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-4"><strong>Student/Parent SMS Message</strong></div>
        <div class="col-md-8" style="white-space: normal;"><?= esc($eventItem->sms_message ?? ''); ?></div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-4"><strong>Selected Student Recipients</strong></div>
        <div class="col-md-8">
            <?php if (! empty($selected_students)): ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-sm mb-0">
                        <thead>
                            <tr>
                                <th style="width: 40px;"><input type="checkbox" checked disabled></th>
                                <th>NAME</th>
                                <th>ADMISSION NO</th>
                                <th>CLASS</th>
                                <th>STREAM</th>
                                <th>PARENT PHONE</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($selected_students as $student): ?>
                                <tr>
                                    <td><input type="checkbox" checked disabled></td>
                                    <td><?= esc($student->full_name); ?></td>
                                    <td><?= esc($student->admission_number); ?></td>
                                    <td><?= esc($student->class_name); ?></td>
                                    <td><?= esc($student->stream_name); ?></td>
                                    <td><?= esc($student->parent_phone ?? ''); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                No students selected
            <?php endif; ?>
        </div>
    </div>
    <hr>
<?php endif; ?>
<?php if ($hasStaffAudience): ?>
    <div class="row">
        <div class="col-md-4"><strong>Staff SMS Message</strong></div>
        <div class="col-md-8" style="white-space: normal;"><?= esc($eventItem->staff_sms_message ?? ''); ?></div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-4"><strong>Selected Staff Recipients</strong></div>
        <div class="col-md-8">
            <?php if (! empty($selected_staffs)): ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-sm mb-0">
                        <thead>
                            <tr>
                                <th style="width: 40px;"><input type="checkbox" checked disabled></th>
                                <th>NAME</th>
                                <th>PHONE</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($selected_staffs as $staff): ?>
                                <tr>
                                    <td><input type="checkbox" checked disabled></td>
                                    <td><?= esc(trim($staff->first_name . ' ' . $staff->last_name)); ?></td>
                                    <td><?= esc($staff->phone_no ?? ''); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                No staff selected
            <?php endif; ?>
        </div>
    </div>
    <hr>
<?php endif; ?>
<?php if ($hasAnySmsMessage): ?>
    <div class="row">
        <div class="col-md-4"><strong>Send Now</strong></div>
        <div class="col-md-8">
            <button type="button" class="btn btn-primary btn-sm" id="sendSchoolCalendarNowBtn" onclick="sendSchoolCalendarNow('<?= (int) $eventItem->id; ?>')">
                <i class="fa fa-paper-plane"></i> Send Now
            </button>
            <div id="sendSchoolCalendarNowFeedback" class="mt-2"></div>
        </div>
    </div>
    <hr>
<?php endif; ?>
<?php endif; ?>
<hr>
<div class="row">
    <div class="col-md-4"><strong>Created Date</strong></div>
    <div class="col-md-8"><?= date('d M Y H:i', strtotime($eventItem->created_date)); ?></div>
</div>

<?php if ((int) ($eventItem->sms_enabled ?? 0) === 1 && $hasAnySmsMessage): ?>
<script type="text/javascript">
    function sendSchoolCalendarNow(id) {
        $('#sendSchoolCalendarNowBtn').prop('disabled', true);
        $('#sendSchoolCalendarNowFeedback').html('<span class="fa fa-spinner fa-spin"></span> Sending SMS...');

        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/send_school_calendar_now'; ?>',
            data: {id: id},
            dataType: 'text',
            timeout: 60000,
            success: function (res) {
                var data;

                try {
                    data = JSON.parse(res);
                } catch (e) {
                    $('#sendSchoolCalendarNowFeedback').html('<div class="alert alert-warning py-2 mb-0">SMS was processed, but the page did not get a clean response. Refresh the page to confirm status.</div>');
                    return;
                }

                if (data.status === "0") {
                    $('#sendSchoolCalendarNowFeedback').html('<div class="alert alert-success py-2 mb-0">' + data.statusDesc + '</div>');
                    if (typeof loadSchoolCalendarResults === 'function') {
                        loadSchoolCalendarResults();
                    }
                } else {
                    $('#sendSchoolCalendarNowFeedback').html('<div class="alert alert-warning py-2 mb-0">' + data.statusDesc + '</div>');
                }
            },
            error: function () {
                $('#sendSchoolCalendarNowFeedback').html('<div class="alert alert-danger py-2 mb-0">Sorry! Failed to send school calendar SMS.</div>');
            },
            complete: function () {
                $('#sendSchoolCalendarNowBtn').prop('disabled', false);
            }
        });
    }
</script>
<?php endif; ?>
