<?php 
    $stym = new App\Models\SystemModel();
    $bmodel = new App\Models\BillingModel();

    $acc = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 9));

    $deposit = $stym->messages_deposit_details('messages_deposits');

?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">Messages Recharge</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">
                        <?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?>
                    </a></li>
                    <li class="breadcrumb-item active" aria-current="page">Recharge</li>
                </ol>
            </div>
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#sms-all">Recharged List</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#add-new">New Recharge</a></li>
            </ul>
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="sms-all">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                    <th>Recharge No:</th>
                                    <th>Recharge Amount</th>
                                    <th>Recharged By</th>
                                    <th>Recharged Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $user = ""; 
                                    foreach ($deposit as $d):
                                        $uid = $stym->get_messages_details('users', $where = array('user_id' => $d->created_by));
                                ?>
                                    <tr>
                                        <td><?= $d->d_id; ?></td>
                                        <td><?= number_format($d->deposit_amount); ?></td>
                                        <td><?= $uid[0]->first_name; ?></td>
                                        <td><?= $d->created_at; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>     
            </div>
            <div class="tab-pane" id="add-new">
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header" style="height:5px">
                                    <h3 class="card-title">Make New Recharge</h3>
                                <div class="card-options">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                            <hr>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div id="sms"></div>
                                        <form class="form-horizontal" id="NewDeposit">
                                            <div class="form-group row">
                                           <!--      <label class="col-md-3 col-form-label">Ledger:</label>
                                                <div class="col-md-7">                                                    
                                                     <select class="form-control" name="ledger" id="ledger" required="">
                                                         <option value="">Select ledger</option>
                                                        <?php foreach($acc as $ac):?>
                                                             <option value="<?= $ac->id; ?>"><?= $ac->account_name; ?></option>
                                                         <?php endforeach; ?>
                                                     </select>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-3 col-form-label">Payee Name:</label>
                                                <div class="col-md-7">
                                                    <input type="text" name="payee" id="payee" class="form-control form-control-md" placeholder="Enter Payee Name">
                                                </div>
                                            </div> -->
                                            <div class="form-group row">
                                                <label class="col-md-3 col-form-label">Amount:</label>
                                                <div class="col-md-7">
                                                    <input type="number" name="deposit" id="deposit" class="form-control form-control-md" placeholder="Enter Amount eg:Tsh:30000" min="1">
                                                </div>
                                            </div>
                                            <!-- <div class="form-group row">
                                                <label class="col-md-3 col-form-label">Current Assets:</label>
                                                <div class="col-md-7">  
                                                <?php 
                                                    $asst = $bmodel->get_item_name('accounts_tbl',$where = array('account_type_id' => 2));
                                                ?>                                                  
                                                     <select class="form-control" name="ledger" id="ledger" required="">
                                                         <option value="">Select ledger</option>
                                                        <?php foreach($asst as $a):?>
                                                             <option value="<?= $a->id; ?>"><?= $a->account_name; ?></option>
                                                         <?php endforeach; ?>
                                                     </select>
                                                </div>
                                            </div> -->
                                            <div class="form-group row">
                                                <label class="col-md-3 col-form-label"></label>
                                                <div class="col-md-7">
                                                    <button type="submit" class="btn btn-primary float-right">Save</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
    $('#NewDeposit').submit(function(e) {
        e.preventDefault();

        var data = {depost: $('#deposit').val()};

        $.ajax({
            type: 'POST',
            data: data,
            url: 'new_deposit',
            success:function(res){
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                    
                    $('#NewDeposit')[0].reset();
                    $('#sms').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }
            },
            error:function(res){
                $('#sms').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Save Deposit.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>')
            }
        });
    })
</script>