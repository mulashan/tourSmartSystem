<style>
    .custom-switch {
      position: relative;
      width: 60px;
      height: 30px;
      background: #ccc;
      border-radius: 30px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .custom-switch-indicator1 {
      position: absolute;
      top: 3px;
      left: 3px;
      width: 24px;
      height: 24px;
      background: white;
      border-radius: 50%;
      transition: transform 0.3s;
    }

    /* When active */
    .custom-switch.active {
      background: #4caf50;
    }

    .custom-switch.active .custom-switch-indicator1 {
      transform: translateX(30px);
    }
  </style>
  <?php
$bmodel = new App\Models\BillingModel();                    
 $stym = new App\Models\SystemModel();
  ?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">System Messages</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php 
                $login = new App\Models\LoginModel();
                if(session()->get('logged_in')==true){
                $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                       echo $shule[0]->instituition;
                       }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Messages</li>
                </ol>
            </div>
            <!-- <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#sms-all">Messages List</a></li>
                    <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#sms-new">New Messages</a></li>
            </ul> -->
              <!---tabs here they go---------------------------->
            <div id="largeScreenTab">
          <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#sms-all">Messages List</a></li>
                    <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#sms-new">New Messages</a></li>
            </ul>
             </div>
            <div id="smallScreenTab">
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#sms-all">Messages List</a></li>
                <li></li><li></li>
                    <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#sms-new">New Messages</a></li>
            </ul>
              
             </div>
    <!---tabs here they end---------------------------->
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="sms-all">
                <div class="row">
                    <div class="col-md-3"></div>
                <div class="d-flex justify-content-center col-md-6">
                    <form class="form-inline">
                        <div class="input-group me-3">
                            <button type="button" class="btn btn-default pull-right" id="daterange-btn">
                                <span>
                                    <i class="fa fa-calendar"></i> Please Select Date
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>

                        <button type="submit" class="btn btn-primary" id="messages">Load</button>
                    </form>
                </div>
                <?php
            $mstatus= $bmodel->get_table_details('message_status_tbl');
            //echo $mstatus[0]->status;
                ?>
                <div class="col-md-2 pull-right"></div>
                <div class="col-md-1 pull-right" >Status
                 <label class="custom-switch pull-right" id="switchBtn">
                <span class="custom-switch-indicator1"> <p id="status">OFF</p></span></label>
                    </div>
                    </div>
                <hr>
                <div class="msgBlnc">
                    <?php 
                       
                
                        $blnc = $stym->messages_deposit_details('messages_balances');
                        $balance_ttl = 0;
                        if(count($blnc) > 0){
                            if($blnc[0]->balance == ""){
                                $balance_ttl = 0;
                            }else{
                                $balance_ttl = $blnc[0]->balance;
                            }
                        }
                        
                        $usedBlnc = $stym->get_total_balance();
                    ?>

                    <div class="d-flex justify-content-between">
                        <div><h6><b>Currently Balance: </b><span>Tsh.<?= number_format($balance_ttl); ?></span></h6></div>
                        <div><h6><b>Used: </b><span id='sms-sent-cost'>Tsh.<?= number_format($usedBlnc[0]->cost); ?></span></h6></div>
                    </div>
                    
                </div>
                <div class="card">
                    <div class="card-body">
                        <table class="table  table-vcenter mb-0 text-nowrap" id="myTable">
                            <thead>
                                <tr>
                                    <th>SN</th>
                                    <th>Message Date</th>
                                    <th>Message Type</th>
                                    <th>Sender type:</th>
                                    <th>Pax</th>
                                    <th>Message</th>
                                    <th>Cost</th>
                                    <th>Initiated By</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="messageData">
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <div class="tab-pane" id="sms-new">
     <!-------------------------------new messages------------------------------------>
                             <div class="card-body">
                                <form class="form-horizontal" id="invoicebtn">
                                    <div id="feedback"></div>
                                   <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="acdyr" class="col-sm-4 col-form-label">Academic year</label>
                                             <div class="col-sm-8">
                                             <select class="form-control form-select" name="year" id="year">
                                                <?php 
                                                $start=2023;
                                                $cyear=date('Y');
                                                for($y=$start;$y<=$cyear+1;$y++){
                                                ?>
                  <option value="<?=$y ?>" <?php if($y==$cyear){ echo 'selected';}?> ><?=$y ?></option>
                                                 
                                             <?php } ?>
                                                </select>
                                             </div>
                                             </div>
                                
                                        <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Msg Date</label>
                                            <div class="col-sm-8">
                                              <input type="date" id="invoice_date" name="invoice_date" value="<?php echo date('Y-m-d');?>" max="<?php echo date('Y-m-d');?>" class="form-control">
                                            </div>
                                          </div>

                                         <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Msg Type</label>
                                            <div class="col-sm-8">
                                              <?php
                                                 $cty= $bmodel->get_table_details('message_types_tbl');
                                                  ?>
                                                <select class="form-control" name="msg_type" id="msg_type">
                                                    <option value="">-Choose-</option>
                                                    <?php foreach($cty as $type): ?>
                                                    <option value="<?= $type->id ?>"><?= $type->type; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                               
                                            </div>
                                          </div>
                                        <div class="form-group row">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Send Type<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                               <select class="form-control" onchange="changeSendType(this)" name="send_type" id="send_type">
                                                    <option value="">Select Type</option>
                                                    <option value="1">Individual</option>
                                                    <option value="2">Group</option>
                                                   
                                                </select>
                                                 <div id="fstrm" style="color:red"></div>
                                            </div>
                                          </div>
                                         <input type="hidden" name="student_id" id="student_id" value="">
                                          
                                         
                                         <div class="form-group row" id="payer_name_row" style="display: none;">
                                            <label for="inputpaidBy" class="col-sm-4 col-form-label">Name Type<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                               <?php
                                                    $ctype= $bmodel->get_table_details('name_type_tbl');
                                                  ?>
                                                <select class="form-control" name="customer_type" id="customer_type">
                                                    <option value="">Select Customer Type</option>
                                                    <?php foreach($ctype as $type): ?>
                                                    <option value="<?= $type->id ?>"><?= $type->name_type; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                          </div>
                                          <div class="form-group row" id="select_invoice" style="display:none;">
                                            <label for="payerame" class="col-sm-4 col-form-label">Search Name<span class="text-danger">*</span></label>
                                            <div class="col-sm-8">
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" name="customer_name or Id"  id="customer_name" placeholder="Search Customer Name" aria-label="Customer Name" aria-describedby="button-addon2">
                                                    <button class="btn btn-outline-primary" type="button" id="button-addon2" onclick="search_customer()"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                          </div>
                                           <div id="payer_details"></div>
                                           <div id="message_details"></div>
                <?php
            
                 $messagex="Happy Birthday# Student first Name. Wishing you a very happy birthday filled with many achievements and success!

";
            if(session()->get('db_id')==4){ 
                 $message=" Mzazi wa #Student first Name, Kristo! Baki ya Muhula TZS XXX, Baki ya mwaka TZS XXX, Kamilisha malipo na Mungu akubariki.";
             }else{
                $message=" #student first name, Malipo ya awamu xxx TZS xxx. Lipa kabla ya tar xx/xx/xxxx. Baki ya mwaka TZS xxx. Kumb no xxx. Ahasante.";
             }
                
               ?>
               <!---birthday message------------------------>
                 <div class="form-group row" style="display:none;" id="birthday">
                <label for="staticEmail" class="col-sm-4 col-form-label">Message</label>
                <div class="col-sm-8 mb-3">
                     <textarea cols='15' rows='3' class="form-control form-control-plaintext" name="msgbtdy"><?= $messagex; ?></textarea>
                  
                </div></div>
                <!-----balance message------------------>
                <div class="form-group row" style="display:none;" id="blc">
                <label for="staticEmail" class="col-sm-4 col-form-label">Message</label>
                <div class="col-sm-8 mb-3">
                     <textarea cols='15' rows='3' class="form-control form-control-plaintext" name="msgblc"><?= $message; ?></textarea>
                  
                </div></div>
                <!---end balance msg-------------------->

                                          </div>
                                     <div class="col-md-6">
                                       <div id="customer_loaded"></div> 
                                       <div id="Name_loaded"></div>
                                       <div id="Invoice_loaded"></div>
                
                     
                                    </div>
                                    <div id="group_details"></div>
                                          </div>

                                  </form>
                                          </div>
     <!------------------------------------------------------------------>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="viewDetails" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="view_content">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
    resetReceiptData();
    function resetReceiptData(){
        $('#payer_details').empty();
        $('#msg_type').val('');
        $('#send_type').val('');
        $('#customer_type').val('');
         $('#customer_name').val('');
        $('#select_invoice').hide();
        $('#customer_loaded').empty();
        $('#Name_loaded').empty();
        $('#Invoice_loaded').empty();
        $('#itm_invoice1').empty();
        $('#itm_invoice').empty();
        $('#amount_due').val(0);
   }
     $("#msg_type").change(function(){
           $('#birthday').hide('');  
            $('#blc').hide('');
         $('#payer_name_row').hide();
           $('#select_invoice').hide();
           $('#payer_details').html('');
           $('#message_details').html('');
           $('#customer_loaded').html('');
            $('#group_details').html('');
             $('#send_type').val('');
        selectElement.style.borderColor = 'red';
         });
    const selectElement = document.getElementById('send_type');
     $("#year").change(function(){
         $('#group_details').html('');
           $('#payer_name_row').hide();
               $('#send_type').val('');
            document.getElementById("fstrm").innerHTML = "";
            selectElement.style.borderColor = 'red';
     });
    function changeSendType(id){
         $('#birthday').hide('');  
            $('#blc').hide('');
       // alert('/'+id.value);
       var msg=$('#msg_type').val();
        if(id.value=='' || msg==''){
             $('#group_details').html('');
           $('#payer_name_row').hide();
            document.getElementById("fstrm").innerHTML = "Choose Send Type"; 
         selectElement.style.borderColor = 'red';
        }else if(id.value==1){
              selectElement.style.borderColor = '';
            if(msg==4){
          load_bithday();
            }else{
            document.getElementById("fstrm").innerHTML = ""; 
              $('#group_details').html('');
           $('#payer_name_row').show();
       }
        }else if(id.value==2){
            selectElement.style.borderColor = '';
           var data='msgtpy='+msg +'&date='+$('#invoice_date').val();

            document.getElementById("fstrm").innerHTML = ""; 
           $('#payer_name_row').hide();
           $('#select_invoice').hide();
           $('#payer_details').html('');
           $('#message_details').html('');
           $('#customer_loaded').html('');
           
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/message_group'; ?>',
                beforeSend: function () {
                    $('#group_details').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
               data:data,
                success: function (result) {
                  $('#group_details').html(result); 
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');
               }
            });
        }
    }
    $("#customer_type").change(function(){
        $('#select_invoice').show();
        
    });
     function search_customer(){
       if($('#customer_type').val() == "") {
           swal("warning","Please Select Name Type","warning");
       }else{
            var paydata = 'paid_by=' + $('#customer_type').val() + "&payer_name=" + $('#customer_name').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/search_payer'; ?>',
                beforeSend: function () {
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#customer_loaded').html(result); 
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');
               }
            });
           }
       
    }

    function select_payer(id,nametype,payer_name){
        $('#student_id').val(id);
       if($('#customer_type').val() == "") {
           swal("warning","Please Select Name Type","warning");
       }else{
            var paydata = 'payer=' + id + "&nametype=" + nametype;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/get_student_details'; ?>',
                beforeSend: function () {
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#payer_details').html(result);
                    $('#payer_name_row').hide(); 
                   $('#customer_loaded').html('');
                   search_message(id,nametype);
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');
               }
            });
           }
       
    }
function search_message(id,nametype){
    var msg=$('#msg_type').val(); 
   // alert(msg);
    //$('#customer_loaded').html(id+' Message will load here '+msg);
     if(msg == "") {
           swal("warning","Please Select Message Type","warning");
       }else if(msg==3){
        var paydata = 'id=' + id + "&nametype=" + nametype+"&year="+$('#year option:selected').val();
      //  alert(paydata);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/get_student_balance_message'; ?>',
                beforeSend: function () {
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#message_details').html(result);
                  $('#customer_loaded').html('');
                  },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');
               }
            });
       }else{
             var paydata = 'id=' + id + "&nametype=" + nametype + "&mtype=" + msg;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/get_student_message'; ?>',
                beforeSend: function () {
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#message_details').html(result);
                  $('#customer_loaded').html('');
                  },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');
               }
            });
       }

}
    function select_payerwer(id,nametype,payer_name){
  
       var payer = nametype +'_' +id;
       // $('#payer_id').val(payer);
        var payerdata = "payer=" + payer;
          //  alert(payerdata);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/index.php/BillingController/get_payer_details'; ?>',
            data: payerdata,
           success: function (res) {
                alert('results');
                $('#payer_details').html(res);
                $('#payer_name_row').hide();
                $('#customer_loaded').html('');
            },
            error: function (){
                alert('error encounted');
            }
        });
    }
   $(function () {
        var start = moment();
        var end = moment();
        function cb(start, end) {
            $('#daterange-btn span').html(start.format('YYYY/M/D') + ' - ' + end.format('YYYY/M/D'));
        }
        $('#daterange-btn').daterangepicker({
            startDate: start,
            endDate: end,
            ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }, cb);
        cb(start, end);

    });

   $('#messages').click(function(e){
        e.preventDefault();

        var data = 'mdate=' + $('#daterange-btn span').html();
        var totalSentCost = 0;

        $.ajax({
            type: 'POST',
            data: data,
            url: 'load_messages',
            beforeSend: function () {
                    $('#messageData').html('<center><b><span class="fa fa-spin fa-spinner"></span> Loading Message...</b></center>');
                },
            dataType: 'JSON',
            success:function(res){
                console.log(res);
                if(res == ""){
                    
                    $("#messageData").empty();
                    var mesg = "No Data Available Found";
                    var tr = "<tr>" +
                    "<td colspan='12' align='center'>" + mesg + "</td>" +
                    "</tr>";
                    $("#messageData").append(tr);
                }else{
                    var len = res.length;
                    $("#messageData").empty();

                    for(var i = 0; i < len; i++){
                        var msgdate = res[i].massage_date;
                        var msg = res[i].message;
                        var sendertype = res[i].sender_type;
                        var type = res[i].type;
                        var pax = res[i].pax;
                        var cost = res[i].cost;
                        var user = res[i].user;
                        var send_number = res[i].send_number;
                       
                      totalSentCost = +totalSentCost + +cost;

                        var msg_tr = "<tr>" +
                        "<td>" + (i+1) + "</td>" +
                        "<td>" + msgdate + "</td>" +
                        "<td>" + type + "</td>" +
                        "<td>" + sendertype + "</td>" +
                        "<td>" + pax + "</td>" +
                        "<td> <textarea cols='20' rows='4' readonly style='border:none;outline:none;resize:none;'>" + msg + "</textarea></td>" +
                        "<td>" + cost + "</td>" +
                        "<td>" + user + "</td>" +
                        "<td><a href='javascript:viewmsg(\""+send_number+"\");' class='btn btn-primary btn'>view</a></td>" +
                        "</tr>";

                        $("#messageData").append(msg_tr);
                    }
                    $("#sms-sent-cost").html(totalSentCost);
                }
            },
            error: function () {
   $('#messageData').html('<center><b><span class="badge badge-danger"><i class="fa fa-warning"></i> Error encounted</b></center>');

               }
        });
   });
   function message_function(){
     event.preventDefault();
    var allvariables = $("#invoicebtn").serialize()+'&date='+$('#invoice_date').val()+'&'+$("#header_form").serialize();
  //alert(allvariables);
    $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/message_balance'; ?>',
                beforeSend: function () {
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Sending Message...</b></center>');
                },
                data: allvariables,
                success: function (result) {
                      $('#customer_loaded').html(''); 
                    if(result){
                    swal('success','Message sent successfully','success');    
                    }else{
                      swal('error','Message not sent successfully','error');   
                    }
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');
               }
            });
   }

   function message_group_function(){
     event.preventDefault();
     var allvariables = $("#invoicebtn").serialize()+'&date='+$('#invoice_date').val()+'&'+$("#header_form").serialize();
     $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/message_balance_groupwise'; ?>',
                beforeSend: function () {
                    $('#send_message').prop("disabled", true);
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Sending Message...</b></center>');
                },
                data: allvariables,
                success: function (result) {
                  $('#customer_loaded').html(''); 
                    if(result){
                    swal('success','Messages sent successfully','success');    
                    }else{
                      swal('error','Messages not sent successfully','error');   
                    }
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');
               }
            });

   }
   function load_bithday(){
     $('#group_details').html('');
     event.preventDefault();
     var allvar ='date='+$('#invoice_date').val();
     $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/student_birthday'; ?>',
                data: allvar,
                beforeSend: function () {
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Loading...</b></center>');
                },
              
                success: function (result) {
                  $('#customer_loaded').html(result); 
                },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');
               }
            });
   }

   function select_msg_student(sid){
    $('#student_id').val(sid);
      var paydata = 'sid=' + sid;
            $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/BillingController/get_student_message'; ?>',
                beforeSend: function () {
                    $('#customer_loaded').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: paydata,
                success: function (result) {
                  $('#message_details').html(result);
                  $('#customer_loaded').html('');
                  },
                error: function () {
                    $('#customer_loaded').html('<p class="text-red">Sorry Something went wrong</p>');
               }
            });
   }
   function viewmsg(send_number){
     $('#view_content').html('');
    $('#viewDetails').modal('show'); 
     // $('#view_content').load('index.php/SystemController/view_messages/'+id);
         $.ajax({
                type: "POST",
                url: 'view-messages',
                beforeSend: function () {
                    $('#view_content').html('<center><b><span class="fa fa-spin fa-spinner"></span> Checking...</b></center>');
                },
                data: {send_number:send_number},
                success: function (result) {
                  $('#view_content').html(result);

                  },
                error: function () {
                    $('#view_content').html('  <div class="text-center alert alert-warning"><strong>Error encounted! </strong> Failed to fetch message data .</div>');
               }
            });
   }

</script>
<script>
    const switchBtn = document.getElementById("switchBtn");
    const statusText = document.getElementById("status");
    var status="<?php echo $mstatus[0]->status;?>";
    changeStatus(status);

    switchBtn.addEventListener("click", () => {
        
      status = switchBtn.classList.contains("active") ? 0 : 1;
      //alert(status);
      updateSmsStatus(status);
      // switchBtn.classList.toggle("active");
      // statusText.textContent = 
      //   switchBtn.classList.contains("active") ? "ON" : "OFF";
    });

    function changeStatus(status){
    //alert(status);
  if (status == 1) {
    switchBtn.classList.add("active");
    statusText.textContent = "ON";
  } else {
    switchBtn.classList.remove("active");
    statusText.textContent = "OFF";
  }

    }
    function updateSmsStatus(status){

          if(status==1){
            var mtext="enable";
          }else{
            var mtext="disable";
          }

         swal({
            title: "Are you sure?",
            text: "You want to "+mtext+" messages",
            // type: "warning",
            customClass: 'swal-wide',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, "+mtext+"!",
            cancelButtonText: "No, cancel!",
            closeOnConfirm: false,
            closeOnCancel: false,
            height:'200px'
          },

          function(isConfirm) {
            if (isConfirm) {
         $.ajax({
                type: "POST",
                url: '<?php echo base_url() . '/index.php/SystemController/change_sms_status/'; ?>'+status,
                 success: function (result) {
                  changeStatus(result);
                  swal("Messages "+mtext+"d");
                  },
                error: function () {
                    swal("error","Sorry Something went wrong!","error")
                    
               }
            });
        } else {
               swal("Cancelled");
            }

          });
    }
  </script>
