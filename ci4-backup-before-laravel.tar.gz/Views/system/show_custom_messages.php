<?php
              helper('calc');
             $bmodel = new App\Models\BillingModel();
             $smodel = new App\Models\StudentModel();
             $report = new App\Models\ReportsModel();
              $amodel = new App\Models\AdmissionModel();
             $dbname=session()->get('db_name');
             $db = \Config\Database::connect($dbname);
           // $hname=$this->report->get_hostelname($hostel);
            $clname="";
              if($classlevel==0){
                $clname="All Level,";
            }else{
                if(count($cl)>0)
              $clname=$cl[0]->level_name;  
            }
            if($class==0){
                $cname="All Classes";
            }else{
                if(count($cl)>0)
              $cname=$cl[0]->class_name;  
            }
            if($stream==0){
                $str="All Stream";
            }else{
                if(count($cl)>0)
              $str=$cl[0]->stream_name;  
            }
      
                ?>
               
            <div id="tobeprinted">
                <?php
            $custom_message="MZAZI WA #student name, TUMSIFU YESU KRISTU. TUNAPENDA KUKUFAHAMISHA KUWA MSEMINARI ANATAKIWA KURIPOTI SEMINARINI TAREHE 20/06/2026 KWA MAANDALIZI YA MTIHANI WA KUHITIMU KIDATO CHA NNE. TAFADHALI HAKIKISHA UMEMALIZA ADA YOTE SIKU YA KURIPOTI."; 
                              
               ?>
                     <input type="hidden" name="custom_message" value="<?=$custom_message;?>"> 
              <div class="card">
               <div class="table-responsive mt-3">
                
                        <table class="table table-hover table-vcenter mb-0 text-nowrap table-bordered"   id="">
                           <thead>
                            <tr>
                                <th>#</th>
                                
                                 <td> <input type="checkbox" name="" value="" onclick="Allcheckbox()" id="Allselected"> All</td>
                                 <th>Names</th>
                               <!--   <th>Birth date</th>
                                 <th>Age</th>
                                 <th>Gender</th> -->
                                 <th>Class</th>
                                 <th>Stream</th>
                                 <th>Type</th>
                                
                                 <th>Phone</th>
                                 
                                 <th>Sms Cost</th>
                                </tr>
                                <thead>
                                    <tbody>
                                <?php
                            $n=0;
                            $female=0;
                               $male=0;
                               $day=0;
                               $board=0;
                               $streamA=0;
                               $streamB=0;
                               $ne=0;
                               $c=0;
                                 $holid_student=array();
                            if(count($cl)>0){
                               
                                foreach($cl as $le){
                                    $n++;
                                  if($le->gender=='Female'){
                                    $female=$female+1;
                                  }
                                  if($le->gender=='Male'){
                                    $male=$male+1;
                                  }
    //////////////////////  ////////////////////////////////////////////////////////////////////////////////
                                  //$holid_student[]=array($le->id);
                                  $student_id=$le->id;
                            // $tinvoice = $bmodel->get_total_invoice_amount($student_id,$year);
                                  
                                
                            // $results=findCalc($student_id,$dbname,$year);
                                  $type=$le->admission_type;
                                  $hst=$le->admission_type;
                                  if($type==3){
                                    $tp='B';
                                    $board++;
                                  }else{
                                     $tp='D';
                                     $day++;
                                  }

                                  if($le->stream_name=='A'){
                                    $streamA=$streamA+1;
                                  }else{
                                     $streamB=$streamB+1;
                                  }
                                  if($le->adimit_for==2){
                                    $new="New Comer";
                                    $ne++;
                                  }else{
                                     $new="Continous";
                                     $c++;
                                  }
                                 
                   
                     $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                      $ddate="";
                      $mbalance1=0;
                      $mbalance2=0;
                      $mbalance3=0;
                    $holid_student[]=array($student_id); 

               $phone = $db->query('SELECT phone1 FROM parents_tbl,parents_students_tbl WHERE parents_tbl.id = parents_students_tbl.parent_id AND'
               . ' parents_tbl.bill_account = 1  AND parents_students_tbl.student_id ='.$student_id.'');
             $pn = $phone->getResult(); 
               if(count($pn)>0){
                $phone=$pn[0]->phone1;
               }else{
                 $phone="---";
               }
    ///////////////////////
               $row="black";
       //  $std=$le->student_id; 
    $name = $amodel->get_student_details('students',$where = array('id' => $student_id));
                     
        
                   
        ///////////////////////////////////////////////////////////////////////////////////
                              $message="MZAZI WA ".$name[0]->first_name." TUMSIFU YESU KRISTU. TUNAPENDA KUKUFAHAMISHA KUWA MSEMINARI ANATAKIWA KURIPOTI SEMINARINI TAREHE 20/06/2026 KWA MAANDALIZI YA MTIHANI WA KUHITIMU KIDATO CHA NNE. TAFADHALI HAKIKISHA UMEMALIZA ADA YOTE SIKU YA KURIPOTI."; 
                              ?> 
                               <input type="hidden" name="message<?=$student_id;?>" value="<?=$message;?>"> 
                            <input type="hidden" name="student[]" value="<?=$student_id;?>"> 
                            <input type="hidden" name="studentName<?=$student_id;?>" value="<?=$name[0]->first_name;?>"> 
                             
                            <input type="hidden" name="phone<?=$student_id;?>" value="<?=$phone;?>"> 
                             
                                    <tr style="color: <?php echo $row;?>;" onclick="selectRow('<?php echo $student_id; ?>')" id="<?php echo $student_id; ?>">
                                    <td><?php echo $n?></td>
                                     <td>  <input type="checkbox" name="selected[]" value="<?php echo $student_id; ?>" onclick="checkbox('<?php echo $student_id; ?>')" id="selected<?php echo $student_id; ?>"></td>
                                    <td><?=$le->full_name?></td>
                                   <td><?=$le->class_name?></td>
                                    <td><?=$le->stream_name?></td>
                                    <td><?=$tp?></td>
                              
                                   <td><?=$phone;?></td>
                                  
                                   <td class="text-center">45</td>
                                   </tr>
                                  
                                   <?php
                                
                                   
                                }
                                ?>
                           <tr> 
                            <td colspan="6"></td>
                            <td>Total</td> 
                            <td class="text-center"><?php echo number_format($n*45);?></td>
                           </tr>
                                <?php

                        }else{
                             echo '<tr>';
                                  
                                    echo '<td colspan="7"> Currently there is no any history.</td>';
                            echo '</tr>';   
                            }
      
          ?>
          </tbody>
           </table>
 
      </div>

  </div>
  </div>
  <div class="form-group mb-3">
                <div class="col-sm-12">
                    <button class="btn btn-primary float-right" onclick="message_group_function();" id="send_message">Send Messages</button>
                </div>
            </div>
<noscript>
    <style>
        .table-condensed{
            padding-bottom: 20px; 

        }
        table.table{
            border-collapse:collapse;
            border: 1px solid black;
            width:80%;
          
            margin-left: auto;
            margin-right: auto;
/*            page-break-inside: avoid;*/
           
        }
         table.table td{
         border:1px solid black;
           font-size: 12px;
         }
        #myTable td,#myTable th{
            border:1px solid black;
           font-size: 12px;
           }
        h6{
            text-align: center;
        }
        .btnp,.viewbtn{
           display: none;
        }
        #myTable_wrapper .dataTables_filter,
        #myTable_wrapper .dataTables_paginate,
        #myTable_wrapper .dataTables_length {
         display: none;
}
 @media print {
      .table {
        border-collapse: collapse !important;
        border: 1px solid black !important;
      }
      }
      table.toba td{
        font-size: 12px;
      }
        
    </style>
</noscript>
  <script>
   $(document).ready(function() {
    checkSelected();
     $('#myTable2').DataTable();
  var table = $("#myTable2").DataTable({
    dom: 'f', // Show only the search input
    paging: false, // Disable pagination
    lengthChange: false, // Disable entries select
  });
});

  

     function selectRow(id){
         var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {
    row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {

    row.style.backgroundColor = 'black';
      row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        }
        checkSelected();
      
      }
      function checkbox(id){
        var row = document.getElementById(id);
        //alert(id);
        var remember = document.getElementById("selected"+id);
        if(remember.checked){
     remember.checked=false;  
      if (row) {

    row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=true; 
      
       if (row) {
    row.style.backgroundColor = 'black';
      row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }  
        } 
        checkSelected();
      }
function Allcheckbox(){
        var values=<?php echo json_encode($holid_student);?>;
        //alert(values.length);
        var rememberAll = document.getElementById("Allselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
            if(rememberAll.checked){
     remember.checked=true;  
      if (row) {
    
    row.style.backgroundColor = 'black';
    row.style.color = 'white';
  } else {
    console.error("Invalid row ID");
  }   
        }else{
      remember.checked=false; 
      
       if (row) {
      row.style.backgroundColor = 'white';
      row.style.color = 'black';
  } else {
    console.error("Invalid row ID");
  }  
        }
        }
        checkSelected();
      }
   
      function checkSelected(){
        var j=0;
        var values=<?php echo json_encode($holid_student);?>;
        //alert(values.length);
        var rememberAll = document.getElementById("Allselected");
        for( var i = 0; i < values.length; i++){ 
            var id=values[i];
             var row = document.getElementById(id);
            var remember = document.getElementById("selected"+id);
            if(remember.checked){
           j++;
       }else{
     
        }
        }
       // alert(j);
        if(j>0){
            $('#send_message').prop("disabled", false);
        }else{
            $('#send_message').prop("disabled", true);
        }
      }
  </script>
 
