<?php
$login = new App\Models\LoginModel();
?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">School Calendar</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>"><?php
                        if (session()->get('logged_in') == true) {
                            $shule = $login->get_student_details('database_list_tbl', $where = array('db_id' => session()->get('db_id')));
                            echo $shule[0]->instituition;
                        }
                    ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">School Calendar</li>
                </ol>
            </div>

            <div id="largeScreenTab">
                <ul class="nav nav-tabs page-header-tab">
                    <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#calendar-list">Calendar List</a></li>
                    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#calendar-add">New Calendar</a></li>
                </ul>
            </div>
            <div id="smallScreenTab">
                <ul class="nav nav-tabs page-header-tab">
                    <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#calendar-list">Calendar List</a></li>
                    <li></li><li></li>
                    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#calendar-add">New Calendar</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="calendar-list">
                <div class="d-flex justify-content-center">
                    <div id="calendarMessageDisplayArea"></div>
                    <form id="calendarFilterForm" class="form-inline">
                        Event date:
                        <input type="hidden" name="thedate" id="calendar_range_value" value="<?= esc($thedate ?? ''); ?>">
                        <div class="input-group ms-3 me-3">
                            <button
                                type="button"
                                class="btn btn-default pull-right daterange-all"
                                id="daterange-btn-calendar"
                                data-start="<?= esc($from_date ?? ''); ?>"
                                data-end="<?= esc($to_date ?? ''); ?>"
                            >
                                <span>
                                    <i class="fa fa-calendar"></i> <?= ! empty($thedate) ? esc($thedate) : 'Please Select Date'; ?>
                                </span>
                                <i class="fa fa-caret-down"></i>
                            </button>
                        </div>
                        <button type="submit" id="applyDateFilter" class="btn btn-primary">Create</button>
                    </form>
                </div>

                <hr>
                <p>&nbsp;</p>
                <center>
                    <div id="calendarResults"></div>
                </center>
            </div>

            <div class="tab-pane" id="calendar-add">
                <div class="card">
                    <div class="card-header" style="height:5px">
                        <h3 class="card-title">New Calendar</h3>
                        <div class="card-options ">
                            <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                        </div>
                    </div>
                    <hr>
                    <div class="card-body">
                        <div id="feedback"></div>
                        <form class="form-horizontal" id="AddSchoolCalendar">
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label">Event Date <span class="text-danger">*</span></label>
                                <div class="col-md-7">
                                    <input type="date" name="event_date" id="event_date" class="form-control form-control-sm" required="required">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label">Event Description <span class="text-danger">*</span></label>
                                <div class="col-md-7">
                                    <textarea name="event_description" id="event_description" rows="4" class="form-control form-control-sm" required="required"></textarea>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label">Event Participants <span class="text-danger">*</span></label>
                                <div class="col-md-7 pt-2">
                                    <label class="custom-control custom-checkbox custom-control-inline">
                                        <input type="checkbox" class="custom-control-input" name="parents" id="parents_participant" value="1">
                                        <span class="custom-control-label">Parents</span>
                                    </label>
                                    <label class="custom-control custom-checkbox custom-control-inline">
                                        <input type="checkbox" class="custom-control-input" name="students" id="students_participant" value="1">
                                        <span class="custom-control-label">Students</span>
                                    </label>
                                    <label class="custom-control custom-checkbox custom-control-inline">
                                        <input type="checkbox" class="custom-control-input" name="staff" id="staff_participant" value="1">
                                        <span class="custom-control-label">Staff</span>
                                    </label>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label">SMS Notification</label>
                                <div class="col-md-7 pt-2">
                                    <label class="custom-control custom-checkbox custom-control-inline">
                                        <input type="checkbox" class="custom-control-input" name="sms_enabled" id="sms_enabled" value="1">
                                        <span class="custom-control-label">Enable SMS notification</span>
                                    </label>
                                </div>
                            </div>
                            <div id="schoolCalendarSmsArea" style="display:none;">
                                <div class="form-group row" id="schoolCalendarSmsAudienceRow" style="display:none;">
                                    <label class="col-md-3 col-form-label">Send SMS To</label>
                                    <div class="col-md-7 pt-2">
                                        <label class="custom-control custom-checkbox custom-control-inline" id="studentSmsAudienceOption" style="display:none;">
                                            <input type="checkbox" class="custom-control-input" name="sms_to_students" id="sms_to_students" value="1">
                                            <span class="custom-control-label">Students / Parents</span>
                                        </label>
                                        <label class="custom-control custom-checkbox custom-control-inline" id="staffSmsAudienceOption" style="display:none;">
                                            <input type="checkbox" class="custom-control-input" name="sms_to_staff" id="sms_to_staff" value="1">
                                            <span class="custom-control-label">Staff</span>
                                        </label>
                                    </div>
                                </div>

                                <div class="form-group row" id="schoolCalendarSmsScheduleRow" style="display:none;">
                                    <label class="col-md-3 col-form-label">SMS Schedule <span class="text-danger">*</span></label>
                                    <div class="col-md-7">
                                        <div class="alert alert-info py-2">
                                            Add one or more dates and times for this SMS. Each schedule will be sent once.
                                        </div>
                                        <div id="schoolCalendarSmsSchedules"></div>
                                        <button type="button" class="btn btn-primary btn-sm mt-2" onclick="addSchoolCalendarScheduleRow('add')">
                                            <i class="fa fa-plus"></i> Add Schedule
                                        </button>
                                    </div>
                                </div>

                                <div id="schoolCalendarStudentSmsSection" style="display:none;">
                                    <div class="form-group row">
                                        <label class="col-md-3 col-form-label">Student/Parent SMS <span class="text-danger">*</span></label>
                                        <div class="col-md-7">
                                            <textarea name="sms_message" id="sms_message" rows="4" class="form-control form-control-sm" placeholder="Write student or parent SMS notification message here"></textarea>
                                            <small class="text-muted d-block mt-2">
                                                Use placeholders: <b>#studentFirstName</b>, <b>#studentFullName</b>, <b>#eventDate</b>, <b>#eventDescription</b>.
                                                SMS will follow the schedule dates and times selected above.
                                            </small>
                                            <small class="text-muted d-block mt-1">
                                                SMS message will be charged every 153 characters.
                                                Characters like <b>@</b> <b>&lt;</b> <b>&gt;</b> <b>^</b> <b>{</b> <b>}</b> <b>\</b> <b>/</b> <b>%</b> <b>'</b> <b>~</b> take up 2 characters. Please account for this when writing your message.
                                            </small>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-3 col-form-label">Send Type <span class="text-danger">*</span></label>
                                        <div class="col-md-7">
                                            <select class="form-control form-control-sm" name="send_type" id="send_type">
                                                <option value="">Select Type</option>
                                                <option value="1">Individual</option>
                                                <option value="2">Group</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div id="groupSmsControls" style="display:none;">
                                        <div class="form-group row">
                                            <label class="col-md-3 col-form-label">Group Filters</label>
                                            <div class="col-md-7">
                                                <div class="row">
                                                    <div class="col-md-4 mb-2">
                                                        <label class="mb-1">Academic year</label>
                                                        <select class="form-control form-control-sm" name="sms_year" id="sms_year">
                                                            <?php foreach (($year_options ?? []) as $year): ?>
                                                                <option value="<?= $year; ?>" <?= (int) ($current_year ?? date('Y')) === (int) $year ? 'selected' : ''; ?>><?= $year; ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4 mb-2">
                                                        <label class="mb-1">Level</label>
                                                        <select class="form-control form-control-sm" name="sms_level_id" id="sms_level_id">
                                                            <option value="0">All</option>
                                                            <?php foreach (($levels ?? []) as $level): ?>
                                                                <option value="<?= $level->id; ?>"><?= esc($level->level_name); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4 mb-2">
                                                        <label class="mb-1">Class</label>
                                                        <select class="form-control form-control-sm" name="sms_class_id" id="sms_class_id">
                                                            <option value="0">All</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4 mb-2">
                                                        <label class="mb-1">Stream</label>
                                                        <select class="form-control form-control-sm" name="sms_stream_id" id="sms_stream_id">
                                                            <option value="0">All</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4 mb-2">
                                                        <label class="mb-1">Status</label>
                                                        <select class="form-control form-control-sm" name="sms_status" id="sms_status">
                                                            <option value="0">All</option>
                                                            <?php foreach (($student_statuses ?? []) as $status): ?>
                                                                <option value="<?= $status->id; ?>" <?= (int) $status->id === 2 ? 'selected' : ''; ?>><?= esc($status->status_name); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <button type="button" class="btn btn-primary btn-sm mt-2" onclick="loadSchoolCalendarSmsGroup('add')">Create</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="individualSmsControls" style="display:none;">
                                        <div class="form-group row">
                                            <label class="col-md-3 col-form-label">Student Search</label>
                                            <div class="col-md-7">
                                                <div class="row">
                                                    <div class="col-md-4 mb-2">
                                                        <label class="mb-1">Academic year</label>
                                                        <select class="form-control form-control-sm" name="sms_year_individual" id="sms_year_individual">
                                                            <?php foreach (($year_options ?? []) as $year): ?>
                                                                <option value="<?= $year; ?>" <?= (int) ($current_year ?? date('Y')) === (int) $year ? 'selected' : ''; ?>><?= $year; ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4 mb-2">
                                                        <label class="mb-1">Status</label>
                                                        <select class="form-control form-control-sm" name="sms_status_individual" id="sms_status_individual">
                                                            <option value="0">All</option>
                                                            <?php foreach (($student_statuses ?? []) as $status): ?>
                                                                <option value="<?= $status->id; ?>" <?= (int) $status->id === 2 ? 'selected' : ''; ?>><?= esc($status->status_name); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4 mb-2">
                                                        <label class="mb-1">Search Name</label>
                                                        <div class="input-group">
                                                            <input type="text" class="form-control form-control-sm" name="student_search" id="student_search" placeholder="Student name / admission no">
                                                            <button type="button" class="btn btn-primary btn-sm" onclick="loadSchoolCalendarSmsIndividual('add')"><i class="fa fa-search"></i></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-3 col-form-label">Student Recipients</label>
                                        <div class="col-md-7">
                                            <div id="schoolCalendarSmsRecipients"></div>
                                        </div>
                                    </div>
                                </div>

                                <div id="schoolCalendarStaffSmsSection" style="display:none;">
                                    <div class="form-group row">
                                        <label class="col-md-3 col-form-label">Staff SMS <span class="text-danger">*</span></label>
                                        <div class="col-md-7">
                                            <textarea name="staff_sms_message" id="staff_sms_message" rows="4" class="form-control form-control-sm" placeholder="Write staff SMS notification message here"></textarea>
                                            <small class="text-muted d-block mt-2">
                                                Use placeholders: <b>#staffFirstName</b>, <b>#staffFullName</b>, <b>#eventDate</b>, <b>#eventDescription</b>.
                                                SMS will follow the schedule dates and times selected above.
                                            </small>
                                            <small class="text-muted d-block mt-1">
                                                SMS message will be charged every 153 characters.
                                                Characters like <b>@</b> <b>&lt;</b> <b>&gt;</b> <b>^</b> <b>{</b> <b>}</b> <b>\</b> <b>/</b> <b>%</b> <b>'</b> <b>~</b> take up 2 characters. Please account for this when writing your message.
                                            </small>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-3 col-form-label">Staff Search</label>
                                        <div class="col-md-7">
                                            <div class="input-group">
                                                <input type="text" class="form-control form-control-sm" name="staff_search" id="staff_search" placeholder="Staff name / phone">
                                                <button type="button" class="btn btn-primary btn-sm" onclick="loadSchoolCalendarStaff('add')">
                                                    <i class="fa fa-search"></i> Load Staff
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-3 col-form-label">Staff Recipients</label>
                                        <div class="col-md-7">
                                            <div id="schoolCalendarStaffRecipients"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-3 col-form-label"></label>
                                <div class="col-md-7">
                                    <button type="submit" class="btn btn-primary float-right">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="viewModal" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">View School Calendar Event</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="viewCalendarContent"><span class="fa fa-spinner fa-spin"></span> Loading...</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editModal" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit School Calendar Event</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="editCalendarContent"><span class="fa fa-spinner fa-spin"></span> Loading...</div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function setCalendarDateRange(rangeText, startDate, endDate) {
        $('#calendar_range_value').val(rangeText);
        $('#daterange-btn-calendar span').html('<i class="fa fa-calendar"></i> ' + rangeText);
        $('#daterange-btn-calendar').attr('data-start', startDate).attr('data-end', endDate);
    }

    function loadSchoolCalendarResults() {
        $('#calendarResults').html('<span class="fa fa-spinner fa-spin"></span> Retreiving results..');
        $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/load_school_calendar'; ?>',
            data: 'thedate=' + encodeURIComponent($('#daterange-btn-calendar span').text().trim()),
            success: function(res){
                $('#calendarResults').html(res);
                if ($.fn.DataTable.isDataTable('#myTable')) {
                    $('#myTable').DataTable().destroy();
                }
                $('#myTable').DataTable();
            },
            error: function(){
                $('#calendarResults').html('<div class="alert alert-warning">Fail to retreive report.!!</div>');
            }
        });
    }

    function schoolCalendarConfig(prefix) {
        if (prefix === 'edit') {
            return {
                form: '#UpdateSchoolCalendar',
                smsEnabled: '#edit_sms_enabled',
                smsArea: '#editSchoolCalendarSmsArea',
                smsAudienceRow: '#editSchoolCalendarSmsAudienceRow',
                smsScheduleRow: '#editSchoolCalendarSmsScheduleRow',
                schedules: '#editSchoolCalendarSmsSchedules',
                participantParents: '#edit_parents_participant',
                participantStudents: '#edit_students_participant',
                participantStaff: '#edit_staff_participant',
                studentAudienceOption: '#editStudentSmsAudienceOption',
                staffAudienceOption: '#editStaffSmsAudienceOption',
                studentSmsAudience: '#edit_sms_to_students',
                staffSmsAudience: '#edit_sms_to_staff',
                eventDate: '#UpdateSchoolCalendar input[name="event_date"]',
                studentSection: '#editSchoolCalendarStudentSmsSection',
                sendType: '#edit_send_type',
                groupBox: '#editGroupSmsControls',
                individualBox: '#editIndividualSmsControls',
                recipients: '#editSchoolCalendarSmsRecipients',
                level: '#edit_sms_level_id',
                classField: '#edit_sms_class_id',
                stream: '#edit_sms_stream_id',
                year: '#edit_sms_year',
                status: '#edit_sms_status',
                yearIndividual: '#edit_sms_year_individual',
                statusIndividual: '#edit_sms_status_individual',
                search: '#edit_student_search',
                staffSection: '#editSchoolCalendarStaffSmsSection',
                staffRecipients: '#editSchoolCalendarStaffRecipients',
                staffSearch: '#edit_staff_search'
            };
        }

        return {
            form: '#AddSchoolCalendar',
            smsEnabled: '#sms_enabled',
            smsArea: '#schoolCalendarSmsArea',
            smsAudienceRow: '#schoolCalendarSmsAudienceRow',
            smsScheduleRow: '#schoolCalendarSmsScheduleRow',
            schedules: '#schoolCalendarSmsSchedules',
            participantParents: '#parents_participant',
            participantStudents: '#students_participant',
            participantStaff: '#staff_participant',
            studentAudienceOption: '#studentSmsAudienceOption',
            staffAudienceOption: '#staffSmsAudienceOption',
            studentSmsAudience: '#sms_to_students',
            staffSmsAudience: '#sms_to_staff',
            eventDate: '#event_date',
            studentSection: '#schoolCalendarStudentSmsSection',
            sendType: '#send_type',
            groupBox: '#groupSmsControls',
            individualBox: '#individualSmsControls',
            recipients: '#schoolCalendarSmsRecipients',
            level: '#sms_level_id',
            classField: '#sms_class_id',
            stream: '#sms_stream_id',
            year: '#sms_year',
            status: '#sms_status',
            yearIndividual: '#sms_year_individual',
            statusIndividual: '#sms_status_individual',
            search: '#student_search',
            staffSection: '#schoolCalendarStaffSmsSection',
            staffRecipients: '#schoolCalendarStaffRecipients',
            staffSearch: '#staff_search'
        };
    }

    function hasSchoolCalendarStudentParticipants(config) {
        return $(config.participantParents).is(':checked') || $(config.participantStudents).is(':checked');
    }

    function hasSchoolCalendarStaffParticipants(config) {
        return $(config.participantStaff).is(':checked');
    }

    function hasSchoolCalendarStudentSmsAudience(config) {
        return $(config.studentSmsAudience).is(':checked');
    }

    function hasSchoolCalendarStaffSmsAudience(config) {
        return $(config.staffSmsAudience).is(':checked');
    }

    function getSchoolCalendarDefaultScheduleValue(config) {
        var eventDate = $(config.eventDate).val();
        if (eventDate) {
            return eventDate + 'T08:00';
        }

        var now = new Date();
        var month = String(now.getMonth() + 1).padStart(2, '0');
        var day = String(now.getDate()).padStart(2, '0');
        return now.getFullYear() + '-' + month + '-' + day + 'T08:00';
    }

    function buildSchoolCalendarScheduleRowHtml(scheduleAt, sentAtText) {
        var sentMarkup = sentAtText ? '<small class="text-success d-block mt-1">' + sentAtText + '</small>' : '';

        return '' +
            '<div class="border rounded p-2 mb-2 school-calendar-schedule-row">' +
                '<div class="row align-items-end">' +
                    '<div class="col-md-10">' +
                        '<label class="mb-1">Schedule date and time</label>' +
                        '<input type="datetime-local" class="form-control form-control-sm" name="sms_schedule_at[]" value="' + (scheduleAt || '') + '">' +
                        sentMarkup +
                    '</div>' +
                    '<div class="col-md-2 mt-2 mt-md-0">' +
                        '<button type="button" class="btn btn-danger btn-sm w-100 remove-school-calendar-schedule">Remove</button>' +
                    '</div>' +
                '</div>' +
            '</div>';
    }

    function addSchoolCalendarScheduleRow(prefix, scheduleAt, sentAtText) {
        var config = schoolCalendarConfig(prefix);
        var scheduleValue = scheduleAt || getSchoolCalendarDefaultScheduleValue(config);
        $(config.schedules).append(buildSchoolCalendarScheduleRowHtml(scheduleValue, sentAtText));
    }

    function ensureSchoolCalendarScheduleRow(prefix) {
        var config = schoolCalendarConfig(prefix);
        if ($(config.schedules).find('.school-calendar-schedule-row').length === 0) {
            addSchoolCalendarScheduleRow(prefix);
        }
    }

    function populateSchoolCalendarClasses(levelSelector, classSelector, selectedClassId) {
        $.ajax({
            url: '<?php echo base_url() . '/class_list'; ?>',
            type: 'post',
            data: {clvl: $(levelSelector).val()},
            dataType: 'json',
            success: function(response){
                $(classSelector).empty().append("<option value='0'>All</option>");
                for (var i = 0; i < response.length; i++) {
                    var selected = parseInt(selectedClassId || 0, 10) === parseInt(response[i]['id'], 10) ? 'selected' : '';
                    $(classSelector).append("<option value='" + response[i]['id'] + "' " + selected + ">" + response[i]['name'] + "</option>");
                }
                $(classSelector).trigger('change');
            }
        });
    }

    function populateSchoolCalendarStreams(classSelector, streamSelector, selectedStreamId) {
        if ($(classSelector).val() === '0') {
            $(streamSelector).empty().append("<option value='0'>All</option>");
            return;
        }
        $.ajax({
            url: '<?php echo base_url() . '/index.php/StudentController/get_stream_details'; ?>',
            type: 'post',
            data: {clvl: $(classSelector).val()},
            dataType: 'json',
            success: function(response){
                $(streamSelector).empty().append("<option value='0'>All</option>");
                for (var i = 0; i < response.length; i++) {
                    var selected = parseInt(selectedStreamId || 0, 10) === parseInt(response[i]['id'], 10) ? 'selected' : '';
                    $(streamSelector).append("<option value='" + response[i]['id'] + "' " + selected + ">" + response[i]['name'] + "</option>");
                }
            }
        });
    }

    function toggleSchoolCalendarSms(prefix) {
        var config = schoolCalendarConfig(prefix);
        if ($(config.smsEnabled).is(':checked')) {
            $(config.smsArea).show();
            $(config.smsScheduleRow).show();
            ensureSchoolCalendarScheduleRow(prefix);
            toggleSchoolCalendarParticipantAreas(prefix, true, true);
        } else {
            $(config.smsArea).hide();
            $(config.smsAudienceRow).hide();
            $(config.smsScheduleRow).hide();
            $(config.studentSection).hide();
            $(config.staffSection).hide();
        }
    }

    function syncSchoolCalendarSmsAudienceOptions(prefix, preserveAudienceSelection) {
        var config = schoolCalendarConfig(prefix);
        var hasStudentParticipants = hasSchoolCalendarStudentParticipants(config);
        var hasStaffParticipants = hasSchoolCalendarStaffParticipants(config);

        if (hasStudentParticipants) {
            $(config.studentAudienceOption).show();
            if (!preserveAudienceSelection && !$(config.studentSmsAudience).is(':checked')) {
                $(config.studentSmsAudience).prop('checked', true);
            }
        } else {
            $(config.studentAudienceOption).hide();
            $(config.studentSmsAudience).prop('checked', false);
        }

        if (hasStaffParticipants) {
            $(config.staffAudienceOption).show();
            if (!preserveAudienceSelection && !$(config.staffSmsAudience).is(':checked')) {
                $(config.staffSmsAudience).prop('checked', true);
            }
        } else {
            $(config.staffAudienceOption).hide();
            $(config.staffSmsAudience).prop('checked', false);
        }

        $(config.smsAudienceRow).toggle(hasStudentParticipants || hasStaffParticipants);
    }

    function toggleSchoolCalendarParticipantAreas(prefix, preserveRecipients, preserveAudienceSelection) {
        var config = schoolCalendarConfig(prefix);
        var smsEnabled = $(config.smsEnabled).is(':checked');

        if (!smsEnabled) {
            $(config.smsAudienceRow).hide();
            $(config.smsScheduleRow).hide();
            $(config.studentSection).hide();
            $(config.staffSection).hide();
            return;
        }

        syncSchoolCalendarSmsAudienceOptions(prefix, preserveAudienceSelection);
        $(config.smsScheduleRow).show();

        if (hasSchoolCalendarStudentSmsAudience(config)) {
            $(config.studentSection).show();
            toggleSchoolCalendarSendType(prefix, preserveRecipients);
        } else {
            $(config.studentSection).hide();
            $(config.groupBox).hide();
            $(config.individualBox).hide();
        }

        if (hasSchoolCalendarStaffSmsAudience(config)) {
            $(config.staffSection).show();
        } else {
            $(config.staffSection).hide();
        }
    }

    function toggleSchoolCalendarSendType(prefix, preserveRecipients) {
        var config = schoolCalendarConfig(prefix);
        var sendType = $(config.sendType).val();

        $(config.groupBox).hide();
        $(config.individualBox).hide();
        if (!preserveRecipients && hasSchoolCalendarStudentSmsAudience(config)) {
            $(config.recipients).html('');
        }

        if (!hasSchoolCalendarStudentSmsAudience(config)) {
            return;
        }

        if (sendType === '2') {
            $(config.groupBox).show();
        } else if (sendType === '1') {
            $(config.individualBox).show();
        }
    }

    function loadSchoolCalendarSmsGroup(prefix) {
        var config = schoolCalendarConfig(prefix);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/school_calendar_sms_group'; ?>',
            data: $(config.form).serialize() + '&mode=' + prefix,
            beforeSend: function () {
                $(config.recipients).html('<center><b><span class="fa fa-spin fa-spinner"></span> Loading students...</b></center>');
            },
            success: function (res) {
                $(config.recipients).html(res);
            },
            error: function () {
                $(config.recipients).html('<div class="alert alert-warning">Failed to load students.</div>');
            }
        });
    }

    function loadSchoolCalendarSmsIndividual(prefix) {
        var config = schoolCalendarConfig(prefix);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/school_calendar_sms_individual'; ?>',
            data: $(config.form).serialize() + '&sms_year=' + $(config.yearIndividual).val() + '&sms_status=' + $(config.statusIndividual).val() + '&student_search=' + $(config.search).val() + '&mode=' + prefix,
            beforeSend: function () {
                $(config.recipients).html('<center><b><span class="fa fa-spin fa-spinner"></span> Searching students...</b></center>');
            },
            success: function (res) {
                $(config.recipients).html(res);
            },
            error: function () {
                $(config.recipients).html('<div class="alert alert-warning">Failed to load students.</div>');
            }
        });
    }

    function loadSchoolCalendarStaff(prefix) {
        var config = schoolCalendarConfig(prefix);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() . '/school_calendar_sms_staff'; ?>',
            data: $(config.form).serialize() + '&staff_search=' + $(config.staffSearch).val() + '&mode=' + prefix,
            beforeSend: function () {
                $(config.staffRecipients).html('<center><b><span class="fa fa-spin fa-spinner"></span> Loading staff...</b></center>');
            },
            success: function (res) {
                $(config.staffRecipients).html(res);
            },
            error: function () {
                $(config.staffRecipients).html('<div class="alert alert-warning">Failed to load staff.</div>');
            }
        });
    }

    function initSchoolCalendarSmsForm(prefix, options) {
        var config = schoolCalendarConfig(prefix);
        var selectedClassId = options && options.selectedClassId ? options.selectedClassId : 0;
        var selectedStreamId = options && options.selectedStreamId ? options.selectedStreamId : 0;
        var preserveRecipients = options && options.preserveRecipients;
        var preserveAudienceSelection = options && options.preserveAudienceSelection;

        toggleSchoolCalendarSms(prefix);
        toggleSchoolCalendarParticipantAreas(prefix, preserveRecipients, preserveAudienceSelection);
        populateSchoolCalendarClasses(config.level, config.classField, selectedClassId);

        $(config.level).off('change.schoolCalendar').on('change.schoolCalendar', function () {
            populateSchoolCalendarClasses(config.level, config.classField, 0);
        });

        $(config.classField).off('change.schoolCalendar').on('change.schoolCalendar', function () {
            populateSchoolCalendarStreams(config.classField, config.stream, selectedStreamId);
            selectedStreamId = 0;
        });

        $(config.smsEnabled).off('change.schoolCalendar').on('change.schoolCalendar', function () {
            toggleSchoolCalendarSms(prefix);
        });

        $(config.participantParents + ',' + config.participantStudents + ',' + config.participantStaff)
            .off('change.schoolCalendar')
            .on('change.schoolCalendar', function () {
                toggleSchoolCalendarParticipantAreas(prefix, true, false);
            });

        $(config.studentSmsAudience + ',' + config.staffSmsAudience)
            .off('change.schoolCalendar')
            .on('change.schoolCalendar', function () {
                toggleSchoolCalendarParticipantAreas(prefix, true, true);
            });

        $(config.sendType).off('change.schoolCalendar').on('change.schoolCalendar', function () {
            toggleSchoolCalendarSendType(prefix, false);
        });

        $(document)
            .off('click.schoolCalendarScheduleRemove', config.schedules + ' .remove-school-calendar-schedule')
            .on('click.schoolCalendarScheduleRemove', config.schedules + ' .remove-school-calendar-schedule', function () {
                $(this).closest('.school-calendar-schedule-row').remove();
            });

        setTimeout(function () {
            populateSchoolCalendarStreams(config.classField, config.stream, selectedStreamId);
        }, 200);

        if ($(config.smsEnabled).is(':checked') || $(config.schedules).find('.school-calendar-schedule-row').length > 0) {
            ensureSchoolCalendarScheduleRow(prefix);
        }
    }

    $('#AddSchoolCalendar').submit(function(e){
        var savedEventDate = $('#event_date').val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/save_school_calendar'; ?>',
            data: $(this).serialize(),
            success: function(res){
                var data = JSON.parse(res);
                if (data['status'] == "0") {
                    $('#AddSchoolCalendar')[0].reset();
                    $('#schoolCalendarSmsRecipients').html('');
                    $('#schoolCalendarStaffRecipients').html('');
                    $('#schoolCalendarSmsArea').hide();
                    $('#schoolCalendarSmsAudienceRow').hide();
                    $('#schoolCalendarSmsScheduleRow').hide();
                    $('#studentSmsAudienceOption').hide();
                    $('#staffSmsAudienceOption').hide();
                    $('#schoolCalendarSmsSchedules').html('');
                    $('#schoolCalendarStudentSmsSection').hide();
                    $('#schoolCalendarStaffSmsSection').hide();
                    $('#groupSmsControls').hide();
                    $('#individualSmsControls').hide();
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>' + data['statusDesc'] + '</div>');
                    initSchoolCalendarSmsForm('add');

                    if (savedEventDate) {
                        var parts = savedEventDate.split('-');
                        var displayDate = parts[0] + '/' + parseInt(parts[1], 10) + '/' + parseInt(parts[2], 10);
                        setCalendarDateRange(displayDate + ' - ' + displayDate, savedEventDate, savedEventDate);
                    }

                    $('.nav-link[href="#calendar-list"]').tab('show');
                    loadSchoolCalendarResults();
                } else {
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>' + data['statusDesc'] + '</div>');
                }
            },
            error: function(){
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Sorry! Something went wrong while saving calendar event.</div>');
            }
        });
        e.preventDefault();
    });

    $('#calendarFilterForm').submit(function(e){
        var selectedRange = $('#daterange-btn-calendar span').text().trim();
        $('#calendar_range_value').val(selectedRange);
        loadSchoolCalendarResults();
        e.preventDefault();
    });

    $(document).on('click', '.ViewEvent', function () {
        $('#viewModal').modal('show');
        $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/view_school_calendar'; ?>',
            data: 'id=' + $(this).attr('data-id'),
            success: function(res){
                $('#viewCalendarContent').html(res);
            },
            error: function(){
                $('#viewCalendarContent').html('<div class="alert alert-danger">Sorry! Failed to load event details.</div>');
            }
        });
    });

    $(document).on('click', '.EditEvent', function () {
        $('#editModal').modal('show');
        $.ajax({
            type: "POST",
            url: '<?php echo base_url() . '/edit_school_calendar'; ?>',
            data: 'id=' + $(this).attr('data-id'),
            success: function(res){
                $('#editCalendarContent').html(res);
            },
            error: function(){
                $('#editCalendarContent').html('<div class="alert alert-danger">Sorry! Failed to load event form.</div>');
            }
        });
    });

    $(document).ready(function () {
        initSchoolCalendarSmsForm('add');
        loadSchoolCalendarResults();
    });
</script>
