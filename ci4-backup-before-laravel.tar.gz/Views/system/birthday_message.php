<?php
             $bmodel = new App\Models\BillingModel();
             $report = new App\Models\ReportsModel();
             $amodel = new App\Models\AdmissionModel();
          $dbname=session()->get('db_name');
          $db = \Config\Database::connect($dbname);
           $par_stu = $amodel->get_student_details('parents_students_tbl',$where = array('student_id' => $student_id,));
          
           $phone="---";
           foreach($par_stu as $pn){
              $par_phone = $amodel->get_student_details('parents_tbl',$where = array('id' => $student_id,'bill_account'=>1));
              if(count($par_phone)>0){
                $phone=$par_phone[0]->phone1;  
              }
           }
          
    //   $phone = $db->query('SELECT phone1 FROM parents_tbl,parents_students_tbl WHERE parents_tbl.id = parents_students_tbl.parent_id AND'
    //           . ' parents_tbl.bill_account = 1  AND parents_students_tbl.student_id ='.$student_id.'');
    //          $pn = $phone->getResult(); 
    //           if(count($pn)>0){
    //             $phone=$pn[0]->phone1;
    //           }else{
    //              $phone="No Phone Number";
    //           }

       $adm = $amodel->get_student_details('students',$where = array('id' => $student_id,));
       if(count($adm)==0){
           echo $student_id;
           return;
       }
       $message="Happy Birthday ".$adm[0]->first_name.".  Wishing you a very happy birthday filled with many achievements and success!";
    ?>

<div class="form-group row">
                 <label for="staticEmail" class="col-sm-4 col-form-label">Phone</label>
                <div class="col-sm-8">
                    <input type="text" name="phone" value="<?php echo $phone;?>" class="form-control-sm">
                 
                </div>
                <label for="staticEmail" class="col-sm-4 col-form-label mb-3">Message</label>
                <div class="col-sm-8 mb-3">
                     <textarea cols='15' rows='5' class="form-control form-control-sm" name="message"><?= $message; ?></textarea>
                 
                </div></div>
               <div class="form-group mb-3">
                <div class="col-sm-12">
                    <button class="btn btn-primary float-right" onclick="message_function();" id="send_message">Send</button>
                </div>
            </div>