<?php 
    $stym = new App\Models\SystemModel();

    $temp = $stym->messages_deposit_details('messages_templates');

?>
<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title">System Messages Template</h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a class="nav-link" href="<?php echo base_url('dashboard')?>">Eden Garden</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Messages Template</li>
                </ol>
            </div>
            <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><a class="nav-link active" id="Class-tab" data-toggle="tab" href="#sms-all">Messages Template</a></li>
                <li class="nav-item"><a class="nav-link" id="Class-tab" data-toggle="tab" href="#newTemp">New Template</a></li>
            </ul>
        </div>
    </div>
</div>

<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane active" id="sms-all">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-hover table-vcenter mb-0 text-nowrap"  id="myTable">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Message</th>
                                    <th>Date Created</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    foreach($temp as $t):
                                ?>
                                <tr>
                                    <td><?= $t->title; ?></td>
                                    <td><?= $t->message; ?></td>
                                    <td><?= $t->date_created; ?></td>
                                    <td><button type="button" class="btn btn-primary btn-sm UpdateID" data-id="<?= $t->m_id;?>"><i class="fa fa-edit"></i> Edit</button></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="tab-pane" id="newTemp">
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header" style="height:5px">
                                    <h3 class="card-title">Make New Template</h3>
                                <div class="card-options">
                                    <a href="#" class="card-options-collapse " data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                </div>
                            </div>
                            <hr>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div id="feedback"></div>
                                        <form method="post" id="Create_Template" class="form-horizontal">
                                            <div class="row mb-3">
                                                <label class="col-sm-3 col-form-label col-form-label-sm">Title:</label>
                                                <div class="col-sm-7">
                                                    <input type="text" class="form-control form-control-sm"  name="title" placeholder="Message Title">
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label class="col-sm-3 col-form-label col-form-label-sm">Message:</label>
                                                <div class="col-sm-7">
                                                    <textarea cols='35' rows='10' class="form-control form-control-sm" name="message"></textarea>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-sm-10">
                                                    <button class="btn btn-primary float-right" type="submit" id="save_template">Create</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Edit Message Template</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="UpdateTemp"></div>
        </div>
      </div>
      
    </div>
  </div>
<script type="text/javascript">
    $('#Create_Template').submit(function(e){
        e.preventDefault();

        $.ajax({
            beforeSend: function () {
                $('#save_template').prop("disabled", true);
            },
            url: '<?php echo base_url() . '/index.php/SystemController/save_Template_Details'; ?>',
            type: 'POST',
            data: $('#Create_Template').serialize(),
            success:function(res){
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                   $('#Create_Template')[0].reset();
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#save_template').prop("disabled", false);
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            },
            error: function(res){
                $('#save_template').prop("disabled", false);
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Create New Template.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
            }
        });
    });

    $(".UpdateID").click(function () {
        var data = 'id=' + $(this).attr('data-id');
        // alert (data);
        $('#myModal').modal('show');

        $.ajax({
            type: "GET",
            url: "<?php echo base_url() . '/index.php/SystemController/manage_Template_Details'; ?>",
            data: data,
            beforSend: function()
            {
                $('#UpdateTemp').html();
            },
            success: function(res){
                $('#UpdateTemp').html(res);
                 
            },
            error: function ()
            {

            }
        });
    });
</script>