<div class="row">
    <div class="col-md-12">
        <div id="feedback"></div>
        <form method="post" id="UpdateTemplate" class="form-horizontal">
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label col-form-label-sm">Title:</label>
                <div class="col-sm-7">
                    <input type="hidden" name="msg_id" value="<?= $template[0]->m_id; ?>">
                    <input type="text" class="form-control form-control-sm"  name="title" placeholder="Message Title" value="<?= $template[0]->title;?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label col-form-label-sm">Message:</label>
                <div class="col-sm-7">
                    <textarea cols='35' rows='10' class="form-control form-control-sm" name="message"><?= $template[0]->message; ?></textarea>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-sm-10">
                    <button class="btn btn-primary float-right" type="submit" id="update_template">Save</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript">
    $('#UpdateTemplate').submit(function(e){
        $.ajax({
            type: "POST",
            url: "<?php echo base_url() . '/index.php/SystemController/Update_messagesTemp'; ?>",
            data: $(this).serialize(),
            success: function (res) {
                var data = JSON.parse(res);
                if(data['status'] == "0"){
                   $('#Create_Template')[0].reset();
                    $('#feedback').html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                }else{
                    $('#save_template').prop("disabled", false);
                    $('#feedback').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>'+ data['statusDesc'] + '</div>');
                }
            },
            error: function (res) {
                $('#feedback').html('<div class="alert alert-danger alert-dismissible" role="alert"><strong>Sorry! Something went wrong!</strong> Couldnt Update Template.<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button></div>');
            }
        });
        e.preventDefault();
    });
</script>