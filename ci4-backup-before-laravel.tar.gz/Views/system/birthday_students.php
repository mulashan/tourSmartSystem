<?php
     $bmodel = new App\Models\BillingModel();
     $smodel = new App\Models\StudentModel();
     $dbname=session()->get('db_name');
      $db = \Config\Database::connect($dbname);
      
      $dated=date('-m-d',strtotime($date));
     //echo $date;
         $names= $db->query('SELECT * FROM students 
                          WHERE `birth_date` = \''.$date.'\' OR`birth_date`LIKE \'%'.$dated.'\'');
                            $result = $names->getResult();
if(count($result) > 0){ 
    ?>
    <table class="table table-hover">
            <thead>
                 <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Birth Date</th>
                    
                    <th></th>
                </tr>
        </thead> 
        <tbody>
            <?php foreach ($result as $s) {
                 $std = $smodel->gettable_stdetail($s->id);
             ?>
            <tr>
                   <td><?= $s->student_id; ?></td>
                   <td><?= $s->first_name.' '.$s->middle_name.' '.$s->last_name; ?></td>
                   <td><?= $s->gender; ?></td>
                   <td><?= $s->birth_date; ?></td>
                  <td><button class="btn btn-primary btn-sm pull-right" onclick="select_msg_student('<?= $s->id; ?>')"><i class="" aria-hidden="true"></i> select</button></td>
               </tr>
           <?php 
        
       } ?>
        </tbody>
      </table>
<?php  }
else{
       echo "<span style='color:red'>No any data Found</span>";

}
?>

 
