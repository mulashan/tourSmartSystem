   <?php
 $bmodel = new App\Models\BillingModel();
  $cmodel = new App\Models\ClassesModel();

  $ctype= $bmodel->get_table_details('name_type_tbl');
  $all_msg = $all_msg ?? $bmodel->get_item_name('messages',$where = array('send_no' =>$msgs[0]->send_number));
  $msg_group = $msgs ?? [];
  
  $name_type_id=0;
  if($msg_group[0]->message_type==2){
  $name_type = $bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$msgs[0]->trans_number,'trans_type'=>2,'transation_nature'=>1));
 $name_type_id=$name_type[0]->name_type_id;
}
?>
 <div class="tab-pane active" id="sms-all">
                <div class="d-flex justify-content-center">
                  <h5>View Message Details</h5>
                </div>
<div class="card">
                    <div class="card-body">
                        <table class="table  table-vcenter mb-0 text-nowrap" id="Table">
                            <thead>
                                <tr>
                                    <th>SN</th>
                                    <th>Names</th>
                                    <th>Massage Id</th>
                                    <th>Phone</th>
                                    <th>Message</th>
                                    <th>Status</th>
                                    <th>Cost</th>
                                
                                
                                </tr>
                            </thead>
                            <tbody id="messageData">
                              <?php 
                              $n=0;
                        foreach($all_msg as $msg){
                            $full_name = '';
                            if($msg->message_type==6){
                              $name = $bmodel->get_item_name('students_application_tbl',$where = array('id' =>$msg->reference_no));
                              if(!empty($name)){
                                  $full_name=$name[0]->full_name;
                              }
                          }else{
                            if($name_type_id==4 && $msg->message_type==2){
                              $name = $bmodel->get_item_name('students_application_tbl',$where = array('id' =>$msg->reference_no)); 
                               if(!empty($name)){
                                   $full_name=$name[0]->full_name;
                               }
                            }else{
                            if($msg->message_type==12 || $msg->message_type==13 || $msg->message_type==14 || $msg->message_type==17){
                              $name = $bmodel->get_item_name('users',$where = array('user_id' =>$msg->reference_no));
                              if(!empty($name)){
                              $full_name=$name[0]->first_name.' '.$name[0]->last_name;

                              }else{
                                $full_name='';
                              }
                               }else{
                            $name = $bmodel->get_item_name('students',$where = array('id' =>$msg->reference_no));
                             if(!empty($name)){
                                 $full_name=$name[0]->full_name;
                             }else if($msg->message_type==18){
                                $name = $bmodel->get_item_name('users',$where = array('user_id' =>$msg->reference_no));
                                if(!empty($name)){
                                    $full_name=trim($name[0]->first_name.' '.$name[0]->last_name);
                                }
                             }
                          }
                        }
                          }
                            
                            $n++;
                            ?>
                            <tr>
                            <td><?php echo $n; ?></td>
                            
                            <td><?php echo $full_name; ?></td>
                            <td><?php echo $msg->message_id; ?></td>
                            <td><?php echo $msg->phone_no; ?></td>
                            <td> <textarea cols='35' rows='4' readonly style='border:none;outline:none;resize:none;'> <?php echo $msg->message; ?></textarea></td>
                            <td><?php echo $msg->status_description; ?><br><?php echo $msg->time_delivered; ?></td>
                            <td>45</td>
                        </tr>
                            <?php
                             }
                              ?> 
                              <tr>
                                  <td></td><td></td><td></td><td></td><td></td><td>Total</td><td><?php echo number_format($n*45); ?></td>
                              </tr> 
                            </tbody>
                        </table>
                    </div>
                </div>
