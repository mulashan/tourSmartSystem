<?php 
    namespace App\Controllers;

    use CodeIgniter\Controller;
    use App\Models\LoginModel;

    class Login extends BaseController{
      
        public function index()
        {
            return view('templates/login');
        } 
        function users_login(){ 
          
           $loginModel = new LoginModel();
          // $session = \Config\Services::session();
           $validation =  \Config\Services::validation();

           $login_data = [
                'username' => 'required|min_length[3]|max_length[255]',
                'pswd' => 'required',
                ];

           if ($this->validate($login_data)){

               $result =  $loginModel->verfy_user($this->request->getPost('username'),$this->request->getPost('pswd')); 

      $user = 0;
     $pass=$this->request->getPost('pswd');
      $hashedPassword = password_hash($pass, PASSWORD_DEFAULT);     
     if($result){
         if($result[0]->updated == 0 && $result[0]->password == sha1($pass)){
               
         $data=array(
         'password'=>$hashedPassword,
         'updated'=>1
             );

     $loginModel->update_table_details('users_session_tbl',$where = array('user_id' =>$result[0]->user_id),$data);
        $user = 1;
                    
                }else{
             
             if($result[0]->updated == 1 && password_verify($pass, $result[0]->password)){

              $user = 1;
             }

            }
              
        if($user ==1){

        $data2=array(
         'password'=>$result[0]->password,
         'updated'=>1
             );


   $users_dtls =  $loginModel->get_users_details($result[0]->user_id);
//   echo $result[0]->user_id;
//   print_r($users_dtls);
//   return;
     $loginModel->update_table_details2('users_session_tbl',$where = array('user_id' =>$result[0]->user_id),$data2,$users_dtls[0]->db_name);    
               $session_data = [
                    'user_id' => $users_dtls[0]->user_id,
                    'first_name' => $users_dtls[0]->first_name,
                    'last_name'  => $users_dtls[0]->last_name,
                    'user_type'  => $users_dtls[0]->user_type,
                    'initial_username'=> $users_dtls[0]->user_type,
                    'user_photo'=> $users_dtls[0]->user_photo,
                    'db_name'=> $users_dtls[0]->db_name,
                    'db_id'=> $users_dtls[0]->db_id,
                    'logged_in' => true
                ];
                $this->session->set($session_data);
                
            $allowed_menu['allowed_menu'] = $loginModel->get_allowed_menu($users_dtls[0]->user_type,$users_dtls[0]->initial_username);
           $this->session->set($allowed_menu);

          $redirectUrl=$this->request->getPost('redirect');
        if($redirectUrl!=""){
              return redirect()->to($redirectUrl ? $redirectUrl : '/');
        }

                return view('templates/header')
                .view('templates/contents')
                .view('templates/footer'); 
               }
           else{
               $this->session ->setTempdata('error','Wrong Username or Password');
                   return redirect()->to(base_url());
           }
       }
              else{
                   $this->session ->setTempdata('error','Wrong Username or Password');
                   return redirect()->to(base_url());
                }
            }else{
                    $this->session ->setTempdata('error',$validation->listErrors());
                    return redirect()->to(base_url());
            }



        }
    }
?>