<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ClassesModel;
use App\Models\StudentModel;

class ClassController extends BaseController
{

    public $cmodel;
    public $smodel;
    public function __construct()
    {
        helper("form");
        $this->cmodel = new ClassesModel();
        $this->smodel = new StudentModel();
         $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
         helper('array');
        // helper('form');
         //helper('validation');
        // $validation = \Config\Services::validation();
    }

    public function classes()
    {

        return view('templates/header')
        .view('student/rooms')
        .view('templates/footer');   
    }


        

    // ---------classes and class level--------// 
    public function clss_level(){
        $data['gvmt_level']= $this->cmodel->government_level();
        return view('templates/header')
        .view('student/class_level',$data)
        .view('templates/footer');   
    }

///////////////////////////////////////////////////////////////////////
        public function load_item_datalv()
    {
        
        $request = service('request');
        $postData = $request->getPost();
        $item_data = array();
        $builder = $this->db->table("items_tbl");

        if(isset($postData['query'])){
            
            $builder->select('id,item_name,item_price,item_size,item_attribute,item_type');
            $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
           // $builder->where('item_type = 1 OR item_type = 2 OR item_type = 3');
            $builder->like('item_name',$postData['query'],'both');
            $builder->limit(100);
            $query = $builder->get();
            $item_result = $query->getResult();
        }else{

            $builder->select('id,item_name,item_price,item_size,item_attribute,item_type');
            $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
            //$builder->where('item_type = 1 OR item_type = 2 OR item_type = 3 OR item_type = 8');
            $builder->limit(100);
            //$builder->where('item_type = 1 OR item_type = 2 OR item_type = 3');
           // $builder->limit(100);
            $query = $builder->get();
            $item_result = $query->getResult();
        }
        
        if(count($item_result) > 0){
            foreach($item_result as $result){
                $item_data[] = array('id'=>$result->id,'text'=>$result->item_name.' '.$result->item_attribute.' '.$result->item_size.' '.$result->item_price);
            }
        }    
        $response['data'] = $item_data;

        return $this->response->setJSON($response);
    }
    ////////////////////////////////////////////////////////////////

    public function load_item_data()
    {
        
        $request = service('request');
        $postData = $request->getPost();
        $item_data = array();
        $builder = $this->db->table("items_tbl");

        if(isset($postData['query'])){
            
            $builder->select('id,item_name,item_price,item_size,item_attribute,item_type');
            $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
           // $builder->where('item_type = 1 OR item_type = 2 OR item_type = 3');
            $builder->like('item_name',$postData['query'],'both');
            //$builder->limit(100);
            $query = $builder->get();
            $item_result = $query->getResult();
        }else{

            $builder->select('id,item_name,item_price,item_size,item_attribute,item_type');
            $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
            $builder->where('item_type = 1 OR item_type = 2 OR item_type = 3 OR item_type = 4 OR item_type = 8');
            //$builder->limit(100);
            //$builder->where('item_type = 1 OR item_type = 2 OR item_type = 3');
           // $builder->limit(100);
            $query = $builder->get();
            $item_result = $query->getResult();
        }
        
        if(count($item_result) > 0){
            foreach($item_result as $result){
                $item_data[] = array('id'=>$result->id,'text'=>$result->item_name.' '.$result->item_attribute.' '.$result->item_size.' '.$result->item_price);
            }
        }    
        $response['data'] = $item_data;

        return $this->response->setJSON($response);
    }

    public function load_item_data1()
    {
        $postedData = $this->request->getRawInput();
        // print_r($postedData['selected_items_array']);
        $selectedItem = explode(',', $postedData['selected_items_array']);

        foreach ($selectedItem as $sdi) {
            if($sdi == $postedData['item_selected']){
                echo "1";
                return;
            }
        }

        $data = $this->cmodel->items_chargedList1($postedData['item_selected']);
        $item_data = array();
         if(count($data) > 0){

             foreach($data as $dt){
                
                $item_data[] = array("id" => $dt->id,"iprice" => $dt->item_price, "iname" => $dt->item_name, "item_group" => $dt->item_group, "isize" => $dt->item_size, "iattr" => $dt->item_attribute);
            }
         }
        echo json_encode($item_data);
    }

    public function load_item_data2($id)
    {
        $postedData = $this->request->getRawInput();
        // print_r($postedData['selected_items_array']);
        $selectedItem = explode(',', $postedData['selected_items_array']);
        $data['itemId']=$this->cmodel->selectItemId($id);
        $array=$data['itemId'];
        foreach ($selectedItem as $sdi) {
                for ($i=0;$i<sizeof($array);$i++) {
                $itemId=$array[$i]->item_id;
                

            if($sdi == $postedData['item_selected']||$itemId==$postedData['item_selected']){
                echo "1";
                return;
            }
            }
        }

        $data = $this->cmodel->items_chargedList1($postedData['item_selected']);
        $item_data = array();
         if(count($data) > 0){

             foreach($data as $dt){
                
                $item_data[] = array("id" => $dt->id,"iprice" => $dt->item_price, "iname" => $dt->item_name, "isize" => $dt->item_size, "iattr" => $dt->item_attribute);
            }
         }
        echo json_encode($item_data);
    }

public function update_level_item()
        {
            
            $level=$this->request->getPost('level_id');
            $levelItem = $this->request->getPost('id');
            $account = $this->request->getPost('account');
            $this->cmodel->delete_levelId($level);
             foreach ($levelItem as $i) {
                $charged_item = array('item_id' => $i, 'level_id' => $level, 'quantity' => $this->request->getPost('qty'.$i), 'account_receivable' => $account);
                $this->cmodel->edit_charged_items($level,$charged_item);
               

            }

  echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span> Level Charged Items Updated Successfully.</div> ';

         
        }   
    public function saveLevels()
    {
        $levelDta = [
            'level' => 'required',
            'application' => 'required',
        ];
           
        if($this->validate($levelDta)){
            $checkingExist = $this->cmodel->check_ifExist('class_level_tbl', $where = array('level_name' => $this->request->getPost('level'))); 

            if($checkingExist){
                 echo json_encode(array('status' =>'1','statusDesc' => 'Level With <b>Name: '.$checkingExist[0]->level_name.' & ID:'.$checkingExist[0]->id.'</b> Already registerd.'));
            }else{
                $data = [
                    'level_name' => ucwords(strtoupper($this->request->getPost('level'))),
                    'academic_type'=>$this->request->getPost('academic_type'),
                    'government_level_id'=>ucfirst($this->request->getPost('government_level')),
                    'updated_by' => $_SESSION['user_id'],
                    'updated_date' => date('Y/m/d H:i:s')
                ];

                $levelId = $this->cmodel->saveLevel($data);
                 if($levelId != 0){
              
              $installment = $this->cmodel->saveInstallmentData($levelId);
            }
                if($levelId != 0){
                    if(!empty($this->request->getPost('application'))){
                        $data1 =  [
                            'level_id' => $levelId,
                            'item_id' => $this->request->getPost('application'),
                            'quantity' => 1,
                        ];
                        
                        $builder = $this->db->table('class_level_items_tbl')->insert($data1);
                    }

                    $levelItem = $this->request->getPost('id');

                    if(!empty($levelItem)){
                        foreach ($levelItem as $lvl) {

                            $insert_level = array('item_id' => $lvl, 'level_id' => $levelId,'account_receivable' => $this->request->getPost('account'), 'quantity' => $this->request->getPost('qty'.$lvl.''));

                            $this->cmodel->Save_newLevel($insert_level);
                            // echo json_encode($insert_level);
                        }
                    }
                }
                echo json_encode(array('status' =>'0','statusDesc' => 'Level Added Successful'));
            }

        }else{
            echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));
            
        }
        

    } 


    public function manage_Levels()
    {
        $id = $this->request->getVar('ids');
        $data['levels'] = $this->cmodel->manage_levelData($id);
        $data['leveldata'] = $this->cmodel->getting_item_details($id);
        $data['leveldatap'] = $this->cmodel->getting_item_detailsap($id);
         $data['gvmt_level']= $this->cmodel->government_level();
        $data['levelID'] = $this->request->getVar('ids');
      
       echo view('student/forms/manage_level',$data);
        //echo view('student/forms/manageLevel',$data);
    }

    public function getting_level_data()
    {
        $builder = $this->db->table('class_level_items_tbl');
        $builder->select('quantity,item_name,item_attribute,item_size,item_id,class_level_items_tbl.id,level_id');
        $builder->join('items_tbl', 'items_tbl.id = class_level_items_tbl.item_id');
        $builder->where('level_id',$this->request->getGet('level_id'));
        $level_result = $builder->get()->getResult();

        $level_data = array();

        if(count($level_result) > 0){

            $iprice = "";
            foreach ($level_result as $lr)
            {
                $datas = $this->cmodel->get_ChargedItems_list($lr->item_id);
                foreach ($datas as $dts) {
                    $iprice = $dts->item_price;
                }

                $data = array("id" => $lr->id,"item_id" => $lr->item_id, "quantity" => $lr->quantity, "name" => $lr->item_name, "size" => $lr->item_size, "attribute" => $lr->item_attribute, "price" => $iprice);
                array_push($level_data, $data);
            }

            echo json_encode($level_data);
        }
    }

    public function adding_another_items()
    {
        $data = [
            'level_id' => $this->request->getPost('id'),
            'item_id' => $this->request->getPost('item'),
            'quantity' => $this->request->getPost('quantity'),
        ];

        $stm = $this->cmodel->add_items($data);
    }

    public function remove_charged_item($id = null)
    {

        $builder = $this->db->table('class_level_items_tbl');
        $builder->where('id',$id);
        $builder->delete();   
    }

    public function UpdateLevel()
    {
        $data = [
            'id' => $this->request->getPost('id'),
            'level_name' => $this->request->getPost('level'),
            'government_level_id' => $this->request->getPost('glevel'),
            'academic_type' => $this->request->getPost('cperiod'),
            'status' => $this->request->getPost('status'),
            'updated_by' => $_SESSION['user_id'],
            'updated_date' => date('Y/m/d H:i:s')
        ];

        // print_r($data);

        $levelID = $this->cmodel->updating_level($this->request->getPost('id'),$data);

        $dta = [
            
            'item_id' => $this->request->getPost('application')
        ];
        $this->smodel->update_table_details('class_level_items_tbl', $where = array('level_id' => $this->request->getPost('id')),$dta);
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
            <span class="glyphicon glyphicon-ok"></span> Level Updated.</div> ';
    }

    public function remove_classLevel($id = null)
    {
        $this->cmodel->delete_class_level($id);
    }



    // ---------classes and semister(school terms) --------//

    public function add_Semister()
    {
        $term_data = [
            'tname' => 'required'
        ];
           
        if ($this->validate($term_data)){
            $checking = $this->cmodel->check_ifExist('school_terms_tbl', $where = array('term_name' => $this->request->getPost('tname'),'academic_year'=> $this->request->getPost('year'),'type_id'=>$this->request->getPost('academic_type'))); 
            if($checking){
                 echo json_encode(array('status' =>'1','statusDesc' => 'Term Name: <b>'.$checking[0]->term_name.'</b> With <b>ID:'.$checking[0]->id.'</b> Already registerd.'));
            }else{
                $data = [
                    'academic_year' => ucwords($this->request->getPost('academic')),
                    'term_name' => ucwords(strtolower($this->request->getPost('tname'))),
                    'start_date' => ucwords($this->request->getPost('startDate')),
                    'end_date' => ucwords($this->request->getPost('endDate')),
                    'due_date' => ucwords($this->request->getPost('dueDate')),
                    'type_id' => $this->request->getPost('academic_type'),
                    'description' => ucwords(strtolower($this->request->getPost('tdescr'))),
                    'updated_date' => date('Y/m/d H:i:s'),
                    'updated_by' => $_SESSION['user_id']
                ];

                $this->cmodel->saveSemisterData($data);
                 echo json_encode(array('status' =>'0','statusDesc' => 'Semister Added Successful'));

            }

        }else{
            echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));
            
        }
    }

    public function manage_SchoolTerms_Details()
    {
        $id = $this->request->getVar('id');
        $data['terms'] = $this->cmodel->manage_School_terms($id);

        echo view('student/forms/manage_SchoolTerms',$data);
    }
  
   public function view_SchoolTerms_Details()
    {
        $id = $this->request->getVar('id');
        $data['terms'] = $this->cmodel->manage_School_terms($id);

        echo view('student/forms/view_SchoolTerms',$data);
    }
    public function Update_SchoolTerms()
    {
        $data = [
            'id' => $this->request->getPost('id'),
            'academic_year' => $this->request->getPost('academic'),
            'term_name' => $this->request->getPost('tname'),
            'description' => $this->request->getPost('tdescr'),
            'start_date' => $this->request->getPost('startDate'),
            'end_date' => $this->request->getPost('endDate'),
            'due_date' => $this->request->getPost('dueDate'),
            'status' => $this->request->getPost('status'),
            'type_id' => $this->request->getPost('academic_type'),
            'updated_by' => $_SESSION['user_id'],
            'updated_date' => date('Y/m/d H:i:s')
        ];

        $this->cmodel->updating_schoolTerms($this->request->getPost('id'),$data);
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
            <span class="glyphicon glyphicon-ok"></span> Term Updated.</div> ';
    }

    public function delete_schoolTerms($id = null)
    {

        $this->cmodel->delete_TermsDtls($id);

    }

    public function Creating_newClass()
    {
        $classValidation = [
            'cname' => 'required',
            'classlvl' => 'required',
        ];
           
        if ($this->validate($classValidation)){
            $class_exist = $this->cmodel->check_ifExist('classes_tbl', $where = array('class_name' => $this->request->getPost('cname')));
            if($class_exist){
                 echo json_encode(array('status' =>'1','statusDesc' => 'Class Name: <b>'.$class_exist[0]->class_name.'</b> With the <b>ID:'.$class_exist[0]->id.'</b> Already Exists.'));
            }else{
                $class_name=ucwords(strtolower($this->request->getPost('cname')));
                $data = [
                    'class_name' => ucwords(strtolower($this->request->getPost('cname'))),
                    'class_level' => $this->request->getPost('classlvl'),
                    'updated_by' =>$this->request->getPost('header_id'),
                    'updated_date' => date('Y/m/d H:i:s')
                ];

                $classID = $this->cmodel->saveNew_Class($data);

                if(!($classID == false)){
                    
                    //////////////////////adding hostel fee////////
                        //   $data1 =  [
                        //     'class_id' => $classID,
                        //     'item_id' => $this->request->getPost('hostelFee'),
                        //     'quantity' => 1,
                        //     'account_receivable' => 6,
                        // ];
                        
                        // $builder = $this->db->table('class_charged_items_tbl')->insert($data1);
                    //////////////////////end of adding hostel fee////////
                    $sdata = json_decode($this->request->getPost('stream'));
                   // $idata = json_decode($this->request->getPost('installment'));

                    // print_r($sdata);
                    if(!empty($data)){

                        foreach ((array)$sdata as $s) {
                            $streamdata = array('class_id' => $classID, 'stream_name' => $s->name, 'stream_capacity' => $s->capacity, 'created_by' => $this->request->getPost('header_id'), 'created_date' => date('Y/m/d H:i:s'));

                            $stream = $this->cmodel->saveStreamData($streamdata);
                        }
                    }

                    $clss = $this->request->getPost('id');

                    if(!empty($clss)){
                        foreach ($clss as $c) {

                            $itemData = array('item_id' => $c, 'class_id' => $classID, 'account_receivable' => $this->request->getPost('account') ,'quantity' => $this->request->getPost('qtys'.$c.''));

                            $this->cmodel->Save_Classcharged_items($itemData);
                        }
                    }
                }
                
                echo json_encode(array('status' =>'0','statusDesc' => 'New Class Created Successful'));
            }

            if(!empty($classID)){
              
              //$installment = $this->cmodel->saveInstallmentData($classID);
            }else{
                 echo json_encode(array('status' =>'1','statusDesc' => $this->validation->listErrors()));

                   // $installment = $this->cmodel->saveInstallmentData($installdata);
            }
             
        }
    }

    public function Remove_class_details($id = null)
    {
        $this->cmodel->deleting_ClassDetails($id);
    }

    public function manage_class_details()
    {
        $id = $this->request->getVar('id');
        $data['classes'] = $this->cmodel->getting_allClass_details($id);
        
        $data['classLevl'] = $this->cmodel->get_all_classLevel();
        $data['classID'] = $this->request->getVar('id');


        echo view('student/forms/manage_classes',$data);
    }

    public function adding_stream_data()
    {
        $data = [
            'stream_name' => ucwords(strtolower($this->request->getPost('name'))),
            'stream_capacity' => $this->request->getPost('capacity'),
            'class_id' => $this->request->getPost('id'),
            'created_by' => $_SESSION['user_id'], 
            'created_date' => date('Y/m/d H:i:s')
        ];

        $stm = $this->cmodel->add_Steam($data);
    }
        public function adding_station_data()
    {
        $data = [
            'session_name' => ucwords(strtolower($this->request->getPost('sess_name'))),
            'session_time' => $this->request->getPost('sess_time'),
            'station_id' => $this->request->getPost('id'),
            'route_id' => $this->request->getPost('routeid'),
             'status'=>1,
            'created_by' => $_SESSION['user_id'], 
            'created_date' => date('Y/m/d H:i:s')
        ];

        $stm = $this->cmodel->add_Stationsession($data);
    }
    
    public function adding_installment_data($id)
    {
        
        $exit = $this->cmodel->check_inst($id,$this->request->getPost('installname'));
        if($exit>0){
            echo '1';
        }else{
        $data = [
            'istallment_name' => $this->request->getPost('installname'),
            'amount' => $this->request->getPost('amount'),
            'tbl_id' => $this->request->getPost('id'),
            'installment_type' =>1,
            
        ];

        $inst = $this->cmodel->add_installment($data);
    }
}
    public function adding_temporary_data()
    {
        $exit=$this->cmodel->check_temp($this->request->getPost('installname'));
        if($exit>0){
          echo "1";  
        }else{
        $data = [
            'istallment_name' => $this->request->getPost('installname'),
            'amount' => $this->request->getPost('amount'),
            'tbl_id' => $this->request->getPost('id'),
            'installment_type' =>1,
            
        ];

        $inst = $this->cmodel->add_temporary($data);
    }
    }
    public function getting_stream_data()
    {
        $builder = $this->db->table('streams_tbl');
        $builder->select('*');
        $builder->where('class_id',$this->request->getGet('class_id'));
        $stream_result = $builder->get()->getResult();

        $stream_dta = array();

        if(count($stream_result) > 0){
            foreach ($stream_result as $sr)
            {
                $data = array("id" => $sr->id,"name" => $sr->stream_name, "capacity" => $sr->stream_capacity, "classid" => $sr->class_id);
                array_push($stream_dta, $data);
            }

            echo json_encode($stream_dta);
        }
    }
public function getting_station_data()
    {
        $builder = $this->db->table('station_session_tbl');
        $builder->select('*');
        $builder->where('station_id',$this->request->getGet('station_id'));
        //$builder->where('status',1);
        $stream_result = $builder->get()->getResult();

        $stream_dta = array();
            //  print_r($stream_result);
        if(count($stream_result) > 0){
            foreach ($stream_result as $sr)
            {

        $builder = $this->db->table('route_tbl');
        $builder->select('*');
        $builder->where('id',$sr->route_id);
        $builder->where('status',1);
        $result = $builder->get()->getResult();
             //********session route*********//
            //  print_r($result);
            if(count($result)==0){
                continue;
            }
        if($result[0]->route_session==1){
                                    $sess='Morning';
                                }
                                elseif($result[0]->route_session==2){
                                    $sess='Afternoon';
                                }
                                elseif($result[0]->route_session==3){
                                    $sess='Evening';
                                }
                $data = array("id" => $sr->id,"session_name" => $sr->session_name, "time" => $sr->session_time, "route_name" => $result[0]->route_name.'('. $sess.')');
                array_push($stream_dta, $data);
            }

            echo json_encode($stream_dta);
        }
    }
    public function getting_installments()
    {
        $builder = $this->db->table('installments_tbl ');
        $builder->select('*');
        $builder->where('tbl_id',$this->request->getGet('class_id'));
        $builder->where('installment_type',1);
        $ments_result = $builder->get()->getResult();
        
        $builder = $this->db->table('class_charged_items_tbl');
        $builder->select('class_charged_items_tbl.item_id,class_charged_items_tbl.quantity,
        price_tbl.item_price');
        $builder->join('price_tbl', 'price_tbl.item_id = class_charged_items_tbl.item_id');
        $builder->where('class_charged_items_tbl.class_id',$this->request->getGet('class_id'));
        $price_result = $builder->get()->getResult();

        $ments_dta = array();
        if(count($price_result) > 0){
            $total=0;
            foreach ($price_result as $pr)
            {
                $qty=$pr->quantity;
                $price=$pr->item_price;
                $tprice=$qty*$price;
                $total=$total+$tprice;
            }
            }
        if(count($ments_result) > 0){
            
            foreach ($ments_result as $sr)
            {
    $builder = $this->db->table('school_terms_tbl');
    $builder->select('*');
    $builder->where('id',$sr->istallment_name);
    $result = $builder->get()->getResult();

                $data = array("id" => $sr->id,"installname" => $result[0]->term_name, "amount" => $sr->amount,
                "duedate" => $result[0]->end_date, "classid" => $sr->tbl_id,"tprice"=>$total);
                array_push($ments_dta, $data);
            }

            echo json_encode($ments_dta);
        }
    }
    
    public function getting_tempo()
    {
        $builder = $this->db->table('installments_tbl ');
        $builder->select('*');
        $builder->where('tbl_id',$this->request->getGet('class_id'));
        $builder->where('installment_type',1);
        $ments_result = $builder->get()->getResult();
        
        /*$builder = $this->db->table('class_charged_items_tbl');
        $builder->select('class_charged_items_tbl.item_id,class_charged_items_tbl.quantity,
        price_tbl.item_price');
        $builder->join('price_tbl', 'price_tbl.item_id = class_charged_items_tbl.item_id');
        $builder->where('class_charged_items_tbl.class_id',$this->request->getGet('class_id'));
        $price_result = $builder->get()->getResult();
   */
        $ments_dta = array();
       
        if(count($ments_result) > 0){
            $total=0;
            foreach ($ments_result as $sr)
            {
    $builder = $this->db->table('school_terms_tbl');
    $builder->select('*');
    $builder->where('id',$sr->istallment_name);
    $result = $builder->get()->getResult();

                $amount=$sr->amount;
                $total=$total+$amount;
                $data = array("id" => $sr->id,"installname" => $result[0]->term_name, "amount" => $sr->amount,
                "duedate" => $result[0]->end_date, "classid" => $sr->tbl_id,"tamount"=>$total);
                array_push($ments_dta, $data);
            }

            echo json_encode($ments_dta);
        }
    }
    public function delete_stream_data($id = null)
    {
         $build = $this->db->table('admission_tbl');
    $build->select('*');
    $build->where('stream_id',$id);
    $result = $build->get()->getResult();
    if(count($result)==0){
        $builder = $this->db->table('streams_tbl');
        $builder->where('id',$id);
        $builder->delete();
    }else{
        echo "Already used";
    }
    } 
     public function delete_station_data($id = null)
    {
        $builder = $this->db->table('station_session_tbl');
        $builder->where('id',$id);
        $builder->delete();
    } 

    public function delete_installment_data($id)
    {
        $builder = $this->db->table('installments_tbl');
        $builder->where('id',$id);
        $builder->delete();
    }

    public function update_class_details()
    {
        $data = [
            'id' => $this->request->getPost('id'),
            'class_name' => $this->request->getPost('name'),
            'class_level' => $this->request->getPost('level'),
            'status' => $this->request->getPost('status'),
            'updated_by' => $_SESSION['user_id'],
            'updated_date' => date('Y/m/d H:i:s')
        ];

        $this->cmodel->updating_class_data($this->request->getPost('id'),$data);
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
            <span class="glyphicon glyphicon-ok"></span> Class Updated.</div> ';
    }

    public function update_session_details()
    {
        $data = [
            'id' => $this->request->getPost('id'),
            'sname' => $this->request->getPost('sname'),
            'status' => $this->request->getPost('status'),
            'created_by' => $_SESSION['user_id'],
            'created_date' => date('Y/m/d H:i:s')
        ];

        $this->cmodel->updating_session_data($this->request->getPost('id'),$data);
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
            <span class="glyphicon glyphicon-ok"></span> station Updated.</div> ';
    }
    public function fetch_classLevel_ItemData()
    {
        $id = $this->request->getVar('levelID');
        $item_group = $this->request->getVar('admfor');

        $builder = $this->db->table('class_level_items_tbl');
        $builder->select('quantity,item_name,item_attribute,item_size,item_group,item_id,class_level_items_tbl.id,level_id,account_receivable');
        $builder->join('items_tbl', 'items_tbl.id = class_level_items_tbl.item_id');
        if($item_group==0){
            $builder->where('items_tbl.item_group',0); 
        }
        $builder->where('item_group!=1');
        $builder->where('item_group!=3');
        $builder->where('item_group!=4');
       $builder->where('level_id',$id);
        $levelresult = $builder->get()->getResult();

        // print_r($levelresult);
        $levelData = array();

        if(count($levelresult) > 0){
            $iprice = "";
            foreach ($levelresult as $l) {
                $data = $this->cmodel->get_ChargedItems_list($l->item_id);
                foreach ($data as $d) {
                    $iprice = $d->item_price;
                }

                $data1 = array("id" => $l->id,"item_id" => $l->item_id, "quantity" => $l->quantity, "name" => $l->item_name, "size" => $l->item_size, "attribute" => $l->item_attribute, "price" => $iprice, "account" => $l->account_receivable);
                array_push($levelData,$data1);
            }

            echo json_encode($levelData);
        }
    }

public function fetch_charged_item(){
             $id = $this->request->getVar('itemid');

        $builder = $this->db->table('items_tbl');
            $builder->select('id,item_name,item_price,item_size,item_attribute,item_type,item_group');
            $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
            $builder->where('id',$id);
            $query = $builder->get();
            $item_result = $query->getResult();

          $levelData = array();

        if(count($item_result) > 0){
            $iprice = "";
            foreach ($item_result as $l) {
               
          $data1 = array("id" => $l->id,"item_id" => $l->id, "name" => $l->item_name, "size" => $l->item_size, "attribute" => $l->item_attribute, "price" => $l->item_price,"item_group" => $l->item_group);
                array_push($levelData,$data1);
            }

            echo json_encode($levelData);
        }  
}
  
   public function getting_class_chargeddItems()
    {
       $item_group=$this->request->getGet('item_group');
        $builder = $this->db->table('class_charged_items_tbl');
        $builder->select('quantity,account_receivable,item_name,item_attribute,item_size,item_group,item_id,class_charged_items_tbl.id,class_id,group_name');
        $builder->join('items_tbl', 'items_tbl.id = class_charged_items_tbl.item_id');
         $builder->join('item_groups_types_tbl', 'item_groups_types_tbl.group_id = items_tbl.item_group');
        // $builder->where('items_tbl.id = class_charged_items_tbl.account_receivable');
        if($item_group!=11){
        $builder->where('item_group',$item_group);
        }
        $builder->where('class_id',$this->request->getGet('class_id'));
        $class_result = $builder->get()->getResult();

        $class_data = array();

        if(count($class_result) > 0){

            $iprice = "";
            foreach ($class_result as $cr)
            {
                $datas = $this->cmodel->get_ChargedItems_list($cr->item_id);
                foreach ($datas as $dts) {
                    $iprice = $dts->item_price;
                }
                
                 $groups = $this->smodel->gettable_data('item_groups_types_tbl', $where = array('group_id'=> $cr->item_group));


                 $data = array("id" => $cr->id,"item_id" => $cr->item_id, "quantity" => $cr->quantity, "name" => $cr->item_name, "size" => $cr->item_size, "attribute" => $cr->item_attribute, "item_group" =>$groups[0]->group_name, "price" => $iprice, "account" => $cr->account_receivable, "item_group_name" => $cr->group_name);
               
                array_push($class_data, $data);
            }

            echo json_encode($class_data);
        }else{
            echo "1";
        }
    }

    public function get_class_chargeddItems()
    {
        $item_group=$this->request->getGet('admfor');
        $builder = $this->db->table('class_charged_items_tbl');
        $builder->select('quantity,account_receivable,item_name,item_attribute,item_size,item_group,item_id,class_charged_items_tbl.id,class_id');
        $builder->join('items_tbl', 'items_tbl.id = class_charged_items_tbl.item_id');
        // $builder->where('items_tbl.id = class_charged_items_tbl.account_receivable');
        if($item_group==0){
        $builder->where('item_group',$item_group);
        }
          $builder->where('item_group!=3');
          $builder->where('item_group!=4');
          $builder->where('item_group!=1');
        $builder->where('class_id',$this->request->getGet('class_id'));
        $class_result = $builder->get()->getResult();

        $class_data = array();

        if(count($class_result) > 0){

            $iprice = "";
            foreach ($class_result as $cr)
            {
                $datas = $this->cmodel->get_ChargedItems_list($cr->item_id);
                foreach ($datas as $dts) {
                    $iprice = $dts->item_price;
                }

                $data = array("id" => $cr->id,"item_id" => $cr->item_id, "quantity" => $cr->quantity, "name" => $cr->item_name, "size" => $cr->item_size, "attribute" => $cr->item_attribute, "item_group" => $cr->item_group, "price" => $iprice, "account" => $cr->account_receivable);
                array_push($class_data, $data);
            }

            echo json_encode($class_data);
        }else{
            echo "1";
        }
    }

 public function getting_level_chargeddItems()
    {
        $builder = $this->db->table('class_level_items_tbl');
        $builder->select('quantity,account_receivable,item_name,item_attribute,item_size,item_group,item_id,class_level_items_tbl.id,level_id');
        $builder->join('items_tbl', 'items_tbl.id = class_level_items_tbl.item_id');
        // $builder->where('items_tbl.id = class_charged_items_tbl.account_receivable');
        $builder->where('item_group != 1');
        $builder->where('level_id',$this->request->getGet('level_id'));
        $level_result = $builder->get()->getResult();
       
       // print_r($level_result);

        $level_data = array();

        if(count($level_result) > 0){

            $iprice = "";
            foreach ($level_result as $cr)
            {
                $datas = $this->cmodel->get_ChargedItems_list($cr->item_id);
                foreach ($datas as $dts) {
                    $iprice = $dts->item_price;
                }
                
                 $groups = $this->smodel->gettable_data('item_groups_types_tbl', $where = array('group_id'=> $cr->item_group));

                $data = array("id" => $cr->id,"item_id" => $cr->item_id, "quantity" => $cr->quantity, "name" => $cr->item_name, "size" => $cr->item_size, "attribute" => $cr->item_attribute, "item_group" => $groups[0]->group_name, "price" => $iprice, "account" => $cr->account_receivable);
                array_push($level_data, $data);
            }

            echo json_encode($level_data);
        }
    }
    public function getting_level_Items()
    {
         $item_group=$this->request->getGet('item_group');
        $builder = $this->db->table('class_level_items_tbl');
        $builder->select('quantity,account_receivable,item_name,item_attribute,item_size,item_group,item_id,class_level_items_tbl.id,level_id');
        $builder->join('items_tbl', 'items_tbl.id = class_level_items_tbl.item_id');
        // $builder->where('items_tbl.id = class_charged_items_tbl.account_receivable');
        if($item_group!=11){
        $builder->where('item_group',$item_group);
        }
        $builder->where('item_group != 1');
        $builder->where('level_id',$this->request->getGet('level_id'));
        $level_result = $builder->get()->getResult();

        $level_data = array();

        if(count($level_result) > 0){

            $iprice = "";
            foreach ($level_result as $cr)
            {
                $datas = $this->cmodel->get_ChargedItems_list($cr->item_id);
                foreach ($datas as $dts) {
                    $iprice = $dts->item_price;
                }
              $groups = $this->smodel->gettable_data('item_groups_types_tbl', $where = array('group_id'=> $cr->item_group));
              
                $data = array("id" => $cr->id,"item_id" => $cr->item_id, "quantity" => $cr->quantity, "name" => $cr->item_name, "size" => $cr->item_size, "attribute" => $cr->item_attribute, "item_group" => $groups[0]->group_name, "price" => $iprice, "account" => $cr->account_receivable);
                array_push($level_data, $data);
            }

            echo json_encode($level_data);
        }else{
            echo "1";
        }
    }

    public function add_Class_chargedItems()
    {
        $data = [
            'class_id' => $this->request->getPost('id'),
            'item_id' => $this->request->getPost('item'),
            'quantity' => $this->request->getPost('quantity'),
            'account_receivable' => $this->request->getPost('account')
        ];

        $this->cmodel->insert_new_charged_item($data);

    }
      public function add_station_chargedItems()
    {
        $data = [
            'station_id' => $this->request->getPost('id'),
            'item_id' => $this->request->getPost('item'),
            'quantity' => $this->request->getPost('quantity'),
             'account_receivable' => $this->request->getPost('account')
        ];

        $this->cmodel->insert_new_charged_itemdata($data);

    }

     public function add_level_chargedItems()
    {
        $data = [
            'level_id' => $this->request->getPost('id'),
            'item_id' => $this->request->getPost('item'),
            'quantity' => $this->request->getPost('quantity'),
            'account_receivable' => $this->request->getPost('account')
        ];

        $this->cmodel->insert_new_level_item($data);

    }

    public function remove_Class_chargedItems($id = null)
    {

        $builder = $this->db->table('class_charged_items_tbl');
        $builder->where('id',$id);
        $builder->delete();   
    }
       public function remove_station_chargedItems($id = null)
    {

        $builder = $this->db->table('station_charged_items_tbl');
        $builder->where('id',$id);
        $builder->delete();   
    }
     public function remove_temp($id)
    {

        $builder = $this->db->table('installments_tbl');
        $builder->where('id',$id);
        $builder->delete();   
    }
    public function deletelevelItem($id)
    {         
        $this->cmodel->deletelevelItem($id);
    }
    public function adding_installment_data3($id)
    {
       $exit = $this->cmodel->check_inst($id,$this->request->getPost('installname'));
        if($exit>0){
            echo '1';
        }else{
        $data = [
            'istallment_name' => $this->request->getPost('installname'),
            'amount' => $this->request->getPost('amount'),
            'tbl_id' => $this->request->getPost('id'),
            'installment_type' =>3,
            
        ];

        $inst = $this->cmodel->add_installment($data);
    }}
public function getting_installments3()
    {
        $builder = $this->db->table('installments_tbl ');
        $builder->select('*');
        $builder->where('tbl_id',$this->request->getGet('level_id'));
        $builder->where('installment_type',3);
        $ments_result = $builder->get()->getResult();
        
        $builder = $this->db->table('class_level_items_tbl');
        $builder->select('class_level_items_tbl.item_id,class_level_items_tbl.quantity,
        price_tbl.item_price');
        $builder->join('price_tbl', 'price_tbl.item_id = class_level_items_tbl.item_id');
        $builder->join('items_tbl', 'items_tbl.id = class_level_items_tbl.item_id');
        $builder->where('class_level_items_tbl.level_id',$this->request->getGet('level_id'));
        $builder->where('items_tbl.item_group',0);
        $price_result = $builder->get()->getResult();

        $ments_dta = array();
        if(count($price_result) > 0){
            $total=0;
            foreach ($price_result as $pr)
            {
                $qty=$pr->quantity;
                $price=$pr->item_price;
                $tprice=$qty*$price;
                $total=$total+$tprice;
            }
            }
        if(count($ments_result) > 0){
            
            foreach ($ments_result as $sr)
            {
         $builder = $this->db->table('school_terms_tbl');
    $builder->select('*');
    $builder->where('id',$sr->istallment_name);
    $result = $builder->get()->getResult();

                $data = array("id" => $sr->id,"installname" => $result[0]->term_name, "amount" => $sr->amount,
                 "classid" => $sr->tbl_id,"tprice"=>$total);
                array_push($ments_dta, $data);
            }

            echo json_encode($ments_dta);
        }
    }
    public function adding_temporary_data3()
    {
         $exit=$this->cmodel->check_temp3($this->request->getPost('installname'));
        if($exit>0){
          echo "1";  
        }else{
        $data = [
            'istallment_name' => $this->request->getPost('installname'),
            'amount' => $this->request->getPost('amount'),
            'tbl_id' => $this->request->getPost('id'),
            'installment_type' =>3,
            
        ];

        $inst = $this->cmodel->add_temporary($data);
    }}
    public function getting_tempo3()
    {
        $builder = $this->db->table('installments_tbl ');
        $builder->select('*');
        $builder->where('tbl_id',$this->request->getGet('level_id'));
        $builder->where('installment_type',3);
        $ments_result = $builder->get()->getResult();
        
        $builder = $this->db->table('class_level_items_tbl');
        $builder->select('class_level_items_tbl.item_id,class_level_items_tbl.quantity,
        price_tbl.item_price');
        $builder->join('price_tbl', 'price_tbl.item_id = class_level_items_tbl.item_id');
        $builder->where('class_level_items_tbl.level_id',$this->request->getGet('level_id'));
        $price_result = $builder->get()->getResult();

        $ments_dta = array();
        if(count($price_result) > 0){
            $total=0;
            foreach ($price_result as $pr)
            {
                $qty=$pr->quantity;
                $price=$pr->item_price;
                $tprice=$qty*$price;
                $total=$total+$tprice;
            }
            }
       
        if(count($ments_result) > 0){
            $total=0;
            foreach ($ments_result as $sr)
            {
                
                $amount=$sr->amount;

                $builder = $this->db->table('school_terms_tbl');
                $builder->select('*');
                $builder->where('id',$sr->istallment_name);
                $result = $builder->get()->getResult();
                            
                $total=$total+$amount;
                $data = array("id" => $sr->id,"installname" => $result[0]->term_name, "amount" => $sr->amount,
                "duedate" => $result[0]->end_date, "classid" ,"tamount"=>$total);
                array_push($ments_dta, $data);
            }

            echo json_encode($ments_dta);
        }
    }
    public function class_view(){
        $id= $this->request->getVar('cid');
        
        $data=array(
           
            'updated'=>$this->cmodel->returnAlldataOfClass($id),
            'item'=>$this->cmodel->ClassItems($id),
        );
        echo view('student/forms/class_view',$data);
    }
    public function classLevel_view(){
        $id= $this->request->getVar('lid');
        
        $data=array(
           
            'updated'=>$this->cmodel->returnAlldataOfLevel($id),
            'item'=>$this->cmodel->LevelItems($id),
        );
        echo view('student/forms/classLevel_view',$data);
    }
     public function updateAccount()
    {
        
        $this->cmodel->update_account_receivable($this->request->getPost('cid'),$this->request->getPost('acid'));
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
            <span class="glyphicon glyphicon-ok"></span> Account Updated Successful.</div> ';
    }

     public function updateAccountstation()
    {
        
        $this->cmodel->update_account_receivablestation($this->request->getPost('id'),$this->request->getPost('acid'));
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
            <span class="glyphicon glyphicon-ok"></span> Account Updated Successful.</div> ';
    }
      public function updateAccountLevel()
    {
        
    $checkAvailable = $this->smodel->gettable_data('class_level_items_tbl', $where = array('level_id'=> $this->request->getPost('lid')));
        if(count($checkAvailable)>0){
        $this->cmodel->update_account_receivableLevel($this->request->getPost('lid'),$this->request->getPost('acid'));
        }else{
         $data=[
            'level_id'=>$this->request->getPost('lid'),
            'item_id'=>0,
            'account_receivable'=>$this->request->getPost('acid')
         ];

          $saveitem = $this->smodel->SaveData_n_get_id('class_level_items_tbl',$data); 
        }
        
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
            <span class="glyphicon glyphicon-ok"></span> Account Updated Successful.</div> ';
    }
     public function get_station_chargeddItems()
    {
        $trip=$this->request->getGet('trip');
        if($trip==1){
            $group=5;
        }else if($trip==2){
            $group=6;
        }
        $month=$this->request->getGet('month');
        $pick=$this->request->getGet('station_pick');
        $drop=$this->request->getGet('station_drop');
        $builder = $this->db->table('station_charged_items_tbl');
        $builder->select('quantity,account_receivable,item_name,item_attribute,item_price,item_size,item_group,station_charged_items_tbl.item_id,station_charged_items_tbl.id,station_id');
        $builder->join('items_tbl', 'items_tbl.id = station_charged_items_tbl.item_id');
        $builder->join('price_tbl', 'price_tbl.item_id = station_charged_items_tbl.item_id');
         if((empty($pick) && !empty($drop)) || (!empty($pick) && empty($drop))){
            if(empty($pick) && !empty($drop)){
        $builder->where('items_tbl.item_group',$group);
         $builder->where('station_id',$this->request->getGet('station_drop'));  
            }else{
        $builder->where('items_tbl.item_group',$group);
        $builder->where('station_id',$this->request->getGet('station_pick'));  
            }
         }else{
          $builder->where('items_tbl.item_group',$group);
          $builder->where('station_id',$this->request->getGet('station_drop'));
         }
           
        $result = $builder->get()->getResult();

        $sdata = array();

        if(count($result) > 0){

            $iprice = "";
            foreach ($result as $cr)
            {
                // $datas = $this->cmodel->get_ChargedItems_list($cr->item_id);
                // foreach ($datas as $dts) {
                //     $iprice = $dts->item_price;
                // }

                $data = array("id" => $cr->id,"item_id" => $cr->item_id, "quantity" => $month, "name" => $cr->item_name, "size" => $cr->item_size, "attribute" => $cr->item_attribute, "item_group" => $cr->item_group, "price" => $cr->item_price, "account" => $cr->account_receivable);
                array_push($sdata, $data);
            }

            echo json_encode($sdata);
        }else{
            echo "1";
        }
    }
    function append_date(){
      $start=$this->request->getGet('start');  
      $month=$this->request->getGet('month'); 
      $tdays=$month*30;
      $effectiveDate = date('Y-m-d', strtotime("+".$tdays." days", strtotime($start)));  
     $sdata = array();
     $data = array("end_date" => $effectiveDate);
                array_push($sdata, $data);
                echo json_encode($sdata);
    }
      // public function GetGovernmentLevels(){
      //  $data= $this->cmodel->ClassItems();
      //        }
}
?>