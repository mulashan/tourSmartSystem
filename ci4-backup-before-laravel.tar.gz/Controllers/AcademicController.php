<?php 
// By chanangwa E,
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UsersModel;
use App\Models\AcademicModel;
    use App\Models\AdmissionModel;
use App\Models\LoginModel;
use App\Models\StudentModel;
class AcademicController extends BaseController{
        public $amodel;
            public $usermodel;
    public $AcademicModel;  
    public function __construct(){
        $dbname=session()->get('db_name');
        $this->AcademicModel = new AcademicModel();
         $this->studentModel = new StudentModel();
          $this->amodel = new AdmissionModel();
        
        $this->db=\Config\Database::connect($dbname);

    }
    function get_stream_list(){
      
            $clvl = $this->amodel->get_student_details('streams_tbl', $where = array('class_id' => $this->request->getPost('clvl'),'status' => 1));
        
    
         $classlist = array();
         if(count($clvl) > 0){
             foreach($clvl as $c){
                $streamdta = $this->amodel->get_student_details('streams_tbl', $where = array('class_id' => $this->request->getPost('clvl'),'status' => 1));
                
                $classlist[] = array("id" => $c->id, "sname" => $c->stream_name);
         }
        }
        echo json_encode($classlist);  
    }
    function view_exams(){
         $AcademicModel = new AcademicModel();
        $data['exams']=$this->AcademicModel->GetAllExams();
        return view('templates/header')
        .view('academic/exam_view',$data)
        .view('templates/footer');
    } 

public function saveExamination(){
 $ExamsValidation=( [
        'examname' =>[
        'label'=>'examname',
        'rules'=>'required',
        'errors'=>[
        'required'=>'Enter Examination '
        ],
        ]
           
        
    ]
    
    );
       if($this->validate($ExamsValidation)){
        $AcademicModel = new AcademicModel();
        $data = [
            'exam_name' => ucfirst($this->request->getPost('examname')),
            'status' => 1,
            'created_by' => session()->get('user_id'),
            'create_date' =>Date('Y-m-d H:i:s')
        ];     
         $AcademicModel->save_exam_record($data);
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
                <span class="glyphicon glyphicon-ok"></span> New Exam Added Successfully.</div> ';
            }
    
            else{
                
                echo '<div class="alert alert-danger alert-dismissible" role="alert" style="width:60%">'.$this->validation->listErrors();'</div>';
            }
            
    }
  
public function remove_exam(){
      $id =$this->request->uri->getSegment(2);
       if($this->AcademicModel->remove_examination($id)){
        $this->session ->setFlashdata('msg','Removed Successfully');
       }else{
         $this->session ->setFlashdata('error','Not Removed Successfully');  
       }
     return redirect()->to( base_url().'/examination');      
    }

    // =================edit=============================
/*================handle update==============*/
public function update_exam() {
    $AcademicModel = new AcademicModel();
    $data = [
        'exam_name' => $this->request->getPost('exam_name'),
        'status'    => $this->request->getPost('status'),
            'created_by' => session()->get('user_id'),
            'create_date' =>Date('Y-m-d H:i:s')
          ];
    $examID = $this->request->getPost('exam_id');
     if($this->AcademicModel->update_examination($examID, $data)){
        $this->session ->setFlashdata('msg','Examination updated Successfully');
        return redirect()->to('/examination');
         return "Exam updated successfully!";
    } else {
    $this->session ->setFlashdata('msg','Examination update failed');
        return redirect()->to('/examination');
    }
}


 // ==============Examination Field End==================
 // ==============Subect Field Start==================
        function view_subject(){
         $AcademicModel = new AcademicModel();
        $data['subjects']=$this->AcademicModel->GetAllSubjects();
        return view('templates/header')
        .view('academic/subjects_view',$data)
        .view('templates/footer');
    }

public function save_Subject(){
 $SubjectValidation=( [
        'subjectname' =>[
        'label'=>'subjectname',
        'rules'=>'required',
        'errors'=>[
        'required'=>'Subject Can Not Be Empty'
        ]],
        'selection' =>[
        'label'=>'selection',
        'rules'=>'required',
        'errors'=>[
        'required'=>'Selection Can Not Be Empty '
        ],
        ],
  
        
        
    ]
    
    );
 //$subjectExist=$this->AcademicModel->($username);
       if($this->validate($SubjectValidation)){
        $AcademicModel = new AcademicModel();
        $data = [
            'subject_name' => ucfirst($this->request->getPost('subjectname')),
            'selection' => ucfirst($this->request->getPost('selection')),
            'status' => 1,
            'created_by' => session()->get('user_id'),
            'create_date' =>Date('Y-m-d H:i:s')
        ];     
         $AcademicModel->save_subject_record($data);
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
                <span class="glyphicon glyphicon-ok"></span> New Subject Added Successfully.</div> ';
            }
    
            else{
                
                echo '<div class="alert alert-danger alert-dismissible" role="alert" style="width:60%">'.$this->validation->listErrors();'</div>';
            }
            
    }
     // ===================Update Subject========================
    public function update_Subject() {
    $AcademicModel = new AcademicModel();
      $data = [
            'subject_name' =>ucfirst($this->request->getPost('subjectname')),
            'selection' => ucfirst($this->request->getPost('selection')),
            'status' => ucfirst($this->request->getPost('subjectstatus')),
                'created_by' => session()->get('user_id'),
            'create_date' =>Date('Y-m-d H:i:s')
        ]; 
    $subjectID = $this->request->getPost('subject_id');
     if($this->AcademicModel->edit_Subject($subjectID, $data)){
        $this->session ->setFlashdata('msg','Subject updated Successfully');
        return redirect()->to('/subject');
         return "Subject updated successfully!";
    } else {
    $this->session ->setFlashdata('msg','Subject update failed');
        return redirect()->to('/subject');
    }
}
// ========================delete subject============
public function remove_subject(){
      $id =$this->request->uri->getSegment(2);
       if($this->AcademicModel->delete_subject($id)){
        $this->session ->setFlashdata('msg','Removed Successfully');
       }else{
         $this->session ->setFlashdata('error','Not Removed Successfully');  
       }
     return redirect()->to( base_url().'/subject');      
    }
// ===========================subjects end here==================
//=========================Characters start here========================
                //====fetch characters====
        function view_charcter(){
         $usermodel = new AcademicModel();
      $data['characters']=$this->AcademicModel->GetAllcharacter();
        return view('templates/header')
        .view('academic/character_view',$data)
        .view('templates/footer');
    }

public function save_character(){
 $CharacterValidation=( [
        'charactername' =>[
        'label'=>'charactername',
        'rules'=>'required',
        'errors'=>[
        'required'=>'Character Name Can Not Be Empty'
        ]],
        'charactercode' =>[
        'label'=>'charactercode',
        'rules'=>'required',
        'errors'=>[
        'required'=>'Code Can Not Be Empty '
        ],
        ],   
        
    ]
    
    );
       if($this->validate($CharacterValidation)){
        $AcademicModel = new AcademicModel();
        $data = [
            'character_name' => ucfirst($this->request->getPost('charactername')),
            'character_code' => ucfirst($this->request->getPost('charactercode')),
            'created_by' => session()->get('user_id'),
            'character_status' =>1,
            'create_date' =>Date('Y-m-d H:i:s')
        ];

      $AcademicModel->save_character_record($data);
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
                <span class="glyphicon glyphicon-ok"></span> New Character Added Successfully.</div> ';
            }
    
            else{
                
                echo '<div class="alert alert-danger alert-dismissible" role="alert" style="width:60%">'.$this->validation->listErrors();'</div>';
            }
            
    }
     // ===================Update Subject========================
    public function update_character() {
    $AcademicModel = new AcademicModel();
      $data = [
         'character_name' => ucfirst($this->request->getPost('charactername')),
        'character_code' => ucfirst($this->request->getPost('charactercode')),
         'character_status' => ucfirst($this->request->getPost('characterstatus')),
          'created_by' => session()->get('user_id'),
            'create_date' =>Date('Y-m-d H:i:s')
        ]; 
    $characterID = $this->request->getPost('character_id');
     if($this->AcademicModel->edit_character($characterID, $data)){
        $this->session ->setFlashdata('msg','Character updated Successfully');
        return redirect()->to('/character');
         return "Character updated successfully!";
    } else {
    $this->session ->setFlashdata('msg','Character update failed');
        return redirect()->to('/character');
    }
}
// ========================delete subject============
public function remove_character(){
      $id =$this->request->uri->getSegment(2);
       if($this->AcademicModel->delete_character($id)){
        $this->session ->setFlashdata('msg','Removed Successfully');
       }else{
         $this->session ->setFlashdata('error','Not Removed Successfully');  
       }
     return redirect()->to( base_url().'/character');      
    }
    // ===========================Character end here==================
//=========================Comb start here========================
                //====fetch comb====
        function view_combs(){
         $usermodel = new AcademicModel();
      $data['combs']=$this->AcademicModel->GetAllComb();
       $data['sub1']=$this->AcademicModel->GetAllsub_edit();
        $data['classlevel']=$this->AcademicModel->GetAllClassLevels();
        return view('templates/header')
        .view('academic/comb_view',$data)
        .view('templates/footer');
    }
public function save_comb()
{
        $AcademicModel = new AcademicModel();  
        $combname=strtoupper($this->request->getPost('combname'));
        $classlevel=$this->request->getPost('classlevel');
$exists=$AcademicModel->CheckCombExist($classlevel,$combname);
if (!empty($exists) && isset($exists)){

           return $this->response->setJSON(['status' => 3]);
    
}else{
    $data = [
            'comb_name'   => strtoupper($this->request->getPost('combname')),
            'classlevel'   => $this->request->getPost('classlevel'),
            'comb_status' => 1,
            'created_by'  => session()->get('user_id'),
            'created_on'  => date('Y-m-d H:i:s')
        ];
    $cid = $AcademicModel->save_comb_record($data);
        if ($cid){
            $dt = $this->request->getPost('sub_select[]');
            $errors = [];

            if (!empty($dt)) {
                foreach ($dt as $dat) {
                    $data2 = [
                        'comb_id'    => $cid,
                        'subject_id' => $dat
                    ];

                    $saved_dt = $this->AcademicModel->insert_comb_sub($data2);
                    if (!$saved_dt) {
                        $errors[] = "Failed to insert subject ID: " . $dat;
                    }
                }
            }else{
                        return $this->response->setJSON(['status' => 2]); 
            }
            if (empty($errors)) {
              return $this->response->setJSON(['status' => 1]);
                echo '<div class="alert alert-success alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
                        <span class="glyphicon glyphicon-ok"></span> New Combination Added Successfully.
                      </div>';
            } else {
                echo '<div class="alert alert-danger alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
                        <span class="glyphicon glyphicon-remove"></span> Some subjects failed to insert: ' . implode(", ", $errors) . '
                      </div>';

            }
        } else {
            echo '<div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
                    <span class="glyphicon glyphicon-remove"></span> Failed to add New Combination.
                  </div>';
        }
    }


  
}


     // ===================Update comb========================
public function update_comb() {
    $AcademicModel = new AcademicModel();

    $data = [
        'comb_name'   => ucfirst($this->request->getPost('combname')),
        'comb_status' => $this->request->getPost('combstatus'),
        'classlevel'  => $this->request->getPost('classlevel'),
        'created_by'  => session()->get('user_id'),
        'created_on'  => date('Y-m-d H:i:s')
    ]; 

    $combID = $this->request->getPost('comb_id');

    $cid = $AcademicModel->edit_comb($combID, $data);
    if ($cid) {
        $dt = $this->request->getPost('sub_select[]');
        $errors = [];

        if (!empty($dt)) {
            $AcademicModel->delete_comb_sub($combID);    
            foreach ($dt as $dat) {
                $data2 = [
                    'comb_id'    => $combID,
                    'subject_id' => $dat
                ];
                if (!$AcademicModel->insert_comb_sub($data2)) {
                    $errors[] = "Failed to insert subject ID: " . $dat;
                }
            }
        }

        if (empty($errors)) {
             return $this->response->setJSON(['status' => 1]);   
        } else {
             return $this->response->setJSON(['status' => 1]);   
        }

    } else {
        $this->session->setFlashdata('msg', 'Combination update failed');
         return $this->response->setJSON(['status' => 1]);   
    }
}

// ========================delete comb============
public function remove_comb(){
      $id =$this->request->uri->getSegment(2);
       if($this->AcademicModel->delete_comb($id)){
        $subcomb=$this->AcademicModel->delete_comb_sub($id);
        $substream=$this->AcademicModel->delete_comb_stream($id);
        if($subcomb==TRUE &&  $substream==TRUE){
             $this->session ->setFlashdata('msg','Removed Successfully'); 
         }else{
           $this->session ->setFlashdata('error','Not Removed Successfully');  
         }
      
       }else{
         $this->session ->setFlashdata('error','Not Removed Successfully');  
       }
     return redirect()->to( base_url().'/combination');      
    }

    //=========================Grade start here========================
                //====fetch grades====
        function view_grades(){
         $AcademicModel = new AcademicModel();
      $data['grades']=$this->AcademicModel->GetAllGrade();
      $data['classlevel']=$this->AcademicModel->GetAllClassLevels();
        return view('templates/header')
        .view('academic/grades_view',$data)
        .view('templates/footer');
    }

    public function GetGradesTable(){
        $level = $this->request->getPost('Clevel');
 $data['grades']=$this->AcademicModel->GetClassLevelgrade($level);
      $data['classlevel']=$this->AcademicModel->GetAllClassLevels();
        echo view('academic/forms/grades_table',$data);
    }
    public function view_grade_updateform(){
                $grade_id = $this->request->getPost('data');
 
 $data['grades']=$this->AcademicModel->GetgradeUpdateForm($grade_id);
      $data['classlevel']=$this->AcademicModel->GetAllClassLevels();
        echo view('academic/forms/grade_update_form',$data);
    }
     public function get_comb_details(){
                $comb_id = $this->request->getPost('comb_id');
  $data['sub1']=$this->AcademicModel->GetAllsub_edit();
 $data['comb']=$this->AcademicModel->GetCombUpdateForm($comb_id);
 $data['comb_allocation']=$this->AcademicModel->GetCombAllocation($comb_id);

      $data['classlevel']=$this->AcademicModel->GetAllClassLevels();
   
        echo view('academic/forms/view_comb_details',$data);
    }
         public function get_character_details(){
$charcter_id = $this->request->getPost('Character_id');
 $data['character']=$this->AcademicModel->GetCharacterDetails($charcter_id);
        echo view('academic/forms/view_character_details',$data);
    }   
public function view_comb_updateform()
{
    $comb_id = $this->request->getPost('data');
    $data['comb'] = $this->AcademicModel->getSingleCombination($comb_id);
    $data['assigned_subjects'] = $this->AcademicModel->getSubjectsInCombination($comb_id);
    $data['sub1'] = $this->AcademicModel->GetAllsub_edit();
    $data['classlevel'] = $this->AcademicModel->GetAllClassLevels();

    echo view('academic/forms/comb_update_form', $data);
}

public function save_grade(){
 $gradeValidation=( [
        'gradename' =>[
        'label'=>'gradename',
        'rules'=>'required',
        'errors'=>[
        'required'=>'Grade Name Can Not Be Empty'
        ]],
         'highgrade' =>[
        'label'=>'highgrade',
        'rules'=>'required',
        'errors'=>[
        'required'=>'Grade Mark Can Not Be Empty'
        ]],
         'lowgrade' =>[
        'label'=>'lowgrade',
        'rules'=>'required',
        'errors'=>[
        'required'=>'Grade Mark Can Not Be Empty'
        ]],
         'gradecomment' =>[
        'label'=>'gradecomment',
        'rules'=>'required',
        'errors'=>[
        'required'=>'Grade Comment Can Not Be Empty'
        ]]
        
    ]
    
    );
       if($this->validate($gradeValidation)){
        $AcademicModel = new AcademicModel();
        $data = [
            'grade_name' => $this->request->getPost('gradename'),
            'upper_performance' => ucfirst($this->request->getPost('highgrade')),
            'lower_performance' => ucfirst($this->request->getPost('lowgrade')),
            'comments' => ucfirst($this->request->getPost('gradecomment')),
            'division_point' =>$this->request->getPost('divisionpoints'),
            'classlevel' =>$this->request->getPost('classlevel'),
            'created_by' => session()->get('user_id'),
            'created_on' =>Date('Y-m-d H:i:s')
        ];
      if($AcademicModel->save_grade_record($data)){
         echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
               <span class="glyphicon glyphicon-ok"></span> New grade Added Successfully.</div> ';
      }
      else{
        echo '<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
                <span class="glyphicon glyphicon-ok"></span> Failed to add New gradeination.</div> ';

      }
        
            }
    
            else{
                
                echo '<div class="alert alert-danger alert-dismissible" role="alert" style="width:60%">'.$this->validation->listErrors();'</div>';
            }
            
    }
     // ===================Update grade========================
    public function update_grade() {
    $AcademicModel = new AcademicModel();
        $comb_id = $this->request->getPost('comb_id');
      $data = [
          'grade_name' => strtoupper($this->request->getPost('gradename')),
            'upper_performance' =>$this->request->getPost('highgrade'),
            'lower_performance' =>$this->request->getPost('lowgrade'),
            'division_point' =>$this->request->getPost('divisionpoints'),
            'comments' => ucfirst($this->request->getPost('gradecomment')),
             'classlevel' =>$this->request->getPost('classlevel'),
             'created_by' => session()->get('user_id'),
            'created_on' =>Date('Y-m-d H:i:s')
        ]; 
        // print_r($data);
        // return;

    $gradeID = $this->request->getPost('grade_id');
     if($this->AcademicModel->edit_grade($gradeID, $data)){
        $this->session ->setFlashdata('msg','grade updated Successfully');
        return redirect()->to('/grades');
         return "grade updated successfully!";
    } else {
    $this->session ->setFlashdata('msg','grade update failed');
        return redirect()->to('/grades');
    }
}
////////////// function to comb data ////////////////
    function get_combinations_details()
    {
        $id  = $this->request->getVar('comb_id');
        echo $id;
        $data = array(
               'inv' => $this->AcademicModel->get_comb_name('combination_tbl',$where = array('comb_id' =>$id))
            );
        print_r( $data);
            return view('academic/view_comb_details',$data);
    }
// ========================delete grade============
public function remove_grade(){
      $id =$this->request->uri->getSegment(2);
       if($this->AcademicModel->delete_grade($id)){
        $this->session ->setFlashdata('msg','Removed Successfully');
       }else{
         $this->session ->setFlashdata('error','Not Removed Successfully');  
       }
     return redirect()->to( base_url().'/grades');      
    }
    
public function Allocation_report(){
  $this->AcademicModel = new AcademicModel();
        $status = $this->request->getPost('status');
        $year = $this->request->getPost('year');
        $class = $this->request->getPost('class');
            $classlevel = $this->request->getPost('classlevel');
            $stream = $this->request->getPost('stream');
            $data['classlevel']=$this->request->getPost('classlevel');
            // print_r($data['classlevel']);
            // return;
            $data['class']=$this->request->getPost('class');
            $data['stream']=$this->request->getPost('stream');
            $data['year']=$this->request->getPost('year');
            $data['time']=1;

            $data['cl_allocation']=$this->AcademicModel->get_subject_allocatiion($class,$classlevel,$stream);
           echo view('academic/forms/allocation_list',$data);
         }

 public function ViewCombSubjects()
    {
        $id=$this->request->getGet('ids');
         $data = array(
            'teacher'  => $this->AcademicModel->get_active_teacher('users'),
            'teach_sub'  => $this->AcademicModel->get_active_subject('subject_tbl'),
             'staffs' => $this->AcademicModel->getAllusers(),
            'view_all' => $this->AcademicModel->Get_Allocation_info($id));
             if (!empty($data['view_all'])) {
        $combination_name = $data['view_all'][0]->comb_name;  
    } else {
        $combination_name = "Unknown Combination";
    }
    echo "<table border='1' cellpadding='5' cellspacing='0'>
            <tr>
                <th>Subjects for {$combination_name}</th>
            </tr>";

    if (!empty($data['view_all'])) {
        foreach ($data['view_all'] as $subject) {
            echo "<tr><td>{$subject->subject_name}</td></tr>";
        }
    } else {
        echo "<tr><td>No subjects found.</td></tr>";
    }

    echo "</table>";

    }

    public function Save_class_allocation(){
        $ExamsValidation=( [
        'class1' =>[
        'label'=>'class1',
        'rules'=>'required',
        'errors'=>[
        'required'=>'Enter Class '
        ],
        ],
        'stream1' =>[
        'label'=>' stream1',
        'rules'=>'required',
        'errors'=>[
        'required'=>'Enter stream'
        ],
        ],
           'comb' =>[
        'label'=>'comb',
        'rules'=>'required',
        'errors'=>[
        'required'=>'Enter Combination '
        ],
        ]    
        
    ]
    
    );
       if($this->validate($ExamsValidation)){
        $AcademicModel = new AcademicModel();
        $data = [
            'class_id' => $this->request->getPost('class1'),
            'stream_id' => $this->request->getPost('stream1'),
            'comb' => $this->request->getPost('comb'),
            'created_by' => session()->get('user_id'),
            'created_on' =>Date('Y-m-d H:i:s')
        ];    
         $AcademicModel->save_allocation_record($data);
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
                <span class="glyphicon glyphicon-ok"></span> New Allocation Added Successfully.</div> ';
            }
    
            else{
                
                echo '<div class="alert alert-danger alert-dismissible" role="alert" style="width:60%">'.$this->validation->listErrors();'</div>';
            }
             
    }
      public function editStreamAllocation()
    {
        $id=$this->request->getGet('ids');
         $data = array(
            'clevel'  => $this->studentModel->get_active_item('class_level_tbl'),
              'comb1'  => $this->AcademicModel->GetActiveCombination(),
            'update_all' => $this->AcademicModel->GetStreamEdit($id));
       echo view('academic/forms/edit_stream_allocation',$data);
       
       
    }
    public function UpdateStreamAllocation(){
        $AcademicModel = new AcademicModel();
        $data = [
            'class_id' => $this->request->getPost('class'),
            'stream_id' => $this->request->getPost('stream'),
            'comb' => $this->request->getPost('comb'),
              'created_by' => session()->get('user_id'),
            'created_on' =>Date('Y-m-d H:i:s')
        ];  
        $stID=$this->request->getPost('update_id');
     if (!empty($data)) {
        if ($AcademicModel->update_allocation_record($stID,$data)) {
               $msg = ['status' => 'success', 'message' => 'Stream updated successfully.'];
           
        }else{
        $msg = ['status' => 'error', 'message' => 'Failed to update stream. Please try again.'];
        }
     
     }else{
      $msg = ['status' => 'error', 'message' => 'Invalid data. Please fill all fields.'];
     }
 echo view('academic/forms/showmsg',$msg);
           }
      public function ReadAllocation()
    {
        $id=$this->request->getGet('ids');
         $data = array(
            'clevel'  => $this->studentModel->get_active_item('class_level_tbl'),
              'comb1'  => $this->AcademicModel->GetActiveCombination(),
            'read_all' => $this->AcademicModel->GetStreamEdit($id));
       echo view('academic/forms/view_stream_allocation',$data);
    }
   public function remove_stream_allocation(){
        $id =$this->request->uri->getSegment(2);
       if($this->AcademicModel->remove_stream_allocations($id)){
        $this->session ->setFlashdata('msg','Removed Successfully');
       }else{
         $this->session ->setFlashdata('error','Not Removed Successfully');  
       }
    }
     function view_techer_subject(){
            $data = array(
               'clevel'  => $this->studentModel->get_active_item('class_level_tbl'),
                'teacher'  => $this->AcademicModel->get_active_teacher('users'),
                 'teach_sub'  => $this->AcademicModel->get_active_subject('subject_tbl'),
               'staffs' => $this->AcademicModel->getAllusers(),
              'allocate'=> $this->AcademicModel->GetAll_TeacherAllocation()
            );
            return view('templates/header')
            .view('academic/teacher_subject',$data)
            .view('templates/footer');
        }

    // =======================Teachers Allocation=====================
             public function ViewStreamSubjects()
    {
        $teacher = $this->request->getPost('teacher_id');
        $classlevel = $this->request->getPost('classlevel_id');
        $class = $this->request->getPost('class_id');
        $stream = $this->request->getPost('stream_id');
         $data = array(
             'teacher_id'=>$teacher,
            'classlevel'=>$classlevel,
            'class'=>$class,
            'stream'=>$stream,
            'teacher'  => $this->AcademicModel->get_active_teacher('users'),
            'teach_sub'  => $this->AcademicModel->get_active_subject('subject_tbl'),
             'staffs' => $this->AcademicModel->getAllusers(),
            'view_unallocated' => $this->AcademicModel->Get_stream_Allocated_subjects($stream,$teacher),
            'view_allocated' => $this->AcademicModel->Get_teacher_Allocated_subjects($stream,$teacher));
         echo view('academic/teacher/stream_subject_lists',$data);

    }
        public function save_teachers_allocation(){
     if ($this->request->isAJAX()) {
        $AcademicModel = new AcademicModel();
         $data = [
            'teacher_id' =>$this->request->getGet('user'),
            'teacher_subject' => $this->request->getGet('modl'),
            'classlevel' => $this->request->getGet('classlevel_id'),
            'class' => $this->request->getGet('class_id'),
            'stream' => $this->request->getGet('stream_id'),
            'allocated_by' => session()->get('user_id'),
            'updated_by' => session()->get('user_id'),
            'save_status' =>0,
            'update_date' =>Date('Y-m-d H:i:s'),
            'allocation_date' =>Date('Y-m-d H:i:s')
        ];    
         $saved=$AcademicModel->save_teacher_allocation_records($data);
         if($saved==true){
             return $this->response->setJSON(['status' => 'success']); 
         }else{
            return $this->response->setJSON(['status' => 'error']); 
         }
   
    }

} 
public function remove_teachers_allocation()
{
         if ($this->request->isAJAX()) {
        $AcademicModel = new AcademicModel();
          $teacher_id=$this->request->getGet('user');
          $subject_id=$this->request->getGet('modl');
          $stream=$this->request->getGet('stream_id'); 
         $removed=$AcademicModel->remove_single_teacher_allocation($teacher_id,$subject_id,$stream);
         if($removed==true){
             return $this->response->setJSON(['status' => 'success']); 
         }else{
            return $this->response->setJSON(['status' => 'error']); 
         }
   
    }
}

    public function allocateAllSubjects()
{
    if ($this->request->isAJAX()) {
        $subjects = $this->request->getPost('subjects');
        foreach ($subjects as $subject) {
 $AcademicModel = new AcademicModel();
        $data = [
            'teacher_id' =>$subject['teacher_id'],
            'teacher_subject' => $subject['subject_id'],
            'classlevel' => $subject['classlevel_id'],
            'class' =>$subject['class_id'],
            'stream' =>$subject['stream_id'],
            'allocated_by' => session()->get('user_id'),
            'updated_by' => session()->get('user_id'),
            'save_status' =>0,
            'update_date' =>Date('Y-m-d H:i:s'),
            'allocation_date' =>Date('Y-m-d H:i:s')
        ];  
             $AcademicModel->save_teacher_allocation_records($data);
        }
      
        
    }
    return $this->response->setJSON(['status' => 'success']);
}
    public function delete_allocation(){
        $id =$this->request->uri->getSegment(2);
       if($this->AcademicModel->remove_teacher_allocation($id)){
        $this->session ->setFlashdata('msg','Removed Successfully');
       }else{
         $this->session ->setFlashdata('error','Not Removed Successfully');  
       }
     return redirect()->to( base_url().'/techers_subject');
    }

  public function editAllocation()
    {
        $id=$this->request->getGet('ids');
         $data = array(
            'clevel'  => $this->studentModel->get_active_item('class_level_tbl'),
             'classname'  => $this->studentModel->get_active_item('classes_tbl'),
            'teacher'  => $this->AcademicModel->get_active_teacher('users'),
            'teach_sub'  => $this->AcademicModel->get_active_subject('subject_tbl'),
             'staffs' => $this->AcademicModel->getAllusers(),
            'update_all' => $this->AcademicModel->Get_Allocation_data($id));
       echo view('academic/forms/manage_allocation',$data);
      
    }

public function Updateallocation(){
      $id=$this->request->getPost('allocate_id');
     $data = [
            'teacher_id' =>$this->request->getPost('name_teacher'),
            'classlevel' =>$this->request->getPost('classlevel'),
            'class' => $this->request->getPost('class'),
            'teacher_subject' => $this->request->getPost('name_subject'),
             'updated_by' => session()->get('user_id'),
            'update_date' => date('Y/m/d H:i:s')
        ];
         $this->AcademicModel ->Allocation_updates($id,$data);
}
  public function ViewAllocation()
    {
        $teacher=$this->request->getPost('teacher_id');
        $subjects=$this->request->getPost('subjects');
         $data = array(
             'teacher' => $this->AcademicModel->getTeacher($teacher),
             'subject_count' => $subjects,
            'view_all' => $this->AcademicModel->Get_Allocation_data($teacher)
         );
       echo view('academic/forms/view_teacher_allocation',$data);
    }
        // =====================end allocation=============
    public function ViewMySubjects(){
        $user=session()->get('user_id');

       $data= array(
        'staffs' => $this->AcademicModel->getAllusers(),
        'my_allocation' => $this->AcademicModel->My_Allocation_data($user)
    );
           return view('templates/header')
            .view('academic/teacher/subject_allocation',$data)
            .view('templates/footer');
    }
public function manage_subjects_class(){
       $data = array(
               'clevel'  => $this->studentModel->get_active_item('class_level_tbl'),
                'teacher'  => $this->AcademicModel->get_active_teacher('users'),
                 'teach_sub'  => $this->AcademicModel->get_active_subject('subject_tbl'),
               'staffs' => $this->AcademicModel->getAllusers(),
               'combs'=>$this->AcademicModel->GetAllComb(),
              'allocate'=> $this->AcademicModel->GetAll_TeacherAllocation()
            );
        return view('templates/header')
        .view('academic/class_subject_view',$data)
        .view('templates/footer');
}
public function GetAllCombByClassLevel(){;
 if($this->request->getPost('clvl')>0){
   $classlevel=$this->request->getPost('clvl');
        $CombData=$this->AcademicModel->GetCombByClassLevel($classlevel); 
        echo json_encode($CombData);
         
    }else{
  return $this->response->setJSON(['status' => 2]);
    }
  
}
  public function GetCombTable(){
        $level = $this->request->getPost('Clevel');
 $data['combs']=$this->AcademicModel->GetCombByClassLevel($level);
       $data['sub1']=$this->AcademicModel->GetAllsub_edit();
      $data['classlevel']=$this->AcademicModel->GetAllClassLevels();
        echo view('academic/forms/combinations_table',$data);
    }
        function get_combstream_details(){
                $class=$this->request->getPost('clvl');
          $streamdta = $this->AcademicModel->get_comb_stream_details($class);

         $classlist = array();
         if(count($streamdta) > 0){
             foreach($streamdta as $c){
                $class=$this->request->getPost('clvl');
                $streamdata = $this->AcademicModel->get_comb_stream_details($class);
                
                $classlist[] = array("id" => $c->id, "name" => $c->stream_name,"comb" => $c->comb_name);
         }
        }
        echo json_encode($classlist);  
    }

public function load_unassigned_stream_subject()
{
     $teacher = $this->request->getPost('teacher_id');
        $classlevel = $this->request->getPost('classlevel_id');
        $class = $this->request->getPost('class_id');
        $stream = $this->request->getPost('stream_id');

    $list = $this->AcademicModel->Get_stream_Allocated_subjects($stream, $teacher);

    if ($list && count($list) > 0) {
        $sn = 0;
        echo '<table class="table table-bordered mt-2">
                <tr>
                    <th>S/N</th>
                    <th>Subject</th>
                    <th><input type="checkbox" onclick="selectAllUnassigned()" id="checkAllUnassigned"> All</th>
                     <th>Action</th>
                </tr>';
        foreach ($list as $item) {
            $sn++;
            echo "<tr>
                    <td>$sn</td>
                    <td>{$item->subject_name}</td>
                    <td><input type='checkbox' class='unassigned-checkbox' value='{$item->subject_id}'></td>
                    <td class='text-center'>
                    <a href='javascript:void(0)' 
   onclick=\"AssignSubjects('{$item->subject_id}', '{$teacher}', '{$classlevel}', '{$class}', '{$stream}')\" 
   title='Assign'>
   <span class='fa fa-plus text-success'></span>
</a>

                    </td>
                  </tr>";
        }
        echo '</table>';
    } else {
        echo '<div class="alert alert-warning">No unassigned subjects.</div>';
    }
}

public function load_assigned_stream_subjects()
{
       $teacher = $this->request->getPost('teacher_id');
        $classlevel = $this->request->getPost('classlevel_id');
        $class = $this->request->getPost('class_id');
        $stream = $this->request->getPost('stream_id');
    

    $list = $this->AcademicModel->Get_teacher_Allocated_subjects($stream, $teacher);

    if ($list && count($list) > 0) {
        $sn = 0;
        echo '<table class="table table-bordered mt-2">
                <tr>
                    <th>S/N</th>
                    <th>Subject</th>
                    <th>Class</th>
                    <th>Stream</th>
                    <th><input type="checkbox" onclick="selectAllAssigned()" id="checkAllAssigned"> All</th>
                    <th>Action</th>
                </tr>';
        foreach ($list as $item) {
            $sn++;
            echo "<tr>
                    <td>$sn</td>
                    <td>{$item->subject_name}</td>
                    <td>{$item->class_name}</td>
                    <td>{$item->stream_name}</td>
                    <td class='text-center'>";
   if($item->id==$stream){
 echo  "<input type='checkbox' class='assigned-checkbox' value='{$item->subject_id}'>";
     }else{
         echo  "<input type='checkbox' class='assigned-checkbox' disabled>";
     }

                 
                   echo"</td> <td class='text-center'>";
                    if($item->id==$stream){
      echo  "<a href='javascript:void(0)' onclick=\"UnassignSubjects('{$item->subject_id}', '{$teacher}', '{$classlevel}', '{$class}', '{$stream}')\" title='Unassign'><span class='fa fa-remove text-danger'></span></a>";
                    }else{
     echo "<a href='javascript:void(0)' 
            class='disabled-link' 
            style='pointer-events: none; opacity: 0.5; cursor: not-allowed;' 
            title='Unassign'>
            <span class='fa fa-remove text-secondary'></span>
          </a>";
                    }

 

               echo"</td>
                  </tr>";
        }
        echo '</table>';
    } else {
        echo '<div class="alert alert-info">No assigned subjects.</div>';
    }
}
public function add_all_teachers_allocation()
{
    $subjectIds = $this->request->getPost('subjects');      
    $AcademicModel = new AcademicModel();
    foreach ($subjectIds as $subjectId) {
          $data = [
            'teacher_id' => $this->request->getPost('teacher_id'),
            'teacher_subject' => $subjectId,
            'classlevel' => $this->request->getPost('classlevel_id'),
            'class' => $this->request->getPost('class_id'),
            'stream' => $this->request->getPost('stream_id'),
            'allocated_by' => session()->get('user_id'),
            'updated_by' => session()->get('user_id'),
            'save_status' =>0,
            'update_date' =>Date('Y-m-d H:i:s'),
            'allocation_date' =>Date('Y-m-d H:i:s')
        ]; 
         $saved=$AcademicModel->save_teacher_allocation_records($data);
    }
    return $this->response->setJSON(['status' => 'success']);
}
public function remove_all_teachers_allocation(){
       $subjectIds = $this->request->getPost('subjects');
    $teacherId = $this->request->getPost('teacher_id');
    $streamId = $this->request->getPost('stream_id');

    $AcademicModel = new AcademicModel();
    foreach ($subjectIds as $subjectId) {
       $removed= $AcademicModel->remove_single_teacher_allocation($teacherId, $subjectId, $streamId);
      if($removed){
        $data['status']= $this->response->setJSON(['status' => 'success']);
      }
      else{
        $data['status']= $this->response->setJSON(['status' => 'error']); 
      }
    }
    return $data['status'];

    
}
public function stream_comb_allocation_status(){
     $AcademicModel = new AcademicModel();
        $classlevel = $this->request->getPost('classlevel');
      $class = $this->request->getPost('class');
    $stream = $this->request->getPost('stream');
     $exists=$this->AcademicModel->get_subject_allocatiion2($class,$classlevel,$stream);
    if (is_array($exists) && count($exists) > 0) {
         $combName = $exists[0]->comb_name ?? 'Unknown';
        return $this->response->setJSON(['AllocationStatus' => 1,'CombinationName' => $combName]);
    } else {
        return $this->response->setJSON(['AllocationStatus' => 2]);
    }
}

}
?>