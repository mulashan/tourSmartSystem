<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\SystemModel;
 use App\Models\StudentModel;
  use App\Models\BillingModel;
    use App\Models\ReportsModel;
   
class SystemController extends BaseController
{
    public $stym;
    public $studentModel;
    private $schoolCalendarSmsAudienceColumnsAvailable = null;
    private $schoolCalendarSmsScheduleTableAvailable = null;
    public function __construct()
    {
        
         if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
        helper("form");
        $this->stym = new SystemModel();
        $this->studentModel = new StudentModel;
          $this->billingModel = new BillingModel;  
          $this->report = new ReportsModel;
          $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
         helper('array');
    }


    public function messages()
    {
        return view('templates/header')
        .view('system/messages')
        .view('templates/footer');
    }

    public function messages_recharge()
    {
        return view('templates/header')
        .view('system/recharge')
        .view('templates/footer');
    }

    public function school_calendar()
    {
        $data = [
            'thedate' => date('Y/n/j') . ' - ' . date('Y/n/j'),
            'from_date' => date('Y-m-d'),
            'to_date' => date('Y-m-d'),
        ] + $this->getSchoolCalendarFormData();

        return view('templates/header')
        .view('system/school_calendar', $data)
        .view('templates/footer');
    }

    public function load_school_calendar()
    {
        $dateRange = $this->request->getPost('thedate');
        $fromDate = date('Y-m-d');
        $toDate = date('Y-m-d');

        if (! empty($dateRange) && strpos($dateRange, ' - ') !== false) {
            [$rawFromDate, $rawToDate] = explode(' - ', $dateRange, 2);
            $fromDate = date('Y-m-d', strtotime(trim($rawFromDate)));
            $toDate = date('Y-m-d', strtotime(trim($rawToDate)));
        }

        $builder = $this->db->table('school_calendar_tbl sc');
        $builder->select('sc.*,users.first_name,users.last_name');
        $builder->join('users', 'users.user_id = sc.created_by', 'left');
        $builder->where('sc.event_date >=', $fromDate);
        $builder->where('sc.event_date <=', $toDate);
        $builder->orderBy('sc.event_date', 'DESC');
        $builder->orderBy('sc.id', 'DESC');

        $data = [
            'events' => $builder->get()->getResult(),
        ];

        echo view('system/forms/school_calendar_list', $data);
    }

    public function save_school_calendar()
    {
        $participants = [
            'parents' => $this->request->getPost('parents') ? 1 : 0,
            'students' => $this->request->getPost('students') ? 1 : 0,
            'staff' => $this->request->getPost('staff') ? 1 : 0,
        ];
        $smsEnabled = $this->request->getPost('sms_enabled') ? 1 : 0;
        $smsAudiences = $this->getSchoolCalendarSmsAudiencesFromRequest($participants, $smsEnabled);
        $smsSchedules = $this->getSchoolCalendarSmsSchedulesFromRequest();
        $smsMessage = trim((string) $this->request->getPost('sms_message'));
        $staffSmsMessage = trim((string) $this->request->getPost('staff_sms_message'));
        $sendType = (int) $this->request->getPost('send_type');
        $selectedStudentIds = $this->getSelectedSchoolCalendarStudentIdsFromRequest();
        $selectedStaffIds = $this->getSelectedSchoolCalendarStaffIdsFromRequest();
        $smsTargetYear = $sendType === 1 ? $this->request->getPost('sms_year_individual') : $this->request->getPost('sms_year');
        $smsTargetStatus = $sendType === 1 ? $this->request->getPost('sms_status_individual') : $this->request->getPost('sms_status');

        if (array_sum($participants) === 0) {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please select at least one event participant.'
            ]);
            return;
        }

        $validationRules = [
            'event_date' => [
                'label' => 'Event Date',
                'rules' => 'required',
                'errors' => [
                    'required' => 'Event Date can not be empty',
                ],
            ],
            'event_description' => [
                'label' => 'Event Description',
                'rules' => 'required',
                'errors' => [
                    'required' => 'Event Description can not be empty',
                ],
            ],
        ];

        if (! $this->validate($validationRules)) {
            $errors = implode('<br>', $this->validator->getErrors());
            echo json_encode([
                'status' => '1',
                'statusDesc' => $errors,
            ]);
            return;
        }

        if ($smsEnabled === 1 && $smsAudiences['student'] === 1 && $smsMessage === '') {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please customize student/parent SMS notification message.'
            ]);
            return;
        }

        if ($smsEnabled === 1 && $smsAudiences['staff'] === 1 && $staffSmsMessage === '') {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please customize staff SMS notification message.'
            ]);
            return;
        }

        if (
            $smsEnabled === 1
            && $smsAudiences['student'] === 1
            && ! in_array($sendType, [1, 2], true)
        ) {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please select SMS send type.'
            ]);
            return;
        }

        if (
            $smsEnabled === 1
            && $smsAudiences['student'] === 1
            && empty($selectedStudentIds)
        ) {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please create and select at least one student for SMS notification.'
            ]);
            return;
        }

        if (
            $smsEnabled === 1
            && $smsAudiences['staff'] === 1
            && empty($selectedStaffIds)
        ) {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please select at least one staff recipient for SMS notification.'
            ]);
            return;
        }

        if ($smsEnabled === 1 && $smsAudiences['student'] === 0 && $smsAudiences['staff'] === 0) {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please choose who should receive the SMS notification.'
            ]);
            return;
        }

        if ($smsEnabled === 1 && ($smsAudiences['student'] === 1 || $smsAudiences['staff'] === 1) && empty($smsSchedules)) {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please add at least one SMS schedule date and time.'
            ]);
            return;
        }

        if ($smsEnabled !== 1 || $smsAudiences['student'] !== 1) {
            $selectedStudentIds = [];
            $sendType = 0;
        }

        if ($smsEnabled !== 1 || $smsAudiences['staff'] !== 1) {
            $selectedStaffIds = [];
        }

        $data = [
            'event_date' => $this->request->getPost('event_date'),
            'event_description' => trim($this->request->getPost('event_description')),
            'parents' => $participants['parents'],
            'students' => $participants['students'],
            'staff' => $participants['staff'],
            'sms_enabled' => $smsEnabled,
            'sms_message' => $smsEnabled === 1 && $smsAudiences['student'] === 1 ? $smsMessage : null,
            'staff_sms_message' => $smsEnabled === 1 && $smsAudiences['staff'] === 1 ? $staffSmsMessage : null,
            'send_type' => $smsEnabled === 1 && $smsAudiences['student'] === 1 ? $sendType : 0,
            'sms_target_year' => $smsEnabled === 1 && $smsAudiences['student'] === 1 ? $this->sanitizeNullableInt($smsTargetYear) : null,
            'sms_target_level_id' => $smsEnabled === 1 && $smsAudiences['student'] === 1 && $sendType === 2 ? $this->sanitizeNullableInt($this->request->getPost('sms_level_id')) : null,
            'sms_target_class_id' => $smsEnabled === 1 && $smsAudiences['student'] === 1 && $sendType === 2 ? $this->sanitizeNullableInt($this->request->getPost('sms_class_id')) : null,
            'sms_target_stream_id' => $smsEnabled === 1 && $smsAudiences['student'] === 1 && $sendType === 2 ? $this->sanitizeNullableInt($this->request->getPost('sms_stream_id')) : null,
            'sms_target_status' => $smsEnabled === 1 && $smsAudiences['student'] === 1 ? $this->sanitizeNullableInt($smsTargetStatus) : null,
            'before_sms_sent_at' => null,
            'event_sms_sent_at' => null,
            'status' => 1,
            'created_by' => $_SESSION['user_id'],
            'created_date' => date('Y-m-d H:i:s'),
        ];
        $this->applySchoolCalendarSmsAudienceData($data, $smsAudiences);

        $eventId = $this->studentModel->SaveData_n_get_id('school_calendar_tbl', $data);
        $this->syncSchoolCalendarRecipients($eventId, $selectedStudentIds);
        $this->syncSchoolCalendarStaffRecipients($eventId, $selectedStaffIds);
        $this->syncSchoolCalendarSmsSchedules($eventId, $smsEnabled === 1 ? $smsSchedules : []);

        echo json_encode([
            'status' => '0',
            'statusDesc' => 'School calendar event added successful'
        ]);
    }

    public function view_school_calendar()
    {
        $id = $this->request->getPost('id');
        $data['event'] = $this->studentModel->gettable_data('school_calendar_tbl', ['id' => $id]);
        $eventItem = $data['event'][0] ?? null;
        $data['sms_student_audience'] = $this->isSchoolCalendarStudentSmsAudienceEnabled($eventItem);
        $data['sms_staff_audience'] = $this->isSchoolCalendarStaffSmsAudienceEnabled($eventItem);
        $data['sms_schedules'] = $this->getSchoolCalendarEventSmsSchedules($eventItem);
        $data['selected_students'] = $this->getSchoolCalendarStudents([
            'year' => $eventItem->sms_target_year ?? date('Y'),
        ], $this->getSchoolCalendarEventSelectedStudentIds($id));
        $data['selected_staffs'] = $this->getSchoolCalendarStaffs('', $this->getSchoolCalendarEventSelectedStaffIds($id));

        echo view('system/view_school_calendar', $data);
    }

    public function edit_school_calendar()
    {
        $id = $this->request->getPost('id');
        $data['event'] = $this->studentModel->gettable_data('school_calendar_tbl', ['id' => $id]);
        $eventItem = $data['event'][0] ?? null;
        $smsStudentAudience = $this->isSchoolCalendarStudentSmsAudienceEnabled($eventItem);
        $smsStaffAudience = $this->isSchoolCalendarStaffSmsAudienceEnabled($eventItem);
        $selectedStudentIds = $this->getSchoolCalendarEventSelectedStudentIds($id);
        $selectedStaffIds = $this->getSchoolCalendarEventSelectedStaffIds($id);
        $smsSchedules = $this->getSchoolCalendarEventSmsSchedules($eventItem);
        $smsStudents = [];
        $smsStaffs = [];

        if ($eventItem) {
            if ($smsStudentAudience && (int) ($eventItem->send_type ?? 0) === 2) {
                $smsStudents = $this->getSchoolCalendarStudents([
                    'year' => $eventItem->sms_target_year ?: date('Y'),
                    'classlevel' => $eventItem->sms_target_level_id ?: 0,
                    'class' => $eventItem->sms_target_class_id ?: 0,
                    'stream' => $eventItem->sms_target_stream_id ?: 0,
                    'status' => $eventItem->sms_target_status ?: 0,
                ]);
            } elseif ($smsStudentAudience && ! empty($selectedStudentIds)) {
                $smsStudents = $this->getSchoolCalendarStudents([
                    'year' => $eventItem->sms_target_year ?: date('Y'),
                ], $selectedStudentIds);
            }

            if ($smsStaffAudience && ! empty($selectedStaffIds)) {
                $smsStaffs = $this->getSchoolCalendarStaffs('', $selectedStaffIds);
            }
        }

        $data['selected_student_ids'] = $selectedStudentIds;
        $data['selected_staff_ids'] = $selectedStaffIds;
        $data['sms_students'] = $smsStudents;
        $data['sms_staffs'] = $smsStaffs;
        $data['sms_schedules'] = $smsSchedules;
        $data['sms_student_audience'] = $smsStudentAudience;
        $data['sms_staff_audience'] = $smsStaffAudience;
        $data = $data + $this->getSchoolCalendarFormData();

        echo view('system/manage_school_calendar', $data);
    }

    public function update_school_calendar()
    {
        $participants = [
            'parents' => $this->request->getPost('parents') ? 1 : 0,
            'students' => $this->request->getPost('students') ? 1 : 0,
            'staff' => $this->request->getPost('staff') ? 1 : 0,
        ];
        $smsEnabled = $this->request->getPost('sms_enabled') ? 1 : 0;
        $smsAudiences = $this->getSchoolCalendarSmsAudiencesFromRequest($participants, $smsEnabled);
        $smsSchedules = $this->getSchoolCalendarSmsSchedulesFromRequest();
        $smsMessage = trim((string) $this->request->getPost('sms_message'));
        $staffSmsMessage = trim((string) $this->request->getPost('staff_sms_message'));
        $eventId = (int) $this->request->getPost('id');
        $sendType = (int) $this->request->getPost('send_type');
        $selectedStudentIds = $this->getSelectedSchoolCalendarStudentIdsFromRequest();
        $selectedStaffIds = $this->getSelectedSchoolCalendarStaffIdsFromRequest();
        $existingEvent = $this->studentModel->gettable_data('school_calendar_tbl', ['id' => $eventId]);
        $existingEventItem = $existingEvent[0] ?? null;
        $existingSmsAudiences = [
            'student' => $this->isSchoolCalendarStudentSmsAudienceEnabled($existingEventItem) ? 1 : 0,
            'staff' => $this->isSchoolCalendarStaffSmsAudienceEnabled($existingEventItem) ? 1 : 0,
        ];
        $existingSchedules = $this->getSchoolCalendarScheduleSignature($this->getSchoolCalendarEventSmsSchedules($existingEventItem));
        $existingRecipientIds = $this->getSchoolCalendarEventSelectedStudentIds($eventId);
        $existingStaffRecipientIds = $this->getSchoolCalendarEventSelectedStaffIds($eventId);
        $smsTargetYear = $sendType === 1 ? $this->request->getPost('sms_year_individual') : $this->request->getPost('sms_year');
        $smsTargetStatus = $sendType === 1 ? $this->request->getPost('sms_status_individual') : $this->request->getPost('sms_status');

        if (array_sum($participants) === 0) {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please select at least one event participant.'
            ]);
            return;
        }

        $validationRules = [
            'event_date' => [
                'label' => 'Event Date',
                'rules' => 'required',
                'errors' => [
                    'required' => 'Event Date can not be empty',
                ],
            ],
            'event_description' => [
                'label' => 'Event Description',
                'rules' => 'required',
                'errors' => [
                    'required' => 'Event Description can not be empty',
                ],
            ],
        ];

        if (! $this->validate($validationRules)) {
            $errors = implode('<br>', $this->validator->getErrors());
            echo json_encode([
                'status' => '1',
                'statusDesc' => $errors,
            ]);
            return;
        }

        if ($smsEnabled === 1 && $smsAudiences['student'] === 1 && $smsMessage === '') {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please customize student/parent SMS notification message.'
            ]);
            return;
        }

        if ($smsEnabled === 1 && $smsAudiences['staff'] === 1 && $staffSmsMessage === '') {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please customize staff SMS notification message.'
            ]);
            return;
        }

        if (
            $smsEnabled === 1
            && $smsAudiences['student'] === 1
            && ! in_array($sendType, [1, 2], true)
        ) {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please select SMS send type.'
            ]);
            return;
        }

        if (
            $smsEnabled === 1
            && $smsAudiences['student'] === 1
            && empty($selectedStudentIds)
        ) {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please create and select at least one student for SMS notification.'
            ]);
            return;
        }

        if (
            $smsEnabled === 1
            && $smsAudiences['staff'] === 1
            && empty($selectedStaffIds)
        ) {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please select at least one staff recipient for SMS notification.'
            ]);
            return;
        }

        if ($smsEnabled === 1 && $smsAudiences['student'] === 0 && $smsAudiences['staff'] === 0) {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please choose who should receive the SMS notification.'
            ]);
            return;
        }

        if ($smsEnabled === 1 && ($smsAudiences['student'] === 1 || $smsAudiences['staff'] === 1) && empty($smsSchedules)) {
            echo json_encode([
                'status' => '1',
                'statusDesc' => 'Please add at least one SMS schedule date and time.'
            ]);
            return;
        }

        if ($smsEnabled !== 1 || $smsAudiences['student'] !== 1) {
            $selectedStudentIds = [];
            $sendType = 0;
        }

        if ($smsEnabled !== 1 || $smsAudiences['staff'] !== 1) {
            $selectedStaffIds = [];
        }

        sort($selectedStudentIds);
        sort($existingRecipientIds);
        sort($selectedStaffIds);
        sort($existingStaffRecipientIds);
        $shouldResetSchedule = $smsEnabled === 1 && (
            ! $existingEventItem
            || $existingEventItem->event_date !== $this->request->getPost('event_date')
            || (int) ($existingEventItem->sms_enabled ?? 0) !== $smsEnabled
            || $existingSmsAudiences['student'] !== $smsAudiences['student']
            || $existingSmsAudiences['staff'] !== $smsAudiences['staff']
            || trim((string) ($existingEventItem->sms_message ?? '')) !== ($smsEnabled === 1 && $smsAudiences['student'] === 1 ? $smsMessage : '')
            || trim((string) ($existingEventItem->staff_sms_message ?? '')) !== ($smsEnabled === 1 && $smsAudiences['staff'] === 1 ? $staffSmsMessage : '')
            || (int) ($existingEventItem->send_type ?? 0) !== $sendType
            || (int) ($existingEventItem->sms_target_year ?? 0) !== (int) ($smsAudiences['student'] === 1 ? ($smsTargetYear ?: 0) : 0)
            || (int) ($existingEventItem->sms_target_level_id ?? 0) !== (int) ($smsAudiences['student'] === 1 && $sendType === 2 ? ($this->request->getPost('sms_level_id') ?: 0) : 0)
            || (int) ($existingEventItem->sms_target_class_id ?? 0) !== (int) ($smsAudiences['student'] === 1 && $sendType === 2 ? ($this->request->getPost('sms_class_id') ?: 0) : 0)
            || (int) ($existingEventItem->sms_target_stream_id ?? 0) !== (int) ($smsAudiences['student'] === 1 && $sendType === 2 ? ($this->request->getPost('sms_stream_id') ?: 0) : 0)
            || (int) ($existingEventItem->sms_target_status ?? 0) !== (int) ($smsAudiences['student'] === 1 ? ($smsTargetStatus ?: 0) : 0)
            || $existingSchedules !== $this->getSchoolCalendarScheduleSignature($smsSchedules)
            || $existingRecipientIds !== $selectedStudentIds
            || $existingStaffRecipientIds !== $selectedStaffIds
        );

        $data = [
            'event_date' => $this->request->getPost('event_date'),
            'event_description' => trim($this->request->getPost('event_description')),
            'parents' => $participants['parents'],
            'students' => $participants['students'],
            'staff' => $participants['staff'],
            'sms_enabled' => $smsEnabled,
            'sms_message' => $smsEnabled === 1 && $smsAudiences['student'] === 1 ? $smsMessage : null,
            'staff_sms_message' => $smsEnabled === 1 && $smsAudiences['staff'] === 1 ? $staffSmsMessage : null,
            'send_type' => $smsEnabled === 1 && $smsAudiences['student'] === 1 ? $sendType : 0,
            'sms_target_year' => $smsEnabled === 1 && $smsAudiences['student'] === 1 ? $this->sanitizeNullableInt($smsTargetYear) : null,
            'sms_target_level_id' => $smsEnabled === 1 && $smsAudiences['student'] === 1 && $sendType === 2 ? $this->sanitizeNullableInt($this->request->getPost('sms_level_id')) : null,
            'sms_target_class_id' => $smsEnabled === 1 && $smsAudiences['student'] === 1 && $sendType === 2 ? $this->sanitizeNullableInt($this->request->getPost('sms_class_id')) : null,
            'sms_target_stream_id' => $smsEnabled === 1 && $smsAudiences['student'] === 1 && $sendType === 2 ? $this->sanitizeNullableInt($this->request->getPost('sms_stream_id')) : null,
            'sms_target_status' => $smsEnabled === 1 && $smsAudiences['student'] === 1 ? $this->sanitizeNullableInt($smsTargetStatus) : null,
            'before_sms_sent_at' => $smsEnabled === 0 ? null : ($shouldResetSchedule ? null : ($existingEventItem->before_sms_sent_at ?? null)),
            'event_sms_sent_at' => $smsEnabled === 0 ? null : ($shouldResetSchedule ? null : ($existingEventItem->event_sms_sent_at ?? null)),
            'status' => $this->request->getPost('status') ?: 1,
        ];
        $this->applySchoolCalendarSmsAudienceData($data, $smsAudiences);

        $this->studentModel->update_table_details(
            'school_calendar_tbl',
            ['id' => $eventId],
            $data
        );
        $this->syncSchoolCalendarRecipients($eventId, $selectedStudentIds);
        $this->syncSchoolCalendarStaffRecipients($eventId, $selectedStaffIds);
        $this->syncSchoolCalendarSmsSchedules($eventId, $smsEnabled === 1 ? $smsSchedules : []);

        echo json_encode([
            'status' => '0',
            'statusDesc' => 'School calendar event updated successful'
        ]);
    }

    public function delete_school_calendar()
    {
        $id = $this->request->getPost('id');

        $this->db->table('school_calendar_sms_recipients_tbl')->where('calendar_id', $id)->delete();
        if ($this->db->query("SHOW TABLES LIKE 'school_calendar_sms_staff_recipients_tbl'")->getNumRows() > 0) {
            $this->db->table('school_calendar_sms_staff_recipients_tbl')->where('calendar_id', $id)->delete();
        }
        if ($this->supportsSchoolCalendarSmsScheduleTable()) {
            $this->db->table('school_calendar_sms_schedule_tbl')->where('calendar_id', $id)->delete();
        }
        $this->studentModel->deletetable_data1('school_calendar_tbl', $id);

        echo json_encode([
            'status' => '0',
            'statusDesc' => 'School calendar event deleted successful'
        ]);
    }

    public function send_school_calendar_now()
    {
        $id = (int) $this->request->getPost('id');
        $event = $this->studentModel->gettable_data('school_calendar_tbl', ['id' => $id]);
        $eventItem = $event[0] ?? null;
        $sendStudentAudience = $this->isSchoolCalendarStudentSmsAudienceEnabled($eventItem);
        $sendStaffAudience = $this->isSchoolCalendarStaffSmsAudienceEnabled($eventItem);

        if (! $eventItem) {
            return $this->response->setJSON([
                'status' => '1',
                'statusDesc' => 'School calendar event not found.'
            ]);
        }

        if (
            (int) ($eventItem->sms_enabled ?? 0) !== 1
        ) {
            return $this->response->setJSON([
                'status' => '1',
                'statusDesc' => 'This event does not have an SMS message ready to send.'
            ]);
        }

        if (! $sendStudentAudience && ! $sendStaffAudience) {
            return $this->response->setJSON([
                'status' => '1',
                'statusDesc' => 'This event does not have any SMS audience selected.'
            ]);
        }

        $studentContacts = $sendStudentAudience ? $this->getSchoolCalendarStudentContacts($eventItem) : [];
        $staffContacts = $sendStaffAudience ? $this->getSchoolCalendarStaffContacts($eventItem) : [];
        $studentMessageReady = $sendStudentAudience && trim((string) ($eventItem->sms_message ?? '')) !== '';
        $staffMessageReady = $sendStaffAudience && trim((string) ($eventItem->staff_sms_message ?? '')) !== '';

        if (! $studentMessageReady && ! $staffMessageReady) {
            return $this->response->setJSON([
                'status' => '1',
                'statusDesc' => 'This event does not have an SMS message ready to send.'
            ]);
        }

        if (empty($studentContacts) && empty($staffContacts)) {
            return $this->response->setJSON([
                'status' => '1',
                'statusDesc' => 'No recipients found for this event.'
            ]);
        }

        $tmsg = $this->studentModel->gettable_data('message_status_tbl', ['status' => 1]);
        if (count($tmsg) === 0) {
            return $this->response->setJSON([
                'status' => '1',
                'statusDesc' => 'SMS service is currently turned off.'
            ]);
        }

        $sendSummary = $this->sendSchoolCalendarGroupedMessages($eventItem, $studentContacts, $staffContacts);
        $sentCount = $sendSummary['total'];
        $sentGroups = [];

        if ($sendSummary['student'] > 0) {
            $sentGroups[] = $sendSummary['student'] . ' student/parent';
        }

        if ($sendSummary['staff'] > 0) {
            $sentGroups[] = $sendSummary['staff'] . ' staff';
        }

        if ($sentCount === 0) {
            return $this->response->setJSON([
                'status' => '1',
                'statusDesc' => 'No valid phone numbers found for the selected recipients.'
            ]);
        }

        return $this->response->setJSON([
            'status' => '0',
            'statusDesc' => 'School calendar SMS sent successfully to ' . implode(' and ', $sentGroups) . '.'
        ]);
    }

    public function school_calendar_sms_group()
    {
        $data = [
            'students' => $this->getSchoolCalendarStudents([
                'year' => $this->request->getPost('sms_year') ?: date('Y'),
                'classlevel' => $this->request->getPost('sms_level_id') ?: 0,
                'class' => $this->request->getPost('sms_class_id') ?: 0,
                'stream' => $this->request->getPost('sms_stream_id') ?: 0,
                'status' => $this->request->getPost('sms_status') ?: 0,
            ]),
            'selected_student_ids' => $this->getSelectedSchoolCalendarStudentIdsFromRequest(),
            'mode' => $this->request->getPost('mode') ?: 'add',
            'empty_message' => 'No students found for the selected group filters.',
        ];

        echo view('system/forms/school_calendar_sms_recipients', $data);
    }

    public function school_calendar_sms_individual()
    {
        $search = trim((string) $this->request->getPost('student_search'));
        $students = [];
        $emptyMessage = 'Search a student name or admission number to load recipients.';

        if ($search !== '') {
            $students = $this->getSchoolCalendarStudents([
                'year' => $this->request->getPost('sms_year') ?: date('Y'),
                'status' => $this->request->getPost('sms_status') ?: 0,
                'search' => $search,
            ]);
            $emptyMessage = 'No students found for that search.';
        }

        $data = [
            'students' => $students,
            'selected_student_ids' => $this->getSelectedSchoolCalendarStudentIdsFromRequest(),
            'mode' => $this->request->getPost('mode') ?: 'add',
            'empty_message' => $emptyMessage,
        ];

        echo view('system/forms/school_calendar_sms_recipients', $data);
    }

    public function school_calendar_sms_staff()
    {
        $data = [
            'staffs' => $this->getSchoolCalendarStaffs(
                trim((string) $this->request->getPost('staff_search')),
                null
            ),
            'selected_staff_ids' => $this->getSelectedSchoolCalendarStaffIdsFromRequest(),
            'mode' => $this->request->getPost('mode') ?: 'add',
            'empty_message' => 'No staff found for that search.',
        ];

        echo view('system/forms/school_calendar_staff_recipients', $data);
    }

    private function getSchoolCalendarFormData(): array
    {
        $currentYear = (int) date('Y');
        $years = [];

        for ($year = 2023; $year <= $currentYear + 1; $year++) {
            $years[] = $year;
        }

        return [
            'levels' => $this->report->get_levels(),
            'student_statuses' => $this->studentModel->getnationalities('student_types_tbl'),
            'year_options' => $years,
            'current_year' => $currentYear,
        ];
    }

    private function supportsSchoolCalendarSmsAudienceColumns(): bool
    {
        if ($this->schoolCalendarSmsAudienceColumnsAvailable !== null) {
            return (bool) $this->schoolCalendarSmsAudienceColumnsAvailable;
        }

        $this->schoolCalendarSmsAudienceColumnsAvailable =
            $this->db->fieldExists('sms_to_students', 'school_calendar_tbl')
            && $this->db->fieldExists('sms_to_staff', 'school_calendar_tbl');

        return (bool) $this->schoolCalendarSmsAudienceColumnsAvailable;
    }

    private function supportsSchoolCalendarSmsScheduleTable(): bool
    {
        if ($this->schoolCalendarSmsScheduleTableAvailable !== null) {
            return (bool) $this->schoolCalendarSmsScheduleTableAvailable;
        }

        $this->schoolCalendarSmsScheduleTableAvailable = $this->db->tableExists('school_calendar_sms_schedule_tbl');

        return (bool) $this->schoolCalendarSmsScheduleTableAvailable;
    }

    private function getSchoolCalendarSmsAudiencesFromRequest(array $participants, int $smsEnabled): array
    {
        $studentParticipantAvailable = $participants['parents'] === 1 || $participants['students'] === 1;
        $staffParticipantAvailable = $participants['staff'] === 1;

        return [
            'student' => $smsEnabled === 1 && $studentParticipantAvailable && $this->request->getPost('sms_to_students') ? 1 : 0,
            'staff' => $smsEnabled === 1 && $staffParticipantAvailable && $this->request->getPost('sms_to_staff') ? 1 : 0,
        ];
    }

    private function applySchoolCalendarSmsAudienceData(array &$data, array $smsAudiences): void
    {
        if (! $this->supportsSchoolCalendarSmsAudienceColumns()) {
            return;
        }

        $data['sms_to_students'] = ! empty($smsAudiences['student']) ? 1 : 0;
        $data['sms_to_staff'] = ! empty($smsAudiences['staff']) ? 1 : 0;
    }

    private function isSchoolCalendarStudentSmsAudienceEnabled($eventItem): bool
    {
        if (! is_object($eventItem)) {
            return false;
        }

        if ($this->supportsSchoolCalendarSmsAudienceColumns() && property_exists($eventItem, 'sms_to_students')) {
            return (int) ($eventItem->sms_to_students ?? 0) === 1;
        }

        return (int) ($eventItem->parents ?? 0) === 1 || (int) ($eventItem->students ?? 0) === 1;
    }

    private function isSchoolCalendarStaffSmsAudienceEnabled($eventItem): bool
    {
        if (! is_object($eventItem)) {
            return false;
        }

        if ($this->supportsSchoolCalendarSmsAudienceColumns() && property_exists($eventItem, 'sms_to_staff')) {
            return (int) ($eventItem->sms_to_staff ?? 0) === 1;
        }

        return (int) ($eventItem->staff ?? 0) === 1;
    }

    private function getSchoolCalendarSmsSchedulesFromRequest(): array
    {
        $scheduleRows = [];

        foreach ((array) $this->request->getPost('sms_schedule_at') as $scheduleAt) {
            $scheduleAt = trim((string) $scheduleAt);
            if ($scheduleAt === '') {
                continue;
            }

            $timestamp = strtotime(str_replace('T', ' ', $scheduleAt));
            if ($timestamp === false) {
                continue;
            }

            $normalized = date('Y-m-d H:i:00', $timestamp);
            $scheduleRows[$normalized] = [
                'scheduled_at' => $normalized,
            ];
        }

        ksort($scheduleRows);

        return array_values($scheduleRows);
    }

    private function getSchoolCalendarScheduleSignature(array $scheduleRows): array
    {
        $signature = [];

        foreach ($scheduleRows as $scheduleRow) {
            $signature[] = (string) ($scheduleRow['scheduled_at'] ?? '');
        }

        sort($signature);

        return $signature;
    }

    private function getSchoolCalendarEventSmsSchedules($eventItem): array
    {
        if (! is_object($eventItem)) {
            return [];
        }

        if ($this->supportsSchoolCalendarSmsScheduleTable()) {
            $scheduleRows = $this->db->table('school_calendar_sms_schedule_tbl')
                ->select('scheduled_at, sent_at')
                ->where('calendar_id', (int) $eventItem->id)
                ->orderBy('scheduled_at', 'ASC')
                ->get()
                ->getResultArray();

            if (! empty($scheduleRows)) {
                return array_map(function (array $scheduleRow) {
                    return [
                        'scheduled_at' => $scheduleRow['scheduled_at'],
                        'scheduled_at_input' => date('Y-m-d\TH:i', strtotime($scheduleRow['scheduled_at'])),
                        'sent_at' => $scheduleRow['sent_at'],
                    ];
                }, $scheduleRows);
            }
        }

        if ((int) ($eventItem->sms_enabled ?? 0) !== 1) {
            return [];
        }

        $legacySchedules = [
            [
                'scheduled_at' => date('Y-m-d H:i:00', strtotime($eventItem->event_date . ' 11:00:00 -1 day')),
                'sent_at' => $eventItem->before_sms_sent_at ?? null,
            ],
            [
                'scheduled_at' => date('Y-m-d H:i:00', strtotime($eventItem->event_date . ' 08:00:00')),
                'sent_at' => $eventItem->event_sms_sent_at ?? null,
            ],
        ];

        return array_map(function (array $scheduleRow) {
            return [
                'scheduled_at' => $scheduleRow['scheduled_at'],
                'scheduled_at_input' => date('Y-m-d\TH:i', strtotime($scheduleRow['scheduled_at'])),
                'sent_at' => $scheduleRow['sent_at'],
            ];
        }, $legacySchedules);
    }

    private function syncSchoolCalendarSmsSchedules(int $eventId, array $scheduleRows): void
    {
        if (! $this->supportsSchoolCalendarSmsScheduleTable()) {
            return;
        }

        $existingRows = $this->db->table('school_calendar_sms_schedule_tbl')
            ->select('scheduled_at, sent_at, created_date')
            ->where('calendar_id', $eventId)
            ->get()
            ->getResultArray();

        $existingLookup = [];
        foreach ($existingRows as $existingRow) {
            $existingLookup[$existingRow['scheduled_at']] = $existingRow;
        }

        $this->db->table('school_calendar_sms_schedule_tbl')->where('calendar_id', $eventId)->delete();

        if (empty($scheduleRows)) {
            return;
        }

        $insertRows = [];
        foreach ($scheduleRows as $scheduleRow) {
            $scheduledAt = (string) ($scheduleRow['scheduled_at'] ?? '');
            if ($scheduledAt === '') {
                continue;
            }

            $existingRow = $existingLookup[$scheduledAt] ?? null;
            $insertRows[] = [
                'calendar_id' => $eventId,
                'scheduled_at' => $scheduledAt,
                'sent_at' => $existingRow['sent_at'] ?? null,
                'created_date' => $existingRow['created_date'] ?? date('Y-m-d H:i:s'),
            ];
        }

        if (! empty($insertRows)) {
            $this->db->table('school_calendar_sms_schedule_tbl')->insertBatch($insertRows);
        }
    }

    private function getSelectedSchoolCalendarStudentIdsFromRequest(): array
    {
        $selectedStudentIds = array_map('intval', (array) $this->request->getPost('selected_students'));
        $selectedStudentIds = array_values(array_unique(array_filter($selectedStudentIds)));
        sort($selectedStudentIds);

        return $selectedStudentIds;
    }

    private function getSelectedSchoolCalendarStaffIdsFromRequest(): array
    {
        $selectedStaffIds = array_map('intval', (array) $this->request->getPost('selected_staff'));
        $selectedStaffIds = array_values(array_unique(array_filter($selectedStaffIds)));
        sort($selectedStaffIds);

        return $selectedStaffIds;
    }

    private function getSchoolCalendarEventSelectedStudentIds(int $eventId): array
    {
        $recipientRows = $this->db->table('school_calendar_sms_recipients_tbl')
            ->select('student_id')
            ->where('calendar_id', $eventId)
            ->orderBy('student_id', 'ASC')
            ->get()
            ->getResult();

        return array_map(static function ($row) {
            return (int) $row->student_id;
        }, $recipientRows);
    }

    private function getSchoolCalendarEventSelectedStaffIds(int $eventId): array
    {
        if ($this->db->query("SHOW TABLES LIKE 'school_calendar_sms_staff_recipients_tbl'")->getNumRows() === 0) {
            return [];
        }

        $recipientRows = $this->db->table('school_calendar_sms_staff_recipients_tbl')
            ->select('staff_id')
            ->where('calendar_id', $eventId)
            ->orderBy('staff_id', 'ASC')
            ->get()
            ->getResult();

        return array_map(static function ($row) {
            return (int) $row->staff_id;
        }, $recipientRows);
    }

    private function getSchoolCalendarStudents(array $filters = [], ?array $studentIds = null): array
    {
        if ($studentIds !== null) {
            $studentIds = array_values(array_unique(array_filter(array_map('intval', $studentIds))));
            if (empty($studentIds)) {
                return [];
            }
        }

        $builder = $this->db->table('admission_tbl');
        $builder->select('
            students.id,
            students.first_name,
            students.full_name,
            students.student_id AS admission_number,
            admission_tbl.academic_year,
            admission_tbl.status AS admission_status,
            classes_tbl.class_name,
            streams_tbl.stream_name,
            class_level_tbl.level_name,
            MIN(parents_tbl.phone1) AS parent_phone
        ');
        $builder->join('classes_tbl', 'classes_tbl.id = admission_tbl.class_id');
        $builder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id');
        $builder->join('streams_tbl', 'streams_tbl.id = admission_tbl.stream_id');
        $builder->join('students', 'students.id = admission_tbl.student_id');
        $builder->join('parents_students_tbl', 'parents_students_tbl.student_id = admission_tbl.student_id', 'left');
        $builder->join('parents_tbl', 'parents_tbl.id = parents_students_tbl.parent_id', 'left');

        if ($studentIds !== null) {
            $builder->whereIn('admission_tbl.student_id', $studentIds);
            if (! empty($filters['year'])) {
                $builder->where('admission_tbl.academic_year', (int) $filters['year']);
            }
        } else {
            $builder->where('admission_tbl.academic_year', (int) ($filters['year'] ?? date('Y')));

            if (! empty($filters['classlevel'])) {
                $builder->where('admission_tbl.level_id', (int) $filters['classlevel']);
            }
            if (! empty($filters['class'])) {
                $builder->where('admission_tbl.class_id', (int) $filters['class']);
            }
            if (! empty($filters['stream'])) {
                $builder->where('admission_tbl.stream_id', (int) $filters['stream']);
            }

            $normalizedStatus = $this->normalizeSchoolCalendarStudentStatus($filters['status'] ?? 0);
            if ($normalizedStatus > 0) {
                $builder->where('admission_tbl.status', $normalizedStatus);
            }

            $search = trim((string) ($filters['search'] ?? ''));
            if ($search !== '') {
                $builder->groupStart();
                $builder->like('students.full_name', $search);
                $builder->orLike('students.student_id', $search);
                $builder->groupEnd();
            }
        }

        $builder->groupBy('students.id');
        $builder->groupBy('students.first_name');
        $builder->groupBy('students.full_name');
        $builder->groupBy('students.student_id');
        $builder->groupBy('admission_tbl.academic_year');
        $builder->groupBy('admission_tbl.status');
        $builder->groupBy('classes_tbl.class_name');
        $builder->groupBy('streams_tbl.stream_name');
        $builder->groupBy('class_level_tbl.level_name');
        $builder->orderBy('students.full_name', 'ASC');

        return $builder->get()->getResult();
    }

    private function getSchoolCalendarStaffs(string $search = '', ?array $staffIds = null): array
    {
        $builder = $this->db->table('users');
        $builder->select('user_id, first_name, last_name, phone_no');
        $builder->where('staff', 1);
        $builder->where('status', 1);

        if ($staffIds !== null) {
            $staffIds = array_values(array_unique(array_filter(array_map('intval', $staffIds))));
            if (empty($staffIds)) {
                return [];
            }
            $builder->whereIn('user_id', $staffIds);
        }

        $search = trim($search);
        if ($search !== '') {
            $builder->groupStart();
            $builder->like('first_name', $search);
            $builder->orLike('last_name', $search);
            $builder->orLike('phone_no', $search);
            $builder->groupEnd();
        }

        $builder->orderBy('first_name', 'ASC');
        $builder->orderBy('last_name', 'ASC');

        return $builder->get()->getResult();
    }

    private function normalizeSchoolCalendarStudentStatus($status): int
    {
        if ((string) $status === '2') {
            return 1;
        }

        if ((string) $status === '1') {
            return 2;
        }

        return (int) $status;
    }

    private function sanitizeNullableInt($value): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }

        return (int) $value;
    }

    private function syncSchoolCalendarRecipients(int $eventId, array $studentIds): void
    {
        $studentIds = array_values(array_unique(array_filter(array_map('intval', $studentIds))));
        $this->db->table('school_calendar_sms_recipients_tbl')->where('calendar_id', $eventId)->delete();

        if (empty($studentIds)) {
            return;
        }

        $recipientRows = [];
        foreach ($studentIds as $studentId) {
            $recipientRows[] = [
                'calendar_id' => $eventId,
                'student_id' => $studentId,
                'created_date' => date('Y-m-d H:i:s'),
            ];
        }

        $this->db->table('school_calendar_sms_recipients_tbl')->insertBatch($recipientRows);
    }

    private function syncSchoolCalendarStaffRecipients(int $eventId, array $staffIds): void
    {
        if ($this->db->query("SHOW TABLES LIKE 'school_calendar_sms_staff_recipients_tbl'")->getNumRows() === 0) {
            return;
        }

        $staffIds = array_values(array_unique(array_filter(array_map('intval', $staffIds))));
        $this->db->table('school_calendar_sms_staff_recipients_tbl')->where('calendar_id', $eventId)->delete();

        if (empty($staffIds)) {
            return;
        }

        $recipientRows = [];
        foreach ($staffIds as $staffId) {
            $recipientRows[] = [
                'calendar_id' => $eventId,
                'staff_id' => $staffId,
                'created_date' => date('Y-m-d H:i:s'),
            ];
        }

        $this->db->table('school_calendar_sms_staff_recipients_tbl')->insertBatch($recipientRows);
    }

    private function getSchoolCalendarStudentContacts($eventItem): array
    {
        $contacts = [];
        $studentRecipients = $this->db->table('school_calendar_sms_recipients_tbl scr')
            ->select('students.id, students.first_name, students.full_name, MIN(parents_tbl.phone1) AS parent_phone')
            ->join('students', 'students.id = scr.student_id')
            ->join('parents_students_tbl', 'parents_students_tbl.student_id = scr.student_id', 'left')
            ->join('parents_tbl', 'parents_tbl.id = parents_students_tbl.parent_id', 'left')
            ->where('scr.calendar_id', $eventItem->id)
            ->groupBy('students.id')
            ->groupBy('students.first_name')
            ->groupBy('students.full_name')
            ->get()
            ->getResult();

        foreach ($studentRecipients as $student) {
            if (empty($student->parent_phone)) {
                continue;
            }

            $phoneKey = preg_replace('/[^0-9]/', '', $student->parent_phone);
            if ($phoneKey === '') {
                continue;
            }

            $contacts[$phoneKey] = [
                'phone' => $student->parent_phone,
                'reference_no' => $student->id,
                'student_first_name' => $student->first_name,
                'student_full_name' => $student->full_name,
            ];
        }

        return array_values($contacts);
    }

    private function getSchoolCalendarStaffContacts($eventItem): array
    {
        if ($this->db->query("SHOW TABLES LIKE 'school_calendar_sms_staff_recipients_tbl'")->getNumRows() === 0) {
            return [];
        }

        $contacts = [];
        $staffRecipients = $this->db->table('school_calendar_sms_staff_recipients_tbl scr')
            ->select('users.user_id, users.first_name, users.last_name, users.phone_no')
            ->join('users', 'users.user_id = scr.staff_id')
            ->where('scr.calendar_id', $eventItem->id)
            ->where('users.status', 1)
            ->get()
            ->getResult();

        foreach ($staffRecipients as $staff) {
            if (empty($staff->phone_no)) {
                continue;
            }

            $phoneKey = preg_replace('/[^0-9]/', '', $staff->phone_no);
            if ($phoneKey === '') {
                continue;
            }

            $contacts[$phoneKey] = [
                'phone' => $staff->phone_no,
                'reference_no' => $staff->user_id,
                'staff_first_name' => $staff->first_name,
                'staff_full_name' => trim($staff->first_name . ' ' . $staff->last_name),
            ];
        }

        return array_values($contacts);
    }

    private function prepareSchoolCalendarMessage($eventItem, array $contact): string
    {
        $message = (string) ($eventItem->sms_message ?? '');
        $replacements = [
            '#studentFirstName' => $contact['student_first_name'] ?? '',
            '#studentFullName' => $contact['student_full_name'] ?? '',
            '#eventDate' => date('d/m/Y', strtotime($eventItem->event_date)),
            '#eventDescription' => $eventItem->event_description,
        ];

        return str_replace(array_keys($replacements), array_values($replacements), $message);
    }

    private function prepareSchoolCalendarStaffMessage($eventItem, array $contact): string
    {
        $message = (string) ($eventItem->staff_sms_message ?? '');
        $replacements = [
            '#staffFirstName' => $contact['staff_first_name'] ?? '',
            '#staffFullName' => $contact['staff_full_name'] ?? '',
            '#eventDate' => date('d/m/Y', strtotime($eventItem->event_date)),
            '#eventDescription' => $eventItem->event_description,
        ];

        return str_replace(array_keys($replacements), array_values($replacements), $message);
    }

    private function generateSchoolCalendarMsgNo(): int
    {
        $tkens = $this->studentModel->get_max_id('message_groups_tbl', 'send_number');
        if (count($tkens) > 0) {
            return (int) $tkens[0]->max_id + 1;
        }

        return 1;
    }

    private function sendSchoolCalendarSms($dest, $msg, $type, $refNo, $snn): void
    {
        $messag = $this->stym->load_messages_balances();
        $senderid = constant('SENDER_ID_' . session()->get('db_id'));
        if (! $senderid || count($messag) === 0) {
            return;
        }

        $timeSent = time();
        $apiKey = API_KEY;
        $destination = preg_replace('/[^0-9]/', '', $dest);
        $message = rawurlencode(trim($msg));
        $senderid = urlencode($senderid);

        $fetch = file_get_contents("https://www.sms.co.tz/api.php?do=sms&api_key={$apiKey}&senderid={$senderid}&dest={$destination}&msg={$message}");
        list($status, $note, $smsid) = explode(',', $fetch);

        if ($status === 'OK') {
            $msgid = $smsid;
            $sntStatus = 1;
            $cost = 45;
            $accCost = $cost;
        } else {
            $msgid = '';
            $sntStatus = 2;
            $cost = 45;
            $accCost = $cost;
        }

        $tempsmsdata = [
            'message_type' => $type,
            'phone_no' => str_replace(' ', '', $dest),
            'message' => $msg,
            'cost' => $cost,
            'created_at' => $timeSent,
            'message_id' => $msgid,
            'status' => $status,
            'status_description' => $note,
            'sent_status' => $sntStatus,
            'send_no' => $snn,
            'reference_no' => $refNo
        ];

        $this->studentModel->SaveData('messages', $tempsmsdata);

        $balance = ($messag[0]->balance - $accCost);
        $smsDt = [
            'balance' => $balance,
            'created_at' => date('Y/m/d H:i:s')
        ];
        $this->stym->update_sms_balance($smsDt, $messag[0]->b_id);
    }

    private function buildSchoolCalendarMessageSummary($eventItem, bool $includeStudentAudience, bool $includeStaffAudience): string
    {
        $parts = [];

        if ($includeStudentAudience && trim((string) ($eventItem->sms_message ?? '')) !== '') {
            $parts[] = 'Student/Parent: ' . trim((string) $eventItem->sms_message);
        }

        if ($includeStaffAudience && trim((string) ($eventItem->staff_sms_message ?? '')) !== '') {
            $parts[] = 'Staff: ' . trim((string) $eventItem->staff_sms_message);
        }

        return implode(' | ', $parts);
    }

    private function sendSchoolCalendarGroupedMessages($eventItem, array $studentContacts, array $staffContacts): array
    {
        $sendStudentAudience = ! empty($studentContacts) && trim((string) ($eventItem->sms_message ?? '')) !== '';
        $sendStaffAudience = ! empty($staffContacts) && trim((string) ($eventItem->staff_sms_message ?? '')) !== '';

        if (! $sendStudentAudience && ! $sendStaffAudience) {
            return ['total' => 0, 'student' => 0, 'staff' => 0];
        }

        $snn = $this->generateSchoolCalendarMsgNo();
        $smsdata = [
            'send_type' => ! empty($eventItem->send_type) ? $eventItem->send_type : 2,
            'message_type' => 18,
            'send_number' => $snn,
            'massage_date' => date('Y-m-d H:i:s'),
            'send_by' => $_SESSION['user_id'],
            'messagex' => $this->buildSchoolCalendarMessageSummary($eventItem, $sendStudentAudience, $sendStaffAudience),
            'trans_number' => $eventItem->id
        ];

        $this->studentModel->SaveData('message_groups_tbl', $smsdata);

        $studentSent = $sendStudentAudience
            ? $this->sendSchoolCalendarAudienceMessages($eventItem, $studentContacts, 'student', $snn)
            : 0;
        $staffSent = $sendStaffAudience
            ? $this->sendSchoolCalendarAudienceMessages($eventItem, $staffContacts, 'staff', $snn)
            : 0;

        return [
            'total' => $studentSent + $staffSent,
            'student' => $studentSent,
            'staff' => $staffSent,
        ];
    }

    private function sendSchoolCalendarAudienceMessages($eventItem, array $contacts, string $audience, int $snn): int
    {
        $sentCount = 0;
        foreach ($contacts as $contact) {
            $cleanPhone = $this->sanitizeSchoolCalendarPhone($contact['phone']);
            if (! $cleanPhone) {
                continue;
            }

            $message = $audience === 'staff'
                ? $this->prepareSchoolCalendarStaffMessage($eventItem, $contact)
                : $this->prepareSchoolCalendarMessage($eventItem, $contact);

            try {
                $this->sendSchoolCalendarSms($cleanPhone, $message, 18, $contact['reference_no'], $snn);
                $sentCount++;
            } catch (\Throwable $e) {
                log_message('error', 'School calendar ' . $audience . ' SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
            }
        }

        return $sentCount;
    }

    private function sanitizeSchoolCalendarPhone($phone)
    {
        $phone = preg_replace('/\D+/', '', (string) $phone);

        if (substr($phone, 0, 5) === '00255') {
            $phone = substr($phone, 2);
        }

        if (substr($phone, 0, 1) === '0' && strlen($phone) === 10) {
            $phone = '255' . substr($phone, 1);
        }

        if (substr($phone, 0, 3) === '255' && strlen($phone) === 12) {
            return $phone;
        }

        return false;
    }

    public function messages_template()
    {
        return view('templates/header')
        .view('system/messages_template')
        .view('templates/footer');
    }

    public function make_newDeposit(){

        $amount = $this->request->getPost('depost');
        
        $blnc_amount = $this->stym->load_messages_balances();

        $blnc = $blnc_amount[0]->balance + $amount;

        if($blnc_amount[0]->balance == ""){
            $data2 = [
                'balance' => $amount,
                'created_at' => date('Y/m/d H:i:s')
            ];
            $this->stym->save_messages_balances('messages_balances',$data2);
        }else{
            $data2 = [
                'balance' => $blnc,
                'created_at' => date('Y/m/d H:i:s')
            ];
            $id = $blnc_amount[0]->b_id;

            $this->stym->update_messages_balances($id,$data2);
        }
        

        $data = [
            'deposit_amount' => $amount,
            'created_by' => $_SESSION['user_id'],
            'created_at' => date('Y/m/d H:i:s')
        ];

        $deposit = $this->stym->save_messages_balances('messages_deposits',$data);
        echo json_encode(array('status' =>'0','statusDesc' => 'New Deposit Added Successful'));
    }

    public function load_messages_details()
    {
        $date = $this->request->getPost('mdate');

        list($startingdate, $endingdate) = explode('-', $date);
        $enddate = strtotime($endingdate . ' 23:59:59');
        $startdate = strtotime($startingdate);

        $msgs = $this->stym->load_messages($startdate,$enddate);
        $groupedMsgs = $this->mergeSchoolCalendarMessageGroups($msgs);
        $messges =array();
        $type = "";
        $msg = "";
          
        if(count($groupedMsgs) > 0){
            foreach ($groupedMsgs as $groupedMessage) {
                $m = $groupedMessage['group'];
                $sendNumbers = $groupedMessage['send_numbers'];
                $ttlmsg = $this->getMessagesBySendNumbers($sendNumbers);

                if (count($ttlmsg) <= 5) {
                    foreach ($ttlmsg as $messageItem) {
                        if (!empty($messageItem->message_id) && empty($messageItem->time_sent)) {
                            $this->check_sms($messageItem->message_id);
                        }
                    }
                }

                $msg_type=$this->studentModel->gettable_data('message_types_tbl',$where = array('id' => $m->message_type));
             $type="";
             if(count($msg_type)>0){
                $type =$msg_type[0]->type; 
             }
               
                //-------------------------------------//

                if($m->reference_no == '')
                    $msg = "";
                else
                    $msg = $m->reference_no;

                if($m->time_sent==''){
                 $sent='';
                }else{
                 $sent=$m->time_sent;
                }
                 if($m->send_type==1){
                 $send='Individual';
                }else{
                 $send='Group';
                }
                $user=$this->studentModel->gettable_data('users',$where = array('user_id' => $m->send_by));
              if(count($user)>0){
                $n=count($ttlmsg);
                $totalCost = 0;
                foreach ($ttlmsg as $messageCostItem) {
                    $totalCost += (int) ($messageCostItem->cost ?? 0);
                }
                $messges[] = array(
                    'type' => $type,
                    'massage_date' => $m->massage_date,
                    'sender_type' => $send,
                    'message' => $this->buildMergedSchoolCalendarListMessage($groupedMessage['rows']),
                    'user' => $user[0]->first_name,
                    'cost' => number_format($totalCost),
                    'send_number' => implode(',', $sendNumbers),
                    'pax' => $n
                );
                // $messges[] = $m;
                //print_r($messges);
            }
            }
        }
        echo json_encode($messges);
    }

    private function mergeSchoolCalendarMessageGroups(array $msgs): array
    {
        $mergedGroups = [];
        $usedIndexes = [];

        foreach ($msgs as $index => $msg) {
            if (isset($usedIndexes[$index])) {
                continue;
            }

            $groupRows = [$msg];
            $sendNumbers = [(int) $msg->send_number];
            $usedIndexes[$index] = true;

            if ((int) $msg->message_type === 18) {
                $baseTime = strtotime($msg->massage_date);

                foreach ($msgs as $innerIndex => $innerMsg) {
                    if (isset($usedIndexes[$innerIndex]) || $innerIndex === $index) {
                        continue;
                    }

                    if (
                        (int) $innerMsg->message_type === 18
                        && (int) $innerMsg->trans_number === (int) $msg->trans_number
                        && (int) $innerMsg->send_by === (int) $msg->send_by
                        && abs(strtotime($innerMsg->massage_date) - $baseTime) <= 10
                    ) {
                        $groupRows[] = $innerMsg;
                        $sendNumbers[] = (int) $innerMsg->send_number;
                        $usedIndexes[$innerIndex] = true;
                    }
                }
            }

            sort($sendNumbers);
            $mergedGroups[] = [
                'group' => $msg,
                'rows' => $groupRows,
                'send_numbers' => $sendNumbers,
            ];
        }

        return $mergedGroups;
    }

    private function getMessagesBySendNumbers(array $sendNumbers): array
    {
        $sendNumbers = array_values(array_unique(array_filter(array_map('intval', $sendNumbers))));
        if (empty($sendNumbers)) {
            return [];
        }

        return $this->db->table('messages')
            ->whereIn('send_no', $sendNumbers)
            ->orderBy('mid', 'ASC')
            ->get()
            ->getResult();
    }

    private function getMessageGroupsBySendNumbers(array $sendNumbers): array
    {
        $sendNumbers = array_values(array_unique(array_filter(array_map('intval', $sendNumbers))));
        if (empty($sendNumbers)) {
            return [];
        }

        return $this->db->table('message_groups_tbl')
            ->whereIn('send_number', $sendNumbers)
            ->orderBy('send_number', 'ASC')
            ->get()
            ->getResult();
    }

    private function buildMergedSchoolCalendarListMessage(array $groupRows): string
    {
        $messages = [];

        foreach ($groupRows as $groupRow) {
            $message = trim((string) ($groupRow->messagex ?? ''));
            if ($message !== '' && ! in_array($message, $messages, true)) {
                $messages[] = $message;
            }
        }

        return implode(' | ', $messages);
    }

    public function save_Template_Details()
    {
        $data = [
            'title' => ucfirst($this->request->getPost('title')),
            'message' => ucfirst($this->request->getPost('message')),
            'created_by' => $_SESSION['user_id']
        ];

        $this->stym->save_messages_balances('messages_templates',$data);
        echo json_encode(array('status' =>'0','statusDesc' => 'New Template Created Successful'));
    }

    public function manage_Template_Details()
    {
        $id = $this->request->getVar('id');
        $data['template'] = $this->stym->get_messages_details('messages_templates', $where = array('m_id' => $id));

        echo view('system/manage_smsTemplate',$data);
    }

    public function Update_messagesTemp()
    {
        $data = [
            'm_id' => $this->request->getPost('msg_id'),
            'title' => ucfirst($this->request->getPost('title')),
            'message' => ucfirst($this->request->getPost('message')),
            'created_by' => $_SESSION['user_id']
        ];

        $this->stym->update_table_details('messages_templates',$where = array('m_id' => $this->request->getPost('msg_id')),$data);
        echo json_encode(array('status' =>'0','statusDesc' => 'Template Updated Successful'));
        // echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
        //     <span class="glyphicon glyphicon-ok"></span>Updated Successfully.</div> ';
    }
     function check_sms($msgid){
         if (empty($msgid)) {
             return;
         }

         $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_CONNECTTIMEOUT => 2,
            CURLOPT_TIMEOUT => 3,
            CURLOPT_URL => 'http://www.sms.co.tz/api.php?do=dlr&id=' . $msgid . '&username=' . SMS_UNAME . '&password=' . SMS_PASSWORD . '&senderid=' . SENDER_ID . '',
        ));
        $msg_status = curl_exec($curl);
        if ($msg_status === false || $msg_status === '') {
            curl_close($curl);
            return;
        }
        curl_close($curl);
       // echo $msg_status;
        //$err = curl_error($msg_status); 
     $parts = explode(',', $msg_status);
     if (count($parts) < 2) {
         return;
     }
     list($err,$er)= $parts;
     if($err=='ERR'){
          //  echo $err;
            }else{
             
            
        if($msg_status != ""){
       
           $dlrParts = explode(',', $msg_status);
           if (count($dlrParts) < 3) {
               return;
           }
           list($sntdate, $stts, $deldate) = $dlrParts;

           $tempsmsdata = array(
               'sent_status' => 2, //Sent and delivered
               'time_sent' => $sntdate,
               'status_description' => $stts,
               'time_delivered' => $deldate
           );
           //print_r($tempsmsdata);
            $this->studentModel->update_table_details('messages',$where = array('message_id' => $msgid),$tempsmsdata);
            // echo 'updated';
          
           }
         
     }  
       }

       function view_messages(){
            $sendNumbers = array_values(array_unique(array_filter(array_map('intval', explode(',', (string) $this->request->getPost('send_number'))))));
            $msgs_ids = $this->getMessagesBySendNumbers($sendNumbers);
             if(count($msgs_ids) > 0 && count($msgs_ids) <= 5){
            foreach ($msgs_ids as $m) {
                if (!empty($m->message_id) && empty($m->time_sent)) {
                    $this->check_sms($m->message_id);
                }

            }
        }
            $data = array(
               'msgs' => $this->getMessageGroupsBySendNumbers($sendNumbers),
               'all_msg' => $this->getMessagesBySendNumbers($sendNumbers)
            );
            return view('system/view_messages',$data);
        }

        function load_new(){
            $user_id = $this->request->getPost('header_id');
            $seen_data = array();
            foreach($this->request->getPost('update') as $u){
                 
            $data=$this->billingModel->get_item_name('new_notifications_tbl',$where = array('user_id' =>$user_id,'update_id' =>$u));
            if(count($data)>0){
                $seen_data[] = array("seen" => 1,"update"=>$u);
            }else{
                $seen_data[] = array("seen" => 0,"update"=>$u);
            }
            }
            echo json_encode($seen_data);
        }
        function load_seen(){
            $not = $this->request->getPost('not');
           $user_id = $this->request->getPost('header_id');

              $data = [
            'update_id' => $not,
             'user_id' => $user_id
                   ];

        $this->stym->save_messages_balances('new_notifications_tbl',$data);
        echo "1";
        }

    public function load_modal_content($modalIndex) {
    $data['modalIndex'] = $modalIndex;
    return view('updates/modal_content_' . $modalIndex, $data);
     }
    
     function search_application(){
         $search = $this->request->getPost('appname');
       // $db = \Config\Database::connect($dbname);
         $names= $this->db->query('SELECT * FROM students 
                          WHERE `id` = \''.$search.'\' OR `full_name` LIKE \'%'.$search.'%\' OR `first_name` LIKE \'%'.$search.'%\' OR`last_name` LIKE \'%'.$search.'%\'');
            $result2 = $names->getResult();
        
         if(count($result2) > 0){

            echo
            '<table class="table table-hover">
            <thead>
                 <tr>
                    
                    <th>ID</th>
                    <th>Student Name</th>
                    <th></th>
                   
                </tr>
            </thead><tbody>';
            foreach ($result2 as $rsl){
               $fullname = $rsl->first_name.' '.$rsl->last_name;
                
                echo '<tr><td>'.$rsl->id.'</td>';
                echo '<td>'.$fullname.'</td>';
                 echo '<td><button class="btn btn-primary btn-sm" onclick="select_name('.$rsl->id.',\''.$fullname.'\')">select</button></td><td></td></tr>';
            
            }
            echo '</tbody>';
        }else{
       echo "<span style='color:red'>No any data Found</span>";
        }
     }
function get_application_name(){
    $student_id=$this->request->getPost('id');
    // $result = $this->studentModel->gettable_data('students',$where = array('id' => $student_id ));
     $result =[
        'student'=> $this->stym->gettable_stadm($student_id),
        'parent'=> $this->studentModel->gettable_parent($student_id)
     ];
    
            return json_encode($result);
}  
public function fetch_terms()
    {
        $id = $this->request->getVar('id');
        $year = $this->request->getVar('year');

         $period = $this->billingModel->get_item_name('class_level_tbl', $where = array('id' => $id));
        // print_r($period);
        if(date('Y')==$year){
           
            $installments = $this->report->checkTerm_date(date('Y-m-d'),$year,$period[0]->academic_type);
           //print_r($installments);
       }else{
        $installments =$this->billingModel->get_item_name_desc('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$period[0]->academic_type)); 
       }
        
           
        if(count($installments) > 0){
            $select_term = array();
            foreach($installments as $sd){
                $select_term []=array("id" => $sd->id,"name" => $sd->term_name);
            }

            echo json_encode($select_term);
        }
    }
    
     function vfd_settings(){
         return view('templates/header')
        .view('system/vfd_setting')
        .view('templates/footer');
    }

    function save_vfd_details(){
        $data=array(
           "serialNum"=>$this->request->getPost('snumber'),
           "tinNum"=>$this->request->getPost('tnumber'),
           "docTin"=>$this->request->getPost('docTin'),
           "custTIN"=>$this->request->getPost('custTin'),
           "custVRN"=>$this->request->getPost('vrn'),
           "UIN"=>$this->request->getPost('uin'),
           "NAME"=>$this->request->getPost('name'),
           "ADDRESS"=>$this->request->getPost('address'),
           "REGION"=>$this->request->getPost('region'),
           "STREET"=>$this->request->getPost('street'),
           "mobile"=>$this->request->getPost('mobile'),
           "TAXOFFICE"=>$this->request->getPost('taxoffice'),
           "username"=>$this->request->getPost('username'),
           "password"=>$this->request->getPost('password'),
           "licence"=>$this->request->getPost('licence'),
           "server_type"=>$this->request->getPost('serverType'),
           "request_url"=>$this->request->getPost('url'),
           "status"=>$this->request->getPost('status'),
        );
      $this->stym->save_messages_balances('vfd_settings_tbl',$data);
      echo 1;
    }
    
    function change_sms_status($status){
        $data=[
        "status"=>$status
        ];
      $this->stym->update_table_details('message_status_tbl',$where = array('id >' => 0),$data);
      return $status;
    }
     
}
