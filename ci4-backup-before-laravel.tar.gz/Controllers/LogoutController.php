<?php

namespace App\Controllers;

use App\Models\BillModel;
use App\Models\EmbededModel;
use App\Controllers\BaseController;

class LogoutController extends BaseController
{
    public function Logout()
    {
		
		unset($_SESSION['logged_in']);
        session_destroy();
        return view('templates/login');
        
       
    }
    
     public function Logout2()
    {
		
	return view('templates/login');
     } 
    
     public function checkSession()
    {
        
    if(session()->get('logged_in')==true){
        echo 1;
       }else{
    echo 0;
       }
       } 
       
 public function importTable()
{
    // Load the databases
    $dbs = [
        //  \Config\Database::connect('default'),
         \Config\Database::connect('advamhwe_elimu_db'),
         \Config\Database::connect('advamhwe_st_anne'),
         \Config\Database::connect('advamhwe_usariverseminary'),
         \Config\Database::connect('advamhwe_demo'),
        \Config\Database::connect('advamhwe_littleAcorns_db'),
        \Config\Database::connect('advamhwe_guardian_angles_db'),
        \Config\Database::connect('advamhwe_moshiAcademy_db'),
        \Config\Database::connect('advamhwe_nothernHighlands_db'),
        \Config\Database::connect('advamhwe_kilimanjaroSports_db'),
        \Config\Database::connect('advamhwe_springInstitute_db'),
        \Config\Database::connect('advamhwe_bridge'),
         \Config\Database::connect('advamhwe_kilemaVTC_db'),
         \Config\Database::connect('advamhwe_kisarika_db'),
         \Config\Database::connect('advamhwe_kusiriye_db'),
         
    ];

    // The table structure or data you want to import
$queries = [
 "CREATE TABLE `school_calendar_sms_schedule_tbl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `calendar_id` int NOT NULL,
  `scheduled_at` datetime NOT NULL,
  `sent_at` datetime DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_school_calendar_sms_schedule` (`calendar_id`,`scheduled_at`),
  KEY `idx_school_calendar_sms_schedule_calendar` (`calendar_id`),
  KEY `idx_school_calendar_sms_schedule_send` (`scheduled_at`,`sent_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;","

INSERT INTO `school_calendar_sms_schedule_tbl` (`calendar_id`, `scheduled_at`, `sent_at`)
SELECT
  `id`,
  DATE_SUB(CONCAT(`event_date`, ' 11:00:00'), INTERVAL 1 DAY),
  `before_sms_sent_at`
FROM `school_calendar_tbl`
WHERE `sms_enabled` = 1;","

INSERT INTO `school_calendar_sms_schedule_tbl` (`calendar_id`, `scheduled_at`, `sent_at`)
SELECT
  `id`,
  CONCAT(`event_date`, ' 08:00:00'),
  `event_sms_sent_at`
FROM `school_calendar_tbl`
WHERE `sms_enabled` = 1;
"

];


    // Import the table into each database
    foreach ($dbs as $db) {
        foreach ($queries as $query) {
            if (!$db->query($query)) {
                // Log the error if a query fails
         echo "Error executing query on database:  - ";
               // return;
            }
        }
    }

    echo "Table updated successfully into all databases.";
}

 public function automatic_run($id) {
     echo 'successful';
 }
 
  function loaded_privacy(){
        echo view('users/forms/privacy_policy');
    }
    public function salary_slip($name_id,$transNo,$db_id){
    $this->billmodel = new BillModel();
         $this->embededmodel = new EmbededModel();
          $name=$this->billmodel->get_database($name_id,$db_id);
            if(!empty($name)){
             $dbname=$name->db_name;
          }else{
            $dbname='';
          }
        $db=\Config\Database::connect($dbname);
        $db->initialize();
    $this->embededmodel->setDatabase($db);
    $data['database']=$dbname;
    $payroll_id=$this->embededmodel->get_pay_data($transNo,$name_id);
    $salary_advance=$this->embededmodel->get_advance_data($name_id,$transNo);
    $data['company']=$this->embededmodel->get_company_details('company_tbl');
   if($payroll_id>0){
    $data['history']=$this->embededmodel->get_staff_data($name_id,$transNo,$payroll_id->payroll_id);
       
}elseif($salary_advance>0){
    $data['advances']=$this->embededmodel->get_advance_data($name_id,$transNo);
  
}

 echo view('users/forms/embeded_payslip',$data);      
        
    }
public function exportDatabases()
{
 $user = 'username';
    $password = 'password';
    $db = 'advamhwe_elimu_db';

    $command = "/bin/mysqldump -u $user -p'$password' --databases $db 2>&1";

    exec($command, $output, $result);

    echo "<pre>";
    print_r($output);
    echo "</pre>";

    echo "Result: $result";
}
 
}

?>