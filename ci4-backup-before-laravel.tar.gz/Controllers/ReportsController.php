<?php 
    namespace App\Controllers;

    use CodeIgniter\Controller;
    use PhpOffice\PhpSpreadsheet\Spreadsheet;
    use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
      use App\Models\StaffModel;
     use App\Models\ItemsModel;
    use App\Models\ReportsModel;
    use App\Models\BillingModel;
    use App\Models\AdmissionModel;
    use App\Models\PaymentsModel;
    use App\Models\StudentModel;
    class ReportsController extends BaseController{
       public $bmodel; 
     public $staffmodel;
     public function __construct(){
         $publicMethods = ['public_school_fees_schedule'];
         $currentMethod = service('router')->methodName();

         if (in_array($currentMethod, $publicMethods, true)) {
            $this->preparePublicSchoolFeesScheduleSession();
         } elseif(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
            $this->staffmodel = new StaffModel();
            $this->bmodel = new BillingModel();
            $this->report= new ReportsModel;
              $this->smodel = new StudentModel; 
              $this->amodel= new AdmissionModel;
            $this->imodel= new ItemsModel;
           $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);


        }

        private function preparePublicSchoolFeesScheduleSession()
        {
            $dbId = (int) service('request')->getGet('db');
            if ($dbId <= 0) {
                return;
            }

            $defaultDb = \Config\Database::connect();
            $database = $defaultDb->table('database_list_tbl')
                ->select('db_id, db_name')
                ->where('db_id', $dbId)
                ->get()
                ->getResult();

            if (count($database) > 0) {
                session()->set('db_id', $database[0]->db_id);
                session()->set('db_name', $database[0]->db_name);
            }
        }
        function reports(){
            return view('templates/header')
            .view('reports/report')
            .view('templates/footer');   
        }
        
        
        function income_info(){
             $cmp = $this->bmodel->get_item_name('company_tbl', $where = array('created_by >' => 0));
   if($cmp[0]->classification==1){
  $this->classification_income_report();
    return;
   }
             $thedate = $this->request->getPost('thedate');
            list($startingdate, $endingdate) = explode('-', trim($thedate));
            
// Convert dd/mm/yyyy to yyyy-mm-dd format for strtotime to work correctly
$startingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($startingdate))));
$endingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($endingdate))));
// Trim whitespace and specify time if necessary, e.g., using 00:00 for start and 23:59 for end.
$sdate = strtotime(trim($startingdate) . ' 00:00');
$enddate = strtotime(trim($endingdate) . ' 23:59');
            echo '<div id="printreport">';
            echo "<h5>".$cmp[0]->company_name."</h5>";
            echo "<h5>Income statement report</h5>";
             echo "<h5>Report Date ".date('d/m/Y H:i', $sdate)." - ".date('d/m/Y H:i', $enddate)."</h5>";
            $name="Sales";
            $sold="Cost of Goods Sold";
            $other="Other Income";
            $sales= $this->report->sales($name);
            $cgs= $this->report->solid($sold);
            $oth= $this->report->other($other);
            foreach($sales as $sale){
                $saleid=$sale->id;
            }
           $all= $this->report->all_sales($saleid,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
            $totalsales=0;
           if (count($all) > 0) {
            $sl = 0;
// print_r($sales);           
           // echo "<h5>Sales</h5>";
            echo '<table class="table table-bordered">

                            <tr>
                                <th>Sales of goods</th>
                                 <th></th>
                                 <th></th>
                                 
                            </tr>';
             $totalsales=0;               
           foreach ($all as $fo) {
            $ledger=$fo->ledger_id;
            $type=$fo->ledger_type;
            $result=$this->report->allofthem($ledger,$type,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
             $totals=0;
            //  print_r($result);
               $totalDebits = 0;  // Initialize total for debits
                $totalCredits = 0; // Initialize total for credits
   
              foreach ($result as $pes) {
                  if ($pes->transation_nature == 2) { // Assuming 2 means Debit
                   $totalDebits += $pes->amount; // Accumulate debit amounts
                      } elseif ($pes->transation_nature == 1) { // Assuming 1 means Credit
                    $totalCredits += $pes->amount; // Accumulate credit amounts
                  }
                }
   
       // Calculate the balance (Debit - Credit)
       $totals =abs($totalDebits - $totalCredits);
                $totalsales=$totalsales+ $totals;
            //  print_r($totals);
             
                echo '<tr>';
                
                
                echo '<td style="padding-left:150px"> ' . $fo->account_name . '</td>';
                echo '<td>' . number_format($totals) . '</td>';
                echo "<td><center><a href=\"javascript:void()\" onclick=\"viewLedger('" . $fo->ledger_id . "','" . $type. "','" . $thedate. "')\" title=\"View this ledger\"><span class=\"view\">View</span></a></center></td>";     echo '</tr>';
            }
            echo '<tr style="border-top:2px solid silver">';
            echo '<td> <b>Total Sales</b> </td>';
             
            echo '<td><b>' . number_format($totals) . '</b></td>';
            echo '</tr>';
            echo '</table';
        } else {
            echo "<table class='table table-bordered' >";
            echo '<tr>
                    <th></th>
                    <th></th>
                     <th></th>
                                     </tr>';
            echo '<tr style="border-top:2px solid silver">';
            echo '<td> <b>Total Sales</b> </td>';
             
            echo '<td><b>' . number_format($totalsales) . '</b></td>';
            echo '</tr>';
            echo '</table';        }

        //another table 2
        foreach($cgs as $cgs){
                $cgid=$cgs->id;
            }
        $goods_sold= $this->report->cost_sold($cgid,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        $totalSold=0;
         if (count($goods_sold) > 0) {
            $sl = 0;
            
           // echo "<h5>Sales</h5>";
            echo '<table class="table table-bordered">

                            <tr>
                                <th>Less: Cost of goods sold</th>
                                 <th></th>
                                 <th></th>
                            </tr>';
           foreach ($goods_sold as $fo1) {
                $ledger1=$fo1->ledger_id;
                $type=$fo1->ledger_type;
             $result=$this->report->allofthem1($ledger1,$type,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
             $totals=0;
                $totalDebits = 0;  // Initialize total for debits
                $totalCredits = 0; // Initialize total for credits
   
              foreach ($result as $pes) {
           // Check the nature of the transaction
                  if ($pes->transation_nature == 2) { // Assuming 2 means Debit
                   $totalDebits += $pes->amount; // Accumulate debit amounts
                      } elseif ($pes->transation_nature == 1) { // Assuming 1 means Credit
                    $totalCredits += $pes->amount; // Accumulate credit amounts
                  }
                }
   
       // Calculate the balance (Debit - Credit)
       $totals = abs($totalDebits - $totalCredits);
                
                $totalSold=$totalSold+ $totals;
                echo '<tr>';
                                
                echo '<td style="padding-left:150px">' . $fo1->account_name . '</td>';
                echo '<td>' . number_format($totals) . '</td>';
                echo "<td><center><a href=\"javascript:void()\" onclick=\"viewLedger('" . $fo1->ledger_id . "','" . $type. "','" . $thedate. "')\" title=\"View this ledger\"><span class=\"view\">View</span></a></center></td>";
                echo '</tr>';
            }
            echo '<tr style="border-top:2px solid silver">';
            echo '<td> <b>Total Cost of Goods sold</b> </td>';
             
            echo '<td><b>' . number_format($totalSold) . '</b></td>';
            echo '</tr>';
            echo '</table';
        } else {
            echo "<table class='table table-bordered'>";
            echo '<tr>
                    <th>Less: Cost of goods sold</th>
                     <th></th>
                     <th></th>
                </tr>';
            echo '<tr style="border-top:2px solid silver">';
            echo '<td> <b>Total Cost of Goods sold</b> </td>';
             
            echo '<td><b>' . number_format($totalSold) . '</b></td>';
            echo '</tr>';
            echo '</table';
        }
        $gross=$totalsales-$totalSold;
        echo "<table>";
                  echo '<tr>
                    <th></th>
                     <th></th>
                     <th></th>
                </tr>';
            echo '<tr style="border-bottom:2px solid #999;border-top:2px solid silver;">';
            echo '<td> <b>GROSS PROFIT</b> </td>';
             
            echo '<td><b>' . number_format($gross) . '</b></td>';
            echo '</tr>';
            echo '</table';

            //another table 3
            foreach($oth as $ot){
                $othersid=$ot->id;
            }
        $other_income= $this->report->other_income($othersid,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        $totalIncome=0;
         if (count($other_income) > 0) {
            $sl = 0;
            
           // echo "<h5>Sales</h5>";
            echo '<table class="table table-bordered">
                           <tr>
                                <th></th>
                                 <th></th>
                                 <th></th>
                            </tr>
                            <tr>
                                <th>sales of services</th>
                                 <th></th>
                                 <th></th>
                            </tr>';
           foreach ($other_income as $fo2) {
                $ledger1=$fo2->ledger_id;
                $type=$fo2->ledger_type;
             $result=$this->report->allofthem1($ledger1,$type,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
             $totals=0;
            //  print_r($result);
                
                $totalDebits = 0;  // Initialize total for debits
                $totalCredits = 0; // Initialize total for credits
   
              foreach ($result as $pes) {
           // Check the nature of the transaction
                  if ($pes->transation_nature == 2) { // Assuming 2 means Debit
                   $totalDebits += $pes->amount; // Accumulate debit amounts
                      } elseif ($pes->transation_nature == 1) { // Assuming 1 means Credit
                    $totalCredits += $pes->amount; // Accumulate credit amounts
                  }
                }
   
       // Calculate the balance (Debit - Credit)
       $totals =abs($totalDebits - $totalCredits);
                
                $totalIncome=$totalIncome+ $totals;
                echo '<tr>';
                                
                echo '<td style="padding-left:150px"> ' . $fo2->account_name . '</td>';
                echo '<td>' . number_format($totals) . '</td>';
               echo "<td><center><a href=\"javascript:void()\" onclick=\"viewLedger('" . $fo2->ledger_id . "','" . $type. "','" . $thedate. "')\" title=\"View this ledger\"><span class=\"view\">View</span></a></center></td>";
                echo '</tr>';
            }
            echo '<tr style="border-top:1px solid black">';
            echo '<td> <b>Total Other Income</b> </td>';
             
            echo '<td><b>' . number_format($totalIncome) . '</b></td>';
            echo '</tr>';
            echo '</table';
        } else {
            echo "<table class='table table-bordered'>";
            echo '<tr>
                    <th></th>
                     <th></th>
                     <th></th>
                </tr>';
            echo '<tr style="border-top:2px solid silver">';
            echo '<td> <b>Total Other Income</b> </td>';
             
            echo '<td><b>' . number_format($totalIncome) . '</b></td>';
            echo '</tr>';
            echo '</table';
        }
        $totaly=$gross+$totalIncome;
         echo "<table>";
            echo '<tr>
                    <th></th>
                     <th></th>
                     <th></th>
                </tr>';
            echo '<tr style="border-top:2px solid black;border-bottom:2px solid silver;">';
            echo '<td> <b>TOTAL GROSS PROFIT $ OTHER SERVICES</b> </td>';
             
            echo '<td><b>' . number_format($totaly) . '</b></td>';
            echo '</tr>';
            echo '</table';
            echo '</div>';
            
           $id = 10; // Assuming this is some static ID
            $thy = $this->report->expense($id);
            $totalexpense=0;
            
            // Assuming $thy can return multiple rows; you might want to fetch just one
            $expensname = null; 
            foreach ($thy as $coder) {
                $expensname = $coder->type_name; // Get the type_name
            
            // Fetch all expenses based on the expense name and date range
            $getexp = $this->report->all_expence($expensname, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
            
// print_r($getexp);            
            echo '<tr>
                    <th>' . $coder->type_name . '</th>
                    <th></th>
                    <th></th>
                  </tr>';
                
            $totalSold = 0; // Initialize totalSold
            
            foreach ($getexp as $kepns) {
                $ledgerexp = $kepns->ledger_id; // Use this property
                $typek = $kepns->ledger_type;
            
                // Get detailed expense for the current ledger and type
                $resulte = $this->report->allofthemexpe($ledgerexp, $typek, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        
                   if (count($resulte) > 0) {
                $totals = 0; // Initialize totals for each row

                 $totalDebits = 0;  // Initialize total for debits
             $totalCredits = 0; // Initialize total for credits

           foreach ($resulte as $pes) {
        // Check the nature of the transaction
               if ($pes->transation_nature == 2) { // Assuming 2 means Debit
                $totalDebits += $pes->amount; // Accumulate debit amounts
                   } elseif ($pes->transation_nature == 1) { // Assuming 1 means Credit
                 $totalCredits += $pes->amount; // Accumulate credit amounts
               }
             }

    // Calculate the balance (Debit - Credit)
    $totals =abs($totalDebits - $totalCredits);
            
                $totalSold += $totals; // Accumulate to the total sold
// print_r($totalSold); 
                echo '<tr>';
                echo '<td style="padding-left:150px">' . $kepns->account_name . '</td>';
                echo '<td>' . number_format($totals) . '</td>';
                echo "<td><center><a href=\"javascript:void()\" onclick=\"viewLedger('" . $ledgerexp . "','" . $typek . "','" . $thedate . "')\" title=\"View this ledger\"><span class=\"view\">View</span></a></center></td>";
                echo '</tr>';    
                $totalexpense=$totalexpense+ $totals;

                }
            }
echo '<tr>
<th></th>
<th></th>
 <th></th>
                 </tr>';
echo '<tr style="border-top:2px solid silver">';
echo '<td> <b>Total Expense</b> </td>';
            echo '<td><b>' . number_format($totalexpense) . '</b></td>';
            echo '</tr>';
                $tota=$totaly-$totalexpense;
                echo '<tr>
                        <th></th>
                         <th></th>
                         <th></th>
                    </tr>';
                echo '<tr style="border-top:2px solid black;border-bottom:2px solid silver;">';
                echo '<td> <b>TOTAL  PROFIT OR LOSS</b> </td>';
                 
                echo '<td><b>' . number_format($tota) . '</b></td>';
                echo '</tr>';
            echo '</table>';
            
            }
        }
        
         function classification_income_report(){
 $cmp = $this->bmodel->get_item_name('company_tbl', $where = array('created_by >' => 0));
$thedate = $this->request->getPost('thedate');
list($startingdate, $endingdate) = explode('-', trim($thedate));
            
// Convert dd/mm/yyyy to yyyy-mm-dd format for strtotime to work correctly
$startingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($startingdate))));
$endingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($endingdate))));
// Trim whitespace and specify time if necessary, e.g., using 00:00 for start and 23:59 for end.
$sdate = strtotime(trim($startingdate) . ' 00:00');
$enddate = strtotime(trim($endingdate) . ' 23:59');
            echo '<div id="printreport">';
            echo "<h5>".$cmp[0]->company_name."</h5>";
            echo "<h5>Classification Income Statement Report</h5>";
             echo "<h5>Report Date ".date('d/m/Y H:i', $sdate)." - ".date('d/m/Y H:i', $enddate)."</h5>";
            $name="Sales";
            $sold="Cost of Goods Sold";
            $other="Other Income";
            $sales= $this->report->sales($name);
            $cgs= $this->report->solid($sold);
            $oth= $this->report->other($other);

             $clsfctn = $this->bmodel->get_item_name('classification_tbl', $where = array('id >' => 0));
            foreach($sales as $sale){
                $saleid=$sale->id;
            }
           $all= $this->report->all_sales($saleid,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
            $totalsales=0;
           if (count($all) > 0) {
            $sl = 0;
// print_r($sales);           
           // echo "<h5>Sales</h5>";
            echo '<table class="table table-bordered">
                        <tr>
                                
                                 <th></th>';
                    foreach($clsfctn as $cl){
                      echo '<th>'.$cl->class_name.'</th>';
                         }
                    echo ' <th>Total</th>
                           </tr>
                            <tr>
                                <th>Sales of goods</th>
                                 <th></th>
                                 <th></th>
                                 
                            </tr>';
             $totalsales=0;               
           foreach ($all as $fo) {
            $ledger=$fo->ledger_id;
            $type=$fo->ledger_type;
        
              echo '<tr>';
                
                
                echo '<td style="padding-left:150px"> ' . $fo->account_name . '</td>';
                   
                   $totalArray=array();
                foreach($clsfctn as $cl){
                    $totals=0;
                 $totalDebits = 0;  
                $totalCredits = 0;

                $result=$this->report->allofthem($ledger,$type,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate),$cl->id);
                foreach ($result as $pes) {
                  if ($pes->transation_nature == 2) { 
                   $totalDebits += $pes->amount; 
                      } elseif ($pes->transation_nature == 1) { 
                    $totalCredits += $pes->amount; 
                  }
                }
                // Calculate the balance (Debit - Credit)
              $totals =abs($totalDebits - $totalCredits);
              $totalArray[]=array('id'=>$cl->id, 'amount'=>$totals);
                $totalsales=$totalsales+ $totals;

                // echo "<td colspan='".count($clsfctn)."'></td>";
                echo '<td class="text-right">' . number_format($totals) . '</td>';
                  }

               echo '<td class="text-right">' . number_format($totalsales) . '</td>';
                echo "<td><center><a href=\"javascript:void()\" onclick=\"viewLedger('" . $fo->ledger_id . "','" . $type. "','" . $thedate. "')\" title=\"View this ledger\"><span class=\"view\">View</span></a></center></td>";     echo '</tr>';
            }
            echo '<tr style="border-top:2px solid silver">';
            echo '<td> <b>Total Sales</b> </td>';
            
            $totals_class = [];

            foreach ($totalArray as $entry) {
            $id = $entry['id'];
            $amount = $entry['amount'];

            if (!isset($totals_class[$id])) {
                $totals_class[$id] = 0;
            }

            $totals_class[$id] += $amount;
            }
             foreach ($totals_class as $id => $amount) {
                      echo '<th class="text-right">'.number_format($amount).'</th>';
                         }
             
            echo '<td class="text-right"><b>' . number_format($totalsales) . '</b></td>';
            echo '</tr>';
            echo '</table';
        } else {
            echo "<table class='table table-bordered' >";
            echo '<tr> <th></th>';
                     foreach($clsfctn as $cl){
                      echo '<th>'.$cl->class_name.'</th>';
                         }

                    echo ' <th>Total</th>
                           </tr>
                            <tr>
                                <th>Sales of goods</th>
                                 <th></th>
                                 <th></th>
                                 
                            </tr>';
            echo '<tr style="border-top:2px solid silver">';
            
            echo '<td> <b>Total Sales</b> </td>';

           
              foreach($clsfctn as $cl){
                      echo '<th class="text-right">0</th>';
                         }
            echo '<td class="text-right"><b>' . number_format($totalsales) . '</b></td>';
            echo '</tr>';
            echo '</table';      
          }
      //another table 2
        foreach($cgs as $cgs){
                $cgid=$cgs->id;
            }
        $goods_sold= $this->report->cost_sold($cgid,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        $totalSold=0;
         if (count($goods_sold) > 0) {
            $sl = 0;
            
           // echo "<h5>Sales</h5>";
            echo '<table class="table table-bordered">

                            <tr>
                                <th>Less: Cost of goods sold</th>
                                 <th></th>
                                 <th></th>
                            </tr>';
           foreach ($goods_sold as $fo1) {
                $ledger1=$fo1->ledger_id;
                $type=$fo1->ledger_type;
                      echo '<tr>';
                                
                echo '<td style="padding-left:150px">' . $fo1->account_name . '</td>';
                  $totalArray=array();
                foreach($clsfctn as $cl){
                $totals=0;
                 $totalDebits = 0;  
                $totalCredits = 0;

                $result=$this->report->allofthem1($ledger1,$type,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate),$cl->id);
               foreach ($result as $pes) {
                  if ($pes->transation_nature == 2) { 
                   $totalDebits += $pes->amount; 
                      } elseif ($pes->transation_nature == 1) { 
                    $totalCredits += $pes->amount; 
                  }
                }
                // Calculate the balance (Debit - Credit)
              $totals =abs($totalDebits - $totalCredits);
              $totalArray[]=array('id'=>$cl->id, 'amount'=>$totals);
               // $totalsales=$totalsales+ $totals;

                echo '<td class="text-right">' . number_format($totals) . '</td>';

                 }
                 $totalSold=$totalSold+ $totals;
                 echo '<td class="text-right">' . number_format($totalSold) . '</td>';
                echo "<td><center><a href=\"javascript:void()\" onclick=\"viewLedger('" . $fo1->ledger_id . "','" . $type. "','" . $thedate. "')\" title=\"View this ledger\"><span class=\"view\">View</span></a></center></td>";
                echo '</tr>';
            }
            echo '<tr style="border-top:2px solid silver">';
            echo '<td> <b>Total Cost of Goods sold</b> </td>';
             
             $totals_class = [];

            foreach ($totalArray as $entry) {
            $id = $entry['id'];
            $amount = $entry['amount'];

            if (!isset($totals_class[$id])) {
                $totals_class[$id] = 0;
            }

            $totals_class[$id] += $amount;
            }

            foreach ($totals_class as $id => $amount) {
                      echo '<th class="text-right">'.number_format($amount).'</th>';
                         }
            if(count($totals_class)==0){
              foreach($clsfctn as $cl){
              echo '<th class="text-right">0</th>';
               }  
              }
            echo '<td class="text-right"><b>' . number_format($totalSold) . '</b></td>';
            echo '</tr>';
            echo '</table';
        } else {
            echo "<table class='table table-bordered'>";
            echo '<tr>
                    <th>Less: Cost of goods sold</th>
                     <th></th>
                     <th></th>
                </tr>';
            echo '<tr style="border-top:2px solid silver">';
            echo '<td> <b>Total Cost of Goods sold</b> </td>';
             
              foreach($clsfctn as $cl){
              echo '<th class="text-right">0</th>';
               }  
              
            echo '<td class="text-right"><b>' . number_format($totalSold) . '</b></td>';
            echo '</tr>';
            echo '</table';
        }
        $gross=$totalsales-$totalSold;
        echo "<table>";
                  echo '<tr>
                    <th></th>
                     <th></th>
                     <th></th>
                </tr>';
            echo '<tr style="border-bottom:2px solid #999;border-top:2px solid silver;">';
            echo '<td> <b>GROSS PROFIT</b> </td>';
              foreach($clsfctn as $cl){
              echo '<th class="text-right"></th>';
               } 
            echo '<td class="text-right"><b>' . number_format($gross) . '</b></td>';
            echo '</tr>';
            echo '</table';

              //another table 3
            foreach($oth as $ot){
                $othersid=$ot->id;
            }
        $other_income= $this->report->other_income($othersid,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        $totalIncome=0;
         if (count($other_income) > 0) {
            $sl = 0;
            
           // echo "<h5>Sales</h5>";
            echo '<table class="table table-bordered">
                           <tr>
                                <th></th>
                                 <th></th>
                                 <th></th>
                            </tr>
                            <tr>
                                <th>sales of services</th>
                                 <th></th>
                                 <th></th>
                            </tr>';
                            $totalArray=array();
           foreach ($other_income as $fo2) {
                $ledger1=$fo2->ledger_id;
                $type=$fo2->ledger_type;
                 $totalIncome2=0;
                   
                echo '<tr>';
                                
                echo '<td style="padding-left:150px"> ' . $fo2->account_name . '</td>';

                 
                foreach($clsfctn as $cl){
                $totals=0;
                 $totalDebits = 0;  
                $totalCredits = 0;

                $result=$this->report->allofthem1($ledger1,$type,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate),$cl->id);
               foreach ($result as $pes) {
                  if ($pes->transation_nature == 2) { 
                   $totalDebits += $pes->amount; 
                      } elseif ($pes->transation_nature == 1) { 
                    $totalCredits += $pes->amount; 
                  }
                }
                // Calculate the balance (Debit - Credit)
              $totals =abs($totalDebits - $totalCredits);
              $totalArray[]=array('id'=>$cl->id, 'amount'=>$totals);
               // $totalsales=$totalsales+ $totals;

                echo '<td class="text-right">' . number_format($totals) . '</td>';
                 $totalIncome=$totalIncome+ $totals;
                 $totalIncome2=$totalIncome2+ $totals;
                 }
                 
               echo '<td class="text-right">' . number_format($totalIncome2) . '</td>';
               echo "<td><center><a href=\"javascript:void()\" onclick=\"viewLedger('" . $fo2->ledger_id . "','" . $type. "','" . $thedate. "')\" title=\"View this ledger\"><span class=\"view\">View</span></a></center></td>";
                echo '</tr>';
            }
            echo '<tr style="border-top:1px solid black">';
            echo '<td> <b>Total Other Income</b> </td>';
             
              $totals_class = [];
           /// print_r($totalArray);
            foreach ($totalArray as $entry) {
            $id = $entry['id'];
            $amount = $entry['amount'];

            if (!isset($totals_class[$id])) {
                $totals_class[$id] = 0;
            }

            $totals_class[$id] += $amount;
            }

            foreach ($totals_class as $id => $amount) {
                      echo '<th class="text-right">'.number_format($amount).'</th>';
                         }
            if(count($totals_class)==0){
              foreach($clsfctn as $cl){
              echo '<th class="text-right">0</th>';
               }  
              }
            echo '<td class="text-right"><b>' . number_format($totalIncome) . '</b></td>';
            echo '</tr>';
            echo '</table';
        } else {
            echo "<table class='table table-bordered'>";
            echo '<tr>
                    <th></th>
                     <th></th>
                     <th></th>
                </tr>';
            echo '<tr style="border-top:2px solid silver">';
            echo '<td> <b>Total Other Income</b> </td>';
             
              foreach($clsfctn as $cl){
              echo '<th class="text-right">0</th>';
               }
            echo '<td class="text-right"><b>' . number_format($totalIncome) . '</b></td>';
            echo '</tr>';
            echo '</table';
        }
        $totaly=$gross+$totalIncome;
         echo "<table>";
            echo '<tr>
                    <th></th>
                     <th></th>
                     <th></th>
                </tr>';
            echo '<tr style="border-top:2px solid black;border-bottom:2px solid silver;">';
            echo '<td> <b>TOTAL GROSS PROFIT $ OTHER SERVICES</b> </td>';
             foreach($clsfctn as $cl){
              echo '<th class="text-right"></th>';
               }
            echo '<td class="text-right"><b>' . number_format($totaly) . '</b></td>';
            echo '</tr>';
            echo '</table';
            echo '</div>'; 

             $id = 10; // Assuming this is some static ID
            $thy = $this->report->expense($id);
            $totalexpense=0;
            
            $expensname = null; 
            foreach ($thy as $coder) {
                $expensname = $coder->type_name; // Get the type_name
            
            $getexp = $this->report->all_expence($expensname, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
            
// print_r($getexp);            
            echo '<tr>
                    <th>' . $coder->type_name . '</th>
                    <th></th>
                    <th></th>
                  </tr>';
                
            $totalSold = 0; // Initialize totalSold
            $totalArray=array();
            foreach ($getexp as $kepns) {
                $ledgerexp = $kepns->ledger_id; // Use this property
                $typek = $kepns->ledger_type;
            
                

               
                echo '<tr>';
                echo '<td style="padding-left:150px">' . $kepns->account_name . '</td>';

                  
                foreach($clsfctn as $cl){
                $totals=0;
                 $totalDebits = 0;  
                $totalCredits = 0;

                 $result = $this->report->allofthemexpe($ledgerexp, $typek, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate),$cl->id);
               foreach ($result as $pes) {
                  if ($pes->transation_nature == 2) { 
                   $totalDebits += $pes->amount; 
                      } elseif ($pes->transation_nature == 1) { 
                    $totalCredits += $pes->amount; 
                  }
                }
                // Calculate the balance (Debit - Credit)
              $totals =abs($totalDebits - $totalCredits);
              $totalArray[]=array('id'=>$cl->id, 'amount'=>$totals);
               // $totalsales=$totalsales+ $totals;

                echo '<td class="text-right">' . number_format($totals) . '</td>';

                 }
                  $totalSold += $totals; 
                echo '<td class="text-right">' . number_format($totalSold) . '</td>';
                echo "<td><center><a href=\"javascript:void()\" onclick=\"viewLedger('" . $ledgerexp . "','" . $typek . "','" . $thedate . "')\" title=\"View this ledger\"><span class=\"view\">View</span></a></center></td>";
                echo '</tr>';    
                $totalexpense=$totalexpense+ $totals;

                
                }
                
echo '<tr>
<th></th>
<th></th>
 <th></th>
                 </tr>';
echo '<tr style="border-top:2px solid silver">';
echo '<td> <b>Total Expense</b> </td>';

  $totals_class = [];

            foreach ($totalArray as $entry) {
            $id = $entry['id'];
            $amount = $entry['amount'];

            if (!isset($totals_class[$id])) {
                $totals_class[$id] = 0;
            }

            $totals_class[$id] += $amount;
            }

            foreach ($totals_class as $id => $amount) {
                      echo '<th class="text-right">'.number_format($amount).'</th>';
                         }
                
                if(count($totals_class)==0){
             foreach($clsfctn as $cl){
                  echo '<td class="text-right">0</td>';
                 }
                }
            echo '<td class="text-right"><b>' . number_format($totalexpense) . '</b></td>';
            echo '</tr>';
                $tota=$totaly-$totalexpense;
                echo '<tr>
                        <th></th>
                         <th></th>
                         <th></th>
                    </tr>';
                echo '<tr style="border-top:2px solid black;border-bottom:2px solid silver;">';
                echo '<td> <b>TOTAL  PROFIT OR LOSS</b> </td>';
                 foreach($clsfctn as $cl){
                  echo '<td class="text-right"></td>';
                 }
                echo '<td class="text-right"><b>' . number_format($tota) . '</b></td>';
                echo '</tr>';
            echo '</table>';
            
            }

//end------------------
        }
    
    public function getSingle_ledger()
        {
           $ledgerId = $this->request->getVar('ledgerId');
    $ledgertype = $this->request->getVar('ledgertype');
    $thedate = $this->request->getVar('thedate');

    list($startingdate, $endingdate) = explode('-', $thedate);
    
// Convert dd/mm/yyyy to yyyy-mm-dd format for strtotime to work correctly
$startingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($startingdate))));
$endingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($endingdate))));
    $sdate = strtotime(trim($startingdate) . ' 00:00:00');
    $enddate = strtotime(trim($endingdate) . ' 23:59:59');
   // Logging for checking date values before querying
    $formatted_start_date = date('Y-m-d H:i:s', $sdate);
    $formatted_end_date = date('Y-m-d H:i:s', $enddate);
    
   
    if ($ledgerId == 9) {
        $data['ledger'] = $this->report->getSingle_viewapp($ledgerId, $ledgertype, $formatted_start_date, $formatted_end_date);
    } elseif ($ledgerId == 27) {
        $data['ledger'] = $this->report->getTransactions($ledgerId, $ledgertype, $formatted_start_date, $formatted_end_date);
    } else {
        $data['ledger'] = $this->report->getSingle_view($ledgerId, $ledgertype, $formatted_start_date, $formatted_end_date);
    }

   // Pass the formatted dates to the view
    $data['start_date'] = $formatted_start_date;
    $data['end_date'] = $formatted_end_date;
    $data['id'] = $ledgerId;
    $data['type'] = $ledgertype;

    echo view('reports/forms/view_ledger', $data);
         }
        function generate_cashcollection_rpt() {
        $thedate = $this->request->getPost('thedate');
        $ledgerId = $this->request->getPost('ledgerId');
        $ledgertype = $this->request->getPost('ledgertype');

        list($startingdate, $endingdate) = explode('-', $thedate);
        $enddate = strtotime($endingdate);
        $sdate = strtotime($startingdate);
        $mode = "";
        if ($this->request->getPost('pmode') == 0) {
            $mode = "ALL TRANSACTION MODE";
        } else {
            $paymode = $this->report->get_paymode($this->request->getPost('pmode'));
            $mode = $paymode[0]->type_name;
        
        }
        $acc_name=$this->report->select_account($ledgerId);
        $data = array(
            'strtdate' => strtotime($startingdate),
            'enddate' => $enddate,
            'type' => $ledgertype,
            'id' => $ledgerId,
            'account_name'=>$acc_name[0]->account_name,
            'pmode_name' => $mode,
            'pmode' => $this->request->getPost('pmode'),
            'cashcollctn_data' => $this->report->cashcollcted_repts($ledgerId,$ledgertype,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate), $this->request->getPost('pmode'))
        );
        echo view('reports/forms/ledger_report', $data);
      //echo date('Y-m-d H:i', $enddate);
    }
    
     function sales_by_classes(){
            return view('templates/header')
            .view('reports/sales_by_classes')
            .view('templates/footer');   
        }
        
        function sales_by_classes1(){
          $thedate = $this->request->getPost('thedate');
            list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            echo '<div id="printreport">';
            echo "<h5>EDEN GARDEN</h5>";
            echo "<h5>Sales by class report</h5>";
             echo "<h5>Report Date ".date('d-m-Y H:i', $sdate)." - ".date('d-m-Y H:i', $enddate)."</h5>";
             $classLevel=$this->report->selectAllclasslevel(date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));

              echo '<table class="table table-bordered">

                            <tr>
                                <th>Class Level</th>
                                 <th>No of Admitted Student</th>
                                 <th>Total Sales</th>
                                 <th></th>
                            </tr>';
                            if(count($classLevel)>0){
                                foreach($classLevel as $le){
                                    echo '<tr>';
                                    echo '<td>'.$le->level_name.'</td>';
                                    echo '<td></td>';
                                    echo '<td></td>';
                                    echo '<tr>';
                                    $lvid=$this->report->getclasses($le->id,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
                                    if(count($lvid)>0){
                                      foreach($lvid as $l){
                                        $ttlclass=$this->report->countClasses($l->id,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
                                        $class_sales=$this->report->get_name_id($l->id,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
                                        $ttlsales=0;
                                        if(count($class_sales)>0){
                                        foreach($class_sales as $sale){
                                         $ttlsales=$ttlsales+ $sale->amount;
                                        }}
                                      echo '<tr>';
                                    echo '<td style="padding-left:100px;">'.$l->class_name.'</td>';
                                    echo '<td style="text-align:center">'.count($ttlclass).'</td>';
                                    echo '<td>'.number_format($ttlsales).'</td>';
                                     echo "<td><center><a href=\"javascript:void()\" onclick=\"viewClasses('" . $l->id . "','" . $thedate. "')\" title=\"View this class\"><span class=\"view\">View</span></a></center></td>";
                                    echo '<tr>';
                                      }  
                                    }else{
                                        
                                    }
                                }
                            }else{
                             echo '<tr>';
                                   
                                    echo '<td colspan="4"> Currently there is no any history.</td>';
                            echo '<tr>';   
                            }
            echo '</table>';   
        }
        
        public function class_sales_report()
        {
            $classId = $this->request->getVar('classId');
            
            $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            $data['class'] = $this->report->getSingle_class($classId,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
            $data['start'] = $sdate;
            $data['end'] = $enddate;
            $data['cid'] = $classId;
           
            
            echo view('reports/forms/sales_class_report',$data);
         }
          function collection_by_classes(){
            return view('templates/header')
            .view('reports/collection_by_classes')
            .view('templates/footer');   
        }
        
         function collection_by_classes1() {
            $cmp = $this->bmodel->get_item_name('company_tbl', $where = array('created_by >' => 0));

            // Get the posted data from Ajax request
            $year = $this->request->getPost('year');
            $classLevel = $this->request->getPost('classlevel');
            $classname = $this->report->getonlycnamelevel($classLevel);
 

            echo '<div id="printreport">';
            echo "<h5>".$cmp[0]->company_name."</h5>";
            echo "<h5>Class List Summary</h5>";
            echo "<h5>Report Year " . htmlspecialchars($year) . "</h5>";
            // echo "<h5>Level :" . $classname[0]->level_name . "</h5>";
             // If classLevel is "All" just output "All Levels"
    if ($classLevel == 0) {
        echo "<h5>Level : All Levels</h5>";
    } else {
        echo "<h5>Level :" . $classname[0]->level_name . "</h5>";
    }
            echo '<div>'; 
            echo '<table class="table table-bordered att-list" id="myTable">
                    <tr>
                        <th>Class</th>
                        <th>Balance B/F</th>
                        <th>Invoiced</th>
                        <th>Receipted</th>
                        <th>Balance</th>
                    </tr>';
                    $classIds =0; // Array to hold the IDs
        
                    foreach ($classname as $classData) {
                        $classIds = $classData->id; // Add the ID to the array
                  }

            $classLevelData = $this->report->selectClassLevel($year, $classLevel); 
    

            // if (empty($classLevelData)) {
            //     echo "No class level data found.";
            //     return; 
            // }
        
            $summedData = [];
            $totalInvoiced = 0; 
            $totalCreditnote = 0; 
            $totalRecaipted = 0;
            $totalInvoices = 0;
        
            // balance b/f
            $pyear = $year - 1;
            $classLevelDataprev = $this->report->selectClassLevelbf($pyear, $classLevel); 
            
            // When classLevel is 0, fetch all levels
    if ($classLevel == 0) {
            $allFields = $this->report->get_levels(); // Get all levels for further processing
            // print_r($allFields); // You can return or process this array as needed
            $pyear = $year - 1;
            $classLevelDataprev = $this->report->selectClassLevelbfall($pyear); 
            $classLevelData = $this->report->selectClassLevelall($year); 
        }
            // Create an array to store balance b/f data
            $balancebfData = [];
            foreach ($classLevelDataprev as $data) {
                $invoice = 0; 
                $creditnote = 0; 
                $recaipted = 0;
        
                if ($data->trans_type == 1) { 
                    $invoice = $this->report->get_amount('classes_tbl', ['class_name' => $data->class_name]) ?: 0; 
                    $totalInvoices += $invoice; 
                }
        
                if ($data->trans_type == 6) { 
                    $creditnote = $this->report->get_amount('classes_tbl', ['class_name' => $data->class_name]) ?: 0; 
                    $totalCreditnote += $creditnote; 
                }
        
                if ($data->trans_type == 2) { 
                    $recaipted = $this->report->get_amount('classes_tbl', ['class_name' => $data->class_name]) ?: 0; 
                    $totalRecaipted += $recaipted; 
                }
        
                $invoices = $invoice + $creditnote; 
                $key = $data->class_name; 
        
                if (!isset($balancebfData[$key])) {
                    $balancebfData[$key] = [
                        'invoices' => $invoices,
                        'receipted' => $recaipted,
                    ];
                } else {
                    $balancebfData[$key]['invoices'] += $invoices;
                    $balancebfData[$key]['receipted'] += $recaipted;
                }
            }
               
            foreach ($classLevelData as $data) {
            // print_r($data->id);

                $invoiced = 0; 
                $creditnote = 0; 
                $recaipted = 0;
                
        
                // Get the amounts based on the transaction type
                if ($data->trans_type == 1) { 
                    $invoiced = $this->report->get_amount('classes_tbl', ['class_name' => $data->class_name]) ?: 0; 
                    $totalInvoiced += $invoiced; 
                }
        
                if ($data->trans_type == 6) { 
                    $creditnote = $this->report->get_amount('classes_tbl', ['class_name' => $data->class_name]) ?: 0; 
                    $totalCreditnote += $creditnote; 
                }
                
                if ($data->trans_type == 2) { 
                    $recaipted = $this->report->get_amount('classes_tbl', ['class_name' => $data->class_name]) ?: 0; 
                    $totalRecaipted += $recaipted; 
                }
        
                $invoice = $invoiced + $creditnote; 
                $key = $data->class_name; 
                
                if (!isset($summedData[$key])) {
                    $summedData[$key] = [
                        'class_name' => $data->class_name,
                        'invoice' => $invoice,
                        'receipted' => $recaipted, 
                        'id' => $data->id, 
                    ];
                } else {
                    $summedData[$key]['receipted'] += $recaipted; 
                    $summedData[$key]['invoice'] += $invoice; 
                }
            }
        
            if (!empty($summedData)) {
                foreach ($summedData as $item) {
                //    print_r( $item['id'] );

                    // Calculate the balances
                    $balance = $item['invoice'] - $item['receipted'];
                    $balanceBf = isset($balancebfData[$item['class_name']]) 
                                ? $balancebfData[$item['class_name']]['invoices'] - $balancebfData[$item['class_name']]['receipted'] 
                                : 0;
            
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($item['class_name']) . '</td>'; // Class name
                    echo '<td>' . htmlspecialchars(number_format($balanceBf)) . '</td>'; // Balance B/F
                    echo '<td>' . number_format($item['invoice']) . '</td>'; // Invoice amount for this class
                    echo '<td>' . htmlspecialchars(number_format($item['receipted'])) . '</td>'; // Receipted amount for this class
                    echo '<td>' . htmlspecialchars(number_format($balance)) . '</td>'; // Balance calculation
                    echo "<td><center><a href=\"javascript:void()\" onclick=\"viewClassListSummary('" . $item['id'] . "','" . $year . "')\" title=\"View this ledger\"><span class=\"view\">View</span></a></center></td>";
                    echo '</tr>';

                }
                
                // Totals Section
                echo '<tr style="border-top:2px solid silver">';
                echo '<td><b>TOTALS</b></td>';
                
                // Initialize total trackers
                $totalBalanceBf = 0; // Total Balance B/F
                $totalInvoiced = 0;   // Total Invoiced
                $totalReceipted = 0;  // Total Receipted
                $totalBalance = 0;    // Total Balance
            
                foreach ($summedData as $item) {
                    $key = $item['class_name'];
            
                    // Accumulate totals for invoiced and receipted
                    $totalInvoiced += $item['invoice'];
                    $totalReceipted += $item['receipted'];
            
                    // If there's data for the current class in previous balances
                    if (isset($balancebfData[$key])) {
                        $totalBalanceBf += $balancebfData[$key]['invoices'] - $balancebfData[$key]['receipted'];
                    }
                }
            
                // Calculate total balance
                $totalBalance = $totalInvoiced - $totalReceipted;
            
                // Output total values to the table
                echo '<td>' . number_format($totalBalanceBf) . '</td>'; // Total Balance B/F
                echo '<td>' . number_format($totalInvoiced) . '</td>';   // Total Invoiced
                echo '<td>' . number_format($totalReceipted) . '</td>';  // Total Receipted
                echo '<td>' . number_format($totalBalance) . '</td>';     // Total Balance
                echo '<td></td>'; // Empty cell to match column structure
                echo '</tr>';
            } else {
                echo '<p>No data available to display.</p>';
            }
            
            echo '</table>';
            echo '</div>'; 
        } 
        
         public function student_collection_report()
        {
            $stid = $this->request->getVar('stid');
            
            $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            $data['class'] = $this->report->student_collection($stid,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
            $data['start'] = date('Y-m-d H:i', $sdate);
            $data['end'] = date('Y-m-d H:i', $enddate);
            $data['stid'] = $stid;
           //echo "Welcome to home ground";
            
           echo view('reports/forms/student_collection_report',$data);
         }
         function boarding_list(){
            return view('templates/header')
            .view('reports/boarding_report_view')
            .view('templates/footer');
         }
         function boarding_list2(){
            $hostel = $this->request->getPost('hostel');
            $class = $this->request->getPost('class');
            $classlevel = $this->request->getPost('classlevel');
             $year = $this->request->getPost('year');
           // echo $hostel.'<br>';
           // echo $class.'<br>';
           // echo $classlevel.'<br>';
            $board=$this->report->boarding_list2($hostel,$class,$classlevel,$year);
            //print_r($board);
            $hname=$this->report->get_hostelname($hostel);
            $hostelname="";
            if($hostel==0){
                $hostelname="All";
            }else{
              $hostelname=$hname[0]->hostel_name;  
            }
             if($classlevel==0){
                $clname="All Levels,";
            }else{
              $clname=$board[0]->level_name;  
            }
            if($class==0){
                $cname="All Classes";
            }else{
              $cname=$board[0]->class_name;  
            }
                $schoolname=$this->report->get_schoolname();
                echo "<h5><b>".$schoolname[0]->company_name."</h5>";
               echo "<h5>".$hostelname." hostel, ".$cname. " Boarding students list</h5>";
              echo '<table class="table table-bordered" id="myTable">

                            <tr>
                                <th>Reg No</th>
                                 <th>Adm No</th>
                                 <th>Names</th>
                                 <th>Age</th>
                                 <th>Gender</th>
                                 <th>Level</th>
                                 <th>Class</th>
                            </tr>';
                            $n=0;
                            $female=0;
                               $male=0;
                            if(count($board)>0){
                               
                                foreach($board as $le){
                                  if($le->gender=='Female'){
                                    $female=$female+1;
                                  }
                                  if($le->gender=='Male'){
                                    $male=$male+1;
                                  }
                                    echo '<tr>';
                                    echo '<td>'.$le->student_id.'</td>';
                                    echo '<td>'.$le->id.'</td>';
                                    echo '<td>'.$le->full_name.'</td>';
                                    echo '<td>'.(date('Y') - date('Y',strtotime($le->birth_date))).'</td>';
                                    echo '<td>'.$le->gender.'</td>';
                                    echo '<td>'.$le->level_name.'</td>';
                                    echo '<td>'.$le->class_name.'</td>';
                                   
                                   echo '<tr>';
                                   
                                }
         }else{
                             echo '<tr>';
                                  
                                    echo '<td colspan="7"> Currently there is no any history.</td>';
                            echo '<tr>';   
                            }
          echo '</table>';
          
          echo '<h6 style="">Summary,</h6>';
          echo '<h6 style="">Male = '.$male.'</h6>';
          echo '<h6 style="">Female = '.$female.'</h6>';
          echo '<h6 style="">Total = '.($female+$male).'</h6>';
          
         }
function route_list(){
    return view('templates/header')
            .view('reports/route_list_view')
            .view('templates/footer');

    }
    function class_list(){
    return view('templates/header')
            .view('reports/class_list_view')
            .view('templates/footer');

    }
     function class_list2(){
          $status = $this->request->getPost('status');
      
        $year = $this->request->getPost('year');
        $class = $this->request->getPost('class');
            $classlevel = $this->request->getPost('classlevel');
            $stream = $this->request->getPost('stream');
            $data['classlevel']=$this->request->getPost('classlevel');
            $data['class']=$this->request->getPost('class');
            $data['stream']=$this->request->getPost('stream');
            $data['year']=$this->request->getPost('year');
            $data['time']=1;
         
   
            $data['cl']=$this->report->class_list2($class,$classlevel,$stream,$year,$status);
            $studentIds = array_map(static function ($student) {
                return (int) $student->id;
            }, $data['cl']);

            if (count($studentIds) > 0) {
                $paymentsModel = new PaymentsModel();
                $paymentsModel->primeTermBalanceContext($studentIds, (int) $year, session()->get('db_name'));
            } else {
                PaymentsModel::clearTermBalanceContext();
            }

          try {
              echo view('reports/forms/view_student_list',$data);
          } finally {
              PaymentsModel::clearTermBalanceContext();
          }
         }
     function route_list2(){
          $vnumber = $this->request->getPost('vnumber');
          $class = $this->request->getPost('class');
          $cl=$this->report->route_list2($vnumber,$class);
          $data['list']=$cl;
           echo view('reports/forms/route_student_list',$data); 
     }
     function route_list222(){
          
          $vnumber = $this->request->getPost('vnumber');
          $class = $this->request->getPost('class');
       
            $cl=$this->report->route_list2($vnumber,$class);
           // $hname=$this->report->get_hostelname($hostel);
            

           if($vnumber==0){
                $vhno="All Vehicle ";
            }else{
              $vhno=$cl[0]->vehicle_number;  
            }
            if($class==0){
                $cname="All Classes";
            }else{
              $cname=$cl[0]->class_name;  
            }
              $schoolname=$this->report->get_schoolname();
            
            echo "<h5><b>".$schoolname[0]->company_name."</h5>";
               echo "<h5>".$vhno." ".$cname. " students list</h5>";
              echo '<table class="table table-bordered" id="myTable">

                        <tr>
                                <th>Reg No</th>
                                 <th>Adm No</th>
                                 <th>Names</th>
                                 <th>Age</th>
                                 <th>Gender</th>
                                 <th>Class</th>
                                 <th>parent</th>
                                 <th>Phone</th>
                                 <th>Route</th>
                                 <th>Vehicle Name</th>
                                 <th>Vehicle Number</th>
                                 <th>Driver</th>
                                 <th>Phone</th>
                            </tr>';
                            $n=0;
                            $female=0;
                               $male=0;
                            if(count($cl)>0){
                               
                                foreach($cl as $le){
                                    $parent= $this->report->get_parent($le->id);
                                    $drive= $this->report->get_driver_detail($le->driver_id);

                                  if($le->gender=='Female'){
                                    $female=$female+1;
                                  }
                                  if($le->gender=='Male'){
                                    $male=$male+1;
                                  }
                                    echo '<tr>';
                                    echo '<td>'.$le->student_id.'</td>';
                                    echo '<td>'.$le->id.'</td>';
                                    echo '<td>'.$le->full_name.'</td>';
                                    echo '<td>'.(date('Y') - date('Y',strtotime($le->birth_date))).'</td>';
                                    echo '<td>'.$le->gender.'</td>';
                                    echo '<td>'.$le->class_name.'</td>';
                                    echo '<td>'.$parent[0]->first_name.' '.$parent[0]->last_name.'</td>';
                                    echo '<td>'.$parent[0]->phone1.'</td>';
                                    echo '<td>'.$le->route_id.'</td>';
                                    echo '<td>'.$le->vehicle_name.'</td>';
                                    echo '<td>'.$le->vehicle_number.'</td>';
                                    echo '<td>'.$drive[0]->first_name." ".$drive[0]->last_name.'</td>';
                                    echo '<td>'.$drive[0]->phone_no.'</td>';
                                   
                                   echo '<tr>';
                                   
                                }
         }else{
                             echo '<tr>';
                                  
                                    echo '<td colspan="7"> Currently there is no any history.</td>';
                            echo '<tr>';   
                            }
          echo '</table>';
          
          echo '<h6 style="">Summary,</h6>';
          echo '<h6 style="">Male = '.$male.'</h6>';
          echo '<h6 style="">Female = '.$female.'</h6>';
          echo '<h6 style="">Total = '.($female+$male).'</h6>';
          
         }
         function attendance(){
            $attendance_id=$this->request->getGet('attendance_id');
            $data['attendance_id'] =$attendance_id;
            $data['partial'] = $this->request->getGet('partial') == '1';
            if ($data['partial']) {
                return view('reports/attendance', $data);
            }
           return view('templates/header')
            .view('reports/attendance',$data)
            .view('templates/footer'); 
         }
  public function get_student_list($sid,$cid)
          {
  
    $builder = $this->db->table('admission_tbl');
    $builder->select('students.id,students.first_name,students.middle_name,students.last_name,students.full_name,students.birth_date,students.gender,admission_tbl.admission_type,admission_tbl.adimit_for');
    $builder->join('students','students.id=admission_tbl.student_id');
    $builder->where('admission_tbl.stream_id',$sid);
    $builder->where('admission_tbl.class_id',$cid);
    $builder->where('admission_tbl.academic_year', date('Y'));
    $builder->where('admission_tbl.status', 1);
    $builder->orderBy('students.full_name','ASC');
    $ments_result = $builder->get()->getResult();
    
    $ments_dta = array();
    $paymentsModel = new PaymentsModel();
    $dbname = session()->get('db_name');
    $year = date('Y');
   
    if(count($ments_result) > 0){
       
        foreach ($ments_result as $sr)
        {
            $termInvoices = $paymentsModel->get_total_invoice_amount_type2($sr->id, $year, $dbname);
            if (count($termInvoices) === 0) {
                continue;
            }
            $age = '';
            if (!empty($sr->birth_date) && $sr->birth_date !== '0000-00-00') {
                $birthDate = new \DateTime($sr->birth_date);
                $age = $birthDate->diff(new \DateTime())->y . ' Yrs';
            }
            $type = ((int) $sr->admission_type === 3) ? 'B' : 'D';
            $admissionFor = ((int) $sr->adimit_for === 2) ? 'New Comer' : 'Continous';

            $data = array(
                "id" => $sr->id,
                "name" => trim($sr->full_name),
                "age" => $age,
                "gender" => $sr->gender,
                "type" => $type,
                "for" => $admissionFor
            );
            array_push($ments_dta, $data);
        }

    }
        echo json_encode($ments_dta);
    }
    function stream_list(){
       $clvl = $this->report->get_stream('streams_tbl',$where = array('class_id' => $this->request->getPost('clvl') ));
         $classlist = array();
         if(count($clvl) > 0){
             foreach($clvl as $c){
                 $classlist[] = array("id" => $c->id, "sname" => $c->stream_name);
         }
        }
        echo json_encode($classlist);  
    }
function save_attendance(){
             $checked=$this->request->getPost('type');
             $student=$this->request->getPost('student_id');
            
             if(count($checked)!=count($student)){
             echo 3;
             }else{
                 $cid=$this->request->getPost('class');
                 $stid=$this->request->getPost('stream');
                 $sess=$this->request->getPost('time');
                 $date=$this->request->getPost('doc');
                 // echo $sess;
                 // echo $date;
                 $sess_exit=$this->report->sess_exit($cid,$stid,$sess,$date);
                 if(count($sess_exit)>0){
                 echo 4;
                 }else{
            $data = [
                'class_id' => $this->request->getPost('class'),
                'stream_id' => $this->request->getPost('stream'),
                'date_taken' => $this->request->getPost('doc'),
                'time_taken' => $this->request->getPost('time'),
                'date_created' => date('Y/m/d H:i:s')
            ];
            if ($this->db->fieldExists('created_by', 'attendance_list_tbl')) {
                $data['created_by'] = session()->get('user_id');
            }
            $attendance_id=$this->report->save_attendance_list($data);
            
            if($attendance_id != 0){
           $student=$this->request->getPost('student_id');
                
                foreach ($student as $i) {
                    
                    $type=$this->request->getPost('type['.$i.']');
                    
                    $atte_record = array('attendance_id' => $attendance_id, 'student_id' => $i,'type' => $type);
                        
                    $this->report->attendance_record($atte_record);
                    
                }
                echo 1;
        }else{
          echo 2;  
        }
        }
     }
}
function attendance_record(){
 $data['partial'] = $this->request->getGet('partial') == '1';
 if ($data['partial']) {
    return view('reports/attendance_record', $data);
 }
 return view('templates/header')
            .view('reports/attendance_record', $data)
            .view('templates/footer');
}

function get_attendance_list_summary(){
    $cid = $this->request->getPost('class');
    $lid = $this->request->getPost('stream1');
    $doc = $this->request->getPost('doc');
    $sess = $this->request->getPost('time');

    $hasCreatedBy = $this->db->fieldExists('created_by', 'attendance_list_tbl');
    $attendanceBySelect = $hasCreatedBy
        ? "COALESCE(CONCAT(users.first_name, ' ', users.last_name), '-') AS attendance_by"
        : "'-' AS attendance_by";

    $builder = $this->db->table('attendance_list_tbl');
    $builder->select("
        attendance_list_tbl.id,
        attendance_list_tbl.date_taken,
        attendance_list_tbl.time_taken,
        attendance_list_tbl.date_created,
        classes_tbl.class_name,
        streams_tbl.stream_name,
        {$attendanceBySelect},
        SUM(CASE WHEN attendance_record.type = 1 THEN 1 ELSE 0 END) AS present_count,
        SUM(CASE WHEN attendance_record.type = 0 THEN 1 ELSE 0 END) AS absent_count,
        SUM(CASE WHEN attendance_record.type = 2 THEN 1 ELSE 0 END) AS late_count
    ");
    $builder->join('classes_tbl','classes_tbl.id=attendance_list_tbl.class_id');
    $builder->join('streams_tbl','streams_tbl.id=attendance_list_tbl.stream_id');
    $builder->join('attendance_record','attendance_record.attendance_id=attendance_list_tbl.id', 'left');
    if ($hasCreatedBy) {
        $builder->join('users','users.user_id=attendance_list_tbl.created_by', 'left');
    }
    if ($cid !== null && $cid !== '') {
        $builder->where('attendance_list_tbl.class_id', $cid);
    }
    if ($lid !== null && $lid !== '') {
        $builder->where('attendance_list_tbl.stream_id', $lid);
    }
    if ($doc !== null && $doc !== '') {
        $builder->where('attendance_list_tbl.date_taken', $doc);
    }
    if ($sess !== null && $sess !== '') {
        $builder->where('attendance_list_tbl.time_taken', $sess);
    }
    $builder->groupBy('attendance_list_tbl.id');
    $builder->orderBy('attendance_list_tbl.date_taken', 'DESC');
    $builder->orderBy('attendance_list_tbl.time_taken', 'ASC');
    $result = $builder->get()->getResult();

    $sessionNames = [1 => 'Morning', 2 => 'Afternoon', 3 => 'Night'];
    $data = [];
    foreach ($result as $row) {
        $data[] = [
            'id' => $row->id,
            'attendance_date' => date('M d, Y', strtotime($row->date_taken)),
            'class' => $row->class_name,
            'stream' => $row->stream_name,
            'session' => $sessionNames[(int) $row->time_taken] ?? '',
            'present' => (int) $row->present_count,
            'absent' => (int) $row->absent_count,
            'late' => (int) $row->late_count,
            'attendance_by' => $row->attendance_by,
            'trans_date' => date('M d, Y H:i', strtotime($row->date_created)),
        ];
    }

    echo json_encode($data);
}

function get_attendance_record($cid,$lid,$doc,$sess){
   $builder = $this->db->table('streams_tbl');
    $builder->select('streams_tbl.stream_name,classes_tbl.class_name');
    $builder->join('classes_tbl','classes_tbl.id=streams_tbl.class_id');
    $builder->where('streams_tbl.class_id',$cid);
    $builder->where('streams_tbl.id',$lid);
    
    $details = $builder->get()->getResult();
    if(count($details) > 0){
       
        foreach ($details as $dt)
        {
        $data['details']['class']=$dt->class_name;
        $data['details']['stream']=$dt->stream_name;
        $data['details']['doc'] = date('M d, Y',strtotime($doc));
        if($sess==1){
            $sesname="Morning";
        }elseif($sess==2){
         $sesname="Afternoon";   
        }elseif($sess==3){
            $sesname="Night";
        }
        $data['details']['session'] = $sesname;
            
        }
        }

    $builder = $this->db->table('attendance_list_tbl');
    $builder->select('attendance_record.student_id,attendance_record.id,attendance_id,attendance_record.type,students.first_name,students.middle_name,students.last_name');
    $builder->join('attendance_record','attendance_record.attendance_id=attendance_list_tbl.id');
    $builder->join('students','students.id=attendance_record.student_id');
  
    $builder->where('attendance_list_tbl.class_id',$cid);
    $builder->where('attendance_list_tbl.stream_id',$lid);
    $builder->where('attendance_list_tbl.date_taken',$doc);
    $builder->where('attendance_list_tbl.time_taken',$sess);
    $ments_result = $builder->get()->getResult();
    
    $ments_dta = array();
   
    if(count($ments_result) > 0){
       
        foreach ($ments_result as $sr)
        {
        $data['data'][]=$sr;
        $data['attendance_id'] = $sr->attendance_id;
            // $data['data'][] = array("id" => $sr->attendance_id,"fname" => $sr->first_name,"mname" => $sr->middle_name,"lname" => $sr->last_name,"type" => $sr->type);
            // array_push($ments_dta, $data);
        }

        //echo json_encode($ments_dta);
        echo json_encode($data);
    }
}
function attendance_edit($attendance_id){
 $builder = $this->db->table('attendance_record');
    $builder->select('date_taken,attendance_record.student_id,attendance_record.id,attendance_id,attendance_record.type,students.first_name,students.middle_name,students.last_name,students.full_name,students.birth_date,students.gender,admission_tbl.admission_type,admission_tbl.adimit_for,attendance_list_tbl.class_id,attendance_list_tbl.stream_id,attendance_list_tbl.time_taken');
    $builder->join('attendance_list_tbl','attendance_list_tbl.id=attendance_record.attendance_id');
    $builder->join('students','students.id=attendance_record.student_id');
    $builder->join('admission_tbl','admission_tbl.student_id=students.id AND admission_tbl.class_id=attendance_list_tbl.class_id AND admission_tbl.stream_id=attendance_list_tbl.stream_id AND admission_tbl.academic_year=YEAR(attendance_list_tbl.date_taken)', 'left');
  
    $builder->where('attendance_record.attendance_id',$attendance_id);
    $builder->orderBy('students.full_name','ASC');
    $result = $builder->get()->getResult();
    $ments_dta = array();
   
    if(count($result) > 0){
       
        foreach ($result as $sr)
        {
        $cid=$sr->class_id;    
        $lid=$sr->stream_id;    
        $doc=$sr->date_taken;    
        $sess=$sr->time_taken;    
        $data['data'][]=$sr;
        $data['attendance_id'] = $sr->attendance_id;
            
        }
     //--------------------------------------
      $builder = $this->db->table('streams_tbl');
    $builder->select('streams_tbl.stream_name,classes_tbl.class_name');
    $builder->join('classes_tbl','classes_tbl.id=streams_tbl.class_id');
    $builder->where('streams_tbl.class_id',$cid);
    $builder->where('streams_tbl.id',$lid);
    
    $details = $builder->get()->getResult();
    if(count($details) > 0){
       
        foreach ($details as $dt)
        {
        $data['details']['class']=$dt->class_name;
        $data['details']['stream']=$dt->stream_name;
        $data['details']['doc'] = date('M d, Y',strtotime($doc));
        if($sess==1){
            $sesname="Morning";
        }elseif($sess==2){
         $sesname="Afternoon";   
        }elseif($sess==3){
            $sesname="Night";
        }
        $data['details']['session'] = $sesname;
            
        }
        }
    //--------------------------------------
        echo json_encode($data);
    }
}
function edit_attendance(){
             $checked=$this->request->getPost('type');
             $student=$this->request->getPost('student_id');
            
             if(count($checked)!=count($student)){
             echo 3;
             }else{
                 $cid=$this->request->getPost('class');
                 $stid=$this->request->getPost('stream1');
                 $sess=$this->request->getPost('time');
                 $date=$this->request->getPost('doc');
                 $attendance_id=$this->request->getPost('attendance_id');
                
            $data = [
                'class_id' => $this->request->getPost('class'),
                'stream_id' => $this->request->getPost('stream1'),
                'date_taken' => $this->request->getPost('doc'),
                'time_taken' => $this->request->getPost('time'),
                'date_created' => date('Y/m/d H:i:s')
            ];
            if ($this->db->fieldExists('created_by', 'attendance_list_tbl')) {
                $data['created_by'] = session()->get('user_id');
            }
            $attendance_id2=$this->report->edit_attendance_list($data,$attendance_id);
            
            if($attendance_id2==1){
           $student=$this->request->getPost('student_id');
                
                foreach ($student as $i) {
                    
                    $type=$this->request->getPost('type['.$i.']');
                    
                    // $atte_record = array('attendance_id' => $attendance_id, 'student_id' => $i,'type' => $type);
                        
                    $this->report->attendance_record_edit($i,$attendance_id,$type);
                    
                }
                echo 1;
        }else{
          echo 2;  
        }
        
     }
}
function class_attendance_report(){
    return view('templates/header')
            .view('reports/class_attendance_report')
            .view('templates/footer');

}
function get_attendance_report($cid,$lid,$doc,$sess){
     $thedate=$this->request->getPost('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate);
            $sdate = strtotime($startingdate);
$data['details']['doc'] = date('M, d Y',$sdate)." to ".date(' M, d Y',$enddate);
    // echo $cid;
    // echo "<br>";
    // echo $sess;
 $builder = $this->db->table('streams_tbl');
    $builder->select('streams_tbl.stream_name,classes_tbl.class_name');
    $builder->join('classes_tbl','classes_tbl.id=streams_tbl.class_id');
    $builder->where('streams_tbl.class_id',$cid);
    $builder->where('streams_tbl.id',$lid);
    
    $details = $builder->get()->getResult();
    if(count($details) > 0){
      
       
        foreach ($details as $d)
        {
             
        $data['details']['class']=$d->class_name;
        $data['details']['stream']=$d->stream_name;
        
        
        if($sess==1){
            $sesname="Morning";
        }elseif($sess==2){
         $sesname="Afternoon";   
        }elseif($sess==3){
            $sesname="Night";
        }elseif($sess==0){
            $sesname="All Sessions";
        }
        $data['details']['session'] = $sesname;
            
        }
        }else{
            echo 0;
        }

    $builder = $this->db->table('attendance_list_tbl');
    $builder->select('attendance_record.student_id,attendance_record.id,attendance_id,attendance_record.type,students.first_name,students.middle_name,students.last_name');
    $builder->join('attendance_record','attendance_record.attendance_id=attendance_list_tbl.id');
    $builder->join('students','students.id=attendance_record.student_id');
  
    $builder->where('attendance_list_tbl.class_id',$cid);
    $builder->where('attendance_list_tbl.stream_id',$lid);
    //$builder->where('attendance_list_tbl.date_taken',$doc);
    //$builder->like('attendance_list_tbl.date_taken', date('Y-m-d', $sdate));
     $builder->where('DATE(date_taken) >=', date('Y-m-d', $sdate));
    $builder->where('DATE(date_taken) <=', date('Y-m-d', $enddate));
    if($sess!=0){
    $builder->where('attendance_list_tbl.time_taken',$sess);
      }
      $builder->groupBy('student_id');
    $ments_result = $builder->get()->getResult();
    
    $ments_dta = array();
   
    if(count($ments_result) > 0){
       
        foreach ($ments_result as $sr)
        {
        $data['data'][]=$sr;

        //$data['record'][$sr->student_id][] = $sr;
        $data['attendance_id'] = $sr->attendance_id;
         $stu_id=$sr->student_id;  
        }
   $stid=$this->report->getTotaldays($cid,$lid,$stu_id,date('Y-m-d', $sdate), date('Y-m-d', $enddate),$sess);
   $n=0;
   foreach ($stid as $st)
        {
     $n++;
        }
      $data['details']['noc'] = $n;  
       
    }else{
        echo "less";
    }

    $builder = $this->db->table('attendance_list_tbl');
    $builder->select('attendance_record.student_id,attendance_record.id,attendance_id,attendance_record.type,students.first_name,students.middle_name,students.last_name');
    $builder->join('attendance_record','attendance_record.attendance_id=attendance_list_tbl.id');
    $builder->join('students','students.id=attendance_record.student_id');
  
    $builder->where('attendance_list_tbl.class_id',$cid);
    $builder->where('attendance_list_tbl.stream_id',$lid);
     $builder->where('DATE(date_taken) >=', date('Y-m-d', $sdate));
    $builder->where('DATE(date_taken) <=', date('Y-m-d', $enddate));
    if($sess!=0){
    $builder->where('attendance_list_tbl.time_taken',$sess);
      }
      $mresult = $builder->get()->getResult();
    
    $ments_dta = array();
    if(count($mresult) > 0){
       
        foreach ($mresult as $r)
        {
       
        $data['record'][$r->student_id][] = $r;

    }
}
     echo json_encode($data);  
}
function attendance_record_summary(){
    return view('templates/header')
            .view('reports/attendance_record_summary')
            .view('templates/footer'); 
}
function get_attendance_summary(){
  $thedate=$this->request->getPost('thedate');
  $sess=$this->request->getPost('sess');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate);
            $sdate = strtotime($startingdate);
            if($sess==1){
                $ses="Morning session";
            }else if($sess==2){
                $ses="Afternoon session";
            }else if($sess==3){
                $ses="Night session";
            }else{
                $ses="All sessions";
            }

  echo '<div id="printreport">';
             $schoolname=$this->report->get_schoolname();
            
            echo "<h5>".$schoolname[0]->company_name."</h5>";
            echo "<h5>Attendance Record Summary by classes</h5>";
             echo "<h5>Date: ".date('M, d Y',$sdate)." to ".date('M, d Y', $enddate)." ".$ses."</h5>";
             $classes=$this->report->select_attendance_class(date('Y-m-d', $sdate), date('Y-m-d', $enddate),$sess);

              echo '<table class="table table-bordered">

                            <tr>
                                <th>Classes</th>
                                 <th>Present</th>
                                 <th>Absent</th>
                                 <th>Late</th>
                                 <th></th>
                            </tr>';
                            if(count($classes)>0){
                                //echo count($classes);
                                foreach($classes as $cc){
                                    $classname=$this->report->classes_att($cc->class_id);
                                    echo '<tr>';
                                    echo '<td style="padding-left:50px">'.$classname[0]->class_name.'</td>';
                                    echo '<td></td>';
                                    echo '<td></td>';
                                    echo '<tr>';
                                    $stream=$this->report->get_stream_attendance($cc->class_id,date('Y-m-d', $sdate), date('Y-m-d', $enddate),$sess);
                                    
                                    if(count($stream)>0){
                                      foreach($stream as $st){
                                        //echo $st->stream_name;

                                        $ttlstream=$this->report->count_attendance($cc->class_id,$st->stream_id,date('Y-m-d', $sdate), date('Y-m-d', $enddate),$sess);
                                        
                                        $present=0;
                                        $absent=0;
                                        $late=0;
                                        if(count($ttlstream)>0){
                                            //echo count($ttlstream);
                                        foreach($ttlstream as $atd){
                                            //echo $atd->type;
                                            if($atd->type==1){
                                                $present=$present +1;
                                            }elseif($atd->type==0){
                                                $absent=$absent +1;
                                            }elseif($atd->type==2){
                                                $late=$late+1;
                                            }
                                         
                                        }}
                                      echo '<tr>';
                                    echo '<td style="padding-left:100px;">'.$st->stream_name.'</td>';
                                    echo '<td style="text-align:center">'.$present.'</td>';
                                    echo '<td>'.$absent.'</td>';
                                    echo '<td>'.$late.'</td>';
                                     echo "<td><center><a href=\"javascript:void()\" onclick=\"viewClasses('" . $cc->class_id . "','" . $st->stream_id. "','" . $thedate. "','" . $sess. "')\" title=\"View students\"><span class=\"view\">View</span></a></center></td>";
                                    echo '<tr>';
                                      }  
                                    }else{
                                        
                                    }
                                }
                            }else{
                             echo '<tr>';
                                   
                                    echo '<td colspan="4"> Currently there is no any history.</td>';
                            echo '<tr>';   
                            }
            echo '</table>';    
}
function parent_attendance($id){
    $builder = $this->db->table('parents_tbl');
    $builder->select('');
    $builder->where('student_id',$id);
    $builder->where('bill_account',0);
    $details = $builder->get()->getResult();
    
        $n=0;
                  echo '<table class="table table-bordered" id="myTable">

                        <tr>
                                 <th>First Name</th>
                                 <th>Last Name</th>
                                 <th>Phone</th>
                                 
                            </tr>';
                            if(count($details)>0){
                            foreach($details as $par){
                             $n++;

                            echo '<tr>';
                            
                            echo '<td>'.$par->first_name.'</td>';
                            echo '<td>'.$par->last_name.'</td>';
                            echo '<td>'.$par->phone1.'</td>';
                           echo '</tr>';
                             
        }

    }
    echo '</table>';
}
function class_list_report(){
    echo 'here';
}
function view_student_balance(){
       $studentId = (int) $this->request->getPost('sid');
            $year = (int) $this->request->getPost('year');
            $data['student_id'] =  $studentId;
            $data['id'] = $studentId;
            $data['year'] = $year;

            if ($studentId > 0 && $year > 0) {
                $paymentsModel = new PaymentsModel();
                $paymentsModel->primeTermBalanceContext([$studentId], $year, session()->get('db_name'));
            } else {
                PaymentsModel::clearTermBalanceContext();
            }
            try {
                echo view('reports/forms/view_student_balance',$data); 
            } finally {
                PaymentsModel::clearTermBalanceContext();
            }
}

  function fetch_balance(){
        $class = $this->request->getPost('class');
        $year = $this->request->getPost('year');
            $classlevel = $this->request->getPost('classlevel');
            $stream = $this->request->getPost('stream');
            $date = $this->request->getPost('date');
            $date= date('m-d',strtotime($date));
            $msg_type = $this->request->getPost('msg_type');
            $data['classlevel']=$this->request->getPost('classlevel');
            $data['class']=$this->request->getPost('class');
            $data['stream']=$this->request->getPost('stream');
            $data['year']=$this->request->getPost('year');
             $status=$this->request->getPost('status');
          
            if($msg_type==4){
              $data['cl']=$this->report->class_list_birthday($class,$classlevel,$stream,$date);
           echo view('system/prepare_birthday_message',$data); 
            }elseif($msg_type==3){
                $data['term']=$this->request->getPost('term');
              $data['cl']=$this->report->class_list2($class,$classlevel,$stream,$year,$status);
           echo view('system/prepare_balance_message',$data); 
            }elseif($msg_type==6){
              $data['cl']=$this->report->class_list2($class,$classlevel,$stream,$year,2);
           echo view('system/show_installment_messages',$data); 
            }elseif($msg_type==16){
              $data['cl']=$this->report->class_list2($class,$classlevel,$stream,$year,2);
           echo view('system/show_custom_messages',$data); 
            }
            
         }

  function school_route(){
         return view('templates/header')
            .view('reports/forms/school_routes_list')
            .view('templates/footer');
           
     }
     function view_route_students(){
        $id=$this->request->getPost('id');
       $data = array(
               'list' => $this->report->get_school_station($id),
                 'classes' => $this->report->get_school_classes(),
               'rtid' => $id
            );
            return view('reports/forms/specific_students_route',$data); 
     }
     function view_route_shedule(){
         $data = array(
               'list' => $this->report->get_school_station($this->request->getPost('routeid')),
               'rtid' => $this->request->getPost('routeid'),
                'class_id' => $this->request->getPost('class_id'),
               'dates' => $this->request->getPost('thedate')
            );
         //print_r($data);
     return view('reports/forms/routes_shedule_by_dates',$data); 
     }
   function school_routes_list2(){
       $data=array(
         'thedate' => $this->request->getPost('thedate')
       ); 
     return view('reports/forms/school_routes_list2',$data); 
     }

     function balance_sheet() {
      return view('templates/header')
            .view('reports/balance-sheet-date-filter')
            .view('templates/footer');    

     } 
     function balance_sheet_info(){
        $thedate = $this->request->getPost('thedate');
           // list($startingdate, $endingdate) = explode('-', $thedate);
            //  $enddate = strtotime($endingdate);
             $sdate = strtotime($thedate. ' 23:59:59');
            //echo $thedate;
            $data['thedate']=$sdate;
            return view('reports/forms/school_balancesheet',$data); 
     }
     function application_report(){
         return view('templates/header')
            .view('reports/application_report_view')
            .view('templates/footer');  
     }
     function process_application_report(){
       $thedate = $this->request->getPost('thedate');
       $classlevel = $this->request->getPost('classlevel');
       $class = $this->request->getPost('class');
       $status = $this->request->getPost('status');
         list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate);
            $sdate = strtotime($startingdate);
            //echo $thedate;
            $app=$this->report->fetch_app_report(date('Y-m-d', $sdate), date('Y-m-d', $enddate),$classlevel,$class,$status);
            //print_r($app);
            $data=array(
                 'appl'=>$app,
                 'sdate'=>$sdate,
                 'enddate'=>$enddate
            );
            return view('reports/forms/application_list_view',$data);  
     }

     function vehicle_report(){
        return view('templates/header')
            .view('reports/vehicle_report_view')
            .view('templates/footer');  
     }
     function load_vehicle_reports(){
         $data=array(
                 'thedate'=>$this->request->getPost('thedate'),
            );
            return view('reports/forms/vehicle_report_list',$data); 
     }
     function vehicle_sales($vid,$sdate,$enddate){
    $data=array(
           'vid'=>$vid,
          'thedate'=>date('Y/m/d',$sdate).'-'.date('Y/m/d',$enddate)
            );
    return view('reports/forms/vehicle_sales_model',$data); 
     }

     function load_status_report(){
        $thedate=$this->request->getPost('thedate');
        $type=$this->request->getPost('type');
        $data=array(
            'thedate'=>$thedate,
            'type'=>$type,
            'vid'=>$this->request->getPost('vid')
        );
        //print_r($data);
        echo view('reports/forms/vehicle_sales_filtered',$data); 
     }
      function load_reports($sid,$yr){
         $data['student_id'] =  $sid;
            $data['id'] = $sid;
            $data['year'] = $yr;
             
         return view('reports/forms/all_fees_report',$data); 
     }
    function pocket_money(){
        return view('templates/header')
            .view('reports/pocket_money')
            .view('templates/footer'); 
     }
     function get_pocket_money(){
        $year = $this->request->getPost('year');
        $hostel = $this->request->getPost('hostel');
        $class = $this->request->getPost('class');
            $classlevel = $this->request->getPost('classlevel');
            $stream = $this->request->getPost('stream');
            $data['classlevel']=$this->request->getPost('classlevel');
            $data['class']=$this->request->getPost('class');
            $data['stream']=$this->request->getPost('stream');
            $data['year']=$this->request->getPost('year');
            $data['bd_val']=$this->report->pocket_money_model($class,$classlevel,$stream,$year,$hostel);
           
           echo view('reports/forms/pocket_money_list',$data);    
     }
     function get_bording_details(){
        $year = $this->request->getPost('year');
        $data=array(
         'year'=>$year
        );
           
           echo view('reports/forms/boarding_students_list',$data); 
     } 
      function project_report(){
        return view('templates/header')
            .view('reports/project_report')
            .view('templates/footer'); 
     }

function get_bording_admission(){
        $year = $this->request->getPost('year');
        $hostel = $this->request->getPost('hostel');
        $class = $this->request->getPost('class');
            $classlevel = $this->request->getPost('classlevel');
            $stream = $this->request->getPost('stream');
            $data['classlevel']=$this->request->getPost('classlevel');
            $data['class']=$this->request->getPost('class');
            $data['stream']=$this->request->getPost('stream');
            $data['year']=$this->request->getPost('year');
            $data['term']=$this->request->getPost('term');
            $data['admission']=$this->report->get_bording_detail($class,$classlevel,$stream,$year,$hostel);

      echo view('student/forms/admission_boarding_list',$data); 
     }
function view_boarding_details($id,$term){
  $data['id']=$id;
  $data['term']=$term;
     echo view('student/forms/view_boarding_details',$data);
}

function pocket_money_bod(){
    return view('templates/header')
            .view('student/boarding_pocket_money')
            .view('templates/footer');  
}
function get_pocket_details(){
   $year = $this->request->getPost('year');
        $hostel = $this->request->getPost('hostel');
        $class = $this->request->getPost('class');
            $classlevel = $this->request->getPost('classlevel');
            $stream = $this->request->getPost('stream');
            $data['classlevel']=$this->request->getPost('classlevel');
            $data['class']=$this->request->getPost('class');
            $data['stream']=$this->request->getPost('stream');
            $data['year']=$this->request->getPost('year');
            $data['bd_val']=$this->report->get_bording_detail($class,$classlevel,$stream,$year,$hostel);
           
           echo view('student/forms/newpocket_money_students',$data); 
}
function cash_bank_report(){
    return view('templates/header')
            .view('reports/cash_bank_report')
            .view('templates/footer');
}

function cash_bank_list(){
    $data['thedate']=$this->request->getPost("thedate");
    echo view('reports/forms/cash_bank_list',$data); 
}

function view_cash_bank(){

     $data['thedate']=$this->request->getVar("thedate");
     $data['id']=$this->request->getVar("ids");
    echo view('reports/forms/cash_bank_view',$data); 
}

function select_students(){
        $status = $this->request->getPost('status');
        $year = $this->request->getPost('year');
        $class = $this->request->getPost('class');
            $classlevel = $this->request->getPost('classlevel');
            $stream = $this->request->getPost('stream');
            $admType = $this->request->getPost('admType');
           $data['admType']=$admType;
            $data['classlevel']=$this->request->getPost('classlevel');
            $data['class']=$this->request->getPost('class');
            $data['stream']=$this->request->getPost('stream');
            $data['year']=$this->request->getPost('year');

            $data['cl']=$this->report->class_list2($class,$classlevel,$stream,$year,$status);
             //print_r($data);
           
           echo view('company/form/project_students',$data); 
         }
          function fetch_class_list_byname(){
       $name=$this->request->getPost('name');
        $name=trim($name);
        $name_parts = explode(" ", $name);
       // print_r($name_parts);
      
       $year=$this->request->getPost('year');
       $data['year']=$this->request->getPost('year');
       $data['time']=2;
            $data['cl']=$this->report->class_list_byname($name_parts,count($name_parts),$year);
            $studentIds = array_map(static function ($student) {
                return (int) $student->id;
            }, $data['cl']);

            if (count($studentIds) > 0) {
                $paymentsModel = new PaymentsModel();
                $paymentsModel->primeTermBalanceContext($studentIds, (int) $year, session()->get('db_name'));
            } else {
                PaymentsModel::clearTermBalanceContext();
            }

            try {
                echo view('reports/forms/view_student_list',$data); 
            } finally {
                PaymentsModel::clearTermBalanceContext();
            }
         }
         
          function get_pocket_money_list(){
   $year = $this->request->getPost('year');
        $hostel = $this->request->getPost('hostel');
        $class = $this->request->getPost('class');
            $classlevel = $this->request->getPost('classlevel');
            $stream = $this->request->getPost('stream');
            $data['classlevel']=$this->request->getPost('classlevel');
            $data['staff_id']=$this->request->getPost('staff_id');
            $data['class']=$this->request->getPost('class');
            $data['stream']=$this->request->getPost('stream');
            $data['year']=$this->request->getPost('year');
            $data['bd_val']=$this->report->get_bording_detail($class,$classlevel,$stream,$year,$hostel);
           
           echo view('bills/forms/pocket_refund_view',$data); 
}

public function view_pocket_money($student_id){
    $data['student_id']=$student_id;
 echo view('reports/forms/pocket_money_view',$data);
}

public function pocket_transaction($student_id,$trans_no){
    $data['student_id']=$student_id;
    $data['trans_no']=$trans_no;
echo view('reports/forms/pocket_money_transactions',$data);
}

function get_pocket_money_listEdit(){
   $year = $this->request->getPost('year');
        $hostel = $this->request->getPost('hostel');
        $class = $this->request->getPost('class');
            $classlevel = $this->request->getPost('classlevel');
            $stream = $this->request->getPost('stream');
            $data['classlevel']=$this->request->getPost('classlevel');
            $data['staff_id']=$this->request->getPost('staff_id');
            $data['class']=$this->request->getPost('class');
            $data['stream']=$this->request->getPost('stream');
            $data['year']=$this->request->getPost('year');
            $data['vouch_number']=$this->request->getPost('trans_no');
            $data['bd_val']=$this->report->get_bording_detail($class,$classlevel,$stream,$year,$hostel);
           
           echo view('bills/forms/pocket_refund_viewEdit',$data); 
}

   public function class_list_Summary() {
    $year = $this->request->getGet('year');
    $id = $this->request->getGet('id');

    // Validate the year input to ensure it's a valid number
    if (!is_numeric($year) || strlen($year) !== 4) {
        echo "Please enter a valid year.";
        return;
    }

    // Calculate start and end dates based on the entered year
    $startDate = "{$year}-01-01"; // January 1st of the specified year
    $endDate = "{$year}-12-31";   // December 31st of the specified year

    // Fetch the class list using the year, id, and date range
    $data['list'] = $this->report->getClassList($year, $id, $startDate, $endDate);
    $data['year'] = $year;
    $data['id'] = $id;

    // Debugging output to check if data is fetched correctly
    if (empty($data['list'])) {
        echo "No data found for the selected class and year.";
    } else {
        echo view('reports/forms/view_class_list', $data);
    }
}

function recalculate(){
    $year=2024;
  $pk= $this->bmodel->get_item_name('pocket_money_transaction_tbl',$where=array('academic_year'=>$year)); 
  $pocket_data=array(); 
  foreach($pk as $k){
    $data=$k->student_id."".$k->transaction_no;
     if (!in_array($data, $pocket_data)) {
        array_push($pocket_data, $data);
    }else{
        echo $data.'</br>';
    }

  } 
  //print_r($pocket_data);
}

function trial_balance(){
            return view('templates/header')
            .view('reports/trial_balance')
            .view('templates/footer');   
        }

         function get_trial_balance() {
            $cmp = $this->bmodel->get_item_name('company_tbl', $where = array('created_by >' => 0));
            $thedate = $this->request->getPost('thedate');
            list($startingdate, $endingdate) = explode('-', trim($thedate));
            // print_r($thedate);
            // Convert dd/mm/yyyy to yyyy-mm-dd format for strtotime to work correctly
            $startingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($startingdate))));
            $endingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($endingdate))));
            
            // Trim whitespace and specify time if necessary
            $sdate = strtotime(trim($startingdate) . ' 00:00');
            $enddate = strtotime(trim($endingdate) . ' 23:59');
            
            echo '<div id="printreport">';
            echo "<h5>" . htmlspecialchars($cmp[0]->company_name) . "</h5>";
            echo "<h5>Trial Balance Report</h5>";
            echo "<h5>Report Date " . date('d/m/Y H:i', $sdate) . " - " . date('d/m/Y H:i', $enddate) . "</h5>";
            
            $all = $this->report->getAccountList();
            // print_r($all[1]->account_type_id);
            
           

            if (count($all) > 0) {
                echo '<table class="table table-bordered">
                <tr>
                    <th>Ledger Name</th>
                    <th>Ledger Type</th>
                    <th>Debit</th>
                    <th>Credit</th>
                </tr>';
                // Initialize total debit and credit before the account loop
                $totaldebit = 0;
                $totalcredit = 0;
                 $balanceb=0;
                foreach ($all as $done) {
                    $debitequit=0;
                    $debitequit=0;
                    $debita=0;
                    $credita=0;
                    $debit = 0; // Reset debit for the current account
                    $credit = 0; // Reset credit for the current account
                    $ledger_nature = isset($done->ledger_nature) ? $done->ledger_nature : null;
                     if($done->account_type_id==8){
                          //calculating balance before the date----
                          $s='2020-01-01';
                          $std = strtotime($s);
                          // Extract the year from sdate
                $year = date('Y', $sdate);
                // $prevyear=$year - 1;
                // $dateEndOfYear = "$prevyear-12-31";
                // $endOfYearTimestamp = strtotime($dateEndOfYear); // This converts it to a timestamp
                 $beforeequit = $this->report->beforealllequity($done->id, date('Y-m-d H:i', $std), date('Y-m-d H:i', $enddate));
                //   $beforeequit = $this->report->beforeallledge($done->id, date('Y-m-d H:i', $std), date('Y-m-d H:i', $sdate));
                         
                            $balancebequty=0;
                           foreach($beforeequit as $bf){
                                if($bf->transation_nature==2){
                              $balancebequty=$balancebequty+$bf->amount;
                            //   $debit=$balancebequty;
                              }else{
                             //  echo $balanceb;
                            $balancebequty=$balancebequty-$bf->amount;
                            $credit =$balancebequty;
                             }
                             }
                        }else if($done->account_type_id==3){
                            $allledger = $this->report->allledger($done->id, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
                    // print_r($allledger);
                           foreach ($allledger as $do) {
                              $totals = isset($do->amount) ? $do->amount : 0  ; 
                                if ($do->transation_nature == 2) { // Debit
                                    $debit += $totals;
                                   } elseif ($do->transation_nature == 1) { // Credit
                                     $credit += $totals;
                                     }
                           }
                        }elseif($done->account_type_id==4){
                    $allledger = $this->report->allledger($done->id, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
                           foreach ($allledger as $do) {
                              $totals = isset($do->amount) ? $do->amount : 0  ; 
                                if ($do->transation_nature == 2) { // Debit
                                    $debit += $totals;
                                   } elseif ($do->transation_nature == 1) { // Credit
                                     $credit += $totals;
                                     }
                           }
                        }elseif($done->account_type_id==10){
                    $allledger = $this->report->allledger($done->id, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
                           foreach ($allledger as $do) {
                              $totals = isset($do->amount) ? $do->amount : 0  ; 
                                if ($do->transation_nature == 2) { // Debit
                                    $debit += $totals;
                                   } elseif ($do->transation_nature == 1) { // Credit
                                     $credit += $totals;
                                     }
                           }
                        }else{
                            //calculating balance before the date----
                               $s='2020-01-01';
                            //    $s='01-01-2020';
                            //    $end = strtotime('-1 day',strtotime($sdate));
                               $std = strtotime($s);
              
                             // echo date('Y-m-d',$end);
                    $before = $this->report->beforeallledge($done->id, date('Y-m-d H:i', $std), date('Y-m-d H:i', $sdate));
                           
                            //  print_r($done->id);echo "<br>";print_r($done->account_name);echo "<br>";
                              $balanceb=0;
                            //   print_r($before);
                            foreach ($before as $bf) {
                                
                                if ($bf->trans_type == 4 || $bf->trans_type == 5) {
                                    $approval_status1 =$this->amodel->get_student_details('approval_numbers', $where = array('trans_no' => $bf->trans_no, 'trans_type' => $bf->trans_type));
                                    if (count($approval_status1) == 0) {
                                        // print_r("none");
                                        continue;
                                    }
                    
                                    $approval_status = $this->amodel->get_student_details('approval_history', $where = array('app_no' => $approval_status1[0]->app_id, 'hstatus' => 1));
                                    if (count($approval_status) == 0) {
                                        continue;
                                    }
                                    $check_status = $this->amodel->get_student_details('transaction_numbers_tbl', $where = array('status' => 1, 'trans_type_id' => $bf->trans_type, 'trans_number' => $bf->trans_no));
                                    if (count($check_status) == 0) {
                                        continue;
                                    }
                                }
                                if ($bf->ledger_id == 10 && $bf->trans_type == 3) {
                                    $check_status = $this->amodel->get_student_details('transaction_numbers_tbl', $where = array('status' => 1, 'trans_type_id' => $bf->trans_type, 'trans_number' => $bf->trans_no, 'trans_desc !=' => ""));
                                    if (count($check_status) == 0) {
                                        continue;
                                    }
                                } else if ($bf->ledger_id == 10 && $bf->trans_type != 3 && $bf->transation_nature == 1) {
                                    continue;
                                }
                                if ($bf->transation_nature == 2) { // Assuming this means it's a Debit
                                    $balanceb += $bf->amount; // Increase balance for debit transactions
                                } else { // This assumes that anything else is a Credit
                                    $balanceb -= $bf->amount; // Decrease balance for credit transactions
                                }

                            }
                            
                            //calculating balance before the date end here----
                    $allledger = $this->report->allledger($done->id, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));

                           foreach ($allledger as $do) {
                            if ($do->trans_type == 4 || $do->trans_type == 5) {
                                $approval_status1 =$this->amodel->get_student_details('approval_numbers', $where = array('trans_no' => $do->trans_no, 'trans_type' => $do->trans_type));
                                if (count($approval_status1) == 0) {
                                    continue;
                                }
                
                                $approval_status = $this->amodel->get_student_details('approval_history', $where = array('app_no' => $approval_status1[0]->app_id, 'hstatus' => 1));
                                if (count($approval_status) == 0) {
                                    continue;
                                }
                            }
                            if ($do->ledger_id == 10 && $do->trans_type == 3) {
                                $check_status = $this->amodel->get_student_details('transaction_numbers_tbl', $where = array('status' => 1, 'trans_type_id' => $do->trans_type, 'trans_number' => $do->trans_no, 'trans_desc !=' => ""));
                                if (count($check_status) == 0) {
                                    continue;
                                }
                            } else if ($do->ledger_id == 10 && $do->trans_type != 3 && $do->transation_nature == 1) {
                                continue;
                            }
                              $totals = isset($do->amount) ? $do->amount : 0  ; 
                                if ($do->transation_nature == 2) { // Debit
                                    $debit += $totals;
                                   } elseif ($do->transation_nature == 1) { // Credit
                                     $credit += $totals;
                                     }
                           }
                        }
        
                        
                    // Calculate balance based on ledger_nature
                    if ($ledger_nature == 2) {
                        if($done->account_type_id==1){
                        $balancenow = $debit - $credit; // Ledger nature 2: Debit - Credit
                        $balance=$balanceb+$balancenow;
                            //  print_r($balancenow);echo "<br>";
                        }elseif($done->account_type_id==2){
                            $balancenow = $debit - $credit; // Ledger nature 2: Debit - Credit
                            $balance=$balanceb+$balancenow;
                        }elseif($done->account_type_id==5){
                            $balancenow = $debit - $credit; // Ledger nature 2: Debit - Credit
                            $balance=$balanceb+$balancenow;
                        }elseif($done->account_type_id==9){
                            $balancenow = $debit - $credit; // Ledger nature 2: Debit - Credit
                            $balance=$balanceb+$balancenow;
                        }else{
                            $balance = $debit - $credit; // Ledger nature 2: Debit - Credit
                        }
                    } elseif ($ledger_nature == 1) {
                        if($done->account_type_id==6){
                            $balancenow = $credit - $debit; // Ledger nature 2: Debit - Credit
                            $balance=$balanceb+$balancenow;
                            //  print_r($balancenow);echo "<br>";
                        }elseif($done->account_type_id==7){
                            $balancenow = $credit - $debit; // Ledger nature 2: Debit - Credit
                            $balance=$balanceb+$balancenow;
                            //  print_r($balancenow);echo "<br>";
                        }elseif($done->account_type_id==11){
                            $balancenow = $credit - $debit; // Ledger nature 2: Debit - Credit
                            $balance=$balanceb+$balancenow;
                            //  print_r($balancenow);echo "<br>";
                        }elseif($done->account_type_id==12){
                            $balancenow = $credit - $debit; // Ledger nature 2: Debit - Credit
                            $balance=$balanceb+$balancenow;
                            //  print_r($balancenow);echo "<br>";
                        }elseif($done->account_type_id==13){
                            $balancenow = $credit - $debit; // Ledger nature 2: Debit - Credit
                            $balance=$balanceb+$balancenow;
                            //  print_r($balancenow);echo "<br>";
                        }elseif($done->account_type_id==8){
                            // $balancenow = $credit - $debit; // Ledger nature 2: Debit - Credit
                            $balance=$balancebequty;
                            //  print_r($balancebequty);echo "<br>";
                        }else{
                            $balance = $credit - $debit; // Ledger nature 1: Credit - Debit
                        }
                    } else {
                        $balance = 0; // Default case
                    }
                
                    
                    // Output the row for the current account
                    echo '<tr>';
                    echo '<td style=""> ' . htmlspecialchars($done->account_name) . '</td>';
                    echo '<td style=""> ' . htmlspecialchars($done->type_name) . '</td>';
                    
                    // Display balance based on ledger_nature
                    if ($ledger_nature == 2) {
                        echo '<td style="padding-left:150px"> ' . number_format($balance) . '</td>';  // Credit side
                        echo '<td style="padding-left:150px">  </td>'; // Debit side
                    } elseif ($ledger_nature == 1) {
                        echo '<td style="padding-left:150px">  </td>'; // Debit side
                        echo '<td style="padding-left:150px"> ' . number_format($balance) . '</td>'; // Credit side
                    } else {
                        echo '<td style="padding-left:150px"> ' . number_format($balance) . '</td>'; // Default for other types
                        echo '<td style="padding-left:150px">  </td>'; // Debit side
                    }
                    
               echo "<td><center><a class=\"btn btn-primary btn-sm\" href=\"javascript:void()\" onclick=\"detail_view('" . $done->id . "','" . $thedate. "')\" title=\"View this ledger\"><span class=\"view\">View</span></a></center></td>";

                    echo '</tr>';
                    
        // Decide how to incorporate balanceb
        if ($done->ledger_nature == 2) { // Example for an account that operates with 'Debit - Credit'
            $debita = $balanceb; // All of balanceb is treated as a debit
         } elseif ($done->ledger_nature == 1) { // For accounts where it's 'Credit - Debit'
               $credita = $balanceb; // All of balanceb is treated as a credit
         }
                    // Accumulate total debit and credit
                    $totaldebit += $debit + $debita;
                    $totalcredit += $credit +$credita;
                            //   print_r($credit);

                      }
        //for retained earnings
                      echo '<tr style=" ">';
// Fetch company name
$cmp = $this->bmodel->get_item_name('company_tbl', array('created_by >' => 0)); 
// Your start date
                          $s='2020-01-01';
                          $sdate = strtotime($s);
$thedate = $this->request->getPost('thedate');
// list($startingdate, $endingdate) = explode('-', trim($thedate));

// $startingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($startingdate))));
// $endingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($endingdate))));

// Set timestamps for the start and end of the date period
// $sdate = strtotime(trim($startingdate) . ' 00:00');
// $enddate = strtotime(trim($endingdate) . ' 23:59');

// Initialize variables for sales calculation
$name = "Sales";
$sold = "Cost of Goods Sold";
$other = "Other Income";

// Get sales data
$sales =$this->report->sales($name);
$cgs = $this->report->solid($sold);
$oth = $this->report->other($other);

// Calculate total sales
$totalsales = 0;
if (!empty($sales)) {
    foreach ($sales as $sale) {
        $saleid = $sale->id;
    }

    $all =$this->report->all_sales($saleid, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));

    foreach ($all as $fo) {
        $ledger = $fo->ledger_id;
        $type = $fo->ledger_type;
        $result = $this->report->allofthem($ledger, $type, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        $totalDebits = $totalCredits = 0;

        // Calculate total debits and credits
        foreach ($result as $pes) {
            if ($pes->transation_nature == 2) {
                $totalDebits += $pes->amount;
            } elseif ($pes->transation_nature == 1) {
                $totalCredits += $pes->amount;
            }
        }

        // Calculate totals
        $totals = abs($totalDebits - $totalCredits);
        $totalsales += $totals;
    }
}

// Calculate cost of goods sold
$totalSold = 0;
if (!empty($cgs)) {
    foreach ($cgs as $cgsItem) {
        $cgid = $cgsItem->id;
    }

    $goods_sold = $this->report->cost_sold($cgid, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
    
    foreach ($goods_sold as $fo1) {
        $ledger1 = $fo1->ledger_id;
        $type = $fo1->ledger_type;
        $result = $this->report->allofthem1($ledger1, $type, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        $totalDebits = $totalCredits = 0;

        // Calculate total debits and credits for cost of goods sold
        foreach ($result as $pes) {
            if ($pes->transation_nature == 2) {
                $totalDebits += $pes->amount;
            } elseif ($pes->transation_nature == 1) {
                $totalCredits += $pes->amount;
            }
        }

        $totals = abs($totalDebits - $totalCredits);
        $totalSold += $totals;
    }
}

// Gross profit calculation
$gross = $totalsales - $totalSold;

// Calculate other income
$totalIncome = 0;
if (!empty($oth)) {
    foreach ($oth as $ot) {
        $othersid = $ot->id;
    }

    $other_income = $this->report->other_income($othersid, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
    
    foreach ($other_income as $fo2) {
        $ledger1 = $fo2->ledger_id;
        $type = $fo2->ledger_type;
        $result = $this->report->allofthem1($ledger1, $type, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        $totalDebits = $totalCredits = 0;

        // Calculate total debits and credits for other income
        foreach ($result as $pes) {
            if ($pes->transation_nature == 2) {
                $totalDebits += $pes->amount;
            } elseif ($pes->transation_nature == 1) {
                $totalCredits += $pes->amount;
            }
        }

        $totals = abs($totalDebits - $totalCredits);
        $totalIncome += $totals;
    }
}

// Total calculations
$totaly = $gross + $totalIncome;

// Find total expenses
$id = 10; // Assuming this is some static ID
$thy = $this->report->expense($id);
$totalexpense = 0;

foreach ($thy as $coder) {
    $expensname = $coder->type_name; // Get the type_name
    $getexp = $this->report->all_expence($expensname, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
    
    foreach ($getexp as $kepns) {
        $ledgerexp = $kepns->ledger_id; // Use this property
        $typek = $kepns->ledger_type;

        // Get detailed expense for the current ledger and type
        $resulte =$this->report->allofthemexpe($ledgerexp, $typek, date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        if (!empty($resulte)) {
            $totalDebits = $totalCredits = 0;

            // Calculate total debits and credits for expenses
            foreach ($resulte as $pes) {
                if ($pes->transation_nature == 2) {
                    $totalDebits += $pes->amount;
                } elseif ($pes->transation_nature == 1) {
                    $totalCredits += $pes->amount;
                }
            }

            $totals = abs($totalDebits - $totalCredits);
            $totalexpense += $totals;
        }
    }
}

// Final profit/loss calculation
$tota = $totaly - $totalexpense;

                      echo '<td>Retained Earnings</td>';
                      echo '<td></td>';
                       echo '<td style="padding-left:150px"></td>';
                     echo '<td style="padding-left:150px"><b>' . number_format($gross) . '</b></td>';
                      echo '</tr>';
                         // Output the total row
                        echo '<tr style="border-top:2px solid silver">';
                        echo '<td><b>Total</b></td>';
                        echo '<td></td>';
                         echo '<td style="padding-left:150px"><b>' . number_format($totaldebit) . '</b></td>';
                       echo '<td style="padding-left:150px"><b>' . number_format($totalcredit+$tota) . '</b></td>';
                        echo '</tr>';
                        
                       echo '</table>';
                    
                  } else {
                      echo 'No records found.';
                  }
        

        }
        function view_trial_balance(){
            $id = $this->request->getVar('ids');
            $thedate = $this->request->getVar('thedate');
            // print_r($thedate);
        
            list($startingdate, $endingdate) = explode('-', $thedate);
            
        // Convert dd/mm/yyyy to yyyy-mm-dd format for strtotime to work correctly
        $startingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($startingdate))));
        $endingdate = date('Y-m-d', strtotime(str_replace('/', '-', trim($endingdate))));
            $sdate = strtotime(trim($startingdate) . ' 00:00:00');
            $enddate = strtotime(trim($endingdate) . ' 23:59:59');
            $s='2020-01-01';
            $std = strtotime($s);
            // Logging for checking date values before querying 
            $sdate = date('Y-m-d H:i:s', $sdate);
            $enddate = date('Y-m-d H:i:s', $enddate);
            $data['before'] =$this->report->beforeallledge($id, date('Y-m-d H:i', $std), $sdate);
            $data['ledger'] = $this->report->allledger($id, $sdate, $enddate);
           
            // Pass the formatted dates to the view
            $data['sdate'] = $sdate;
            $data['enddate'] = $enddate;
            $data['id'] = $id;
        
            echo view('reports/forms/view_trial_balance', $data);

       }

    function receivable_report(){
         return view('templates/header')
            .view('reports/account_receivable_report')
            .view('templates/footer');
       }

function account_receivable_list(){
    $data['thedate']=$this->request->getPost("thedate");
    echo view('reports/forms/account_receivable_list',$data); 
}

function check_unbalanced_trans(){
    return;
    $type=$this->request->getPost("type");
    //echo $type;

     $data=array(
    "type"=> $type,
  
    );
       
     $n=0;
     $pr=0;
     
     $total2=0;
    
$trans_credit=$this->bmodel->get_all_creditnote($type,2,0);
if(count($trans_credit)>0){
foreach ($trans_credit as $ts) {
 $trans_debit=$this->bmodel->get_all_creditnote($type,1,$ts->trans_no);

 if(count($trans_debit)==0){
     if(count($trans_debit) != $ts->total){

    $items = $this->bmodel->get_item_name('item_transation_tbl', array('trans_number' => $ts->trans_no,'trans_type'=>1));

$totaly=0;
 $sum=0;
 $rep=0;
 $discount=0;
 $all = $this->bmodel->get_item_name('ledger_transaction_tbl', array('trans_no' => $ts->trans_no,'trans_type'=>1,));
 $k=0;
     foreach($items as $it){
         $k++;
    $totaly=$totaly+$it->unit_price;
$ntm = $this->bmodel->get_item_name('ledger_transaction_tbl', array('trans_no' => $ts->trans_no,'trans_type'=>1,'trans_item'=>$it->item_id));

   if(count($ntm)>0 && $type==1 && $it->item_id==64){
    $discount=64;
    $data=array(
      'amount'=>$ntm[0]->amount*-1,
    );
     $builder = $this->db->table('ledger_transaction_tbl');
    $builder->where('id',$ntm[0]->id);
    $builder->update($data);
     } 
     $repeat=array();
     if(count($ntm)>1 && $type==1){
        foreach($ntm as $tm){
            $temp=$tm->trans_item.''.$tm->amount;
            if (!in_array($temp, $repeat)) {
        array_push($repeat, $temp);
             }else{
              $rep=100; 
     $builder = $this->db->table('ledger_transaction_tbl');
    $builder->where('id',$tm->id);
    $builder->delete(); 
             }
            
        }
   
     } 
    if(count($ntm)==0 && $type==1){
       $pr=1;
    //   if($it->unit_price != $all[$k-1]->amount){
        $leger_items = $this->bmodel->get_item_name('items_ledgers_tbl',$where = array('item_id' => $it->item_id)); 
        $leger = $this->bmodel->get_item_name('accounts_tbl',$where = array('id' => $leger_items[0]->account_id)); 
         
       
               $fix = [
                       'ledger_id' => $leger_items[0]->account_id,
                       'ledger_type' => $leger[0]->account_type_id,
                       'trans_item' => $it->item_id,
                       'trans_no' => $it->trans_number,
                       'trans_type' => 1,
                       'amount' => $it->unit_price,
                       'transation_nature' => 1,
                       'name_type_id' => 1,
                       'name_id' => $ts->name_id,
                       'balance' => 0
                       ];
                 
    //  print_r($rcledger);
    //  return;
              
       $this->smodel->SaveData('ledger_transaction_tbl',$fix);
    //             }else{

    //           $data=array(
    //   'trans_item'=>$it->item_id,
    //          );
    //  $builder = $this->db->table('ledger_transaction_tbl');
    // $builder->where('id',$all[$k-1]->id);
    // $builder->update($data);

    //             } 
 } }

if($type==1){
 if(($totaly -$ts->total) ==0 && $discount !=64){
    //echo $totaly.'=='.$ts->total;
  $sum=1;
   $fix = [
'amount' => $totaly
         ];
     $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $ts->trans_no,'trans_type'=>1,'transation_nature'=>2),$fix);    
 
 }else{

 } 
 }  

 $thn = $this->bmodel->get_item_name('transaction_numbers_tbl', array('trans_number' => $ts->trans_no,'trans_type_id'=>$type));
$bmodel=$this->bmodel;
//////name////////////
 $leger_transaction[0]=$ts;
if($leger_transaction[0]->name_type_id == 4){
$app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
$student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
$student_id = $app[0]->id;
$type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
$name_type = $type_name[0]->name_type;

}
else if($leger_transaction[0]->name_type_id == 3){
 $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
 $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
 $student_id = $app[0]->id;
 $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
 $name_type = $type_name[0]->name_type;
}else if($leger_transaction[0]->name_type_id == 1){
 $app = $bmodel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
 $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
 $student_id = $app[0]->id;
 $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
 $name_type = $type_name[0]->name_type;
}else if($leger_transaction[0]->name_type_id == 7){
 $app = $bmodel->get_item_name('users',$where = array('user_id'=>$leger_transaction[0]->name_id));
 $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
 $student_id = $app[0]->user_id;
 $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
 $name_type = $type_name[0]->name_type;
}else if($leger_transaction[0]->name_type_id == 2){
 $app = $bmodel->get_item_name('supplier_tbl',$where = array('supplier_id'=>$leger_transaction[0]->name_id));
 $student_name = $app[0]->supplier_name; 
 $student_id = $app[0]->supplier_id;
 $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
 $name_type = $type_name[0]->name_type;
}else if($leger_transaction[0]->name_type_id == 6){
$admn = $bmodel->get_item_name('other_students_tbl', $where = array('id'=>$leger_transaction[0]->name_id));
$student_name = $admn[0]->first_name.' '.$admn[0]->middle_name.' '.$admn[0]->last_name;
$type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
 $name_type = $type_name[0]->name_type;
}else if($leger_transaction[0]->name_type_id == 5){
$pad = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $ts->trans_no,'trans_type' => $type,'name_type_id' => 1));
if(count($pad)>0){
$app = $bmodel->get_item_name('students', $where = array('id' => $pad[0]->name_id));
                             
 $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
 $student_id = $app[0]->id;
 $type_name = $bmodel->get_item_name('name_type_tbl',$where = array('id'=>1));
 $name_type = $type_name[0]->name_type;
     }
 }
else{
    $student_name="";
    $name_type="";
}
 /////name/////////
 
         $n++;
 
 
     $diff=0;
     echo "<tr>";
    echo "<td>" . $n . "</td>";
    echo "<td class='text-center'>" . $ts->trans_no. "</td>";
    echo "<td class=''>" . $thn[0]->trans_date . "</td>";
      echo "<td class='text-right'>" .  $student_name. "</td>";
      echo "<td class='text-right'>" . $name_type. "</td>";
      echo "<td class='text-right'>" . number_format($ts->total). "</td>";
    // echo "<td class='text-right'>" . number_format($trans_debit[0]->total) . "</td>";
    echo "<td class='text-right'>" . number_format($diff) . "</td>";
    
    echo "<td class='text-right'>" . ($totaly-$ts->total)."->".$rep."</td>";
    
    echo "<tr>";
     }
 }else{
     $fix = [
           'ledger_id' => 6,
           'ledger_type' => 7,
           'trans_item' => 0,
           'trans_no' => $ts->trans_no,
           'trans_type' => 1,
           'amount' =>$ts->total,
           'transation_nature' => 2,
           'name_type_id' => 1,
           'name_id' => $ts->name_id,
           'balance' =>$ts->total 
           ];
           if($type==1){
           $this->smodel->SaveData('ledger_transaction_tbl',$fix);
          }

    echo "<tr>";
    echo "<td class=''>" . $n. "</td>";
    echo "<td class='text-center'>" . $ts->trans_no. "</td>";
    echo "<td class='text-right'>no</td>";
    echo "<td class='text-right'>no</td>";
    echo "<td class='text-right'>no</td>";
    echo "<td class='text-right'>no</td>";
   
    "</tr>";
 }
    
}
}else{
    echo "<tr><td> No any transaction found</td></tr>";
}

}

function total_cash_colected(){
     helper('bank');
              $sdate=date('Y-m-d 00:00');
                $edate=date('Y-m-d 23:59');
                $results=bank_cash($sdate,$edate);
               // print_r($results);
                $ttl_collected=0;
                foreach ($results as $account) {
                   
               $ttl_collected=$ttl_collected + $account['amount_in'];
                }
                return number_format($ttl_collected);
}

function student_pocket_money(){
    $student_id=$this->request->getVar('ids');
         $mydate=$this->request->getVar('thedate');

            $data['student_id']=$student_id;
            $data['thedate']=$mydate;
 echo view('reports/forms/student_pocket_money',$data);

}

function student_boarding_history(){
    $student_id=$this->request->getVar('ids');
         $mydate=$this->request->getVar('thedate');

            $data['student_id']=$student_id;
            $data['thedate']=$mydate;
 echo view('reports/forms/student_boarding_history',$data);

}

function term_balance_report(){
      return view('templates/header')
            .view('reports/term_balance_view')
            .view('templates/footer');
}

function school_fees_schedule(){
      return view('templates/header')
            .view('reports/school_fees_schedule')
            .view('templates/footer');
}

function load_school_fees_schedule(){
    $classId = (int) $this->request->getPost('class');
    $admissionType = $this->request->getPost('admission_type');
    $admissionFor = $this->request->getPost('admission_for');
    $qrUrl = $this->buildSchoolFeesSchedulePublicUrl($classId, $admissionType, $admissionFor);
    $qrImage = $this->generateSchoolFeesScheduleQr($qrUrl);

    $rows = $this->buildSchoolFeesScheduleRows($classId, $admissionType, $admissionFor);

    $schoolname = $this->report->get_schoolname();
    $company = count($schoolname) > 0 ? $schoolname[0] : null;
    echo view('reports/forms/school_fees_schedule_list', [
        'rows' => $rows,
        'schoolname' => $company ? $company->company_name : '',
        'company' => $company,
        'qrUrl' => $qrUrl,
        'qrImage' => $qrImage,
        'filters' => [
            'class' => $classId,
            'admission_type' => $admissionType,
            'admission_for' => $admissionFor,
        ],
    ]);
}

function public_school_fees_schedule(){
    $classId = (int) $this->request->getGet('class');
    $admissionType = $this->request->getGet('admission_type') ?: 'all';
    $admissionFor = $this->request->getGet('admission_for') ?: 'all';
    $rows = $this->buildSchoolFeesScheduleRows($classId, $admissionType, $admissionFor);
    $schoolname = $this->report->get_schoolname();
    $company = count($schoolname) > 0 ? $schoolname[0] : null;

    echo view('reports/public_school_fees_schedule', [
        'rows' => $rows,
        'schoolname' => $company ? $company->company_name : '',
        'company' => $company,
        'qrUrl' => $this->buildSchoolFeesSchedulePublicUrl($classId, $admissionType, $admissionFor),
        'qrImage' => '',
        'filters' => [
            'class' => $classId,
            'admission_type' => $admissionType,
            'admission_for' => $admissionFor,
        ],
    ]);
}

private function buildSchoolFeesScheduleRows($classId, $admissionType, $admissionFor)
{
    $classes = $this->getSchoolFeesScheduleClasses($classId);
    $typeOptions = $admissionType === 'all' ? [0, 3] : [(int) $admissionType];
    $forOptions = $admissionFor === 'all' ? [0, 2] : [(int) $admissionFor];
    $rows = [];

    foreach ($classes as $classRow) {
        foreach ($typeOptions as $type) {
            foreach ($forOptions as $for) {
                $items = $this->getSchoolFeesScheduleItems((int) $classRow->id, (int) $classRow->class_level, $type, $for);
                $total = 0;

                foreach ($items as $item) {
                    $total += (float) $item['amount'];
                }

                $rows[] = [
                    'class_id' => (int) $classRow->id,
                    'class_name' => $classRow->class_name,
                    'level_name' => $classRow->level_name,
                    'admission_type' => $this->schoolFeesAdmissionTypeName($type),
                    'admission_for' => $this->schoolFeesAdmissionForName($for),
                    'items' => $items,
                    'total' => $total,
                ];
            }
        }
    }

    return $rows;
}

private function buildSchoolFeesSchedulePublicUrl($classId, $admissionType, $admissionFor)
{
    return base_url('public_school_fees_schedule') . '?' . http_build_query([
        'db' => session()->get('db_id'),
        'class' => $classId,
        'admission_type' => $admissionType,
        'admission_for' => $admissionFor,
    ]);
}

private function generateSchoolFeesScheduleQr($url)
{
    helper('qrcode');
    $filename = 'school_fees_schedule_' . md5($url) . '.png';
    $path = ROOTPATH . 'public/qrcodes/' . $filename;

    if (! is_file($path)) {
        generate_qr_code($url, $filename);
    }

    return base_url('public/qrcodes/' . $filename);
}

private function getSchoolFeesScheduleClasses($classId)
{
    $builder = $this->db->table('classes_tbl');
    $builder->select('classes_tbl.id, classes_tbl.class_name, classes_tbl.class_level, class_level_tbl.level_name');
    $builder->join('class_level_tbl', 'class_level_tbl.id = classes_tbl.class_level');
    if ($classId > 0) {
        $builder->where('classes_tbl.id', $classId);
    }
    $builder->where('classes_tbl.status', 1);
    $builder->orderBy('class_level_tbl.id', 'ASC');
    $builder->orderBy('classes_tbl.id', 'ASC');

    return $builder->get()->getResult();
}

private function getSchoolFeesScheduleItems($classId, $levelId, $admissionType, $admissionFor)
{
    $items = [];
    $levelFee = $this->amodel->fetch_classLevel_fee($admissionFor === 2 ? 2 : 0, $levelId);
    $classFee = $this->amodel->fetch_class_fee($admissionFor === 2 ? 2 : 0, $classId);

    foreach ($levelFee as $item) {
        $items[] = $this->schoolFeesScheduleItemArray($item, 'Level Fee');
    }

    foreach ($classFee as $item) {
        $items[] = $this->schoolFeesScheduleItemArray($item, 'Class Fee');
    }

    if ($admissionType === 3) {
        $boardingClassFee = $this->amodel->fetch_boarding_fee($admissionFor === 2 ? 2 : 0, $classId);
        $boardingLevelFee = $this->amodel->fetch_boarding_fee2($admissionFor === 2 ? 2 : 0, $levelId);

        foreach ($boardingClassFee as $item) {
            $items[] = $this->schoolFeesScheduleItemArray($item, 'Boarding Fee');
        }

        foreach ($boardingLevelFee as $item) {
            $items[] = $this->schoolFeesScheduleItemArray($item, 'Boarding Fee');
        }
    }

    return $items;
}

private function schoolFeesScheduleItemArray($item, $source)
{
    return [
        'source' => $source,
        'item_name' => $item->item_name ?? '',
        'item_attribute' => $item->item_attribute ?? '',
        'item_size' => $item->item_size ?? '',
        'quantity' => isset($item->quantity) ? (float) $item->quantity : 1,
        'amount' => isset($item->item_price) ? (float) $item->item_price : 0,
    ];
}

private function schoolFeesAdmissionTypeName($type)
{
    return (int) $type === 3 ? 'Boarding' : 'Day';
}

private function schoolFeesAdmissionForName($for)
{
    return (int) $for === 2 ? 'New Comer' : 'Continuing';
}

function load_term_balance(){
     $status = $this->request->getPost('status');
        $year = $this->request->getPost('year');
        $class = $this->request->getPost('class');
            $classlevel = $this->request->getPost('classlevel');
            $stream = $this->request->getPost('stream');
            $data['classlevel']=$this->request->getPost('classlevel');
            $data['class']=$this->request->getPost('class');
            $data['stream']=$this->request->getPost('stream');
            $data['year']=$this->request->getPost('year');
            $data['time']=1;
            $data['cl']=$this->report->class_list2($class,$classlevel,$stream,$year,$status);
            $paymentsModel = new PaymentsModel();
            try {
                if (count($data['cl']) > 0) {
                    $studentIds = array_map(static function ($row) {
                        return (int) $row->id;
                    }, $data['cl']);
                    $paymentsModel->primeTermBalanceContext($studentIds, (int) $year, session()->get('db_name'));
                }

                $data = array_merge($data, $this->prepareTermBalanceSummary(
                    $data['cl'],
                    (int) $year,
                    (int) $classlevel,
                    (int) $class,
                    (int) $stream,
                    (int) $data['time']
                ));

                echo view('reports/forms/view_student_term_balances',$data);
            } finally {
                PaymentsModel::clearTermBalanceContext();
            }
}

protected function prepareTermBalanceSummary($classList, $year, $classlevel, $class, $stream, $time)
{
    $summary = [
        'schoolname' => '',
        'reportTitle' => '',
        'termBalanceRows' => [],
        'termBalanceTotals' => [
            'open' => 0,
            'installments' => 0,
            'paid' => 0,
        ],
    ];

    if (count($classList) === 0) {
        return $summary;
    }

    $schoolname = $this->report->get_schoolname();
    if (count($schoolname) > 0) {
        $summary['schoolname'] = $schoolname[0]->company_name;
    }

    if ($time == 1) {
        $levelName = $classlevel == 0 ? 'All Levels' : ($classList[0]->level_name ?? '');
        $className = $class == 0 ? 'All Classes' : ($classList[0]->class_name ?? '');
        $streamName = $stream == 0 ? 'All Stream' : ($classList[0]->stream_name ?? '');
    } else {
        $levelName = $classList[0]->level_name ?? '';
        $className = $classList[0]->class_name ?? '';
        $streamName = $classList[0]->stream_name ?? '';
    }

    $summary['reportTitle'] = trim($levelName . ' ' . $className . ' ' . $streamName) . ' Term Balances for ' . $year;

    $groupedClassList = [];
    foreach ($classList as $student) {
        $levelKey = (int) ($student->level_id ?? 0);
        if (! isset($groupedClassList[$levelKey])) {
            $groupedClassList[$levelKey] = [];
        }
        $groupedClassList[$levelKey][] = $student;
    }

    $mergedRows = [];
    foreach ($groupedClassList as $studentsInLevel) {
        $group = $this->buildTermBalanceGroup($studentsInLevel, $year);
        if ($group !== null) {
            foreach ($group['rows'] as $index => $row) {
                if (! isset($mergedRows[$index])) {
                    $mergedRows[$index] = $row;
                    continue;
                }

                $mergedRows[$index]['open'] += $row['open'];
                $mergedRows[$index]['ment'] += $row['ment'];
                $mergedRows[$index]['paid'] += $row['paid'];
                $mergedRows[$index]['balance'] += $row['balance'];
            }

            $summary['termBalanceTotals']['open'] += $group['totals']['open'];
            $summary['termBalanceTotals']['installments'] += $group['totals']['installments'];
            $summary['termBalanceTotals']['paid'] += $group['totals']['paid'];
        }
    }

    ksort($mergedRows);
    $summary['termBalanceRows'] = array_values($mergedRows);

    return $summary;
}

protected function buildTermBalanceGroup($classList, $year)
{
    if (count($classList) === 0) {
        return null;
    }

    $levelRows = $this->bmodel->get_item_name('class_level_tbl', ['id' => $classList[0]->level_id]);
    if (count($levelRows) === 0) {
        return null;
    }

    $installments = $this->bmodel->get_item_name('school_terms_tbl', [
        'academic_year' => $year,
        'type_id' => $levelRows[0]->academic_type,
    ]);
    if (count($installments) === 0) {
        return null;
    }

    helper('calc');

    $dbname = session()->get('db_name');
    $termTotals = [];
    foreach ($installments as $index => $installment) {
        $termTotals[$index] = [
            'open' => 0,
            'ment' => 0,
            'paid' => 0,
            'balance' => 0,
            'term_name' => $installment->term_name,
            'due_date' => $installment->due_date,
        ];
    }

    foreach ($classList as $student) {
        $results = findCalc((int) $student->id, $dbname, $year);
        if (! is_array($results) || count($results) === 0) {
            continue;
        }

        foreach ($termTotals as $index => &$termTotal) {
            if (! isset($results[$index]) || ! is_array($results[$index])) {
                continue;
            }

            $termResult = $results[$index];
            if ($index === 0) {
                $termTotal['open'] += (float) ($termResult['openingbalance'] ?? 0);
            }

            $termTotal['ment'] += (float) ($termResult['ment'] ?? 0);
            $termTotal['paid'] += (float) ($termResult['paid_amount'] ?? 0);
            $termTotal['balance'] += (float) ($termResult['mbalance'] ?? 0);
        }
        unset($termTotal);
    }

    $rows = [];
    $totals = [
        'open' => 0,
        'installments' => 0,
        'paid' => 0,
    ];

    foreach ($termTotals as $index => $termTotal) {
        $rows[] = [
            'term_name' => $termTotal['term_name'],
            'open' => $index === 0 ? $termTotal['open'] : 0,
            'ment' => $termTotal['ment'],
            'due_date' => $termTotal['due_date'],
            'paid' => $termTotal['paid'],
            'balance' => $termTotal['balance'],
        ];
        $totals['installments'] += $termTotal['ment'];
        $totals['paid'] += $termTotal['paid'];
    }

    if (isset($termTotals[0])) {
        $totals['open'] = $termTotals[0]['open'];
    }

    return [
        'rows' => $rows,
        'totals' => $totals,
    ];
}

function detailed_term_balances(){
     return view('templates/header')
            .view('reports/datailed_term_balance')
            .view('templates/footer');
    
}

function fetch_balance_detaialed_report(){


    $class = $this->request->getPost('class');
        $year = $this->request->getPost('year');
            $classlevel = $this->request->getPost('classlevel');
            $stream = $this->request->getPost('stream');
           $data['classlevel']=$this->request->getPost('classlevel');
            $data['class']=$this->request->getPost('class');
            $data['stream']=$this->request->getPost('stream');
            $data['year']=$this->request->getPost('year');
            $status=$this->request->getPost('status');
          
             
              $this->installment_balances($class,$classlevel,$stream,$year);
           //echo view('system/show_installment_messages',$data); 
            
}

function installment_balances($class,$classlevel,$stream,$year){
 
 $cl=$this->report->class_list2($class,$classlevel,$stream,$year,2);
    $period = $this->bmodel->get_item_name('class_level_tbl', $where = array('id' => $cl[0]->level_id));
    

                $schoolname=$this->report->get_schoolname();

                 $dateterm = $this->report->checkTerm_date(date('Y-m-d'),$year,$period[0]->academic_type);
                  //print_r($dateterm);
                  if (is_countable($dateterm) && count($dateterm) > 0) {
                    $term_name=$dateterm[0]->term_name;
                   }else{
                    $dateterm = $this->report->checkTerm_date2(date('Y-m-d'),$year,$period[0]->academic_type);
                     
                     $term_name=$dateterm[0]->term_name;
                   }
                   $installments = $this->bmodel->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$period[0]->academic_type));
                   $resulted['installments']=$installments;
                   
                   $i=0;
                   $myinst=[];
                    foreach($installments as $st){
                     $i++;
                      $myinst[] = $i . "-Term";
                     
                     }
               $data[] = array_merge(['#', 'ACADEMIC YR', 'NAMES','CLASS','STREAM','TYPE','FOR','ADMISSION DATE'], $myinst,['TOTAL']);

                   
                     //////////////////////////
                              $n=0;
                              $female=0;
                               $male=0;
                               $day=0;
                               $board=0;
                               $streamA=0;
                               $streamB=0;
                               $ne=0;
                               $c=0;
                      
                       helper('calc');

                            $dbname=session()->get('db_name');
                             if(count($cl)==0){
                               return;
                               }


                                foreach($cl as $le){
                                    $n++;
                                  if($le->gender=='Female'){
                                    $female=$female+1;
                                  }
                                  if($le->gender=='Male'){
                                    $male=$male+1;
                                  }

                                $student_id=$le->id;

                              $results=findCalc($student_id,$dbname,$year);
                          
                                  $type=$le->admission_type;
                                  $hst=$le->admission_type;

                                  if($type==3){
                                    $tp='B';
                                    $board++;
                                  }else{
                                     $tp='D';
                                     $day++;
                                  }

                                  if($le->stream_name=='A'){
                                    $streamA=$streamA+1;
                                  }else{
                                     $streamB=$streamB+1;
                                  }
                                  if($le->adimit_for==2){
                                    $new="New Comer";
                                    $ne++;
                                  }else{
                                     $new="Continous";
                                     $c++;
                                  }
                 $ctr_number="";
             $tinvoice = $this->bmodel->get_total_invoice_amount($student_id,$year);
                 if(count($tinvoice)==0){
                       continue;
                              }

                    $mbalance1=0;
                  $mbalance2=0;
                  $mbalance3=0;
                  $mbalance4=0;

                  $ttlAmount = 0;
                     $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                      $ddate="";
                      
             foreach ($installments as $r) {
                    $i++;
                    if($i==1){

                 $duedate1=$r->due_date;
             
                   $openingbalance=$results[0]['openingbalance'];
                       $ment=$results[0]['ment'];
                        $mbalance1=$ment;
                        $mbalance=$results[0]['mbalance'];
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[0]['today']==1){
                       $todaybalance=$results[0]['todaybalance']; 
                     }
                     }
                      if($i==2){
                       $duedate2=$r->due_date;
                        $ment=$results[1]['ment'];
                        $mbalance2=$ment;
                        $mbalance=$results[1]['mbalance'];
                        $paid_amount=$results[1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[1]['today']==1){
                       $todaybalance=$results[1]['todaybalance']; 
                     }
                     }
                   if($i==3){
                  $duedate3=$r->due_date;
         
                     $ment=$results[2]['ment'];
                        $mbalance3=$ment;
                        $mbalance=$results[2]['mbalance'];
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[2]['today']==1){
                       $todaybalance=$results[2]['todaybalance']; 
                     }
                     }

                     if($i==4){
                  $ment=$results[3]['ment'];
                        $mbalance4=$ment;
                        $mbalance=$results[3]['mbalance'];
                        $paid_amount=$results[3]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[3]['today']==1){
                       $todaybalance=$results[3]['todaybalance']; 
                     }
                     }
                     
                      } 
                      $mbalances = [1 => $mbalance1, 2 => $mbalance2, 3 => $mbalance3,4 => $mbalance4];
                     

             $phone = $this->db->query('SELECT phone1 FROM parents_tbl,parents_students_tbl WHERE parents_tbl.id = parents_students_tbl.parent_id AND'
               . ' parents_tbl.bill_account = 1  AND parents_students_tbl.student_id ='.$student_id.'');
             $pn = $phone->getResult(); 
               if(count($pn)>0){
                $phone_number=$pn[0]->phone1;
               }else{
                 $phone_number="--";
               }

                
                 $k=0;
                 $totalment=0;
                 $myinst=[];
                foreach($installments as $st){
                    $k++;
                     $ment=$mbalances[$k] ?? 0; 
                  $myinst[]=number_format($ment);
                  
                 $totalment=$totalment+$ment;
                
                   }
               
                  
               $data[] = array_merge([$n, $le->academic_year, $le->full_name,$le->class_name,$le->stream_name,$tp,$new,$le->date_joined], $myinst,[number_format($totalment)]);

                          }
                     /////////////////////////
                if($this->request->getPost('load')==1){
                  $resulted["data"]=$data;
                   echo view('reports/forms/detailed_term_balances_list',$resulted);
               }else{
  }
  if($this->request->getPost('load')!=1){
                    $this->exportReport1($data);
                    return;
                    }
 
}

function exportReport1($data){
    //$data1 =$data;
         $spreadsheet = new Spreadsheet();

        // Get active sheet
        $sheet = $spreadsheet->getActiveSheet();

        // Fill spreadsheet with data
        $sheet->fromArray($data);

        // Auto-size columns
$highestColumn = $sheet->getHighestColumn();
$highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn);
for ($col = 1; $col <= $highestColumnIndex; $col++) {
    $sheet->getColumnDimensionByColumn($col)->setAutoSize(true);
}

// Wrap and shrink text
$style = $sheet->getStyle($sheet->calculateWorksheetDimension());
$style->getAlignment()->setWrapText(true);
$style->getAlignment()->setShrinkToFit(true);

        // Write the file in Excel format
        $writer = new Xlsx($spreadsheet);

        // Create temporary file name
        $fileName = 'Reports_term_balances_' . date('Y-m-d H:i:s') . '.xlsx';

        // Set headers to force download of Excel file
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
        header('Cache-Control: max-age=0');

        // Output Excel file
        $writer->save('php://output');
        //echo "Exported successfully";
        exit;
}



public function exportReport()
{
    $data = $this->request->getPost('reportData');

    if (is_string($data)) {
        $data = json_decode($data, true);
    }

    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Write each row from $data
    $rowNum = 1;
    foreach ($data as $row) {
        // Write each cell
        $colNum = 1;
        foreach ($row as $cell) {
            $sheet->setCellValueByColumnAndRow($colNum, $rowNum, $cell);
            $colNum++;
        }
        $rowNum++;
    }

    // Output Excel file
    $fileName = 'Reports_term_balances_' . date('Y-m-d_H-i-s') . '.xlsx';

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $fileName . '"');
header('Cache-Control: max-age=0');
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
}

//end markup
public function exportNSSFdata(){
            $payroll_year = $this->request->getPost('year');
            $payroll_month = $this->request->getPost('month');
            $department = $this->request->getPost('dep');
            $title = $this->request->getPost('job');
            $classfication = $this->request->getPost('class_status');
            $bank = $this->request->getPost('bank'); 
            $data=$this->staffmodel->NSSFReport($payroll_year,$payroll_month,$department,$title,$classfication,$bank);


        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'MEMBER NO');
        $sheet->setCellValue('B1', 'FIRST NAME');
        $sheet->setCellValue('C1', 'MIDDLE NAME');
        $sheet->setCellValue('D1', 'SURNAME');
        $sheet->setCellValue('E1', 'WAGE');
$sheet->getStyle('A1:E1')->getFont()->setBold(true)->setSize(12);

        $row = 2;
        foreach ($data as $info) {
            $sheet->setCellValue('A'.$row, $info->pension_no);
            $sheet->setCellValue('B'.$row, $info->first_name);
            $sheet->setCellValue('C'.$row, $info->other_name);
            $sheet->setCellValue('D'.$row, $info->last_name);
            $sheet->setCellValue('E'.$row, $info->basic_salary);
          
            $row++;
        }
foreach(range('A','E') as $col){
    $sheet->getColumnDimension($col)->setAutoSize(true);
}
$highestRow = $sheet->getHighestRow();
$sheet->getStyle('A2:E' . $highestRow)->getFont()->setSize(12);
        $writer = new Xlsx($spreadsheet);
        $filename = 'NSSF_report.xlsx';

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="'. $filename .'"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
        exit;
}
public function exportPAYEdata(){
            $payroll_year = $this->request->getPost('year');
            $payroll_month = $this->request->getPost('month');
            $department = $this->request->getPost('dep');
            $title = $this->request->getPost('job');
            $classfication = $this->request->getPost('class_status');
            $bank = $this->request->getPost('bank'); 
            $data=$this->staffmodel->payeReport($payroll_year,$payroll_month,$department,$title,$classfication,$bank);


        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'EMPLOYER TIN :');
        $sheet->setCellValue('A2', 'EMPLOYEES DETAILS');
        $sheet->setCellValue('A3', 'SN');
        $sheet->setCellValue('B3', 'EMPLOYEE TIN');
        $sheet->setCellValue('C3', 'RESIDENTIAL STATUS');
        $sheet->setCellValue('D3', 'TYPE OF EMPLOYMENT');
        $sheet->setCellValue('E3', 'SOCIAL SECURITY NO');
        $sheet->setCellValue('F3', 'BASIC SALARY');
        $sheet->setCellValue('G3', 'ALLOWANCE');
        $sheet->setCellValue('H3', 'DEDUCTION');
        $sheet->setCellValue('I3', 'LOCATION');
$sheet->getStyle('A1:E1')->getFont()->setBold(true)->setSize(12);
$sheet->getStyle('A2:E2')->getFont()->setBold(true)->setSize(12);
$sheet->getStyle('A3:I3')->getFont()->setBold(true)->setSize(12);

        $row = 4;
        $sn=1;
        if(!empty($data)){
        foreach ($data as $info) {
                $deductions=$info->advances+$info->pension+$info->paye+$info->nhif+$info->heslb;
                $location='Tanzania Mainland';
            if($info->residential_status==1){
             $resident='RESIDENT';
            }else{
                $resident='NON - RESIDENT';
            }
            if($info->employment_type==1){
                 $emp_type='PRIMARY';
            }else{
                $emp_type='SECONDARY';
            }
            $sheet->setCellValue('A'.$row, $sn);
            $sheet->setCellValue('B'.$row, $info->tin_no);
            $sheet->setCellValue('C'.$row, $resident);
            $sheet->setCellValue('D'.$row, $emp_type);
            $sheet->setCellValue('E'.$row, $info->pension_no);
            $sheet->setCellValue('F'.$row, $info->basic_salary);
            $sheet->setCellValue('G'.$row, $info->allowances);
            $sheet->setCellValue('H'.$row, $deductions);
            $sheet->setCellValue('I'.$row, $location);
          
            $row++;
            $sn++;
        }
foreach(range('A','J') as $col){
    $sheet->getColumnDimension($col)->setAutoSize(true);
}
$highestRow = $sheet->getHighestRow();
$sheet->getStyle('A4:J' . $highestRow)->getFont()->setSize(12);
        $writer = new Xlsx($spreadsheet);
        $filename = 'PAYE_report.xlsx';

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="'. $filename .'"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
        exit;
}}
public function exportWCFdata(){
            $payroll_year = $this->request->getPost('year');
            $payroll_month = $this->request->getPost('month');
            $department = $this->request->getPost('dep');
            $title = $this->request->getPost('job');
            $classfication = $this->request->getPost('class_status');
            $bank = $this->request->getPost('bank'); 
            $data=$this->staffmodel->WCFReport($payroll_year,$payroll_month,$department,$title,$classfication,$bank);
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'WCF NUMBER');
        $sheet->setCellValue('B1', 'FIRST NAME');
        $sheet->setCellValue('C1', 'MIDDLE NAME');
        $sheet->setCellValue('D1', 'LASTNAME');
        $sheet->setCellValue('E1', 'GENDER');
        $sheet->setCellValue('F1', 'DOB');
        $sheet->setCellValue('G1', 'BASIC PAY');
        $sheet->setCellValue('H1', 'GROSS PAY');
        $sheet->setCellValue('I1', 'JOB TITLE');
        $sheet->setCellValue('J1', 'EMPLOYMENT CATEGORY');
        $sheet->setCellValue('K1', 'NATIONAL ID');
        $sheet->setCellValue('L1', 'EMPLOYEE PHONE');
$sheet->getStyle('A1:M1')->getFont()->setBold(true)->setSize(12);

        $row = 2;
        $sn=1;
        if(!empty($data)){
        foreach ($data as $info) {
                $phone= ' '.$info->phone_no;
                $category='PERMANENT';
            $gross=$info->basic_salary+$info->allowances;
            $sheet->setCellValue('A'.$row, $info->wcf_no);
            $sheet->setCellValue('B'.$row, $info->first_name);
            $sheet->setCellValue('C'.$row, $info->other_name);
            $sheet->setCellValue('D'.$row, $info->last_name);
            $sheet->setCellValue('E'.$row, $info->gender);
            $sheet->setCellValue('F'.$row, $info->birth_date);
            $sheet->setCellValue('G'.$row, $info->basic_salary);
            $sheet->setCellValue('H'.$row, $gross);
            $sheet->setCellValue('I'.$row, $info->job_tittle);
            $sheet->setCellValue('J'.$row, $category);
            $sheet->setCellValue('K'.$row, $info->national_id);
            $sheet->setCellValue('L'.$row, $phone);
          
            $row++;
            $sn++;
        }
foreach(range('A','L') as $col){
    $sheet->getColumnDimension($col)->setAutoSize(true);
}
$highestRow = $sheet->getHighestRow();
$sheet->getStyle('A2:L' . $highestRow)->getFont()->setSize(12);
        $writer = new Xlsx($spreadsheet);
        $filename = 'WCF_report.xlsx';

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="'. $filename .'"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
        exit;
}}

public function exportNETdata(){
            $payroll_year = $this->request->getPost('year');
            $payroll_month = $this->request->getPost('month');
            $department = $this->request->getPost('dep');
            $title = $this->request->getPost('job');
            $classfication = $this->request->getPost('class_status');
            $bank = $this->request->getPost('bank'); 
            $data=$this->staffmodel->NetsalariesReport($payroll_year,$payroll_month,$department,$title,$classfication,$bank);
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'SN');
        $sheet->setCellValue('B1', 'PAYROLL YEAR');
        $sheet->setCellValue('C1', 'PAYROLL MONTH');
        $sheet->setCellValue('D1', 'FIRST NAME');
        $sheet->setCellValue('E1', 'MIDDLE NAME');
        $sheet->setCellValue('F1', 'LASTNAME');
        $sheet->setCellValue('G1', 'DEPARTMENT');
        $sheet->setCellValue('H1', 'JOB TITLE');
        $sheet->setCellValue('I1', 'NET AMOUNT');
        $sheet->setCellValue('J1', 'BANK');
        $sheet->setCellValue('K1', 'ACC NAME');
        $sheet->setCellValue('L1', 'ACC NUMBER');
$sheet->getStyle('A1:L1')->getFont()->setBold(true)->setSize(12);

        $row = 2;
        $sn=1;
        if(!empty($data)){
        foreach ($data as $info) {
            $sheet->setCellValue('A'.$row, $sn);
            $sheet->setCellValue('B'.$row, $info->payroll_year);
            $sheet->setCellValue('C'.$row, $info->month);
            $sheet->setCellValue('D'.$row, $info->first_name);
            $sheet->setCellValue('E'.$row, $info->other_name);
            $sheet->setCellValue('F'.$row, $info->last_name);
            $sheet->setCellValue('G'.$row, $info->dep_name);
            $sheet->setCellValue('H'.$row, $info->job_tittle);
            $sheet->setCellValue('I'.$row, $info->net_salaries);
            $sheet->setCellValue('J'.$row, $info->bank_name);
            $sheet->setCellValue('K'.$row, $info->account_name);
            $sheet->setCellValue('L'.$row, $info->account_number);
          
            $row++;
            $sn++;
        }
foreach(range('A','L') as $col){
    $sheet->getColumnDimension($col)->setAutoSize(true);
}
$highestRow = $sheet->getHighestRow();
$sheet->getStyle('A2:L' . $highestRow)->getFont()->setSize(12);
        $writer = new Xlsx($spreadsheet);
        $filename = 'NET_report.xlsx';

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="'. $filename .'"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
        exit;
}}
}
?>
