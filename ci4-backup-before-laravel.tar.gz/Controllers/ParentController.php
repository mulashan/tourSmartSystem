<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ParentModel;

class ParentController extends BaseController
{
    public $pmodel;
    public function __construct()
    {
         if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
        helper("form");
        $this->pmodel = new ParentModel();
         $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
         helper('array');
    }

    public function parent()
    {
        return view('templates/header')
        .view('parent/parent_pg')
        .view('templates/footer');
    }

    public function view_parent_info($pid)
    {
        $data = array(
           'parentInfo' => $this->pmodel->get_parent_information('parents_students_tbl',$where = array('parent_id' =>$pid))
        );
        return view('parent/view_parentInfo',$data);
    }
}
