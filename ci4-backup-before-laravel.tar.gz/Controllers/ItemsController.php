<?php 
    namespace App\Controllers;

    use CodeIgniter\Controller;
    use App\Models\ItemsModel;
    use App\Models\BillingModel;
    use App\Models\ClassesModel;

    class ItemsController extends BaseController{
        public $itemmodel;
        public $bmodel;
        public $cmodel;
        public function __construct(){
             if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
            $this->itemmodel = new ItemsModel();
            $this->bmodel = new BillingModel();
            $this->cmodel = new ClassesModel();
             $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect();
        }
        
        public function account(){
            // $db = \Config\Database::connect();
            $ItemModel = new ItemsModel();
            $data['atype'] = $ItemModel->getAccounttypeList();
            $data['accounts'] = $ItemModel->getAccountList();

            return view('templates/header')
            .view('items/account',$data)
            .view('templates/footer');
        }
        

        public function saveAccount()
        {
            // $itemmodel = new ItemsModel();
            $ledger_validation = [
                'acname' => [
                    'label' => 'ledger Name',
                    'rules' => 'required'
                ],
                'ac_type' => [
                    'label' => 'Ledger Type',
                    'rules' => 'required'
                ],
            ];

            if($this->validate($ledger_validation)){
                $ledger_exist = $this->cmodel->check_ifExist('accounts_tbl', $where = array('account_name' => $this->request->getPost('acname')));
                if($ledger_exist){
                 echo json_encode(array('status' =>'1','statusDesc' => 'Ledger Name:<b>'.$ledger_exist[0]->account_name.'</b> With the <b>ID:'.$ledger_exist[0]->id.'</b> Already Exists.'));
                }else{
                     $sub_account =$this->request->getPost('subacc');
                    $sb_acc=$sub_account;
                    if($sub_account==''){
                       $sb_acc=0;
                    }
                    $data = [
                        'account_name' => ucwords(ucfirst($this->request->getPost('acname'))),
                        'account_type_id' => $this->request->getPost('ac_type'),
                        'account_code' => $this->request->getPost('acno'),
                        'description' => ucwords(ucfirst($this->request->getPost('descr'))),
                        'sub_account' =>$sb_acc,
                        'updated_by' =>$this->request->getPost('header_id'),
                        'updated_date' => date('Y/m/d H:i:s')
                    ];
                     $this->itemmodel->SaveAccountData($data); 
                    echo json_encode(array('status' =>'0','statusDesc' => 'New Ledger Created Successful'));
                }
            }
            
        }

        public function get_AccntData()
        {
            $id = $this->request->getVar('ids');
            $data['accnts'] = $this->itemmodel->getSingle_data($id);
            $data['atype'] = $this->itemmodel->getAccounttypeList();
            $data['accounts'] = $this->itemmodel->getAccountList();

            // echo json_encode($data);
            echo view('items/forms/edit_account',$data);

            
        }
      
       public function get_AccntData2()
        {
            $id = $this->request->getVar('ids');
            $data['ledger'] = $this->itemmodel->getSingle_view($id);
            $data['id'] = $id;
            //$data['atype'] = $this->itemmodel->getAccounttypeList();
            //$data['accounts'] = $this->itemmodel->getAccountList();

            // echo json_encode($data);
            //print_r($data);
            // return;
            echo view('items/forms/view_account',$data);

            
        }
        public function update_account()
        {
            $data = [
                'id' => $this->request->getPost('idkl'),
                'account_name' => $this->request->getPost('acname'),
                'account_type_id' => $this->request->getPost('ac_type'),
                'account_code' => $this->request->getPost('acno'),
                'description' => $this->request->getPost('descr'),
                'sub_account' => $this->request->getPost('subacc'),
                'updated_by' => $_SESSION['user_id'],
                'updated_date' => date('Y/m/d H:i:s')
            ];

            // print_r($data);

            $this->itemmodel->updating_account($this->request->getPost('idkl'),$data);
            echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
                <span class="glyphicon glyphicon-ok"></span> Ledger Updated.</div> ';
        }


        public function delete($id = null)
        {

             // $data['post'] = $this->itemmodel->where('id', $id)->delete();

             // return redirect()->to( base_url('account') )->with('msg', 'deleted Successfully');
            $this->itemmodel->delete_AccountDtls($id);
        }


        public function get_SubAccount()
        {
            $id = $this->request->getVar('id');
            $data = $this->itemmodel->get_sub_account($id);

            $subaccount_data = array();
             if(count($data) > 0){
                $sub = "";
                 foreach($data as $c){
                    if($c->sub_account != 0){
                        $data2 = $this->itemmodel->get_sub_account2($c->sub_account);
                        foreach ($data2 as $dt) {
                            $sub = $dt->account_name;
                        }

                     $subaccount_data[] = array("id" => $c->id, "pname" => $c->type_name, "sub_acc" => $sub, "name" => $c->account_name);
                    }else{

                     $subaccount_data[] = array("id" => $c->id, "pname" => $c->type_name, "sub_acc" => $sub, "name" => $c->account_name);
                    }
                    
                }
             }
            echo json_encode($subaccount_data);
        }


        // ************************************************************************//
            // -----------------start of items data--------------------//


        public function items(){            
            $data['ityplist'] = $this->itemmodel->get_all_ItemLists();

            return view('templates/header')
            .view('items/items',$data)
            .view('templates/footer');
        } 

        public function Create_Item()
        {
             $itemAccnt = $this->request->getPost('account');
                $legder_data = [];
                $c=0;
          foreach ($itemAccnt as $ic) {

                    if($ic != ""){
                        $c++;
                    }
                }
                if($c==0){
                 return redirect()->to( base_url('item') )->with('Error', 'Item Not Created, Please select ledger');
                }else{

            $data = [
                'item_name' => ucwords(strtolower($this->request->getPost('iname'))),
                'item_type' => $this->request->getPost('i_typ'),
                'item_size' => $this->request->getPost('isize'),
                'item_attribute' => $this->request->getPost('iattr'),
                'item_group' => $this->request->getPost('igroup'),
                'sub_item_of' => $this->request->getPost('icateg'),
                'updated_by' => $_SESSION['user_id'],
                'updated_date' => date('Y/m/d H:i:s')
            ];
           // print_r($data);

            $iid = $this->itemmodel->Save_newItem($data);
           //echo $iid;
            if($iid != 0){
                $data1 = [
                    'item_price' => $this->request->getPost('iprice'),
                    'item_id' => $iid,
                    'updated_by' => $_SESSION['user_id'],
                    'updated_date' => date('Y/m/d H:i:s')
                ];
                $this->itemmodel->saveItemPrice($data1);
                
                foreach ($itemAccnt as $ic) {

                    if($ic != ""){
                        
                        $legder_data = array('item_id' => $iid, 'account_id' => $ic);

                        $this->itemmodel->Save_itemLedger($legder_data);
                    }
                }
               }

             return redirect()->to( base_url('item') )->with('msg', 'Item Created Successfully');
         }

        }

        public function fetch_subitems()
        {
            $id = $this->request->getVar('id');
            // print($id);
            $subitem = $this->bmodel->get_item_name('items_tbl', $where = array('item_type' => $id));
            // print_r($subitem);

            if(count($subitem) > 0){
                $select_items = array();

                foreach($subitem as $sub){
                    $select_items [] = array("id" => $sub->id, "name" => $sub->item_name, "attr" => $sub->item_attribute, "size" => $sub->item_size);
                }
                echo json_encode($select_items);
            }
        }

        public function Update_Item()
        {
            $id = $this->request->getVar('id');
            $data['ItemsLst'] = $this->itemmodel->get_allItems_details($id);
            $data['itypes'] = $this->itemmodel->getItemTypeList();
            $data['atypes'] = $this->itemmodel->Get_Accounttypes_Listdetails();
            $data['llist'] = $this->itemmodel->ledgerItemList($id);

            echo view('items/forms/manage_items',$data);
        }
    public function view_Item()
        {
            $id = $this->request->getVar('id');
            $data['ItemsLst'] = $this->itemmodel->get_allItems_details($id);
            $data['itypes'] = $this->itemmodel->getItemTypeList();
            $data['atypes'] = $this->itemmodel->Get_Accounttypes_Listdetails();
            $data['llist'] = $this->itemmodel->ledgerItemList($id);

            echo view('items/forms/view_items',$data);
        }
         public function update_items_details()
        {
            $data = [
                'id' => $this->request->getPost('id'),
                'item_name' => $this->request->getPost('iname'),
                'item_type' => $this->request->getPost('i_typ'),
                'item_size' => $this->request->getPost('isize'),
                'item_attribute' => $this->request->getPost('iattr'),
                'sub_item_of' => $this->request->getPost('icateg'),
                'item_group' => $this->request->getPost('igroup'),
                'updated_by' => $_SESSION['user_id'],
                'updated_date' => date('Y/m/d H:i:s')
            ];

            $data1 = [
                'item_price' => $this->request->getPost('iprice'),
                'updated_by' => $_SESSION['user_id'],
                'updated_date' => date('Y/m/d H:i:s')
            ];

            $this->itemmodel->updating_items($this->request->getPost('id'),$data,$data1);


            if($this->request->getPost('id')){
                $acnt = $this->request->getPost('pidd');
                $this->itemmodel->delete_itemsledger($this->request->getPost('id'));
                foreach($this->request->getPost('accounts') as $ids => $n ){

                        $data2 = [
                            'account_id' => $n,
                            'item_id' => $this->request->getPost('id'),
                        ];

                        $this->itemmodel->updating_itemsledger($this->request->getPost('id'),$data2);
                }
            }

            echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span> Item Updated Successfully.</div> ';
        }

        public function deleteItem($id)
        {   
            // $data = [
            //     'item_status' => 2
            // ];
            // $this->itemmodel->update_table_details('items_tbl', $where = array('id' => $id),$data);
             $this->itemmodel->delete_item($id);
        
        }
        
         function view_balanceSheet(){
             //echo "here ";
         $id = $this->request->getVar('ids');
         $thedate = $this->request->getVar('thedate');
            
            $data['id'] = $id;
            $data['thedate'] = $thedate;
             $id = $this->request->getVar('ids');
           $sn = $this->request->getVar('sn');

             if($sn==1){
         $data['ledger'] = $this->itemmodel->getSingle_view($id);
          echo view('items/forms/view_balance_sheet',$data); 
             }else{
           
          echo view('reports/forms/balanceSheet_view_2',$data); 
             }
        }

     function view_balance_group($id,$thedate,$group){
     $data['id'] = $id;
      $data['thedate'] = $thedate;
      // $data['ledger'] = $this->itemmodel->balancesheetModel($id,date('Y-m-d H:i', $thedate));
       if($group==0){
       $data['ledger'] = $this->itemmodel->getSingle_view($id,date('Y-m-d H:i', $thedate));
      
       echo view('items/forms/view_account',$data);
       }else{
        $data['ledger'] = $this->itemmodel->getSingle_view2($id,date('Y-m-d H:i', $thedate));
      
       echo view('items/forms/view_balance_account',$data); 
       }
     
        }
        
         function load_item_transaction($id){
           
     $data['ItemsLst'] = $this->itemmodel->get_allItems_details($id); 
      echo view('items/forms/view_item_transactions',$data);
        }

    }
?>