<?php

namespace App\Controllers;

class HomeController extends BaseController
{
    public function index()
    {
        // return view('welcome_message');
        return view('templates/login');
            //     .view('templates/contents')
            //    .view('templates/footer');
    }
       function home(){
       $data = $this->getDashboardSchoolCalendarData();
       return view('templates/header')
        .view('templates/contents', $data)
        .view('templates/footer'); 
		
	
		
    }

    public function dashboard_school_calendar_widget()
    {
        echo view('templates/dashboard_school_calendar_widget', $this->getDashboardSchoolCalendarData(
            (int) $this->request->getPost('year')
        ));
    }

    private function getDashboardSchoolCalendarData(?int $year = null): array
    {
        $currentYear = $year && $year > 2000 ? $year : (int) date('Y');
        $currentMonth = (int) date('n');
        $calendarByMonth = [];

        for ($month = 1; $month <= 12; $month++) {
            $calendarByMonth[$month] = [
                'month_number' => $month,
                'month_name' => date('F', mktime(0, 0, 0, $month, 1, $currentYear)),
                'events' => [],
            ];
        }

        $dbName = session()->get('db_name');
        if (! empty($dbName)) {
            $db = \Config\Database::connect($dbName);

            if ($db->query("SHOW TABLES LIKE 'school_calendar_tbl'")->getNumRows() > 0) {
                $events = $db->table('school_calendar_tbl')
                    ->select('id, event_date, event_description, parents, students, staff, status')
                    ->where('status', 1)
                    ->where('YEAR(event_date)', $currentYear, false)
                    ->orderBy('event_date', 'ASC')
                    ->orderBy('id', 'ASC')
                    ->get()
                    ->getResult();

                foreach ($events as $event) {
                    $month = (int) date('n', strtotime($event->event_date));
                    $calendarByMonth[$month]['events'][] = $event;
                }
            }
        }

        return [
            'dashboard_calendar_year' => $currentYear,
            'dashboard_calendar_months' => $calendarByMonth,
            'dashboard_current_month' => $calendarByMonth[$currentMonth] ?? null,
        ];
    }
}
