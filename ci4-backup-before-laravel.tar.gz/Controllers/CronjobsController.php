<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\ResponseInterface;
   use App\Models\PaymentsModel;
    use App\Models\LoginModel;

class CronjobsController extends BaseController
{
  
   public function __construct(){
         
         $this->payment_model = new PaymentsModel;
         
        }

  public function automatic_run($id) {
    $dbn = constant('DB' . $id);
    
        $db = \Config\Database::connect($dbn);
        $date=date('Y-m-d');
     $dated=date('-m-d',strtotime($date));
    
         $names= $db->query('SELECT * FROM students 
              WHERE `birth_date` = \''.$date.'\' OR`birth_date`LIKE \'%'.$dated.'\'');
                $result = $names->getResult();
                //print_r($result);

                //msg setting
                $messagex="Happy Birthday# Student first Name. Wishing you a very happy birthday filled with many achievements and success!";
              $snn = $this->generate_msg_no_2($dbn);
         $smsdata = array(
                    'send_type' => 2,
                    'message_type' => 4,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => 10,
                    'messagex' => $messagex
                   );   

    if(count($result)>0){
        $this->payment_model->SaveData('message_groups_tbl',$smsdata,$dbn);
    foreach($result as $s)
        {
      
      $parent=$this->payment_model->get_item_name('parents_students_tbl',$where = array('student_id' =>$s->id),$dbn);
      $p_phone=$this->payment_model->get_item_name('parents_tbl',$where = array('id' =>$parent[0]->parent_id),$dbn);

        $phone=$p_phone[0]->phone1;
        $message="Happy Birthday ".$s->first_name.". Wishing you a very happy birthday filled with many achievements and success!";
        
       // echo $phone.' /'.$message.' /'.$s->id.'</br>';
        $this->SMSsender2($phone,$message,4,$s->id,$snn,$id,0);
   
       }

      }else{
        echo "none student";
      }          //end msg setting

      $this->process_school_calendar_messages($id, $dbn, $db);
     }

     function generate_msg_no_2($db) {
        $ino = "";
        $tkens = $this->payment_model->get_max_id('message_groups_tbl','send_number',$db);
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }

function manage_transport_messages($id){

     $dbn=constant('DB' . $id);
 $dates=$this->payment_model->get_item_name('transport_details', $where = array('status' => 1),$dbn);
 foreach($dates as $dts){
    $date1 = date('Y-m-d');
    $date2 = $dts->end_date;

    // Convert the dates to Unix timestamps
$timestamp1 = strtotime($date1);
$timestamp2 = strtotime($date2);

// Calculate the difference in seconds
$difference = $timestamp2 - $timestamp1;

// Convert the difference to days
$days_difference = floor($difference / (60 * 60 * 24));
if($days_difference >=0){
$st_name=$this->payment_model->get_item_name('students', $where = array('id' => $dts->student_id),$dbn);
    if($days_difference==3){
         

      $msg = $st_name[0]->first_name.', Tunakukumbusha usafiri wako utaishia tar '.date('d/m/Y', $timestamp2).'. Kibali namba '.$dts->permit_id.' cha tar '.date('d/m/Y',strtotime($dts->start_date)).'. Wasiliana na shule kwaajili ya kulipia tena.';

   //***invoice *************************************//
         $bill = $this->payment_model->gettable_billingdata($dts->student_id,$dbn);
        
        $messagex="#first_name, Tunakukumbusha usafiri wako utaishia tar xx/xx/xxxx. Kibali namba xxxx cha tar xx/xx/xxxx. Wasiliana na shule kwaajili ya kulipia tena.";
     $snn = $this->generate_msg_no_2($dbn);
      $smsdata = array(
                    'send_type' => 2,
                    'message_type' => 7,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>10,
                    'messagex' => $messagex,
                    'trans_number' =>  $dts->trans_numb
                  
                );
     // echo $msg;
 $this->payment_model->SaveData('message_groups_tbl',$smsdata,$dbn);

      $this->SMSsender2($bill[0]->phone1,$msg,7,$dts->student_id,$snn,$id,NULL);
   
    }elseif($days_difference==0){

     $msg = $st_name[0]->first_name.', Kibali cha usafiri namba '.$dts->permit_id.' cha tar '.date('d/m/Y',strtotime($dts->start_date)).' kimeisha leo. Kama ungependa kuendelea na huduma hii na bado hujafanya hivyo, piga 0755266243.';

   //***invoice *************************************//
         $bill = $this->payment_model->gettable_billingdata($dts->student_id,$dbn);
        
        $messagex="#firstname, Kibali cha usafiri no. xxxx cha tar dd/mm/yy kimeisha leo. Kama ungependa kuendelea na huduma hii na bado hujafanya hivyo, piga xxxx-xxx-xxx.";
     $snn = $this->generate_msg_no_2($dbn);
      $smsdata = array(
                    'send_type' => 2,
                    'message_type' => 7,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>10,
                    'messagex' => $messagex,
                    'trans_number' =>  $dts->trans_numb
                  
                );
     
 $this->payment_model->SaveData('message_groups_tbl',$smsdata,$dbn);

     $this->SMSsender2($bill[0]->phone1,$msg,7,$dts->student_id,$snn,$id,NULL);
      
    }

}else{
$Dt = array(
    'status' => 2,
        );
   $this->payment_model->update_table_details('transport_details',$where = array('id' => $dts->id),$Dt,$dbn);   
}

 }
 echo "success";
}

function manage_school_calendar_messages($id){
     $dbn = constant('DB' . $id);
     $db = \Config\Database::connect($dbn);
     date_default_timezone_set('Africa/Dar_es_Salaam');

     $this->process_school_calendar_messages($id, $dbn, $db);
     echo "success";
}

private function process_school_calendar_messages($id, $dbn, $db){
     date_default_timezone_set('Africa/Dar_es_Salaam');

     if (
         $db->query("SHOW TABLES LIKE 'school_calendar_tbl'")->getNumRows() === 0
         || $db->query("SHOW TABLES LIKE 'school_calendar_sms_recipients_tbl'")->getNumRows() === 0
     ) {
         return;
     }

     if ($this->has_school_calendar_schedule_table($db)) {
         $schedules = $db->table('school_calendar_sms_schedule_tbl scss')
             ->select('scss.id AS schedule_id, scss.scheduled_at, scss.sent_at AS schedule_sent_at, sc.*')
             ->join('school_calendar_tbl sc', 'sc.id = scss.calendar_id')
             ->where('sc.sms_enabled', 1)
             ->where('sc.status', 1)
             ->where('scss.sent_at IS NULL', null, false)
             ->where('scss.scheduled_at <=', date('Y-m-d H:i:s'))
             ->orderBy('scss.scheduled_at', 'ASC')
             ->get()
             ->getResult();

         foreach ($schedules as $schedule) {
             $this->send_school_calendar_scheduled_message($db, $dbn, $id, $schedule);
         }

         return;
     }

     $events = $db->table('school_calendar_tbl')
         ->where('sms_enabled', 1)
         ->where('status', 1)
         ->groupStart()
             ->where('before_sms_sent_at IS NULL', null, false)
             ->orWhere('event_sms_sent_at IS NULL', null, false)
         ->groupEnd()
         ->where('event_date >=', date('Y-m-d', strtotime('-1 day')))
         ->orderBy('event_date', 'ASC')
         ->get()
         ->getResult();

     foreach ($events as $event) {
         $now = strtotime(date('Y-m-d H:i:s'));
         $beforeAt = strtotime($event->event_date . ' 11:00:00 -1 day');
         $eventAt = strtotime($event->event_date . ' 08:00:00');

         if (empty($event->before_sms_sent_at) && $now >= $beforeAt) {
             $this->send_school_calendar_messages($db, $dbn, $id, $event, 'before');
         }

         if (empty($event->event_sms_sent_at) && $now >= $eventAt) {
             $this->send_school_calendar_messages($db, $dbn, $id, $event, 'event');
         }
     }
}

private function send_school_calendar_scheduled_message($db, $dbn, $dbid, $schedule){
     $sendStudentAudience = $this->is_school_calendar_student_sms_audience_enabled($db, $schedule);
     $sendStaffAudience = $this->is_school_calendar_staff_sms_audience_enabled($db, $schedule);
     $studentContacts = $sendStudentAudience ? $this->get_school_calendar_student_contacts($db, $schedule) : [];
     $staffContacts = $sendStaffAudience ? $this->get_school_calendar_staff_contacts($db, $schedule) : [];
     $this->send_school_calendar_grouped_messages($dbn, $dbid, $schedule, $studentContacts, $staffContacts);

     $db->table('school_calendar_sms_schedule_tbl')
         ->where('id', $schedule->schedule_id)
         ->update(['sent_at' => date('Y-m-d H:i:s')]);
}

private function send_school_calendar_messages($db, $dbn, $dbid, $event, $phase){
     $column = $phase === 'before' ? 'before_sms_sent_at' : 'event_sms_sent_at';
     $sendStudentAudience = $this->is_school_calendar_student_sms_audience_enabled($db, $event);
     $sendStaffAudience = $this->is_school_calendar_staff_sms_audience_enabled($db, $event);
     $studentContacts = $sendStudentAudience ? $this->get_school_calendar_student_contacts($db, $event) : [];
     $staffContacts = $sendStaffAudience ? $this->get_school_calendar_staff_contacts($db, $event) : [];
     $this->send_school_calendar_grouped_messages($dbn, $dbid, $event, $studentContacts, $staffContacts);

     $db->table('school_calendar_tbl')
         ->where('id', $event->id)
         ->update([$column => date('Y-m-d H:i:s')]);
}

private function get_school_calendar_student_contacts($db, $event){
     $contacts = array();

     $studentRecipients = $db->table('school_calendar_sms_recipients_tbl scr')
         ->select('students.id, students.first_name, students.full_name, MIN(parents_tbl.phone1) AS parent_phone')
         ->join('students', 'students.id = scr.student_id')
         ->join('parents_students_tbl', 'parents_students_tbl.student_id = scr.student_id', 'left')
         ->join('parents_tbl', 'parents_tbl.id = parents_students_tbl.parent_id', 'left')
         ->where('scr.calendar_id', $event->id)
         ->groupBy('students.id')
         ->groupBy('students.first_name')
         ->groupBy('students.full_name')
         ->get()
         ->getResult();

     foreach ($studentRecipients as $student) {
         if (empty($student->parent_phone)) {
             continue;
         }

         $phoneKey = preg_replace('/[^0-9]/', '', $student->parent_phone);
         if ($phoneKey === '') {
             continue;
         }

         $contacts[$phoneKey] = array(
             'phone' => $student->parent_phone,
             'reference_no' => $student->id,
             'student_first_name' => $student->first_name,
             'student_full_name' => $student->full_name,
         );
     }

     return array_values($contacts);
}

private function get_school_calendar_staff_contacts($db, $event){
     if ($db->query("SHOW TABLES LIKE 'school_calendar_sms_staff_recipients_tbl'")->getNumRows() === 0) {
         return [];
     }

     $contacts = array();
     $staffRecipients = $db->table('school_calendar_sms_staff_recipients_tbl scr')
         ->select('users.user_id, users.first_name, users.last_name, users.phone_no')
         ->join('users', 'users.user_id = scr.staff_id')
         ->where('scr.calendar_id', $event->id)
         ->where('users.status', 1)
         ->get()
         ->getResult();

     foreach ($staffRecipients as $staff) {
         if (empty($staff->phone_no)) {
             continue;
         }

         $phoneKey = preg_replace('/[^0-9]/', '', $staff->phone_no);
         if ($phoneKey === '') {
             continue;
         }

         $contacts[$phoneKey] = array(
             'phone' => $staff->phone_no,
             'reference_no' => $staff->user_id,
             'staff_first_name' => $staff->first_name,
             'staff_full_name' => trim($staff->first_name . ' ' . $staff->last_name),
         );
     }

     return array_values($contacts);
}

private function prepare_school_calendar_message($event, $contact){
     $message = (string) $event->sms_message;
     $replacements = array(
         '#studentFirstName' => $contact['student_first_name'] ?? '',
         '#studentFullName' => $contact['student_full_name'] ?? '',
         '#eventDate' => date('d/m/Y', strtotime($event->event_date)),
         '#eventDescription' => $event->event_description,
     );

     return str_replace(array_keys($replacements), array_values($replacements), $message);
}

private function prepare_school_calendar_staff_message($event, $contact){
     $message = (string) $event->staff_sms_message;
     $replacements = array(
         '#staffFirstName' => $contact['staff_first_name'] ?? '',
         '#staffFullName' => $contact['staff_full_name'] ?? '',
         '#eventDate' => date('d/m/Y', strtotime($event->event_date)),
         '#eventDescription' => $event->event_description,
     );

     return str_replace(array_keys($replacements), array_values($replacements), $message);
}

private function sanitizeSchoolCalendarPhone($phone){
     $phone = preg_replace('/\D+/', '', (string) $phone);

     if (substr($phone, 0, 5) === '00255') {
         $phone = substr($phone, 2);
     }

     if (substr($phone, 0, 1) === '0' && strlen($phone) === 10) {
         $phone = '255' . substr($phone, 1);
     }

     if (substr($phone, 0, 3) === '255' && strlen($phone) === 12) {
         return $phone;
     }

     return false;
}

private function has_school_calendar_sms_audience_columns($db){
     return $db->fieldExists('sms_to_students', 'school_calendar_tbl')
         && $db->fieldExists('sms_to_staff', 'school_calendar_tbl');
}

private function has_school_calendar_schedule_table($db){
     return $db->tableExists('school_calendar_sms_schedule_tbl');
}

private function is_school_calendar_student_sms_audience_enabled($db, $event){
     if ($this->has_school_calendar_sms_audience_columns($db) && property_exists($event, 'sms_to_students')) {
         return (int) ($event->sms_to_students ?? 0) === 1;
     }

     return (int) ($event->parents ?? 0) === 1 || (int) ($event->students ?? 0) === 1;
}

private function is_school_calendar_staff_sms_audience_enabled($db, $event){
     if ($this->has_school_calendar_sms_audience_columns($db) && property_exists($event, 'sms_to_staff')) {
         return (int) ($event->sms_to_staff ?? 0) === 1;
     }

     return (int) ($event->staff ?? 0) === 1;
}

private function build_school_calendar_message_summary($event, $includeStudentAudience, $includeStaffAudience){
     $parts = array();

     if ($includeStudentAudience && !empty(trim((string) $event->sms_message))) {
         $parts[] = 'Student/Parent: ' . trim((string) $event->sms_message);
     }

     if ($includeStaffAudience && !empty(trim((string) $event->staff_sms_message))) {
         $parts[] = 'Staff: ' . trim((string) $event->staff_sms_message);
     }

     return implode(' | ', $parts);
}

private function send_school_calendar_grouped_messages($dbn, $dbid, $event, $studentContacts, $staffContacts){
     $sendStudentAudience = !empty($studentContacts) && !empty(trim((string) $event->sms_message));
     $sendStaffAudience = !empty($staffContacts) && !empty(trim((string) $event->staff_sms_message));

     if (!$sendStudentAudience && !$sendStaffAudience) {
         return;
     }

     $snn = $this->generate_msg_no_2($dbn);
     $smsdata = array(
         'send_type' => !empty($event->send_type) ? $event->send_type : 2,
         'message_type' => 18,
         'send_number' => $snn,
         'massage_date' => date('Y-m-d H:i:s'),
         'send_by' => !empty($event->created_by) ? $event->created_by : 10,
         'messagex' => $this->build_school_calendar_message_summary($event, $sendStudentAudience, $sendStaffAudience),
         'trans_number' => $event->id
     );

     $this->payment_model->SaveData('message_groups_tbl', $smsdata, $dbn);

     if ($sendStudentAudience) {
         $this->send_school_calendar_audience_messages($dbid, $event, $studentContacts, 'student', $snn);
     }

     if ($sendStaffAudience) {
         $this->send_school_calendar_audience_messages($dbid, $event, $staffContacts, 'staff', $snn);
     }
}

private function send_school_calendar_audience_messages($dbid, $event, $contacts, $audience, $snn){

     foreach ($contacts as $contact) {
         $cleanPhone = $this->sanitizeSchoolCalendarPhone($contact['phone']);
         if (! $cleanPhone) {
             continue;
         }

         $message = $audience === 'staff'
             ? $this->prepare_school_calendar_staff_message($event, $contact)
             : $this->prepare_school_calendar_message($event, $contact);

         try {
             $this->SMSsender2($cleanPhone, $message, 18, $contact['reference_no'], $snn, $dbid, 0);
         } catch (\Throwable $e) {
             log_message('error', 'School calendar ' . $audience . ' SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
         }
     }
}
 
function SMSsender2($dest,$msg,$type,$ref_no,$snn,$dbid,$show_response=0) {
        
           $username=SMS_UNAME;
            $password=SMS_PASSWORD;
           $senderid = constant('SENDER_ID_' . $dbid);
            $db=constant('DB' . $dbid);
            
             $messag = $this->payment_model->load_messages_balances($db);

             $time_sent = time();
              $destination=str_replace('-', '', $dest);
             $message=urlencode($msg);
             $senderid = urlencode($senderid);
          $fetch=file_get_contents("https://www.sms.co.tz/api.php?do=sms&username={$username}&password={$password}&senderid={$senderid}&dest={$destination}&msg={$message}");
           
            list($status, $note, $smsid) = explode(',', $fetch);
            if($show_response == 2){
              echo '<th>Message status:</th>';
              echo '<td><i>' . $note . '</i></td>';
            }
            if ($status == 'OK') {
                $msgid = $smsid;
                $snt_status = 1;    // Message sent successfully
                $cost = 45;
                $acc_cost = $cost;
                if($type!=2){
                echo 'Message sent successfully';
                  }  
            } else {
                $msgid = '';
                $snt_status = 2;    // Message just sent 
                $cost = 45;
                $acc_cost = $cost;
            }

            
                $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
            
               
            $this->payment_model->SaveData('messages',$tempsmsdata,$db);
          //  echo 'msg saved';

            $balance = ($messag[0]->balance - $acc_cost);

          $smsDt = array(
                'balance' => $balance,
                'created_at' => date('Y/m/d H:i:s')
            );
            $this->payment_model->update_sms_balance($smsDt, $messag[0]->b_id,$db);

          //  curl_close($curl);
     echo 'successful sent';
    }
    
    function whatsap_message(){
           $verifyToken = "econnect_223";

        $mode = $this->request->getGet('hub_mode');
        $token = $this->request->getGet('hub_verify_token');
        $challenge = $this->request->getGet('hub_challenge');
         file_put_contents('econnect/message.txt', $challenge);

        if ($mode && $token) {
            if ($mode === 'subscribe' && $token === $verifyToken) {
                // Return the challenge for webhook validation
                return $this->response->setStatusCode(200)->setBody($challenge);
            } else {
                return $this->response->setStatusCode(403)->setBody("Forbidden: Invalid Token");
            }
        }

        return $this->response->setStatusCode(400)->setBody("Bad Request");
    
     
       
    }
    
     public function receiveMessage()
    { 
        
         // Get JSON input from WhatsApp
        $json = $this->request->getJSON(true); // true = return as associative array
            file_put_contents('econnect/message.txt', json_encode($json));
            
        // Check if the response contains the required fields
        if (!isset($json['entry'])) {
            return $this->respond(['status' => 'error', 'message' => 'Invalid Webhook Data'], 400);
        }
        $data=array();
        // Loop through entries and extract details  
        foreach ($json['entry'] as $entry) {
            foreach ($entry['changes'] as $change) {
                $value = $change['value'] ?? [];

                // Extract metadata
                $businessPhone = $value['metadata']['display_phone_number' ] ?? 'N/A';
                $businessPhoneId = $value['metadata']['phone_number_id'] ?? 'N/A';

                // Extract contact details
                $contactName = $value['contacts'][0]['profile']['name'] ?? 'Unknown';
                $contactWaId = $value['contacts'][0]['wa_id'] ?? 'Unknown';

                // Extract message details
                if (!empty($value['messages'])) {
                    foreach ($value['messages'] as $message) {
                        $sender = $message['from'] ?? 'Unknown';
                        $messageId = $message['id'] ?? 'Unknown';
                        $timestamp = $message['timestamp'] ?? 'Unknown';
                        $messageType = $message['type'] ?? 'Unknown';
                        $messageBody = $message['text']['body'] ?? 'No Text';

                        // Log or process the message
                        log_message('info', "WhatsApp Message Received from $contactName ($sender): $messageBody");

                        // Example response
                        $data = [
                            'business_phone' => $businessPhone,
                            'business_phone_id' => $businessPhoneId,
                            'contact_name' => $contactName,
                            'contact_wa_id' => $contactWaId,
                            'message_from' => $sender,
                            'message_id' => $messageId,
                            'timestamp' => $timestamp,
                            'message_type' => $messageType,
                            'message_body' => $messageBody,
                            'type' =>2
                        ];
                        
                         file_put_contents('econnect/message_data.txt', $data);
                         // Save message in database
                       $dbn='default';
                         $this->payment_model->SaveData('whatsapp_messages',$data,$dbn);
                         
                         $this->pushToWebSocket($messageBody);
                    }
                }
            }
        }

        // Return response
        
       // return $this->respond(['status' => 'success', 'data' => $data], 200);
    
}

public function chatMessages()
    {
        //   return view('templates/header')
        //     .view('system/chat_view')
        //     .view('templates/footer');
        
        return view('system/chat_view');
    }
    
      public function pushToWebSocket($message)
    {
        // WebSocket server URL
        // $websocket_url = 'ws://localhost:8080';  // or your WebSocket server address

        // Use Ratchet's WebSocket client to send a message
      //  $connector = new Connector();

       // $connector($websocket_url)
          //  ->then(
          //      function (WebSocket $conn) use ($message) {
                    // Once connected, send the message
            //         $conn->send($message);
            //         $conn->close(); // Close the connection after sending
            //     },
            //     function (\Exception $e) {
            //         echo "Could not connect to WebSocket server: {$e->getMessage()}\n";
            //     }
            // );
    }
    
    public function fetchSchools($id){
            $dbn="default";
        
             $db_data=$this->payment_model->gettable_data('database_list_tbl',$where = array('db_id >' =>0),$dbn);
             //print_r($db_data);
    // $data=$this->payment_model-> get_messages_details('database_list_tbl',$where,$db);
     echo json_encode($db_data);
    }
    
        public function school_chosen($id){
            $dbn="default";
        
             $db_data=$this->payment_model->gettable_data('database_list_tbl',$where = array('db_id' =>$id),$dbn);
             $dbn_name=$db_data[0]->db_name;
            $class_data=$this->payment_model->gettable_data('classes_tbl',$where = array('id >' =>0),$dbn_name);
             //print_r($db_data);
    // $data=$this->payment_model-> get_messages_details('database_list_tbl',$where,$db);
     echo json_encode($class_data);
    }
    
      public function class_students($class_id, $id){
            $dbn="default";
        
             $db_data=$this->payment_model->gettable_data('database_list_tbl',$where = array('db_id' =>$id),$dbn);
             $dbn_name=$db_data[0]->db_name;
              $year=date('Y');
            $class_data=$this->payment_model->gettable_data('admission_tbl',$where = array('class_id' =>$class_id,'academic_year'=>$year),$dbn_name);
            $holid_students=array();
            if(count($class_data)>0){
                foreach($class_data as $data){
                    
                   $student_data=$this->payment_model->gettable_data('students',$where = array('id' =>$data->student_id),$dbn_name);
                   if(count($student_data)>0){
                       foreach($student_data as $dt){
                $holid_students[] = array("student_id" => $dt->id,"student_name" => $dt->full_name,); 
                       }
            
                   }
                   
                }
            
            }
             
             //print_r($db_data);
    // $data=$this->payment_model-> get_messages_details('database_list_tbl',$where,$db);
     echo json_encode($holid_students);
    }
    
    
    public function store(): ResponseInterface
    {
         try {
        $institutionId   = $this->request->getPost('institution_id');
        $classId         = $this->request->getPost('class_id');
        $studentId       = $this->request->getPost('student_id');
        $remoteStudentId = $this->request->getPost('remote_student_id');
        $name            = trim((string) $this->request->getPost('name'));

        if (!$institutionId) {
            return $this->response->setStatusCode(422)->setJSON([
                'message' => 'institution_id inahitajika.',
            ]);
        }

        if ($name === '') {
            return $this->response->setStatusCode(422)->setJSON([
                'message' => 'name inahitajika.',
            ]);
        }

        $files = $this->request->getFiles();
        $faceImages = $files['face_images'] ?? $files['face_images[]'] ?? [];

        if (!is_array($faceImages)) {
            $faceImages = [$faceImages];
        }

        if (count($faceImages) !== 5) {
            return $this->response->setStatusCode(422)->setJSON([
                'message' => 'Lazima utume picha 5 kwenye face_images[].',
            ]);
        }

        $db = db_connect('default');
        $db->transStart();

        $builder = $db->table('student_registrations');

        $existing = null;
        if ($remoteStudentId) {
            $existing = $builder
                ->where('institution_id', $institutionId)
                ->where('remote_student_id', $remoteStudentId)
                ->get()
                ->getRowArray();
        }

        $registrationData = [
            'institution_id'   => $institutionId,
            'class_id'         => $classId ?: null,
            'student_id'       => $studentId ?: null,
            'remote_student_id'=> $remoteStudentId ?: null,
            'name'             => $name,
            'training_status'  => 'pending',
            'updated_at'       => date('Y-m-d H:i:s'),
        ];

        if ($existing) {
            $builder->where('id', $existing['id'])->update($registrationData);
            $registrationId = (int) $existing['id'];

            $db->table('student_registration_images')
                ->where('registration_id', $registrationId)
                ->delete();
        } else {
            $registrationData['created_at'] = date('Y-m-d H:i:s');
            $builder->insert($registrationData);
            $registrationId = (int) $db->insertID();
        }

        $uploadDir = WRITEPATH . 'public/student-faces/' . $registrationId . '/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $savedImages = [];

        foreach ($faceImages as $index => $image) {
            if (!$image || !$image->isValid()) {
                $db->transRollback();
                return $this->response->setStatusCode(422)->setJSON([
                    'message' => 'Kuna picha haijafika vizuri.',
                ]);
            }

            $newName = 'student-face-' . ($index + 1) . '-' . time() . '.' . $image->getExtension();
            $image->move($uploadDir, $newName, true);

            $relativePath = 'public/student-faces/' . $registrationId . '/' . $newName;
            $savedImages[] = $relativePath;

            $db->table('student_registration_images')->insert([
                'registration_id' => $registrationId,
                'capture_order'   => $index + 1,
                'image_path'      => $relativePath,
                'created_at'      => date('Y-m-d H:i:s'),
            ]);
        }

        $db->transComplete();

        if (!$db->transStatus()) {
            return $this->response->setStatusCode(500)->setJSON([
                'message' => 'Imeshindikana kuhifadhi usajili.',
            ]);
        }

        return $this->response->setJSON([
            'message' => 'Usajili umehifadhiwa.',
            'student' => [
                'id' => $registrationId,
                'institution_id' => (int) $institutionId,
                'institution_name' => null,
                'name' => $name,
                'training_status' => 'pending',
                'face_images_count' => count($savedImages),
            ],
        ]);
        
         } catch (\Throwable $e) {
        log_message('error', 'store_students_images failed: ' . $e->getMessage());

        return $this->response->setStatusCode(500)->setJSON([
            'message' => 'Server error: ' . $e->getMessage(),
        ]);
    }
    }
    
       public function app_users_login(){ 
          
           $loginModel = new LoginModel();
          // $session = \Config\Services::session();
           $validation =  \Config\Services::validation();

           $login_data = [
                'username' => 'required|min_length[3]|max_length[255]',
                'pswd' => 'required',
                ];

           if ($this->validate($login_data)){

               $result =  $loginModel->verfy_user($this->request->getPost('username'),$this->request->getPost('pswd')); 

      $user = 0;
     $pass=$this->request->getPost('pswd');
      $hashedPassword = password_hash($pass, PASSWORD_DEFAULT);     
     if($result){
         if($result[0]->updated == 0 && $result[0]->password == sha1($pass)){
               
         $data=array(
         'password'=>$hashedPassword,
         'updated'=>1
             );

     $loginModel->update_table_details('users_session_tbl',$where = array('user_id' =>$result[0]->user_id),$data);
        $user = 1;
                    
                }else{
             
             if($result[0]->updated == 1 && password_verify($pass, $result[0]->password)){

              $user = 1;
             }

            }
              
        if($user ==1){

        $data2=array(
         'password'=>$result[0]->password,
         'updated'=>1
             );


   $users_dtls =  $loginModel->get_users_details($result[0]->user_id);
//   echo $result[0]->user_id;
//   print_r($users_dtls);
//   return;
     $loginModel->update_table_details2('users_session_tbl',$where = array('user_id' =>$result[0]->user_id),$data2,$users_dtls[0]->db_name);    
               $session_data = [
                   'status' => 200,
                    'user_id' => $users_dtls[0]->user_id,
                    'first_name' => $users_dtls[0]->first_name,
                    'last_name'  => $users_dtls[0]->last_name,
                    'user_type'  => $users_dtls[0]->user_type,
                    'initial_username'=> $users_dtls[0]->user_type,
                    'user_photo'=> $users_dtls[0]->user_photo,
                    'db_id'=> $users_dtls[0]->db_id,
                    'school_name'=> $users_dtls[0]->instituition,
                    'logged_in' => true
                ];
               // $this->session->set($session_data);
                
           // $allowed_menu['allowed_menu'] = $loginModel->get_allowed_menu($users_dtls[0]->user_type,$users_dtls[0]->initial_username);
           //$this->session->set($allowed_menu);

        //   $redirectUrl=$this->request->getPost('redirect');
        // if($redirectUrl!=""){
        //       return redirect()->to($redirectUrl ? $redirectUrl : '/');
        // }

                // return view('templates/header')
                // .view('templates/contents')
                // .view('templates/footer'); 
                 echo json_encode($session_data);
               }
           else{
               //$this->session ->setTempdata('error','Wrong Username or Password');
               $session_data = [
                   'status' => 201,
                   'message' => 'Wrong Username or Password',
                   ];
                 echo json_encode($session_data);
           }
       }
              else{
                  $session_data = [
                   'status' => 201,
                   'message' => 'Wrong Username or Password',
                   ];
                 echo json_encode($session_data);
                }
            }else{
                    //$this->session ->setTempdata('error',$validation->listErrors());
                     $session_data = [
                   'status' => 201,
                   'message' => $validation->listErrors(),
                   ];
                 echo json_encode($session_data);
                    
            }



        }
 //marksthe end   
     
}
