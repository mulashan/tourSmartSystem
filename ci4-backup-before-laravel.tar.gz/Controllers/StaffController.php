<?php 
    namespace App\Controllers;

    use CodeIgniter\Controller;
    use App\Models\StaffModel;
    use App\Models\AdmissionModel;
use App\Models\StudentModel;
use App\Models\ClassesModel;
use App\Models\BillingModel;
use App\Models\SystemModel;
use App\Models\BillModel;
    class StaffController extends BaseController{
          public $amodel;
    public $smodel;
    public $cmodel;
    public $bmodel;
    public $staffmodel;
    public $sytm_model; 
     public $billmodel;
     public function __construct(){
         
          if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
           $this->amodel = new AdmissionModel();
        $this->smodel = new StudentModel();
        $this->cmodel = new ClassesModel();
        $this->bmodel = new BillingModel();
        $this->sytm_model = new SystemModel();
        $this->staffmodel = new StaffModel();
        $this->billmodel = new BillModel();
        $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
            helper('age');
         helper('results_helper');
            $this->staff= new StaffModel;
           $this->db=\Config\Database::connect($dbname);


        }
        function generate_msg_no() {
        $ino = "";
        $tkens = $this->smodel->get_max_id('message_groups_tbl','send_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
      function SMSsender($dest,$msg,$type,$ref_no,$snn,$show_response=0) {
         $tmsg = $this->smodel->gettable_data('message_status_tbl',$where = array('status' => 1,));
                  if(count($tmsg)==0){
                   return;   
                  }
          if($snn==0){
                   $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname.Tafadhali Fanya Malipo Kupitia CRDB.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => $type,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i'),
                    'send_by' =>session()->get('user_id'),
                    'messagex' => $messagex,
                    'trans_number' => $this->request->getPost('trno')
                  
                );
                
      
 $this->smodel->SaveData('message_groups_tbl',$smsdata); 
        }
             $messag = $this->sytm_model->load_messages_balances();

            $time_sent = time();
                $senderid=constant('SENDER_ID_' . session()->get('db_id'));
           
                 if($senderid){
              $username=SMS_UNAME;
             $password=SMS_PASSWORD;
                 }else{
                     return;
                 }
             $destination=$dest;
             $message=urlencode($msg);
              $senderid = urlencode($senderid);
          $fetch=file_get_contents("https://www.sms.co.tz/api.php?do=sms&username={$username}&password={$password}&senderid={$senderid}&dest={$destination}&msg={$message}");
           
            list($status, $note, $smsid) = explode(',', $fetch);
            if($show_response == 2){
              echo '<th>Message status:</th>';
              echo '<td><i>' . $note . '</i></td>';
            }
            if ($status == 'OK') {
                $msgid = $smsid;
                $snt_status = 1; 
                $cost = 45;
                $acc_cost = $cost;
                if($type!=5){
                  }  
            } else {
                $msgid = '';
                $snt_status = 2;
                $cost = 45;
                $acc_cost = $cost;
            }

       
                $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
          
             $msg_details = $this->billmodel->get_item_name('messages',$where = array('send_no' => $snn,'reference_no' => $ref_no));
      $this->smodel->SaveData('messages',$tempsmsdata); 
                $balance = ($messag[0]->balance - $acc_cost);

           $smsDt = array(
                'balance' => $balance,
                'created_at' => date('Y/m/d H:i:s')
            );
        $this->sytm_model->update_sms_balance($smsDt, $messag[0]->b_id);
     
    }
        function staff(){
            return view('templates/header')
            .view('users/staff')
            .view('templates/footer');   
        }

        public function staff_report()
        {
            $status = $this->request->getPost('status');
            $staff = $this->request->getPost('staff');
            $dep = $this->request->getPost('dep');
            $job = $this->request->getPost('job');
            $name="ALL";
// =============================================================================
            $check_exp = $this->staffmodel->check_expireContracts();

$today = date('Y-m-d');
if ($check_exp->contract_check=='' || $check_exp->contract_check != $today) {
    $expired = $this->staffmodel->expireContracts();
    $uexpired = $this->staffmodel->unexpireContracts();
    
    if ($check_exp) {
        $this->staffmodel->update_expire_check();
    } else {
        $this->staffmodel->update_expire_check();
    }
}

// =============================================================================
           $db_id=session()->get('db_id');
            if(!$staff==0){
            $typename = $this->staff->staff_name($staff);
            $name=$typename[0]->type_name;
             }
            $data['staff_name']=$name;
            $data['staf'] = $this->staff->staff_report($status,$staff,$dep,$job,$db_id);
           echo view('reports/forms/staff_report',$data);
         }
         public function boarding_setup(){
          return view('templates/header')
        .view('student/students_boarding')
        .view('templates/footer');    
         }
         public function boarding_details(){
              $id = $this->request->getVar('id');
        $data['student_dtl'] = $this->amodel->get_student_details('students', $where = array('id' => $id, 'status' =>2));
        // $data['classes'] = $this->amodel->get_student_details('classes_tbl', $where = array('status' => 1));
        $data['studentparent'] = $this->amodel->get_student_details('parents_students_tbl', $where = array('student_id' => $id));

        echo view('student/boarding_details',$data);
         }

    function save_boarding_details(){
             $pno = $this->generate_boarding_pno();
          
          $data = [
                    'student_id' => $this->request->getPost('sid'),
                    'academic_year' => $this->request->getPost('acdy'),
                    'permit_id' => $pno,
                    'admission_type' => $this->request->getPost('admit'),
                    'hostel' => $this->request->getPost('hstl'),
                    'month' => 0,
                    'start_date' => $this->request->getPost('djoin'),
                    'end_date' => $this->request->getPost('end'),
                      'created_date' => $this->request->getPost('djoin'),
                    'created_by' =>4,
                    'status ' => 1
                   
                ];

                $data2 = [
                    'admission_type' => 3
                ];
//print_r($data);
              $this->amodel->SaveDetails('boarding_tbl',$data);
              $this->smodel->update_table_details('admission_tbl',$where = array('student_id' => $this->request->getPost('sid')),$data2);
                $this->save_boarding_transaction_items($this->request->getPost('sid')); 
    }

    public function save_boarding_transaction_items($student_id){
        // $session = session();
        $transNo = $this->generate_transaction_no();
        $admnTransaction = [
                'trans_type_id' => 1,
                'trans_number' => $transNo,
                'trans_date' => $this->request->getPost('djoin'),
                'updated_by' => 4,
                'updated_date' => date('Y-m-d H:i:s')
        ];
        $this->smodel->SaveData('transaction_numbers_tbl',$admnTransaction);
      //  print_r($admnTransaction);
//$student_id=$this->request->getPost('sid');
        $total_cost = 0;
        $invoice_type = [
             'trans_no' => $transNo,
             'transaction_type_id' => 1,
             'invoice_type_id' => 5
         ];
        $itm_trans = $this->smodel->SaveData_n_get_id('invoice_type_transaction',$invoice_type); 
         // print_r($invoice_type);

         $itype ="";
         $amountttl = 0;
         $qtys = 0;
         $id="";
        
        //for account receivables
      //$data = $this->request->getRawInput()['receivable_total_balance'];
       // $receivableData = json_decode($data);
        //print_r($receivableData);
        $total= 0;
        $ledgerId = '';
        $i=0;
        $itemID = $this->request->getPost('iid');
       // print_r($itemID);
           foreach ($itemID as $c) {
            //$c=$rd->iid;
         // echo $c;
            $i++;
            
  //////////////////////////////////////////////////////////////////////////////////////
             
                 $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c));
            foreach($itm as $i){
                $itype = $i->item_type;
            }
            $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $transNo,'trans_type' => 1, 'quantity' => $this->request->getPost('quantity'.$c.''), 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $this->request->getPost('prco'.$c.''));

           $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);
             //print_r($itemData);

            $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 

            $total_cost+=  $this->request->getPost('prco'.$c.'');
          
          $amount=0;
          $transactions=0;
            foreach($leger_items as $lg){
                $amount=$this->request->getPost('prco'.$c.'');
                $transactions+=$amount;
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                $ledger = [
                     'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $c,
                     'trans_no' => $transNo,
                     'trans_type' => 1,
                     'amount' =>$this->request->getPost('quantity'.$c.'')*$this->request->getPost('prco'.$c.''),
                     'transation_nature' => 1,
                     'name_type_id' => 1,
                     'name_id' => $student_id,
                ];
                $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 
               //print_r($ledger);
            }
////////////////////////////////////////////////////////////////////////////////////                
            $total += $this->request->getPost('quantity'.$c.'')*$this->request->getPost('prco'.$c.'');
            $ledgerId =  $this->request->getPost('account');
        
        }

        $ac_ledger = [
            'ledger_id' => $ledgerId,
            'ledger_type' => 7,
            'trans_no' => $transNo,
            'trans_type' => 1,
            'amount' => $total,
            'transation_nature' => 2,
            'name_type_id' => 1,
            'name_id' => $student_id,
            'balance' => $total,
        ];   
      $trans=$this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger);
       //print_r($ac_ledger); 
        
        if($trans=1){
            echo '1';
        }else{
            echo '0';
        }
        $desc='Boarding fee';
        $this->createControl_number_crdb($total_cost,$student_id,$transNo,$desc);
      // $this->createControl_number($total_cost,$student_id,$transNo);
    }

    public function generate_transaction_no()
    {
        $ino = "";
        $tkens = $this->smodel->get_max_invoice('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
     public function generate_boarding_pno()
    {
        $ino = "";
        $tkens = $this->smodel->get_max_id('boarding_tbl','permit_id');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }

    public function priceview(){
        echo view('student/forms/view_price'); 
    }
     public function discountView(){
        echo view('student/forms/deposit_popup'); 
    }
     public function ivoice_popup($id){
        $data['id']=$id;
        echo view('student/forms/invoice_popup_edit',$data); 
    }
    public function form_popup(){
        echo view('student/forms/admition_popup'); 
    }

     function createControl_number_crdb($total_cost,$student_id,$transNo,$desc){
        $charge=50;
         $student_details = $this->smodel->gettable_data('students',$where = array('id' => $student_id));
         $db_id=session()->get('db_id');
         $des=$des.' : '.$total_cost.' </br> Bank charges : '.$charge;
         if($db_id==1){
          $data=array(
            'name' =>$student_details[0]->full_name,
            'receipt_no' => $transNo,
            'amount' => $total_cost+$charge,
            'currency' => 'TZS',
            'payment_desc' => $des,
            'visit_no'=>$student_details[0]->student_id,
            'file_no'=>$student_id,
            'payment_channel' => 1,
            'facility_id' => FACILITY_ID_1,
            'payment_type' => PAYMENT_TYPE_1,
            'prefix' => PREFIX_1,
            'call_back_url' => base_url().CRDB_CALLBACK_1,
            'allow_partial' => 'FIXED'

        );
          //print_r(json_encode($data));

    $url = CRDB_URL_1."createPayment";
}elseif($db_id==2){
   $data=array(
            'name' =>$student_details[0]->full_name,
            'receipt_no' => $transNo,
            'amount' => $total_cost+$charge,
            'currency' => 'TZS',
            'payment_desc' => $desc,
            'visit_no'=>$student_details[0]->student_id,
            'file_no'=>$student_id,
            'payment_channel' => 1,
            'facility_id' => FACILITY_ID_2,
            'payment_type' => PAYMENT_TYPE_2,
            'prefix' => PREFIX_2,
            'call_back_url' => base_url().CRDB_CALLBACK_2,
            'allow_partial' => 'FIXED'

        );
          //print_r(json_encode($data));

    $url = CRDB_URL_2."createPayment";
}
     $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                //echo $response;
                $err = curl_error($ch); 
                curl_close($ch);

                 if ($err) {
                    //echo "Error #:" . $err;
                    $status = 5;
                    $reference=0;
                     $time=date('Y-m-d H:i:s');
                } else {
                   
                    $obj2 = json_decode($response,TRUE);
                    if($obj2['status']=='success'){
                      $status = 1;
                    }else{
                       $status = 2;
                    }
                    $time=$obj2['date_created'];
                    
                    $reference= $obj2['paymentReference'];
                }

                 $crdb_data = array(
                    'trans_no' =>  $transNo,
                    'student_id' =>  $student_id,
                    'reference_no' => $reference,
                    'amount' => $total_cost,
                    'charges' => $charge,
                    'paid_charges' => 0,
                    'payment_status' => 0,
                    'payment_channel' => '3', //CRDB
                    'date_created' => $time,
                    'allow_partial' => 0,
                    'trans_type' => 1
                 );
            //print_r($crdb_data);
                $this->amodel->SaveDetails('payment_request',$crdb_data);

            $msg = "Kumb No: ".$reference.", Tarehe: ".$time.", Kiasi:TZS ".number_format($total_cost).", Mwanafunzi: ".$student_details[0]->full_name.".".
                 "Tafadhali Fanya Malipo Kupitia CRDB.";
   //************************invoice msg setup*************************************//
         $bill = $this->smodel->gettable_billingdata($student_id);
        
        $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname.Tafadhali Fanya Malipo Kupitia CRDB.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 1,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>$this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $transNo
                  
                );
      
 $this->smodel->SaveData('message_groups_tbl',$smsdata);

      $this->SMSsender($bill[0]->phone1,$msg,1,$studentID,$snn,NULL);
     //   ($dest,$msg,$type,$ref_no,$snn,$show_response=0)
       
        //*************************end msg invoice setup**********************************// 
    }

function student_absconds($year){
    $data=[
      'year'=>$year
    ];
   // print_r($data);
   return view('templates/header')
            .view('student/student_absconds',$data)
            .view('templates/footer');
}

function absconds_by_class($year){

  $tday = date('d-m-Y');
       // $level = $this->studentModel->get_religon_details();
        $data = array();
          $class = $this->smodel->get_class_details();
            
            foreach ($class as $l){
            
                $data[]= ['name' => $l->class_name,'total'=>count($this->smodel->gettable_data('absconding_tbl',$where=array('class'=>$l->id,'absconded_year'=>$year)))];
            
        }
            
        
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/absconds_by_class_graph',$send);
}

function student_graduants($year){
    $data=[
      'year'=>$year
    ];
   // print_r($data);
   return view('templates/header')
            .view('student/student_graduants',$data)
            .view('templates/footer');
}

public function get_gender_graph($year){
        $tday = date('d-m-Y');
        //$class = $this->studentModel->get_class_details();
        $data = array();
      
 $graduats = $this->smodel->gettable_data('graduation_tbl',$where = array('graduation_year' => $year));
    $male=0;
    $female=0;
    if(count($graduats)>0){
        foreach ($graduats as $v) {
            $adms = $this->smodel->gettable_data('admission_tbl',$where = array('id' => $v->adm_id));
             
    if(count($adms)>0){
             $gender = $this->smodel->gettable_data('students',$where = array('id' => $adms[0]->student_id)); 

             if($gender[0]->gender=='Male') {
               $male=$male+1;
             }else{
              $female=$female+1;
             }
         }else{
            //echo $v->adm_id.'/';
         }

        }
      
    }

    $data[]= ['name' =>'Male','total'=>$male];
    $data[]= ['name' =>'Female','total'=>$female];
      $send['data'] = json_encode($data);

       echo view('graphs/gender_admission_graph',$send);
      //$this->load->view('graphs/patients_waiting_department',$send);
    } 

    function graduants_by_class($year){

  $tday = date('d-m-Y');
       // $level = $this->studentModel->get_religon_details();
        $data = array();
          $class = $this->smodel->get_class_details();
            
            foreach ($class as $l){
            
                $data[]= ['name' => $l->class_name,'total'=>count($this->smodel->gettable_data('graduation_tbl',$where=array('class'=>$l->id,'graduation_year'=>$year)))];
            
        }
            
        
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/absconds_by_class_graph',$send);
}

public function students_details($year){
        $tday = date('d-m-Y');
      
        $data = array();
        
        $religions=$this->staff->get_distinct_religion();
        
         foreach ($religions as $rl){
          
            $tl=$this->staff->get_total_religion($rl->religion,$year);
                $data[]= ['name' =>$rl->religion,'total'=>count($tl)];
            
        }
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/religion_graphs',$send);
      //$this->load->view('graphs/patients_waiting_department',$send);
    }

    public function students_nationality($year){
        $tday = date('d-m-Y');
      
        $data = array();
       
        $nat=$this->staff->get_distinct_nationality();
        
         foreach ($nat as $rl){
          
            $tl=$this->staff->get_total_nationality($rl->nationality,$year);
                $data[]= ['name' =>$rl->nationality,'total'=>count($tl)];
            
        }
      $send['data'] = json_encode($data);
      
       echo view('graphs/nation_graphs',$send);
      
    }
    
    public function recevable_edit($id){
        $data['id']=$id;
        echo view('student/forms/edit_receivable_popup',$data); 
    }
    
    function student_transfered($year){
    $data=[
      'year'=>$year
    ];
   // print_r($data);
   return view('templates/header')
            .view('student/student_transfered_dashboard',$data)
            .view('templates/footer');
}

function student_noshow($year){
    $data=[
      'year'=>$year
    ];
   // print_r($data);
   return view('templates/header')
            .view('student/student_noshow_dashboard',$data)
            .view('templates/footer');
}

 public function transfered_gender_details($year){
        $tday = date('d-m-Y');
        //$class = $this->smodel->get_class_details();
        $data = array();
      
 $transfer = $this->smodel->gettable_data('transfered_students_tbl',$where = array('academic_year' => $year));
    $male=0;
    $female=0;
    if(count($transfer)>0){
        foreach ($transfer as $v) {
            $adms = $this->smodel->gettable_data('admission_tbl',$where = array('id' => $v->adm_id));
             
    if(count($adms)>0){
             $gender = $this->smodel->gettable_data('students',$where = array('id' => $adms[0]->student_id)); 

             if($gender[0]->gender=='Male') {
               $male=$male+1;
             }else{
              $female=$female+1;
             }
         }else{
            //echo $v->adm_id.'/';
         }

        }
      
    }
    $data[]= ['name' =>'Male','total'=>$male];
    $data[]= ['name' =>'Female','total'=>$female];
      $send['data'] = json_encode($data);

       echo view('graphs/gender_admission_graph',$send);


}

    public function noshow_gender_details($year){
         $tday = date('d-m-Y');
        //$class = $this->smodel->get_class_details();
        $data = array();
      
 $noshow = $this->smodel->gettable_data('student_not_show_tbl',$where = array('academic_year' => $year));
    $male=0;
    $female=0;
    if(count($noshow)>0){
        foreach ($noshow as $v) {
            $adms = $this->smodel->gettable_data('admission_tbl',$where = array('id' => $v->adm_id));
             
    if(count($adms)>0){
             $gender = $this->smodel->gettable_data('students',$where = array('id' => $adms[0]->student_id)); 

             if($gender[0]->gender=='Male') {
               $male=$male+1;
             }else{
              $female=$female+1;
             }
         }else{
            //echo $v->adm_id.'/';
         }

        }
      
    }
    $data[]= ['name' =>'Male','total'=>$male];
    $data[]= ['name' =>'Female','total'=>$female];
      $send['data'] = json_encode($data);

       echo view('graphs/gender_admission_graph',$send);


}

function transfer_by_class($year){
     $tday = date('d-m-Y');
       // $level = $this->smodel->get_religon_details();
        $data = array();
          $class = $this->smodel->get_class_details();
            
            foreach ($class as $l){
            
                $data[]= ['name' => $l->class_name,'total'=>count($this->smodel->gettable_data('transfered_students_tbl',$where=array('class'=>$l->id,'academic_year'=>$year)))];
            
        }
            
        
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/absconds_by_class_graph',$send);
}

function noshow_by_class($year){
     $tday = date('d-m-Y');
       // $level = $this->smodel->get_religon_details();
        $data = array();
          $class = $this->smodel->get_class_details();
            
            foreach ($class as $l){
            
                $data[]= ['name' => $l->class_name,'total'=>count($this->smodel->gettable_data('student_not_show_tbl',$where=array('class'=>$l->id,'academic_year'=>$year)))];
            
        }
            
        
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/absconds_by_class_graph',$send);
}

function today_collection(){
    
   return view('templates/header')
            .view('student/today_collection_dashboard')
            .view('templates/footer');
}

function bankCollection(){
     helper('bank');
       // $level = $this->smodel->get_religon_details();
        $data = array();
       
            $sdate=date('Y-m-d 00:00');
                $edate=date('Y-m-d 23:59');
                $results=bank_cash($sdate,$edate);
            
            foreach ($results as $l){
            
                $data[]= ['name' => $l['account_name'],'total'=>$l['amount_in']];
            
        }
            
        
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/today_collection_graph',$send);
}

function bankBalances(){
     helper('bank');
       // $level = $this->smodel->get_religon_details();
        $data = array();
       
            $sdate=date('Y-m-d 00:00');
            $edate=date('Y-m-d 23:59');
            $results=bank_cash($sdate,$edate);
            
            foreach ($results as $l){
            
                $data[]= ['name' => $l['account_name'],'total'=>$l['c_balance']];
            
              }
            
        
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/today_balance_graph',$send);
}

        

function others(){
    $data['others']= $this->smodel->gettable_data('others_tbl',$where = array('id >' => 0));
    return view('templates/header')
            .view('users/other_users',$data)
            .view('templates/footer'); 
}

    function register_customer()
    {

        $data=[
            'customer_name'=>ucfirst($this->request->getPost('customer_name')),
            'customer_address'=>$this->request->getPost('customer_address'),
            'customer_phone'=>$this->request->getPost('customer_phone'),
            'customer_email'=>$this->request->getPost('customer_email'),
            'customer_tin'=>$this->request->getPost('customer_tin'),
            'customer_vrn'=>$this->request->getPost('customerVrn'),
            'status'=>1,
            'updated_by'=>$_SESSION['user_id'],
            'updated_date'=>date('Y/m/d H:i:s'),
        ];
       $this->smodel->SaveData('others_tbl',$data);
        echo json_encode(array('status'=>'0','statusDesc'=>'New Customer Registered successfully'));
    }

function school_departments(){
     $data['dep']=$this->smodel->gettable_data('departments_tbl',$where = array('id >' => 0));
        return view('templates/header')
            .view('users/departments',$data)
            .view('templates/footer');    
    }

    function job_tittle(){
         $data['dep']=$this->smodel->gettable_data('job_tittle_tbl',$where = array('id >' => 0));
        return view('templates/header')
            .view('users/job_tittle',$data)
            .view('templates/footer');    
    }

    function add_department(){
        $data = [
            'dep_name' => ucfirst($this->request->getPost('dep_name')),
            'created_by' => session()->get('user_id'),
            'created_date' => date('Y/m/d H:i:s')
        ];
        $this->smodel->SaveData('departments_tbl',$data);
    }
    public function edit_depertment($id){
       $data=$this->smodel->gettable_data('departments_tbl',$where = array('id' => $id));
       return $this->response->setJSON($data);
    } 
    public function update_depertment(){
        $dep_id=$this->request->getPost('department_id');
        $info= $this->request->getPost('department_name');
        $saveData=['dep_name'=>$info];
        $update=  $this->smodel->update_table_details('departments_tbl',$where = array('id' =>$dep_id ),$saveData);
        if($update){
            $data=['message'=>1];
    return $this->response->setJSON($data);
        }
        else{
              $data=['message'=>2];
         return $this->response->setJSON($data);  
        }
       
    }
    public function view_depertment($id){
       $data['department']=$this->smodel->gettable_data('departments_tbl',$where = array('id' => $id));
            $data['staffs']=$this->staffmodel->GetStaffsByDepartment($id);
                    echo view('users/forms/view_depertment',$data);

    }

function add_job_tittle(){
    $data = [
            'job_tittle' => ucfirst($this->request->getPost('job_name')),
            'created_by' => session()->get('user_id'),
            'created_date' => date('Y/m/d H:i:s')
        ];
        
        $this->smodel->SaveData('job_tittle_tbl',$data);
}
 public function edit_job_tittle($id){
       $data=$this->smodel->gettable_data('job_tittle_tbl',$where = array('id' => $id));
       return $this->response->setJSON($data);
    } 
    public function update_job_tittle(){
        $id=$this->request->getPost('tittle_id');
        $info= $this->request->getPost('tittle_name');
        $saveData=['job_tittle'=>$info];
        $update=  $this->smodel->update_table_details('job_tittle_tbl',$where = array('id' =>$id ),$saveData);
        if($update>0){
            $data=['message'=>1];
    return $this->response->setJSON($data);
        }
        else{
              $data=['message'=>2];
         return $this->response->setJSON($data);  
        }
       
    }
     public function view_job_tittle($id){
       $data['title']=$this->smodel->gettable_data('job_tittle_tbl',$where = array('id' => $id));
       $data['staffs']=$this->staffmodel->GetStaffsByJob($id);
             echo view('users/forms/view_job_tittle',$data);
    }
     public function delete_job_title(){
         $id=$this->request->getPost('id');
               $info= $this->request->getPost('tittle_name');
       $delete=$this->smodel->deletetable_data1('job_tittle_tbl',$where = array('id' => $id));
               if($delete){
            $data=['message'=>$info,
          'response'=>1];
    return $this->response->setJSON($data);
        }
        else{
                $data=['message'=>$info,
          'response'=>1];
         return $this->response->setJSON($data);  
        }

    }     public function delete_department(){
         $id=$this->request->getPost('id');
               $info= $this->request->getPost('department_name');
       $delete=$this->smodel->deletetable_data1('departments_tbl',$where = array('id' => $id));
               if($delete){
            $data=['message'=>$info,
          'response'=>1];
    return $this->response->setJSON($data);
        }
        else{
                $data=['message'=>$info,
          'response'=>1];
         return $this->response->setJSON($data);  
        }

    } 
function edit_staff($user_id){
     $data['det']=$this->smodel->gettable_data('users',$where = array('user_id' => $user_id));
     $data['banks']=$this->smodel->gettable_data('bank_lists_tbl','bank_id > 0');
      $data['staff_details']=$this->smodel->gettable_data('staff_details_tbl',$where = array('user_id' => $user_id));
 echo view('users/forms/edit_staff',$data);
}

function updateStaff(){
     $user_id=$this->request->getPost('user_id');
     $file = $this->request->getFile('profile_pic');
    if ($file && $file->isValid() && !$file->hasMoved()) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($file->getMimeType(), $allowedTypes)) {
            $response['message'] = 'Invalid image type.';
            return $this->response->setJSON($response);
        }
        if ($file->getSize() > 2 * 1024 * 1024) {
            $response['message'] = 'File too large. Max 2MB.';
            return $this->response->setJSON($response);
        }
        
        $oldPhoto =$this->request->getPost('old_photo');
        if (!empty($oldPhoto) && $oldPhoto !== 'default_picture.png') {
            $oldPath = ROOTPATH . 'public/users_photos/' . $oldPhoto;
            if (file_exists($oldPath)){
                unlink($oldPath);
            }
        }
        $newName = $file->getRandomName();
        $file->move(ROOTPATH . 'public/users_photos/', $newName);
        $photoData = ['user_photo' => $newName];
        if ( $this->smodel->update_table_details('users',$where = array('user_id' => $user_id),$photoData)) {
                $response = ['status' => 'success', 'message' => 'Uploaded', 'token' => csrf_hash()];
        } else {
            $response['message'] = 'Failed to save to database.';
        }
    }

    $allowance = (int) str_replace(',', '', $this->request->getPost('allowances'));
    $bsalary = (int) str_replace(',', '', $this->request->getPost('bsalary'));
    $classfication=$this->request->getPost('classification');
    $classify=0;
    if($classfication !=''){
        $classify=$classfication; 
    }
    $housing=0;
$tucta=0;
$loans=0;
$maafa=0;
if(session()->get('db_id')==17){
$maafa = str_replace(',', '', $this->request->getPost('maafa'));
$housing = str_replace(',', '', $this->request->getPost('housing'));
$loans = str_replace(',', '', $this->request->getPost('loans'));
$maafa = (float) $maafa;
$housing = (float) $housing;
$loans = (float) $loans;
$tucta = (int) $this->request->getPost('tucta_status');
$emp_no = $this->request->getPost('employee_number');
$eletricity_status = (int) $this->request->getPost('electricty_charges');
}
 $data = [
            'dep_id' => $this->request->getPost('dep_id'), 
            'job_id' => $this->request->getPost('job_id'),  
            'basic_salary' => $bsalary,  
            'allowances' => $allowance, 
            'contract_expiry_date' => $this->request->getPost('expiry_date'),  
            'account_number' => $this->request->getPost('account_number'),  
             'pension_no' => $this->request->getPost('pension_no'),  
            'tin_no' => $this->request->getPost('tin_no'),  
            'status' => $this->request->getPost('staff_status'),  
            'nhf_no' => $this->request->getPost('nhf_no'),  
            'wcf_no' => $this->request->getPost('wcf_no'),  
            'heslb_no' => $this->request->getPost('heslb_no'),  
            'account_name' => $this->request->getPost('account_name'),  
            'bank_name' => $this->request->getPost('bank_name'),  
            'pension_pay_status' => $this->request->getPost('nssf_status'),  
            'nhif_pay_status' => $this->request->getPost('nhif_status'),  
            'heslb_pay_status' => $this->request->getPost('heslb_status'),  
            'employment_type' => $this->request->getPost('employment_type'),  
            'residential_status' => $this->request->getPost('residential_status'),  
             'housing' => $housing,  
            'maafa' => $maafa,  
            'tucta_status' => $tucta,  
             'employee_number' => $emp_no,  
            'electricty_status' => $eletricity_status, 
            'classfication_id' => $classify 
          
        ];
        $present=$this->smodel->gettable_data('staff_details_tbl',$where = array('user_id' => $user_id));
        if(count($present)>0){
 $update_data=$this->smodel->update_table_details('staff_details_tbl',$where = array('user_id' => $user_id),$data);
      $data = [
            'birth_date' => $this->request->getPost('dob'),
          
        ];
        $this->smodel->update_table_details('users',$where = array('user_id' => $user_id),$data);
        }else{
     $update_data=$this->smodel->SaveData('staff_details_tbl',$data);
        }
if($update_data){
$response=[
'status'=>1,
'message'=>'updated'
];
}else{
    $response=[
'status'=>2,
'message'=>'Failed'
];

}
     return $this->response->setJSON($response);

  }
  
  function view_staff($user_id){
$staff=$user_id;
      $year=0;
    $month=0;
     $data['payrolls']=$this->staffmodel->GetStaffPayments($staff,$year,$month);
     $data['months']=$this->smodel->get_item_name('months',$where = array('month_id >' => 0));
     $data['det']=$this->smodel->gettable_data('users',$where = array('user_id' => $user_id));
      $data['staff_details']=$this->staffmodel->GetStaffData($user_id);
      $data['advances']=$this->staffmodel->GetSalaryAdvancesData($user_id);
      $data['paid_adv']=$this->staffmodel->GetPaidPayrollData($user_id);
 echo view('users/forms/view_staff_details',$data);
}
public function payroll(){
    $year =date('Y');
$this->smodel->update_table_details('months', [], ['is_current' => 0]);
 $mon_id = intval(date('m'));
 $data=['is_current'=>1];
    $current_month=$this->smodel->update_table_details('months',$where = array('month_id' => $mon_id),$data);
     $data['payrolls']=$this->staffmodel->GetAllPayroll();
     $data['all_staff']=$this->staffmodel->GetAllStaffs();
     $data['salary_advances']=$this->staffmodel->GetSalaryAdvances($year,$mon_id);
       $data['over_time']=$this->staffmodel->GetOvertime($year,$mon_id);
        $data['months']=$this->smodel->gettable_data('months',$where = array('month_id >' => 0));
        $data['brackets'] = $this->staffmodel->get_current_tax_brackets($year);
        $data['legers'] = $this->staffmodel->getLedgers();
           $data['electricity_charge']=$this->staffmodel->GetElectricityCharge($year,$mon_id);
            $data['loans_dedutions']=$this->staffmodel->GetLoansDeductions($year,$mon_id);
        $data['payroll_status']=$this->staffmodel->PayrollApprovalStatus();
        return view('templates/header')
            .view('users/payroll_home',$data)
            .view('templates/footer');  

}
    function add_payroll(){
            $trans_id = "";
       
        $tkens = $this->smodel->get_max_payroll('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $trans_id = $trans;
        } else {
            $trans_id =  1;
        }
    
    $staff_ids = $this->request->getPost('staff_id');
    $basic_salaries = $this->request->getPost('basic_salary');
    $allowances = $this->request->getPost('allowances');
    $pensions = $this->request->getPost('pension');
    $nhifs = $this->request->getPost('nhif');
    $payes = $this->request->getPost('paye');
    $advances = $this->request->getPost('advances');
    $net_salaries = $this->request->getPost('net_salary');
    $accounts = $this->request->getPost('account_id');
    $type_id = $this->request->getPost('type_id');
    $dr_amount = $this->request->getPost('dr_amount');
    $cr_amount = $this->request->getPost('cr_amount');
    $net_salary_id = $this->request->getPost('net_salary_id');
    $payroll_date = $this->request->getPost('date');
    $payroll_year = $this->request->getPost('year');
    $payroll_month = $this->request->getPost('month');
    $classfication=$this->request->getPost('classfication');
     log_message('error', 'PAYE POST => ' . print_r($payes, true));
     log_message('error', 'ACCOUNTS POST => ' . print_r($accounts, true));
     log_message('error', 'STAFF POST => ' . print_r($staff_ids, true));
     log_message('error', 'Year POST => ' . print_r($payroll_year, true));
//return;
 $month_name=$this->staffmodel->monthname($payroll_month);
     $this->db->transStart();
        $payrollTransaction = [
                'trans_type_id' => 10,
                'trans_number' => $trans_id,
                'trans_date' => date('Y-m-d H:i:s'),
                'updated_by' => session()->get('user_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
        $this->smodel->SaveData('transaction_numbers_tbl',$payrollTransaction);
        $payroll_data=[
           'payroll_month' => $payroll_month,
            'payroll_year' => $payroll_year,
            'created_by' => session()->get('user_id'),
             'transaction_id' => $trans_id,
            'transaction_type_id' => 10,
            'payroll_date' => date('Y-m-d'),
            'create_date' => date('Y/m/d H:i:s')
        ];
          $saved_payrolls=$this->staffmodel->register_payroll($payroll_data);
          if($saved_payrolls){
                              $approval = [
                    'trans_type'=>10,
                    'trans_no'=>$trans_id,
                    'name'=>$saved_payrolls,
                    'name_type'=>7,
                ];

             
            $app_hist_id = $this->billmodel->save_approval_data('approval_numbers',$approval);
            $app_history =[
                'app_no'=>$app_hist_id,//temp,
                'user'=>session()->get('user_id'),
                'user_role'=>1,
                'comment'=>'Please Approve!',
                'hstatus'=>3,
                'hist_date'=>date('Y-m-d H:i:s'),
            ];
            $this->billmodel->save_approval_history_data('approval_history',$app_history);
               $VoucherData = [
        'reason' => '',
        'trans_type' => 10,
        'voucher_type' => 6,
        'payment_no' =>$trans_id,
        'trans_no' => $trans_id
    ];
    $this->smodel->SaveData('voucher_relation_tbl', $VoucherData);
    foreach ($staff_ids as $index => $staff_id) {
        $data = [
            'staff_id' => $staff_id,
            'basic_salary' => $this->request->getPost('49'.$staff_id)?? 0,
            'allowances' =>  $this->request->getPost('50'.$staff_id)?? 0,
            'pension' =>  $this->request->getPost('43'.$staff_id) ?? 0,
            'nhif' =>  $this->request->getPost('51'.$staff_id)?? 0,
            'wcf' =>  $this->request->getPost('53'.$staff_id)?? 0,
            'heslb' =>  $this->request->getPost('55'.$staff_id)?? 0,
            'maafa' =>  $this->request->getPost('56'.$staff_id)?? 0,
            'housing' =>  $this->request->getPost('57'.$staff_id)?? 0,
            'tucta' =>  $this->request->getPost('58'.$staff_id)?? 0,
            'other_loans' =>  $this->request->getPost('59'.$staff_id)?? 0,
            'paye' => $payes[$index]?? 00,
            'over_time' => 0,
            'advances' => $this->request->getPost('48'.$staff_id)?? 0,
            'net_salaries' => $this->request->getPost('54'.$staff_id)?? 0,
              'electricity' =>  $this->request->getPost('60'.$staff_id)?? 0,
            'net_salary_balances' => $this->request->getPost('54'.$staff_id)?? 0,
            'staff_classfication' => $classfication[$index]?? 0,
            'payroll_ids' => $saved_payrolls
        ];
  // print_r($data);
  // return;
        $saved=$this->smodel->SaveData('staff_payrolls_tbl',$data);
         $ledger_data = array(53, 43, 51, 50,49,55,56,57,58,59);

foreach ($ledger_data as $value) {
    $ledger_class=[
    'staff_id' => $staff_id,
    'ledger_id' => $value,
    'amount' => $this->request->getPost($value.$staff_id)?? 0,
    'classfication' => $classfication[$index]?? 0,
    'transaction_type_id' => 10,
    'transaction_id' => $trans_id,
    'transation_nature' => 1,
    'payrolls' => $saved_payrolls
    ];
    $saved=$this->smodel->SaveData('payroll_classifications_tbl',$ledger_class);
}

         
    }
    foreach ($accounts as $index1 => $account_id) {
    if($this->request->getPost('amount'.$account_id)==0){
        continue;
    }
    $name_id=$this->request->getPost('institution'.$account_id);
    if($name_id==''){
        $name=session()->get('user_id');
        $type_name=7;
    }
    else{
      $name=$name_id;
      $type_name=8;  
    }
 $data2 = [
            'ledger_id' => $account_id,
            'ledger_type' => $this->request->getPost('type_id'.$account_id),
            'amount' => $this->request->getPost('amount'.$account_id)?? 0,
            'name_id' => $name,
            'name_type_id' => $type_name,
            'trans_type' => 10,
            'trans_item' => 0,
            'balance' => $this->request->getPost('amount'.$account_id)?? 0,
            'transation_nature' =>  $this->request->getPost('nature'.$account_id),
            'trans_no' =>  $trans_id

        ];
       $saved2=$this->smodel->SaveData('ledger_transaction_tbl',$data2);


    }
     $this->db->transComplete();
   if($this->db->transStatus() === TRUE) {

// +++++++++++++++++++++++++====================Message start==========================++++++++++++++++++++++++++++++++++++++++++
    $total_amount = (float) $this->request->getPost('total_amount');

        $messagex="<transaction name> <transaction no> to <Name> for <amount> pending approval. Approve now: <link>";
          $msg = "Payroll ".$saved_payrolls." for (".$month_name->month." ".$payroll_year.") "." ".number_format($total_amount)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
 $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 17,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' =>session()->get('user_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans_id
                  
                );
           
     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
        $priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
        if(count($priveleged)>0){
            foreach($priveleged as $plv){

            if (ctype_digit((string)$plv->privilege_id)) {
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>session()->get('db_id')));
              $this->smodel->SaveData('message_groups_tbl',$smsdata);
               foreach($assigned_user as $user){
                if($user->phone_no !=""){
$cleanPhone = sanitize_phone($user->phone_no);
if ($cleanPhone) {
    try {
           $this->SMSsender($cleanPhone, $msg, 17, $user->user_id, $snn, NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}

           $data=array(
           'phone_no'=>$user->phone_no,
           'msg'=>$msg,
           'billto'=>$trans_id,
           'snn'=>$snn,
           );
  
              }
               }
                }else{
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));

              if(count($assigned_approval)>0){
                   $this->smodel->SaveData('message_groups_tbl',$smsdata);
                foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>session()->get('db_id')));
                if($assigned_user[0]->phone_no !=""){
           
             $cleanPhone = sanitize_phone($assigned_user[0]->phone_no);
if ($cleanPhone) {
    try {
     $this->SMSsender($cleanPhone, $msg, 17, $assigned_user[0]->user_id, $snn, NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $assigned_user[0]->phone_no);
}
            $data=array(
           'msg'=>$msg,
           'billto'=>$trans_id,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

          }
          }
                }
                }

           
            }
        }


}
// +++++++++++++++++++++++++=================Message end===============++++++++++++++++++++++++++++++++++++++++++
        return $this->response->setJSON([
        'status' => 1,
        'description' => 'Payroll saved successfully'
    ]);
} else {
        $this->db->transRollback();
     return $this->response->setJSON([
        'status' => 2,
        'description' => 'Failed to save payrolls'
    ]);
}

}
}
public function GetPaymentDetails(){
     $staff_id = $this->request->getPost('staff_id');
    $payroll_id = $this->request->getPost('payroll_id');
    $year=$this->request->getPost('year');
    $month=$this->request->getPost('month');
     $data['payrolls']=$this->staffmodel->GetPayments_details($staff_id,$payroll_id,$year,$month);
     return view('users/forms/staff_payroll_details', $data);
}
public function fetchPayrollStaff()
{
    $month = $this->request->getPost('month');
    $year = $this->request->getPost('year');
    $all_staff = $this->staffmodel->GetAllStaffs();
     $salary_advances=$this->staffmodel->GetSalaryAdvances($year,$month);
    $brackets = $this->staffmodel->get_current_tax_brackets($year);
    $legers= $this->staffmodel->getLedgers();
        $electricity_charge=$this->staffmodel->GetElectricityCharge($year,$month);
       $loans_dedutions=$this->staffmodel->GetLoansDeductions($year,$month);
      $over_time=$this->staffmodel->GetOvertime($year,$month);
    $data = [
        'all_staff' => $all_staff,
        'month' => $month,
        'year' => $year,
        'legers' => $legers,
        'salary_advances' => $salary_advances,
          'electricity_charge' => $electricity_charge,
        'brackets' => $brackets,
        'loans_dedutions' => $loans_dedutions,
        'over_time' => $over_time
    ];
    $tableBody = view('users/forms/payroll_table_body', $data);
    $summaryHtml = view('users/forms/payroll_summary_table', $data);

    return $this->response->setJSON([
        'tableBody' => $tableBody,
        'summaryHtml' => $summaryHtml
    ]);
}
public function payroll_reports(){
        echo view('templates/header')
            .view('users/net_salary_report')
            .view('templates/footer');  

}
    function get_net_report(){
            $payroll_year = $this->request->getPost('year');
            $payroll_month = $this->request->getPost('month');
            $department = $this->request->getPost('dep');
            $title = $this->request->getPost('job');
            $classfication = $this->request->getPost('class_status');
            $bank = $this->request->getPost('bank');  
                $data['payroll_year']=$payroll_year;
            $data['payroll_month']=$payroll_month;
            $data['department']=$department;
            $data['title']=$title;
            $data['classfication']=$classfication;
            $data['bank']=$bank; 
            $data['net_data']=$this->staffmodel->NetsalariesReport($payroll_year,$payroll_month,$department,$title,$classfication,$bank);
          
          echo view('users/forms/view_netsalary_report',$data); 
         }
public function get_paye_report(){
      echo view('templates/header')
            .view('users/paye_report')
            .view('templates/footer'); 
}
   public function paye_report(){
            $payroll_year = $this->request->getPost('year');
            $payroll_month = $this->request->getPost('month');
            $department = $this->request->getPost('dep');
            $title = $this->request->getPost('job');
            $classfication = $this->request->getPost('class_status');
            $bank = $this->request->getPost('bank');   
                $data['payroll_year']=$payroll_year;
            $data['payroll_month']=$payroll_month;
            $data['department']=$department;
            $data['title']=$title;
            $data['classfication']=$classfication;
            $data['bank']=$bank;
            $data['net_data']=$this->staffmodel->payeReport($payroll_year,$payroll_month,$department,$title,$classfication,$bank);      
          echo view('users/forms/view_paye_report',$data); 
         }

 public function get_wcf_report(){
      echo view('templates/header')
            .view('users/wcf_report')
            .view('templates/footer'); 
}
   public function wcf_report(){
            $payroll_year = $this->request->getPost('year');
            $payroll_month = $this->request->getPost('month');
            $department = $this->request->getPost('dep');
            $title = $this->request->getPost('job');
            $classfication = $this->request->getPost('class_status');
            $bank = $this->request->getPost('bank');   
              $data['payroll_year']=$payroll_year;
            $data['payroll_month']=$payroll_month;
            $data['department']=$department;
            $data['title']=$title;
            $data['classfication']=$classfication;
            $data['bank']=$bank;
            $data['net_data']=$this->staffmodel->WCFReport($payroll_year,$payroll_month,$department,$title,$classfication,$bank);
       
          echo view('users/forms/view_wcf_report',$data); 
         }
 public function get_nssf_report(){
      echo view('templates/header')
            .view('users/nssf_report')
            .view('templates/footer'); 
}
   public function nssf_report(){
            $payroll_year = $this->request->getPost('year');
            $payroll_month = $this->request->getPost('month');
            $department = $this->request->getPost('dep');
            $title = $this->request->getPost('job');
            $classfication = $this->request->getPost('class_status');
            $bank = $this->request->getPost('bank'); 
            $data['payroll_year']=$payroll_year;
            $data['payroll_month']=$payroll_month;
            $data['department']=$department;
            $data['title']=$title;
            $data['classfication']=$classfication;
            $data['bank']=$bank;
            $data['net_data']=$this->staffmodel->NSSFReport($payroll_year,$payroll_month,$department,$title,$classfication,$bank);
       
          echo view('users/forms/view_nssf_report',$data); 
         }
         public function delete_staff(){
            $staff=$this->request->getPost('staff_id');
            $deleted=$this->staffmodel->DeleteStaff($staff);
            if($deleted){
                $data=['staff'=>0];
                $this->smodel->update_table_details('users',$where = array('user_id' => $staff),$data);
                  $data=['response'=>1];
    return $this->response->setJSON($data);
            }
         }
         public function getGrouped()
{
    $group = $this->request->getPost('group');
    $month = $this->request->getPost('month');
    $year  = $this->request->getPost('year');

    $staffs = $this->staffmodel->GetGroupedData($group);
    $advances = $this->staffmodel->GetSalaryAdvances($year, $month);
    $electricity_charges = $this->staffmodel->GetElectricityCharge($year, $month);
    $brackets = $this->staffmodel->get_current_tax_brackets($year);
    $legers = $this->staffmodel->getLedgers();
    $company = $this->staffmodel->get_company_details();
    $loans_dedutions=$this->staffmodel->GetLoansDeductions($year,$month);
    $advanceMap = [];
    foreach ($advances as $adv) {
        $advanceMap[$adv->staff_id] = $adv->advance_amount;
    }
    $electricityMap = [];
foreach ($electricity_charges as $ec) {
    $electricityMap[$ec->staff_id] = $ec->charge_amount;
}
$loansMap = [];
foreach ($loans_dedutions as $loan) {
    $loansMap[$loan->staff_id] = $loan->loan_amount;
}

    $data = [];
    foreach ($staffs as $row) {
        $key = '';
        if ($group == 1) {
            $key = $row->dep_name;
        } elseif ($group == 2) {
            $key = $row->job_tittle;
        } elseif ($group == 3) {
            $key = $row->classfication_id;
        }
        $row->advance_amount = $advanceMap[$row->user_id] ?? 0;
$row->electricity_amount = $electricityMap[$row->user_id] ?? 0;
$row->loan_amount = $loansMap[$row->user_id] ?? 0;
        $data[$key][] = $row;
    }
 $response = [
        'staffs'   => $data,
        'legers'   => $legers,
        'hasClass'      => ($company[0]->classification ?? 0),
        'hasWCF'      => ($company[0]->wcf_status ?? 0), 
        'database_id'      => session()->get('db_id'), 
        'brackets' => $brackets
    ];
    return $this->response->setJSON($response);
}
         public function view_payrolls($id){
        $trans_type=10;
        $trans_id=$this->staffmodel->payrollTransID($id);
       $data['payroll_info']=$this->staffmodel->view_payrollData($id);
       $data['approval_status']=$this->staffmodel->checkApprovalStatus($id,$trans_type);
        $data['payroll_data']=$this->staffmodel->payroll_approval_view($id,$trans_type);
    $data['ledger_data']=$this->staffmodel->view_payroll_ledger($trans_id->transaction_id,$trans_type);
             echo view('users/forms/view_payroll',$data);
    }

    public function Get_staffData(){
   $staff_id = $this->request->getPost('user_id');  
      $data['staff_data']=$this->staffmodel->view_staffData($staff_id);
       echo view('users/forms/staff_data',$data);
}

    public function view_overtime(){
                $this->smodel->update_table_details('months', [], ['is_current' => 0]);
 $mon_id = intval(date('m'));
 $data=['is_current'=>1];
    $current_month=$this->smodel->update_table_details('months',$where = array('month_id' => $mon_id),$data);
         $data['months']=$this->billmodel->get_item_name('months',$where = array('month_id >' => 0));
            echo view('templates/header')
             .view('users/overtime_home',$data)
             .view('templates/footer');
    }
    public function GetAdvanceDetails(){
     $transaction_id = $this->request->getPost('transaction_id');
     $staff = $this->request->getPost('staff');
     $data['advance_dtls']=$this->staffmodel->GetAdvance_details($transaction_id,$staff);
     return view('users/forms/salary_advance_details', $data);
}

public function save_overtime(){
    $overtime_date = $this->request->getPost('overtime_date');
    $overtime_day = $this->request->getPost('overtime_day');
    $fromtime = $this->request->getPost('fromtime');
    $totime = $this->request->getPost('totime');
    $hours = $this->request->getPost('hours');
    $rate = $this->request->getPost('rate');
    $advance_amount = $this->request->getPost('advance_amount');
    $staffs_id = $this->request->getPost('staff_datum');
    $payroll_years = $this->request->getPost('payroll_year');
    $payroll_months = $this->request->getPost('payroll_month');
    $amounts = $this->request->getPost('amount');
    $day_type = $this->request->getPost('day_type');
    $total_amount = $this->request->getPost('total_amount');
        $this->db->transStart();
         $trans_id = "";
        $tkens = $this->smodel->get_max_payroll('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $trans_id = $trans;
        } else {
            $trans_id =  1;
        }
    if($trans_id != ""){
                $payrollTransaction = [
                'trans_type_id' => 10,
                'trans_number' => $trans_id,
                'trans_date' => date('Y-m-d H:i:s'),
                'updated_by' => session()->get('user_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
 $transction=$this->smodel->SaveData('transaction_numbers_tbl',$payrollTransaction);
            $advance_ledger = [
        'ledger_id' => 56,
        'ledger_type' => 10,
        'amount' => $total_amount,
        'name_id' => $staffs_id,
        'name_type_id' => 7,
        'trans_type' => 10,
        'trans_item' => 0,
        'balance' => $total_amount,
        'transation_nature' => 2,
        'trans_no' => $trans_id
    ];

    $this->smodel->SaveData('ledger_transaction_tbl', $advance_ledger);

    if (is_array($amounts) && is_array($payroll_years) && is_array($payroll_months)  && is_array($hours)
&& is_array($fromtime) && is_array($totime) && is_array($rate)  && is_array($day_type))  {
        foreach ($amounts as $index => $amount) {
            $p_year = $payroll_years[$index];
            $p_month = $payroll_months[$index];
            $day_nature = $day_type[$index];
            $from_time = $fromtime[$index];
            $to_time = $totime[$index];
            $total_hours = $hours[$index];
            $to_time = $totime[$index];
            $rate_data = $rate[$index];
             $overtime_data = [
        'payroll_year' => $p_year ?? null,
        'payroll_month' => $p_month ?? null,
        'staff_id' =>$staffs_id,
        'nature_day' =>$day_nature,
        'from_time' =>$from_time,
        'to_time' =>$to_time,
        'total_hours' =>$total_hours,
        'rate' =>$rate_data,
        'amount' =>$amount,
        'prepared_on' =>$overtime_date,
        'transation_number' => $trans_id
    ];
          //  $saved=$this->smodel->SaveData('overtime_schedule_tbl', $overtime_data);
            if (!$this->db->table('overtime_schedule_tbl')->insert($overtime_data)) {
    $this->db->transRollback();
    return $this->response->setJSON([
        'status' => 2,
        'description' => 'Failed to insert overtime schedule',
    ]);
}

        }
    
            $approval = [
                    'trans_type'=>10,
                    'trans_no'=>$trans_id,
                    'name'=>$staffs_id ?? null,
                    'name_type'=>7,
                ];

             
            $app_hist_id = $this->billmodel->save_approval_data('approval_numbers',$approval);
            $app_history =[
                'app_no'=>$app_hist_id,
                'user'=>session()->get('user_id'),
                'user_role'=>1,
                'comment'=>$this->request->getPost('bill_comment'),
                'hstatus'=>3,
                'hist_date'=>date('Y-m-d H:i:s'),
            ];
            $this->billmodel->save_approval_history_data('approval_history',$app_history);
               $VoucherData = [
        'reason' => '',
        'trans_type' => 10,
        'voucher_type' => 9,
        'payment_no' =>$trans_id ,
        'trans_no' => $trans_id
    ];
    $this->smodel->SaveData('voucher_relation_tbl', $VoucherData);

    }}
        $this->db->transComplete();
   if($this->db->transStatus() === TRUE) {
         $staff_data=$this->staffmodel->view_staffData($staffs_id);

// +++++++++++++++++++++++++====================Message start==========================++++++++++++++++++++++++++++++++++++++++++
    $total_amount = (float) $this->request->getPost('total_amount');
        $messagex="<transaction name> <transaction no> to <Name> for <amount> pending approval. Approve now: <link>";
            $msg = "Voucher ".$trans_id." to ".$staff_data->first_name." ".$staff_data->last_name." for ".number_format($total_amount)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
 $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 17,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' =>session()->get('user_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans_id
                  
                );
     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
        $priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
        if(count($priveleged)>0){
            foreach($priveleged as $plv){

            if (ctype_digit((string)$plv->privilege_id)) {
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>session()->get('db_id')));
              $this->smodel->SaveData('message_groups_tbl',$smsdata);
               foreach($assigned_user as $user){
                if($user->phone_no !=""){
           
$cleanPhone = sanitize_phone($user->phone_no);
if ($cleanPhone) {
    try {
        $this->SMSsender($cleanPhone, $msg, 17, $trans_id, $snn, NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}


           $data=array(
           'phone_no'=>$cleanPhone,
           'msg'=>$msg,
           'billto'=>$trans_id,
           'snn'=>$snn,
           );
              }
               }
                }else{
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));

              if(count($assigned_approval)>0){
                   $this->smodel->SaveData('message_groups_tbl',$smsdata);
                foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>session()->get('db_id')));
                if($assigned_user[0]->phone_no !=""){
          
             $cleanPhone = sanitize_phone($assigned_user[0]->phone_no);
if ($cleanPhone) {
    try {
        $this->SMSsender($cleanPhone, $msg, 17, $trans_id, $snn, NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $assigned_user[0]->phone_no);
}  
            $data=array(
           'msg'=>$msg,
           'billto'=>$trans_id,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

          }
          }
                }
                }

           
            }
        }}
// +++++++++++++++++++++++++====================Message end==========================++++++++++++++++++++++++++++++++++++++
    return $this->response->setJSON([
        'status' => 1,
        'description' => 'Overtime saved successfully',
    ]);
    }else{
           $this->db->transRollback();
            return $this->response->setJSON([
        'status' => 2,
        'description' => 'Overtime saved failed',
    ]);

    }
    return;
    }

public function delete_payroll(){
    $payroll_id=$this->request->getPost('payroll_id');
    $trans_id=$this->request->getPost('trans_no');
    $trans_type=10;
       $this->db->transStart();
   $app_number=$this->staffmodel->GetApprovalNumber($trans_type,$trans_id,$payroll_id);
   $ledgers=$this->staffmodel->DeleteLedgerTransaction($trans_type,$trans_id);
   $payroll_class=$this->staffmodel->DeleteLedgerPayroll_class($trans_type,$trans_id,$payroll_id);
   $staff_payrolls=$this->staffmodel->Deletestaff_payrolls($trans_type,$trans_id,$payroll_id);
   $voucher_relation=$this->staffmodel->Deletevoucher_relation($trans_type,$trans_id,$payroll_id);
   $approval_numbers=$this->staffmodel->Deleteapproval_numbers($trans_type,$trans_id,$payroll_id);
   $approval_history=$this->staffmodel->Deleteapproval_history($app_number->app_id);
   $payrolls=$this->staffmodel->Deletepayrolls($trans_type,$trans_id,$payroll_id);
   $trans_numbers=$this->staffmodel->Deletetransaction_numbers($trans_type,$trans_id,$payroll_id);
   $MessageGroup=$this->staffmodel->DeleteMessageGroup($trans_id);
      $this->db->transComplete();
   if($this->db->transStatus() === TRUE) {
      return $this->response->setJSON([
        'status'      => 1,
        'description'  => 'Deleted Successful'
    ]);
   }else{
           $this->db->transRollback();
          return $this->response->setJSON([
        'status'      => 2,
        'description'  => 'Failed to delete'
    ]);
   }

}

  public  function electricity_deductions(){ 
            $year =date('Y');
$this->smodel->update_table_details('months', [], ['is_current' => 0]);
 $mon_id = intval(date('m'));
 $data=['is_current'=>1];
 $db_id=session()->get('db_id');
    $current_month=$this->smodel->update_table_details('months',$where = array('month_id' => $mon_id),$data);
        $data['months']=$this->smodel->gettable_data('months',$where = array('month_id >' => 0));
         $data['legers']=$this->billmodel->get_government_name();
            $data['saved_charges'] = $this->staff->GetElectricityList();
            $data['saver'] = $this->staff->getAllusersData($db_id);
         return view('templates/header')
          .view('users/electricity_charges.php',$data)
          .view('templates/footer');
    }
    public function electricity_list(){
        $db_id=session()->get('db_id');
        $charge_year=$this->request->getPost('charge_year');
        $data['charge_year']=$charge_year;
        $charge_month=$this->request->getPost('charge_month');
        $data['charges_date']=$this->request->getPost('charges_date');
        $data['charge_month']=$this->staff->get_month_name($charge_month);
        $data['staffs'] = $this->staff->staff_electricity_list($db_id);
        $data['saved_charges'] = $this->staff->check_saved_charges($charge_month,$charge_year);
        echo view('users/forms/electricity_charges_list',$data);
    }
      public function saveCharges()
{
    $post = $this->request->getPost();
    $year = $this->request->getPost('year');
    $month = $this->request->getPost('month');
    $date = $this->request->getPost('date');
    $topay = $this->request->getPost('topay_gvm');
    $total = $this->request->getPost('totalpay_gvm_value');
    $cleanData = [];

foreach ($topay as $staff_id => $amount)
{
        $amount = str_replace(',', '', $amount);
        if($amount>0){
                    $ChargeData = [
        'staff_id' => $staff_id,
        'charge_amount' => $amount,
        'charge_date' => $date,
        'pay_month' => $month,
        'pay_year' =>$year ,
        'created_on' =>date('Y-m-d H:i:s') ,
        'created_by' => session()->get('user_id')
    ];

        $save_data = $this->staff->save_electricity_charges($ChargeData);
    }

}
if($save_data==true){
$response=[
'status'=>1,
'message'=>'updated'
];
}else{
    $response=[
'status'=>2,
'message'=>'Failed'
];

}
     return $this->response->setJSON($response);
}
public function load_electricity_data(){
    $db_id=session()->get('db_id');
        $year = $this->request->getPost('saved_charge_year');
    $month = $this->request->getPost('saved_charge_month');
        $data['saved_charges'] = $this->staff->GetElectricityChargeList($year,$month);
            $data['saver'] = $this->staff->getAllusersData($db_id);
              echo view('users/forms/electricity_saved_list',$data);
    }
    public function edit_charges(){
        $id = $this->request->getPost('id');
        $data['ec'] = $this->staff->GetUpdateCharges($id);
              echo view('users/forms/electricity_edit',$data);
    } 
    public function upadte_charges(){
        $charge_id = $this->request->getPost('charge_id');
        $amount = $this->request->getPost('new_amount');
         $amount = str_replace(',', '', $amount);
         $data=[
            'charge_amount'=>$amount
        ];
        
             $save_data = $this->staff->updatechargedata($data,$charge_id);

if($save_data>0){
$response=[
'status'=>1,
'message'=>'updated'
];
}else{
    $response=[
'status'=>2,
'message'=>'Failed'
];

}
return $this->response->setJSON($response);
    }
    public function view_deductions(){
        $db_id=session()->get('db_id');
       $charge_year=$this->request->getPost('year');
       $month=$this->request->getPost('month');
       $date=$this->request->getPost('date');
       $month_id=$this->request->getPost('month_id');
       $data['date']=$date;
       $data['month']=$month;
       $data['year']=$charge_year;
       $data['month_id']=$month_id;
       
         $data['saver'] = $this->staff->getAllusersData($db_id);
        $data['saved_charges'] = $this->staff->GetMonthlyDeductions($month_id,$charge_year);
        $data['payrolls'] = $this->staff->payrollDeduction($month_id,$charge_year);
        echo view('users/forms/view_electricity_deduction',$data);
    }
    public function deletecharges(){
          $month = $this->request->getPost('month');
          $year = $this->request->getPost('year');
          $data=[
            'pay_month'=>$month,
            'pay_year'=>$year
        ];
        $delete = $this->staff->Deletecharges($data);
        if($delete){
$response=[
'status'=>1,
'message'=>'deleted'
];
}else{
    $response=[
'status'=>2,
'message'=>'deleted'
];

}
return $this->response->setJSON($response);
    }
     public function view_single_charges(){
        $id = $this->request->getPost('id');
         $month = $this->request->getPost('month');
          $year = $this->request->getPost('year');
         $data['payrolls'] = $this->staff->payrollDeduction($month,$year);
        $data['ec'] = $this->staff->GetUpdateCharges($id);
              echo view('users/forms/electricity_view',$data);
    }
    public function deletesinglecharges(){
                 $id = $this->request->getPost('id');
          $data=[
            'charge_id'=>$id
        ];
        $delete = $this->staff->Deletecharges($data);
        if($delete){
$response=[
'status'=>1,
'message'=>'deleted'
];
}else{
    $response=[
'status'=>2,
'message'=>'deleted'
];

    }
    return $this->response->setJSON($response);
}
 public  function loans_deductions(){
            $year =date('Y');
$this->smodel->update_table_details('months', [], ['is_current' => 0]);
 $mon_id = intval(date('m'));
 $data=['is_current'=>1];
 $db_id=session()->get('db_id');
    $current_month=$this->smodel->update_table_details('months',$where = array('month_id' => $mon_id),$data);
        $data['months']=$this->smodel->gettable_data('months',$where = array('month_id >' => 0));
         $data['legers']=$this->billmodel->get_government_name();
            $data['saved_charges'] = $this->staff->GetLoanDeductionsList();
            $data['saver'] = $this->staff->getAllusersData($db_id);
         return view('templates/header')
          .view('users/home_loans.php',$data)
          .view('templates/footer');
    }
        public function load_loans_info(){
            $id = $this->request->getPost('user_id');
            $bank = $this->request->getPost('user_id');

        $this->smodel->update_table_details('months', [], ['is_current' => 0]);
 $mon_id = intval(date('m'));
 $data=['is_current'=>1];
    $current_month=$this->smodel->update_table_details('months',$where = array('month_id' => $mon_id),$data);
         $data['months']=$this->billmodel->get_item_name('months',$where = array('month_id >' => 0));
         $data['staff_id']=$id;
         $data['bank_ids']=$bank;
echo view('users/forms/loans_schedule',$data);
    }
    public function save_loan_info(){
    $year = $this->request->getPost('year');
    $month = $this->request->getPost('month');
    $advance_amount = $this->request->getPost('advance_amount');
    $staffs_id = $this->request->getPost('staffs_id');
    $charges_date = $this->request->getPost('charges_date');
    $bank_id = $this->request->getPost('bank_id');
    $ttls = $this->request->getPost('ttl');  
    $payroll_years = $this->request->getPost('payroll_year');
    $payroll_months = $this->request->getPost('payroll_month');
    $amounts = $this->request->getPost('amount');
    $total_amount = $this->request->getPost('total_amount');
    if (is_array($ttls) && is_array($payroll_years) && is_array($payroll_months)) {
        foreach ($ttls as $index => $ttl) {
            $p_year = $payroll_years[$index];
            $p_month = $payroll_months[$index];
            $amt = $amounts[$index];
             $loans = [
        'pay_year' => $p_year ?? null,
        'pay_month' => $p_month ?? null,
        'loan_amount' => $amt,
        'staff_id' =>$staffs_id,
        'charge_date' =>$charges_date,
       'created_on' =>date('Y-m-d H:i:s'),
        'created_by' => session()->get('user_id')
    ];
            $saved=$this->staff->save_loan_deductions($loans);
        }
        if($saved){
               return $this->response->setJSON([
        'status' => 1,
        'description' => 'Loan schedule saved successfully',
    ]);
    }else{
            return $this->response->setJSON([
        'status' => 2,
        'description' => 'Loan schedule saved failed',
    ]);

    }
    }}
         public   function fetch_loan_month()
    {
        $payroll_month = $this->request->getPost('payroll_month');
        $year = $this->request->getPost('year');
        $staff = $this->request->getPost('staff_id');
        $ded=$this->staffmodel->GetRowDeductions($year,$payroll_month,$staff);
        $payrolls = $this->staff->payrollDeduction($payroll_month,$year);

            $builder = $this->db->table('months');
            $builder->select('month_id,month');
            $builder->where('month_id',$payroll_month);
            $query = $builder->get();
            $month_result = $query->getResult();
        if(count($month_result) > 0){
           $data = [];

foreach ($month_result as $result) {

    $data[] = [
        "month_id"    => $result->month_id,
        "month"       => $result->month,
        "payrolls"    => $payrolls->payroll_id ?? null,
        "loan_amount" => $ded->loan_amount ?? 0,
    ];
}


    echo json_encode($data);
        }  
    }
        public function view_loans_deduction(){
        $db_id=session()->get('db_id');
       $charge_year=$this->request->getPost('year');
       $month=$this->request->getPost('month');
       $date=$this->request->getPost('date');
       $month_id=$this->request->getPost('month_id');
       $data['date']=$date;
       $data['month']=$month;
       $data['year']=$charge_year;
       $data['month_id']=$month_id;
       
         $data['saver'] = $this->staff->getAllusersData($db_id);
        $data['saved_charges'] = $this->staff->GetMonthlyLoans($month_id,$charge_year);
        $data['payrolls'] = $this->staff->payrollDeduction($month_id,$charge_year);
        echo view('users/forms/view_loans_deduction',$data);
    }
         public function view_single_loan(){
        $id = $this->request->getPost('id');
         $month = $this->request->getPost('month');
          $year = $this->request->getPost('year');
         $data['payrolls'] = $this->staff->payrollDeduction($month,$year);
        $data['ec'] = $this->staff->GetUpdateLoan($id);
              echo view('users/forms/single_loan_view',$data);
    }
        public function edit_single_loan(){
               $month = $this->request->getPost('month');
          $year = $this->request->getPost('year');
        $id = $this->request->getPost('id');
          $data['payrolls'] = $this->staff->payrollDeduction($month,$year);
        $data['ec'] = $this->staff->GetUpdateLoan($id);
              echo view('users/forms/single_loan_edit',$data);
    }
        public function upadate_loan(){
          
        $charge_id = $this->request->getPost('charge_id');
        $amount = $this->request->getPost('new_amount');
         $amount = str_replace(',', '', $amount);
         $data=[
            'loan_amount'=>$amount
        ];
        
             $save_data = $this->staff->updateLoandata($data,$charge_id);

if($save_data>0){
$response=[
'status'=>1,
'message'=>'updated'
];
}else{
    $response=[
'status'=>2,
'message'=>'Failed'
];

}
return $this->response->setJSON($response);
    } 
        public function deleteloans(){
          $month = $this->request->getPost('month');
          $year = $this->request->getPost('year');
          $data=[
            'pay_month'=>$month,
            'pay_year'=>$year
        ];
        $delete = $this->staff->delete_loans($data);
        if($delete){
$response=[
'status'=>1,
'message'=>'deleted'
];
}else{
    $response=[
'status'=>2,
'message'=>'deleted'
];

}
return $this->response->setJSON($response);
    }
        public function deletesingleloan(){
                 $id = $this->request->getPost('id');
          $data=[
            'charge_id'=>$id
        ];
        $delete = $this->staff->delete_loans($data);
        if($delete){
$response=[
'status'=>1,
'message'=>'deleted'
];
}else{
    $response=[
'status'=>2,
'message'=>'deleted'
];

    }
    return $this->response->setJSON($response);
}
    }
?>