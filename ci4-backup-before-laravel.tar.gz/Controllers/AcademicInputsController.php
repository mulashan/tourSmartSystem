<?php
// By Chanangwa E.
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\UsersModel;
use App\Models\AcademicModel;
use App\Models\LoginModel;
use App\Models\StudentModel;
use App\Models\AcademicInputsModel;
use App\Models\ResultsModel;
use App\Models\ExamModel;
class AcademicInputsController extends BaseController
{
    protected $academicModel;
    protected $studentModel;
    protected $academicInputsModel;
    protected $db;

    public function __construct()
    {
        $dbname = session()->get('db_name');
        $this->db = \Config\Database::connect($dbname);
        $this->academicModel = new AcademicModel();
        $this->studentModel = new StudentModel();
          $this->ExamModel = new ExamModel();
  $this->AcademicModel = new AcademicModel();
$this->academicInputsModel = new AcademicInputsModel();
    }

    public function view_charcters()
    {    $year= date("Y");
        $data['term'] = $this->academicInputsModel->current_terms($year);
        $data['class'] = $this->academicInputsModel->list_classes();
        $data['record'] = $this->academicInputsModel->ViewRecords($year);
        return view('templates/header')
            . view('academic_inputs/character_input_view', $data)
            . view('templates/footer');
    }
        public function ViewcharctersList()
    { 
         $year=$this->request->getPost('year');
         $data['year']=$this->request->getPost('year');
        $data['term'] = $this->academicInputsModel->current_terms($year);
        $data['record'] = $this->academicInputsModel->character_result_list($year);
            echo view('academic_inputs/forms/student_character_list', $data);
    }


    public function get_students_ByStream(){
 $academicInputsModel = new AcademicInputsModel();
        $stream = $this->request->getPost('stream');
        $year = $this->request->getPost('year');
        $term = $this->request->getPost('term');
        $class = $this->request->getPost('class');
        $date = $this->request->getPost('date');
          $where=[
         'academic_year'=>$year,
        'term'=>$term,
        'class'=>$class,
        'stream'=>$stream
       ];
       $classlevel=$this->academicInputsModel->getClassLevelByClass($class);
        $data['exists'] = $academicInputsModel->CheckExistance($where);
            $data['date']=$this->request->getPost('date');
            $data['year'] = $this->request->getPost('year');
            $data['term'] = $this->request->getPost('term');
            $data['class'] = $this->request->getPost('class');
            $data['stream'] = $this->request->getPost('stream');
            $data['details']=$this->academicInputsModel->FetchCharacterData($class,$stream,$term,$year);
             $data['character']=$this->academicInputsModel->CharacterList();
              $data['selected_char']=$this->academicInputsModel->SelectedCharacterList();
             $data['grades']=$this->academicInputsModel->GradeList($classlevel);
           echo view('academic_inputs/forms/character_fill_form',$data); 
         }
 public function SaveCharacter(){
     $student_id = $this->request->getPost('student_id');
    $character_id = $this->request->getPost('character_id');
    $grade_id = $this->request->getPost('grade_id');
     $term = $this->request->getPost('term_id');
      $year = $this->request->getPost('year_id');
       $date = $this->request->getPost('date_id');
       $data=[
        'student_id'=>$student_id,
        'character_id'=>$character_id,
        'grade_id'=>$grade_id,
        'academic_yr'=>$year,
        'term'=>$term,
        'exam_date'=>$date
       ];

    $academicInputsModel = new AcademicInputsModel();
     $exists=$academicInputsModel->characterResultExist($student_id, $character_id);
     if(!empty($exists)){
       $where=['student_id' => $student_id,
              'character_id' => $character_id,
             'academic_yr'=>$year,
             'term'=>$term
              ];  
        $update=['grade_id' => $grade_id];
 $academicInputsModel->UpdateCharacterResults($where,$update);
     }else{
   $academicInputsModel->SaveCharacterResults($data);
     }
 }


         public function save_yearly_record(){
             $academicInputsModel = new AcademicInputsModel();
          $class=$this->request->getPost('class');
       $year=$this->request->getPost('year');
       $stream=$this->request->getPost('stream');
       $date=$this->request->getPost('date');
       $term=$this->request->getPost('term');
        $data=[
        'academic_year'=>$year,
        'term'=>$term,
        'class'=>$class,
        'stream'=>$stream,
        'exam_date'=>$date,
        'updated_date'=>Date('Y-m-d H:i:s'),
        'created_by'=>session()->get('user_id')
       ];
       $where=[
         'academic_year'=>$year,
        'term'=>$term,
        'class'=>$class,
        'stream'=>$stream
       ];
        $exists = $academicInputsModel->CheckExistance($where);
        if($exists){
    $msg = ['status' => 'error', 'message' => 'Records Already Exists.'];
        }else{
      if (!empty($data)) {
        if ($academicInputsModel->SaveCharacterRecord($data)) {
               $msg = ['status' => 'success', 'message' => 'Records Saved successfully.'];
           
        }else{
        $msg = ['status' => 'error', 'message' => 'Failed to Save Records. Please try again.'];
        }
     
     }else{
      $msg = ['status' => 'error', 'message' => 'Invalid data. Please fill all fields.'];
     }

         }
          echo view('academic/forms/showmsg',$msg);

}
public function delete_yearly_record(){
            $academicInputsModel = new AcademicInputsModel();
          $class=$this->request->getPost('class');
       $year=$this->request->getPost('year');
       $stream=$this->request->getPost('stream');
       $date=$this->request->getPost('date');
       $term=$this->request->getPost('term');
        $data=[
        'academic_year'=>$year,
        'term'=>$term,
        'class'=>$class,
        'stream'=>$stream,
        'exam_date'=>$date
       ];
       $where=[
         'academic_year'=>$year,
        'term'=>$term,
        'class'=>$class,
        'stream'=>$stream
       ];
       $classlevel=$this->academicInputsModel->getClassLevelByClass($class);
        $exists = $academicInputsModel->CheckExistance($where);
        if ($academicInputsModel->DeleteCharacterRecord($where)){
            $data['date']=$this->request->getPost('date');
            $data['year'] = $this->request->getPost('year');
            $data['term'] = $this->request->getPost('term');
            $data['class'] = $this->request->getPost('class');
            $data['stream'] = $this->request->getPost('stream');
            $data['details']=$this->academicInputsModel->FetchCharacterData($class,$stream,$term,$year);
             $data['character']=$this->academicInputsModel->CharacterList();
              $data['selected_char']=$this->academicInputsModel->SelectedCharacterList();
             $data['grades']=$this->academicInputsModel->GradeList($classlevel);
               return $this->response->setJSON(['status' => 'success', 'message' => 'Record deleted successfully!']);
           echo view('academic_inputs/forms/character_fill_form',$data); 
         
        }else{
        $msg = ['status' => 'error', 'message' => 'Failed to Allow Records update. Please try again.'];
         echo view('academic/forms/showmsg',$msg);
          return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to delete record!']);
        }

         }

              public function ViewStreamcharctersList()
    { 
         $year=$this->request->getPost('year_id');
         $term=$this->request->getPost('term_id');
         $class=$this->request->getPost('class_id');
         $stream=$this->request->getPost('stream_id');
         $record=$this->request->getPost('record_id');
         $data['classname']=$this->request->getPost('classname');
         $data['streamname']=$this->request->getPost('streamname');
         $data['combname']=$this->request->getPost('combname');
        $data['term'] = $this->academicInputsModel->current_terms($year);
         $data['character']=$this->academicInputsModel->CharacterList();
      $data['stream_record'] = $this->academicInputsModel->ViewStreamRecords($year,$record,$term);
      $data['students'] = $this->academicInputsModel->FetchExam_list($class,$stream,$year);
            echo view('academic_inputs/forms/stream_character_results', $data);
    }

        public function get_students_ByStream_Results(){
 $academicInputsModel = new AcademicInputsModel();
        $stream = $this->request->getPost('stream');
        $year = $this->request->getPost('year');
        $term = $this->request->getPost('term');
        $exam = $this->request->getPost('exam');
        $class = $this->request->getPost('class');
        $date = $this->request->getPost('date');
        $examtype= $this->request->getPost('examtype');
        $where=[
         'academic_year'=>$year,
        'term'=>$term,
        'class'=>$class,
        'exam_type_id'=>$examtype,
        'stream'=>$stream
       ];
       $classlevel=$this->academicInputsModel->getClassLevelByClass($class);
        $data['exists'] = $academicInputsModel->CheckResultsRecordExistance($where);
            $data['date']=$this->request->getPost('date');
            $data['year'] = $this->request->getPost('year');
            $data['term'] = $this->request->getPost('term');
            $data['class'] = $this->request->getPost('class');
            $data['stream'] = $this->request->getPost('stream');
            $data['examtype'] = $this->request->getPost('examtype');
            $data['details']=$this->academicInputsModel->FetchCharacterData($class,$stream,$term,$year);
            $data['subjects']=$this->academicInputsModel->GetSubjectsByStream($stream);
            $data['character']=$this->academicInputsModel->CharacterList();
           $data['selected_char']=$this->academicInputsModel->SelectedCharacterList();
             $data['grades']=$this->academicInputsModel->GradeList($classlevel);
          
             $data['results']=$this->academicInputsModel->GetExamResults($examtype,$term,$year,$stream,$class,$classlevel);
           echo view('academic_inputs/forms/exam_results_fill_form',$data); 
         }
          public function SaveExamResult(){
     $student_id = $this->request->getPost('student_id');
    $subject_id = $this->request->getPost('subject_id');
    $marks = $this->request->getPost('marks');
     $term = $this->request->getPost('term_id');
     $examtype = $this->request->getPost('examtype_id');
      $year = $this->request->getPost('year_id');
       $date = $this->request->getPost('date_id');
       $class = $this->request->getPost('class_id');
           $this->ExamModel = new ExamModel();
           $exammodel = new ExamModel();
   $classlevel=$this->academicInputsModel->getClassLevelByClass($class);
    $grade =$exammodel->GradeValues($marks,$classlevel);
    if(!empty($grade) && isset($grade)){
        $grade_id=$grade->grade_id;
       $data=[
        'student_id'=>$student_id,
        'subject_id'=>$subject_id,
        'marks_scored'=>$marks,
        'academic_year'=>$year,
        'exam_id'=>$examtype,
        'grade_id'=>$grade_id,
        'created_by'=>session()->get('user_id'),
        'created_on'=>Date('Y-m-d H:i:s'),
        'term'=>$term
       ];

    $academicInputsModel = new AcademicInputsModel();
     $exists=$academicInputsModel->ExamResultExist($student_id,$subject_id,$term,$examtype,$year);
     if(!empty($exists)){
       $where=['student_id' => $student_id,
              'subject_id' => $subject_id,
             'academic_year'=>$year,
             'exam_id'=>$examtype,
             'term'=>$term
              ];  
        $update=['marks_scored' => $marks, 'grade_id' => $grade_id];
 $updatemarks=$academicInputsModel->UpdateExamResults($where,$update);
 if($updatemarks){
       $grade = $this->academicInputsModel->getGradeForMarks($marks,$classlevel);
    return $this->response->setJSON([
        'status' => 1,
        'grade_name' => $grade,
        'grade_id' => $grade_id
    ]);
 }else{
  return $this->response->setJSON(['status' => 4]);  
 }
  
     }else{

  $Addmarks= $academicInputsModel->SaveExamResults($data);
  if($Addmarks){
    $grade = $this->academicInputsModel->getGradeForMarks($marks,$classlevel);
    return $this->response->setJSON([
        'status' => 1,
        'grade_name' => $grade,
        'grade_id' => $grade_id
    ]);
  }
    else{
        return $this->response->setJSON(['status' => 4]);    
    }
   
     } 
    }
        else{
           return $this->response->setJSON(['status' => 3]);  
        }

 }
 public function RefreshExamGrades()
{
    $db = \Config\Database::connect(session()->get('db_name'));
    $studentModel = new AcademicInputsModel();
    $examModel = new ExamModel();

    $class = $this->request->getPost('class');
    $stream = $this->request->getPost('stream');
    $year = $this->request->getPost('year');
    $term = $this->request->getPost('term');
    $examtype = $this->request->getPost('examtype');
    $date = $this->request->getPost('date');

    $classLevel = $this->academicInputsModel->getClassLevelByClass($class);
    $results = $db->table('exam_results_tbl')
        ->where([
            'academic_year' => $year,
            'term' => $term,
            'exam_id' => $examtype
           
        ])
        ->get()
        ->getResult();

    if (empty($results)) {
        return $this->response->setJSON(['status' => 0, 'message' => 'No saved marks found.']);
    }

    $updated = 0;

    foreach ($results as $row) {
            $db = \Config\Database::connect(session()->get('db_name'));
        $grade = $examModel->GradeValues($row->marks_scored, $classLevel);
        if (!empty($grade)) {
            $db->table('exam_results_tbl')
                ->where('result_id', $row->result_id)
                ->update(['grade_id' => $grade->grade_id]);
            $updated++;
        }
    }

    return $this->response->setJSON([
        'status' => 1,
        'message' => "Examination results refreshed for $updated records."
    ]);
}

 public function SaveExam_yearly_record(){
       $academicInputsModel = new AcademicInputsModel();
       $class=$this->request->getPost('class');
       $year=$this->request->getPost('year');
       $stream=$this->request->getPost('stream');
       $date=$this->request->getPost('date');
       $term=$this->request->getPost('term');
       $examtype=$this->request->getPost('examtype');
        $studentIds = $this->request->getPost('student_ids');
       $subjectIds = $this->request->getPost('subject_ids');
        $data=[
        'academic_year'=>$year,
        'term'=>$term,
        'class'=>$class,
        'stream'=>$stream,
        'exam_type_id'=>$examtype,
        'exam_date'=>$date,
        'updated_date'=>Date('Y-m-d H:i:s'),
        'created_by'=>session()->get('user_id')
       ];
    
       $where=[
         'academic_year'=>$year,
        'term'=>$term,
        'class'=>$class,
        'exam_type_id'=>$examtype,
        'stream'=>$stream
       ];
        $exists = $academicInputsModel->CheckResultsRecordExistance($where);
        if($exists){
    $msg = ['status' => 'error', 'message' => 'Records Already Exists.'];
        }else{
      if (!empty($data)) {
        $record=$academicInputsModel->SaveExamRecord($data);
        if ($record) {
            foreach ($studentIds as $studentId) {
    foreach ($subjectIds as $subjectId) {
        $where1 = [
            'student_id'   => $studentId,
            'subject_id'   => $subjectId,
            'academic_year'         => $year,
            'term'         => $term,
            'exam_id' => $examtype,
           
        ];
    

           $where=[
         'academic_year'=>$year,
        'term'=>$term,
        'exam_id'=>$examtype
       ];
      if (!empty($where)){
        if ($academicInputsModel->Add_record_data($where1,$record)) {
               $msg = ['status' => 'success', 'message' => 'Records Saved successfully.'];
           
        }else{
        $msg = ['status' => 'error', 'message' => 'Failed to Save Records. Please try again.'];
        }
     
     }

   }}
           
        }else{
        $msg = ['status' => 'error', 'message' => 'Failed to Save Records. Please try again.'];
        }
     
     }else{
      $msg = ['status' => 'error', 'message' => 'Invalid data. Please fill all fields.'];
     }

         }
          echo view('academic/forms/showmsg',$msg);
 }
 public function delete_Exam_yearly_record(){
            $academicInputsModel = new AcademicInputsModel();
          $class=$this->request->getPost('class');
       $year=$this->request->getPost('year');
       $stream=$this->request->getPost('stream');
       $date=$this->request->getPost('date');
       $term=$this->request->getPost('term');
       $examtype=$this->request->getPost('examtype');
     $studentIds = $this->request->getPost('student_ids');
       $subjectIds = $this->request->getPost('subject_ids');
        $data=[
        'academic_year'=>$year,
        'term'=>$term,
        'class'=>$class,
        'stream'=>$stream,
        'exam_type_id'=>$examtype,
        'exam_date'=>$date
       ];
           $where=[
         'academic_year'=>$year,
         'exam_type_id'=>$examtype,
        'term'=>$term,
        'class'=>$class,
        'stream'=>$stream
       ];
       $classlevel=$this->academicInputsModel->getClassLevelByClass($class);
        $exists = $academicInputsModel->CheckResultsRecordExistance($where);
        $record =$exists[0]->result_record_id;;
    foreach ($studentIds as $studentId) {
    foreach ($subjectIds as $subjectId) {
        $where1 = [
            'student_id'   => $studentId,
            'subject_id'   => $subjectId,
            'academic_year'         => $year,
            'term'         => $term,
            'exam_id' => $examtype,
           
        ];
           $where2=[
         'academic_year'=>$year,
        'term'=>$term,
        'exam_id'=>$examtype
       ];
           $where=[
         'academic_year'=>$year,
         'exam_type_id'=>$examtype,
        'term'=>$term,
        'class'=>$class,
        'stream'=>$stream
       ];
      if (!empty($where) && !empty($where1)){
        $data_update=$academicInputsModel->Update_record_data($where1,$record);
        if ($data_update) {
                if ($academicInputsModel->DeleteMonthlyRecord($where)){
            $data['date']=$this->request->getPost('date');
            $data['year'] = $this->request->getPost('year');
            $data['term'] = $this->request->getPost('term');
            $data['class'] = $this->request->getPost('class');
            $data['stream'] = $this->request->getPost('stream');
            $data['details']=$this->academicInputsModel->FetchCharacterData($class,$stream,$term,$year);
             $data['character']=$this->academicInputsModel->CharacterList();
              $data['selected_char']=$this->academicInputsModel->SelectedCharacterList();
             $data['grades']=$this->academicInputsModel->GradeList($classlevel);
               return $this->response->setJSON(['status' => 'success', 'message' => 'Record deleted successfully!']);
           echo view('academic_inputs/forms/exam_results_fill_form',$data); 
         
        }else{
      
          return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to delete record!']);
          echo view('academic_inputs/forms/exam_results_fill_form',$data); 
        }

        }else{
           return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to delete record!']);
        echo view('academic_inputs/forms/exam_results_fill_form',$data); 
        }
     
     }

   }}


         }
         public function View_ExamResult_List(){
         $year=$this->request->getPost('year');
         $record=$this->academicInputsModel->exam_result_list($year);
         $data['year']=$this->request->getPost('year');
         if(!empty($record)){
             $data['record'] = $this->academicInputsModel->exam_result_list($year);
            echo view('academic_inputs/forms/exam_results_list', $data);
        }else{
             $data['record'] = $this->academicInputsModel->exam_result_list($year);
             //$data['record'] = $this->academicInputsModel->filled_exam_result_list($year);
            echo view('academic_inputs/forms/filled_exam_results', $data);
        }
       
}
            public function ViewExamResultsList()
    {
         $year=$this->request->getPost('year_id');
         $term=$this->request->getPost('term_id');
         $class=$this->request->getPost('class_id');
         $stream=$this->request->getPost('stream_id');
         $examtype=$this->request->getPost('stream_id');
         $record=$this->request->getPost('record_id');
         $data['classname']=$this->request->getPost('classname');
         $data['streamname']=$this->request->getPost('streamname');
         $data['examname']=$this->request->getPost('examname');
         $data['combname']=$this->request->getPost('combname');
          $data['results'] = $this->academicInputsModel->GetExamMarks_list($year,$record,$term);
         $data['subjects']=$this->academicInputsModel->GetSubjectsByStreamReport_List($class,$stream);
            $data['students'] = $this->academicInputsModel->FetchExam_list($class, $stream, $year);
            echo view('academic_inputs/forms/view_exam_results_list', $data);
    }
            public function view_exam_results()
    {    $year= date("Y");
        $data['term'] = $this->academicInputsModel->current_terms($year);
        $data['class'] = $this->academicInputsModel->list_classes();
        $data['exams'] = $this->academicInputsModel->list_exams();
        $data['record'] = $this->academicInputsModel->ViewRecords($year);
        if(session()->get('user_type')==6){
           return view('templates/header')
            . view('academic_inputs/exam_results_view', $data)
            . view('templates/footer');  
        }else{
              $username=session()->get('user_id');
              $data['myclass'] = $this->academicInputsModel->list_my_classes($username);
               return view('templates/header')
            . view('academic_inputs/teachers/exam_results_input_view', $data)
            . view('templates/footer');  
        }
       
    }
        public  function get_stream_by_class(){
        $this->ResultsModel = new ResultsModel();
           $class=$this->request->getPost('clvl');
            if(session()->get('user_type')==6){
             $data = $this->academicInputsModel->Comb_stream_list($class); 
              return $this->response->setJSON($data);
       }else{
         $username=session()->get('user_id');
             $data = $this->academicInputsModel->my_Comb_stream_list($class,$username); 
               return $this->response->setJSON($data);
        }

}
        public function teacher_based_students_ByStream_Results(){
           $academicInputsModel = new AcademicInputsModel();
        $stream = $this->request->getPost('stream');
        $year = $this->request->getPost('year');
        $term = $this->request->getPost('term');
        $exam = $this->request->getPost('exam');
        $class = $this->request->getPost('class');
        $date = $this->request->getPost('date');
        $examtype= $this->request->getPost('examtype');
        $where=[
        'academic_year'=>$year,
        'term'=>$term,
        'exam_id'=>$examtype
       ];
            $username=session()->get('user_id');
            $classlevel=$this->academicInputsModel->getClassLevelByClass($class);
            $data['exists'] = $academicInputsModel->CheckResultsStatus($where);
            $data['date']=$this->request->getPost('date');
            $data['year'] = $this->request->getPost('year');
            $data['term'] = $this->request->getPost('term');
            $data['class'] = $this->request->getPost('class');
            $data['stream'] = $this->request->getPost('stream');
            $data['examtype'] = $this->request->getPost('examtype');
            $data['details']=$this->academicInputsModel->FetchCharacterData($class,$stream,$term,$year);
            $data['subjects']=$this->academicInputsModel->GetSubjectsTeacherByStream($stream,$username);
            $data['character']=$this->academicInputsModel->CharacterList();
            $data['selected_char']=$this->academicInputsModel->SelectedCharacterList();
            $data['grades']=$this->academicInputsModel->GradeList($classlevel);
            $data['results']=$this->academicInputsModel->GetExamResults($examtype,$term,$year,$stream,$class,$classlevel);
           echo view('academic_inputs/teachers/forms/input_results_fill_form',$data); 
         }

 public function SubmitExam_details(){
       $academicInputsModel = new AcademicInputsModel();
       $class=$this->request->getPost('class');
       $year=$this->request->getPost('year');
       $stream=$this->request->getPost('stream');
       $date=$this->request->getPost('date');
       $term=$this->request->getPost('term');
       $examtype=$this->request->getPost('examtype');
       $studentIds = $this->request->getPost('student_ids');
       $subjectIds = $this->request->getPost('subject_ids');
foreach ($studentIds as $studentId) {
    foreach ($subjectIds as $subjectId) {
        $where1 = [
            'student_id'   => $studentId,
            'subject_id'   => $subjectId,
            'academic_year'         => $year,
            'term'         => $term,
            'exam_id' => $examtype,
           
        ];
    

       $where=[
         'academic_year'=>$year,
        'term'=>$term,
        'exam_id'=>$examtype
       ];
      if (!empty($where)){
        if ($academicInputsModel->SubmitExamResults($where1)) {
               $msg = ['status' => 'success', 'message' => 'Records Saved successfully.'];
           
        }else{
        $msg = ['status' => 'error', 'message' => 'Failed to Save Records. Please try again.'];
        }
     
     }else{
      $msg = ['status' => 'error', 'message' => 'Invalid data. Please fill all fields.'];
     }

         }
          echo view('academic/forms/showmsg',$msg);

       }  
 }
 public function Allow_update_Exam_results(){
      $academicInputsModel = new AcademicInputsModel();
       $class=$this->request->getPost('class');
       $year=$this->request->getPost('year');
       $stream=$this->request->getPost('stream');
       $date=$this->request->getPost('date');
       $term=$this->request->getPost('term');
       $examtype=$this->request->getPost('examtype');
       $studentIds = $this->request->getPost('student_ids');
       $subjectIds = $this->request->getPost('subject_ids');
foreach ($studentIds as $studentId) {
    foreach ($subjectIds as $subjectId) {
        $where1 = [
            'student_id'   => $studentId,
            'subject_id'   => $subjectId,
            'academic_year'         => $year,
            'term'         => $term,
            'exam_id' => $examtype,
           
        ];
    

       $where=[
         'academic_year'=>$year,
        'term'=>$term,
        'exam_id'=>$examtype
       ];
      if (!empty($where)){
        if ($academicInputsModel->AllowUpdateExamResults($where1)) {
               $msg = ['status' => 'success', 'message' => 'Records Saved successfully.'];
           
        }else{
        $msg = ['status' => 'error', 'message' => 'Failed to Save Records. Please try again.'];
        }
     
     }else{
      $msg = ['status' => 'error', 'message' => 'Invalid data. Please fill all fields.'];
     }

         }
          echo view('academic/forms/showmsg',$msg);

       }  

 }
}
?>
