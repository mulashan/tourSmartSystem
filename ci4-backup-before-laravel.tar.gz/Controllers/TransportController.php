<?php 
namespace App\Controllers;
use CodeIgniter\Config\Services;
use CodeIgniter\Controller;
use App\Models\TransportModel;
use App\Models\AdmissionModel;
use App\Models\StudentModel;
use App\Models\SystemModel;
use App\Models\PaymentsModel;

class TransportController extends BaseController{
	public $transport;
	public $amodel;
	public $smodel;
	public function __construct(){
	    
	     if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
		$this->transport= new TransportModel;
		 $this->amodel = new AdmissionModel();
		 $this->smodel = new StudentModel();
		 $this->sytm_model = new SystemModel();
		 $this->payment_model = new PaymentsModel;
		 
	 $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
           helper('age');

     $session = \Config\Services::session();
	}

	function transport(){
			//$data['fetch']=$this->transport->getAllVehicles();
		$data=array(
			'fetch'=>$this->transport->getAllVehicles(),
			'fetch2'=>$this->transport->getAllVehicles(),
			'result'=>$this->transport->ChargedItem(),
			'update'=>$this->transport->getAllVehicles()
			
		);
		return view('templates/header')
		.view('transport/transport',$data)
		.view('templates/footer');
	}
	////////////////////////////////////////////////
	function add_new_vehicle()
	{
		$validation =  \Config\Services::validation();

		 $classesValidation=( [
			'vname' =>[
				'label'=>' Vehicle Name',
				'rules'=>'required|is_unique[vehicles_tbl.vehicle_name]',
				'errors'=>[
					'required'=>'Vehicle Name Can Not Be Empty',
					'is_unique'=>'The Vehicle Name Exist'

				],
			],
			// 'vreg' =>[
			// 	'label'=>' Vehicle Registration Number',
			// 	'rules'=>'required|is_unique[vehicles_tbl.vehicle_number]',
			// 	'errors'=>[
			// 		'required'=>'Vehicle Registration Number Can Not Be Empty',
			// 		'is_unique'=>'The Vehicle With This Reg No Exist'
			// 	],
			// ],
			'scapcty' =>[
				'label'=>' Vehicle Capacity',
				'rules'=>'required',
				'errors'=>[
					'required'=>'Vehicle Capacity Can Not Be Empty'
				],
			],
			'route' =>[
				'label'=>' Route',
				'rules'=>'required',
				'errors'=>[
					'required'=>'Vehicle Route Can Not Be Epmty'
				],
			],
			'status' =>[
				'label'=>' Status',
				'rules'=>'required',
				'errors'=>[
					'required'=>'Vehicle Status Can Not Be Empty'
				],
			],

		]

	);
		if($this->validate($classesValidation)){
			$data = [
				'vehicle_name' => "hice",
				 'vehicle_number' => $this->request->getPost('vname'),
				'capacity' => $this->request->getPost('scapcty'),
				'route_id' => $this->request->getPost('route'),
				'driver_id' => 0,
				'balance' => 1,
				'status' =>$this->request->getPost('status'),
				'updated_by' =>$_SESSION['user_id'],
				'updated_date' => date('Y/m/d H:i:s')
			];
			$servedData=$this->transport->addNewVehicle($data);
            
            if($servedData != 0){
			 $this->transport->saveInstallmentData($servedData);
                //$charged_item = array();
        }else{
        
        }

			if($servedData !=0){


				$Item=$this->request->getPost('id');
				$c=0;
				foreach ($Item as $i) {

					$charged_item = array('transport_id' => $servedData, 'item_id' => $i,
						'quantity' => $this->request->getPost('qty['.$c.']'), 'account_receivable' => $this->request->getPost('account'));
					$this->transport->create_charged_item($charged_item);
					$c++;
				}


			}
			

		}else{
			
		}


	}
		function DeleteVehicle(){
		$id=$this->request->getPost('id');
		if($this->transport->deleteVehicle($id)&&$this->transport->deleteTransportItem($id)){
			return redirect()->to('/transport');
		}
	}
	function DeleteVehicleItem($id = null){
		
		//$tid=$this->request->getPost('vehicle');
		//$iid=$this->request->getPost('item_id');
		//if($this->transport->deleteVehicleItem($tid,$iid)){
			//echo "no";
		
	//	}


		$this->transport->delete_transport_chargedItems($id);
	}
	public function load_item_data()
	{

		$request = service('request');
		$postData = $request->getPost();
		$item_data = array();
		$builder = $this->db->table("items_tbl");

		if(isset($postData['query'])){

			$builder->select('id,item_name,item_price,item_attribute,item_size');
			$builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
			$builder->like('item_name',$postData['query'],'both');
			$builder->limit(100);
			$query = $builder->get();
			$item_result = $query->getResult();
		}else{

			$builder->select('id,item_name,item_price,item_attribute,item_size');
			$builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
			$builder->limit(100);
			$query = $builder->get();
			$item_result = $query->getResult();
		}

		if(count($item_result) > 0){
			foreach($item_result as $result){
				$price=number_format($result->item_price);
				$item_data[] = array(

					'id'=>$result->id,
					'text'=>$result->item_name.':'.'  size= '.$result->item_size.','.' price= ' .$price.','.'  attribute='.$result->item_attribute);
			}
		}    
		$response['data'] = $item_data;

		return $this->response->setJSON($response);
	}
	public function load_item_data1()
	{

		
		$postedData = $this->request->getRawInput();
        // print_r($postedData['selected_items_array']);
		$selectedItem = explode(',', $postedData['selected_items_array']);

		foreach ($selectedItem as $sdi) {


			if($sdi == $postedData['item_selected'] ){
				echo "1";
				return;

			}
		}

		$data = $this->transport->items_chargedList1($postedData['item_selected']);
		$item_data = array();
		if(count($data) > 0){

			foreach($data as $dt){

				$item_data[] = array("id" => $dt->id,"iprice" => $dt->item_price, "iname" => $dt->item_name,
					"isize"=>$dt->item_size,"iattribute"=>$dt->item_attribute
				);
			}
		}
		echo json_encode($item_data);
	}
	public function load_item_dat($transport_id)
	{


		$retunedVehiclesItems["item"]=$this->transport->selectingAllItemsOfVehicle($transport_id);
		$Items=$retunedVehiclesItems["item"];
		$postedData = $this->request->getRawInput();
        // print_r($postedData['selected_items_array']);
		$selectedItem = explode(',', $postedData['selected_items_array']);

		foreach ($selectedItem as $sdi) {
			for($i=0; $i<sizeof($Items); $i++){
				$itemid=$Items[$i]->item_id;



				if($sdi == $postedData['item_selected']||$itemid== $postedData['item_selected'] ){
					echo "1";
					return;
				}
			}
		}

		$data = $this->transport->items_chargedList1($postedData['item_selected']);
		$item_data = array();
		if(count($data) > 0){

			foreach($data as $dt){

				$item_data[] = array("id" => $dt->id,"iprice" => $dt->item_price, "iname" => $dt->item_name,
					"isize"=>$dt->item_size,"iattribute"=>$dt->item_attribute
				);
			}
		}
		echo json_encode($item_data);
	}
	public function loadVehicleUpdate(){
		$id= $this->request->getVar('trs');
		$item_id= $this->request->getPost('iid');
		$data=array(
			'fetch'=>$this->transport->getAllVehicles(),
			'result'=>$this->transport->ChargedItem(),
			'updated'=>$this->transport->returnAlldataOfVehicle($id),
			'item'=>$this->transport->vehicleItems($id),
			'vehicle_id'=>$this->request->getPost('vid')
		);
		echo view('transport/VehicleUpdate',$data);
	}

	public function ViewVehicleUpdate(){
		$id= $this->request->getVar('trs');
		$item_id= $this->request->getPost('iid');
		$data=array(
			'fetch'=>$this->transport->getAllVehicles(),
			'result'=>$this->transport->ChargedItem(),
			'updated'=>$this->transport->returnAlldataOfVehicle($id),
			'item'=>$this->transport->vehicleItems($id),
			'vehicle_id'=>$this->request->getPost('vid')
		);
		echo view('transport/VehicleView',$data);
	}
	
	//updating the vehicles
	function update_vehicle()
	{
		// $id=$this->request->getPost('vid');
		$data = [
			'id' =>$this->request->getPost('vid'),
			'vehicle_name' => "hice",
			'vehicle_number' => $this->request->getPost('vname'),
			'capacity' => $this->request->getPost('scapcty'),
			'route_id' => $this->request->getPost('route'),
			'driver_id' => 0,
			'balance' => 1,
			'status' =>$this->request->getPost('status'),
			'updated_by' =>$_SESSION['user_id'],
			'updated_date' => date('Y/m/d H:i:s')
		];

// print_r($data);
// return;
		$this->transport->Update_Vehicle($this->request->getPost('vid'),$data);
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
            <span class="glyphicon glyphicon-ok"></span> Vehicle Updated Successful.</div> ';
		
	}
	//start of the updating the item detail
	function update_items()
	{
		$transport=$this->request->getPost('vid');
		$Item=$this->request->getPost('id');
         //$this->transport->delete_TransportId($transport);
		$c=0;
		foreach ($Item as $i) {

			$charged_item = array(
				'transport_id' =>$transport, 'item_id' => $i,
				'quantity' => $this->request->getPost('qt['.$c.']'));
			$this->transport->edit_charged_item($transport,$charged_item);
			$c++;

		}

		return redirect()->to('/transport');
	}
	
public function adding_temporary_data4()
{
	$exit=$this->transport->check_temp($this->request->getPost('installname'));
        if($exit>0){
          echo "1";  
        }else{
    $data = [
        'istallment_name' => $this->request->getPost('installname'),
        'amount' => $this->request->getPost('amount'),
        'tbl_id' => $this->request->getPost('id'),
        'installment_type' =>4,
        
    ];

    $inst = $this->transport->add_temporary($data);
}}
public function getting_tempo4()
{
    $builder = $this->db->table('installments_tbl ');
    $builder->select('*');
    $builder->where('tbl_id',$this->request->getGet('acc_id'));
    $builder->where('installment_type',4);
    $ments_result = $builder->get()->getResult();
	
    $ments_dta = array();
   
    if(count($ments_result) > 0){
		$total=0;
        foreach ($ments_result as $sr)
        {
	$builder = $this->db->table('school_terms_tbl');
    $builder->select('*');
    $builder->where('id',$sr->istallment_name);
    $result = $builder->get()->getResult();
	
			$amount=$sr->amount;
			
			$total=$total+$amount;
            $data = array("id" => $sr->id,"installname" => $result[0]->term_name, "amount" => $sr->amount,
			"duedate" => $result[0]->end_date, "classid" => $sr->tbl_id,"tamount"=>$total);
            array_push($ments_dta, $data);
        }

    }
echo json_encode($ments_dta);

    }	
        	

 public function getting_installments4()
    {
        $builder = $this->db->table('installments_tbl ');
        $builder->select('*');
        $builder->where('tbl_id',$this->request->getGet('tra_id'));
        $id=$this->request->getGet('tra_id');
        $builder->where('installment_type',4);
        $ments_result = $builder->get()->getResult();
		
		$builder = $this->db->table('transport_item_tbl');
        $builder->select('transport_item_tbl.item_id,transport_item_tbl.quantity,
		price_tbl.item_price');
		$builder->join('price_tbl', 'price_tbl.item_id = transport_item_tbl.item_id');
		$builder->where('transport_item_tbl.transport_id',$this->request->getGet('tra_id'));
        $price_result = $builder->get()->getResult();

        $ment_dta = array();
        //echo (count($price_result));
        if(count($price_result) > 0){
			$total=0;
            foreach ($price_result as $pr)
            {
				$qty=$pr->quantity;
				$price=$pr->item_price;
				$tprice=$qty*$price;
				$total=$total+$tprice;
			}
			}else{
			$total=0;
	
			}
        if(count($ments_result) > 0){
			
            foreach ($ments_result as $sr)
            {
     $builder = $this->db->table('school_terms_tbl');
    $builder->select('*');
    $builder->where('id',$sr->istallment_name);
    $result = $builder->get()->getResult();

                $data = array("id" => $sr->id,"installname" => $result[0]->term_name, "amount" => $sr->amount,
				"duedate" => $result[0]->end_date, "classid" => $sr->tbl_id,"tprice"=>$total);
               array_push($ment_dta, $data);
            }
             
            echo json_encode($ment_dta);
        }
    }
    public function adding_installment_data4($id)
    {
    	$exit = $this->transport->check_inst($id,$this->request->getPost('installname'));
        if($exit>0){
            echo '1';
        }else{

        $data = [
            'istallment_name' => $this->request->getPost('installname'),
            'amount' => $this->request->getPost('amount'),
            'tbl_id' => $this->request->getPost('id'),
            'installment_type' =>4
            
        ];

       $this->transport->add_installment($data);
    }}

    function new_transport(){
    return view('templates/header')
		.view('transport/nw_transport')
		.view('templates/footer');	
    }
    function save_route(){
    	
    	 
    	$data = [
            'route_name' => ucfirst($this->request->getPost('routename')),
            'via' => ucfirst($this->request->getPost('vianame')),
            'station' => $this->request->getPost('stationname'),
            'start_time' => $this->request->getPost('timename'),
            'vehicle' => $this->request->getPost('vehiclename'),
            'status' =>  $this->request->getPost('status'),
            'route_session' =>  $this->request->getPost('sess'),
            'created_by' => $_SESSION['user_id']
            
            
        ];

       $this->transport->add_route($data);
       echo '<div class="alert alert-success">Saved Successful!</div>';
    }

   public function load_routeList()
{
    $builder = $this->db->table('route_tbl ');
    $builder->select('*');
    $result = $builder->get()->getResult();
	
    $ments_dta = array();
   
    if(count($result) > 0){
		
        foreach ($result as $sr)
        {
        	$st=$sr->status;
        	if($st==1){
        		$status='<span style="color:green">Active</span>';
        	}else{
        	$status='<span style="color:red">Inactive</span>';	
        	}

        	if($sr->route_session==1){
        		$sess='Morning';
        	}
        	elseif($sr->route_session==2){
        		$sess='Afternoon';
        	}
        	elseif($sr->route_session==3){
        		$sess='Evening';
        	}
        	else{
        	$sess='<span style="color:red">Absent</span>';	
        	}
		 $vhcl=$this->transport->search_vehicle($sr->vehicle);
		 $cr=$this->transport->search_createdby($sr->created_by);
            $data = array("id" => $sr->id,"route_name" => $sr->route_name, "via" => $sr->via,  "status" => $status,"created_date" => $sr->created_date,"created_by" => $cr[0]->first_name.'  '. $cr[0]->last_name,"stationname" => $sr->station,"timename" => $sr->start_time,"vehiclename" => $vhcl[0]->vehicle_number,"session" => $sess);
            array_push($ments_dta, $data);
        }

    }
echo json_encode($ments_dta);

    }
    ///////////////////////////////////////////////	
    function save_vehicle(){
 $validation =  \Config\Services::validation();

		 $classesValidation=( [
 'vno' =>[
				'label'=>' Vehicle Number',
				'rules'=>'required|is_unique[vehicles_list_tbl.vehicle_number]',
				'errors'=>[
					'required'=>'Vehicle Name Can Not Be Empty',
					'is_unique'=>'The Vehicle Number Exist'

				],
			],
		]);
// 		 if($this->validate($classesValidation)){
    	$data = [
            'vehicle_number' => $this->request->getPost('vno'),
            'vehicle_model' => $this->request->getPost('vmodel'),
            'capacity' => $this->request->getPost('capacity'),
            'driver_name' => ucfirst($this->request->getPost('drname')),
           'driver_contact' => $this->request->getPost('drcontact'),
            'status' =>$this->request->getPost('status'),
            'created_by' => $_SESSION['user_id']
            
            
        ];
        // print_r($data);
        // return;

       $this->transport->add_vehicle($data);
       echo '<div class="alert alert-success">Saved Successful!</div>';
//   }else{
//   	echo '<div class="alert alert-danger">Not Saved, Vehicle Already Exit!</div>';
//   }
    }
    function load_vehicleList(){
     $builder = $this->db->table('vehicles_list_tbl ');
    $builder->select('*');
    $result = $builder->get()->getResult();
	
    $ments_dta = array();
   
    if(count($result) > 0){
		
        foreach ($result as $sr)
        {
		$st=$sr->status;
        	if($st==1){
        		$status='<span style="color:green">Active</span>';
        	}else{
        	$status='<span style="color:red">Inactive</span>';	
        	}
        	$cr=$this->transport->search_createdby($sr->created_by);

            $data = array("id" => $sr->id,"vehicle_number" => $sr->vehicle_number, "vehicle_model" => $sr->vehicle_model,"driver_name" => $sr->driver_name,"capacity" => $sr->capacity,"driver_contact" => $sr->driver_contact,
			"status" => $status,"created_date" => $sr->created_date,"created_by" => $cr[0]->first_name.' '.$cr[0]->last_name);
            array_push($ments_dta, $data);
        }

    }
echo json_encode($ments_dta);
	
    }
 function save_route_vehicle(){
 	$stime=$this->request->getPost('strtVal');
 	$etime=$this->request->getPost('fnshVal');
 	$checkExit=$this->transport->check_vehicle_route($this->request->getPost('vname'),$this->request->getPost('rname'),date('H:i:s', $stime),date('H:i:s', $etime));
 	 	if(count($checkExit)>0){
 		$n=0;
 		foreach($checkExit as $check){
 		if(strtotime($check->start_time)<=strtotime($stime)&&
            strtotime($check->end_time)>=strtotime($stime)){
 	
       $n++;
 	}
   }
 	if($n>0){
  echo '<div class="alert alert-warning">Vehicle Already assigned that route within that time!</div>';
 	}else{
 	$data = [
            'vehicle_id' => $this->request->getPost('vname'),
            'start_time' => $this->request->getPost('strtVal'),
            'route_id' => $this->request->getPost('rname'),
            'end_time' => $this->request->getPost('fnshVal'),
            'created_by' => $_SESSION['user_id']
         ];

       $this->transport->add_vehicle_route($data);
       echo '<div class="alert alert-success">Saved Successful!</div>';	
 	}

 }else{
 	$data = [
            'vehicle_id' => $this->request->getPost('vname'),
            'start_time' => $this->request->getPost('strtVal'),
            'route_id' => $this->request->getPost('rname'),
            'end_time' => $this->request->getPost('fnshVal'),
            'created_by' => $_SESSION['user_id']
         ];

       $this->transport->add_vehicle_route($data);
       echo '<div class="alert alert-success">Saved Successful!</div>';
    }
    }
    ////////////////////////////////////////////////////////////////////////
    function load_vehicleRouteList(){
    $builder = $this->db->table('station_tbl');
    $builder->select('station_tbl.id,station_tbl.station_name,station_tbl.status,station_tbl.created_by,station_tbl.created_date');
    //$builder->join('route_tbl','route_tbl.id=station_tbl.route');
   $result = $builder->get()->getResult();
	
    $ments_dta = array();
   
    if(count($result) > 0){
		
        foreach ($result as $sr)
        {
		if($sr->status==1){
			$st='<span style="color:green">Active</span>';
		}else{
		$st='<span style="color:red">Inactive</span>';
		}

	 $builder = $this->db->table('users');
    $builder->select('*');
    $builder->where('user_id',$sr->created_by);
    $resulted = $builder->get()->getResult();

            $data = array("id" => $sr->id,"station_name" => $sr->station_name, "status" =>  $st,"created_date" => $sr->created_date,"created_by" => $resulted[0]->first_name.' '.$resulted[0]->last_name);
            array_push($ments_dta, $data);
        }

    }
echo json_encode($ments_dta);

    }
     function view_Route(){
    $id=$this->request->getGet('id');
    $data['route']=$this->transport->fetch_route_data($id);
    echo view('transport/view_route',$data);
     }
   function edit_Route(){
   	$id=$this->request->getGet('id');
   	$builder = $this->db->table('route_tbl ');
    $builder->select('*');
    $builder->where('id',$id);
    $result = $builder->get()->getResult();
   	//echo $id;

   	$builder = $this->db->table('vehicles_list_tbl ');
    $builder->select('*');
    $builder->where('id',$result[0]->vehicle);
    $results = $builder->get()->getResult();

   	if(count($result) > 0){
   		if($result[0]->status==1){
          $status="Active";
          $sid=1;
   		}else{
   			$status="Inactive";
   			$sid=2;
   		}
   		//****sesion select***//
   		if($result[0]->route_session==1){
          $sess="Morning";
          $sessid=1;
   		}
   		elseif($result[0]->route_session==2){
          $sess="Afternoon";
          $sessid=2;
   		}
   		elseif($result[0]->route_session==3){
          $sess="Evening";
          $sessid=3;
   		}
   		else{
   		$sess=0;
          $sessid=0;
   		}
		echo '<table>
                        <tr>
                        <th class="box-title" style="padding-right:5px;"><i class=""></i></th>
						<th style="padding-right:7px;"><h5>Edit Route </h5></th>
                           
                        </tr>
                     </table>						
                    </div>
					
					
                    <div class="box-body" id="modu">
                        <table class="table table-bordered" id="myTable">
                            <tr>
                                <td>Route Name</td>
                              <td>
                              <input type="hidden" name="id" id="id" class="form-control" value="'.$result[0]->id.'">
                              <input type="text" name="rname" id="rname" class="form-control" value="'.$result[0]->route_name.'"></td></tr>
                              <tr>
                              <td>Via</td>
                              <td><input type="text" name="evia" value="'.$result[0]->via.'" id="via" class="form-control"></td>                                  
                            </tr>
                            <tr>
                              <td>Session</td>
                              <td><select name="name_sess" class="form-select form-control">
                              <option value="'.$sessid.'" selected>'.$sess.'</option>
                              <option value="1"
                                >Morning</option>
                                    <option value="2" 
                                >Afternoon</option>
                                 <option value="3" 
                                >Evening</option>
                               </select>
                               </td>                                  
                            </tr>
                            <tr>
                              <td>Starting Station</td>
                              <td><input type="text" name="station2" value="'.$result[0]->station.'" id="" class="form-control"></td>                                  
                            </tr>
                            <tr>
                              <td>Start time</td>
                              <td><input type="time" name="start_time_e" value="'.$result[0]->start_time.'" id="start_time" class="form-control"></td>                                  
                            </tr>
                      <tr>
                              <td>Vehicle</td>
                              <td><select name="vehicle_e" id="vehicle_e" class="form-select form-control">
                               <option value="">--choose--</option>';
                             $vehicles= $this->amodel->get_student_details('vehicles_list_tbl', $where = array('id >' => 0,));  
							foreach ($vehicles as $vh) {
							$selected = ($vh->vehicle_number == $results[0]->vehicle_number) ? 'selected' : '';
							echo '<option value="' . $vh->id . '" ' . $selected . '>' . $vh->vehicle_number . '</option>';
							}
                               echo '</select>
                            </td>                                  
                            </tr>
                             <tr>
                              <td>Status</td>
                              <td><select name="statu" class="form-select form-control">
                              <option value="'.$sid.'" selected>'.$status.'</option>
                              <option value="1"
                                >Active</option>
                                    <option value="2" 
                                >Inactive</option>
                               </select>
                              </td>                                  
                            </tr>
                        <tr><td></td>
                            <td><input type="button" onClick="editRoute_btn()" name="route-btn" class="form-control btn btn-primary btn-sm" value="edit"></td>
                            <td></td></tr>
                        </table>';
                         //maybe useful
                        // <tr>
                        //         <td>Fare</td>
                        //         <td><input type="number" id="fare" value="'.$result[0]->fare.'" name="efare" class="form-control"></td>
                        //     </tr>
		
      
}

}
function save_edit_Route(){
      
              $data = [
            'route_name' => ucfirst($this->request->getPost('rname')),
            'via' => ucfirst($this->request->getPost('via')),
            'station' => $this->request->getPost('station'),
            'start_time' => $this->request->getPost('start_time'),
            'status' =>  $this->request->getPost('status'),
            'route_session' =>  $this->request->getPost('sess'),
            'vehicle'=>  $this->request->getPost('vehicle_name'),
            'created_date' =>  date('Y-m-d H:i:s'),
            'created_by' => $_SESSION['user_id']
           ];

       $this->transport->edit_route($data,$this->request->getPost('rid'));
       echo '<div class="alert alert-success">Updated Successful!</div>';	
}

function deleteroute($id){
$this->transport->delete_route($id);
}
function edit_Vehicle(){
   	$id=$this->request->getGet('id');
   	$builder = $this->db->table('vehicles_list_tbl ');
    $builder->select('*');
    $builder->where('id',$id);
    $result = $builder->get()->getResult();
   	//echo $id;
   	if(count($result) > 0){
   		if($result[0]->status==1){
          $status="Active";
          $sid=1;
   		}else{
   			$status="Inactive";
   			$sid=2;
   		}
		echo ' 
                    <table>
                        <tr>
                        <th class="box-title" style="padding-right:5px;"><i class=""></i></th>
						<th style="padding-right:7px;"><h5>Edit Vehicle </h5></th>
                           
                        </tr>
                     </table>
		          <table class="table table-bordered" id="myTable">
		          <tr>
                                <td>Vehicle Name</td>
                                <td><input type="text" id="drcontact" value="'.$result[0]->driver_contact.'" required="required" name="edrcontact" class="form-control"></td>
                            </tr>
                            <tr>
                                <td>Vehicle No:</td>
                              <td>
                             <input type="hidden" name="eid" required="required" value="'.$result[0]->id.'" id="vno" placeholder="T-234-AAA" class="form-control">
                              <input type="text" name="evno" required="required" value="'.$result[0]->vehicle_number.'" id="vno" placeholder="T-234-AAA" class="form-control"></td>
                            </tr>
                            <tr>
                                <td>Vehicle Model</td>
                                <td><input type="text" id="vmodel" value="'.$result[0]->vehicle_model.'" required="required" name="evmodel" class="form-control"></td>
                            </tr>
                            <tr>
                                <td>Capacity</td>
                                <td><input type="text" id="vcapacity" value="'.$result[0]->capacity.'" required="required" name="vcapa" class="form-control"></td>
                            </tr>';
                            $builder = $this->db->table('users');
							$builder->select('*');
								$builder->where('users.user_type', 4);
								$query = $builder->get()->getResult();
				echo "<tr><td>Driver Name</td><td><select class='form-select form-control'   name='edrname' id='drname' >
               ";

                 foreach($query as $qr)  {
                 	if($qr->user_id==$result[0]->driver_name){
                  echo "<option selected='selected' value=$qr->user_id>$qr->first_name $qr->last_name</option>";
              }else{
              	 echo "<option value=$qr->user_id>$qr->first_name $qr->last_name</option>";
                    } 
              }

                echo "</select></td>"; 
                            echo '
                          
                            <tr>
                              <td>Status</td>
                              <td><select name="statv">
                              <option value="'.$sid.'" selected>'.$status.'</option>
                              <option value="1"
                                >Active</option>
                                    <option value="2" 
                                >Inactive</option>
                               </select>
                              </td>                                  
                            </tr>
                        <tr><td></td>
                            <td><input type="button" required="required" onClick="vehicle_editbtn()"  class="form-control btn btn-primary" value="edit"></td></tr>
                        </table>';
		
      
}

}
function save_edit_Vehicle(){
	$data = [
            'vehicle_number' => $this->request->getPost('vno'),
            'vehicle_model' => $this->request->getPost('vmodel'),
            'capacity' => $this->request->getPost('capacity'),
            'driver_name' => ucfirst($this->request->getPost('drname')),
            'driver_contact' => $this->request->getPost('drcontact'),
            'status' => $this->request->getPost('status'),
            'created_by' => $_SESSION['user_id']
            
            
        ];

       $this->transport->edit_vehicle($data,$this->request->getPost('id'));
       echo '<div class="alert alert-success">Updated Successful!</div>';	
}
function delete_vehicle($id){
$this->transport->delete_vehicle($id);	
}
function edit_RouteVehicle(){
$id=$this->request->getGet('id');
   
//$data=$this->transport->singleVehicleRoute($id);
$data=array(
       'dta'=>$this->transport->singleVehicleRoute($id)
);
echo view('transport/edit_route_Vehicle',$data); 
  	
}
function view_RouteVehicle(){
$id=$this->request->getGet('id');
   
//$data=$this->transport->singleVehicleRoute($id);
$data=array(
       'dta'=>$this->transport->singleVehicleRoute($id)
);
echo view('transport/view_station',$data); 
  	
}
function edit_RouteVehicleData(){
  $data = [
            'vehicle_id' => $this->request->getPost('vname'),
            'start_time' => $this->request->getPost('strtVal'),
            'route_id' => $this->request->getPost('rname'),
            'end_time' => $this->request->getPost('fnshVal'),
            'created_by' => $_SESSION['user_id']
         ];

       $update=$this->transport->edit_vehicle_route($data,$this->request->getPost('id'));
       if($update){
       echo '<div class="alert alert-success">Updated Successful!</div>';
}else{
 echo '<div class="alert alert-danger">Failed to update Successful!</div>';	
}
}

// function deleteRouteVehicle($id){
// 	$this->transport->delete_RouteVehicle($id);
// }

 public function deleteRouteVehicle($id = null)
    {
      $builder = $this->db->table('station_tbl');
        $builder->where('id',$id);
        $builder->delete();

        $builder = $this->db->table('station_session_tbl');
        $builder->where('station_id',$id);
        $builder->delete();

         $builder = $this->db->table('station_charged_items_tbl');
        $builder->where('station_id',$id);
        $builder->delete();
    } 
  public function transport_setup()
    {
        return view('templates/header')
        .view('transport/transport_setup')
        .view('templates/footer');   
    }

     public function manage_transport_setup()
    {
        $id = $this->request->getVar('id');
        $data['student_dtl'] = $this->amodel->get_student_details('students', $where = array('id' => $id, 'transport_status' =>0));
    //print_r($data['student_dtl']);
        $data['studentparent'] = $this->amodel->get_student_details('parents_students_tbl', $where = array('student_id' => $id));

        echo view('transport/manage_transport_setup',$data);
    }
      public function get_item_selected()
    {
    	 	$item_id =  $this->request->getPost('item');
	        $qty =  $this->request->getPost('quantity');
        $data = [
            'station_id' =>0,
            'item_id' => $this->request->getPost('item'),
            'quantity' => $this->request->getPost('quantity'),
            'account_receivable' => 0
        ];

        $this->transport->Save_Stationcharged_items($data);

    }

     // public function get_item_selected(){
     	
	// 	$item_id =  $this->request->getPost('item');
	// 	$qty =  $this->request->getPost('quantity');
		
	// 	$builder = $this->db->table("items_tbl");


	// 		$builder->select('id,item_name,item_price,item_group,item_attribute,item_size');
	// 		$builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
	// 		$builder->where('items_tbl.id',$item_id);
	// 		$query = $builder->get();
	// 		$item_result = $query->getResult();
		
     //    $item_data = array();
	// 	if(count($item_result) > 0){
           
	// 		foreach($item_result as $dt){
     //              //$tprice=$qty*$dt->item_price;

	// 			$item = array("id" => $dt->id,"iprice" => $dt->item_price,"qty" => $qty, "iname" => $dt->item_name,
	// 				"isize"=>$dt->item_size,"iattribute"=>$dt->item_attribute,"item_group"=>$dt->item_group
	// 			);
	// 			array_push($item_data, $item);
	// 		}
	// 	}
	// 	echo json_encode($item_data);
     // }
       public function createStation()
    {
          
     
            $s_exist = $this->transport->check_ifExist('station_tbl', $where = array('station_name' => $this->request->getPost('stationname')));
            if($s_exist){
                 echo json_encode(array('status' =>'1','statusDesc' => 'Station Name: <b>'.$s_exist[0]->station_name.'</b> With the <b>ID:'.$s_exist[0]->id.'</b> Already Exists.'));
            }
            else{
                //$s_name=ucwords(strtolower($this->request->getPost('stationname')));
                $data = [
                    'station_name' => ucwords(strtolower($this->request->getPost('stationname'))),
                    'route' => 0,
                    'created_by' => $_SESSION['user_id'],
                    'status' => 1,
                    'created_date' => date('Y/m/d H:i:s')
                ];

                $stationID = $this->transport->saveNew_station($data);

                if(!($stationID == false)){
                   
                    $sdata = json_decode($this->request->getPost('sessions'));
                    //$idata = json_decode($this->request->getPost('installment'));

                    // print_r($sdata);
                    if(!empty($sdata)){

                        foreach ((array)$sdata as $s) {
                            $se = array('station_id' => $stationID,'route_id'=>$s->routeid, 'session_name' => $s->session, 'session_time' => $s->time,'status'=>1, 'created_by' => $_SESSION['user_id'], 'created_date' => date('Y/m/d H:i:s'));

                            $sess = $this->transport->saveSessionData($se);
                        }
                    }

                    $ss = $this->request->getPost('id');
                         $i=0;
                    if(!empty($ss)){
                        foreach ($ss as $c) {

                            $itemData = array('item_id' => $c, 'station_id' => $stationID, 'account_receivable' => $this->request->getPost('account') ,'quantity' => $this->request->getPost('qty['.$i.']'));

                            $this->transport->Save_Station_items($itemData,$c);
                         $i++;
                         }
                    }
                }
                
                 echo json_encode(array('status' =>'0','statusDesc' => 'New Station Created Successful'));
             }

           
    }

     public function getting_station_chargeddItems()
    {
        $item_group=$this->request->getGet('item_group');
        $builder = $this->db->table('station_charged_items_tbl');
        $builder->select('quantity,account_receivable,item_name,item_attribute,item_size,item_group,item_id,station_charged_items_tbl.id,station_id');
        $builder->join('items_tbl', 'items_tbl.id = station_charged_items_tbl.item_id');
         $builder->where('station_charged_items_tbl.station_id',$this->request->getGet('station_id'));
        if($item_group!=11){
        $builder->where('item_group',$item_group);
        }
   
        $s_result = $builder->get()->getResult();

        $s_data = array();

        if(count($s_result) > 0){

            $iprice = "";
            foreach ($s_result as $cr)
            {
                $datas = $this->transport->get_ChargedItems_list($cr->item_id);
                foreach ($datas as $dts) {
                    $iprice = $dts->item_price;
                }

                $data = array("id" => $cr->id,"item_id" => $cr->item_id, "qty" => $cr->quantity, "name" => $cr->item_name, "size" => $cr->item_size, "attribute" => $cr->item_attribute, "item_group" => $cr->item_group, "price" => $iprice, "account" => $cr->account_receivable);
                array_push($s_data, $data);
            }

            echo json_encode($s_data);
        }else{
            echo "1";
        }
    }
    public function update_session_details()
    {
        $data = [
            'id' => $this->request->getPost('id'),
            'station_name' => $this->request->getPost('sname'),
            'status' => $this->request->getPost('status'),
            'created_by' => $session->get('user_id'),
            'created_date' => date('Y/m/d H:i:s')
        ];

        $this->transport->updating_session_data($this->request->getPost('id'),$data);
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
            <span class="glyphicon glyphicon-ok"></span> station Updated.</div> ';
    }
    public function getting_station_data()
    {
    	$sess=$this->request->getGet('sess_group');
        $builder = $this->db->table('station_session_tbl');
        $builder->select('station_tbl.station_name,station_session_tbl.session_name,station_session_tbl.session_time');
        $builder->join('station_tbl','station_tbl.id=station_session_tbl.station_id');
        $builder->where('route_id',$this->request->getGet('route_id'));
        if($sess!=0){
         $builder->where('station_session_tbl.session_name',$sess);	
        }
        $query = $builder->get()->getResult();

        $stream_dta = array();

        if(count($query) > 0){
            foreach ($query as $sr)
            {

 $data = array("station_name" => $sr->station_name,"session_name" => $sr->session_name, "time" => $sr->session_time);
                array_push($stream_dta, $data);
            }

            echo json_encode($stream_dta);
        }
    }

    function save_transport_details(){
            $session = session();
    	$pno = $this->generate_trans_pno();
    	 $transNo = $this->generate_transaction_no();
            $data = $this->request->getRawInput()['trans_data'];
        $receivableData = json_decode($data);
        $total= 0;
        $ledgerId = '';
        $i=0;
        if(count($receivableData) ==0){
            echo json_encode(array('status' =>2,'statusDesc' => 'Transport Not Created Successful.')); 
          return;  
        }
        foreach ($receivableData as $rd) {
            if (isset($rd->sid)) {
         $studentid=$rd->sid;
         $transport_type=$rd->transport_type;
    	  $data = [
                    'student_id' => $rd->sid,
                    'permit_id' => $pno,
                    'transport_trip' => $rd->trip,
                    'pickup_station' =>$rd->pick,
                    'pickup_session' => $rd->session_pick,
                    'drop_station' => $rd->drop,
                    'drop_session' => $rd->session_drop,
                    'start_date' =>$rd->start,
                    'end_date' => $rd->end,
                    'month' => $rd->tmonth,
                    'trans_numb' => $transNo,
                    'date_created' => date('Y/m/d H:i:s'),
                    'created_by' =>$session->get('user_id'),
                    'status ' => 3,
                    'transport_type ' => $transport_type
                   
                ];
            }}

                $data2 = [
                    'transport_status' => 1
                ];
              $this->amodel->SaveDetails('transport_details',$data);
            $this->smodel->update_table_details('students',$where = array('student_id' => $this->request->getPost('student_id')),$data2);
               $this->save_transport_transaction_items($studentid,$transNo); 
    }

 public function generate_trans_pno()
    {
        $ino = "";
        $tkens = $this->smodel->get_max_id('transport_details','permit_id');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }

  public function save_transport_transaction_items($student_id,$transNo){
      	 $session = session();
       
   //$pno = $this->generate_trans_pno();
            $data = $this->request->getRawInput()['trans_data'];
        $receivableData = json_decode($data);
        $total= 0;
        $ledgerId = '';
        $i=0;
        $desc="Transport fee";
        // print_r($receivableData);
        // return;
        foreach ($receivableData as $rd) {
            if(isset($rd->djoin)){
         $djoin=$rd->djoin;
            $transport_type=$rd->transport_type;
         if($transport_type !=""){
         	 $t_details=$this->smodel->gettable_data('transport_type_tbl',$where = array('id' => $transport_type));
         	 $desc=$t_details[0]->type_name;

         }
         
        }}
        $admnTransaction = [
                'trans_type_id' => 1,
                'trans_number' => $transNo,
                'trans_date' => $djoin,
                'updated_by' =>$this->request->getPost('header_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
        $this->smodel->SaveData('transaction_numbers_tbl',$admnTransaction);
        //print_r($admnTransaction);

        $total_cost = 0;
        $invoice_type = [
             'trans_no' => $transNo,
             'transaction_type_id' => 1,
             'invoice_type_id' => 4
         ];
        $itm_trans = $this->smodel->SaveData_n_get_id('invoice_type_transaction',$invoice_type); 
           //print_r($invoice_type);

         $itype ="";
         $amountttl = 0;
         $qtys = 0;
         $id="";
        
        //for account receivables
        $data = $this->request->getRawInput()['trans_data'];
        $receivableData = json_decode($data);
        $total= 0;
        $ledgerId = '';
        $i=0;
        foreach ($receivableData as $rd) {
            $i++;
            $c=$rd->iid;
            $p='prco'.$c;
            $q='quantity'.$c;
             if($rd->$p==0){
              continue;
             }else{

//////////////////////////////////////////////////////////////////////////////////////
             	$c=$rd->iid;
             	 $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c));
            foreach($itm as $i){
                $itype = $i->item_type;
            }
            $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $transNo,'trans_type' => 1, 'quantity' => $rd->$q, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $rd->$p/$rd->$q);

            $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);
         //print_r($itemData);
            $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
            $total_cost+=$rd->$p;
          
          $amount=0;
          $transactions=0;
            foreach($leger_items as $lg){
                $amount=$rd->$p;
                 $total += $amount;
                $transactions+=$amount;
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                
                $ledger = [
                     'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $c,
                     'trans_no' => $transNo,
                     'trans_type' => 1,
                     'amount' =>$amount,
                     'transation_nature' => 1,
                     'name_type_id' => 1,
                     'name_id' => $student_id,
                ];
               $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 
               // print_r($ledger);
            }
////////////////////////////////////////////////////////////////////////////////////             	
           
            $ledgerId = $rd->account;
        }
        }
        if($ledgerId>0){

        }else{
        	$ledgerId=16;
        }
        $ac_ledger = [
            'ledger_id' => $ledgerId,
            'ledger_type' => 7,
            'trans_no' => $transNo,
            'trans_type' => 1,
            'amount' => $total,
            'transation_nature' => 2,
            'name_type_id' => 1,
            'name_id' => $student_id,
            'balance' => $total,
        ];   
        $trans=$this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger); 
        //print_r($ac_ledger);
        
        // if($trans=1){
        // 	echo '1';
        // }else{
        // 	echo '0';
        // }
      //  $desc='Transport fee';
        // echo json_encode(array('status' =>1,'statusDesc' => 'Transport Created Successful.'));
         $db_id=$this->request->getPost('db_id');
         //if($db_id==1){
             
        $this->createControl_number_crdb($total,$student_id,$transNo,$desc);
    //   //  echo json_encode(array('status' =>1,'statusDesc' => 'Transport Created Successful.'));   
    //      }else{
    //       echo json_encode(array('status' =>1,'statusDesc' => 'Transport Created Successful.'));   
    //      }
    }

    public function generate_transaction_no()
    {
        $ino = "";
        $tkens = $this->smodel->get_max_invoice('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
    public function transport_dashboard(){
    	  return view('templates/header')
            .view('student/transport_dash_view')
            .view('templates/footer');
    }

     public function load_route_session()
    {

        $sesid = $this->request->getVar('sess');
        $lor = $this->amodel->get_student_details('route_tbl', $where = array('route_session' => $sesid,'status' => 1));

        if(count($lor) > 0){
            $select_route = array();
            foreach ($lor as $cl) {
             if($cl->route_session==1){
        		$sess='Morning';
        	}
        	elseif($cl->route_session==2){
        		$sess='Afternoon';
        	}
        	elseif($cl->route_session==3){
        		$sess='Evening';
        	}

                $select_route []=array('id' => $cl->id, 'rname' => $cl->route_name.' ('.$sess.')');
               
            }
            echo json_encode($select_route);
        }
    }

    public function transport_detail_view($pid){
    	
    	 $data['student_dtl'] = $this->transport->get_transport_permit($pid);
         $data['id']=$pid;
        echo view('transport/transport_detail_view',$data);
    }
  public function transport_detail_edit($pid){
    	
    	 $data['student_dtl'] = $this->transport->get_transport_permit($pid);
         $data['id']=$pid;
        echo view('transport/transport_detail_edit',$data);
    }

     function Edit_transport_details(){
            $session = session();
    	//$pno = $this->generate_trans_pno();
    	 //$transNo = $this->generate_transaction_no();
            $data = $this->request->getRawInput()['trans_data'];
        $receivableData = json_decode($data);
      //  print_r($receivableData);
        $total= 0;
        $ledgerId = '';
        $i=0;
        $desc="Usafiri";
        foreach ($receivableData as $rd) {
         $studentid=$rd->sid;
         $transNo=$rd->trno;
         $permit_id=$rd->pid;
         $transport_type=$rd->transport_type;
         if($transport_type !=""){
         	 $t_details=$this->smodel->gettable_data('transport_type_tbl',$where = array('id' => $transport_type));
         	 $desc=$t_details[0]->type_name;

         }
         
      if(property_exists($receivableData[0], 'pick')){
         if($rd->picknew!=""){
         $pick=$rd->picknew;
         $sesspick=$rd->session_picknew;
         }elseif($rd->pick!=""){
         	$pick=$rd->pick;
         	$sesspick=$rd->session_pick;
         }else{
         	$pick=0;
         	$sesspick=0;
         }
       }else{
       	$pick=0;
        $sesspick=0;
       }

if(property_exists($receivableData[0], 'drop')){
         if($rd->dropnew!=""){
         $drop=$rd->dropnew;
         $sessdrop=$rd->session_dropnew;
         }elseif($rd->drop!=""){
         	$drop=$rd->drop;
         	$sessdrop=$rd->session_drop;
         }else{
         	$drop=0;
         	$sessdrop=0;
         }
     }else{
     	$drop=0;
         $sessdrop=0;
     }
    	  $data = [
                    'student_id' => $rd->sid,
                    'permit_id' => $rd->pid,
                    'transport_trip' => $rd->trip,
                    'pickup_station' =>$pick,
                    'pickup_session' => $sesspick,
                    'drop_station' => $drop,
                    'drop_session' => $sessdrop,
                    'start_date' =>$rd->start,
                    'end_date' => $rd->end,
                    'month' => $rd->tmonth,
                     'transport_type' => $transport_type,
                   'created_by' =>$this->request->getPost('header_id'),
                 ];
            }

                $data2 = [
                    'transport_status' => 1
                ];
//print_r($data);
              //$this->amodel->SaveDetails('transport_details',$data);
       $this->smodel->update_table_details('transport_details',$where = array('permit_id' =>$permit_id),$data);
       
        //msg edit added here##################################
       $itm = $this->smodel->gettable_data('transport_details',$where = array('permit_id' => $permit_id));
       $control=$this->smodel->gettable_data('payment_request',$where = array('trans_no' => $itm[0]->trans_numb,'trans_type'=>1));
       $reference=$control[0]->reference_no??0;
        $ledger=$this->smodel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $itm[0]->trans_numb,'trans_type'=>1,'transation_nature'=>2));
        $total_cost=$ledger[0]->amount;
        $student_details=$this->smodel->gettable_data('students',$where = array('id' => $itm[0]->student_id));

       $msg = "Kumb No: ".$reference.", Kiasi:TZS ".number_format($total_cost).", Mwanafunzi: ".$student_details[0]->full_name.". ".
                 $desc;
              $bill = $this->smodel->gettable_billingdata($itm[0]->student_id);
        
        $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname.Usafiri.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 1,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>session()->get('user_id'),
                    'messagex' => $messagex,
                    'trans_number' => $itm[0]->trans_numb
                  
                );
      
      if(session()->get('user_id')==1){
 $this->smodel->SaveData('message_groups_tbl',$smsdata);

      $this->SMSsender($bill[0]->phone1,$msg,1,$itm[0]->student_id,$snn,NULL);
      }
//msg edit added here##################################
       echo '1';
         //       $this->edit_transport_transaction_items($studentid,$transNo); 
    }

    public function edit_transport_transaction_items($student_id,$transNo){
      	 $session = session();
       
   //$pno = $this->generate_trans_pno();
            $data = $this->request->getRawInput()['trans_data'];
        $receivableData = json_decode($data);
        $total= 0;
        $ledgerId = '';
        $i=0;
        foreach ($receivableData as $rd) {
         $djoin=$rd->djoin;
        }
        $admnTransaction = [
                'trans_type_id' => 1,
                'trans_number' => $transNo,
                'trans_date' => $djoin,
                'updated_by' =>$this->request->getPost('header_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
        //$this->smodel->SaveData('transaction_numbers_tbl',$admnTransaction);
         $this->smodel->update_table_details('transaction_numbers_tbl',$where = array('trans_type_id' =>1,'trans_number' =>$transNo),$admnTransaction);
        //print_r($admnTransaction);

        $total_cost = 0;
        // $invoice_type = [
        //      'trans_no' => $transNo,
        //      'transaction_type_id' => 1,
        //      'invoice_type_id' => 4
        //  ];
        // $itm_trans = $this->smodel->SaveData_n_get_id('invoice_type_transaction',$invoice_type); 
        //    //print_r($invoice_type);

         $itype ="";
         $amountttl = 0;
         $qtys = 0;
         $id="";
        
        //for account receivables
        $data = $this->request->getRawInput()['trans_data'];
        $receivableData = json_decode($data);
        $total= 0;
        $ledgerId = '';
        $i=0;
        foreach ($receivableData as $rd) {
            $i++;
            $c=$rd->iid;
            $p='prco'.$c;
            $q='quantity'.$c;
             if($rd->$p==0){
              continue;
             }else{

//////////////////////////////////////////////////////////////////////////////////////
             	$c=$rd->iid;
             	 $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c));
            foreach($itm as $i){
                $itype = $i->item_type;
            }
            $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $transNo,'trans_type' => 1, 'quantity' => $rd->$q, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $rd->$p);

           // $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);
             $this->smodel->update_table_details('item_transation_tbl',$where = array('trans_type' =>1,'trans_number' =>$transNo),$itemData);
         //print_r($itemData);
            $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
            $total_cost+=$rd->$p;
          
          $amount=0;
          $transactions=0;
            foreach($leger_items as $lg){
                $amount=$rd->$p;
                $transactions+=$amount;
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                    continue;
                }
                $ledger = [
                     'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $c,
                     'trans_no' => $transNo,
                     'trans_type' => 1,
                     'amount' =>$amount,
                     'transation_nature' => 1,
                     'name_type_id' => 1,
                     'name_id' => $student_id,
                ];
               // $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 
                $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('trans_type' =>1,'trans_no' =>$transNo,'transation_nature'=>1,'name_id'=>$student_id),$ledger);
                //print_r($ledger);
            }
////////////////////////////////////////////////////////////////////////////////////             	
            $total += $rd->$p;
            $ledgerId = $rd->account;
        }
        }

        $ac_ledger = [
            'ledger_id' => $ledgerId,
            'ledger_type' => 7,
            'trans_no' => $transNo,
            'trans_type' => 1,
            'amount' => $total,
            'transation_nature' => 2,
            'name_type_id' => 1,
            'name_id' => $student_id,
            'balance' => $total,
        ];   
       // $trans=$this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger); 
        $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('trans_type' =>1,'trans_no' =>$transNo,'transation_nature'=>2,'name_id'=>$student_id),$ac_ledger);
    
        echo '1';
        //print_r($ac_ledger);
        
      
    }


    function createControl_number_crdb($total_cost,$student_id,$transNo,$des){
         $student_details = $this->smodel->gettable_data('students',$where = array('id' => $student_id));
         
       //  $des=$desc.' : '.$total_cost.' and Bank charges : '.$charge;
         $db_id=$this->request->getPost('db_id');
         //////////////////////////////////////////////////////////
                  $db='default';
          $bank_requirements = $this->payment_model->get_item_name('payments_requirements_tbl',$where = array('db_id' => $db_id, 'status'=>1),$db);  
          if(count($bank_requirements)>0){
            $charge=$bank_requirements[0]->charges;
            
           $curl=base_url().''.$bank_requirements[0]->invoice_callbackUrl;
         

         $facility_id=$bank_requirements[0]->facility_id;
         $payment_type=$bank_requirements[0]->payment_type;
         $prefix=$bank_requirements[0]->prefix;
         $crdb_url=CRDB_URL_1;
         $desc=$des.' : '.$total_cost.' and Bank charges : '.$charge;

          }else{
              echo json_encode(array('status' =>1,'statusDesc' => 'Transport Created Successful.'));
              return;
          }
         /////////////////////////////////////////////////////
        
          $data=array(
             'name' =>$student_details[0]->full_name,
            'receipt_no' => $transNo,
            'amount' => $total_cost+$charge,
            'currency' => 'TZS',
            'payment_desc' => $desc,
            'visit_no'=>$student_id,
            'file_no'=>$student_id,
            'payment_channel' => 1,
            'facility_id' => $facility_id,
            'payment_type' => $payment_type,
            'prefix' =>$prefix,
            'call_back_url' => $curl,
           'allow_partial' => 'FIXED'

        );
          //print_r(json_encode($data));

    $url = CRDB_URL_1."createPayment";
   // $url='http://41.220.137.109:8000/api/createPayment';
     $ch = curl_init();
              curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2); // Use TLS 1.2 (recommended)
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));

                $response = curl_exec($ch);
                //echo $response;
                  file_put_contents('Apifeedback/req_crdb_transport' . $transNo. '.txt', json_encode($data));
                $err = curl_error($ch); 
                curl_close($ch);

                 if ($err) {
                    echo "Error #:" . $err;
                    $status = 5;
                    $reference=0;
                     $time=date('Y-m-d H:i:s');
                } else {
                   
                    $obj2 = json_decode($response,TRUE);
                    if($obj2['status']=='success'){
                      $status = 1;
                    }else{
                       $status = 2;
                    }
                    $time=$obj2['date_created'];
                    
                    $reference= $obj2['paymentReference'];
                }

                 $crdb_data = array(
                    'trans_no' =>  $transNo,
                    'student_id' =>  $student_id,
                    'reference_no' => $reference,
                    'amount' => $total_cost,
                    'charges' => $charge,
                    'paid_charges' => 0,
                    'payment_status' => 0,
                    'payment_channel' => 3, //CRDB
                    'date_created' => $time,
                    'allow_partial' => 0,
                    'trans_type' => 1
                 );
            //print_r($crdb_data);
                $this->amodel->SaveDetails('payment_request',$crdb_data);
             $ttl=$charge +$total_cost;
            $msg = "Kumb No: ".$reference.", Tarehe: ".$time.", Kiasi:TZS ".number_format($total_cost).", Mwanafunzi: ".$student_details[0]->full_name.". ".
                 $desc;
   //************************invoice msg setup*************************************//
         $bill = $this->smodel->gettable_billingdata($student_id);
        
        $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname.Usafiri.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 1,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>session()->get('user_id'),
                    'messagex' => $messagex,
                    'trans_number' => $transNo
                  
                );
      
 $this->smodel->SaveData('message_groups_tbl',$smsdata);

      $this->SMSsender($bill[0]->phone1,$msg,1,$student_id,$snn,NULL);
     //   ($dest,$msg,$type,$ref_no,$snn,$show_response=0)
       
        //**end msg invoice setup**********************************// 
        $student_name=$student_details[0]->full_name;
        echo json_encode(array('status' =>1,'statusDesc' => 'Student '.$student_name.' Control Number <b>'.$reference.'</b> Created Successful.'));
    }
    
     function generate_msg_no() {
        $ino = "";
        $tkens = $this->smodel->get_max_id('message_groups_tbl','send_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
    
       function SMSsender($dest,$msg,$type,$ref_no,$snn,$show_response=0) {
           $tmsg = $this->smodel->gettable_data('message_status_tbl',$where = array('status' => 1,));
                  if(count($tmsg)==0){
                   return;   
                  }
             $messag = $this->sytm_model->load_messages_balances();

            $time_sent = time();
              $senderid=constant('SENDER_ID_' . session()->get('db_id'));
                 if($senderid){
              $username=SMS_UNAME;
             $password=SMS_PASSWORD;
                 }else{
                     return;
                 }
                 
        //      if(session()->get('db_id')==1){
        //     $username=SMS_UNAME;
        //      $password=SMS_PASSWORD;
        //      $senderid=SENDER_ID;
        //  }elseif(session()->get('db_id')==4){
        //   $username=SMS_UNAME_USA;
        //      $password=SMS_PASSWORD_USA;
        //      $senderid=SENDER_ID_USA;  
        //  }elseif(session()->get('db_id')==5){
        //   $username=SMS_UNAME_AFYA;
        //      $password=SMS_PASSWORD_AFYA;
        //      $senderid=SENDER_ID_AFYA;  
        //  }
        //  else{
        //     return;
        //  }
             $destination=str_replace('-', '', $dest);
             $message=urlencode($msg);
             $senderid = urlencode($senderid);
          $fetch=file_get_contents("https://www.sms.co.tz/api.php?do=sms&username={$username}&password={$password}&senderid={$senderid}&dest={$destination}&msg={$message}");
           
            list($status, $note, $smsid) = explode(',', $fetch);
            if($show_response == 2){
              echo '<th>Message status:</th>';
              echo '<td><i>' . $note . '</i></td>';
            }
            if ($status == 'OK') {
                $msgid = $smsid;
                $snt_status = 1;    // Message sent successfully
                $cost = 45;
                $acc_cost = $cost;
                if($type!=5){
               // echo 'Message sent successfully';
                  }  
            } else {
                $msgid = '';
                $snt_status = 2;    // Message just sent 
                $cost = 45;
                $acc_cost = $cost;
            }
             $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
            
            $this->smodel->SaveData('messages',$tempsmsdata);
          //  echo 'msg saved';

            $balance = ($messag[0]->balance - $acc_cost);

           $smsDt = array(
                'balance' => $balance,
                'created_at' => date('Y/m/d H:i:s')
            );
            $this->sytm_model->update_sms_balance($smsDt, $messag[0]->b_id);

          //  curl_close($curl);
     // echo 'successful sent';
    }
    
    function SMSsender2($dest,$msg,$type,$ref_no,$snn,$show_response=0,$dbid) {
        $tmsg=constant('TMSG' . $dbid);
                  if($tmsg==0){
                   return;   
                  }
                  
                   $senderid=constant('SENDER_ID_' . $dbid);
                 
                 if($senderid){
              $username=SMS_UNAME;
             $password=SMS_PASSWORD;
                 }else{
                     return;
                 }
         
          
         if($dbid==1){
          $db=DB1;
           $username=SMS_UNAME;
            $password=SMS_PASSWORD;
            $senderid=SENDER_ID;
         }elseif($dbid==4){
          $db=DB4;
          $username=SMS_UNAME_USA;
         $password=SMS_PASSWORD_USA;
         $senderid=SENDER_ID_USA; 
         }
             $messag = $this->payment_model->load_messages_balances($db);

             $time_sent = time();
             $destination=str_replace('-', '', $dest);
             $message=urlencode($msg);
             $senderid = urlencode($senderid);
          $fetch=file_get_contents("https://www.sms.co.tz/api.php?do=sms&username={$username}&password={$password}&senderid={$senderid}&dest={$destination}&msg={$message}");
           
            list($status, $note, $smsid) = explode(',', $fetch);
            if($show_response == 2){
              echo '<th>Message status:</th>';
              echo '<td><i>' . $note . '</i></td>';
            }
            if ($status == 'OK') {
                $msgid = $smsid;
                $snt_status = 1;    // Message sent successfully
                $cost = 45;
                $acc_cost = $cost;
                if($type!=2){
                echo 'Message sent successfully';
                  }  
            } else {
                $msgid = '';
                $snt_status = 2;    // Message just sent 
                $cost = 45;
                $acc_cost = $cost;
            }

            
                $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
            
               
            $this->payment_model->SaveData('messages',$tempsmsdata,$db);
          //  echo 'msg saved';

            $balance = ($messag[0]->balance - $acc_cost);

          $smsDt = array(
                'balance' => $balance,
                'created_at' => date('Y/m/d H:i:s')
            );
            $this->payment_model->update_sms_balance($smsDt, $messag[0]->b_id,$db);

          //  curl_close($curl);
     // echo 'successful sent';
    }

function generate_msg_no_2($db) {
        $ino = "";
        $tkens = $this->payment_model->get_max_id('message_groups_tbl','send_number',$db);
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }


function manage_transport_messages($id){
     if($id==1){
      $dbn=DB1;
    }elseif($id==4){
       $dbn=DB4;
    }
 $dates=$this->payment_model->get_item_name('transport_details', $where = array('status' => 1),$dbn);
 foreach($dates as $dts){
 	$date1 = date('Y-m-d');
    $date2 = $dts->end_date;

    // Convert the dates to Unix timestamps
$timestamp1 = strtotime($date1);
$timestamp2 = strtotime($date2);

// Calculate the difference in seconds
$difference = $timestamp2 - $timestamp1;

// Convert the difference to days
$days_difference = floor($difference / (60 * 60 * 24));
if($days_difference >=0){
$st_name=$this->payment_model->get_item_name('students', $where = array('id' => $dts->student_id),$dbn);
	if($days_difference==3){
	     

	  $msg = $st_name[0]->first_name.', Tunakukumbusha usafiri wako utaishia tar '.date('d/m/Y', $timestamp2).'. Kibali namba '.$dts->permit_id.' cha tar '.date('d/m/Y',strtotime($dts->start_date)).'. Wasiliana na shule kwaajili ya kulipia tena.';

   //***invoice *************************************//
         $bill = $this->payment_model->gettable_billingdata($dts->student_id,$dbn);
        
        $messagex="#first_name, Tunakukumbusha usafiri wako utaishia tar xx/xx/xxxx. Kibali namba xxxx cha tar xx/xx/xxxx. Wasiliana na shule kwaajili ya kulipia tena.";
     $snn = $this->generate_msg_no_2($dbn);
      $smsdata = array(
                    'send_type' => 2,
                    'message_type' => 7,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>10,
                    'messagex' => $messagex,
                    'trans_number' =>  $dts->trans_numb
                  
                );
      
 $this->payment_model->SaveData('message_groups_tbl',$smsdata,$dbn);

      $this->SMSsender2($bill[0]->phone1,$msg,7,$dts->student_id,$snn,NULL,$id);
   
	}elseif($days_difference==0){

     $msg = $st_name[0]->first_name.', Kibali cha usafiri na '.$dts->permit_id.' cha tar '.date('d/m/Y',strtotime($dts->start_date)).' kimeisha leo. Kama ungependa kuendelea na huduma hii na bado hujafanya hivyo, piga 0755266243.';

   //***invoice *************************************//
         $bill = $this->payment_model->gettable_billingdata($dts->student_id,$dbn);
        
        $messagex="#firstname, Kibali cha usafiri na. xxxx cha tar dd/mm/yy kimeisha leo. Kama ungependa kuendelea na huduma hii na bado hujafanya hivyo, piga xxxx-xxx-xxx.";
     $snn = $this->generate_msg_no_2($dbn);
      $smsdata = array(
                    'send_type' => 2,
                    'message_type' => 7,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>10,
                    'messagex' => $messagex,
                    'trans_number' =>  $dts->trans_numb
                  
                );
      
 $this->payment_model->SaveData('message_groups_tbl',$smsdata,$dbn);

      $this->SMSsender2($bill[0]->phone1,$msg,7,$dts->student_id,$snn,NULL,$id);
      
	}

}else{
$Dt = array(
    'status' => 2,
        );
   $this->payment_model->update_table_details('transport_details',$where = array('id' => $dts->id),$Dt,$dbn);	
}

 }
}

function fetch_transports($start,$end){
            $thedate=$this->request->getPost('thedate');
            $expire_date=$this->request->getPost('expire');
            $trans_type=$this->request->getPost('trans_type');
            $status=$this->request->getPost('status');
            //echo $thedate;
             list($startingdate, $endingdate) = explode('-', $thedate);
             list($startingex, $endingex) = explode('-', $expire_date);
             $enddate = strtotime($endingdate. '23:59:59');
            $sdate = strtotime($startingdate);
             $endex = strtotime($endingex. '23:59:59');
            $sex = strtotime($startingex);
            
            $adm=$this->transport->gettable_dataT(
               	date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate),
               	date('Y-m-d H:i', $sex), date('Y-m-d H:i', $endex),
               	$trans_type,$status);
           
            // $data = array(
            //    'admission' => $this->transport->gettable_dataT(
            //    	date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate),
            //    	date('Y-m-d H:i', $sex), date('Y-m-d H:i', $endex),
            //    	$trans_type,$status)
            //     );
         // echo count($jk);
           // return;
         
         $sn = $start;
         $max=$end;
         $allData=count($adm);
         //$allData=5;
         if(count($adm)>0){
     // foreach ($admission as $adm){
         	for($i=$sn;$i<=$max;$i++){
            $sn++;
            if($i==$allData){
            	break;
            }
            if($adm[$i]->transport_trip==1){
                $trip='One Way';
            }else{
               $trip='Round Trip';  
            }

            $today=date('Y-m-d');
            $start=$adm[$i]->start_date;
            $end=$adm[$i]->end_date;
            if(strtotime($start) > strtotime($today)){
                $ex=1;
            }elseif(strtotime($start) <= strtotime($today) && strtotime($today) <= strtotime($end)){
                 $ex=2;
            }else{
                $ex=3;
            }
         if($adm[$i]->status==1 && $ex==1){
                $status='Paid';
                $color='blue';
            }elseif($adm[$i]->status==2){
               $status='Expired';  
               $color='red';  
            }
            elseif($adm[$i]->status==3){
               $status='Pending';  
               $color=' #d35400';  
            }elseif($adm[$i]->status==1 && $ex==2){
               $status='Active';  
               $color='green';  
            }elseif($adm[$i]->status==1 && $ex==3){
               $status='Expired';  
               $color='red';  
            }
            $std = $this->amodel->get_student_details('students', $where = array('id' => $adm[$i]->student_id));
             $stadm = $this->amodel->get_student_details('admission_tbl', $where = array('student_id' => $adm[$i]->student_id));
            $room = $this->amodel->get_student_details('classes_tbl', $where = array('id' => $stadm[0]->class_id));
         
            $user = $this->amodel->get_student_details('users', $where = array('user_id' => $adm[$i]->created_by));
            $full_name=$std[0]->first_name.' '.$std[0]->middle_name.' '.$std[0]->last_name;

            echo "<tr><input type='hidden' value='".$allData."' id='counted".$i."'>";
            echo "<td>".$adm[$i]->permit_id."</td>";
            echo "<td>".$adm[$i]->start_date."</td>";
            echo "<td>".$trip."</td>";
            echo "<td>".$full_name."</td>";
            echo "<td>".findAge($std[0]->birth_date)."</td>";
            echo "<td>".$room[0]->class_name."</td>";
            echo "<td>".($adm[$i]->month *30)."</td>";
            echo "<td>".$adm[$i]->end_date."</td>";
            echo "<td style='color:".$color."'>".$status."</td>";
            echo "<td>
             <button type='button' class='btn btn-primary btn-sm editTrans' onclick='editTrans(".$adm[$i]->permit_id.")'><i class='fa fa-edit'></i> Edit</button>
           <button type='button' class='btn btn-primary btn-sm viewTrans' onclick='viewTrans(". $adm[$i]->permit_id.")'><i class='fa fa-eye'></i> View</button>
            </td>";
            echo "</tr>";

          }
          // echo "<td></td>";
         }
          // echo view('transport/transport_list_filter',$data);

        }

        function fetch_transport_byname(){

        	 $name=$this->request->getPost('name');
        	 $year=$this->request->getPost('year');
        	
             $admission = $this->transport->fetch_transport_byname(
               	$name,$year);
              // 	print_r($admission);
             $sn=0;
               foreach ($admission as $adm){
        $sn++;
        if($adm->transport_trip==1){
            $trip='One Way';
        }else{
           $trip='Round Trip';  
        }

        $today=date('Y-m-d');
        $start=$adm->start_date;
        $end=$adm->end_date;
        if(strtotime($start) > strtotime($today)){
            $ex=1;
        }elseif(strtotime($start) <= strtotime($today) && strtotime($today) <= strtotime($end)){
             $ex=2;
        }else{
            $ex=3;
        }
     if($adm->status==1 && $ex==1){
            $status='Paid';
            $color='blue';
        }elseif($adm->status==2){
           $status='Expired';  
           $color='red';  
        }
        elseif($adm->status==3){
           $status='Pending';  
           $color=' #d35400';  
        }elseif($adm->status==1 && $ex==2){
           $status='Active';  
           $color='green';  
        }elseif($adm->status==1 && $ex==3){
           $status='Expired';  
           $color='red';  
        }
        $std = $this->amodel->get_student_details('students', $where = array('id' => $adm->student_id));
         $stadm = $this->amodel->get_student_details('admission_tbl', $where = array('student_id' => $adm->student_id));
        $room = $this->amodel->get_student_details('classes_tbl', $where = array('id' => $stadm[0]->class_id));
     
        $user = $this->amodel->get_student_details('users', $where = array('user_id' => $adm->created_by));
         $full_name=$std[0]->first_name.' '.$std[0]->middle_name.' '.$std[0]->last_name;
        echo "<tr>";
            echo "<td>".$adm->permit_id."</td>";
            echo "<td>".$adm->start_date."</td>";
            echo "<td>".$trip."</td>";
            echo "<td>".$full_name."</td>";
            echo "<td>".findAge($std[0]->birth_date)."</td>";
            echo "<td>".$room[0]->class_name."</td>";
            echo "<td>".($adm->month *30)."</td>";
            echo "<td>".$adm->end_date."</td>";
            echo "<td style='color:".$color."'>".$status."</td>";
            echo "<td>
          <button type='button' class='btn btn-primary btn-sm editTrans' onclick='editTrans(".$adm->permit_id.")'><i class='fa fa-edit'></i> Edit</button>
           <button type='button' class='btn btn-primary btn-sm viewTrans' onclick='viewTrans(". $adm->permit_id.")'><i class='fa fa-eye'></i> View</button>
            </td>";
            echo "</tr>";

        }

        }
        
         function transport_type(){
         	$data=array(
			'fetch'=>$this->amodel->get_student_details('transport_type_tbl', $where = array('id >' =>0))
			
		);
		return view('templates/header')
		.view('transport/transport_type',$data)
		.view('templates/footer');
 }

 function add_transport_type(){
      
    $validation =  \Config\Services::validation();

		 $cValidation=( [
			'type_name' =>[
				'label'=>' Transport Type Name',
				'rules'=>'required',
				'errors'=>[
					'required'=>'Transport Type Can Not Be Empty',
					'is_unique'=>'The Transport Type Exist'

				],
			],
				]

	);
		if($this->validate($cValidation)){
			$data = [
				'type_name' => $this->request->getPost('type_name'),
				'created_by' =>$_SESSION['user_id'],
				'created_date' => date('Y-m-d H:i:s')
			];
			 $this->amodel->SaveDetails('transport_type_tbl',$data);
			 echo 1;

 }
}

function transport_type_details(){
	$id=$this->request->getPost('id');
	$fetch=$this->amodel->get_student_details('transport_type_tbl', $where = array('id' =>$id));
	
	echo '
        <form class="card-body form-horizontal"  id="EditTransportType" method="post" >
            <div id="fdbk" class="text-success"></div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label">Transport Type<span class="text-danger">*</span></label>
                    <div class="col-md-8">
                        <input type="text" id="type_name" class="form-control" name="type_name"required="required" value="'.$fetch[0]->type_name.'">
                        <input type="hidden" name="id" value="'.$fetch[0]->id.'">
                    
                    </div>
                </div>
               
                     <div class="form-group row">
                            <label class="col-md-3 col-form-label"></label>
                            <div class="col-md-8">
                               
                                <button type="button" onclick="update_name()" class="btn btn-primary float-right">Update</button>
                            </div>
                        </div>
                    </form>
	                ';

}

 function update_transport_type(){
      
    $validation =  \Config\Services::validation();

		 $cValidation=( [
			'type_name' =>[
				'label'=>' Transport Type Name',
				'rules'=>'required',
				'errors'=>[
					'required'=>'Transport Type Can Not Be Empty',
					'is_unique'=>'The Transport Type Exist'

				],
			],
				]

	);
		if($this->validate($cValidation)){
			$data = [
				'type_name' => $this->request->getPost('type_name'),
				'created_by' =>$_SESSION['user_id'],
				'created_date' => date('Y-m-d H:i:s')
			];
			// print_r($data);
			// return;
			 $this->smodel->update_table_details('transport_type_tbl',$where = array('id' => $this->request->getPost('id')),$data);
			 echo 1;

 }
}

 function overdue_transport(){
        	 return view('templates/header')
            .view('transport/overdue_transport_dash')
            .view('templates/footer');
        }

       function vehicle_overdue($vid){
    $data=array(
           'vid'=>$vid,
         );
    return view('transport/overdue_transport_view',$data); 
     }

      function overdue_details(){
       $type=$this->request->getPost('type');
        $data=array(
  
            'type'=>$type,
            'vid'=>$this->request->getPost('vid')
        );
        //print_r($data);
        echo view('transport/vehicle_overdue_details',$data); 
     }

     function total_overdue_transport(){
     	helper('overdue');
       echo number_format(transport_overdue());
     }

     function request_overdue_transport_delete(){
        $selected = $this->request->getPost('trans_numbers');

        if(empty($selected) || !is_array($selected)){
            return $this->response->setJSON([
                'status' => 0,
                'statusDesc' => 'Please select at least one transport invoice.'
            ]);
        }

        $requested = [];
        $skipped = [];
        $userId = session()->get('user_id');

        foreach (array_unique($selected) as $transNo) {
            $transNo = trim((string) $transNo);
            if ($transNo === '') {
                continue;
            }

            $transportRows = $this->db->table('transport_details')
                ->where('trans_numb', $transNo)
                ->get()
                ->getResult();

            if (count($transportRows) === 0) {
                $skipped[] = $transNo . ' not found';
                continue;
            }

            $eligible = false;
            $permitIds = [];
            foreach ($transportRows as $row) {
                $permitIds[] = $row->permit_id;
                $days = floor((time() - strtotime($row->date_created)) / (60 * 60 * 24));
                if ((int) $row->status === 3 && $days > 30) {
                    $eligible = true;
                }
            }

            if (! $eligible) {
                $skipped[] = $transNo . ' is no longer overdue';
                continue;
            }

            $invoice = $this->db->table('transaction_numbers_tbl')
                ->where('trans_number', $transNo)
                ->where('trans_type_id', 1)
                ->get()
                ->getRow();

            if (empty($invoice)) {
                $skipped[] = $transNo . ' invoice missing';
                continue;
            }

            $approvalRow = $this->db->table('approval_numbers')
                ->where('trans_no', $transNo)
                ->where('trans_type', 1)
                ->get()
                ->getRow();

            if ($approvalRow) {
                $appId = $approvalRow->app_id;
                $latestHistory = $this->db->table('approval_history')
                    ->where('app_no', $appId)
                    ->orderBy('hist_id', 'DESC')
                    ->get()
                    ->getRow();

                if ($latestHistory && (int) $latestHistory->hstatus === 3) {
                    $skipped[] = $transNo . ' already pending approval';
                    continue;
                }
            } else {
                $approvalData = [
                    'trans_type' => 1,
                    'trans_no' => $transNo,
                    'name' => $transportRows[0]->student_id,
                    'name_type' => 1,
                ];
                $this->db->table('approval_numbers')->insert($approvalData);
                $appId = $this->db->insertID();
            }

            $comment = 'Please approve deletion of overdue transport permit ' . implode(', ', array_unique($permitIds)) . ' and invoice ' . $transNo . '.';
            $history = [
                'app_no' => $appId,
                'user' => $userId,
                'user_role' => 1,
                'comment' => $comment,
                'hstatus' => 3,
                'hist_date' => date('Y-m-d H:i:s'),
            ];
            $this->db->table('approval_history')->insert($history);
            $requested[] = $transNo;
        }

        $message = count($requested) . ' transport request(s) sent for approval.';
        if (count($requested) === 0) {
            $message = 'No delete request submitted.';
        }
        if (! empty($skipped)) {
            $message .= ' Skipped: ' . implode('; ', $skipped) . '.';
        }

        return $this->response->setJSON([
            'status' => count($requested) > 0 ? 1 : 0,
            'statusDesc' => $message,
            'requested' => $requested,
            'skipped' => $skipped,
        ]);
     }
// end mark
}

  
?>
