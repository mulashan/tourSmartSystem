<?php
// By Chanangwa E.
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\UsersModel;
use App\Models\AcademicModel;
use App\Models\LoginModel;
use App\Models\StudentModel;
use App\Models\AcademicInputsModel;
use App\Models\ResultsModel;
use App\Models\ExamModel;
use App\Models\AcademicOutputsModel;
class AcademicOutputsController extends BaseController
{
    protected $academicModel;
    protected $studentModel;
    protected $academicInputsModel;
    protected $academicOutputsModel;
    protected $db;

    public function __construct()
    {
        $dbname = session()->get('db_name');
        $this->db = \Config\Database::connect($dbname);
        $this->academicModel = new AcademicModel();
        $this->studentModel = new StudentModel();
          $this->ExamModel = new ExamModel();
$this->academicInputsModel = new AcademicInputsModel();
$this->academicOutputsModel = new AcademicOutputsModel();
    }
  public function ViewGeneralReports(){
      $year= date("Y");
        $data['term'] = $this->academicInputsModel->current_terms($year);
        $data['exams'] = $this->academicInputsModel->list_exams();
    return view('templates/header')
            .view('academic_reports/general_reports_view',$data)
            .view('templates/footer');

    }
    public function FetchGeneralReports()
{
    helper('results_helper');
    $status = $this->request->getPost('status');
    $year = $this->request->getPost('year');
    $class = $this->request->getPost('class');
    $classlevel = $this->request->getPost('classlevel');
    $stream = $this->request->getPost('stream');
    $term = $this->request->getPost('terms');
    $start_date = $this->request->getPost('start_date');
    $end_date = $this->request->getPost('end_date');
    $exam_type_label = $this->request->getPost('exam_type_label');
    $exam_type_value = $this->request->getPost('exam_type_value');
    $goverment_level = $this->academicOutputsModel->get_governmennt_levels($classlevel);
    $data['classlevel']=$classlevel;
    $data['class']=$class;
    $data['stream']=$stream;
    $data['government_level'] =$goverment_level->government_level_id;

if(isset($goverment_level)){
    if($exam_type_value>0){
       if((in_array($goverment_level->government_level_id, [1, 2, 3]))){
        if($exam_type_value==2){
    $start_date = $year.'-01-01';
    $end_date = $year.'-06-30';
        $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        if(isset($monthly,$midterm) && !empty($monthly) && !empty($midterm)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}

    $data['exam_types_count']=2;
$data['results'] = array_values($combinedResults);

$data['results'] = array_values($combinedResults);
 
        }
             else{
                 $data['message']= 'First midterm exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }

    }
    else if($exam_type_value==5){
    $start_date = $year.'-07-01';
    $end_date = $year.'-11-30';
        $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        if(isset($monthly,$midterm) && !empty($monthly) && !empty($midterm)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}

    $data['exam_types_count']=2;
$data['results'] = array_values($combinedResults);

$data['results'] = array_values($combinedResults);
 
        }
             else{
    $data['message']= 'Second midterm  exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }

    }
    elseif($exam_type_value==3){
             $examtype=3;
  $start=$year.'-01-01';
    $end=$year.'-06-30';
     $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
    $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $terminal = $this->academicOutputsModel->GetExamMarksReport($classlevel,$class,$stream,$examtype,$start,$end,$year);
        if(isset($monthly,$midterm,$terminal) && !empty($monthly) && !empty($midterm) && !empty($terminal)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm, $terminal) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}$data['exam_types_count']=3;
$data['results'] = array_values($combinedResults);

        }else{
    $data['message']= 'Terminal exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }
    }  

        elseif($exam_type_value==4){
            $examtype=4;
            $start=$year.'-07-01';
    $end=$year.'-11-30';
        $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $annual = $this->academicOutputsModel->GetExamMarksReport($classlevel,$class,$stream,$examtype,$start,$end,$year);
if(isset($monthly,$midterm,$annual) && !empty($monthly) && !empty($midterm) && !empty($annual)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm, $annual) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}


$data['exam_types_count']=3;
$data['results'] = array_values($combinedResults);

        }
        else{
    $data['message']= 'Annual exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }

    }


    }elseif($goverment_level->government_level_id==4){
    
     if($exam_type_value==2){
$start=$year.'-07-01';
    $end=$year.'-11-30';
         $examtype=2;

        $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start,$end,$year);
        $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start,$end,$year);
         //         print_r($monthly);
         // return;
        if(isset($monthly,$midterm) && !empty($monthly) && !empty($midterm)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}

    $data['exam_types_count']=2;
$data['results'] = array_values($combinedResults);

$data['results'] = array_values($combinedResults);
 
        }
             else{
                $data['message']= 'First Midterm exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }
        }
     else if($exam_type_value==5){

    $start_date = 1+$year.'-01-01';
    $end_date = 1+$year.'-06-30';
   $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
       
    $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        if(isset($monthly,$midterm) && !empty($monthly) && !empty($midterm)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}

    $data['exam_types_count']=2;
$data['results'] = array_values($combinedResults);

$data['results'] = array_values($combinedResults);
 
        }
             else{
                $data['message']= 'Second midterm exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }

    }

        elseif($exam_type_value==3){


$start_date=$year.'-07-01';
    $end_date=$year.'-11-30';
                $examtype=3;
        $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $terminal = $this->academicOutputsModel->GetExamMarksReport($classlevel,$class,$stream,$examtype,$start_date,$end_date,$year);
        if(isset($monthly,$midterm,$terminal) && !empty($monthly) && !empty($midterm) && !empty($terminal)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm, $terminal) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}$data['exam_types_count']=3;
$data['results'] = array_values($combinedResults);

        }else{
   $data['message']= 'Terminal exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }
        }
elseif($exam_type_value==4){
     $start=1+$year.'-01-01';
    $end=1+$year.'-06-30';
    $examtype=4;
     $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start,$end,$year);
        $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start,$end,$year);
        $annual = $this->academicOutputsModel->GetExamMarksReport($classlevel,$class,$stream,$examtype,$start,$end,$year);
if(isset($monthly,$midterm,$annual) && !empty($monthly) && !empty($midterm) && !empty($annual)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm, $annual) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}


$data['exam_types_count']=3;
$data['results'] = array_values($combinedResults);

        }
        else{
$data['message']= 'Annual exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }
        }

    }
    else{
        
        

     $start=$year.'-01-01';
    $end=$year.'-01-01';   
    }

    }else{
        if($exam_type_value==0){
             if((in_array($goverment_level->government_level_id, [1, 2, 3]))){
                echo 'whole year. O level';

             }elseif($goverment_level->government_level_id==4){
    echo 'whole year. A level';
             }
        }
        else if($exam_type_value=='custom'){
            echo 'Custom';
        }
   
return;
    }

}


        $data['class']=$this->request->getPost('class');
        $data['stream']=$this->request->getPost('stream');
          $data['terms']=$this->request->getPost('terms');
            $data['examtypes']=$this->request->getPost('exam_type_value');

    $rawSubjects = $this->academicOutputsModel->GetSubjectsByStreamReport($class,$stream);
    $subjectsByComb = [];
    foreach ($rawSubjects as $row) {
        $comb = $row->comb;
        if (!isset($subjectsByComb[$comb])) {
            $subjectsByComb[$comb] = [
                'subjects' => [],
                'count' => 0,
                'comb' => $comb,
            ];
        }
        $alreadyExists = false;
        foreach ($subjectsByComb[$comb]['subjects'] as $s) {
            if ($s['subject_id'] == $row->subject_id) {
                $alreadyExists = true;
                break;
            }
        }
        if (!$alreadyExists) {
            $subjectsByComb[$comb]['subjects'][] = [
                'subject_id' => $row->subject_id,
                 'selection' => $row->selection,
                'subject_name' => $row->subject_name
            ];
            $subjectsByComb[$comb]['count']++;
        }
    }
    $data['subjectsByComb'] = $subjectsByComb;
    $data['exam_type_value'] =$exam_type_value;
    $data['exam_type_label'] =$exam_type_label;
    $data['row_stream_data'] =$rawSubjects;
    $data['gradeBoundaries'] = $this->academicOutputsModel->getGradeBoundaries($classlevel);
      $data['gradesTable'] = $this->academicOutputsModel->getGrades_forDivision($classlevel);
    $data['cl'] = $this->academicOutputsModel->FetchReports($class, $classlevel, $stream, $year, $status);
    echo view('academic_reports/forms/view_all_student', $data);
}

       public function view_student_report(){
        helper('results_helper');
   $year = $this->request->getPost('year');
   $id = $this->request->getPost('id');
   $student_id = $this->request->getPost('id');
     $sn = $this->request->getPost('sn');
     $stream = $this->request->getPost('stream');
     $pre_stream = $this->request->getPost('pre_stream');
     $combname = $this->request->getPost('combname');
     $class = $this->request->getPost('clas');
    $term = $this->request->getPost('terms');
    $examtype = $this->request->getPost('examtypes');
    $exam_type_value = $this->request->getPost('exam_type_value');
    $exam_type_label = $this->request->getPost('exam_type_label');
    $government_level = $this->request->getPost('government_level');
     $classlevel=$this->academicInputsModel->getClassLevelByClass($class);
     $data=[
        'classlevel'=> $classlevel,
        'class'=> $class,
        'stream'=> $stream
          ];
        if($examtype==2 || $examtype==5){
         $data['exams'] = $this->academicInputsModel->list_examsBy_midterm();
        }elseif($examtype==3){
         $data['exams'] = $this->academicInputsModel->list_examsBy_terminal();    
        }
        elseif($examtype==4){

         $data['exams'] = $this->academicInputsModel->list_examsBy_annual();    
        }else{
 $data['exams'] = $this->academicInputsModel->list_examsBy_range();
        }
$goverment_level = $this->academicOutputsModel->get_governmennt_levels($classlevel);
     $data['government_level']=$goverment_level->government_level_id;

if(isset($goverment_level)){
    if($exam_type_value>0){
    if((in_array($goverment_level->government_level_id, [1, 2, 3]))){
        if($exam_type_value==2){
    $start = $year.'-01-01';
    $end = $year.'-06-30';
    $examtype_id=[1,2];
    $data['results'] = $this->academicOutputsModel->StudentExamMarksReport($year,$term,$id,$examtype_id,$start,$end);
         
        }
        elseif($exam_type_value==3){
             $examtype=3;
  $start=$year.'-01-01';
    $end=$year.'-06-30';
            $data['results'] = $this->academicOutputsModel->StudentExamMarksReport($year,$term,$id,$examtype,$start,$end);
        }
            elseif($exam_type_value==5){
            $examtype=2;
            $start=$year.'-07-01';
    $end=$year.'-11-30';
    $data['results'] = $this->academicOutputsModel->StudentExamMarksReport($year,$term,$id,$examtype,$start,$end);
        }
            elseif($exam_type_value==4){
            $examtype=3;
            $start=$year.'-07-01';
    $end=$year.'-11-30';
    $data['results'] = $this->academicOutputsModel->StudentExamMarksReport($year,$term,$id,$examtype,$start,$end);
        }

    }elseif($goverment_level->government_level_id==4){
     if($exam_type_value==2){
$start=$year.'-07-01';
    $end=$year.'-11-30';
     $examtype_id=[1,2];
    $data['results'] = $this->academicOutputsModel->StudentExamMarksReport($year,$term,$id,$examtype,$start,$end);
        }
     elseif($exam_type_value==3){
$start=$year.'-07-01';
    $end=$year.'-11-30';
     $examtype=3;
            $data['results'] = $this->academicOutputsModel->StudentExamMarksReport($year,$term,$id,$examtype,$start,$end);
        }
        elseif($exam_type_value==4){
     $start=1+$year.'-01-01';
    $end=1+$year.'-06-30';
    $examtype=4;
            $data['results'] = $this->academicOutputsModel->StudentExamMarksReport($year,$term,$id,$examtype,$start,$end);
        }
     elseif($exam_type_value==5){
    $examtype=2;
    $start=1+$year.'-01-01';
    $end=1+$year.'-06-30';
    $data['results'] = $this->academicOutputsModel->StudentExamMarksReport($year,$term,$id,$examtype,$start,$end);
        }
        else{
            echo 'here message';
        }


    }
    else{
     $start=$year.'-01-01';
    $end=$year.'-01-01';   
    }
    }

}
$rawSubjects = $this->academicOutputsModel->GetSubjectsByStreamReport($class,$stream);
  $subjectsByComb = [];
    foreach ($rawSubjects as $row) {
        $comb = $row->comb;
        if (!isset($subjectsByComb[$comb])) {
            $subjectsByComb[$comb] = [
                'subjects' => [],
                'count' => 0,
                'comb' => $comb,
            ];
        }
        $alreadyExists = false;
        foreach ($subjectsByComb[$comb]['subjects'] as $s) {
            if ($s['subject_id'] == $row->subject_id) {
                $alreadyExists = true;
                break;
            }
        }
        if (!$alreadyExists) {
            $subjectsByComb[$comb]['subjects'][] = [
                'subject_id' => $row->subject_id,
                 'selection' => $row->selection,
                'subject_name' => $row->subject_name
            ];
            $subjectsByComb[$comb]['count']++;
        }
    }
    $data['subjectsByComb'] = $subjectsByComb;
     $data['characters']=$this->academicModel->GetAllcharacter();
     $data['sn']=$sn;
     $where=['character_results_tbl.student_id' => $id,
             'character_results_tbl.academic_yr'=>$year
              ];  
              // ===============================================version 2 report===========================

        // =====================================O- level and primary============================
    if((in_array($goverment_level->government_level_id, [1, 2, 3]))){
            $start_term1 = $year.'-01-01';
    $end_term1 = $year.'-06-30';
    $start_term2 = $year.'-07-01';
    $end_term2 = $year.'-12-30';
    $examtype_term1=[1, 2,3];
    $examtype_term2=[1, 2,4];
    $status=2;
    $students = $this->academicOutputsModel->FetchReports($class, $classlevel, $stream, $year, $status);
    $examtype=[1, 2,3,4];
    $student = $this->request->getPost('student');
$Mid1subjectAverages = $this->academicOutputsModel->getStudentSubjectAverages($year, $stream, $class, $examtype, $start_term1, $end_term1,$student);
$Mid2subjectAverages = $this->academicOutputsModel->getStudentSubjectAverages($year, $stream, $class, $examtype, $start_term2, $end_term2,$student);
$subject_position_term1 = $this->academicOutputsModel->getSubjectPositions($year, $stream, $class, $examtype, $start_term1, $end_term1);
$subject_position_term2 = $this->academicOutputsModel->getSubjectPositions($year, $stream, $class, $examtype, $start_term2, $end_term2);
$overallAverages_term1 = $this->academicOutputsModel->getStudentOverallAverages($year, $stream, $class, $examtype, $start_term1, $end_term1,$student);
$overallAverages_term2 = $this->academicOutputsModel->getStudentOverallAverages($year, $stream, $class, $examtype, $start_term2, $end_term2,$student);

usort($overallAverages_term1, fn($a, $b) => $b->overall_avg <=> $a->overall_avg);
foreach ($overallAverages_term1 as $rank => &$position_term1) {
    $position_term1->position = $rank + 1;
}
usort($overallAverages_term2, fn($a, $b) => $b->overall_avg <=> $a->overall_avg);
foreach ($overallAverages_term2 as $rank => &$position_term2) {
    $position_term2->position = $rank + 1;
}
// print_r($subject_position_term1);
// return;
 $data['overallAverages_term1']= $overallAverages_term1;
 $data['overallAverages_term2']= $overallAverages_term2;
 $data['students']= $students;
 $data['students_count']= $this->academicOutputsModel->getNumberStudents($year,$class);
 $data['Mid1subjectAverages']= $Mid1subjectAverages;
 $data['Mid2subjectAverages']= $Mid2subjectAverages;
 $data['subject_position_term1'] = $subject_position_term1;
 $data['subject_position_term2'] = $subject_position_term2;
 $data['start_date'] =$start_term1;
$data['end_date'] =$end_term2;


    }
    // =========================================A-level======================================
     elseif($goverment_level->government_level_id==4){
    $start_term1 = $year.'-07-01';
    $end_term1 = $year.'-12-30';
    $start_term2 = 1+$year.'-01-01';
    $end_term2 = 1+$year.'-06-30';
    $examtype_term1=[1, 2,3];
    $examtype_term2=[1, 2,4];
    $status=2;
    $students = $this->academicOutputsModel->FetchReports($class, $classlevel, $stream, $year, $status);
    $examtype=[1, 2,3,4];
    $student = $this->request->getPost('student');
$Mid1subjectAverages = $this->academicOutputsModel->getStudentSubjectAverages($year, $stream, $class, $examtype, $start_term1, $end_term1,$student);
$Mid2subjectAverages = $this->academicOutputsModel->getStudentSubjectAverages($year, $stream, $class, $examtype, $start_term2, $end_term2,$student);
$subject_position_term1 = $this->academicOutputsModel->getSubjectPositions($year, $stream, $class, $examtype, $start_term1, $end_term1);
$subject_position_term2 = $this->academicOutputsModel->getSubjectPositions($year, $stream, $class, $examtype, $start_term2, $end_term2);
$overallAverages_term1 = $this->academicOutputsModel->getStudentOverallAverages($year, $stream, $class, $examtype, $start_term1, $end_term1,$student);
$overallAverages_term2 = $this->academicOutputsModel->getStudentOverallAverages($year, $stream, $class, $examtype, $start_term2, $end_term2,$student);

usort($overallAverages_term1, fn($a, $b) => $b->overall_avg <=> $a->overall_avg);
foreach ($overallAverages_term1 as $rank => &$position_term1) {
    $position_term1->position = $rank + 1;
}
usort($overallAverages_term2, fn($a, $b) => $b->overall_avg <=> $a->overall_avg);
foreach ($overallAverages_term2 as $rank => &$position_term2) {
    $position_term2->position = $rank + 1;
}
 $data['overallAverages_term1']= $overallAverages_term1;
 $data['overallAverages_term2']= $overallAverages_term2;
 $data['students']= $students;
 $data['students_count']= $this->academicOutputsModel->getNumberStudents($year,$class);
 $data['Mid1subjectAverages']= $Mid1subjectAverages;
 $data['Mid2subjectAverages']= $Mid2subjectAverages;
 $data['subject_position_term1'] = $subject_position_term1;
 $data['subject_position_term2'] = $subject_position_term2;
 $data['start_date'] =$start_term1;
$data['end_date'] =$end_term2;

     }
              // ===============================================version 2 report===========================
$subjectPosition = $this->request->getPost('subject_position');
   $data['subject_position'] = is_array($subjectPosition) ? $subjectPosition : json_decode($subjectPosition, true);
   $data['year']=$this->request->getPost('year');
   $data['average']=$this->request->getPost('average');
   $data['TotalStudents']=$this->academicOutputsModel->getTotalStudents($year,$class,$pre_stream,$stream);
   $data['averageGrade']=$this->request->getPost('averageGrade');
   $data['totalmarks']=$this->request->getPost('totalmarks');
   $data['postion']=$this->request->getPost('postion');
   $data['combname']=$this->request->getPost('combname');
   $data['exam_type_label']=$this->request->getPost('exam_type_label');
   $data['gradeBoundaries'] = $this->academicOutputsModel->getGradeBoundaries($classlevel);
   $data['student']=$this->academicOutputsModel->StudentReport($id,$year);
   $data['classdata']=$this->academicOutputsModel->StudentSubjects($class,$stream);
   $data['char_report']=$this->academicOutputsModel->StudentCharacterResult($id,$year);
$data['exams_term1'] = $this->academicInputsModel->list_examsBy_term1();
 $data['exams_term2'] = $this->academicInputsModel->list_examsBy_term2();
  $data['student_data']=$this->academicOutputsModel->StudentReport($student_id,$year);
            echo view('academic_reports/forms/student_report',$data);  
}
         function fetch_search_byname(){
       $name=$this->request->getPost('name');
       $year=$this->request->getPost('year');
       $data['year']=$this->request->getPost('year');
       $data['time']=2;
            $data['cl']=$this->academicOutputsModel->student_search_byname($name,$year);
           echo view('academic_reports/forms/view_all_student',$data); 
         }


public function SubjectResultsDetailed(){
        $year= date("Y");
        $data['term'] = $this->academicInputsModel->current_terms($year);
        $data['exams'] = $this->academicInputsModel->list_exams();
    return view('templates/header')
            .view('academic_reports/subject_detailed_results_view',$data)
            .view('templates/footer');

}
public function FetchDetailedReports()
{
    helper('results_helper');
    $status = $this->request->getPost('status');
    $year = $this->request->getPost('year');
    $class = $this->request->getPost('class');
    $classlevel = $this->request->getPost('classlevel');
    $stream = $this->request->getPost('stream');
    $term = $this->request->getPost('terms');
    $examtype = $this->request->getPost('examtypes');
    $data = [
        'classlevel' => $classlevel,
        'terms' => $term,
        'examtype' => $examtype,
        'class' => $class,
        'stream' => $stream,
        'year' => $year,
        'time' => 1,
    ];
    $students = $this->academicOutputsModel->FetchReports($class, $classlevel, $stream, $year, $status);
    $data['cl'] = $students;
    $examResults = $this->academicOutputsModel->DetailedExamMarksReport($year);
    $data['groupedResults'] = $examResults;
    $characterResults = $this->academicOutputsModel->DetailedCharacterResult($year);
    $characterData = [];
    foreach ($characterResults as $char) {
        $characterData[$char->student_id][$char->character_id] = $char->grade_name;
    }
    $data['characterData'] = $characterData;
    $rawSubjects = $this->academicOutputsModel->GetSubjectsByStreamReport($class,$stream);
    $subjectsByComb = [];
    foreach ($rawSubjects as $row) {
        $comb = $row->comb;
        if (!isset($subjectsByComb[$comb])) {
            $subjectsByComb[$comb] = ['subjects' => [], 'count' => 0, 'comb' => $comb];
        }
        $exists = false;
        foreach ($subjectsByComb[$comb]['subjects'] as $s) {
            if ($s['subject_id'] == $row->subject_id) {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $subjectsByComb[$comb]['subjects'][] = [
                'subject_id' => $row->subject_id,
                'selection' => $row->selection,
                'subject_name' => $row->subject_name
            ];
            $subjectsByComb[$comb]['count']++;
        }
    }
    $rawSubjects = $this->academicOutputsModel->GetSubjectsByStreamReport($class, $stream); 

$subjectsByStream = [];
foreach ($rawSubjects as $row) {
    $streamId = $row->stream_id;
    if (!isset($subjectsByStream[$streamId])) {
        $subjectsByStream[$streamId] = [
            'subjects' => [],
            'comb' => $row->comb_name,
        ];
    }

    $subjectsByStream[$streamId]['subjects'][$row->subject_id] = $row->subject_name;
}

  $data['subjectsByStream'] = $subjectsByStream;
    $data['subjectsByComb'] = $subjectsByComb;
    $data['gradeBoundaries'] = $this->academicOutputsModel->getGradeBoundaries($classlevel);
    $data['gradesTable'] = $this->academicOutputsModel->getGrades_forDivision($classlevel);
    $data['character'] = $this->academicInputsModel->CharacterList();
    $examsType = $this->academicOutputsModel->getExamtypes();
    $data['exams_type'] = $examsType;
    $data['results'] = $examResults;
    echo view('academic_reports/forms/detailed_results', $data);
}


public function top_10_students(){
       $year= date("Y");
        $data['term'] = $this->academicInputsModel->current_terms($year);
        $data['exams'] = $this->academicInputsModel->list_exams();
    return view('templates/header')
            .view('academic_reports/top_10_students_view',$data)
            .view('templates/footer');
}
   public function FetchTop10Reports()
{
     helper('results_helper');
    $status = $this->request->getPost('status');
    $year = $this->request->getPost('year');
    $class = $this->request->getPost('class');
    $classlevel = $this->request->getPost('classlevel');
    $stream = $this->request->getPost('stream');
    $term = $this->request->getPost('terms');
    $examtype = $this->request->getPost('examtypes');
    $start_date = $this->request->getPost('start_date');
    $end_date = $this->request->getPost('end_date');
    $exam_type_label = $this->request->getPost('exam_type_label');
    $exam_type_value = $this->request->getPost('exam_type_value');
    $goverment_level = $this->academicOutputsModel->get_governmennt_levels($classlevel);
    $sata['classlevel']=$classlevel;
    $sata['class']=$class;
    $sata['stream']=$stream;
    $data['government_level'] =$goverment_level->government_level_id;
        $data['class']=$this->request->getPost('class');
        $data['stream']=$this->request->getPost('stream');
          $data['terms']=$this->request->getPost('terms');
            $data['examtypes']=$this->request->getPost('examtypes');
            $data['year']=$this->request->getPost('year');

if(isset($goverment_level)){
    if($exam_type_value>0){
    if((in_array($goverment_level->government_level_id, [1, 2, 3]))){
        if($exam_type_value==2){
    $start_date = $year.'-01-01';
    $end_date = $year.'-06-30';
        $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        if(isset($monthly,$midterm) && !empty($monthly) && !empty($midterm)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}

    $data['exam_types_count']=2;
$data['results'] = array_values($combinedResults);
  $data['exam_details'] = 'First midterm exaination results';
        }
             else{
                 $data['message']= 'First midterm exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }

    }
            else if($exam_type_value==5){
    $start_date = $year.'-07-01';
    $end_date = $year.'-11-30';
        $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        if(isset($monthly,$midterm) && !empty($monthly) && !empty($midterm)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}

    $data['exam_types_count']=2;
$data['results'] = array_values($combinedResults);
  $data['exam_details'] = 'Second midterm exaination results';
        }
             else{
    $data['message']= 'Second midterm  exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }

    }
    elseif($exam_type_value==3){
             $examtype=3;
  $start=$year.'-01-01';
    $end=$year.'-06-30';
     $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
    $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $terminal = $this->academicOutputsModel->GetExamMarksReport($classlevel,$class,$stream,$examtype,$start,$end,$year);
        if(isset($monthly,$midterm,$terminal) && !empty($monthly) && !empty($midterm) && !empty($terminal)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm, $terminal) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}$data['exam_types_count']=3;
$data['results'] = array_values($combinedResults);
 $data['exam_details'] = 'Terminal exaination results';
        }else{
    $data['message']= 'Terminal exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }
    }  

        elseif($exam_type_value==4){
            $examtype=4;
            $start=$year.'-07-01';
    $end=$year.'-11-30';
        $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $annual = $this->academicOutputsModel->GetExamMarksReport($classlevel,$class,$stream,$examtype,$start,$end,$year);
if(isset($monthly,$midterm,$annual) && !empty($monthly) && !empty($midterm) && !empty($annual)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm, $annual) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}


$data['exam_types_count']=3;
$data['results'] = array_values($combinedResults);
 $data['exam_details'] = 'Annual midterm exaination results';
        }
        else{
    $data['message']= 'Annual exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }

    }


    }elseif($goverment_level->government_level_id==4){
    
     if($exam_type_value==2){
$start=$year.'-07-01';
    $end=$year.'-11-30';
         $examtype=2;
        $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        if(isset($monthly,$midterm) && !empty($monthly) && !empty($midterm)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}

    $data['exam_types_count']=2;
$data['results'] = array_values($combinedResults);

$data['results'] = array_values($combinedResults);
 $data['exam_details'] = 'First Midterm exaination results';
        }
             else{
                $data['message']= 'First Midterm exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }
        }
     else if($exam_type_value==5){

    $start_date = 1+$year.'-01-01';
    $end_date = 1+$year.'-06-30';
   $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
       
    $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        if(isset($monthly,$midterm) && !empty($monthly) && !empty($midterm)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}

    $data['exam_types_count']=2;
$data['results'] = array_values($combinedResults);

$data['results'] = array_values($combinedResults);
 $data['exam_details'] = 'Second midterm exaination results';
        }
             else{
                $data['message']= 'Second midterm exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }

    }

        elseif($exam_type_value==3){


$start=$year.'-07-01';
    $end=$year.'-11-30';
                $examtype=3;
        $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year);
        $terminal = $this->academicOutputsModel->GetExamMarksReport($classlevel,$class,$stream,$examtype,$start,$end,$year);
        if(isset($monthly,$midterm,$terminal) && !empty($monthly) && !empty($midterm) && !empty($terminal)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm, $terminal) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}$data['exam_types_count']=3;
$data['results'] = array_values($combinedResults);
$data['exam_details'] = 'Terminal exaination results';
        }else{
   $data['message']= 'Terminal exaination results';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }
        }
elseif($exam_type_value==4){
     $start=1+$year.'-01-01';
    $end=1+$year.'-06-30';
    $examtype=4;
     $monthly = $this->academicOutputsModel->GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start,$end,$year);
        $midterm = $this->academicOutputsModel->GetExamMidterm_MarksReport($classlevel,$class,$stream,$start,$end,$year);
        $annual = $this->academicOutputsModel->GetExamMarksReport($classlevel,$class,$stream,$examtype,$start,$end,$year);
if(isset($monthly,$midterm,$annual) && !empty($monthly) && !empty($midterm) && !empty($annual)){
          $combinedResults = [];
foreach (array_merge($monthly, $midterm, $annual) as $r) {
    $key = $r->student_id . '_' . $r->subject_id;

    if (!isset($combinedResults[$key])) {
        $combinedResults[$key] = [
            'student_id' => $r->student_id,
            'subject_id' => $r->subject_id,
            'marks' => [],
            'grades' => [],
            'exam_types' => []
        ];
    }
    $combinedResults[$key]['marks'][] = $r->marks_scored;
    $combinedResults[$key]['grades'][] = $r->grade_name;

}


$data['exam_types_count']=3;
$data['results'] = array_values($combinedResults);
$data['exam_details'] = 'Annual exaination results';

        }
        else{
$data['message']= 'Annual exaination results not published';
  $data['results'] = [];
    $data['exam_types_count'] = 0;
        }
        }

    }
    else{

     $start=$year.'-01-01';
    $end=$year.'-01-01';   
    }
    }

}

        $data['class']=$this->request->getPost('class');
        $data['stream']=$this->request->getPost('stream');
          $data['terms']=$this->request->getPost('terms');
            $data['examtypes']=$this->request->getPost('exam_type_value');

    $rawSubjects = $this->academicOutputsModel->GetSubjectsByStreamReport($class,$stream);
    $subjectsByComb = [];
    foreach ($rawSubjects as $row) {
        $comb = $row->comb;
        if (!isset($subjectsByComb[$comb])) {
            $subjectsByComb[$comb] = [
                'subjects' => [],
                'count' => 0,
                'comb' => $comb,
            ];
        }
        $alreadyExists = false;
        foreach ($subjectsByComb[$comb]['subjects'] as $s) {
            if ($s['subject_id'] == $row->subject_id) {
                $alreadyExists = true;
                break;
            }
        }
        if (!$alreadyExists) {
            $subjectsByComb[$comb]['subjects'][] = [
                'subject_id' => $row->subject_id,
                 'selection' => $row->selection,
                'subject_name' => $row->subject_name
            ];
            $subjectsByComb[$comb]['count']++;
        }
    }
    $data['subjectsByComb'] = $subjectsByComb;
    $data['exam_type_value'] =$exam_type_value;
    $data['exam_type_label'] =$exam_type_label;
    $data['row_stream_data'] =$rawSubjects;
    $data['gradeBoundaries'] = $this->academicOutputsModel->getGradeBoundaries($classlevel);
      $data['gradesTable'] = $this->academicOutputsModel->getGrades_forDivision($classlevel);
    $data['cl'] = $this->academicOutputsModel->FetchReports($class, $classlevel, $stream, $year, $status);
    echo view('academic_reports/forms/top_10_tables', $data);

}
public function subject_performance(){
        $year= date("Y");
        $data['term'] = $this->academicInputsModel->current_terms($year);
        $data['exams'] = $this->academicInputsModel->list_exams();
    return view('templates/header')
            .view('academic_reports/subjects_performance_view',$data)
            .view('templates/footer');  
}
   public function SubjectWisePerformance()
{
    $status = $this->request->getPost('status');
    $year = $this->request->getPost('year');
    $class = $this->request->getPost('class');
    $classlevel = $this->request->getPost('classlevel');
    $stream = $this->request->getPost('stream');
    $term = $this->request->getPost('terms');
    $examtype = $this->request->getPost('examtypes');

    $data = [
        'classlevel' => $classlevel,
        'terms' => $term,
        'examtype' => $examtype,
        'class' => $class,
        'stream' => $stream,
        'year' => $year,
        'time' => 1,
    ];
        $data['class']=$this->request->getPost('class');
        $data['stream']=$this->request->getPost('stream');
          $data['terms']=$this->request->getPost('terms');
            $data['examtypes']=$this->request->getPost('examtypes');
            $data['year']=$this->request->getPost('year');
    $data['results'] = $this->academicOutputsModel->GetExamMarksReport($examtype,$term);
    $rawSubjects = $this->academicOutputsModel->GetSubjectsByStreamReport($class,$stream);
    $subjectsByComb = [];
    foreach ($rawSubjects as $row) {
        $comb = $row->comb;
        if (!isset($subjectsByComb[$comb])) {
            $subjectsByComb[$comb] = [
                'subjects' => [],
                'count' => 0,
                'comb' => $comb,
            ];
        }
        $alreadyExists = false;
        foreach ($subjectsByComb[$comb]['subjects'] as $s) {
            if ($s['subject_id'] == $row->subject_id) {
                $alreadyExists = true;
                break;
            }
        }
        if (!$alreadyExists) {
            $subjectsByComb[$comb]['subjects'][] = [
                'subject_id' => $row->subject_id,
                'subject_name' => $row->subject_name
            ];
            $subjectsByComb[$comb]['count']++;
        }
    }
    $data['subjectsByComb'] = $subjectsByComb;

    $data['gradeBoundaries'] = $this->academicOutputsModel->getGradeBoundaries($classlevel);
    $data['cl'] = $this->academicOutputsModel->FetchReports($class, $classlevel, $stream, $year, $status);
    echo view('academic_reports/forms/subject_performance_view', $data);

}
public function examtype_results(){
 $year= date("Y");
        $data['term'] = $this->academicInputsModel->current_terms($year);
        $data['exams'] = $this->academicInputsModel->list_exams();
    return view('templates/header')
            .view('academic_reports/exam_typresults_view',$data)
            .view('templates/footer');
}
 public function FetchExamTypeReports()
{
    $status = $this->request->getPost('status');
    $year = $this->request->getPost('year');
    $class = $this->request->getPost('class');
    $classlevel = $this->request->getPost('classlevel');
    $stream = $this->request->getPost('stream');
    $term = $this->request->getPost('terms');
    $examtype = $this->request->getPost('examtypes');
    $data = [
        'classlevel' => $classlevel,
        'terms' => $term,
        'examtype' => $examtype,
        'class' => $class,
        'stream' => $stream,
        'year' => $year,
        'time' => 1,
    ];
        $data['class']=$this->request->getPost('class');
        $data['stream']=$this->request->getPost('stream');
          $data['terms']=$this->request->getPost('terms');
            $data['examtypes']=$this->request->getPost('examtypes');
    $data['results'] = $this->academicOutputsModel->GetExamMarksReportByExamType($examtype,$term,$classlevel,$year,$class,$stream);
    $rawSubjects = $this->academicOutputsModel->GetSubjectsByStreamReport($class,$stream);
    $subjectsByComb = [];
    foreach ($rawSubjects as $row) {
        $comb = $row->comb;
        if (!isset($subjectsByComb[$comb])) {
            $subjectsByComb[$comb] = [
                'subjects' => [],
                'count' => 0,
                'comb' => $comb,
            ];
        }
        $alreadyExists = false;
        foreach ($subjectsByComb[$comb]['subjects'] as $s) {
            if ($s['subject_id'] == $row->subject_id) {
                $alreadyExists = true;
                break;
            }
        }
        if (!$alreadyExists) {
            $subjectsByComb[$comb]['subjects'][] = [
                'subject_id' => $row->subject_id,
                'subject_name' => $row->subject_name
            ];
            $subjectsByComb[$comb]['count']++;
        }
    }
    $data['subjectsByComb'] = $subjectsByComb;
    $data['gradeBoundaries'] = $this->academicOutputsModel->getGradeBoundaries($classlevel);
    $data['cl'] = $this->academicOutputsModel->FetchReports($class, $classlevel, $stream, $year, $status);
    echo view('academic_reports/forms/view_examtype_results', $data);
}
public function load_class($id = null){
             $data = $this->academicOutputsModel->GetClassList($id);
   echo $data->class_name.' ';
   
}
public function load_stream_data($id = null){
             $data = $this->academicOutputsModel->GetStreamList($id);
   echo ' - '.$data->stream_name.'  ' .' ( '.$data->comb_name.' )';
   
}
// ===============================================for students list==============================================
       public function student_academic_report(){
        helper('results_helper');
   $year = $this->request->getPost('year');
   $student = $this->request->getPost('student');
   $student_info=$this->academicOutputsModel->getStudentDetails($student,$year);
    $class = $student_info->class_id;
    $classlevel = $student_info->level_id;
    $stream = $student_info->stream_id;
    $pre_stream=0;
    $term=7;
    $examtype = $this->request->getPost('exam_type_value');
    $exam_type_value = $this->request->getPost('exam_type_value');
    $exam_type_label = $this->request->getPost('exam_type_label');

$goverment_level = $this->academicOutputsModel->get_governmennt_levels($classlevel);
$data['government_level']=$goverment_level->government_level_id;
 $data['exams_term1'] = $this->academicInputsModel->list_examsBy_term1();
 $data['exams_term2'] = $this->academicInputsModel->list_examsBy_term2();

if(isset($goverment_level)){
    if($exam_type_value>0){
    if((in_array($goverment_level->government_level_id, [1, 2, 3]))){
        if($exam_type_value==2){
    $start = $year.'-01-01';
    $end = $year.'-06-30';
    $data['start_date'] =$start;
    $data['end_date'] =$end;
    $examtype=[1, 2];
    $data['exams_count']=$examtype;
    $data['results_term1'] = $this->academicOutputsModel->StudentAcademicReport($year,$term,$student,$examtype,$start,$end);
         
        }
        elseif($exam_type_value==3){
             $examtype=3;
  $start=$year.'-01-01';
    $end=$year.'-06-30';
      $data['start_date'] =$start;
    $data['end_date'] =$end;
    $examtype=[1, 2,3];
            $data['results_term1'] = $this->academicOutputsModel->StudentAcademicReport($year,$term,$student,$examtype,$start,$end);
        }
            elseif($exam_type_value==5){
            $examtype=2;
            $start=$year.'-07-01';
    $end=$year.'-11-30';
      $data['start_date'] =$start;
    $data['end_date'] =$end;
    $data['results'] = $this->academicOutputsModel->StudentAcademicReport($year,$term,$student,$examtype,$start,$end);
        }
            elseif($exam_type_value==4){
            $examtype=3;
            $start=$year.'-07-01';
    $end=$year.'-11-30';
      $data['start_date'] =$start;
    $data['end_date'] =$end;
    $data['results'] = $this->academicOutputsModel->StudentAcademicReport($year,$term,$student,$examtype,$start,$end);
        }


    }elseif($goverment_level->government_level_id==4){
        // ===================================First Midterm for A-level (july 1 to december)===========================
     if($exam_type_value==2){
$start=$year.'-07-01';
    $end=$year.'-11-30';
      $data['start_date'] =$start;
    $data['end_date'] =$end;
     $examtype=2;
    $data['results'] = $this->academicOutputsModel->StudentAcademicReport($year,$term,$student,$examtype,$start,$end);

        }
         // ===================================Terminal for A-level (july 1 to december)===========================
     elseif($exam_type_value==3){
$start=$year.'-07-01';
    $end=$year.'-11-30';
      $data['start_date'] =$start;
    $data['end_date'] =$end;
     $examtype=3;
            $data['results'] = $this->academicOutputsModel->StudentAcademicReport($year,$term,$student,$examtype,$start,$end);
        }
     // ===================================Annual for A-level (january 1 to june)===========================
        elseif($exam_type_value==4){
     $start=1+$year.'-01-01';
    $end=1+$year.'-06-30';
      $data['start_date'] =$start;
    $data['end_date'] =$end;
    $examtype=4;
            $data['results'] = $this->academicOutputsModel->StudentAcademicReport($year,$term,$student,$examtype,$start,$end);
           
        }
  // ===================================Second Midterm for A-level (january 1 to June)===========================
     elseif($exam_type_value==5){
    $examtype=2;
    $start=1+$year.'-01-01';
    $end=1+$year.'-06-30';
      $data['start_date'] =$start;
    $data['end_date'] =$end;
    $data['results'] = $this->academicOutputsModel->StudentAcademicReport($year,$term,$student,$examtype,$start,$end);
        }


    }
    // ===================================whole year=================================================
    }elseif($exam_type_value==0 && $exam_type_value!='custom'){
          if((in_array($goverment_level->government_level_id, [1, 2, 3]))){
     $start_date = $this->request->getPost('start_date');
    $end_date = $this->request->getPost('end_date');
    $data['start_date'] =$start_date;
    $data['end_date'] =$end_date;
    $start_date_term1=$year.'-01-01';
    $end_date_term1=$year.'-06-30';
    $start_date_term2=$year.'-07-01';
    $end_date_term2=$year.'-12-30';
    $data['results_term1'] = $this->academicOutputsModel->getStudentExamMarksReportTerm1($year,$term,$student,$examtype,$start_date_term1,$end_date_term1);
    $data['results_term2'] = $this->academicOutputsModel->getStudentExamMarksReportTerm2($year,$term,$student,$examtype,$start_date_term2,$end_date_term2);    
        }
      elseif($goverment_level->government_level_id==4){
      $start_date=$year.'-01-07';
    $end_date=1+$year.'-06-30';
       $data['start_date'] =$start_date;
    $data['end_date'] =$end_date;
     $start_date_term1=$year.'-01-07';
    $end_date_term1=1+$year.'-12-30';
    $start_date_term2=$year.'-07-01';
    $end_date_term2=1+$year.'-06-30';
   $data['results_term1'] = $this->academicOutputsModel->getStudentExamMarksReportTerm1($year,$term,$student,$examtype,$start_date_term1,$end_date_term1);
    $data['results_term2'] = $this->academicOutputsModel->getStudentExamMarksReportTerm2($year,$term,$student,$examtype,$start_date_term2,$end_date_term2);    
    }
   // ===================================Custom range=================================================
    }
    elseif($exam_type_value=='custom'){
      if((in_array($goverment_level->government_level_id, [1, 2, 3]))){
    $start = $year.'-01-01';
    $end = $year.'-06-30';
      $data['start_date'] =$start;
    $data['end_date'] =$end;
    $examtype=2;
    $start_date = $this->request->getPost('start_date ');
    $end_datee = $this->request->getPost('end_date ');
    $data['results'] = $this->academicOutputsModel->getStudentExamMarksReport($year,$term,$student,$examtype,$start,$end);    
        }
      elseif($goverment_level->government_level_id==4){
        $start = $year.'-01-01';
    $end = $year.'-06-30';
      $data['start_date'] =$start;
    $data['end_date'] =$end;
    $start_date = $this->request->getPost('start_date ');
    $end_datee = $this->request->getPost('end_date ');
    $examtype=2;
    $data['results'] = $this->academicOutputsModel->getStudentExamMarksReport($year,$term,$student,$examtype,$start,$end);    
    }
}
    // ================================exam type 0============= ==

}
$rawSubjects = $this->academicOutputsModel->GetSubjectsByStreamReport($class,$stream);
  $subjectsByComb = [];
    foreach ($rawSubjects as $row) {
        $comb = $row->comb;
        if (!isset($subjectsByComb[$comb])) {
            $subjectsByComb[$comb] = [
                'subjects' => [],
                'count' => 0,
                'comb' => $comb,
            ];
        }
        $alreadyExists = false;
        foreach ($subjectsByComb[$comb]['subjects'] as $s) {
            if ($s['subject_id'] == $row->subject_id) {
                $alreadyExists = true;
                break;
            }
        }
        if (!$alreadyExists) {
            $subjectsByComb[$comb]['subjects'][] = [
                'subject_id' => $row->subject_id,
                 'selection' => $row->selection,
                'subject_name' => $row->subject_name
            ];
            $subjectsByComb[$comb]['count']++;
        }
    }

    $data['subjectsByComb'] = $subjectsByComb;
     $data['characters']=$this->academicModel->GetAllcharacter();
     //$data['sn']=$sn;
     $where=['character_results_tbl.student_id' => $student,
             'character_results_tbl.academic_yr'=>$year
              ];  
$subjectPosition = $this->request->getPost('subject_position');
   $data['subject_position'] = is_array($subjectPosition) ? $subjectPosition : json_decode($subjectPosition, true);
   $data['year']=$this->request->getPost('year');
   $data['average']=$this->request->getPost('average');
   $data['TotalStudents']=$this->academicOutputsModel->getTotalStudents($year,$class,$pre_stream,$stream);
   $data['averageGrade']=$this->request->getPost('averageGrade');
   $data['totalmarks']=$this->request->getPost('totalmarks');
   $data['postion']=$this->request->getPost('postion');
   $data['combname']=$this->request->getPost('combname');
   $data['exam_type_label']=$this->request->getPost('exam_type_label');
   $data['gradeBoundaries'] = $this->academicOutputsModel->getGradeBoundaries($classlevel);
   $data['st_report']=$this->academicOutputsModel->StudentReport($student,$year);

   $data['classdata']=$this->academicOutputsModel->StudentSubjects($class,$stream);
   $data['char_report']=$this->academicOutputsModel->GetcharacterHistory($student,$year);
   $data['my_student']= $student;
//    if($exam_type_value==0 || $exam_type_value ='custom'){
//     // echo view('student/forms/custom_academic_history',$data);
// }else 
if(in_array($exam_type_value, [1, 2, 3, 4, 5])){
  echo view('student/forms/academic_history',$data);
}else{
  echo view('student/forms/custom_academic_history',$data);  
}
             
}
public function StudentPerformance()
{
    helper('results_helper');
   $year = $this->request->getPost('year');
   $student = $this->request->getPost('student');
   $student_info=$this->academicOutputsModel->getStudentDetails($student,$year);
    $class = $student_info->class_id;
    $classlevel = $student_info->level_id;
    $stream = $student_info->stream_id;
    $term=7;
    $examtype = $this->request->getPost('exam_type_value');
    $exam_type_value = $this->request->getPost('exam_type_value');
    $exam_type_label = $this->request->getPost('exam_type_label');
$goverment_level = $this->academicOutputsModel->get_governmennt_levels($classlevel);
$data['government_level']=$goverment_level->government_level_id;

   if($examtype==2){
         $data['exams'] = $this->academicInputsModel->list_examsBy_midterm();
        }elseif($examtype==3){

         $data['exams'] = $this->academicInputsModel->list_examsBy_terminal();    
        }
        elseif($examtype==4){

         $data['exams'] = $this->academicInputsModel->list_examsBy_annual();    
        }
          if($examtype==5){
         $data['exams'] = $this->academicInputsModel->list_examsBy_midterm();
        }
          $data['tests'] = $this->academicOutputsModel->GetStudentTestPerformance($student);
          $data['midterm'] = $this->academicOutputsModel->GetStudentMidtermPerformance($student);
          $data['terminal'] = $this->academicOutputsModel->GetStudentTerminalPerformance($student);
          $data['annual'] = $this->academicOutputsModel->GetStudentAnnualPerformance($student);
            echo view('student/forms/academic_history_graph',$data); 
}

public function my_student_academic_report()
{
    helper('results_helper');
   $year = $this->request->getPost('year');
   $student_id = $this->request->getPost('student');
   $student_info=$this->academicOutputsModel->getStudentDetails($student_id,$year);
   if(empty($student_info)){
   echo '<span class="alert alert-info">This student has not been admitted for the '.$year.' academic year.</span>';
    return;
   }
    $class = $student_info->class_id;
    $classlevel = $student_info->level_id;
    $stream = $student_info->stream_id;
    $examtype = $this->request->getPost('exam_type_value');
    $exam_type_value = $this->request->getPost('exam_type_value');
    $exam_type_label = $this->request->getPost('exam_type_label');
$goverment_level = $this->academicOutputsModel->get_governmennt_levels($classlevel);
$gradeBoundaries= $this->academicOutputsModel->getGradeBoundaries($classlevel);
    $Mid1subjectAverages = [];
    $subject_position = [];
    $overallAverages = [];
    $students = [];
    $start='';
    $end='';
if(isset($goverment_level)){


        // =====================================O- level and primary============================
    if((in_array($goverment_level->government_level_id, [1, 2, 3]))){
            $start_term1 = $year.'-01-01';
    $end_term1 = $year.'-06-30';
    $start_term2 = $year.'-07-01';
    $end_term2 = $year.'-12-30';
    $examtype_term1=[1, 2,3];
    $examtype_term2=[1, 2,4];
    $status=2;
    $students = $this->academicOutputsModel->FetchReports($class, $classlevel, $stream, $year, $status);
    $examtype=[1, 2,3,4];
    $student = $this->request->getPost('student');
$Mid1subjectAverages = $this->academicOutputsModel->getStudentSubjectAverages($year, $stream, $class, $examtype, $start_term1, $end_term1,$student);
$Mid2subjectAverages = $this->academicOutputsModel->getStudentSubjectAverages($year, $stream, $class, $examtype, $start_term2, $end_term2,$student);
$subject_position_term1 = $this->academicOutputsModel->getSubjectPositions($year, $stream, $class, $examtype, $start_term1, $end_term1);
$subject_position_term2 = $this->academicOutputsModel->getSubjectPositions($year, $stream, $class, $examtype, $start_term2, $end_term2);
$overallAverages_term1 = $this->academicOutputsModel->getStudentOverallAverages($year, $stream, $class, $examtype, $start_term1, $end_term1,$student);
$overallAverages_term2 = $this->academicOutputsModel->getStudentOverallAverages($year, $stream, $class, $examtype, $start_term2, $end_term2,$student);

usort($overallAverages_term1, fn($a, $b) => $b->overall_avg <=> $a->overall_avg);
foreach ($overallAverages_term1 as $rank => &$position_term1) {
    $position_term1->position = $rank + 1;
}
usort($overallAverages_term2, fn($a, $b) => $b->overall_avg <=> $a->overall_avg);
foreach ($overallAverages_term2 as $rank => &$position_term2) {
    $position_term2->position = $rank + 1;
}
 $data['overallAverages_term1']= $overallAverages_term1;
 $data['overallAverages_term2']= $overallAverages_term2;
 $data['students']= $students;
 $data['students_count']= $this->academicOutputsModel->getNumberStudents($year,$class);
 $data['Mid1subjectAverages']= $Mid1subjectAverages;
 $data['Mid2subjectAverages']= $Mid2subjectAverages;
 $data['subject_position_term1'] = $subject_position_term1;
 $data['subject_position_term2'] = $subject_position_term2;
 $data['start_date'] =$start_term1;
$data['end_date'] =$end_term2;


    }
    // =========================================A-level======================================
     elseif($goverment_level->government_level_id==4){
    $start_term1 = $year.'-07-01';
    $end_term1 = $year.'-12-30';
    $start_term2 = 1+$year.'-01-01';
    $end_term2 = 1+$year.'-06-30';
    $examtype_term1=[1, 2,3];
    $examtype_term2=[1, 2,4];
    $status=2;
    $students = $this->academicOutputsModel->FetchReports($class, $classlevel, $stream, $year, $status);
    $examtype=[1, 2,3,4];
    $student = $this->request->getPost('student');
$Mid1subjectAverages = $this->academicOutputsModel->getStudentSubjectAverages($year, $stream, $class, $examtype, $start_term1, $end_term1,$student);
$Mid2subjectAverages = $this->academicOutputsModel->getStudentSubjectAverages($year, $stream, $class, $examtype, $start_term2, $end_term2,$student);
$subject_position_term1 = $this->academicOutputsModel->getSubjectPositions($year, $stream, $class, $examtype, $start_term1, $end_term1);
$subject_position_term2 = $this->academicOutputsModel->getSubjectPositions($year, $stream, $class, $examtype, $start_term2, $end_term2);
$overallAverages_term1 = $this->academicOutputsModel->getStudentOverallAverages($year, $stream, $class, $examtype, $start_term1, $end_term1,$student);
$overallAverages_term2 = $this->academicOutputsModel->getStudentOverallAverages($year, $stream, $class, $examtype, $start_term2, $end_term2,$student);

usort($overallAverages_term1, fn($a, $b) => $b->overall_avg <=> $a->overall_avg);
foreach ($overallAverages_term1 as $rank => &$position_term1) {
    $position_term1->position = $rank + 1;
}
usort($overallAverages_term2, fn($a, $b) => $b->overall_avg <=> $a->overall_avg);
foreach ($overallAverages_term2 as $rank => &$position_term2) {
    $position_term2->position = $rank + 1;
}
 $data['overallAverages_term1']= $overallAverages_term1;
 $data['overallAverages_term2']= $overallAverages_term2;
 $data['students']= $students;
 $data['students_count']= $this->academicOutputsModel->getNumberStudents($year,$class);
 $data['Mid1subjectAverages']= $Mid1subjectAverages;
 $data['Mid2subjectAverages']= $Mid2subjectAverages;
 $data['subject_position_term1'] = $subject_position_term1;
 $data['subject_position_term2'] = $subject_position_term2;
 $data['start_date'] =$start_term1;
$data['end_date'] =$end_term2;

     }
     // =========================================VTC======================================
       elseif($goverment_level->government_level_id==5){

     }
     // =========================================Collage======================================
       elseif($goverment_level->government_level_id==6){

     }
     // =========================================University======================================
         elseif($goverment_level->government_level_id==7){

     }
     else{
         echo '<span class="alert alert-danger">Unkown class level.</span>';
    return;
     }

}

$data['government_level']=$goverment_level->government_level_id;
$data['gradeBoundaries']=$gradeBoundaries;
 $data['exams_term1'] = $this->academicInputsModel->list_examsBy_term1();
 $data['exams_term2'] = $this->academicInputsModel->list_examsBy_term2();
 $data['student_data']=$this->academicOutputsModel->StudentReport($student_id,$year);
$data['classdata']=$this->academicOutputsModel->StudentSubjects($class,$stream);
$data['government_level']=$goverment_level->government_level_id;
$data['year']= $this->request->getPost('year');
return view('student/forms/academic_history',$data);

}
public function CheckSubjectAverage(){
        helper('results_helper');
   $year = $this->request->getPost('year');
   $subject_id = $this->request->getPost('subject_id');
   $class = $this->request->getPost('class_id');
   $classlevel = $this->request->getPost('classlevel');
   $goverment_level = $this->request->getPost('government_level');
   $stream = $this->request->getPost('stream');
   $term = $this->request->getPost('term');

$subject = $this->academicOutputsModel->GetSubjectByID($subject_id);
//$data['government_level']=$goverment_level->government_level_id;
        // =====================================O- level and primary============================
    if((in_array($goverment_level, [1, 2, 3]))){
        $term = $this->request->getPost('term');
    $start_term1 = $year.'-01-01';
    $end_term1 = $year.'-06-30';
    $start_term2 = $year.'-07-01';
    $end_term2 = $year.'-12-30';
    $examtype_term1=[1, 2,3];
    $examtype_term2=[1, 2,4];
    $status=2;
    $students = $this->academicOutputsModel->FetchReports($class, $classlevel, $stream, $year, $status);
    $examtype=[1, 2,3,4];
    $student = $this->request->getPost('student');
$subject_position_term1 = $this->academicOutputsModel->GetStudentsSubjectPositions($year, $subject_id,$stream, $class, $examtype, $start_term1, $end_term1);
$subject_position_term2 = $this->academicOutputsModel->GetStudentsSubjectPositions($year,$subject_id, $stream, $class, $examtype, $start_term2, $end_term2);
$subjectAverages = $this->academicOutputsModel->GetSubjectAverages($year,$subject_id, $stream, $class, $examtype, $start_term1, $end_term1,$student);
 $data['students']= $students;
 $data['subject_position_term1'] = $subject_position_term1;
 $data['subject_position_term2'] = $subject_position_term2;
 $data['subject_marks'] = $subjectAverages;
 $data['subjects'] =$subject_id;
 $data['subject_name'] =$subject;
  $data['subject_marks'] = $subjectAverages;
      if($term==1){
 $data['exams_term'] = $this->academicInputsModel->list_examsBy_term1();
     }elseif($term==2){
 $data['exams_term'] = $this->academicInputsModel->list_examsBy_term2();
     }else{
echo 'empty';
     }
    }
    // =========================================A-level======================================
     elseif($goverment_level==4){
        $term = $this->request->getPost('term');
    $start_term1 = $year.'-07-01';
    $end_term1 = $year.'-12-30';
    $start_term2 = 1+$year.'-01-01';
    $end_term2 = 1+$year.'-06-30';
    $examtype_term1=[1, 2,3];
    $examtype_term2=[1, 2,4];
    $status=2;
    $students = $this->academicOutputsModel->FetchReports($class, $classlevel, $stream, $year, $status);
    $examtype=[1, 2,3,4];
    $student = $this->request->getPost('student');
$subject_position_term1 = $this->academicOutputsModel->GetStudentsSubjectPositions($year,$subject_id,$stream, $class, $examtype, $start_term1, $end_term1);
$subject_position_term2 = $this->academicOutputsModel->GetStudentsSubjectPositions($year,$subject_id, $stream, $class, $examtype, $start_term2, $end_term2);
$subjectAverages = $this->academicOutputsModel->GetSubjectAverages($year,$subject_id, $stream, $class, $examtype, $start_term1, $end_term1,$student);
 $data['students']= $students;
 $data['subject_position_term1'] = $subject_position_term1;
 $data['subject_position_term2'] = $subject_position_term2;
 $data['start_date'] =$start_term1;
$data['end_date'] =$end_term2;
$data['subjects'] =$subject_id;
 $data['subject_name'] =$subject;
  $data['subject_marks'] = $subjectAverages;
     
     if($term==1){
 $data['exams_term'] = $this->academicInputsModel->list_examsBy_term1();
     }elseif($term==2){
 $data['exams_term'] = $this->academicInputsModel->list_examsBy_term2();
     }else{
echo 'empty';
     }
}
      $data['exams_term1'] = $this->academicInputsModel->list_examsBy_term1();
 $data['exams_term2'] = $this->academicInputsModel->list_examsBy_term2();
     return view('student/forms/academic_subject_position',$data);
}

}
?>
