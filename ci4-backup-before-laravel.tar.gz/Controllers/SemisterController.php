<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AdmissionModel;
use App\Models\BillingModel;
use App\Models\StudentModel;
use App\Models\SystemModel;
use App\Models\ReportsModel;

class SemisterController extends BaseController
{

    public function __construct(){
        
         if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
        $this->amodel = new AdmissionModel();
        $this->smodel = new StudentModel();
        $this->billingModel = new BillingModel();
         $this->sytm_model = new SystemModel();
        $this->reportsModel=new ReportsModel();
         
         $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
            helper('age');

      }
    public function semister()
    {
        return view('templates/header')
        .view('student/semister')
        .view('templates/footer');
    } 
    public function get_semisters(){
        $data=array(
          'year'=>$this->request->getPost('year')
        );
       echo view('student/forms/semister_list',$data);
    }
    public function get_pending(){
        $data=array(
          'year'=>$this->request->getPost('year'),
          'iclass'=>$this->request->getPost('iclass'),
          'stream'=>$this->request->getPost('istream'),
          'adfor'=>$this->request->getPost('adfor'),
          'bod'=>$this->request->getPost('bod'),
          'hostel'=>$this->request->getPost('hostel'),
        );
       echo view('student/forms/student_pending_list',$data);
    }
     public function get_pending_newcomer(){
        $data=array(
          'year'=>$this->request->getPost('year')
        );
       echo view('admission/student_newcomer',$data);
    }
    public function get_admission(){
        $data=array(
          'admission'=>array(),
          'search'=>1,
          'year'=>$this->request->getPost('year')
        );
       echo view('student/forms/student_adimitted_list',$data);  
    }
    public function get_pending_continous(){
        $data=array(
          'year'=>$this->request->getPost('year'),
          'classId'=>$this->request->getPost('class')
        );
       echo view('student/forms/student_continous_list',$data);  
    }
     public function get_graduations(){
       $data=array(
          'year'=>$this->request->getPost('year'),
          'class'=>$this->request->getPost('class')
        );
       echo view('admission/forms/student_graduation_list',$data);  
    }
    
    
      public function get_adimition_manage()
    {
            $id = $this->request->getPost('id');
            $val = $this->amodel->get_student_details('admission_tbl', $where = array('id' => $id));
        //print_r($val);
        $data['lv']=$val[0]->level_id;
        $data['cl']=$val[0]->class_id;
        $data['bod']=$val[0]->admission_type;
        $data['year']=$val[0]->academic_year;
        $data['str']=$val[0]->stream_id;
        $data['for']=$val[0]->adimit_for;
         $data['hstlid']=$val[0]->hostel_id;
        $data['adm_id']=$id;
        $data['student_dtl'] = $this->amodel->get_student_details('students', $where = array('id' => $val[0]->student_id));

     
        $data['studentparent'] = $this->amodel->get_student_details('parents_students_tbl', $where = array('student_id' => $val[0]->student_id));

        echo view('student/admission_manage_details',$data);
    }

    public function get_class_graduators()
    {
       $data=array(
          'year'=>$this->request->getPost('year'),
          'classId'=>$this->request->getPost('class')
        );
       echo view('admission/forms/class_graduation_list',$data); 
      
    }
    function save_graduation_class(){
        $adm_id=$this->request->getPost('selected');
        $batch_no=$this->generate_graduation_no($this->request->getPost('Academic_year'),$this->request->getPost('class'));
    foreach($adm_id as $id){
               $data = [
                    'adm_id' =>$id,
                    'graduation_number ' => $batch_no,
                    'class' => $this->request->getPost('class'),
                    'graduation_date' => $this->request->getPost('admission_date'),
                    'graduation_year' => $this->request->getPost('Academic_year'),
                    'date_created' => date('Y/m/d H:i:s'),
                    'created_by ' =>  $this->request->getPost('header_id'),
                 ];
               // print_r($data);
         $this->amodel->SaveDetails('graduation_tbl',$data);
        
         $data2 = [
                    'status' => 4
                ];

            $sid=$this->request->getPost('sid'.$id);
               $this->smodel->update_table_details('students',$where = array('id' => $sid),$data2); 
               
          $this->smodel->update_table_details('admission_tbl',$where = array('id' => $id),$data2); 
               echo '1';

               $stn = $this->smodel->gettable_data('students',$where = array('id' => $sid)); 
                 $msg = "Dear ".$stn[0]->first_name.", Congratulations for your Graduation. We wish you all the best.";
   //****invoice msg setup*************************************//
          $phone = $this->smodel->gettable_billingdata($sid);
        
        $messagex="Dear Student Name, congratulations for your Graduation. We wish you all the best.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 2,
                    'message_type' => 10,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $sid
                  
                );
     if(count($phone)>0){
 //$this->smodel->SaveData('message_groups_tbl',$smsdata);

   //$this->SMSsender($phone[0]->phone1,$msg,10,$sid,$snn,NULL);
      }
     }
    }
 public function generate_graduation_no($academic,$class)
    {
        $ino = "";
        $result=$this->amodel->get_student_details('graduation_tbl', $where = array('graduation_year' =>$academic,'class' =>$class));
        if(count($result)>0){
            $ino = $result[0]->graduation_number;
        }else{
         $lastYear=$academic-1;
        $tkens =$this->amodel->get_student_details('graduation_tbl', $where = array('graduation_year' =>$lastYear,'class' =>$class));
        if (count($tkens) > 0) {
            $trans = $tkens[0]->graduation_number + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
    }
        return $ino;
    }
    public function generate_absconded_no()
    {
        $ino = "";
        $col="entry_number";
    $builder = $this->db->table('absconding_tbl');
     $builder->select('max('.$col.') as max_id');
     $tkens=$builder->get()->getResult();
        if (($tkens[0]->max_id) > 0) {
            //print_r($tkens);
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
    
        return $ino;
    }
    public function cash_transfer(){
        return view('templates/header')
        .view('payment/cash_transfer')
        .view('templates/footer');
    }

     function search_transaction(){
        $search = $this->request->getPost('payer_name');
        //echo $search;
         $result=$this->amodel->get_student_details('transaction_numbers_tbl', $where = array('trans_number' =>$search,'trans_type_id' =>2));
            //print_r($result);
              if(count($result) > 0){
              $amt=$this->amodel->get_student_details('ledger_transaction_tbl', $where = array('trans_no' =>$search,'trans_type' =>2,'ledger_type'=>7));
              $lg=$this->amodel->get_student_details('ledger_transaction_tbl', $where = array('trans_no' =>$search,'trans_type' =>2,'ledger_type'=>9));
              $accname=$this->amodel->get_student_details('accounts_tbl', $where = array('id' =>$lg[0]->ledger_id));
               $stname=$this->amodel->get_student_details('students', $where = array('id' =>$amt[0]->name_id));

           echo '<div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Receipt No</label>
                <div class="col-sm-8">
                  <input type="text" readonly  class="form-control"  value="'.$search.'" name="receipt_number" id="receipt_number">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Student Name</label>
                <div class="col-sm-8">
                 <input type="hidden" class="form-control"  value="'.$stname[0]->id.'" name="student_from" id="student_from">
                  <input type="text" readonly class="form-control"  value="'.$stname[0]->full_name.'">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Receipt Amount</label>
                <div class="col-sm-8">
                 <input type="hidden" readonly class="form-control"  value="'.$amt[0]->amount.'" id="rct_amount">
                  <input type="text" readonly class="form-control"  value="'.number_format($amt[0]->amount).'">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Ledger Name</label>
                <div class="col-sm-8">
                 <input type="hidden" class="form-control"  value="'.$accname[0]->id.'" name="from_ledger" id="from_ledger">
                  <input type="text" readonly class="form-control"  value="'.$accname[0]->account_name.'">
                </div>
                </div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Reverse Amount<span class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="number" class="form-control"  value="" onkeyup="enter_amount()" name="amount" id="i_amount">
                </div>
                </div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Reason</label>
                <div class="col-sm-8">
                  <textarea class="form-control"  value="" name="reason" id="reason"></textarea>
                </div>
                </div>';
              
            
        }else{
          echo "<span style='color:red'>No any receipt Found</span>";
        }
    
    }

    function search_invoice(){
        $search = $this->request->getPost('invoice_number');
        //echo $search;
         $result=$this->amodel->get_student_details('transaction_numbers_tbl', $where = array('trans_number' =>$search,'trans_type_id' =>1));
            //print_r($result);
              if(count($result) > 0){
              $amt=$this->amodel->get_student_details('ledger_transaction_tbl', $where = array('trans_no' =>$search,'trans_type' =>1,'transation_nature'=>2));
              $ref=$this->amodel->get_student_details('payment_request', $where = array('trans_no' =>$search,'trans_type' =>1));
              $refe=0;
              if(count($ref)>0){
                $refe=$ref[0]->reference_no;
              }
              $paid=$this->amodel->get_student_details('transactions_relation', $where = array('invoice_trans_no' =>$search));
              $tpaid=0;
              if(count($paid)>0){
                foreach($paid as $p){
                 $amtpaid=$this->amodel->get_student_details('ledger_transaction_tbl', $where = array('trans_no' =>$p->receipt_trans_no,'trans_type' =>2,'ledger_type'=>7));
                 $tpaid+=$amtpaid[0]->amount;  
                }
              }

           echo '<div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Invoice No</label>
                <div class="col-sm-8">
                  <input type="text" readonly  class="form-control"  value="'.$search.'" name="invoice_number">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">invoice Date</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value="  '.$result[0]->trans_date.'">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Reference number</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value="  '.$refe.'">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Invoice Amount</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value="  '.number_format($amt[0]->amount).'">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Paid amount</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value="  '.number_format($tpaid).'">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Reason</label>
                <div class="col-sm-8">
                 <textarea name="reason" id="reason" value="" required="required" class="form-control"></textarea>
                </div>
                </div>';
            
        }else{
          echo "<span style='color:red'>No any receipt Found</span>";
        }
    
    }

     public function new_admission(){
         
          $level=$this->request->getPost('class_level');
          $legers_acc = $this->smodel->gettable_data('class_level_items_tbl',$where = array('level_id' => $level));
        if(count($legers_acc)==0){
            echo "2";
          return;
          }
        
    $student_id=$this->request->getPost('selected');
     $year=$this->request->getPost('year');
          $class=$this->request->getPost('class');
          $hst=$this->request->getPost('hstl');
    foreach($student_id as $sid){
        $checkIfexit= $this->smodel->gettable_data('admission_tbl',$where = array('student_id' => $sid,'academic_year'=>$this->request->getPost('year')));
        if(count($checkIfexit)>0){
            continue;
        }
         
        $data = [
                    'student_id' =>$sid,
                    'academic_year' => $this->request->getPost('year'),
                    'date_joined' => $this->request->getPost('admission_date'),
                    'level_id' => $this->request->getPost('class_level'),
                    'class_id' => $this->request->getPost('class'),
                    'stream_id' => $this->request->getPost('stream'),
                    'admission_type' => $this->request->getPost('admission_type'),
                    'hostel_id' => $this->request->getPost('hstl'),
                    'transport' =>'No',
                    'vehicle_id' =>0,
                    'adimit_for' => $this->request->getPost('for'),
                    'admitted_by ' => $this->request->getPost('header_id'),
                    'admitted_date' => date('Y/m/d H:i:s')
                ];
               // print_r($data);
       $this->amodel->SaveDetails('admission_tbl',$data);
            $data2 = [
                    'status' => 2
                ];

            
             $this->smodel->update_table_details('students',$where = array('id' => $sid),$data2); 
               //bording
                if($this->request->getPost('hstl')>0){
                 $pno = $this->generate_boarding_pno();
          
          $datah = [
                    'student_id' => $sid,
                    'academic_year' => $this->request->getPost('acdy'),
                    'permit_id' => $pno,
                    'admission_type' => $this->request->getPost('admission_type'),
                    'hostel' => $this->request->getPost('hstl'),
                    'month' => 0,
                    'start_date' => $this->request->getPost('admission_date'),
                    'end_date' => $this->request->getPost('end'),
                      'created_date' => date('Y/m/d H:i:s'),
                    'created_by' =>$this->request->getPost('header_id'),
                    'status ' => 1
                   
                ];
               $this->amodel->SaveDetails('boarding_tbl',$datah);
                  } 
                  //end
       $transNo = $this->generate_transaction_no();
        $admnTransaction = [
                'trans_type_id' => 1,
                'trans_number' => $transNo,
                'trans_date' => $this->request->getPost('admission_date'),
                'updated_by' => $this->request->getPost('header_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
    
        $trans_id = $this->smodel->SaveData_n_get_id('transaction_numbers_tbl',$admnTransaction);
        $check_class = $this->smodel->gettable_data('company_tbl',$where = array('classification' => 1));
        if(count($check_class)>0){
            $classification = [
                'trans_id' => $trans_id,
               'classification_id' => $this->request->getPost('class_id'),
                
                 ];
       $this->smodel->SaveData('invoice_classification_tbl',$classification);
         }

        $total_cost = 0;
        $invoice_type = [
             'trans_no' => $transNo,
             'transaction_type_id' => 1,
             'invoice_type_id' => 2
         ];
         $itm_trans = $this->smodel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);
         ///geting items
        
              if($this->request->getPost('for'.$sid)==2 || $this->request->getPost('for')==2){
         $levelFee=$this->amodel->fetch_classLevel_fee(2,$this->request->getPost('class_level'));
         
         }else{
           $levelFee=$this->amodel->fetch_classLevel_fee(0,$this->request->getPost('class_level')); 
            
         }
              $items=array();
              foreach($levelFee as $lv){
             $items[]=array($lv->item_id);
              }

         ///////start///////////////
              if($this->request->getPost('for'.$sid)==2 || $this->request->getPost('for')==2){
          $classFee=$this->amodel->fetch_class_fee(2, $this->request->getPost('class'));
          //print_r($classFee);
         // return;
              }else{
    $classFee=$this->amodel->fetch_class_fee(0, $this->request->getPost('class'));
              }
              
       
         foreach($classFee as $cl){
       $items[]=array($cl->item_id);
          }
  if($this->request->getPost('admission_type'.$sid)==3){
    if($this->request->getPost('for'.$sid)==2){
      $bFee=$this->amodel->fetch_boarding_fee(2,$this->request->getPost('class'));
      //print_r($bFee);
      $bFee2=$this->amodel->fetch_boarding_fee2(2,$this->request->getPost('class_level'));  
     // print_r($bFee2);
  }else{
     $bFee=$this->amodel->fetch_boarding_fee(0,$this->request->getPost('class'));
     $bFee2=$this->amodel->fetch_boarding_fee2(0,$this->request->getPost('class_level'));  
  }
    if(count($bFee)>0){
     foreach($bFee as $bf){
     $items[]=array($bf->item_id);
      }
      }

      if(count($bFee2)>0){
     foreach($bFee2 as $bf){
     $items[]=array($bf->item_id);
      }
      }
  }elseif($this->request->getPost('admission_type')==3){
    if($this->request->getPost('for')==2){
      $bFee=$this->amodel->fetch_boarding_fee(2,$this->request->getPost('class'));
      //print_r($bFee);
      $bFee2=$this->amodel->fetch_boarding_fee2(2,$this->request->getPost('class_level'));  
    //   print_r($bFee2);
  }else{
     $bFee=$this->amodel->fetch_boarding_fee(0,$this->request->getPost('class'));
     $bFee2=$this->amodel->fetch_boarding_fee2(0,$this->request->getPost('class_level'));  
  }
    if(count($bFee)>0){
     foreach($bFee as $bf){
     $items[]=array($bf->item_id);
      }
      }

      if(count($bFee2)>0){
     foreach($bFee2 as $bf){
     $items[]=array($bf->item_id);
      }
      }
  }
  else{
    //   echo "it is not boarding";
  }
  //////////loop items
     $itype ="";
         $amountttl = 0;
         $qtys = 0;
         $id="";
         $discount=0;
        //  print_r($items);
        //  return;
  foreach ($items as $item) {
    //echo $item[0] . "<br>";
    $c=$item[0];
 $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c));
 $item_price = $this->smodel->gettable_data('price_tbl',$where = array('item_id' => $c));
            foreach($itm as $i){
                $itype = $i->item_type;
            }
            $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $transNo,'trans_type' => 1, 'quantity' => 1, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $item_price[0]->item_price);

            $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);

            $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
            if(count($itm)>0 && $itm[0]->item_group==7){
                 $discount=1 * $item_price[0]->item_price;
            $total_cost-=1 * $item_price[0]->item_price;
            }else{

            $total_cost+=1 * $item_price[0]->item_price;
          }
          $amount=0;
          $transactions=0;
            foreach($leger_items as $lg){
                $amount= 1 * $item_price[0]->item_price;
                $transactions+=$amount;
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                // if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                //     continue;
                // }
                $ledger = [
                     'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $c,
                     'trans_no' => $transNo,
                     'trans_type' => 1,
                     'amount' =>  1 * $item_price[0]->item_price,
                     'transation_nature' => 1,
                     'name_type_id' => 1,
                     'name_id' => $sid,
                ];
                $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 
            }
        }

//////////end loop items
          //for account receivables
       $total= 0;
        $ledgerId = '';
        $i=0;
        $total=$this->request->getPost('total_fee'.$sid);
          $level=$this->request->getPost('class_level');
          $legers_acc = $this->smodel->gettable_data('class_level_items_tbl',$where = array('level_id' => $level));
        if(count($legers_acc)>0){
          $ledgerId=$legers_acc[0]->account_receivable;
          }else{
         $legers_acc = $this->smodel->gettable_data('accounts_tbl',$where = array('account_type_id' => 7));
         if(count($legers_acc)>0){
         $ledgerId=$legers_acc[0]->id;
         }else{
           $legers_acc = $this->smodel->gettable_data('accounts_tbl',$where = array('account_type_id' => 4)); 
                    $ledgerId=$legers_acc[0]->id;
         }
          }
        $ac_ledger = [
            'ledger_id' => $ledgerId,
            'ledger_type' => 7,
            'trans_no' => $transNo,
            'trans_type' => 1,
            'amount' => $total,
            'transation_nature' => 2,
            'name_type_id' => 1,
            'name_id' => $sid,
            'balance' => $total,
        ];   
        $this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger); 
       $desc='School Fees';
         $this->createControl_number_crdb_admission($total,$sid,$transNo,1,$desc,1,1,$year,$class,$hst);
        echo '1';
   }
 }
  public function generate_transaction_no()
    {
        $ino = "";
        $tkens = $this->smodel->get_max_invoice('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
     public function generate_boarding_pno()
    {
        $ino = "";
        $tkens = $this->smodel->get_max_id('boarding_tbl','permit_id');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }

    function load_receipt(){
     echo view('admission/forms/use_other_receipt');
    }

    function load_reversal(){
   $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            
            $data = array(
               'trans' => $this->billingModel->get_item_name2('transaction_numbers_tbl',$where = array('trans_type_id' => 7),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))
            );
            //print_r($data);
            echo view('payment/reversed_receipt',$data);
    }

    function view_revesal($id){
        $data = array(
               'recpt' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('id' =>$id))
            );
            return view('payment/reversal_detailed',$data);
    }

    function view_graduation($yr,$class){
        $data = array(
               'year' =>$yr,
               'class' =>$class,
            );
         echo view('admission/forms/graduation_view',$data);
    }
    function edit_graduation($yr,$class){
        $data = array(
               'year' =>$yr,
               'class' =>$class,
            );
         echo view('admission/forms/graduation_edit',$data);
    }
     function delete_graduation($yr,$class,$iid){
          $items = $this->smodel->gettable_data('graduation_tbl',$where = array('id' => $iid));
           $adm = $this->smodel->gettable_data('admission_tbl',$where = array('id' => $items[0]->adm_id));
       $data2 = [
                    'status' => 2
                ];

        $this->smodel->update_table_details('students',$where = array('id' => $adm[0]->student_id),$data2);
        $this->smodel->deletetable_data1('graduation_tbl',$iid); 

            $data = array(
               'year' =>$yr,
               'class' =>$class,
            );
         echo view('admission/forms/graduation_edit',$data);
    }

  function SMSsender($dest,$msg,$type,$ref_no,$snn,$show_response=0) {
        $tmsg = $this->smodel->gettable_data('message_status_tbl',$where = array('status' => 1,));
                  if(count($tmsg)==0){
                   return;   
                  }
            $messag = $this->sytm_model->load_messages_balances();
              $senderid=constant('SENDER_ID_' . session()->get('db_id'));
                 
                 if($senderid){
              $username=SMS_UNAME;
             $password=SMS_PASSWORD;
                 }else{
                     return;
                 }

             $time_sent = time();
           
             $destination=str_replace('-', '', $dest);
             $message=urlencode($msg);
             $senderid = urlencode($senderid);
          $resp=file_get_contents("https://www.sms.co.tz/api.php?do=sms&username={$username}&password={$password}&senderid={$senderid}&dest={$destination}&msg={$message}");

            
            list($status, $note, $smsid) = explode(',', $resp);
            if($show_response == 2){
              echo '<th>Message status:</th>';
              echo '<td><i>' . $note . '</i></td>';
            }
            if ($status == 'OK') {
                $msgid = $smsid;
                $snt_status = 1;    // Message sent successfully
                $cost = 45;
                $acc_cost = $cost;
            } else {
                $msgid = '';
                $snt_status = 2;    // Message just sent 
                $cost = 45;
                $acc_cost = $cost;
            }

             $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'reference_no' => $ref_no,
                    'send_no'=>$snn
                   
                );
            
            $this->smodel->SaveData('messages',$tempsmsdata);
          //  echo 'msg saved';

        $balance = ($messag[0]->balance - $acc_cost);

        $smsDt = array(
            'balance' => $balance,
            'created_at' => date('Y/m/d H:i:s')
        );
        $this->sytm_model->update_sms_balance($smsDt, $messag[0]->b_id);
            //curl_close($curl);
        
    }
     function generate_msg_no() {
        $ino = "";
        $tkens = $this->smodel->get_max_id('message_groups_tbl','send_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
 function get_class_absconding(){
        $search=$this->request->getPost('search');
        $year=$this->request->getPost('year');
         
        if($search){
           $name=$this->request->getPost('name');
           $name=trim($name);
       $name_parts = explode(" ", $name);
        $clas=$this->reportsModel->class_list_byname($name_parts,count($name_parts),$year);
      
        if(count($clas)==1){
        $sadm =$clas;
       

        }else{
            if(count($clas) >0){
           echo "Please search one among of these:-";
            echo '</br>';
           foreach($clas as $as){
            echo $as->full_name;
            echo '</br>';
           }
            }else{
            echo 'No results found';
            }
            return;
         
        }

        }else{

        $classId=$this->request->getPost('class');
        $sadm = $this->smodel->gettable_data('admission_tbl', $where = array('academic_year'=>$year,'class_id'=>$classId));
         $clas = $this->smodel->gettable_data('classes_tbl', $where = array('id'=>$classId,'status' => 1));
        }
    
        
       $data=array(
          'year'=>$this->request->getPost('year'),
          
          'sadm'=>$sadm,
          'clas'=>$clas,
        );
            //print_r($data);
       echo view('admission/forms/class_absconding_list',$data);  
    } 

     function save_absconding_class(){
        $adm_id=$this->request->getPost('selected');
        $batch_no=$this->generate_absconded_no();
    foreach($adm_id as $id){
               $data = [
                    'adm_id' =>$id,
                    'entry_number ' => $batch_no,
                    'class' => $this->request->getPost('class'),
                    'absconded_date' => $this->request->getPost('admission_date'),
                    'absconded_year' => $this->request->getPost('Academic_year'),
                    'date_created' => date('Y/m/d H:i:s'),
                    'created_by ' =>  $this->request->getPost('header_id'),
                 ];
               // print_r($data);
         $this->amodel->SaveDetails('absconding_tbl',$data);
        
         $data2 = [
                    'status' => 5
                ];

            $sid=$this->request->getPost('sid'.$id);
               $this->smodel->update_table_details('students',$where = array('id' => $sid),$data2); 
                 $this->smodel->update_table_details('admission_tbl',$where = array('id' => $id),$data2); 
               echo '1';

               $stn = $this->smodel->gettable_data('students',$where = array('id' => $sid)); 
               
                 $school_phone = $this->smodel->gettable_data('company_tbl',$where = array('phone2 !=' =>"")); 
               if(count($school_phone)>0){
                $schoolPhone=$school_phone[0]->phone2;
               }else{
                $schoolPhone="";
               }

            $msg = "Dear ".$stn[0]->first_name.", You have been marked as Absconded from school effectively from ".$this->request->getPost('admission_date').". If this is a mistake please call ".$schoolPhone.".";
   //****invoice msg setup*************************************//
          $phone = $this->smodel->gettable_billingdata($sid);
        
        $messagex="Dear Student fName, You have been marked as Absconded from school effectively from abscod date. If this is a mistake please call #phoneNo.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 2,
                    'message_type' => 11,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $sid
                  
                );
     if(count($phone)>0){
 $this->smodel->SaveData('message_groups_tbl',$smsdata);

   $this->SMSsender($phone[0]->phone1,$msg,10,$sid,$snn,NULL);
      }
     }
    }

    function get_absconded_students(){
         $data=array(
          'year'=>$this->request->getPost('year'),
          'class'=>$this->request->getPost('class')
        );
       echo view('admission/forms/student_absconded_list',$data); 
    }
    function view_absconds($yr,$class,$ent){
        $data = array(
               'year' =>$yr,
               'class' =>$class,
               'ent' =>$ent,
            );
         echo view('admission/forms/absconded_view',$data);
    }
    function edit_absconds($yr,$class,$ent){
        $data = array(
               'year' =>$yr,
               'class' =>$class,
                'ent' =>$ent,
            );
         echo view('admission/forms/absconded_edit',$data);
    }
    function delete_absconds($yr,$class,$iid,$ent){
          $items = $this->smodel->gettable_data('absconding_tbl',$where = array('id' => $iid));
           $adm = $this->smodel->gettable_data('admission_tbl',$where = array('id' => $items[0]->adm_id));
       $data2 = [
                    'status' => 2
                ];

        $this->smodel->update_table_details('students',$where = array('id' => $adm[0]->student_id),$data2);
         $data2 = [
                    'status' => 1
                ];
          $this->smodel->update_table_details('admission_tbl',$where = array('id' => $items[0]->adm_id),$data2); 
        $this->smodel->deletetable_data1('absconding_tbl',$iid); 

            $data = array(
               'year' =>$yr,
               'class' =>$class,
               'ent' =>$ent,
            );
         echo view('admission/forms/absconded_edit',$data);
    }
    
     public function course_period(){
         return view('templates/header')
        .view('student/course_period')
        .view('templates/footer');
    }
    
    public function save_course_period(){
       $checking = $this->smodel->gettable_data('academic_types_tbl', $where = array('academic_type' => $this->request->getPost('pname'))); 
            if($checking){
                 echo json_encode(array('status' =>'1','statusDesc' => 'Course Period: <b>'.$checking[0]->academic_type.' Already registerd.'));
            }else{
               $data = [
                    'academic_type' => $this->request->getPost('pname'),
                    'status' => 1,
                    'date_created' => date('Y/m/d H:i:s'),
                    'created_by ' =>  $this->request->getPost('header_id'),
                 ];
               // print_r($data);
         $this->amodel->SaveDetails('academic_types_tbl',$data);
          echo json_encode(array('status' =>'0','statusDesc' => 'Course Period added Successful'));
      }
     }
    public function editCoursePeriod(){
    $id = $this->request->getVar('id');
        $data['period'] = $this->smodel->gettable_data('academic_types_tbl', $where = array('id' => $id));

        echo view('student/forms/manage_CoursePeriod',$data);
    }

    public function update_period(){
        $data = [
            'academic_type' => $this->request->getPost('period'),
            'status' => $this->request->getPost('status'),
            'created_by' => $_SESSION['user_id'],
            'date_created' => date('Y/m/d H:i:s')
        ];

         $this->smodel->update_table_details('academic_types_tbl',$where = array('id' => $this->request->getPost('id')),$data);
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
            <span class="glyphicon glyphicon-ok"></span> Course Period Updated Successful.</div> ';
    }
    
    function load_reversal_todeposit(){
   $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            
            $data = array(
               'trans' => $this->billingModel->get_item_name2('transaction_numbers_tbl',$where = array('trans_type_id' => 7),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))
            );
            //print_r($data);
            echo view('payment/reversed_receipt_todeposit',$data);
    }

    function view_revesal_todeposit($id){
        $data = array(
               'recpt' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('id' =>$id))
            );
            return view('payment/reversal_todeposit_detailed',$data);
    }
    
   function get_class_admission(){
        $search=$this->request->getPost('search');
        $year=$this->request->getPost('year');
         
        if($search){
           $name=$this->request->getPost('name');
           $name=trim($name);
       $name_parts = explode(" ", $name);
        $clas=$this->reportsModel->class_list_byname($name_parts,count($name_parts),$year);
      
        if(count($clas)==1){
        $sadm =$clas;
       

        }else{
            if(count($clas) >0){
           echo "Please search one among of these:-";
            echo '</br>';
           foreach($clas as $as){
            echo $as->full_name;
            echo '</br>';
           }
            }else{
            echo 'No results found';
            }
            return;
         
        }

        }else{

        $classId=$this->request->getPost('class');
        $sadm = $this->smodel->gettable_data('admission_tbl', $where = array('academic_year'=>$year,'class_id'=>$classId));
         $clas = $this->smodel->gettable_data('classes_tbl', $where = array('id'=>$classId,'status' => 1));
        }
        
       $data=array(
          'year'=>$this->request->getPost('year'),
          
          'sadm'=>$sadm,
          'clas'=>$clas,
        );
       echo view('admission/forms/class_admission_list',$data);  
    } 

     function save_notshow_students(){
        $adm_id=$this->request->getPost('selected');
        $batch_no=$this->generate_notshow_no();
    foreach($adm_id as $id){
               $data = [
                    'adm_id' =>$id,
                    'batch_no ' => $batch_no,
                    'class' => $this->request->getPost('class'),
                    'academic_year' => $this->request->getPost('Academic_year'),
                    'date_created' => date('Y/m/d H:i:s'),
                    'created_by ' =>  $this->request->getPost('header_id'),
                 ];
               // print_r($data);
         $this->amodel->SaveDetails('student_not_show_tbl',$data);
        
         $data2 = [
                    'status' => 6
                ];

            $sid=$this->request->getPost('sid'.$id);
               $this->smodel->update_table_details('students',$where = array('id' => $sid),$data2); 
               
          $this->smodel->update_table_details('admission_tbl',$where = array('id' => $id),$data2); 
               echo '1';

               $stn = $this->smodel->gettable_data('students',$where = array('id' => $sid)); 
                  $msg = "Dear ".$stn[0]->first_name.", You have been marked as Absconded from school effectively from abscod date. If this is a mistake please call 0755266243.";
   //****invoice msg setup*************************************//
          $phone = $this->smodel->gettable_billingdata($sid);
        
        $messagex="Dear Student fName, You have been marked as Absconded from school effectively from abscod date. If this is a mistake please call 0755266243.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 2,
                    'message_type' => 11,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $sid
                  
                );
     if(count($phone)>0){
 //$this->smodel->SaveData('message_groups_tbl',$smsdata);

   //$this->SMSsender($phone[0]->phone1,$msg,10,$sid,$snn,NULL);
      }
     }
    }

     public function generate_notshow_no()
    {
        $ino = "";
        $col="batch_no";
    $builder = $this->db->table('student_not_show_tbl');
     $builder->select('max('.$col.') as max_id');
     $tkens=$builder->get()->getResult();
        if (($tkens[0]->max_id) > 0) {
            //print_r($tkens);
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
    
        return $ino;
    }

    function get_notshow_students(){
         $data=array(
          'year'=>$this->request->getPost('year'),
          'class'=>$this->request->getPost('class')
        );
       echo view('admission/forms/student_notshow_list',$data); 
    }

 function view_notShow($yr,$class,$ent){
        $data = array(
               'year' =>$yr,
               'class' =>$class,
               'ent' =>$ent,
            );
         echo view('admission/forms/notshow_view',$data);
    }

    function edit_notshow($yr,$class,$ent){
        $data = array(
               'year' =>$yr,
               'class' =>$class,
                'ent' =>$ent,
            );
         echo view('admission/forms/notshow_edit',$data);
    }

    function delete_notshow($yr,$class,$iid,$ent){
          $items = $this->smodel->gettable_data('student_not_show_tbl',$where = array('id' => $iid));
           $adm = $this->smodel->gettable_data('admission_tbl',$where = array('id' => $items[0]->adm_id));
       $data2 = [
                    'status' => 2
                ];

        $this->smodel->update_table_details('students',$where = array('id' => $adm[0]->student_id),$data2);
          $data2 = [
                    'status' => 1
                ];
          $this->smodel->update_table_details('admission_tbl',$where = array('id' => $items[0]->adm_id),$data2); 
        $this->smodel->deletetable_data1('student_not_show_tbl',$iid); 

            $data = array(
               'year' =>$yr,
               'class' =>$class,
               'ent' =>$ent,
            );
         echo view('admission/forms/notshow_edit',$data);
    }
    
     function get_class_admission_fortransfer(){
       $data=array(
          'year'=>$this->request->getPost('year'),
          'classId'=>$this->request->getPost('class')
        );
       echo view('admission/forms/class_admissionForTransfer_list',$data);  
    }

    function save_transfer_students(){
$adm_id=$this->request->getPost('selected');
        $batch_no=$this->generate_transfer_batch();
    foreach($adm_id as $id){
               $data = [
                    'adm_id' =>$id,
                    'batch_no ' => $batch_no,
                    'class' => $this->request->getPost('class'),
                    'academic_year' => $this->request->getPost('Academic_year'),
                    'date_created' => date('Y/m/d H:i:s'),
                    'created_by ' =>  $this->request->getPost('header_id'),
                 ];
               // print_r($data);
         $this->amodel->SaveDetails('transfered_students_tbl',$data);
        
         $data2 = [
                    'status' => 3
                ];

            $sid=$this->request->getPost('sid'.$id);
               $this->smodel->update_table_details('students',$where = array('id' => $sid),$data2); 
                
          $this->smodel->update_table_details('admission_tbl',$where = array('id' => $id),$data2); 
               echo '1';
 
     }
    }

     public function generate_transfer_batch()
    {
        $ino = "";
        $col="batch_no";
    $builder = $this->db->table('transfered_students_tbl');
     $builder->select('max('.$col.') as max_id');
     $tkens=$builder->get()->getResult();
        if (($tkens[0]->max_id) > 0) {
            //print_r($tkens);
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
    
        return $ino;
    }

    function get_transfered_students(){
         $data=array(
          'year'=>$this->request->getPost('year'),
          'class'=>$this->request->getPost('class')
        );
       echo view('admission/forms/student_transfered_list',$data); 
    }

    function view_transfered($yr,$class,$ent){
        $data = array(
               'year' =>$yr,
               'class' =>$class,
               'ent' =>$ent,
            );
         echo view('admission/forms/transfered_view',$data);
    }

    function edit_transfered($yr,$class,$ent){
        $data = array(
               'year' =>$yr,
               'class' =>$class,
                'ent' =>$ent,
            );
         echo view('admission/forms/transfered_edit',$data);
    }
     function delete_transfered_students($yr,$class,$iid,$ent){
          $items = $this->smodel->gettable_data('transfered_students_tbl',$where = array('id' => $iid));
           $adm = $this->smodel->gettable_data('admission_tbl',$where = array('id' => $items[0]->adm_id));
       $data2 = [
                    'status' => 2
                ];

        $this->smodel->update_table_details('students',$where = array('id' => $adm[0]->student_id),$data2);
          $data2 = [
                    'status' => 1
                ];
          $this->smodel->update_table_details('admission_tbl',$where = array('id' => $items[0]->adm_id),$data2); 
        $this->smodel->deletetable_data1('transfered_students_tbl',$iid); 

            $data = array(
               'year' =>$yr,
               'class' =>$class,
               'ent' =>$ent,
            );
         echo view('admission/forms/transfered_edit',$data);
    }
    
    function load_deposit_toreverse(){
     echo view('admission/forms/reverse_other_deposit');
    }

     function search_transaction3(){
        $search = $this->request->getPost('payer_name');
        //echo $search;
         $result=$this->amodel->get_student_details('transaction_numbers_tbl', $where = array('trans_number' =>$search,'trans_type_id' =>3));
            //print_r($result);
              if(count($result) > 0){
              $amt=$this->amodel->get_student_details('ledger_transaction_tbl', $where = array('trans_no' =>$search,'trans_type' =>3,'transation_nature'=>1));
              $lg=$this->amodel->get_student_details('ledger_transaction_tbl', $where = array('trans_no' =>$search,'trans_type' =>3,'ledger_type'=>9));
              $accname=$this->amodel->get_student_details('accounts_tbl', $where = array('id' =>$lg[0]->ledger_id));
               $stname=$this->amodel->get_student_details('students', $where = array('id' =>$amt[0]->name_id));

           echo '<div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Deposit No</label>
                <div class="col-sm-8">
                  <input type="text" readonly  class="form-control"  value="'.$search.'" name="deposit_number" id="deposit_number">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Student Name</label>
                <div class="col-sm-8">
                 <input type="hidden" class="form-control"  value="'.$stname[0]->id.'" name="student_from" id="student_from">
                  <input type="text" readonly class="form-control"  value="'.$stname[0]->full_name.'">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Deposit Amount</label>
                <div class="col-sm-8">
                 <input type="hidden" readonly class="form-control"  value="'.$amt[0]->amount.'" id="deposit_amount">
                  <input type="text" readonly class="form-control"  value="'.number_format($amt[0]->amount).'">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Ledger Name</label>
                <div class="col-sm-8">
                 <input type="hidden" class="form-control"  value="'.$accname[0]->id.'" name="from_ledger" id="from_ledger">
                  <input type="text" readonly class="form-control"  value="'.$accname[0]->account_name.'">
                </div>
                </div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Reverse Amount<span class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="number" class="form-control"  value="" onkeyup="enter_amount()" name="amount" id="i_amount">
                </div>
                </div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Reason</label>
                <div class="col-sm-8">
                  <textarea class="form-control"  value="" name="reason" id="reason"></textarea>
                </div>
                </div>';
              
            
        }else{
          echo "<span style='color:red'>No any receipt Found</span>";
        }
    
    }
    
    function createControl_number_crdb_admission($total_cost,$student_id,$transNo,$type,$des,$alw,$customer_type,$year,$class,$hst){

        if($alw==0){
            $a='FIXED';
        }else{
           $a='FLEXIBLE'; 
        }
        
        if($customer_type==6){
          $student_details = $this->smodel->gettable_data('other_students_tbl',$where = array('id' => $student_id));
        }else{
         $student_details = $this->smodel->gettable_data('students',$where = array('id' => $student_id));   
        }
         
         //$desc=$total_cost.' is '.$des.' and '.$charge.' is bank charges';
       
         $db_id=$this->request->getPost('db_id');
if($db_id==1)
{
            $charge=1180;
            $desc=$des.' : '.$total_cost.' </br> Bank charges : '.$charge;
         if($type==3){
            $curl=base_url().CRDB_CALLBACK_DEPOSIT_1;
         }elseif($customer_type==6){
            $curl=base_url().ALIENS_1;
         }else{
            $curl=base_url().CRDB_CALLBACK_1; 
         }
           $facility_id=FACILITY_ID_1;
         $payment_type=PAYMENT_TYPE_1;
         $prefix=PREFIX_1;
         $crdb_url=CRDB_URL_1;
}
elseif($db_id==4)
{

            $charge=0;
            $desc=$des.' : '.$total_cost.' </br> Bank charges : '.$charge;
         if($type==3){
            $curl=base_url().CRDB_CALLBACK_DEPOSIT_4;
         }elseif($customer_type==6){
            $curl=base_url().ALIENS_4;
         }else{
            $curl=base_url().CRDB_CALLBACK_4; 
         }
           $facility_id=FACILITY_ID_4;
         $payment_type=PAYMENT_TYPE_4;
         $prefix=PREFIX_4;
         $crdb_url=CRDB_URL_4;
}elseif($db_id==5)
     {
             $time=date('Y-m-d H:i:s'); 
            $msg = "Kumb No: ---, Tarehe: ".$time.", Kiasi:TZS ".number_format($total_cost).", Mwanafunzi: ".$student_details[0]->full_name.".". "Ada.";
              $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname. Ada.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => $type,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>$this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $transNo
                  
                );
      
 $this->smodel->SaveData('message_groups_tbl',$smsdata);

      $this->SMSsender($phone,$msg,$type,$student_id,$snn,NULL);
      echo json_encode(array('status' =>1,'statusDesc' => 'save successfully.'));
    return;
   }
else{
    echo json_encode(array('status' =>1,'statusDesc' => 'saved successfully.'));
    return;
   }
          $data=array(
            'name' =>$student_details[0]->full_name,
            'receipt_no' => $transNo,
            'amount' => $total_cost+$charge,
            'currency' => 'TZS',
            'payment_desc' => $desc,
            'visit_no'=>$student_id,
            'file_no'=>$student_id,
            'payment_channel' => 1,
            'facility_id' => $facility_id,
            'payment_type' => $payment_type,
            'prefix' => $prefix,
            'call_back_url' => $curl,
            'allow_partial' => $a

        );

          //print_r(json_encode($data));
  file_put_contents('Apifeedback/req_crdb' . $transNo. '.txt', json_encode($data));
    $url = $crdb_url."createPayment";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
           
                $response = curl_exec($ch);
                //echo $response;
                $err = curl_error($ch); 
                curl_close($ch);

                 if ($err) {
                    //echo "Error #:" . $err;
                    $status = 5;
                    $reference=0;
                     $time=date('Y-m-d H:i:s');

                     echo json_encode(array('status' =>1,'statusDesc' => ' Control Number Not Created Successful.'));
                } else {
                   
                    $obj2 = json_decode($response,TRUE);
                    if($obj2['status']=='success'){
                      $status = 1;
                    }else{
                       $status = 2;
                    }
                    $time=$obj2['date_created'];
                    
                    $reference= $obj2['paymentReference'];
                
                $crdb_data = array(
                    'trans_no' =>  $transNo,
                    'student_id' =>  $student_id,
                    'reference_no' => $reference,
                    'amount' => $total_cost,
                    'charges' => $charge,
                    'payment_status' => 0,
                    'payment_channel' => 3, //CRDB
                    'date_created' => $time,
                    'allow_partial' => $alw,
                    'trans_type' => $type,
                     'academic_year' => $year
                 );
            //print_r($crdb_data);
     $this->amodel->SaveDetails('payment_request',$crdb_data);

     //mmmmmmmmmmmmmm installments placed here mmmmmmmm//
      
        $semister = $this->smodel->gettable_data('school_terms_tbl',$where = array('academic_year' => $year));
        $time=date('Y-m-d H:i:s'); 
            $msg = "Kumb No: ".$reference.", Tarehe: ".$time.", Kiasi:TZS ".number_format($total_cost).", Mwanafunzi: ".$student_details[0]->full_name.".". "Ada ".$year."";
       if(count($semister)>0){
        // $msg=$this->generate_installment_msg($transNo,$year,$class,$hst,$reference,$student_id);  
    }else{
         $time=date('Y-m-d H:i:s'); 
            $msg = "Kumb No: ".$reference.", Tarehe: ".$time.", Kiasi:TZS ".number_format($total_cost).", Mwanafunzi: ".$student_details[0]->full_name.".". "Ada ".$year."";
       
    }
       
   //*******invoice msg setup*************************************//
                 $phone=0;
                 if($customer_type==6){
                
                $bill = $this->smodel->gettable_data('other_students_tbl',$where = array('id' => $student_id));
                
                 if(count($bill)>0){
                $phone=$bill[0]->phone;
                  }
                 }else{
                $bill = $this->smodel->gettable_billingdata($student_id);
                if(count($bill)>0){
                $phone=$bill[0]->phone1;
                  }
                 }
        
        
        $messagex="#first_name, Kumb No: xxx, 1st - nnn/- kabla ya Y-m-d, 2nd - nnn/- kabla ya Y-m-d, 3rd - nnn/- kabla ya Y-m-d. Ada Y.";
      $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => $type,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>$this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $transNo
                  
                );
      if($db_id !=4){
 $this->smodel->SaveData('message_groups_tbl',$smsdata);

      $this->SMSsender($phone,$msg,1,$student_id,$snn,NULL);
      }
     
    //****end msg invoice setup**********************************// 
    
       $student_name=$student_details[0]->full_name;
        echo json_encode(array('status' =>1,'statusDesc' => 'Student '.$student_name.' Control Number <b>'.$reference.'</b> Created Successful.'));
  }
    }
    
    function fix_status(){
     $load5 = $this->smodel->gettable_data('absconding_tbl',$where = array('id >' => 0));
     $load6 = $this->smodel->gettable_data('student_not_show_tbl',$where = array('id >' => 0));
     $load4 = $this->smodel->gettable_data('graduation_tbl',$where = array('id >' => 0));
     $load3 = $this->smodel->gettable_data('transfered_students_tbl',$where = array('id >' => 0));
     if(count($load5)>0){
        foreach($load5 as $l){
         $data=array(
             'status'=>5
         );

  $this->smodel->update_table_details('admission_tbl',$where = array('id' => $l->adm_id),$data);
        }
     }elseif(count($load4)>0){
  foreach($load4 as $l){
         $data=array(
             'status'=>4
         );

  $this->smodel->update_table_details('admission_tbl',$where = array('id' => $l->adm_id),$data);
        }
      
     }elseif(count($load3)>0){
  foreach($load3 as $l){
         $data=array(
             'status'=>3
         );

  $this->smodel->update_table_details('admission_tbl',$where = array('id' => $l->adm_id),$data);
        }
      
     }elseif(count($load6)>0){
  foreach($load6 as $l){
         $data=array(
             'status'=>6
         );

  $this->smodel->update_table_details('admission_tbl',$where = array('id' => $l->adm_id),$data);
        }
      
     }
   echo "computed successfully";  
   
}

function fetch_admission_byname(){
     $name=$this->request->getPost('name');
        $name=trim($name);
       $name_parts = explode(" ", $name);
        // print_r($name_parts);
        // return;
      //echo $name;
       $year=$this->request->getPost('year');
       $data['year']=$this->request->getPost('year');
       $data['search']=2;
     
            $data['admission']=$this->smodel->admission_byname($name_parts,count($name_parts),$year);
            //print_r($data);
           
       echo view('student/forms/student_adimitted_list',$data);  
}

 public function generate_installment_msg($transNo,$year,$class,$hst,$reference,$student_id)
    {
        helper('calc');
        $dbname=session()->get('db_name');
        $results=findCalc($student_id,$dbname,$year);
         $level = $this->billingModel->get_item_name('classes_tbl', $where = array('id' => $class));
         $period = $this->billingModel->get_item_name('class_level_tbl', $where = array('id' => $level[0]->class_level));
     $message = "";
    
                $mbalance1=0;
                  $mbalance2=0;
                  $mbalance3=0;

                     $dateterm = $this->reportsModel->checkTerm_date(date('Y-m-d'),$year,$period[0]->academic_type);
                  //print_r($dateterm);
                    if (is_countable($dateterm) && count($dateterm) > 0) {
                    $term_name=$dateterm[0]->term_name;
                   }else{
                    $dateterm = $this->reportsModel->checkTerm_date2(date('Y-m-d'),$year,$period[0]->academic_type);
                     
                     $term_name=$dateterm[0]->term_name;
                   }
                  
                   $installments = $this->billingModel->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$period[0]->academic_type));
                    
                    $ttlAmount = 0;
                     $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                      $ddate="";
                   
                    foreach ($installments as $r) {
                        // $paid_amount=0;
                        
                  $i++;
                     
                     if($i==1){
                    
                         $duedate1=$r->due_date;
             
                   $openingbalance=$results[0]['openingbalance'];
                       $ment=$results[0]['ment'];
                        $mbalance1=$ment;
                        $mbalance=$results[0]['mbalance'];
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[0]['today']==1){
                       $todaybalance=$results[0]['todaybalance']; 
                     }
                    }
                      if($i==2){
               
                  $duedate2=$r->due_date;
           
                         $ment=$results[1]['ment'];
                        $mbalance2=$ment;
                        $mbalance=$results[1]['mbalance'];
                        $paid_amount=$results[1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[1]['today']==1){
                       $todaybalance=$results[1]['todaybalance']; 
                     }  
                     }
                   if($i==3){
                    $duedate3=$r->due_date;
         
                     $ment=$results[2]['ment'];
                        $mbalance3=$ment;
                        $mbalance=$results[2]['mbalance'];
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[2]['today']==1){
                       $todaybalance=$results[2]['todaybalance']; 
                     }
                     }
                     
                       if($i==4){
                    $duedate3=$r->due_date;
         
                     $ment=$results[3]['ment'];
                        $mbalance3=$ment;
                        $mbalance=$results[3]['mbalance'];
                        $paid_amount=$results[3]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[3]['today']==1){
                       $todaybalance=$results[3]['todaybalance']; 
                     }
                     }
                    
                      } 
           $st_details = $this->billingModel->get_item_name('students',$where=array('id'=>$student_id));
           if($i==2){
               $message=$st_details[0]->first_name.", Kumb No ".$reference.", 1st - ".number_format($mbalance1)."/- kabla ya ".date('Y-m-d',strtotime($duedate1)).", 2nd - ".number_format($mbalance2)."/- kabla ya ".date('Y-m-d',strtotime($duedate2))." . Ada ".$year.".";  
           }else{
            $message=$st_details[0]->first_name.", Kumb No ".$reference.", 1st - ".number_format($mbalance1)."/- kabla ya ".date('Y-m-d',strtotime($duedate1)).", 2nd - ".number_format($mbalance2)."/- kabla ya ".date('Y-m-d',strtotime($duedate2)). ", 3rd- ".number_format($mbalance3)."/- kabla ya ".date('Y-m-d',strtotime($duedate3)).". Ada ".$year.".";    
           }
                
        return $message;
    }
 // just end   
}
