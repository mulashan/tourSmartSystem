<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UsersModel;
use App\Models\LoginModel;
use App\Models\StudentModel;

class UsersController extends BaseController{

    public $usermodel;
    public $smodel;
    public function __construct(){
        
         if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
        $dbname=session()->get('db_name');
        $this->usermodel = new UsersModel();
         $this->smodel = new StudentModel();
		$this->db=\Config\Database::connect($dbname);

    }

    function users(){

        $usermodel = new UsersModel();
        $data['usertype'] = $usermodel->getUsertypeList();
        $data['users'] = $usermodel->getUsers(session()->get('db_id'));
        return view('templates/header')
        .view('users/users_pg', $data)
        .view('templates/footer');
    }

    function users_type(){
		 $usermodel = new UsersModel();
		$data['users']=$this->usermodel->GetAllUserType();
        return view('templates/header')
        .view('users/user_type_page',$data)
        .view('templates/footer');
    } 


    public function saveUserType()
    {
 $UserTypeValidation=( [
		'utype' =>[
		'label'=>'Type',
		'rules'=>'required|is_unique[users_type_tbl.type_name]',
		'errors'=>[
		'required'=>'Enter User Typetype',
		'is_unique'=>'This Kind Of User Type Exist'
		
		],
		],
		'udesc' =>[
		'label'=>' Description',
		'rules'=>'required',
		'errors'=>[
		'required'=>'User Description Can Not Be Empty'
		],
		],
		
		
		
	]
	
	);
		if($this->validate($UserTypeValidation)){
        $usermodel = new UsersModel();
        $data = [
            'type_name' => ucfirst($this->request->getPost('utype')),
            'description' => ucfirst($this->request->getPost('udesc'))
        ];
        $usermodel->saverecords($data);
        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
                <span class="glyphicon glyphicon-ok"></span> New User Added Successfully.</div> ';
			}
	
			else{
				
				echo '<div class="alert alert-danger alert-dismissible" role="alert" style="width:60%">'.$this->validation->listErrors();'</div>';
			}
			
	}

    public function add_new_users()
    {
		$usermodel = new UsersModel();

                $img = $this->request->getFile('photo');
                    $img_name = "";
                    if($img->isValid() && !$img->hasMoved()){
                        $img_name = time().$img->getName();
                        $img->move(ROOTPATH.'public/users_photos/',$img_name); 
                    }
    $database_id=$this->request->getPost('inst');
$where_data1 = [
    'phone_no' =>$this->request->getPost('phone'),
    'birth_date' =>$this->request->getPost('dob')
];
$where_data2 = [
    'phone_no' =>$this->request->getPost('phone')
];
$where_data3 = [
    'birth_date' =>$this->request->getPost('dob'),
    'first_name' => ucfirst($this->request->getPost('first_name'))
];
 $user_exits=$usermodel->Check_user_existance($where_data1,$where_data2,$where_data3,$database_id);
 if (!empty($user_exits) && count($user_exits)>0) {
return $this->response->setJSON(['status'=>2]);
} else {
                             $data = [
            'first_name' => ucfirst($this->request->getPost('first_name')),
            'last_name' => ucfirst($this->request->getPost('last_name')),
            'other_name' => ucfirst($this->request->getPost('other_name')),
            'phone_no' => $this->request->getPost('phone'),
            'gender' => $this->request->getPost('gender'),
            'national_id' => $this->request->getPost('national_id'),
            'email' => $this->request->getPost('email'),
            'user_type' => $this->request->getPost('user_type'),
            'user_photo'=>$img_name,
            'physical_adress' => $this->request->getPost('physical_adress'),
            'staff' => $this->request->getPost('staff'),
            'birth_date' => $this->request->getPost('dob'),
            'registar' => session()->get('user_id'),
            'database_id' => $this->request->getPost('inst'),
            'updated_date' => date('Y/m/d H:i:s')
        ];

    $user_id=$usermodel->addNewUser2($data);
if(!empty($user_id)){
    $dbname=$usermodel->get_details('database_list_tbl',$where = array('db_id' =>$this->request->getPost('inst')));

    $data = [
            'user_id'=>$user_id,
            'first_name' => ucfirst($this->request->getPost('first_name')),
            'last_name' => ucfirst($this->request->getPost('last_name')),
            'other_name' => ucfirst($this->request->getPost('other_name')),
            'phone_no' => $this->request->getPost('phone'),
            'gender' => $this->request->getPost('gender'),
            'national_id' => $this->request->getPost('national_id'),
            'email' => $this->request->getPost('email'),
            'user_type' => $this->request->getPost('user_type'),
            'user_photo'=>$img_name,
            'physical_adress' => $this->request->getPost('physical_adress'),
            'staff' => $this->request->getPost('staff'),
            'birth_date' => $this->request->getPost('dob'),
            'database_id' => $this->request->getPost('inst'),
            'updated_date' => date('Y/m/d H:i:s')
        ];
    $user_id=$usermodel->addNewUser($data,$dbname[0]->db_name);
             if( $this->request->getPost('staff')==1 && $user_id !=0){
                 $staff_data = [
            'user_id' => $user_id,
            'dep_id' => 0, 
            'job_id' => 0,  
            'basic_salary' => 0,  
            'allowances' => 0,  
            'contract_expiry_date' => Date('Y-m-d H:i:s'),  
            'account_number' =>0,  
             'pension_no' => 0,  
            'tin_no' => 0, 
            'heslb_no' =>0, 
            'nhf_no' => 0,  
            'wcf_no' =>0,  
            'account_name' => '',  
            'status' => 1,
            'bank_name' => 0,  
            'created_by' =>session()->get('user_id'),  
            'created_on' => Date('Y-m-d H:i:s'),  
            'employment_type' => 0,  
            'residential_status' => 0,  
            'classfication_id' => 0  
          
        ];
           
     $this->smodel->SaveData('staff_details_tbl',$staff_data);
        }
        $username='ELC0'.$user_id;
        $pswd=$this->request->getPost('last_name');
		$password= password_hash($pswd, PASSWORD_DEFAULT);
        
	    if($user_id !=0){
                    $data1=[
        'initial_username'=>$username,
        'username'=>$username,
        'password'=>$password,
        'user_id'=>$user_id,
        'user_status'=>1,
        'last_login'=>date('Y/m/d H:i:s'),
        'updated'=>1,
        ];
        }

    
    
     $usermodel->LoginDetails2($data1);
     $usermodel->LoginDetails($data1,$dbname[0]->db_name);

     
     echo 'Your Username: '.$username.' and password: '.$pswd;
   }else{
    return $this->response->setJSON(['status'=>3]);
   }
   }}
	
	public function edit_user_type($id)
    {

        $data['user_info'] = $this->usermodel->user_inf($id);
        $data['setting'] = $this->usermodel->user_settings($id);
        $list_assign = $this->usermodel->user_settings($id);
        $list_assigned = array(0);
        if (count($list_assign) > 0) {
            foreach ($list_assign as $row) {
                array_push($list_assigned, $row->module_id);
            }
        }
        $data['unassigned_priv'] = $this->usermodel->list_unassigned_privileges($id, $list_assigned);
       return view('templates/header')
        .view('users/user_type_edit',$data)
        .view('templates/footer');
    }
	public function deleteUser($id)
    {
$this->usermodel->deleteUser($id);
        	
    }
	public function editUser()
    {
        //$id = $this->request->getVar('ids');
		$id=$this->request->uri->getSegment(2);
        $data['user'] = $this->usermodel->get_User($id);
        $data['setting'] = $this->usermodel->user_settings($this->request->uri->getSegment(3));
        //$data['ses'] = $this->usermodel->get_session($id);
       echo view('users/forms/manage_user',$data);
    }
	
	public function DeleteUserType(){
		   $usermodel = new UsersModel();
		$id=$this->request->getPost('id');
		if($this->usermodel->DeleteUserType($id)){
			return redirect()->to('/users_type');
			
		}
	}
	public function UpdateUser(){
		 $usermodel = new UsersModel();
		 $id=$this->request->getPost('id');
		 $data = [
            'type_name' => ucfirst($this->request->getPost('utype')),
            'description' => ucfirst($this->request->getPost('udesc'))
        ];
		 if($this->usermodel->UpdateUserType($id,$data)){
			return redirect()->to('/users_type');
			
		}
	}
	
	
	public function userEdit()
        {
			$img = $this->request->getFile('photo');
          $img1 = $this->request->getPost('photo1');
                 if($img!=""){
                    $img_name = "";
                    if($img->isValid() && !$img->hasMoved()){
                        $img_name = time().$img->getName();
                        $img->move(ROOTPATH.'public/users_photos/',$img_name); 
                    }
                    }
                    else{
                      $img_name=time().$img1;  
                    }
			$id=$this->request->getPost('user_id');
			$data = [
            'first_name' => ucfirst($this->request->getPost('first_name')),
            'last_name' => ucfirst($this->request->getPost('last_name')),
            'other_name' => ucfirst($this->request->getPost('other_name')),
            'phone_no' => $this->request->getPost('phone'),
            'gender' => $this->request->getPost('gender'),
            'national_id' => $this->request->getPost('national_id'),
            'email' => $this->request->getPost('email'),
            'user_type' => $this->request->getPost('user_type'),
            'status' => $this->request->getPost('status'),
            'user_photo' => $img_name,
            'physical_adress' => $this->request->getPost('physical_adress'),
            'staff' => $this->request->getPost('staff2'),
            'birth_date' => $this->request->getPost('dob2'),
            'updated_date' => date('Y/m/d H:i:s')
        ];
         $data_s=[
           'user_status'=>$this->request->getPost('status'),
        ];
        // echo $id;
        // print_r($data_s);
         $this->usermodel ->userEdit($id,$data,$data_s);
          if(session()->get('db_id')!=1){
         $this->usermodel->update_users_1($id, $data,'default','users',$data_s); 
            }
             $present=$this->smodel->gettable_data('staff_details_tbl',$where = array('user_id' => $id));
            if( $this->request->getPost('staff2')==1){
              $data2 = [
            'user_id' => $this->request->getPost('user_id'),
            'dep_id' => 0, 
            'job_id' => 0,  
            'basic_salary' => 0,  
            'allowances' => 0,  
            'contract_expiry_date' => Date('Y-m-d H:i:s'),  
            'account_number' =>0,  
             'pension_no' => 0,  
            'tin_no' => 0,  
            'nhf_no' => 0,  
            'wcf_no' =>0,  
            'account_name' => '',  
            'bank_name' => 0,
            'created_by' =>session()->get('user_id'),  
            'created_on' => Date('Y-m-d H:i:s'),  
            'employment_type' => 0, 
            'status' => 1,
            'residential_status' => 0,  
            'classfication_id' => 0  
          
        ];
             if(count($present)==0){
     $this->smodel->SaveData('staff_details_tbl',$data2);
        }
            }
                
            echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span> Updated Successfully.</div> ';
       // return redirect()->to( base_url('accomodation') )->with('msg', 'Accomodation updated Successfully');
		 $this->session ->setFlashdata('msg','
		 <div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span> Updated Successfully.</div>');
		 }
		
		public function asssign_privileges()
    {
 $id =$this->request->uri->getSegment(2);
 $mo =$this->request->uri->getSegment(3);
  $add_menu = array(
            'privilege_id' => $mo,
            'module_id' => $id,
        );
       if($this->usermodel ->assign_menu($add_menu)){
		$this->session ->setFlashdata('msg','Added Successfully');
	   }else{
		 $this->session ->setFlashdata('error','Not Added Successfully');  
	   }
        return redirect()->to( base_url().'/edit_user_type/'.$mo);
        		
    }
	
	
		public function remove_privilege()
    {
 $modid =$this->request->uri->getSegment(2);
 $usetype =$this->request->uri->getSegment(3);
  
       if($this->usermodel ->remove_menu($modid,$usetype)){
		$this->session ->setFlashdata('msg','Removed Successfully');
	   }else{
		 $this->session ->setFlashdata('error','Not Removed Successfully');  
	   }
        return redirect()->to( base_url().'/edit_user_type/'.$usetype);
        		
    }
	
		public function remove_usertype()
    {
      
      $usetype =$this->request->uri->getSegment(2);
        $check=$this->usermodel ->check_usertype($usetype);
		 if(count($check)>0){
			 echo '1';
			//$this->session ->setFlashdata('error','Can not remove this user type. First you must remove all users assigned to this user type'); 
		         //return redirect()->to( base_url().'/users_type');
		 }else{
       if($this->usermodel ->remove_usertype($usetype)){
		$this->session ->setFlashdata('msg','Removed Successfully');
	   }else{
		 $this->session ->setFlashdata('error','Not Removed Successfully');  
	   }
     return redirect()->to( base_url().'/users_type');
	}  		
    }
function unassgnd_permissions()
    {
        $list_assign = $this->usermodel->user_settings_all($this->request->uri->getSegment(2),$this->request->uri->getSegment(3));
        $list_assigned = array();
        if (($list_assign) > 0) {
            foreach ($list_assign 
			as $row) {
                array_push($list_assigned, $row->module_id);
            }
        }
        $unassigned_priv = $this->usermodel->list_unassigned_privileges($this->request->uri->getSegment(2), $list_assigned);
        if (($unassigned_priv) > 0) {
            $sn = 0;
            echo '<table class="table table-bordered">
                            <tr>
                                <th>S/N</th>
                                <th>Module name</th>
                                <th>Descriptions</th>
                                <th>&nbsp;</th>
                            </tr>';
            foreach ($unassigned_priv as $ass_priv) {
                $sn++;
                echo '<tr>';
                echo '<td>' . $sn . '</td>';
                echo '<td>' . $ass_priv->label . '</td>';
                echo '<td>' . $ass_priv->description . '</td>';
                echo "<td><center><a href=\"javascript:void()\" onclick=\"AssgnSpecialModule('" . $ass_priv->module_id . "')\" title=\"Assign this Module\"><span class=\"fa fa-plus\"></span></a></center></td>";
                echo '</tr>';
            }
            echo '</table';
        } else {
            echo 'No unassigned module.';
        }
    }
	
	function load_special_permissions()
    {
        $sps = $this->usermodel->user_settings($this->request->uri->getSegment(2));
        if (($sps) > 0) {
            $sn = 0;
            echo '<table class="table table-bordered">
                            <tr>
                                <th>S/N</th>
                                <th>Module name</th>
                                <th>Descriptions</th>
                                <th>&nbsp;</th>
                            </tr>';
            foreach ($sps as $sp) {
                $sn++;
                echo '<tr>';
                echo '<td>' . $sn . '</td>';
                echo '<td>' . $sp->label . '</td>';
                echo '<td>' . $sp->description . '</td>';
                echo "<td><center><a href=\"javascript:void()\" onclick=\"UnassgnSpecialModule('" . $sp->module_id . "')\" title=\"Unassign this Module\"><span class=\"fa fa-minus\"></span></a></center></td>";
                echo '</tr>';
            }
            echo '</table';
        } else {
            echo 'No special permission assigned.';
        }
    }
function add_special_permissions()
    {
        $add_menu = [
            'privilege_id' => $this->request->getPost('user'),
            'module_id' => $this->request->getPost('modl'),
        ];
		
        $this->usermodel->assign_menu($add_menu);

    }
function remove_special_permissions()
    {
        $this->usermodel->remov_user_priv($this->request->getPost('user'), $this->request->getPost('modl'));

        
    }
function password_reset()
    {
        $encrptd = password_hash($this->request->getPost('nwpswd'), PASSWORD_DEFAULT);

        $changes = array(
            'password' => $encrptd,
             'updated'=>1,
        );
        //print_r($changes);
      //  $this->usermodel->update_users($this->request->getPost('pid'), $undata);
       
        $this->usermodel->change_pass($this->request->getPost('pid'), $changes);
             $this->usermodel->change_pass2($this->request->getPost('pid'), $changes);

        echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <span class="glyphicon glyphicon-ok"></span>Password Updated to <b>' . $this->request->getPost('nwpswd') . '</b></div>';
    }
	
	public function profile_Edit()
    {
        //$id = $this->request->getVar('ids');
		$id=$this->request->uri->getSegment(2);
		//$id=session()->get('user_id');
        $data['user'] = $this->usermodel->get_User($id);
        return view('templates/header')
        .view('users/forms/manage_profile',$data)
        .view('templates/footer');
       
    }
	public function profileEdit()
        {
			$img = $this->request->getFile('photo');
          $img1 = $this->request->getPost('photo1');
                 if($img!=""){
                    $img_name = "";
                    if($img->isValid() && !$img->hasMoved()){
                        $img_name = time().$img->getName();
                        $img->move(ROOTPATH.'public/users_photos/',$img_name); 
                    }
                    }
                    else{
                      $img_name=time().$img1;  
                    }

			$id=$this->request->getPost('user_id');
			$data = [
            'first_name' => $this->request->getPost('first_name'),
            'last_name' => $this->request->getPost('last_name'),
            'other_name' => $this->request->getPost('other_name'),
            'phone_no' => $this->request->getPost('phone'),
            'gender' => $this->request->getPost('gender'),
            'national_id' => $this->request->getPost('national_id'),
            'email' => $this->request->getPost('email'),
            'user_type' => $this->request->getPost('user_type'),
            'status' => $this->request->getPost('status'),
            'user_photo' => $img_name,
            'physical_adress' => $this->request->getPost('physical_adress'),
            'updated_date' => date('Y/m/d H:i:s')
        ];
         $this->usermodel ->userEdit($id,$data);
         if(session()->get('db_id')!=1){
         $this->usermodel->update_users_1($id, $data,'default','users'); 
            }
            echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span> Updated Successfully.</div> ';
       // return redirect()->to( base_url('accomodation') )->with('msg', 'Accomodation updated Successfully');
		 $this->session ->setFlashdata('res','
		 <div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span>Profile Updated Successfully.</div>');
		 return redirect()->to( base_url()."/profile_edit/".session()->get('user_id'));
		 }
		  function username_updator()
    {
        
            $undata = array(
                'username' => $this->request->getPost('nwusername')
            );
            $this->usermodel->update_users(session()->get('user_id'), $undata);
            $this->usermodel->update_users2(session()->get('user_id'), $undata);
         //    if(session()->get('db_id')!=1){
         // $this->usermodel->update_users_1(session()->get('user_id'), $undata,'default','users_session_tbl'); 
         //    }
            echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <span class="glyphicon glyphicon-ok"></span>Username Updated to <b>' . $this->request->getPost('nwun') . '</b></div>';
        		 $this->session ->setFlashdata('res','
		 <div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
             <span class="glyphicon glyphicon-ok"></span>Username Updated Successfully.</div>');
		return redirect()->to( base_url()."/profile_edit/".session()->get('user_id'));
    }
	    function password_change()
    {
      $new1= $this->request->getPost('newpass');
      $new2= $this->request->getPost('renewpass');
	  if($new1==$new2){
            $enteredpas = $this->request->getPost('cpass');

            $cpas = $this->usermodel->get_current_pass(session()->get('user_id'));
            $cp = $cpas[0]->password;

            if (password_verify($enteredpas, $cp)) {
                $changes = array( 
                    'password' => password_hash($this->request->getPost('newpass'), PASSWORD_DEFAULT),
                   
                );
             $this->usermodel->change_pass(session()->get('user_id'), $changes);
             $this->usermodel->change_pass2(session()->get('user_id'), $changes);

                $res = '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign"></span> Password Changed Successfully.</div>';
                $this->session->setFlashdata('res', $res);
                return redirect()->to( base_url()."/profile_edit/".session()->get('user_id'));
            } else {
                $res = '<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign"></span> Incorrect Password.</div>';
                $this->session->setFlashdata('res', $res);
                return redirect()->to( base_url()."/profile_edit/".session()->get('user_id'));
            }
            }else{
			$res = '<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign"></span>Password do not match</div>';
                $this->session->setFlashdata('res', $res);
                return redirect()->to( base_url()."/profile_edit/".session()->get('user_id'));	
			}
        
    }

    function check_username(){
        $username=$this->request->getPost('username');
        $check=$this->usermodel->checkUsername($username);
        if($check){
            echo 1;
        }else{
            echo 0;
        }
    }
    
    public function asssign_selected_privileges()
    {

 $module =$this->request->getPost('selected');
 $privilege_id =$this->request->getPost('user_type_id');
 foreach($module as $id){
    $add_menu = array(
            'privilege_id' => $privilege_id,
            'module_id' => $id,
        );
    $this->usermodel ->assign_menu($add_menu);
 }
 
 //$this->session ->setFlashdata('msg','Added Successfully');
 echo $privilege_id;
  //return redirect()->to( base_url().'/edit_user_type/'.$privilege_id);
                
    }

    function unasssign_selected_privileges(){
      
 $module =$this->request->getPost('selected');
 $usetype =$this->request->getPost('user_type_id2');
 foreach($module as $modid){
    
    $this->usermodel ->remove_menu($modid,$usetype) ;
 }
echo $usetype;
    }
    
   
	
}
?>