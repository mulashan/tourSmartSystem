<?php 
namespace App\Controllers;
use App\Controllers\BaseController;
use App\Models\BillModel;
use App\Models\StudentModel;
use App\Models\SystemModel;
use App\Models\BillingModel;
  use App\Models\StaffModel;
use Config\Mimes;
class BillController extends BaseController
{
	public $dbname;
	 public $smodel;
	 public $billmodel;
	   public $staffmodel;
	public function __construct(){
	     if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
        $this->smodel = new StudentModel();
		$this->billmodel = new BillModel();
		$this->studentModel = new StudentModel();
        $this->sytm_model = new SystemModel();
        $this->bmodel = new BillingModel();
            $this->staffmodel = new StaffModel();
         $this->dbname=session()->get('db_name');
           helper('age');
            helper('results_helper');
       $this->db=\Config\Database::connect($this->dbname);
       // $this->dbname=session()->get('elimu_db');

	}

	function Billing(){
		
		  return view('templates/header')
		  .view('bills/bills')
          .view('templates/footer');   
	}

	function load_accounts_data()
	{
			$request = service('request');
			$postData = $request->getPost();
			$account_data = array();
			$builder = $this->db->table("accounts_tbl");

			if(isset($postData['query'])){

			    $builder->select('accounts_tbl.id,accounts_tbl.account_name,accounts_tbl.description,accounts_tbl.status,account_types_tbl.type_name');
			    $builder->join('account_types_tbl','account_types_tbl.id = accounts_tbl.account_type_id  ');
			    $builder->where('accounts_tbl.status =1');
			    $builder->where('accounts_tbl.account_type_id = 10');
			    $builder->like('account_name',$postData['query'],'both');
			    $builder->limit(100);
			    $query = $builder->get();
			    $account_result = $query->getResult();
			}else{

			    $builder->select('accounts_tbl.id,accounts_tbl.account_name,accounts_tbl.description,accounts_tbl.status,account_types_tbl.type_name');
			    $builder->join('account_types_tbl','account_types_tbl.id = accounts_tbl.account_type_id  ');
			    $builder->where('accounts_tbl.status = 1');
			    $builder->where('accounts_tbl.account_type_id = 10');
			    $builder->limit(100);
			    $query = $builder->get();
			    $account_result = $query->getResult();
			}

			if(count($account_result) > 0){
			    foreach($account_result as $result){
			        $name=$result->account_name;
			        $typename = $result->type_name;
			        $description=$result->description;
			        $status=$result->status;
			        //$prc=number_format($result->item_price);
			        $account_data[] = array('id'=>$result->id,'text'=>'  '.' '.' '.$typename.','.'   '.$name);
			    }
			}    
			$response['data'] = $account_data;
			return $this->response->setJSON($response);
	}

	function load_account_data()
	{
		$postedData = $this->request->getRawInput();
		    // print_r($postedData['selected_accounts_array']);
		    // print_r($postedData['accounts_selected']);
		$selectedAccount = explode(',', $postedData['selected_accounts_array']);

		foreach ($selectedAccount as $sdi) {
		    if($sdi == $postedData['accounts_selected']){
		        echo "1";
		        return;
		    }
		}

		$data = $this->billmodel->accounts_chargedList1($postedData['accounts_selected']);
		$account_data = array();
		if(count($data) > 0){

		   foreach($data as $dt){

		    $account_data[] = array("id" => $dt->id,"aname" => $dt->account_name, "adescription" => $dt->description, "astatus" => $dt->status);
		}
		
		echo json_encode($account_data);
		}
	}

	/////////////function to load all payable and receivable and income ledgers/////////
	function load_payable_data()
	{

			$request = service('request');
			$postData = $request->getPost();
			$account_data = array();
			$builder = $this->db->table("accounts_tbl");

			if(isset($postData['query'])){

			    $builder->select('accounts_tbl.id,type_name,account_name');
			    $builder->join('account_types_tbl','account_types_tbl.id = accounts_tbl.account_type_id');
			    $builder->where('account_types_tbl.id = 4 OR account_types_tbl.id=6 OR account_types_tbl.id = 7');
			    $builder->like('type_name',$postData['query'],'both');
			    $builder->limit(100);
			    $query = $builder->get();
			    $payable_result = $query->getResult();
			}else{

			    $builder->select('accounts_tbl.id,type_name,account_name');
			    $builder->join('account_types_tbl','account_types_tbl.id = accounts_tbl.account_type_id');
			    $builder->where('account_types_tbl.id = 4 OR account_types_tbl.id = 6 OR account_types_tbl.id = 7');
			    $builder->limit(100);
			    $query = $builder->get();
			    $payable_result = $query->getResult();
			}

			if(count($payable_result) > 0){
			    foreach($payable_result as $result){
			    	$typename = $result->type_name;
			        $name=$result->account_name;
			        $payable_data[] = array('id'=>$result->id,'text'=>'  '.' '.$typename.', '.$name);
			    }
			}
			//print_r($payable_data);
			$response['data'] = $payable_data;
			return $this->response->setJSON($response);
	}

	//////////////function to fetch data with respective id//////////////////////
	function fetch_expense_ledgers()
	{
		$id = $this->request->getVar('accountid');
		$lgid= $this->request->getVar('incomeid');
		//echo($id);
		  	$builder = $this->db->table('accounts_tbl');
            $builder->select('id,account_name,description,account_type_id');
            $builder->where('id',$id);
            $query = $builder->get();
            $acc_result = $query->getResult();

            $builder = $this->db->table('accounts_tbl');
            $builder->select('id,account_name,description,account_type_id');
            $builder->where('id',$lgid);
            $query = $builder->get();
            $payable_result = $query->getResult();

          $ledgerData = array();

        if(count($acc_result) > 0){
            //$iprice = "";
            foreach ($acc_result as $l) {
               
          $data1 = array("id" => $l->id,"lg_id"=>$lgid,"account_name" => $l->account_name,"account_type_id"=>$l->account_type_id, "description" => $l->description,"payable_name"=>$payable_result[0]->account_name,"payable_id" => $payable_result[0]->id);
                array_push($ledgerData,$data1);
            }

            echo json_encode($ledgerData);
        }  
	}


	//function to load only payable accounts
	function load_accounts_payable(){

			$request = service('request');
			$postData = $request->getPost();
			$account_data = array();
			$builder = $this->db->table("accounts_tbl");

			if(isset($postData['query'])){

			    $builder->select('accounts_tbl.id,accounts_tbl.account_name,accounts_tbl.description,accounts_tbl.status,account_types_tbl.type_name');
			    $builder->join('account_types_tbl','account_types_tbl.id = accounts_tbl.account_type_id  ');
			    $builder->where('accounts_tbl.account_type_id =6');
			    $builder->like('account_name',$postData['query'],'both');
			    $builder->limit(100);
			    $query = $builder->get();
			    $account_result = $query->getResult();
			}else{

			    $builder->select('accounts_tbl.id,accounts_tbl.account_name,accounts_tbl.description,accounts_tbl.status,account_types_tbl.type_name');
			    $builder->join('account_types_tbl','account_types_tbl.id = accounts_tbl.account_type_id  ');
			    $builder->where('accounts_tbl.account_type_id = 6');
			    $builder->limit(100);
			    $query = $builder->get();
			    $account_result = $query->getResult();
			}

			if(count($account_result) > 0){
			    foreach($account_result as $result){
			        $name=$result->account_name;
			        $typename = $result->type_name;
			        $description=$result->description;
			        $status=$result->status;
			        //$prc=number_format($result->item_price);
			        $account_data[] = array('id'=>$result->id,'text'=>'  '.' '.' '.$typename.','.'   '.$name);
			    }
			}    
			$response['data'] = $account_data;
			return $this->response->setJSON($response);
	
	}

	///////////////// function to save new bill /////////////////////
	function Save_Bill_details()
	{
		helper('file');
		$transno = $this->generate_transaction_no();
		$data = [
			'transaction_type' =>4,
			'transaction_no' =>$transno,
			'bill_reference'=>$this->request->getPost('bill_no'),
			'bill_type'=>$this->request->getPost('bill_type'),
			'project_id'=>$this->request->getPost('project'),
			'due_date' =>$this->request->getPost('due_date'),
			];
			$this->billmodel->save_other_details('transaction_other_details_tbl',$data);

			$uploadedfiles = $this->request->getFiles();
			foreach($uploadedfiles['uploadFiles'] as $file){
				$fileName = null;
   				if($file->isValid() && !$file->hasMoved()){
               $fileName = $file->getName();
               if($file->move(ROOTPATH . 'public/transaction_files/',$fileName)){
                $attach = [
  						'transaction_number'=>$transno,
						'image_attachment'=>$fileName,
					];
			  $this->billmodel->save_image_attachment('transaction_attachments_tbl',$attach);

				}else{
					echo $file->getErrorString();
				}
  				}
           }
       		$this->save_looped_ledgers($this->request->getPost('bill_no'));

		}

	function save_looped_ledgers($bill_ref_no)
	{
		// echo($this->request->getPost('incomeledger'));
		// return;
		//print_r($bill_ref_no);
		$lg_id = $this->request->getPost('aid');
		$account_ttl = 0;
		$transno = $this->generate_transaction_no();
		
			$ledgers = [
					'trans_type_id'=>4,
					'trans_number'=>$transno,
					'trans_date'=>date('Y-m-d H:i:s'),
					'trans_desc'=>$this->request->getPost('descr0'),
					'status'=>0,
					'updated_by'=>$this->request->getPost('header_id'),
					'updated_date'=>date('Y-m-d H:i:s'),

				];
			$this->billmodel->save_transcation_data('transaction_numbers_tbl',$ledgers);

			$invoice_type = [
             'trans_no' => $transno,
             'transaction_type_id' => 4,
             'invoice_type_id' => $this->request->getPost('bill_type')
         ];
        $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);

			foreach($lg_id as $id){
			$amount = $this->request->getPost('ttl'.$id.'');
			//$ledger = array('id'=>$id,'bill_ref_no'=>$bill_ref_no,'description'=>$this->request->getPost('description'.$id.''),'amount'=>$amount);


 			$ledgertype = $this->billmodel->get_item_name('accounts_tbl',$where = array('id' => $id));			
 			$account_ttl+=$amount;
				//$this->request->getPost('incomeledger')

				//print_r($ledger);
 			//'expense_description'=>$this->request->getPost('description'.$id.''),

				$ledgers = [
					'ledger_id'=>$id,
					'ledger_type'=>$ledgertype[0]->account_type_id,
					'trans_item'=>$id,
					'trans_no'=>$transno,
					'trans_type'=>4,
					'amount'=>$amount,
					'transation_nature'=>2,
					'name_type_id'=>2,
					'name_id'=>$this->request->getPost('billto'),
					'balance'=>$amount,
					
				];
				$retid = $this->billmodel->save_transcation_data('ledger_transaction_tbl',$ledgers);
				$budget_ledger = [
					'transact_type' =>$ledgertype[0]->account_type_id,
					'transact_number' => $transno,
					'budget_ledger' => $this->request->getPost('incmeledger'.$id.''),
					'lg_no'=>$retid,
					'description'=>$this->request->getPost('description'.$id.''),
				];
				$this->billmodel->save_transaction_budget('transaction_budget_tbl',$budget_ledger);
			
		}
		 		$ledgertype = $this->billmodel->get_item_name('accounts_tbl',$where = array('id' => $this->request->getPost('account_payable')));			
				$ledgers = [
					'ledger_id'=>$this->request->getPost('account_payable'),
					'ledger_type'=>$ledgertype[0]->account_type_id,
					'trans_item'=>0,
					'trans_no'=>$transno,
					'trans_type'=>4,
					'amount'=>$account_ttl,
					'transation_nature'=>1,
					'name_type_id'=>2,
					'name_id'=>$this->request->getPost('billto'),
					'balance'=>$account_ttl,
					

				];
				$this->billmodel->save_transcation_data('ledger_transaction_tbl',$ledgers);

			////////////function to insert approval data /////////////
					$approval = [
					'trans_type'=>4,
					'trans_no'=>$transno,
					'name'=>$this->request->getPost('billto'),
					'name_type'=>2,
				];

			// $this->billmodel->save_approval_data('approval_numbers',$approval);
			$app_hist_id = $this->billmodel->save_approval_data('approval_numbers',$approval);

			/////////// function to insert approval history for Pending //////////
			$app_history =[
				'app_no'=>$app_hist_id,
				'user'=>$this->request->getPost('header_id'),
				'user_role'=>1,
				'comment'=>$this->request->getPost('bill_comment') ?? 'Please Approve',
				'hstatus'=>3,
				'hist_date'=>date('Y-m-d H:i:s'),
			];
			$this->billmodel->save_approval_history_data('approval_history',$app_history);
			
			//send message to approvals
			 $billto=$this->request->getPost('billto');
			 $url=base_url("?redirect=reapproval");
           $supplier_name = $this->billmodel->get_item_name('supplier_tbl',$where = array('supplier_id' => $billto));

			$messagex="<transaction name> <transaction no> to <Name> with amount <amount> is pending your approval.";

			 $msg = "Bill ".$transno." to ".$supplier_name[0]->supplier_name." for ".number_format($account_ttl)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 13,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $transno
                  
                );
    
   
     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
    	$priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
    	if(count($priveleged)>0){
    		foreach($priveleged as $plv){

    		if (ctype_digit((string)$plv->privilege_id)) {
    			//echo "yes ".$plv->privilege_id;
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>session()->get('db_id')));
              // print_r($assigned_user);
               $this->studentModel->SaveData('message_groups_tbl',$smsdata);
               foreach($assigned_user as $user){
               	if($user->phone_no !=""){
          

            $this->SMSsender($user->phone_no,$msg,13,$billto,$snn,NULL);

           $data=array(
           'phone_no'=>$user->phone_no,
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           );
              }
               }
    			}else{
             // echo "no-".$plv->privilege_id;
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));

              if(count($assigned_approval)>0){
                   $this->studentModel->SaveData('message_groups_tbl',$smsdata);
                foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>session()->get('db_id')));
              	if($assigned_user[0]->phone_no !=""){
          

             $this->SMSsender($assigned_user[0]->phone_no,$msg,13,$billto,$snn,NULL);
             //print_r($assigned_user);
            
            $data=array(
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

          }
          }
                }
    			}

    	//		print_r($data);
    		}
    	}
    }

   //  end message to approvals;
 			echo json_encode(array('status' => 1,'description' => 'Bill created successful'));

	}

	////////////// function to generate transaction number ////////////////
	 function generate_transaction_no() {
        $ino = "";
        $tkens = $this->billmodel->get_max_trans('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }


	////////////// function to load and display supplier ////////////////
	function load_supplier_data()
	{
			$request = service('request');
			$postData = $request->getPost();
			$supplier_data = array();
			$builder = $this->db->table("supplier_tbl");

			if(isset($postData['query'])){

			    $builder->select('supplier_tbl.supplier_id,supplier_tbl.supplier_name,supplier_tbl.supplier_phone');
			    $builder->join('users','users.user_id = supplier_tbl.updated_by');
			    $builder->where('supplier_tbl.sstatus = 1');
			    $builder->like('supplier_name',$postData['query'],'both');
			    $builder->limit(100);
			    $query = $builder->get();
			    $account_result = $query->getResult();
			}else{

			    $builder->select('supplier_tbl.supplier_id,supplier_tbl.supplier_name,supplier_tbl.supplier_phone');
			    $builder->join('users','users.user_id = supplier_tbl.updated_by');
			    $builder->where('supplier_tbl.sstatus = 1');
			    $builder->limit(100);
			    $query = $builder->get();
			    $account_result = $query->getResult();
			}

			if(count($account_result) > 0){
			    foreach($account_result as $result){
			        $name=$result->supplier_name;
			        $supplier_data[] = array('id'=>$result->supplier_id,'text'=>'  '.' '.' '.$name);
			    }
			}    
			$response['data'] = $supplier_data;
			return $this->response->setJSON($response);
	

	}

	//////////////////////// function to load approvals ///////////////
	function Load_approvals_data()
	{
		$data['approvals'] = $this->billmodel->get_approvals();
		//$data['Attl'] = $this->billmodel->get_counted_approval();
			return view('templates/header')
			.view('bills/approvals',$data)
			.view('templates/footer');
	}

	/////////////////// function to view approval information ///
	function get_View_approval_data()
	{
		$id = $this->request->getVar('trans_no');
		$vocher= $this->request->getVar('vocher');
		$trans_type = $this->request->getVar('trans_type');
		$data = array(
               'inv' => $this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$id,'trans_type_id'=>$trans_type))
            );

		$data['advances']=$this->billmodel->Check_salary_advance($id);
		$data['vocher']=$vocher;
		$data['trans_types']=$trans_type;
		if($trans_type==1){
return view('transport/view_approval_transport_delete',$data);
		}
		if($trans_type==4){
return view('bills/view_approval',$data);
		}
		if($trans_type==5){
	return view('bills/view_approval5',$data);		
		}
		
		if($trans_type==8){
	   return view('bills/view_approval8',$data);		
		}
			if($trans_type==10){
		$voucher_type=$this->billmodel->get_vouchername($id);	
		if($voucher_type!=''){
			if($voucher_type->id==6){
$data['payroll_info']=$this->billmodel->viewpayrollData($id);
$data['voucher_type']=$voucher_type->voucher_type_name;
	$data['payroll_data']=$this->billmodel->payroll_approval($id,$trans_type);
	$data['ledger_data']=$this->billmodel->payroll_approval_ledger($id,$trans_type);
	   return view('bills/view_approval10',$data);	
			}elseif($voucher_type->id==9){
				$data['payroll_info']=$this->billmodel->viewpayrollData($id);
$data['voucher_type']=$voucher_type->voucher_type_name;
	$data['overtime_data']=$this->billmodel->ovetime_approval($id,$trans_type);
	$data['ledger_data']=$this->billmodel->payroll_approval_ledger($id,$trans_type);
	   return view('bills/view_approvalOvertime',$data);	
			}

		}	
	
		}

	}

	////////////// function to view bill data ////////////////
	function get_View_bill_data()
	{
		$id  = $this->request->getVar('trans_no');
		// $data['bills_view'] = $this->billmodel->fetch_view_bill($id);  
		// return view('bills/view_bills',$data);
		$data = array(
               'inv' => $this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$id,'trans_type_id'=>4))
            );
            return view('bills/view_bills',$data);
	}

	///////////////// function for Receipt ////////////////////
	function Payment_Voucher()
	{
		  return view('templates/header')
		  .view('bills/receipt.php')
          .view('templates/footer');
	}

	//////////////////////// function to retreive data on given date range////
	function receiptdata(){
        $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            
            $data = array(
               'trans' => $this->billmodel->get_item_name2('transaction_numbers_tbl',$where = array('trans_type_id' => 4),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))
            );
            // print_r($data);
            // return;
          echo view('bills/billdata',$data);
    }

    //***####################### filter Bill ################################**//
    function billfilterdata(){

  // $data = array(
              
  //           );
    $thedate=$this->request->getVar('thedate');
    $approval = $this->request->getVar('approval');

    list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
     
      $data = array(
              
     'billfilter' => $this->billmodel->get_filtered_bill('approval_history',$approval,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))
            );

        // print_r($data);
        // return;
      echo view('bills/bill_filtered_response',$data);
       
    }


	function search_payer()
	{
		$search = $this->request->getPost('payer_name');
        $db = \Config\Database::connect($this->dbname);

         if($this->request->getPost('paid_by') == 1){
            $names= $db->query('SELECT * FROM supplier_tbl 
                          WHERE `supplier_id` = \''.$search.'\' OR `supplier_name` LIKE \'%'.$search.'%\'');
            $result = $names->getResult();
          if(count($result) > 0){

            echo
            '<table class="table table-hover">
            <thead>
                 <tr>
                    <th>ID</th>
                    <th>Payer Name</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Email</th>
                </tr>
            </thead><tbody>';
            foreach ($result as $supl){
                $suppl=$this->billmodel->get_supplierdetail($supl->supplier_id);
                if(count($suppl)>0){
                $fullname = $suppl[0]->supplier_name;
                echo '<tr><td>'.$supl->supplier_id.'</td>';
                echo '<td>'.$fullname.'</td>';
                echo '<td>'.$suppl[0]->supplier_phone.'</td>';
                echo '<td>'.$suppl[0]->supplier_address.'</td>';
                echo '<td>'.$suppl[0]->supplier_email.'</td>';
                echo '<td><button class="btn btn-primary btn-sm" onclick="select_payer('.$supl->supplier_id.','.$this->request->getPost('paid_by').',\''.$fullname.'\')">select</button></td></tr>';
            }
        
            }
            echo '</tbody>';
        }else{
          echo "<span style='color:red'>No any data Found</span>";
        }

        }
	}

		/////////////// function to get payer details after selsction ///
		function get_payer_details()
		{
			$db = \Config\Database::connect($this->dbname);
			$suppID = $this->request->getPost('payer');
			$names = $db->query('SELECT supplier_name,supplier_phone,supplier_email,supplier_address FROM supplier_tbl WHERE supplier_id = '.$suppID.'');
			$resu= $names->getResult();

			 echo '<div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Payer Name</label>
                <div class="col-sm-8">
                  <input type="text" readonly  class="form-control"  value="'.$resu[0]->supplier_name.'" >
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Phone</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value="  '.$resu[0]->supplier_phone.'">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Address</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value=" '.$resu[0]->supplier_address.'">
                </div>
                </div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Email</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value="  '.$resu[0]->supplier_email.'">
                </div></div>';
		}

		/////////////////////// function for approve button ////////////////////////////////////
		function Approved_Data()
		{
			$user = $_SESSION['user_id'];
			$type=$this->request->getVar('type');
			//echo "<script>alert('Its Okay!')</script>";
			//echo "<script>alert($user)</script>";
			$trans_number = $this->request->getVar('trans_number');
			$dat_appr =$this->billmodel->get_item_name('approval_numbers',$where=array('trans_no'=>$trans_number,'trans_type'=>$type));
			$checkstatus = $this->billmodel->check_ifExist('approval_history',$where=array('app_no'=>$dat_appr[0]->app_id,'hstatus'=>1));

			if($type==1){
				$result = $this->approveTransportDeletion($dat_appr[0]->app_id, $trans_number, $user);
				return $this->response->setJSON($result);
			}
            
			$data = array(
				'app_no'=>$dat_appr[0]->app_id,
				'user'=>$user,
				'user_role'=>3,
				'comment'=>'Approved!',
				'hstatus'=>1,
				'hist_date'=>date('Y-m-d H:i:s')
			);
			$this->billmodel->save_approval_info('approval_history',$data);
			if ((int) $type === 5) {
				$this->syncRelatedInvoiceBalancesFromVoucher($trans_number);
			}
			$staff_data=$this->billmodel->get_staff_payrollData($trans_number);
			$staff_advance=$this->billmodel->get_staff_advance($trans_number);
					if (!empty($staff_data)){
	 $billto=$this->request->getPost('billto');
			 $url=base_url("?redirect=reapproval");
			$messagex="<transaction name> <transaction no> to <Name> with amount <amount> is pending your approval.";
 $msg='Habari, '.$staff_data->first_name.'. Malipo (Mshahara '.$staff_data->month.' '.$staff_data->payroll_year.') ya TZS '.number_format($staff_data->amount_paid).' yamefanyika tar '.date("d-m-Y H:i:s", strtotime($staff_data->trans_date)).' Kuona Salary Slip bonyeza https://econnect.advaensure.co.tz/slp/'.$staff_data->user_id.'/'.$trans_number.'/'.$staff_data->database_id;

     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 14,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => session()->get('user_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans_number
                  
                );
       $this->studentModel->SaveData('message_groups_tbl',$smsdata);
      $billto=$staff_data->user_id;
      $phone_no=$staff_data->phone_no;
   $cleanPhone = sanitize_phone($phone_no);
if ($cleanPhone) {
    try {
          $this->SMSsender($cleanPhone,$msg,14,$billto,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
 log_message('error', 'Invalid phone number skipped: ' . $staff_data->phone_no);

}
  }else if($staff_advance){
  	 $billto=$this->request->getPost('billto');
			 $url=base_url("?redirect=reapproval");
			$messagex="<transaction name> <transaction no> to <Name> with amount <amount> is pending your approval.";
 $msg=$staff_advance[0]->first_name.'. Malipo ya salary Advances  ya TZS '.number_format($staff_advance[0]->advance_amount).' yamefanyika tar '.date("d-m-Y H:i:s", strtotime($staff_advance[0]->trans_date)).' Slip https://econnect.advaensure.co.tz/slp/'.$staff_advance[0]->user_id.'/'.$trans_number.'/'.$staff_advance[0]->database_id;

     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 14,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => session()->get('user_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans_number
                  
                );
       $this->studentModel->SaveData('message_groups_tbl',$smsdata);
      $billto=$staff_advance[0]->user_id;
      $phone_no=$staff_advance[0]->phone_no;
             $cleanPhone = sanitize_phone($phone_no);
if ($cleanPhone) {
    try {
          $this->SMSsender($cleanPhone,$msg,14,$billto,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
       log_message('error', 'Invalid phone number skipped: ' . $staff_advance[0]->phone_no);

}

  }
    else{

  }
			
		}

		private function syncRelatedInvoiceBalancesFromVoucher($voucherTransNo)
		{
			$voucherRows = $this->db->table('voucher_relation_tbl')
				->select('*')
				->where('payment_no', $voucherTransNo)
				->where('voucher_type', 5)
				->where('trans_type', 2)
				->get()
				->getResult();

			if (count($voucherRows) === 0) {
				return;
			}

			$receiptNumbers = [];
			foreach ($voucherRows as $row) {
				if (! empty($row->trans_no)) {
					$receiptNumbers[] = (string) $row->trans_no;
				}
			}

			foreach (array_unique($receiptNumbers) as $receiptNumber) {
				$this->syncRelatedInvoiceBalancesFromReceipt($receiptNumber);
			}
		}

		private function syncRelatedInvoiceBalancesFromReceipt($receiptTransNo)
		{
			if (trim((string) $receiptTransNo) === '') {
				return;
			}

			$relations = $this->db->table('transactions_relation')
				->select('invoice_trans_no')
				->where('receipt_trans_no', $receiptTransNo)
				->orderBy('id', 'ASC')
				->get()
				->getResult();

			if (count($relations) === 0) {
				return;
			}

			$invoiceNumbers = [];
			foreach ($relations as $relation) {
				$invoiceNumbers[] = (string) $relation->invoice_trans_no;
			}

			foreach (array_unique($invoiceNumbers) as $invoiceNumber) {
				$this->syncInvoiceAndStudentBalance($invoiceNumber);
			}
		}

		private function syncInvoiceAndStudentBalance($invoiceNo)
		{
			$invoiceNo = trim((string) $invoiceNo);
			if ($invoiceNo === '') {
				return;
			}

			$invoiceHeader = $this->db->table('transaction_numbers_tbl')
				->select('*')
				->where('trans_number', $invoiceNo)
				->where('trans_type_id', 1)
				->get()
				->getRow();

			if (! $invoiceHeader) {
				return;
			}

			$invoiceLedger = $this->db->table('ledger_transaction_tbl')
				->select('*')
				->where('trans_no', $invoiceNo)
				->where('trans_type', 1)
				->where('transation_nature', 2)
				->where('name_type_id', 1)
				->orderBy('id', 'ASC')
				->get()
				->getResult();

			if (count($invoiceLedger) === 0) {
				return;
			}

			$studentId = (int) $invoiceLedger[0]->name_id;
			$due = $this->calculateInvoiceDueAmount($invoiceNo);
			if (abs($due) < 0.01) {
				$due = 0;
			}
			if ($due < 0) {
				$due = 0;
			}

			$this->db->table('ledger_transaction_tbl')
				->where('trans_no', $invoiceNo)
				->where('trans_type', 1)
				->where('transation_nature', 2)
				->where('name_type_id', 1)
				->update(['balance' => $due]);

			$year = (int) date('Y', strtotime($invoiceHeader->trans_date));
			$balanceData = [
				'year' => $year,
				'student_id' => $studentId,
				'balance' => $due > 0 ? 0 : $due,
				'present_debit' => $due > 0 ? $due : 0,
				'debted_inv_no' => $invoiceNo,
			];

			$existingBalance = $this->db->table('student_balance_tbl')
				->select('*')
				->where('student_id', $studentId)
				->where('year', $year)
				->get()
				->getResult();

			if (count($existingBalance) > 0) {
				$this->db->table('student_balance_tbl')
					->where('student_id', $studentId)
					->where('year', $year)
					->update($balanceData);
			} else {
				$this->db->table('student_balance_tbl')->insert($balanceData);
			}
		}

		private function calculateInvoiceDueAmount($invoiceNo)
		{
			$total = 0;
			$paidTotal = 0;
			$transferredTotal = 0;
			$refundedTotal = 0;

			$invoiceItems = $this->db->table('item_transation_tbl')
				->select('items_tbl.item_group, item_transation_tbl.quantity, item_transation_tbl.unit_price')
				->join('items_tbl', 'items_tbl.id = item_transation_tbl.item_id')
				->where('item_transation_tbl.trans_type', 1)
				->where('item_transation_tbl.trans_number', $invoiceNo)
				->get()
				->getResult();

			foreach ($invoiceItems as $item) {
				$amount = (float) $item->quantity * (float) $item->unit_price;
				if ((int) $item->item_group === 7) {
					$total -= $amount;
				} else {
					$total += $amount;
				}
			}

			$relations = $this->db->table('transactions_relation')
				->select('*')
				->where('invoice_trans_no', $invoiceNo)
				->orderBy('id', 'ASC')
				->get()
				->getResult();

			foreach ($relations as $relation) {
				$receiptNo = $relation->receipt_trans_no;

				$allReceiptRelations = $this->db->table('transactions_relation')
					->select('*')
					->where('receipt_trans_no', $receiptNo)
					->orderBy('id', 'ASC')
					->get()
					->getResult();

				$receiptLedgers = $this->db->table('ledger_transaction_tbl')
					->select('*')
					->where('trans_no', $receiptNo)
					->where('trans_type', 2)
					->where('ledger_type', 7)
					->where('transation_nature', 1)
					->orderBy('id', 'ASC')
					->get()
					->getResult();

				if (count($receiptLedgers) === 0) {
					$receiptLedgers = $this->db->table('ledger_transaction_tbl')
						->select('*')
						->where('trans_no', $receiptNo)
						->where('trans_type', 2)
						->where('ledger_type', 7)
						->where('transation_nature', 2)
						->orderBy('id', 'ASC')
						->get()
						->getResult();
				}

				if (count($allReceiptRelations) > 1) {
					foreach ($allReceiptRelations as $index => $receiptRelation) {
						if ((string) $receiptRelation->invoice_trans_no === $invoiceNo && isset($receiptLedgers[$index])) {
							$paidTotal += (float) $receiptLedgers[$index]->amount;
						}
					}
				} elseif (count($allReceiptRelations) === 1 && (string) $allReceiptRelations[0]->invoice_trans_no === $invoiceNo) {
					foreach ($receiptLedgers as $receiptLedger) {
						$paidTotal += (float) $receiptLedger->amount;
					}
				}

				$transfers = $this->db->table('receipt_transfer_tbl')
					->select('*')
					->where('old_receipt_number', $receiptNo)
					->get()
					->getResult();

				foreach ($transfers as $transfer) {
					$transferredTotal += (float) $transfer->amount_transfered;
				}

				$refunds = $this->db->table('voucher_relation_tbl')
					->select('*')
					->where('trans_no', $receiptNo)
					->where('trans_type', 2)
					->where('voucher_type', 5)
					->get()
					->getResult();

				foreach ($refunds as $refund) {
					$approval = $this->db->table('approval_numbers')
						->select('*')
						->where('trans_no', $refund->payment_no)
						->where('trans_type', 5)
						->get()
						->getRow();

					if (! $approval) {
						continue;
					}

					$approved = $this->db->table('approval_history')
						->select('*')
						->where('app_no', $approval->app_id)
						->where('hstatus', 1)
						->get()
						->getRow();

					if (! $approved) {
						continue;
					}

					$refundLedger = $this->db->table('ledger_transaction_tbl')
						->select('*')
						->where('trans_no', $refund->payment_no)
						->where('trans_type', 5)
						->where('transation_nature', 2)
						->orderBy('id', 'ASC')
						->get()
						->getRow();

					if ($refundLedger) {
						$refundedTotal += (float) $refundLedger->amount;
					}
				}
			}

			return $total - $paidTotal + $transferredTotal + $refundedTotal;
		}

		private function approveTransportDeletion($appId, $transNumber, $user)
		{
			$detail = $this->db->table('transaction_numbers_tbl')
				->where('trans_number', $transNumber)
				->where('trans_type_id', 1)
				->get()
				->getRow();

			if (empty($detail)) {
				return [
					'status' => 0,
					'message' => 'Invoice not found or already deleted.'
				];
			}

			$controlRows = $this->db->table('payment_request')
				->where('trans_no', $transNumber)
				->where('trans_type', 1)
				->where('payment_status', 0)
				->get()
				->getResult();

			foreach ($controlRows as $controlRow) {
				$cancelResponse = $this->cancelTransportControlNumber($controlRow->reference_no);
				if (! $cancelResponse['status']) {
					return [
						'status' => 0,
						'message' => $cancelResponse['message']
					];
				}
			}

			$this->db->transStart();

			$data = array(
				'app_no'=>$appId,
				'user'=>$user,
				'user_role'=>3,
				'comment'=>'Approved!',
				'hstatus'=>1,
				'hist_date'=>date('Y-m-d H:i:s')
			);
			$this->billmodel->save_approval_info('approval_history',$data);

			$this->db->table('payment_request')
				->where('trans_no', $transNumber)
				->where('trans_type', 1)
				->delete();

			$this->db->table('project_transaction_tbl')
				->where('trans_numba', $transNumber)
				->where('trans_type', 1)
				->delete();

			$this->db->table('transport_details')
				->where('trans_numb', $transNumber)
				->delete();

			$this->db->table('item_transation_tbl')
				->where('trans_number', $transNumber)
				->where('trans_type', 1)
				->delete();

			$this->db->table('invoice_type_transaction')
				->where('trans_no', $transNumber)
				->where('transaction_type_id', 1)
				->delete();

			$this->db->table('transactions_relation')
				->where('invoice_trans_no', $transNumber)
				->delete();

			$this->db->table('ledger_transaction_tbl')
				->where('trans_no', $transNumber)
				->where('trans_type', 1)
				->delete();

			$this->db->table('transaction_numbers_tbl')
				->where('id', $detail->id)
				->delete();

			$this->db->transComplete();

			if ($this->db->transStatus() === false) {
				return [
					'status' => 0,
					'message' => 'Failed to delete approved transport invoice.'
				];
			}

			return [
				'status' => 1,
				'message' => 'Transport invoice and permit deleted successfully.'
			];
		}

		private function cancelTransportControlNumber($referenceNo)
		{
			if (empty($referenceNo)) {
				return ['status' => true];
			}

			$data = array(
				'ref_no' => $referenceNo
			);

			$url = CRDB_URL_1."cancelRefNo";
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_SSLVERSION, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(
				"Content-type: application/json",
			));
			curl_exec($ch);
			$err = curl_error($ch);
			curl_close($ch);

			if ($err) {
				return [
					'status' => false,
					'message' => 'Failed to cancel control number before deleting invoice.'
				];
			}

			return ['status' => true];
		}
		//////////////// function to save rejected bill ///////////////////////
		function Send_Rejected_bill()
		{
			$user = $_SESSION['user_id'];
			$type=$this->request->getVar('type');
			$trans_number = $this->request->getVar('trans_number');
			$dat_appr =$this->billmodel->get_item_name('approval_numbers',$where=array('trans_no'=>$trans_number,'trans_type'=>$type));
			$comment = $this->request->getVar('comment');
			$data = array(
				'app_no'=>$dat_appr[0]->app_id,
				'user'=>$user,
				'user_role'=>3,
				'comment'=>$comment,
				'hstatus'=>2,
				'hist_date'=>date('Y-m-d H:i:s')
			);
			$this->billmodel->save_approval_info('approval_history',$data);
			

		}
		function getSingle_bill_data()
		{
			$id = $this->request->getVar('id');
			$data['bll'] = $this->billmodel->get_edit_bill($id);
			return view('bills/edit_bill',$data);
		}

		function fetch_expens_ldgrs()
		{
			$id = $this->request->getVar('trans_id');
 			$ledgerData = array();
			$data = $this->billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no'=>$id,'ledger_type'=>10));
			$desc=$this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number'=>$id));
			foreach($data as $dt){
					$amount = $dt->amount;
					$lgid = $dt->ledger_id;
				// if($dt->ledger_type == 10){
					$builder = $this->db->table('accounts_tbl');
		            $builder->select('id,account_name,description,account_type_id');
		            $builder->where('id',$dt->ledger_id);
		            $query = $builder->get();
		            $acc_result = $query->getResult();
		            $dat = $this->billmodel->get_item_name('transaction_budget_tbl',$where = array('lg_no'=>$dt->id,'transact_type'=>10));
					$payable_result=$this->billmodel->get_item_name('accounts_tbl',$where = array('id'=>$dat[0]->budget_ledger));

				// }
				// if($dt->ledger_type == 6){
				
				// 	 $builder = $this->db->table('accounts_tbl');
			    //      $builder->select('id,account_name,description,account_type_id');
			    //      $builder->where('id',$dt->ledger_id);
			    //      $query = $builder->get();
			    //      $payable_result = $query->getResult();
				// }
			

         

        if(count($acc_result) > 0){
            //$iprice = "";
            foreach ($acc_result as $l) {
               
          $data1 = array("id"=>$dt->id,"expense_id" => $l->id,"payable_id"=>$lgid,"account_name" => $l->account_name,"account_type_id"=>$l->account_type_id, "description" => $dat[0]->description,"payable_name"=>$payable_result[0]->account_name,"ttl"=>$amount);
                array_push($ledgerData,$data1);
            }
			}
           } 
           echo json_encode($ledgerData);
        	 
		}

		function Update_Bill_info()
		{

			//$lgid = $this->request->getPost('expnsledger');
			$lgid = $this->request->getPost('aid');
			$desc = $this->request->getPost('description');
			$amt = $this->request->getPost('amount');
			$icmlgid = $this->request->getPost('incmledger');
			$trano = $this->request->getPost('trans_nu');
			$ttlamnt = $this->request->getPost('account_ttl');
			$payableid = $this->request->getPost('payable_name');
			// echo $sesid;
			// return;
			$payblid = $this->billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $trano,'trans_item'=>0));
			// print_r($payableid[0]->ledger_id);
			// return;
			

			$nameid = $this->billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $trano));

			foreach($lgid as $id){

			$ledgtype = $this->billmodel->get_item_name('accounts_tbl',$where = array('id' => $id));
			 $ledgersupdt = [
					'ledger_id'=>$id,
					'ledger_type'=>$ledgtype[0]->account_type_id,
					'trans_item'=>$id,
					'trans_no'=>$trano,
					'trans_type'=>4,
					'amount'=>$this->request->getPost('ttl'.$id),
					'expense_description'=> $this->request->getPost('description'.$id),
					'transation_nature'=>2,
					'name_type_id'=>2,
					'name_id'=>$nameid[0]->name_id,
					'balance'=>$this->request->getPost('ttl'.$id),

				];
				$retunedid = $this->billmodel->save_transcation_data('ledger_transaction_tbl',$ledgersupdt);

				$budgetdata = [
				'transact_type'=>$ledgtype[0]->account_type_id,
				'transact_number'=>$trano,
				'budget_ledger'=>$this->request->getPost('payable_name'.$id),
				'lg_no'=>$retunedid,
			];
		}
			$this->billmodel->save_transaction_budget('transaction_budget_tbl',$budgetdata);
				$updttl = [
					
					'amount'=>$ttlamnt,
				];

			$this->billmodel->update_bill($trano,$payblid[0]->ledger_id,$updttl);
			$updtrans = [
					
					'updated_by'=>$_SESSION['user_id'],
				];
			$this->billmodel->update_table_details('transaction_numbers_tbl',$where = array('trans_number' =>$trano),$updtrans);
			 echo json_encode(array('status' => 1,'description' => 'Bill Updated successful'));
			
		}
		function doUploadImage()
		{
			
			$uploadedfiles = $this->request->getFiles();
			$transsno = $this->request->getPost('transactionno');
			foreach($uploadedfiles['uploadFiles'] as $file){
				$fileName = null;
   			if($file->isValid() && !$file->hasMoved()){
               $fileName = $file->getName();
            if($file->move(ROOTPATH . 'public/transaction_files/',$fileName)){
            $attach = [
  						'transaction_number'=>$transsno,
						'image_attachment'=>$fileName,
					];
			$this->billmodel->insert_imagedata('transaction_attachments_tbl',$attach);
				}
			
  		}
  		    echo json_encode(array('status' => 1,'description' => 'File Uploaded successful'));
      }

	}

	///////############ Remove Attachment//////////############
	function removeattachment()
		{
			$fc = "public/transaction_files/".$this->request->getVar('attch_name');
			$this->billmodel->deleteimage($this->request->getVar('attch_id'));
			unlink($fc);
		}


	function delete_expense_data($id,$total)
	{
		$amount_del = $this->billmodel->get_item_name('ledger_transaction_tbl',$where=array('id'=>$id));
		$amount = $this->billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $amount_del[0]->trans_no,'trans_type'=>4,'transation_nature'=>1));
		$data = array(
			'amount'=>$amount[0]->amount-$amount_del[0]->amount,
		);
		$this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $amount[0]->trans_no,'trans_type'=>4,'transation_nature'=>1),$data);   
		$builder = $this->db->table('ledger_transaction_tbl');
        $builder->where('id',$id);
        $builder->delete();
	}

	function pay_voucher(){
		 $data['months']=$this->billmodel->get_item_name('months',$where = array('month_id >' => 0));
		 $data['legers']=$this->billmodel->get_government_name();
		 return view('templates/header')
		  .view('bills/pay_voucher.php',$data)
          .view('templates/footer');
	}

	function refund($id,$type){
		$credit_items=array();
		$overpayments=array();
		// $id=$this->request->getPost("id");
		// $nametype=$this->request->getPost("nametype");
		// $type=$this->request->getPost("type");
		// $voucher_type=$this->request->getPost("voucher_type");
		// $selected=$this->request->getPost("selected");


           if($type ==0){
		$credit_items=$this->billmodel->get_credit_items('ledger_transaction_tbl',$where = array('trans_type'=>6,'transation_nature'=>2,'name_type_id'=>1),$id);
		$overpayments=$this->billmodel->get_all_overpayment($id);
	}elseif($type >0){
		if($type ==6){
			$credit_items=$this->billmodel->get_credit_items('ledger_transaction_tbl',$where = array('trans_type'=>6,'transation_nature'=>2,'name_type_id'=>1),$id);
		}else{
			$overpayments=$this->billmodel->get_all_overpayment($id);
		}
		
	}else{
echo "none none";
	}
//print_r($overpayments);
$merged_list = array_merge($credit_items, $overpayments);
		// Sort the merged list by 'name' field
usort($merged_list, function($a, $b) {
    return strcmp($a->full_name, $b->full_name);
});

// Assign the sorted list to the data array
$data['list'] = $merged_list;
$data['receipt']=0;
	//	$data['list'] = array_merge($credit_items, $overpayments);
		echo view('bills/forms/refund_view',$data);
	}

	function bank_payments($type){
		$data['id']=$type;
     echo view('bills/forms/bank_payments',$data);
	}

	function process_refund_payments(){
	$voucher=$this->request->getPost("voucher");
	//print_r($voucher);
     // return;

	foreach($voucher as $v){
		$amount=$this->request->getPost("amount".$v);
		$amount=str_replace(',', '', $amount);
		if($amount !="" || $amount !=0){
			//echo "amount-> ". str_replace(',', '', $amount)."</br>";
			$trans = $this->generate_payment_no();
      $transaction = [
              'trans_type_id' => 5,
              'trans_number' => $trans,
              'trans_date' => $this->request->getPost('voucher_date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s'),
              
      ];
      $this->studentModel->SaveData('transaction_numbers_tbl',$transaction);
        $amount=(int)$amount;
      $payedamount = $amount; 
       $trno = $this->request->getPost('trans_no'.$v);

       $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 5,
             'invoice_type_id' => $this->request->getPost('invoice_type'.$v)
         ];
        $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);

        if($this->request->getPost('trans_type'.$v)==2){

        	if($this->request->getPost("isreceipt".$v)==1){
        		$balance=0;
        		 $ledger=6;
        		 $ledger_type=7;

        	}else{
          $ledger=21;
         $clg= $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trno,'transation_nature' => 2,'trans_type' => $this->request->getPost('trans_type'.$v),'ledger_type'=>7));
         $ledger_type=7;
        // print_r($clg);
         $balance=$clg[0]->balance-$amount;
         // echo $balance;
         // return;
         
         $nature=1;
     }

        }else if($this->request->getPost('trans_type'.$v)==4){
        	$nature=2;
        	$clg = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trno,'transation_nature' => 1,'trans_type' => $this->request->getPost('trans_type'.$v),'ledger_type'=>6));
        	if(count($clg)>0){
        		$ledger=$clg[0]->ledger_id;
        		$balance=$clg[0]->balance-$amount;
        		$ledger_type=$clg[0]->ledger_type;
        	}else{
        		$ledger=28;
        		$ledger_type=7;
        		
        	}
         }
        else{
        	$nature=2;
        	$clg = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trno,'transation_nature' => 1,'trans_type' => $this->request->getPost('trans_type'.$v),'ledger_type'=>7));
        	if(count($clg)>0){
        		$ledger=$clg[0]->ledger_id;
        		$balance=$clg[0]->balance-$amount;
        		$ledger_type=$clg[0]->ledger_type;
        	}else{
        		$ledger=26;
        		$ledger_type=7;
        		
        	}
         }

         $cbalance = array(
                    'balance' => $balance
                );
         $isreceipt=$this->request->getPost("isreceipt".$v);
         if($isreceipt==0){
           $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $clg[0]->id),$cbalance);
         }
        if($isreceipt==2){
           $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $trno,'trans_type' => $this->request->getPost('trans_type'.$v)),$cbalance);
         }


         $rcledger = [
                       'ledger_id' => $ledger,
                       'ledger_type' => $ledger_type,
                       'trans_item' => 0,
                       'trans_no' => $trans,
                       'trans_type' => 5,
                       'amount' => $amount,
                       'transation_nature' => 2,
                       'name_type_id' => $this->request->getPost('name_type_id'.$v),
                       'name_id' => $this->request->getPost('student_id'.$v),
                       'balance' => $balance
                   ];
  //   print_r($rcledger);
               $payid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$rcledger);

               $relation_transation = [
                       'trans_no' => $trno,
                       'payment_no ' => $trans,
                       'voucher_type ' => $this->request->getPost('voucher_type'),
                       'trans_type ' =>$this->request->getPost('trans_type'.$v),
                       'reason' =>$this->request->getPost('reason'),
                         ];
                $this->studentModel->SaveData('voucher_relation_tbl',$relation_transation);

               $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $this->request->getPost('bank'))); 
                $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 5,
               'amount' => $amount,
               'transation_nature' =>1,
               'name_type_id' => $this->request->getPost('name_type_id'.$v),
               'name_id' => $this->request->getPost('student_id'.$v),
           ];

         $chek_lg = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('ledger_id' => $Bank_leger[0]->id,'ledger_type'=>$Bank_leger[0]->account_type_id,'trans_no'=>$trans,'trans_type'=>5,'transation_nature'=>1)); 
          if(count($chek_lg)>0){

         }else{
           $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);
       }

       ////////////function to insert approval data /////////////
					$approval = [
					'trans_type'=>5,
					'trans_no'=>$trans,
					'name'=>$this->request->getPost('student_id'.$v),
					'name_type'=>$this->request->getPost('name_type_id'.$v),
				];

			// $this->billmodel->save_approval_data('approval_numbers',$approval);
			$app_hist_id = $this->billmodel->save_approval_data('approval_numbers',$approval);

			$app_history =[
				'app_no'=>$app_hist_id,
				'user'=>$this->request->getPost('header_id'),
				'user_role'=>1,
				'comment'=>$this->request->getPost('reason'),
				'hstatus'=>3,
				'hist_date'=>date('Y-m-d H:i:s'),
			];
			$this->billmodel->save_approval_history_data('approval_history',$app_history);
			
			//here we go
           	//send message to approvals
			 $billto=$this->request->getPost('student_id'.$v);
			 $url=base_url("?redirect=reapproval");
           
           $s_name="";
           if($this->request->getPost('name_type_id'.$v)==1){
            $t_name = $this->billmodel->get_item_name('students',$where = array('id' => $billto));
            $s_name=$t_name[0]->first_name.' '.$t_name[0]->last_name;
           }
           if($this->request->getPost('name_type_id'.$v)==2){
            $t_name = $this->billmodel->get_item_name('supplier_tbl',$where = array('supplier_id' => $billto));
            $s_name=$t_name[0]->supplier_name;
           }
           if($this->request->getPost('name_type_id'.$v)==5){
           	 
           $t_name = $this->billmodel->get_item_name('parents_tbl',$where = array('id' => $billto));
             $s_name=$t_name[0]->first_name.' '.$t_name[0]->last_name;
           }
           

			$messagex="<transaction name> <transaction no> to <Name> with amount <amount> is pending your approval.";

			$msg = "Voucher ".$trans." to ".$s_name." for ".number_format($amount)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 14,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
    
   
     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
    	$priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
    	if(count($priveleged)>0){
    		foreach($priveleged as $plv){

    		if (ctype_digit((string)$plv->privilege_id)) {
    			//echo "yes ".$plv->privilege_id;
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>session()->get('db_id')));
              // print_r($assigned_user);
              $this->studentModel->SaveData('message_groups_tbl',$smsdata);
               foreach($assigned_user as $user){
               	if($user->phone_no !=""){
           

            $this->SMSsender($user->phone_no,$msg,14,$billto,$snn,NULL);

           $data=array(
           'phone_no'=>$user->phone_no,
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           );
              }
               }
    			}else{
             // echo "no-".$plv->privilege_id;
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));
              if(count($assigned_approval)>0){
                 $this->studentModel->SaveData('message_groups_tbl',$smsdata);
              	foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>session()->get('db_id')));

              
              	if($assigned_user[0]->phone_no !=""){
           

             $this->SMSsender($assigned_user[0]->phone_no,$msg,14,$billto,$snn,NULL);
             //print_r($assigned_user);
            
            $data=array(
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

          }
      }

                }
    			}

    		//	print_r($data);
    		}
    	}
    }

   //  end message to approvals;
			//------------

		}

	}
	echo json_encode(array('status' => 1,'description' => 'Payment saved successfully'));

	}

function generate_msg_no() {
        $ino = "";
        $tkens = $this->studentModel->get_max_id('message_groups_tbl','send_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
    
	function generate_payment_no() {
        $ino = "";
        $tkens = $this->billmodel->get_max_payment('transaction_numbers_tbl','trans_number','5');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }

    function voucher_list(){
    $thedate = $this->request->getVar('thedate');
list($startingdate, $endingdate) = explode('-', $thedate);
$startingdate = trim($startingdate);
$endingdate   = trim($endingdate);
$startDateTime = date('Y-m-d 00:00:00', strtotime($startingdate));
$endDateTime   = date('Y-m-d 23:59:59', strtotime($endingdate));
$data = array(
    'trans' => $this->billmodel->get_item_name2(
        'transaction_numbers_tbl',
        array('trans_type_id' => 5),
        $startDateTime,
        $endDateTime
    )
);


           echo view('bills/forms/voucher_list',$data);
    }

    function search_customer(){
    	
    	 $credit_items=array();
		$overpayments=array();
        $search = $this->request->getPost('payer_name');
        $type = $this->request->getPost('type');
        $db = \Config\Database::connect($this->dbname);
        if($this->request->getPost('paid_by') == 1){
            $names= $db->query('SELECT * FROM students 
                          WHERE `id` = \''.$search.'\' OR `full_name` LIKE \'%'.$search.'%\' OR `first_name` LIKE \'%'.$search.'%\' OR `last_name` LIKE \'%'.$search.'%\'');
            $result = $names->getResult();

            if(count($result) == 0){
            $name_parts = explode(" ", $search);
            if(count($name_parts)==3){
            	$first_name = $name_parts[0];
                $middle_name = $name_parts[1];
                $last_name = $name_parts[2];
                $names= $db->query('SELECT * FROM students 
                          WHERE `middle_name` LIKE \'%'.$middle_name.'%\' AND `first_name` LIKE \'%'.$first_name.'%\' AND `last_name` LIKE \'%'.$last_name.'%\'');
            $result = $names->getResult();
            }else if(count($name_parts)==2){
                $first_name = $name_parts[0];
                $middle_name = $name_parts[1];
                $names= $db->query('SELECT * FROM students 
                          WHERE `middle_name` LIKE \'%'.$middle_name.'%\' AND `first_name` LIKE \'%'.$first_name.'%\'');
            $result = $names->getResult();
                  }
                 }
                   if(count($result) > 0){

           
            foreach ($result as $rsl){
                $std=$this->studentModel->gettable_stdetail($rsl->id);
                if(count($std)>0){
                //$fullname = $rsl->first_name.' '.$rsl->last_name;

		//$overpayments=array();
		
        if($type ==0){
		$credit_item=$this->billmodel->get_credit_items('ledger_transaction_tbl',$where = array('trans_type'=>6,'transation_nature'=>2,'name_type_id'=>1),$rsl->id);
		if(count($credit_item)>0){
				$credit_items=$credit_item;
			}

		$overpayment=$this->billmodel->get_all_overpayment($rsl->id);
		//print_r($overpayment);
		if(count($overpayment)>0){
			$overpayments=$overpayment;	
			}
	}elseif($type >0){
		if($type ==6){
			$credit_item=$this->billmodel->get_credit_items('ledger_transaction_tbl',$where = array('trans_type'=>6,'transation_nature'=>2,'name_type_id'=>1),$rsl->id);
			if(count($credit_item)>0){
				$credit_items=$credit_item;
			}
		}else{
			$overpayment=$this->billmodel->get_all_overpayment($rsl->id);
			if(count($overpayment)>0){
			$overpayments=$overpayment;	
			}
			//print_r($overpayments);
		}
		
	}else{
echo "none none";
	}
	}else{
              
            }
            }
//print_r($overpayments);
$merged_list = array_merge($credit_items, $overpayments);
		// Sort the merged list by 'name' field
usort($merged_list, function($a, $b) {
    return strcmp($a->full_name, $b->full_name);
});

// Assign the sorted list to the data array
$data['list'] = $merged_list;
$data['receipt'] = 0;
	//	$data['list'] = array_merge($credit_items, $overpayments);
		echo view('bills/forms/refund_view',$data);  	
               
            
           
        }else{
          echo "<span style='color:red'>No any data Found</span>";
        }

        }else if($this->request->getPost('paid_by') == 2){
           //----deal with supply------------------->
        $names= $db->query('SELECT * FROM supplier_tbl 
                          WHERE `supplier_id` = \''.$search.'\' OR `supplier_name` LIKE \'%'.$search.'%\'');
            $result = $names->getResult();
            $student_now=0;	
            if(count($result) == 0){
            	$student_now=1;
            $name_parts = explode(" ", $search);
            
            $names= $db->query('SELECT * FROM students 
                          WHERE `middle_name` LIKE \'%'.$search.'%\' OR `first_name` LIKE \'%'.$search.'%\' OR `last_name` LIKE \'%'.$search.'%\'');
            $result = $names->getResult();
            
                 }

             if(count($result) > 0){

            foreach ($result as $rsl){
            	if($student_now==0){
            	$rsl->id=$rsl->supplier_id;	
            	}
            	$bills=$this->billmodel->get_bill_info('ledger_transaction_tbl',$where = array('ledger_transaction_tbl.trans_type'=>4,'transation_nature'=>2),$rsl->id);
		
                 $data['list'] = $bills;
                  $data['receipt'] = 2;

	//	$data['list'] = array_merge($credit_items, $overpayments);
		echo view('bills/forms/refund_view',$data);

            }
        }

           //----end deal with supply------------------->
        }
    }
 
 function billpay($id){
 	$bill_items=array();
 	$bills=$this->billmodel->get_bill_info('ledger_transaction_tbl',$where = array('ledger_transaction_tbl.trans_type'=>4,'transation_nature'=>2),$id);
		
$data['list'] = $bills;
$data['receipt'] = 2;

	//	$data['list'] = array_merge($credit_items, $overpayments);
		echo view('bills/forms/refund_view',$data);
 }

function view_voucher($id){
$data['recpt'] = $this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('id' => $id));
     $trans_number= $data['recpt'][0]->trans_number;	
    $pocket=$this->billmodel->get_item_name('pocket_money_transaction_tbl',$where = array('transaction_no' => $trans_number));
   $staff= $this->billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$trans_number,'trans_type' =>5,'name_type_id' =>7));
    if(count($pocket)>0){
    echo view('bills/forms/voucher_pocketMoney_printout',$data);
    }elseif($staff>0){
    	$name_id=$staff[0]->name_id;
    	$transNo=$trans_number;
$data['history']=$this->billmodel->get_staff_data($name_id,$transNo);
		echo view('bills/forms/salary_slip',$data);
    }
    else{
	echo view('bills/forms/voucher_view',$data);
      }
}

function search_receipt(){
    	
    	 $receipt_items=array();
		
        
        $type = $this->request->getPost('type');

        if($this->request->getPost('paid_by')==2){
        	$id = $this->request->getPost('receipt_number');
        	$receipt=$this->billmodel->get_bill_info('ledger_transaction_tbl',$where = array('ledger_transaction_tbl.trans_type'=>4,'transation_nature'=>2,'ledger_transaction_tbl.trans_no'=>$id),0);
        	//print_r($receipt);
        	$data['receipt'] = 2;
    
        }else{
        	$data['receipt'] = 1;
        	$id = $this->request->getPost('receipt_number');
        $receipt=$this->billmodel->get_refund_receipt($id);	
        }

         
         //print_r($receipt);


$data['list'] = $receipt;

echo view('bills/forms/refund_view',$data);

        }
        
  function SMSsender($dest,$msg,$type,$ref_no,$snn,$show_response=0) {
           $tmsg = $this->smodel->gettable_data('message_status_tbl',$where = array('status' => 1,));
                  if(count($tmsg)==0){
                   return;   
                  }
          if($snn==0){
          	       $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname.Tafadhali Fanya Malipo Kupitia CRDB.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => $type,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i'),
                    'send_by' =>session()->get('user_id'),
                    'messagex' => $messagex,
                    'trans_number' => $this->request->getPost('trno')
                  
                );
                
      
 $this->smodel->SaveData('message_groups_tbl',$smsdata); 
        }
             $messag = $this->sytm_model->load_messages_balances();

            $time_sent = time();
            $senderKey = 'SENDER_ID_' . session()->get('db_id');
            if (! defined($senderKey)) {
                return;
            }

            $senderid = constant($senderKey);
            if ($senderid) {
              $username=SMS_UNAME;
             $password=SMS_PASSWORD;
                 }else{
                     return;
                 }


             $destination = preg_replace('/\D+/', '', (string) $dest);
             if ($destination === '') {
                return;
             }

             $message = urlencode($msg);
             $senderid = urlencode($senderid);
             $status = 'FAILED';
             $note = 'SMS gateway request failed';
             $smsid = '';
             $cost = 0;
             $acc_cost = 0;
             $snt_status = 2;
             $msgid = '';

             $url = "https://www.sms.co.tz/api.php?do=sms&username={$username}&password={$password}&senderid={$senderid}&dest={$destination}&msg={$message}";
             $context = stream_context_create([
                'http' => [
                    'timeout' => 15,
                ],
             ]);
             $fetch = @file_get_contents($url, false, $context);

             if ($fetch !== false && trim($fetch) !== '') {
                $parts = array_map('trim', explode(',', $fetch, 3));
                $status = $parts[0] ?? 'FAILED';
                $note = $parts[1] ?? 'Unknown SMS gateway response';
                $smsid = $parts[2] ?? '';
             } else {
                log_message('error', 'SMS sending failed for destination: ' . $destination . ' and reference: ' . $ref_no);
             }

            if($show_response == 2){
              echo '<th>Message status:</th>';
              echo '<td><i>' . $note . '</i></td>';
            }
            if ($status == 'OK') {
                $msgid = $smsid;
                $snt_status = 1;    // Message sent successfully
                $cost = 45;
                $acc_cost = $cost;
                if($type!=5){
               // echo 'Message sent successfully';
                  }  
            }

       
                $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => $destination,
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
          
             $msg_details = $this->billmodel->get_item_name('messages',$where = array('send_no' => $snn,'reference_no' => $ref_no));
            //  if(count($msg_details)>0){
            //      $this->studentModel->update_table_details('messages',$where = array('mid' => $msg_details[0]->mid),$tempsmsdata); 
            //  }else{
     $this->studentModel->SaveData('messages',$tempsmsdata); 
            // }
           
          //  echo 'msg saved';

            if ($acc_cost > 0 && count($messag) > 0) {
                $balance = ($messag[0]->balance - $acc_cost);

               $smsDt = array(
                    'balance' => $balance,
                    'created_at' => date('Y/m/d H:i:s')
                );
            $this->sytm_model->update_sms_balance($smsDt, $messag[0]->b_id);
            }
        //  curl_close($curl);
     // echo 'successful sent';
    }
    
    function resendApprovalSms(){
    	$msg=$this->request->getPost('msg');
    	$transno=$this->request->getPost('trno');
    	$type=$this->request->getPost('type');
    	$billto=$this->request->getPost('billto');

    	$messagex="<transaction name> <transaction no> to <Name> for <amount> pending approval. Approve now: <link>";
 $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 13,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $transno
                  
                );
     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
    	$priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
    	if(count($priveleged)>0){
    		foreach($priveleged as $plv){

    		if (ctype_digit((string)$plv->privilege_id)) {
    			//echo "yes ".$plv->privilege_id;
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>session()->get('db_id')));
              // print_r($assigned_user);
              $this->studentModel->SaveData('message_groups_tbl',$smsdata);
               foreach($assigned_user as $user){
               	if($user->phone_no !=""){
       $cleanPhone = sanitize_phone($user->phone_no);
if ($cleanPhone) {
    try {
          $this->SMSsender($cleanPhone,$msg,13,$billto,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
           $data=array(
           'phone_no'=>$user->phone_no,
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           );
              }
               }
    			}else{
             // echo "no-".$plv->privilege_id;
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));

              if(count($assigned_approval)>0){
                   $this->studentModel->SaveData('message_groups_tbl',$smsdata);
                foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>session()->get('db_id')));
              	if($assigned_user[0]->phone_no !=""){
          
               $cleanPhone = sanitize_phone($assigned_user[0]->phone_no);
if ($cleanPhone) {
    try {
          $this->SMSsender($cleanPhone,$msg,13,$billto,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $assigned_user[0]->phone_no);
}
            
            $data=array(
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

          }
          }
                }
    			}

    			//print_r($data);
    		}
    	}
    }
         $id = $transno;
			$data['bll'] = $this->billmodel->get_edit_bill($id);
		return view('bills/edit_bill',$data);
    }
    
    function search_staff()
	{
		$search = $this->request->getPost('matron_name');
        $db = \Config\Database::connect($this->dbname);
          
          $names= $db->query('SELECT * FROM users 
                          WHERE `first_name` = \''.$search.'\' OR `other_name` LIKE \'%'.$search.'%\' OR `first_name` LIKE \'%'.$search.'%\' OR `last_name` LIKE \'%'.$search.'%\'');
            $result = $names->getResult();
          if(count($result) > 0){

            echo
            '<table class="table table-hover">
            <thead>
                 <tr>
                    <th>ID</th>
                    <th>Staff Name</th>
                    <th>User type</th>
                    <th>Phone</th>
                    <th></th>
                </tr>
            </thead><tbody>';
            foreach ($result as $supl){
               $staff = $this->billmodel->get_item_name('users',$where = array('user_id' => $supl->user_id,'database_id'=>session()->get('db_id')));
                if(count($staff)>0){
                $types = $this->billmodel->get_item_name('users_type_tbl',$where = array('id' => $staff[0]->user_type));

                $fullname = $staff[0]->first_name.' '.$staff[0]->last_name;
                echo '<tr><td>'.$supl->user_id.'</td>';
                echo '<td>'.$fullname.'</td>';
                echo '<td>'.$types[0]->type_name.'</td>';
                echo '<td>'.$staff[0]->phone_no.'</td>';
               echo '<td><button class="btn btn-primary btn-sm" onclick="select_staff('.$supl->user_id.',\''.$fullname.'\',event)">select</button></td></tr>';
            }
        
            }
            echo '</tbody>';
        }else{
          echo "<span style='color:red'>No any data Found</span>";
        }

        
	}

function process_refund_pocketMoney(){
    if($this->request->getPost('year2')==0){
        return;
    }
		$db_id=session()->get('db_id');
	$voucher=$this->request->getPost("voucher");
	//print_r($voucher);
     // return;
	$trans = $this->generate_payment_no();
	$total=0;
	 $transaction = [
              'trans_type_id' => 5,
              'trans_number' => $trans,
              'trans_date' => $this->request->getPost('voucher_date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s'),
              
      ];
      $this->studentModel->SaveData('transaction_numbers_tbl',$transaction);

       $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 5,
             'invoice_type_id' => 9
         ];
        $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);

	foreach($voucher as $v)
	{
		$amount=$this->request->getPost("amount".$v);
			$balance=$this->request->getPost("p_balance".$v);
		$amount=str_replace(',', '', $amount);
		$cleanBalance=str_replace(',', '', $balance);
		if($amount !="" || $amount !=0){
			//echo "amount-> ". str_replace(',', '', $amount)."</br>";

     
      $amount=(int)$amount;
          $cleanBalance=(int)$cleanBalance;
      if($amount==0){
      	continue;
      }
      $payedamount = $amount; 
       $final_balance=$cleanBalance-$amount;
       $nature=2;
        
            $pocket = [
                       'account_id' => 10,
                       'transaction_no' => $trans,
                       'amount_given' => $amount,
                        'p_balance' => $final_balance,
                       'student_id' => $this->request->getPost('student'.$v),
                       'trans_used' => 0,
                       'academic_year' => $this->request->getPost('year2'),
                       
                   ]; 
         $this->studentModel->SaveData('pocket_money_transaction_tbl',$pocket);
         
       $total=$total+$amount;
   }
 }
       
         $rcledger = [
                       'ledger_id' => 10,
                       'ledger_type' => 2,
                       'trans_item' => 0,
                       'trans_no' => $trans,
                       'trans_type' => 5,
                       'amount' => $total,
                       'transation_nature' => 2,
                       'name_type_id' => $this->request->getPost('name_type_id'),//temp
                       'name_id' => $this->request->getPost('student_id'),
                       
                   ];
  //   print_r($rcledger);
               $payid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$rcledger);

               $relation_transation = [
                       'trans_no' => 0,
                       'payment_no ' => $trans,
                       'voucher_type ' => $this->request->getPost('voucher_type'),
                       'trans_type ' =>3,
                       'reason' =>$this->request->getPost('reason'),
                         ];
                $this->studentModel->SaveData('voucher_relation_tbl',$relation_transation);

               $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $this->request->getPost('bank'))); 
                $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 5,
                  'trans_item' => 0,
               'amount' => $total,
               'transation_nature' =>1,
               'name_type_id' => $this->request->getPost('name_type_id'),
               'name_id' => $this->request->getPost('student_id'),
           ];

         $chek_lg = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('ledger_id' => $Bank_leger[0]->id,'ledger_type'=>$Bank_leger[0]->account_type_id,'trans_no'=>$trans,'trans_type'=>5,'transation_nature'=>1)); 
          if(count($chek_lg)>0){

         }else{
           $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);
       }

       ////////////function to insert approval data /////////////
					$approval = [
					'trans_type'=>5,
					'trans_no'=>$trans,
					'name'=>$this->request->getPost('student_id'),
					'name_type'=>$this->request->getPost('name_type_id'),
				];

		
			$app_hist_id = $this->billmodel->save_approval_data('approval_numbers',$approval);

			$app_history =[
				'app_no'=>$app_hist_id,
				'user'=>$this->request->getPost('header_id'),
				'user_role'=>1,
				'comment'=>$this->request->getPost('reason'),
				'hstatus'=>3,
				'hist_date'=>date('Y-m-d H:i:s'),
			];
			$this->billmodel->save_approval_history_data('approval_history',$app_history);

			//here we go
           	//send message to approvals
			 $billto=$this->request->getPost('student_id');
			// $url=base_url("?redirect=reapproval");
           
           $s_name="";
           if($this->request->getPost('name_type_id')==1){
            $t_name = $this->billmodel->get_item_name('students',$where = array('id' => $billto));
            $s_name=$t_name[0]->first_name.' '.$t_name[0]->last_name;
           }
           if($this->request->getPost('name_type_id')==2){
            $t_name = $this->billmodel->get_item_name('supplier_tbl',$where = array('supplier_id' => $billto));
            $s_name=$t_name[0]->supplier_name;
           }
           if($this->request->getPost('name_type_id')==5){
           	 
           $t_name = $this->billmodel->get_item_name('parents_tbl',$where = array('id' => $billto));
             $s_name=$t_name[0]->first_name.' '.$t_name[0]->last_name;
           }
            if($this->request->getPost('name_type_id')==7){
           	 
           $t_name = $this->billmodel->get_item_name('users',$where = array('user_id' => $billto));
             $s_name=$t_name[0]->first_name.' '.$t_name[0]->last_name;
           }
           

			$messagex="<transaction name> <transaction no> to <Name> with amount <amount> is pending your approval.";

             $msg = "Voucher ".$trans." to ".$s_name." for ".number_format($total)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";

     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 14,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
    
   
     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
    	$priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
    	if(count($priveleged)>0){
    		foreach($priveleged as $plv){

    		if (ctype_digit((string)$plv->privilege_id)) {
    			//echo "yes ".$plv->privilege_id;
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>$db_id));
              // print_r($assigned_user);
                $this->studentModel->SaveData('message_groups_tbl',$smsdata);
               foreach($assigned_user as $user){
               	if($user->phone_no !=""){
       $cleanPhone = sanitize_phone($user->phone_no);
if ($cleanPhone) {
    try {
          $this->SMSsender($cleanPhone,$msg,14,$user->user_id,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
           $data=array(
           'phone_no'=>$user->phone_no,
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           );
              }
               }
    			}else{
             // echo "no-".$plv->privilege_id;
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));
              if(count($assigned_approval)>0){

              	foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>$db_id));

              
              	if($assigned_user[0]->phone_no !=""){
          $this->studentModel->SaveData('message_groups_tbl',$smsdata);
                 $cleanPhone = sanitize_phone($assigned_user[0]->phone_no);
if ($cleanPhone) {
    try {
 $this->SMSsender($cleanPhone,$msg,14,$assigned_user[0]->user_id,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $assigned_user[0]->phone_no);
}
            
            $data=array(
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

          }
      }

                }
    			}

    			//print_r($data);
    		}
    	}
    }

   //  end message to approvals;
			//------------

   return $this->response->setJSON([
        'status' => 1,
        'description' => 'Payment saved successfully',
    ]);

	}
	
	function search_supplier()
	{

		$sms_balance = $this->billmodel->get_item_name('messages_balances',$where = array('balance !=' => ""));
		$balance=0;
		if(count($sms_balance)>0){
			$balance=$sms_balance[0]->balance;
		}
		$search = $this->request->getPost('supplier_name');
        $db = \Config\Database::connect($this->dbname);
          
            $names= $db->query('SELECT * FROM supplier_tbl 
                          WHERE `supplier_id` = \''.$search.'\' OR `supplier_name` LIKE \'%'.$search.'%\'');
            $result = $names->getResult();
          if(count($result) > 0){

            echo
            '<table class="table table-hover">
            <thead>
                 <tr>
                    <th>ID</th>
                    <th>Supplier Name</th>
                    <th>Phone</th>
                    <th>Address</th>
                  
                </tr>
            </thead><tbody>';
            foreach ($result as $supl){
                $suppl=$this->billmodel->get_supplierdetail($supl->supplier_id);
                if(count($suppl)>0){
                $fullname = $suppl[0]->supplier_name;
                echo '<tr><td>'.$supl->supplier_id.'</td>';
                echo '<td>'.$fullname.'</td>';
                echo '<td>'.$suppl[0]->supplier_phone.'</td>';
                echo '<td>'.$suppl[0]->supplier_address.'</td>';
               echo '<td><button class="btn btn-primary btn-sm" onclick="select_supplier('.$supl->supplier_id.',\''.$fullname.'\','.$balance.',event)">select</button></td></tr>';
            }
        
            }
            echo '</tbody>';
        }else{
          echo "<span style='color:red'>No any data Found</span>";
        }


}

function process_sms_recharge(){
	$db_id=session()->get('db_id');
	
	$trans = $this->generate_payment_no();
	$total=0;
	 $transaction = [
              'trans_type_id' => 5,
              'trans_number' => $trans,
              'trans_date' => $this->request->getPost('voucher_date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s'),
              
      ];
      $this->studentModel->SaveData('transaction_numbers_tbl',$transaction);

       $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 5,
             'invoice_type_id' => 3
         ];
        $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);

		$amount=$this->request->getPost("recharge_amount");
		$amount=str_replace(',', '', $amount);
		if($amount !="" || $amount !=0){
			//echo "amount-> ". str_replace(',', '', $amount)."</br>";

     
      $amount=(int)$amount;
      if($amount==0){
      	return;
      }
      $payedamount = $amount; 
       //$trno = $this->request->getPost('trans_no'.$v);

          $nature=2;
         
       $total=$total+$amount;
   }else{
   	echo json_encode(array('status' => 1,'description' => 'Fail to save, amount is 0'));
   	return;
   }
 
     $expense_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $this->request->getPost('expense_ledger')));
         $rcledger = [
                       'ledger_id' => $expense_leger[0]->id,
                       'ledger_type' =>$expense_leger[0]->account_type_id,
                       'trans_item' => 0,
                       'trans_no' => $trans,
                       'trans_type' => 5,
                       'amount' => $total,
                       'transation_nature' => 2,
                       'name_type_id' => 2,//temp
                       'name_id' => $this->request->getPost('supplier_id'),
                       
                   ];
  //   print_r($rcledger);
             $payid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$rcledger);

               $relation_transation = [
                       'trans_no' => 0,
                       'payment_no' => $trans,
                       'voucher_type' => $this->request->getPost('voucher_type'),
                       'trans_type' => 0,
                       'reason' =>$this->request->getPost('reason'),
                         ];
                $this->studentModel->SaveData('voucher_relation_tbl',$relation_transation);

               $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $this->request->getPost('bank'))); 
                $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 5,
               'amount' => $total,
               'transation_nature' =>1,
               'name_type_id' => 2,//temp
               'name_id' => $this->request->getPost('supplier_id'),
           ];

         $chek_lg = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('ledger_id' => $Bank_leger[0]->id,'ledger_type'=>$Bank_leger[0]->account_type_id,'trans_no'=>$trans,'trans_type'=>5,'transation_nature'=>1)); 
          if(count($chek_lg)>0){

         }else{
           $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);
       }

       ////////////function to insert approval data /////////////
					$approval = [
					'trans_type'=>5,
					'trans_no'=>$trans,
					'name'=>$this->request->getPost('supplier_id'),
					'name_type'=>2,
				];

			$app_hist_id = $this->billmodel->save_approval_data('approval_numbers',$approval);

			$app_history =[
				'app_no'=>$app_hist_id,
				'user'=>$this->request->getPost('header_id'),
				'user_role'=>1,
				'comment'=>$this->request->getPost('reason'),
				'hstatus'=>3,
				'hist_date'=>date('Y-m-d H:i:s'),
			];
			$this->billmodel->save_approval_history_data('approval_history',$app_history);

			//here we go
           	//send message to approvals
			 $billto=$this->request->getPost('supplier_id');
			// $url=base_url("?redirect=reapproval");
           
           $s_name="";
          
          $t_name = $this->billmodel->get_item_name('supplier_tbl',$where = array('supplier_id' => $billto));
            $s_name=$t_name[0]->supplier_name;
           
           $messagex="<transaction name> <transaction no> to <Name> with amount <amount> is pending your approval.";

             $msg = "Voucher ".$trans." to ".$s_name." for ".number_format($total)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";

     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 14,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
    
   
     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
    	$priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
    	if(count($priveleged)>0){
    		foreach($priveleged as $plv){

    		if (ctype_digit((string)$plv->privilege_id)) {
    			//echo "yes ".$plv->privilege_id;
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>$db_id));
              // print_r($assigned_user);
                $this->studentModel->SaveData('message_groups_tbl',$smsdata);
               foreach($assigned_user as $user){
               	if($user->phone_no !=""){
          

            $this->SMSsender($user->phone_no,$msg,13,$billto,$snn,NULL);

           $data=array(
           'phone_no'=>$user->phone_no,
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           );
              }
               }
    			}else{
             // echo "no-".$plv->privilege_id;
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));
              if(count($assigned_approval)>0){

              	foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>$db_id));

              
              	if($assigned_user[0]->phone_no !=""){
          $this->studentModel->SaveData('message_groups_tbl',$smsdata);

             $this->SMSsender($assigned_user[0]->phone_no,$msg,14,$billto,$snn,NULL);
             //print_r($assigned_user);
            
            $data=array(
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

              }
             }

            }
    	   }

    			//print_r($data);
      }
    }
    }

   //  end message to approvals;
	
   echo json_encode(array('status' => 1,'description' => 'Payment saved successfully'));

	}
	
function transfer()
	{
		return view('templates/header')
			.view('transfer/transfer')
			.view('templates/footer');
	}

	function bank_transfers($from,$to){
		$data['from']=$from;
		$data['to']=$to;
     echo view('bills/forms/bank_transfer',$data);
	}

	function save_transfer_details(){
		$db_id=session()->get('db_id');
		$trans = $this->generate_trans_no(8);
	$total=0;
	 $transaction = [
              'trans_type_id' => 8,
              'trans_number' => $trans,
              'trans_date' => $this->request->getPost('transfer_date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s'),
              
      ];
      $this->studentModel->SaveData('transaction_numbers_tbl',$transaction);

      $amount=$this->request->getPost("amount");
		$amount=str_replace(',', '', $amount);
		if($amount !="" || $amount !=0){
		 $amount=(int)$amount;
      if($amount==0){
      	return;
      }
      
        $total=$total+$amount;
   }else{
   	echo json_encode(array('status' => 1,'description' => 'Fail to save, amount is 0'));
   	return;
   }

    $leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $this->request->getPost('bank')));
      $from=$leger[0]->account_name;

         $rcledger = [
                       'ledger_id' => $leger[0]->id,
                       'ledger_type' =>$leger[0]->account_type_id,
                       'trans_item' => 0,
                       'trans_no' => $trans,
                       'trans_type' => 8,
                       'amount' => $total,
                       'transation_nature' => 1,
                       'name_type_id' => 7,
                       'name_id' => $this->request->getPost('header_id'),
                       
                   ];
  //   print_r($rcledger);
             $payid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$rcledger);

             $r_transation = [
                       'transfer_no' => $trans,
                       'transfer_amount' => $total,
                       'reason' =>$this->request->getPost('reason'),
                         ];
        $this->studentModel->SaveData('transfer_payment_tbl',$r_transation);

          $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $this->request->getPost('bank_to'))); 
          $to=$Bank_leger[0]->account_name;
                $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 8,
               'amount' => $total,
               'transation_nature' =>2,
               'name_type_id' => 7,
               'name_id' => $this->request->getPost('header_id'),
           ];

        $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);

        ////////////function to insert approval data /////////////
					$approval = [
					'trans_type'=>8,
					'trans_no'=>$trans,
					'name'=>$this->request->getPost('header_id'),
					'name_type'=>7,
				];

			$app_hist_id = $this->billmodel->save_approval_data('approval_numbers',$approval);

			$app_history =[
				'app_no'=>$app_hist_id,
				'user'=>$this->request->getPost('header_id'),
				'user_role'=>1,
				'comment'=>$this->request->getPost('reason'),
				'hstatus'=>3,
				'hist_date'=>date('Y-m-d H:i:s'),
			];
			$this->billmodel->save_approval_history_data('approval_history',$app_history);

		$messagex="<transaction name> <transaction no> from <accName> to <accName> amount <amount> is pending your approval.";
             
             $s_name="";
             $msg = "Transfer ".$trans." from ".$from." to ".$to." Amount ".number_format($total)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 15,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );

     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
    	$priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
    	if(count($priveleged)>0){
    		foreach($priveleged as $plv){

    		if (ctype_digit((string)$plv->privilege_id)) {
    			//echo "yes ".$plv->privilege_id;
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>$db_id));
              // print_r($assigned_user);
                $this->studentModel->SaveData('message_groups_tbl',$smsdata);
               foreach($assigned_user as $user){
               	if($user->phone_no !=""){
          

            $this->SMSsender($user->phone_no,$msg,15,$user->user_id,$snn,NULL);

           $data=array(
           'phone_no'=>$user->phone_no,
           'msg'=>$msg,
           'snn'=>$snn,
           );
              }
               }
    			}else{
             // echo "no-".$plv->privilege_id;
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));
              if(count($assigned_approval)>0){

              	foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>$db_id));

              
              	if($assigned_user[0]->phone_no !=""){
           $this->studentModel->SaveData('message_groups_tbl',$smsdata);

             $this->SMSsender($assigned_user[0]->phone_no,$msg,15,$assigned_user[0]->user_id,$snn,NULL);
             //print_r($assigned_user);
            
            $data=array(
           'msg'=>$msg,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

            }}}}
            
	//print_r($data);
             }}}
     echo json_encode(array('status' => 1,'description' => 'Transfer saved successfully'));

   }

	function generate_trans_no($tn) {
        $ino = "";
        $tkens = $this->billmodel->get_max_payment('transaction_numbers_tbl','trans_number',$tn);
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }

    function transfer_list(){
    	 $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            
            $data = array(
               'trans' => $this->billmodel->get_item_name2('transaction_numbers_tbl',$where = array('trans_type_id' => 8),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))
            );
           echo view('bills/forms/transfer_list',$data);
    }	
    
     function get_edit_approval_data()
	{
		$id = $this->request->getVar('trans_no');
		$vocher= $this->request->getVar('vocher');
		$trans_type = $this->request->getVar('trans_type');
		$data = array(
               'inv' => $this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$id,'trans_type_id'=>$trans_type))
            );
            	$data['advances']=$this->billmodel->Check_salary_advance($id);
		$data['vocher']=$vocher;
				$data['trans_types']=$trans_type;
		if($trans_type==4){
      return view('bills/edit_approval',$data);
		}
		if($trans_type==5){
	   return view('bills/forms/edit_approval5',$data);		
		}

		if($trans_type==8){
	   return view('transfer/edit_approvals8',$data);		
		}
				if($trans_type==10){
 return view('bills/forms/edit_approval10',$data);		
		}
		
   }

function delete_approval_data(){
	$student_id = $this->request->getVar('student_id');
	$trans_number= $this->request->getVar('trans_number');
	$amount = $this->request->getVar('amount');
 $check_numb = $this->billmodel->get_item_name('pocket_money_transaction_tbl',$where = array('transaction_no' =>$trans_number));

 if(count($check_numb)>1){
 	$check_only1 = $this->billmodel->get_item_name('pocket_money_transaction_tbl',$where = array('transaction_no' =>$trans_number,'student_id'=>$student_id,'amount_given'=>$amount));

	$this->billmodel->deletetable_data('pocket_money_transaction_tbl',$where = array('id' =>$check_only1[0]->id));

	 $ledger = $this->billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$trans_number,'trans_type'=>5));
	 $check_all = $this->billmodel->get_item_name('pocket_money_transaction_tbl',$where = array('transaction_no' =>$trans_number));
	 $remain_amount=0;
	 foreach($check_all as $all){
	 $remain_amount+=$all->amount_given;	
	 }
       
      // $remain_amount=$ledger[0]->amount - (int)$amount;
       $data=array(
         'amount'=>$remain_amount
       );
	$this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' =>$trans_number,'trans_type'=>5,),$data);

	$data = array(
         'inv' => $this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$trans_number,'trans_type_id'=>5))
            );
		$data['vocher']=1;
return view('bills/forms/edit_approval5',$data);
}else{
	echo 1;
}	
	
}

function edit_approval_data(){
   $student_id = $this->request->getVar('student_id');
	$trans_number= $this->request->getVar('trans_number');
	$amount = (int)$this->request->getVar('amount');

	$check_numb = $this->billmodel->get_item_name('pocket_money_transaction_tbl',$where = array('transaction_no' =>$trans_number,'student_id'=>$student_id));

if(count($check_numb)>0 && $amount >0){
$last_amount=$check_numb[0]->amount_given;
$balance_difference=$check_numb[0]->amount_given - $amount;
$current_balance=$check_numb[0]->p_balance+$balance_difference;
	 $data=array(
         'amount_given'=>$amount,
         'p_balance'=>$current_balance
       );
	$this->billmodel->update_table_details('pocket_money_transaction_tbl',$where = array('id' =>$check_numb[0]->id),$data);

	$ledger = $this->billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$trans_number,'trans_type'=>5));
       
       $remain_amount=$ledger[0]->amount - $last_amount;
       $remain_amount=$remain_amount + (int)$amount;
       $data=array(
         'amount'=>$remain_amount
       );
	$this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' =>$trans_number,'trans_type'=>5,),$data);

	$data = array(
         'inv' => $this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$trans_number,'trans_type_id'=>5))
            );
		$data['vocher']=1;
return view('bills/forms/edit_approval5',$data);

}else{
	echo 1;
}
}

function edit_ledger_account(){
	$n = $this->request->getVar('n');
	$acc_id = $this->request->getVar('acc_id');
	$trans_number= $this->request->getVar('trans_number');
	$trans_type= $this->request->getVar('trans_type');

	 $data=array(
         'ledger_id'=>$acc_id
       );
	 if($n==1){
	$this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('ledger_type' =>9,'trans_no'=>$trans_number,'trans_type'=>$trans_type),$data);
     }

     if($n==2){
     	//print_r($data);
	$this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('ledger_type !=' =>9,'trans_no'=>$trans_number,'trans_type'=>$trans_type),$data);
     }

	$data = array(
         'inv' => $this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$trans_number,'trans_type_id'=>5))
            );
		$data['vocher']=1;

		$data2=array(
              'edited_date'=>date('Y-m-d H:i:s'),
            );

$ap_number= $this->billmodel->get_item_name('approval_numbers',$where = array('trans_no' =>$trans_number,'trans_type'=>$trans_type));

$this->billmodel->update_table_details('approval_history',$where = array('app_no' => $ap_number[0]->app_id,'hstatus'=>3),$data2);

return view('bills/forms/edit_approval5',$data);

}

function edit_refund_data(){
	$old_trans_no = $this->request->getVar('old_trans_no');
	$trans_number= $this->request->getVar('trans_number');
	$trans_type= $this->request->getVar('trans_type');
	$amount= (int)$this->request->getVar('amount');
   if($trans_type==2){
    $n=2;
     $old_ledger = $this->billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$old_trans_no,'trans_type'=>$trans_type,'transation_nature'=>2,'ledger_id'=>21));
   }else{
     $n=1;
     $old_ledger = $this->billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$old_trans_no,'trans_type'=>$trans_type,'transation_nature'=>1));
   }

   $ledger = $this->billmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$trans_number,'trans_type'=>5));
   
   $last_amount=$ledger[0]->amount;

      $remain_balance=$old_ledger[0]->balance + $last_amount;
       $remain_balance=$remain_balance - (int)$amount;

    $data=array(
         'amount'=>$amount,
         'balance'=>$remain_balance
       );

    $datab=array(
         'balance'=>$remain_balance
       );
    $this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no'=>$trans_number,'trans_type'=>5),$data);
    $this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('id'=>$old_ledger[0]->id),$datab);

    $data = array(
         'inv' => $this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$trans_number,'trans_type_id'=>5))
            );
		$data['vocher']=1;
return view('bills/forms/edit_approval5',$data);

}

function edit_sms_data(){

	$trans_number= $this->request->getVar('trans_number');
	$amount= (int)$this->request->getVar('amount');	
	 $data=array(
         'amount'=>$amount,
        
       );
	 if($amount >0){
	 $this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no'=>$trans_number,'trans_type'=>5),$data);
	  $data = array(
         'inv' => $this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$trans_number,'trans_type_id'=>5))
            );
		$data['vocher']=1;
return view('bills/forms/edit_approval5',$data);
}else{
	echo 1;
}
}

function edit_transfer_data(){
  $trans_number= $this->request->getVar('trans_number');
 $amount= (int)$this->request->getVar('amount');

       $data1=array(
         'amount'=>$amount,
        );

       $data2=array(
         'transfer_amount'=>$amount,
        );
 	 if($amount >0){
	 $this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no'=>$trans_number,'trans_type'=>8),$data1);
	  $this->billmodel->update_table_details('transfer_payment_tbl',$where = array('transfer_no'=>$trans_number),$data2);
	  $data = array(
         'inv' => $this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$trans_number,'trans_type_id'=>8))
            );
		$data['vocher']=1;
return view('transfer/edit_approvals8',$data);
}else{
	echo 1;
}

}

function edit_transfer_account(){
 $acc_id= $this->request->getVar('acc_id');
 $trans_number= $this->request->getVar('trans_number');
 $acc= (int)$this->request->getVar('acc')+1;

$data=array(
         'ledger_id'=>$acc_id
       );
	$this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('ledger_type' =>9,'trans_no'=>$trans_number,'trans_type'=>8,'transation_nature'=>$acc),$data);

	$data = array(
         'inv' => $this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$trans_number,'trans_type_id'=>8))
            );
		$data['vocher']=1;
return view('transfer/edit_approvals8',$data);

}

function update_transDate($trans_number,$dt,$type,$n){
     

      if($n==1){
      	 $data=array(
              'trans_date'=>$dt,
            );
    $this->billmodel->update_table_details('transaction_numbers_tbl',$where = array('trans_number' => $trans_number,'trans_type_id'=>$type),$data);

      }
      if($n==2){
      	 $data=array(
              'due_date'=>$dt,
            );
      $this->billmodel->update_table_details('transaction_other_details_tbl',$where = array('transaction_no' => $trans_number,'transaction_type'=>$type),$data);	
      }
   if($n==3){
      	 $data=array(
              'bill_reference'=>$dt,
            );
      $this->billmodel->update_table_details('transaction_other_details_tbl',$where = array('transaction_no' => $trans_number,'transaction_type'=>$type),$data);	
      }

      if($n==4){
      	 $data=array(
              'name_id'=>$dt,
            );
      $this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $trans_number,'trans_type'=>$type),$data);	
      }

$data2=array(
              'edited_date'=>date('Y-m-d H:i:s'),
            );

$ap_number= $this->billmodel->get_item_name('approval_numbers',$where = array('trans_no' =>$trans_number,'trans_type'=>$type));

$this->billmodel->update_table_details('approval_history',$where = array('app_no' => $ap_number[0]->app_id,'hstatus'=>3),$data2);
 if($type==4){
 	$data['bll'] = $this->billmodel->get_edit_bill($trans_number);
	return view('bills/edit_bill',$data);
 }
  if($type==5){
 	$data = array(
         'inv' => $this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$trans_number,'trans_type_id'=>5))
            );
		$data['vocher']=1;
return view('bills/forms/edit_approval5',$data);
 }
//echo 1;
}

function load_class_choices(){
return view('bills/forms/pocket_money_filter_class');	
}

function update_refund_pocketMoney(){
		$db_id=session()->get('db_id');
	$voucher=$this->request->getPost("voucher");
	//print_r($voucher);
     // return;
	$trans = $this->request->getPost('trans');
	$total=0;
	 $transaction = [
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s'),
              
      ];
     
      $this->billmodel->update_table_details('transaction_numbers_tbl',$where = array('trans_number' => $trans,'trans_type_id'=>5),$transaction);

	foreach($voucher as $v)
	{
		$amount=$this->request->getPost("amount".$v);
		$amount=str_replace(',', '', $amount);
		if($amount !="" || $amount !=0){
			//echo "amount-> ". str_replace(',', '', $amount)."</br>";

     
      $amount=(int)$amount;
      if($amount==0){
      	continue;
      }
      $payedamount = $amount; 
      
       $nature=2;
        
            $pocket = [
                       'account_id' => 10,
                       'transaction_no' => $trans,
                       'amount_given' => $amount,
                       'student_id' => $this->request->getPost('student'.$v),
                       'trans_used' => 0,
                       'academic_year' => $this->request->getPost('year'),
                       
                   ]; 
         $this->studentModel->SaveData('pocket_money_transaction_tbl',$pocket);
         
       $total=$total+$amount;
   }
 }
    $ledger_amout = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trans,'trans_type'=>5));
         $rcledger = [
                       'amount' => $total+$ledger_amout[0]->amount,
                       
                   ];
  //   print_r($rcledger);
                $this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $trans,'trans_type'=>5),$rcledger);


       ////////////function to insert approval data /////////////
					
			$appnumber_id = $this->studentModel->gettable_data('approval_numbers',$where = array('trans_no' => $trans,'trans_type'=>5));
			$app_hist_id = $appnumber_id[0]->app_id;

			$app_history =[
				'edited_date'=>date('Y-m-d H:i:s'),
			];
			$this->billmodel->update_table_details('approval_history',$where = array('app_no' => $app_hist_id), $app_history);

			//here we go
    echo json_encode(array('status' => 1,'description' => 'Payment added successfully'));

	}
	
function control_number_charges_list(){
     $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            
            $charge=$this->billmodel->get_control_charges('ledger_transaction_tbl',$where = array('trans_type_id' => 2),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
            $allData=array();
            foreach($charge as $rg){
               //echo $rg->amount.'</br>';
            	if($rg->balance ==0){
                      		continue;
                      	}
            	if($rg->name_type_id==1){
            	$student = $this->studentModel->gettable_specific_data('students',$where = array('id' => $rg->name_id),$data=array('id','full_name'));	
            	}
            if($rg->name_type_id==4){
            	$student = $this->studentModel->gettable_specific_data('students_application_tbl',$where = array('id' => $rg->name_id,),$data=array('id','full_name'));	
            	}
          	
          $rel = $this->studentModel->gettable_specific_data('transactions_relation',$where = array('receipt_trans_no' => $rg->trans_number),$data=array('invoice_trans_no'));
          if(count($rel)==0){
          	continue;
          }
          $inv = $this->studentModel->gettable_specific_data('invoice_type_transaction',$where = array('trans_no' => $rel[0]->invoice_trans_no,'transaction_type_id'=>1),$data=array('invoice_type_id'));
          $inv_name = $this->studentModel->gettable_specific_data('invoice_types_tbl',$where = array('id' => $inv[0]->invoice_type_id),$data=array('type_name'));

          $ctr = $this->studentModel->gettable_specific_data('payment_request',$where = array('trans_no' => $rel[0]->invoice_trans_no,'student_id'=>$rg->name_id,'trans_type'=>1),$data=array('reference_no'));
            $reference="";
          if(count($ctr)>0){
          	$reference=$ctr[0]->reference_no;
          }
          $type_name="";
          if(count($inv_name)>0){
          	$type_name=$inv_name[0]->type_name;
          }
          
               $data = array("student_id" => $rg->name_id,"trans_number" => $rg->trans_number, "invoice_type" => $type_name, "name" => $student[0]->full_name, "control" => $reference, "amount" => $rg->balance, "trans_date" => $rg->trans_date,"name_type_id"=>$rg->name_type_id,'trans_no'=>$rel[0]->invoice_trans_no);
                array_push($allData, $data);
               }

         $data = array(
               'trans' => $allData
            );
             // print_r($allData);
             // return;
          echo view('bills/forms/students_charged_list',$data);
	}

	function payControlNumber(){
           
		$db_id=session()->get('db_id');
		$total=0;
	$voucher=$this->request->getPost("voucher");
	// print_r($voucher);
    //   return;
    $trans = $this->generate_payment_no();
     $transaction = [
              'trans_type_id' => 5,
              'trans_number' => $trans,
              'trans_date' => $this->request->getPost('voucher_date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s'),
              
                ];
      $this->studentModel->SaveData('transaction_numbers_tbl',$transaction);

	foreach($voucher as $v){
		$amount=$this->request->getPost("amount".$v);
		$amount=str_replace(',', '', $amount);
			$amount=(int)$amount;
		if($amount >0){
		
      $payedamount = $amount; 
       $trno = $this->request->getPost('trans_no'.$v);

         $clg= $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trno,'trans_type' => 2,'ledger_id'=>22));
        
         $balance=$clg[0]->balance-$amount;
          $nature=1;
     
          $cbalance = array(
                    'balance' => $balance
                );
       
          $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $clg[0]->id),$cbalance);

           $payed = [
                       'inv_no' =>  $this->request->getPost('inv_no'.$v),
                       'rct_no' =>  $trno,
                       'trans_no' => $trans,
                       'amount' => $amount,
                       'student_id' => $this->request->getPost('student_id'.$v),
                       'name_type_id' => $this->request->getPost('name_type_id'.$v),
                       
                   ]; 
         $this->studentModel->SaveData('control_number_charges_payments_tbl',$payed);

          $total=$total+$amount;

          }else{
              continue;
          }

	}
         
           $rcledger = [
                       'ledger_id' => 22,
                       'ledger_type' => 13,
                       'trans_item' => 0,
                       'trans_no' => $trans,
                       'trans_type' => 5,
                       'amount' => $total,
                       'transation_nature' => 2,
                       'name_type_id' => 2,
                       'name_id' => $this->request->getPost('supplier_id'),
                       'balance' => 0
                   ];
  //   print_r($rcledger);
               $payid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$rcledger);

               $relation_transation = [
                       'trans_no' => $trno,
                       'payment_no ' => $trans,
                       'voucher_type ' => $this->request->getPost('voucher_type'),
                       'trans_type ' =>2,
                       'reason' =>$this->request->getPost('reason'),
                         ];
                $this->studentModel->SaveData('voucher_relation_tbl',$relation_transation);

               $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $this->request->getPost('bank'))); 
                $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 5,
               'amount' => $total,
               'transation_nature' =>1,
               'name_type_id' =>2,
               'name_id' => $this->request->getPost('supplier_id'),
           ];

         $chek_lg = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('ledger_id' => $Bank_leger[0]->id,'ledger_type'=>$Bank_leger[0]->account_type_id,'trans_no'=>$trans,'trans_type'=>5,'transation_nature'=>1)); 
          if(count($chek_lg)>0){

         }else{
           $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);
       }

       ////////////function to insert approval data /////////////
					$approval = [
					'trans_type'=>5,
					'trans_no'=>$trans,
					'name'=>2,
					'name_type'=>$this->request->getPost('supplier_id'),
				];

			// $this->billmodel->save_approval_data('approval_numbers',$approval);
			$app_hist_id = $this->billmodel->save_approval_data('approval_numbers',$approval);

			$app_history =[
				'app_no'=>$app_hist_id,
				'user'=>$this->request->getPost('header_id'),
				'user_role'=>1,
				'comment'=>$this->request->getPost('reason'),
				'hstatus'=>3,
				'hist_date'=>date('Y-m-d H:i:s'),
			];
			$this->billmodel->save_approval_history_data('approval_history',$app_history);

			//here we go
           	//send message to approvals
			 $billto=$this->request->getPost('supplier_id');
			 $url=base_url("?redirect=reapproval");
           
           $s_name="";
           
            $t_name = $this->billmodel->get_item_name('supplier_tbl',$where = array('supplier_id' => $billto));
            $s_name=$t_name[0]->supplier_name;
           
           $messagex="<transaction name> <transaction no> to <Name> with amount <amount> is pending your approval.";

             $msg = "Voucher ".$trans." to ".$s_name." amount ".number_format($total)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";

     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 14,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
    
   
     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
    	$priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
    	if(count($priveleged)>0){
    		foreach($priveleged as $plv){

    		if (ctype_digit((string)$plv->privilege_id)) {
    			//echo "yes ".$plv->privilege_id;
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>$db_id));
              // print_r($assigned_user);
                $this->studentModel->SaveData('message_groups_tbl',$smsdata);
               foreach($assigned_user as $user){
               	if($user->phone_no !=""){
          

            $this->SMSsender($user->phone_no,$msg,13,$billto,$snn,NULL);

           $data=array(
           'phone_no'=>$user->phone_no,
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           );
              }
               }
    			}else{
             // echo "no-".$plv->privilege_id;
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));
              if(count($assigned_approval)>0){

              	foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>$db_id));

              
              	if($assigned_user[0]->phone_no !=""){
           $this->studentModel->SaveData('message_groups_tbl',$smsdata);

             $this->SMSsender($assigned_user[0]->phone_no,$msg,14,$billto,$snn,NULL);
             //print_r($assigned_user);
            
            $data=array(
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

          }
      }

                }
    			}

    			//print_r($data);
    		}
    	}
    }

   //  end message to approvals;
			//------------

		
	echo json_encode(array('status' => 1,'description' => 'Payment saved successfully'));
	}

	function load_control_choices(){
return view('bills/forms/control_charges_filter');	
}


	function control_number_charges_edit(){
     $thedate=$this->request->getVar('thedate');
     $trans=$this->request->getVar('trans');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            
            $charge=$this->billmodel->get_control_charges('ledger_transaction_tbl',$where = array('trans_type_id' => 2),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
            $allData=array();
            foreach($charge as $rg){
               //echo $rg->amount.'</br>';
            	if($rg->balance <=0){
                      		continue;
                      	}

                $check_trans = $this->studentModel->gettable_specific_data('control_number_charges_payments_tbl',$where = array('trans_no' => $trans,'rct_no'=>$rg->trans_number),$data=array('trans_no'));
                if(count($check_trans)>0){
                	continue;
                }
            	if($rg->name_type_id==1){
            	$student = $this->studentModel->gettable_specific_data('students',$where = array('id' => $rg->name_id),$data=array('id','full_name'));	
            	}
            if($rg->name_type_id==4){
            	$student = $this->studentModel->gettable_specific_data('students_application_tbl',$where = array('id' => $rg->name_id,),$data=array('id','full_name'));	
            	}
          	
          $rel = $this->studentModel->gettable_specific_data('transactions_relation',$where = array('receipt_trans_no' => $rg->trans_number),$data=array('invoice_trans_no'));
          if(count($rel)==0){
          	continue;
          }
          $inv = $this->studentModel->gettable_specific_data('invoice_type_transaction',$where = array('trans_no' => $rel[0]->invoice_trans_no,'transaction_type_id'=>1),$data=array('invoice_type_id'));
          $inv_name = $this->studentModel->gettable_specific_data('invoice_types_tbl',$where = array('id' => $inv[0]->invoice_type_id),$data=array('type_name'));

          $ctr = $this->studentModel->gettable_specific_data('payment_request',$where = array('trans_no' => $rel[0]->invoice_trans_no,'student_id'=>$rg->name_id,'trans_type'=>1),$data=array('reference_no'));

               $data = array("student_id" => $rg->name_id,"trans_number" => $rg->trans_number, "invoice_type" => $inv_name[0]->type_name, "name" => $student[0]->full_name, "control" => $ctr[0]->reference_no, "amount" => $rg->balance, "trans_date" => $rg->trans_date,"name_type_id"=>$rg->name_type_id,'trans_no'=>$rel[0]->invoice_trans_no);
                array_push($allData, $data);
               }

         $data = array(
               'trans' => $allData
            );
             // print_r($allData);
             // return;
          echo view('bills/forms/students_charged_edit',$data);
	}

	function update_controlCharges(){
		$db_id=session()->get('db_id');
	$voucher=$this->request->getPost("voucher");
	//print_r($voucher);
     // return;
	$trans = $this->request->getPost('trans');
	$total=0;
	 $transaction = [
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s'),
              
      ];
     
      $this->billmodel->update_table_details('transaction_numbers_tbl',$where = array('trans_number' => $trans,'trans_type_id'=>5),$transaction);

	foreach($voucher as $v)
	{
		$amount=$this->request->getPost("amount".$v);
		$amount=str_replace(',', '', $amount);
		 $amount=(int)$amount;
		if($amount !="" || $amount >0){
			//echo "amount-> ". str_replace(',', '', $amount)."</br>";
        $payedamount = $amount; 
      
       $nature=2;
        $trno = $this->request->getPost('trans_no'.$v);

         $clg= $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trno,'trans_type' => 2,'ledger_id'=>22));
        
         $balance=$clg[0]->balance-$amount;
         
      $cbalance = array(
                    'balance' => $balance
                );
       
          $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $clg[0]->id),$cbalance);
         $payed = [
                       'inv_no' =>  $this->request->getPost('inv_no'.$v),
                       'rct_no' =>  $this->request->getPost('trans_no'.$v),
                       'trans_no' => $trans,
                       'amount' => $amount,
                       'student_id' => $this->request->getPost('student_id'.$v),
                       'name_type_id' => $this->request->getPost('name_type_id'.$v),
                       
                   ]; 
         $this->studentModel->SaveData('control_number_charges_payments_tbl',$payed);
         
       $total=$total+$amount;
   }
 }
    $ledger_amout = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trans,'trans_type'=>5));
         $rcledger = [
                       'amount' => $total+$ledger_amout[0]->amount,
                       
                   ];
  //   print_r($rcledger);
                $this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $trans,'trans_type'=>5),$rcledger);


       ////////////function to insert approval data /////////////
					
			$appnumber_id = $this->studentModel->gettable_data('approval_numbers',$where = array('trans_no' => $trans,'trans_type'=>5));
			$app_hist_id = $appnumber_id[0]->app_id;

			$app_history =[
				'edited_date'=>date('Y-m-d H:i:s'),
			];
			$this->billmodel->update_table_details('approval_history',$where = array('app_no' => $app_hist_id), $app_history);

			//here we go
    echo json_encode(array('status' => 1,'description' => 'Payment added successfully'));

	}

	function delete_payments(){
	$trans=$this->request->getPost("trans");

	$appnumber_id = $this->studentModel->gettable_data('approval_numbers',$where = array('trans_no' => $trans,'trans_type'=>5));
			$app_hist_id = $appnumber_id[0]->app_id;

	$pocket = $this->studentModel->gettable_data('pocket_money_transaction_tbl',$where = array('transaction_no' => $trans));
	$control = $this->studentModel->gettable_data('control_number_charges_payments_tbl',$where = array('trans_no' => $trans));
	$other=0;
	$data=array();
	if(count($pocket)>0){
     $other=1;
	}

	if(count($control)>0){
     $other=2;
     $data=$control;
	}

$delete=$this->billmodel->delete_Payment($trans,$app_hist_id,$other,$data);
	if($delete){
		echo json_encode(array('status' => 1,'description' => 'Payment deleted successfully'));
	}else{
	echo json_encode(array('status' => 0,'description' => 'Payment deletion failed'));	
	}

	}
	
		function Approved_Data_All()
		{
		$all_check=$this->billmodel->gettable_approve_data();
         // print_r($all_check);
         // return;
		foreach($all_check as $all){


			$trans_number = $all->transaction_no;
			$dat_appr =$this->billmodel->get_item_name('approval_numbers',$where=array('trans_no'=>$trans_number,'trans_type'=>5));
			$checkstatus = $this->billmodel->check_ifExist('approval_history',$where=array('app_no'=>$dat_appr[0]->app_id,'hstatus'=>1));
            if(count($checkstatus)==0){

			$data = array(
				'app_no'=>$dat_appr[0]->app_id,
				'user'=>8,
				'user_role'=>5,
				'comment'=>'Approved!',
				'hstatus'=>1,
				'hist_date'=>date('Y-m-d H:i:s')
			);
		
			//print_r($data);
		//	$this->billmodel->save_approval_info('approval_history',$data);
          }
      }
      echo 'Approved successfully';
			
		}
		
		public function fetch_voucher_byname($type){
    $name=$this->request->getPost('name');
    $year=$this->request->getPost('year');
    $vtype=$this->request->getPost('voucher_type');
    $search_id=$this->request->getPost('search_id');

    if($search_id ==1){
    	$table="students";
    	$fname="full_name";
    }
    if($search_id ==2){
    	$table="supplier_tbl";
    	$fname="supplier_name";
    }
     if($search_id ==7){
    	$table="users";
    	$fname="first_name";
    }
    
    $data = array(
            'trans' => $this->billmodel->get_item_name3($name,$type,$year,$vtype,$table,$fname,$search_id)
             
            );
            
            $dt=array(
                "name"=>$name,
                 "type"=>$type,
                  "year"=>$year,
                   "vtype"=>$vtype,
                    "table"=>$table,
                     "fname"=>$fname,
                      "search_id"=>$search_id,
                );
            // print_r($dt);
            // print_r($data);
     echo view('bills/forms/voucher_list',$data);
    }
    
    function delete_sms_charges(){
    	$trans=$this->request->getPost("trans");

	$appnumber_id = $this->studentModel->gettable_data('approval_numbers',$where = array('trans_no' => $trans,'trans_type'=>5));
			$app_hist_id = $appnumber_id[0]->app_id;

	$delete=$this->billmodel->delete_Payment_sms($trans,$app_hist_id);
	if($delete){
		echo json_encode(array('status' => 1,'description' => 'Payment deleted successfully'));
	}else{
	echo json_encode(array('status' => 0,'description' => 'Payment deletion failed'));	
	}
    }

    function delete_refund($over,$trno){

    $trans=$this->request->getPost("trans");

	$appnumber_id = $this->studentModel->gettable_data('approval_numbers',$where = array('trans_no' => $trans,'trans_type'=>5));
			$app_hist_id = count($appnumber_id) > 0 ? $appnumber_id[0]->app_id : 0;

	$refund_amount= $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trans,'transation_nature' => 2,'trans_type' => 5,));
       if(count($refund_amount) == 0){
        echo json_encode(array('status' => 0,'description' => 'Payment details not found'));
        return;
       }
       
       $ledger_id=0;
       $balance=0;
       if($over==1){
		$clg= $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trno,'transation_nature' => 2,'trans_type' => 2,'ledger_type'=>7));
         $ledger_id=$clg[0]->id;
        // print_r($clg);
         $balance=$clg[0]->balance +$refund_amount[0]->amount;
     }
     if($over==6){
$clg = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trno,'transation_nature' => 1,'trans_type' => 6,'ledger_type'=>7));
       if(count($clg)>0){
        $ledger_id=$clg[0]->id;		
        $balance=$clg[0]->balance +$refund_amount[0]->amount;
        		
        	}
        }
        if($over==4){
       $clg = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trno,'transation_nature' => 2,'trans_type' => 4,));
        	if(count($clg)>0){
        		 $ledger_id=$clg[0]->id;		
              $balance=$clg[0]->balance +$refund_amount[0]->amount;
              $baltoupdate=array(
                'balance'=>$balance
              );
              $this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' =>$trno,'transation_nature' => 1,'trans_type' => 4),$baltoupdate);
        	}
        }
        if($over==3){
        	$clg = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trno,'transation_nature' => 2,'trans_type' =>3));
        	if(count($clg)>0){
        	$ledger_id=$clg[0]->id;		
              $balance=$clg[0]->balance +$refund_amount[0]->amount;
        	}
        }
         if($over==5){
        	$clg = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trno,'transation_nature' => 2,'trans_type' =>5));
        	$delete_advance=$this->billmodel->delete_Payment_advance($trans);
        	if($delete_advance){
        			if(count($clg)>0){
        	$ledger_id=$clg[0]->id;		
              $balance=$clg[0]->balance +$refund_amount[0]->amount;
        	}
        	}
        

        }

	$delete=$this->billmodel->delete_Payment_refund($trans,$app_hist_id,$ledger_id,$balance);
	if($delete){
		$this->syncRelatedInvoiceBalancesFromReceipt($trno);
		echo json_encode(array('status' => 1,'description' => 'Payment deleted successfully'));
	}else{
	echo json_encode(array('status' => 0,'description' => 'Payment deletion failed'));	
	}

    }
    
    function reconciliation(){
	return view('templates/header')
			.view('bills/reconciliation')
			.view('templates/footer');
	}

	function fetch_payments_reconciliation($start,$end){
       $sdate=$this->request->getPost('start_date');
       $pdate=$this->request->getPost('period_date');
       $account=$this->request->getPost('account');
       $startdate = strtotime($sdate);
       $enddate = strtotime($pdate. ' 23:59:59');
        $trans = $this->billmodel->get_payments(2,$account,date('Y-m-d H:i', $startdate), date('Y-m-d H:i', $enddate));
        
        // if($account==12){
        // foreach($trans as $trs){
        //     $data=array(
        //         'reconciled'=>0
        //         );
        // $this->billmodel->update_table_details('transaction_numbers_tbl',$where = array('trans_number' =>$trs->trans_number,'trans_type_id'=>$trs->trans_type,),$data);
        // }
        //  }
        
        // print_r($trans);
        // return;
        $sn = $start;
         $max=$end;
          $total_cleared=0;
          $total=0;

        if(count($trans)>0){
        	for($i=$sn;$i<=$max;$i++){
                if($i==count($trans)){
                	break;
                }
        		
           $s=$trans[$i];  
     if($trans[$i]->name_type_id == 4){
            $app = $this->bmodel->get_item_name('students_application_tbl',$where = array('id'=>$trans[$i]->name_id));
            $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
            $student_id = $app[0]->id;
          }
        else if($trans[$i]->name_type_id == 3){
             $app = $this->bmodel->get_item_name('parents_tbl',$where = array('id'=>$trans[$i]->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }else if($trans[$i]->name_type_id == 1){
             $app = $this->bmodel->get_item_name('students',$where = array('id'=>$trans[$i]->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }elseif($s->name_type_id==2){
         $app = $this->bmodel->get_item_name('supplier_tbl', $where = array('supplier_id' => $s->name_id));
         $student_name=$app[0]->supplier_name??"";
             }
        else if($trans[$i]->name_type_id == 6){
             $app = $this->bmodel->get_item_name('other_students_tbl',$where = array('id'=>$trans[$i]->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }else if($trans[$i]->name_type_id == 7){
             $app = $this->bmodel->get_item_name('users',$where = array('user_id'=>$trans[$i]->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
            
            
        }
        elseif($s->name_type_id==5){
                             
       $pad = $this->bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $s->trans_no,'trans_type' => $s->trans_type,'name_type_id' => 1));
      
       if(count($pad)>0){
       $std =$this->bmodel->get_item_name('students', $where = array('id' => $pad[0]->name_id));
     
      $student_name=$std[0]->full_name??"";
    }else{
      //$fullname="";
       $std = $this->bmodel->get_item_name('students_application_tbl', $where = array('id' => $s->name_id));
     $student_name=$std[0]->full_name??"";
      }
                            }
        else{
        	$student_name="0-".$trans[$i]->name_type_id;
        }
        
       

    $user = $this->bmodel->get_item_name('users', $where = array('user_id' => $s->updated_by));
    $check="";
    $disable="";
    $bcolor="";
    $color="";
    $crdb="";
  
		if($user[0]->user_id==9){
			$check="checked";
			$disable="disabled";
			 $bcolor="black";
             $color="white";
             $crdb="crdb";
             $check_box="check_box1";
             $total_cleared=$total_cleared+$s->amount;
		}else{
			$check_box="check_box2";
			$crdb="notrec";
			$total=$total+$s->amount;
		}
            echo "<tr style='background-color:".$bcolor.";color:".$color."' id='row".$i."' class='".$crdb."'><input type='hidden' value='".count($trans)."' id='counted".$i."'>";
            echo "<td><input type='checkbox' ".$check.' '.$disable." id='col".$i."' onclick='paymentCheck(".$i.")'  class='".$check_box."' name='selected[]' value='".$i."'></td>";
            echo "<td><input type='hidden' value='".$s->trans_type."' name='trans_type".$i."'>".$s->type_name."</td>";
            echo "<td>".date('Y-m-d',strtotime($s->trans_date))."</td>";
            echo "<td><input type='hidden' value='".$s->trans_number."' name='trans_number".$i."'>".$s->trans_number."</td>";
            echo "<td>".$student_name."</td>";
            // echo "<td>".$name_type ?? ""."</td>";
            echo "<td><input type='hidden' value='".$s->amount."' id='amount".$i."'>".number_format($s->amount)."</td>";
            echo "<td>".$user[0]->first_name.' '.$user[0]->last_name."</td>";
             echo "</tr>";
            }
            echo "<tr><input type='hidden' id='clear".$max."' value='".$total_cleared."'>
            <input type='hidden' id='notcleared".$max."' value='".$total."'>
            <input type='hidden' id='nopayment".$max."' value='0'>
            </tr>";
        	
        }else{
        echo "<tr><input type='hidden' id='nopayment".$max."' value='1'>
        <input type='hidden' id='clear".$max."' value='".$total_cleared."'>
            <input type='hidden' id='notcleared".$max."' value='".$total."'>
        <td>No any payment</td>
            </tr>";	
        }

	}

function credit_payments_reconciliation($start,$end){
		 $pdate=$this->request->getPost('period_date');
       $account=$this->request->getPost('account');
        $sdate=$this->request->getPost('start_date');
       $startdate = strtotime($sdate);
       $enddate = strtotime($pdate. ' 23:59:59');
        $trans = $this->billmodel->get_payments(1,$account, date('Y-m-d H:i', $startdate), date('Y-m-d H:i', $enddate));
        // print_r($trans);
        // return;
         
        //  if($account==12){
        // foreach($trans as $trs){
        //     $data=array(
        //         'reconciled'=>0
        //         );
        // $this->billmodel->update_table_details('transaction_numbers_tbl',$where = array('trans_number' =>$trs->trans_number,'trans_type_id'=>$trs->trans_type,),$data);
        // }
        //  }
         
        $sn = $start;
         $max=$end;
          $total_cleared=0;
          $total=0;

        if(count($trans)>0){
        	for($i=$sn;$i<=$max;$i++){
                if($i==count($trans)){
                	break;
                }
        		
           $s=$trans[$i];  
     if($trans[$i]->name_type_id == 4){
            $app = $this->bmodel->get_item_name('students_application_tbl',$where = array('id'=>$trans[$i]->name_id));
            $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
            $student_id = $app[0]->id;
          }
        else if($trans[$i]->name_type_id == 3){
             $app = $this->bmodel->get_item_name('parents_tbl',$where = array('id'=>$trans[$i]->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }else if($trans[$i]->name_type_id == 1){
             $app = $this->bmodel->get_item_name('students',$where = array('id'=>$trans[$i]->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }elseif($s->name_type_id==2){
         $app = $this->bmodel->get_item_name('supplier_tbl', $where = array('supplier_id' => $s->name_id));
         $student_name=$app[0]->supplier_name??"";
             }
        else if($trans[$i]->name_type_id == 6){
             $app = $this->bmodel->get_item_name('other_students_tbl',$where = array('id'=>$trans[$i]->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }else if($trans[$i]->name_type_id == 7){
             $app = $this->bmodel->get_item_name('users',$where = array('user_id'=>$trans[$i]->name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
            
            
        }
        elseif($s->name_type_id==5){
                             
       $pad = $this->bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $s->trans_no,'trans_type' => $s->trans_type,'name_type_id' => 1));
      
       if(count($pad)>0){
       $std =$this->bmodel->get_item_name('students', $where = array('id' => $pad[0]->name_id));
     
      $student_name=$std[0]->full_name??"";
    }else{
      //$fullname="";
       $std = $this->bmodel->get_item_name('students_application_tbl', $where = array('id' => $s->name_id));
     $student_name=$std[0]->full_name??"";
      }
                            }
        else{
        	$student_name="0-".$trans[$i]->name_type_id;
        }
        
       

    $user = $this->bmodel->get_item_name('users', $where = array('user_id' => $s->updated_by));
    $check="";
    $disable="";
    $bcolor="";
    $color="";
    $crdb="";
  
		if($user[0]->user_id==9){
			$check="checked";
			$disable="disabled";
			 $bcolor="black";
             $color="white";
             $crdb="auto_credit";
             $check_box="";
             $total_cleared=$total_cleared+$s->amount;
		}else{
			$check_box="credit_box2";
			$crdb="notrec_credit";
			$total=$total+$s->amount;
		}
            echo "<tr style='background-color:".$bcolor.";color:".$color."' id='crow".$i."' class='".$crdb."'><input type='hidden' value='".count($trans)."' id='allcredit".$i."'>";
            echo "<td><input type='checkbox' ".$check.' '.$disable." id='ccol".$i."' onclick='creditCheck(".$i.")'  class='".$check_box."' name='selected[]' value='_".$i."'></td>";
            echo "<td><input type='hidden' value='".$s->trans_type."' name='trans_type_".$i."'>".$s->type_name."</td>";
            echo "<td>".date('Y-m-d',strtotime($s->trans_date))."</td>";
            echo "<td><input type='hidden' value='".$s->trans_number."' name='trans_number_".$i."'>".$s->trans_number."</td>";
            echo "<td>".$student_name."</td>";
            // echo "<td>".$name_type ?? ""."</td>";
            echo "<td><input type='hidden' value='".$s->amount."' id='credit_amount".$i."'>".number_format($s->amount)."</td>";
            echo "<td>".$user[0]->first_name.' '.$user[0]->last_name."</td>";
             echo "</tr>";
            }
            echo "<tr><input type='hidden' id='credit_clear".$max."' value='".$total_cleared."'>
            <input type='hidden' id='notcleared_credit".$max."' value='".$total."'>
            <input type='hidden' id='nopayment_credit".$max."' value='0'>
            </tr>";
        	
        }else{
        echo "<tr><input type='hidden' id='nopayment_credit".$max."' value='1'>
        <input type='hidden' id='credit_clear".$max."' value='".$total_cleared."'>
            <input type='hidden' id='notcleared_credit".$max."' value='".$total."'>
        <td>No any payment</td>
            </tr>";	
        }
	}

	function save_reconciliation(){
	  
	  $post = $this->request->getJSON(true);
		$trans = $this->generate_recon_no();
    $begin_balance=$post['beginbalance'];
    $begin_balance=str_replace(',', '', $begin_balance);
    
    $endingbalance=$post['endingbalance'];
    $endingbalance=str_replace(',', '', $endingbalance);
          $data = [
					'account_id'=>$post['account_id'],
					'recon_number'=>$trans,
					'recon_date'=>date('Y-m-d H:i:s'),
					'begin_balance'=>$begin_balance,
					'end_balance '=>$endingbalance,
					'total_cleared'=>$endingbalance,
					'start_date'=>$post['start_date'],
					'end_date'=>$post['date_statement'],
					'trans_by'=>session()->get("user_id"),
					'trans_date'=>date('Y-m-d H:i:s'),

				];

	$selected = $post['selected[]'] ?? [];
//	print_r($selected);


  
				
		
			
			$this->db->transStart();
			$query = $this->db->table('reconciliation_tbl')->insert($data);
	//	$insertID=$this->billmodel->save_transcation_data('reconciliation_tbl',$data);
		
	foreach($selected as $s){
 $transTypeKey = "trans_type" . $s;
    $transNumberKey = "trans_number" . $s;

    $trans_type = $post[$transTypeKey] ?? null;
    $trans_number = $post[$transNumberKey] ?? null;
    
    
			$data2=array(
         'reconciled'=>$trans
              );
     $builder=$this->db->table('transaction_numbers_tbl');
      $builder->where('trans_number',$trans_number);
      $builder->where('trans_type_id',$trans_type);
     $builder->update($data2);
     
  if ($trans_type === null || $trans_number === null) {
        continue;   
       }
}
		
	$this->db->transComplete();
	if ($this->db->transStatus() === FALSE) {
        
        $this->db->transRollback();
        return false; 
    }

    $this->db->close();
		
	return true;

	}

function generate_recon_no() {
        $ino = "";
        $tkens = $this->billmodel->get_max_reconciliation('reconciliation_tbl','recon_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }

     function check_end_balance(){
    	$acc_id=$this->request->getPost('account_id');
    	$tkens = $this->billmodel->check_reconcilitoion($acc_id);
    	if(count($tkens)>0){
    		$newDate = date("Y-m-d", strtotime($tkens[0]->end_date . ' +1 day'));
    		$data=array(
             'recon_amount'=>number_format($tkens[0]->end_balance),
             'recon_last'=>date("Y-m-d",strtotime($tkens[0]->end_date)),
             'new_startDate'=>$newDate,
             'readonly'=>1,
    		);
        echo json_encode($data);
    	}else{
    		$newDate = date("Y-m-01");
    		$lastDate = date("Y-m-d", strtotime($newDate . ' -1 day'));
        $data=array(
             'recon_amount'=>0,
             'recon_last'=>$lastDate,
              'new_startDate'=>$newDate,
              'readonly'=>0, 
    		);
        echo json_encode($data);
    	}
    }

    function filter_reconciliation_list(){
    	$thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            $bid=$this->request->getVar('bankId');
            
            if($bid >0){
            $data = array(
               'recon_data' => $this->billmodel->get_item_name2('reconciliation_tbl',$where = array('account_id' => $bid),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))
            );
        }else{
        	 $data = array(
               'recon_data' => $this->billmodel->get_item_name2('reconciliation_tbl',$where = array('account_id !=' => ""),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))
            );
         }
           echo view('bills/forms/reconciliation_list',$data);
        
    }
    
    function opening_balances(){
    	return view('templates/header')
			.view('bills/opening_balances')
			.view('templates/footer');
    }

    function save_opening_balances(){
    	 $trans= $this->generate_transaction_opening_balance();

        $credit_bank = $this->request->getPost('credit_bank');
        $debit_bank = $this->request->getPost('debit_bank');
        $student_id = $this->request->getPost('header_id');
              $transaction = [
            'trans_type_id' => 9,
            'trans_number' => $trans,
            'trans_date' =>  $this->request->getPost('open_date'),
            'trans_desc' =>  $this->request->getPost('desc'),
            'updated_by' => $this->request->getPost('header_id'),
            'updated_date' => date('Y-m-d H:i:s')
        ];   
       // print_r($transaction);
        //return;
        $this->studentModel->SaveData('transaction_numbers_tbl',$transaction);

         $total_cost = 0;
       
                $total_cost=$this->request->getPost('amount');
               
                    $legers = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $credit_bank)); 
                    $ledger = [
                        'ledger_id' => $credit_bank,
                        'ledger_type' => $legers[0]->account_type_id,
                        'trans_no' => $trans,
                        'trans_type' => 9,
                        'amount' => $total_cost,
                        'transation_nature' => 1,
                        'name_type_id' => 7,
                        'name_id' => $student_id,
                    ];
                $this->studentModel->SaveData('ledger_transaction_tbl',$ledger); 

              $total_amount = 0;
                 // foreach($this->request->getPost('pay_ledger') as $l){
                    $total_amount = $this->request->getPost('amount');
                    $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $debit_bank)); 

                           $Bledger = [
                           'ledger_id' => $Bank_leger[0]->id,
                           'ledger_type' => $Bank_leger[0]->account_type_id,
                           'trans_no' => $trans,
                           'trans_type' => 9,
                           'amount' => $this->request->getPost('amount'),
                           'transation_nature' => 2,
                           'name_type_id' => 7,
                           'name_id' => $student_id,
                       ];

                       $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);
                      
                  echo json_encode(array('status' => 1,'description' => 'receipt created successful' ));
                 
    }

     function generate_transaction_opening_balance() {
        $ino = "";
        $tkens = $this->billmodel->get_max_trans_open('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }

     function fetch_opening_balances(){

    $thedate=$this->request->getVar('thedate');
    //$approval = $this->request->getVar('approval');

    list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
     
     $data = array(
               'open_data' => $this->billmodel->get_item_name2('transaction_numbers_tbl',$where = array('trans_type_id' =>9),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))

            );

      echo view('bills/forms/opening_balances_responces',$data);
       
    }
    
      function directPay(){
echo view('bills/forms/direct_pay');
    }

    function save_directPay(){
    	$placed_amount=0;
    	$lg_id = $this->request->getPost('aid');
	 
	if(!$lg_id){
      return json_encode(array('status' => 2,'description' => 'PLease!, Expenses can not be 0'));
	}
    	helper('file');
		$transno = $this->generate_payment_no();
		//$trans = $this->generate_payment_no();

			$uploadedfiles = $this->request->getFiles();
			foreach($uploadedfiles['uploadFiles'] as $file){
				$fileName = null;
   				if($file->isValid() && !$file->hasMoved()){
               $fileName = $file->getName();
               if($file->move(ROOTPATH . 'public/transaction_files/',$fileName)){
                $attach = [
  						'transaction_number'=>$transno,
						'image_attachment'=>$fileName,
						'transaction_type_id'=>5,
					];
		  $this->billmodel->save_image_attachment('transaction_attachments_tbl',$attach);
         // print_r($attach);
				}else{
					echo $file->getErrorString();
				}
  				}
           }
           $this->save_looped_direct_ledgers($transno,$lg_id);
    }

    function save_looped_direct_ledgers($transno,$lg_id)
	{
		 
		$db_id=session()->get('db_id');
		$account_ttl = 0;
	
		
			$ledgers = [
					'trans_type_id'=>5,
					'trans_number'=>$transno,
					'trans_date'=>$this->request->getPost('voucher_date'),
					'trans_desc'=>"",
					'updated_by'=>$this->request->getPost('header_id'),
					'updated_date'=>date('Y-m-d H:i:s'),

				];
$this->billmodel->save_transcation_data('transaction_numbers_tbl',$ledgers);
//print_r($ledgers);
			$invoice_type = [
             'trans_no' => $transno,
             'transaction_type_id' => 5,
             'invoice_type_id' => 3
         ];
        // print_r($invoice_type);
        $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);

			foreach($lg_id as $id){
			$amount = $this->request->getPost('ttl'.$id.'');
			//$ledger = array('id'=>$id,'bill_ref_no'=>$bill_ref_no,'description'=>$this->request->getPost('description'.$id.''),'amount'=>$amount);


 			$ledgertype = $this->billmodel->get_item_name('accounts_tbl',$where = array('id' => $id));			
 			$account_ttl+=$amount;
				//$this->request->getPost('incomeledger')

				//print_r($ledger);
 			//'expense_description'=>$this->request->getPost('description'.$id.''),

				$ledgers = [
					'ledger_id'=>$id,
					'ledger_type'=>$ledgertype[0]->account_type_id,
					'trans_item'=>$id,
					'trans_no'=>$transno,
					'trans_type'=>5,
					'amount'=>$amount,
					'transation_nature'=>2,
					'name_type_id'=>2,
					'name_id'=>$this->request->getPost('billto'),
					'balance'=>$amount,
					
				];
				//print_r($ledgers);
				//$retid=1;
				$retid = $this->billmodel->save_transcation_data('ledger_transaction_tbl',$ledgers);
				$budget_ledger = [
					'transact_type' =>$ledgertype[0]->account_type_id,
					'transact_number' => $transno,
					'budget_ledger' => $this->request->getPost('incmeledger'.$id.''),
					'lg_no'=>$retid,
					'description'=>$this->request->getPost('description'.$id.''),
				];
				$this->billmodel->save_transaction_budget('transaction_budget_tbl',$budget_ledger);
				//print_r($budget_ledger);
			
		}

		$relation_transation = [
                       'trans_no' => $transno,
                       'payment_no ' => $transno,
                       'voucher_type ' => $this->request->getPost('voucher_type'),
                       'trans_type ' =>3,
                       'reason' =>"",
                         ];
                $this->studentModel->SaveData('voucher_relation_tbl',$relation_transation);
                        // print_r($relation_transation);

		 		$ledgertype = $this->billmodel->get_item_name('accounts_tbl',$where = array('id' => $this->request->getPost('bank')));			
				$ledgers = [
					'ledger_id'=>$this->request->getPost('bank'),
					'ledger_type'=>$ledgertype[0]->account_type_id,
					'trans_item'=>0,
					'trans_no'=>$transno,
					'trans_type'=>5,
					'amount'=>$account_ttl,
					'transation_nature'=>1,
					'name_type_id'=>2,
					'name_id'=>$this->request->getPost('billto'),
					'balance'=>$account_ttl,
					

				];
				//print_r($ledgers);
				$this->billmodel->save_transcation_data('ledger_transaction_tbl',$ledgers);
                //return;
			////////////function to insert approval data /////////////
					$approval = [
					'trans_type'=>5,
					'trans_no'=>$transno,
					'name'=>$this->request->getPost('billto'),
					'name_type'=>2,
				];

			 
			$app_hist_id = $this->billmodel->save_approval_data('approval_numbers',$approval);

			/////////// function to insert approval history for Pending /////////////
			$app_history =[
				'app_no'=>$app_hist_id,//temp,
				'user'=>$this->request->getPost('header_id'),
				'user_role'=>1,
				'comment'=>$this->request->getPost('bill_comment')?? 'Please Approve',
				'hstatus'=>3,
				'hist_date'=>date('Y-m-d H:i:s'),
			];
			$this->billmodel->save_approval_history_data('approval_history',$app_history);

			//send message to approvals
			 $billto=$this->request->getPost('billto');
			 $url=base_url("?redirect=reapproval");
           $supplier_name = $this->billmodel->get_item_name('supplier_tbl',$where = array('supplier_id' => $billto));

			$messagex="<transaction name> <transaction no> to <Name> with amount <amount> is pending your approval.";
              $msg = "Bill ".$transno." to ".$supplier_name[0]->supplier_name." for ".number_format($account_ttl)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";

     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 14,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $transno
                  
                );
    
   
     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
    	$priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
    	if(count($priveleged)>0){
    		foreach($priveleged as $plv){

    		if (ctype_digit((string)$plv->privilege_id)) {
    			//echo "yes ".$plv->privilege_id;
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>$db_id));
              // print_r($assigned_user);
               foreach($assigned_user as $user){
               	if($user->phone_no !=""){
           $this->studentModel->SaveData('message_groups_tbl',$smsdata);

            $this->SMSsender($user->phone_no,$msg,14,$billto,$snn,NULL);

           $data=array(
           'phone_no'=>$user->phone_no,
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           );
              }
               }
    			}else{
             // echo "no-".$plv->privilege_id;
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));

              if(count($assigned_approval)>0){
                foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>$db_id));
              	if($assigned_user[0]->phone_no !=""){
          $this->studentModel->SaveData('message_groups_tbl',$smsdata);

             $this->SMSsender($assigned_user[0]->phone_no,$msg,14,$billto,$snn,NULL);
             //print_r($assigned_user);
            
            $data=array(
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

          }
          }
                }
    			}

    	//		print_r($data);
    		}
    	}
    }

   //  end message to approvals;

 	echo json_encode(array('status' => 1,'description' => 'Voucher created successful'));

	}
	
	function view_reconciliation(){
		$id=$this->request->getPost('id');

		$data = array(
               'recon_data' => $this->billmodel->get_item_name('reconciliation_tbl',$where = array('id' =>$id))

            );

      echo view('bills/forms/reconciliation_details',$data);
	}
	
	function edit_opening_balance(){

		$id=$this->request->getPost('id');

		$data = array(
               'data' => $this->billmodel->get_item_name('transaction_numbers_tbl',$where = array('id' =>$id))

            );

      echo view('bills/forms/edit_opening_balance',$data);
	}

	function update_opening_balances(){

       
      $trans = $this->request->getPost('trans');
      $credit_bank = $this->request->getPost('credit_bank');
        $debit_bank = $this->request->getPost('debit_bank');
        $student_id = $this->request->getPost('header_id');
              $transaction = [
            'trans_type_id' => 9,
            'trans_number' => $trans,
            'trans_date' =>  $this->request->getPost('open_date'),
            'trans_desc' =>  $this->request->getPost('desc'),
            'updated_by' => $this->request->getPost('header_id'),
            'updated_date' => date('Y-m-d H:i:s')
        ];   
       // print_r($transaction);
        //return;
        $this->billmodel->update_table_details('transaction_numbers_tbl',$where = array('trans_number' =>$trans,'trans_type_id'=>9),$transaction);
       

         $total_cost = 0;
       
                $total_cost=$this->request->getPost('amount');
               
                    $legers = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $credit_bank)); 
                    $ledger = [
                        'ledger_id' => $credit_bank,
                        'ledger_type' => $legers[0]->account_type_id,
                        'trans_no' => $trans,
                        'trans_type' => 9,
                        'amount' => $total_cost,
                        'transation_nature' => 1,
                        'name_type_id' => 7,
                        'name_id' => $student_id,
                    ];
                     $this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' =>$trans,'trans_type'=>9,'transation_nature' => 1,),$ledger);
                

              $total_amount = 0;
                 // foreach($this->request->getPost('pay_ledger') as $l){
                    $total_amount = $this->request->getPost('amount');
                    $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $debit_bank)); 

                           $Bledger = [
                           'ledger_id' => $Bank_leger[0]->id,
                           'ledger_type' => $Bank_leger[0]->account_type_id,
                           'trans_no' => $trans,
                           'trans_type' => 9,
                           'amount' => $this->request->getPost('amount'),
                           'transation_nature' => 2,
                           'name_type_id' => 7,
                           'name_id' => $student_id,
                       ];
                         $this->billmodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' =>$trans,'trans_type'=>9,'transation_nature' => 2,),$Bledger);
                   
                      
                  echo json_encode(array('status' => 1,'description' => 'receipt updated successful' ));
	}
public function pay_payroll(){
$year = $this->request->getPost('year');
$month = $this->request->getPost('month');
$pay_type = $this->request->getPost('pay_type');
$gov_ledger = $this->request->getPost('gov_ledger');
$bank_type = $this->request->getPost('bank_type');
	$ledger=10;
if($pay_type==7){
	$data['year']=$year;
	$data['bank_type']=$bank_type;
$data['payroll']=$this->billmodel->GetStaffLedgers($ledger,$year,$month);
echo view('bills/forms/payroll_staff',$data);
}
elseif($pay_type==8){
	$data['year']=$year;
	$data['bank_type']=$bank_type;
	 $data['legers']=$this->billmodel->get_ledgers_name($gov_ledger);
$data['payroll']=$this->billmodel->GetGovernmentLedgers($ledger,$gov_ledger,$year,$month);
echo view('bills/forms/payroll_government',$data);

}
}
public function pay_government_payroll()
{            $trans_id = "";
        $tkens = $this->smodel->get_max_payroll_payment('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $trans_id = $trans;
        } else {
            $trans_id =  1;
        }
    $year = $this->request->getPost('year');
    $payroll_ids = $this->request->getPost('payroll_id');
    $ledger_key = $this->request->getPost('ledger_key');
    $pay_type = $this->request->getPost('pay_type');
    $gov_ledger = $this->request->getPost('gov_ledger');
    $balance_before = $this->request->getPost('balance_before');
    $to_pay = $this->request->getPost('topay_gvm');
    $amount_before = $this->request->getPost('amount_before');
    $payroll_numbers = $this->request->getPost('payroll_no');
    $ledger_id = $this->request->getPost('ledger_id');
    $transaction_type = $this->request->getPost('transaction_type');
    $ledger_type = $this->request->getPost('ledger_type');
    $name_type_id = $this->request->getPost('name_type_id');
    $transation_nature = $this->request->getPost('transation_nature');
    $total_gov_pay = $this->request->getPost('totalpay_gvm_value');
    $institution_id = $this->request->getPost('institution_id');
    $bank_id = $this->request->getPost('bank_id');
    $total_balance = $this->request->getPost('total_balance');
    $ledger_name = $this->request->getPost('ledger_name');
    $ledger_count=0;
    // print_r($ledger_key);
    // return;
    $this->db->transStart();
    if($trans_id != ""){
    	        $payrollTransaction = [
                'trans_type_id' => 5,
                'trans_number' => $trans_id,
                'trans_date' => date('Y-m-d H:i:s'),
                'updated_by' => session()->get('user_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
 $transction=$this->smodel->SaveData('transaction_numbers_tbl',$payrollTransaction);
 if($transction){
 	$newbalance=$total_balance-$total_gov_pay;
 	    $bankData = [
        'ledger_id' => $bank_id ?? null,
        'ledger_type' => 9,
        'amount' => $total_gov_pay,
        'name_id' => $institution_id ?? null,
        'name_type_id' => 8,
        'trans_type' => 5,
        'trans_item' => 0,
        'balance' => $newbalance,
        'transation_nature' => 1,
        'trans_no' => $trans_id
    ];
    $this->studentModel->SaveData('ledger_transaction_tbl', $bankData);
}}
 	foreach ($ledger_key as $index => $ledger_keys) {
    $toPayRaw = $to_pay[$index] ?? '';
    $cleanedToPay = str_replace(',', '', $toPayRaw);
    $toPay = floatval($cleanedToPay);
    if (trim($cleanedToPay) === '' || $toPay <= 0) {
        continue;
    }

    $balance = floatval(str_replace(',', '', $balance_before[$index] ?? 0));
    $balance_after = $balance - $toPay;

    $condition = [
        'id' => $ledger_keys ?? null
    ];
      $updateData = [
        'balance' => $balance_after
      ];
$this->billmodel->update_current_balance($condition,$updateData);
$ledger_count+=1;
}
$instit_transno=$trans_id;
   foreach ($payroll_ids as $index => $payroll_no) {
   	    $toPayRaw = $to_pay[$index] ?? '';
    $cleanedToPay = str_replace(',', '', $toPayRaw);
    $toPay = floatval($cleanedToPay);
    if (trim($cleanedToPay) === '' || $toPay <= 0) {
        continue;
    }
    $instit_transno+=1;
    if($trans_id != ""){
    	        $payrollTransaction = [
                'trans_type_id' => 5,
                'trans_number' => $instit_transno,
                'trans_date' => date('Y-m-d H:i:s'),
                'updated_by' => session()->get('user_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
 $transction=$this->smodel->SaveData('transaction_numbers_tbl',$payrollTransaction);
 $payrollpaymentData = [
        'ledger_id' => $ledger_id ?? null,
        'ledger_type' => $ledger_type ?? null,
        'amount' => $toPay,
        'name_id' => $institution_id ?? null,
        'name_type_id' => $name_type_id ?? null,
        'trans_type' => 5,
        'trans_item' => 0,
        'balance' => $balance_after,
        'transation_nature' => 2,
        'trans_no' => $instit_transno
    ];
    $this->studentModel->SaveData('ledger_transaction_tbl', $payrollpaymentData);
     $bank_instData = [
        'ledger_id' => $bank_id ?? null,
        'ledger_type' => 9,
        'amount' => $toPay,
        'name_id' =>$institution_id,
        'name_type_id' => $name_type_id ?? null,
        'trans_type' => 5,
        'trans_item' => 0,
        'balance' => $balance_after,
        'transation_nature' => 1,
         'creater_status' => 0,
        'trans_no' => $instit_transno
    ];
    $this->studentModel->SaveData('ledger_transaction_tbl', $bank_instData);
  $payroll_id = $payroll_ids[$index] ?? '';
 $payrollRelation = [
        'payroll_id' => $payroll_no ?? null,
        'amount_paid' => $toPay,
        'staff_id' =>$institution_id,
        'payroll_payment_id' => $instit_transno
    ];
    $this->studentModel->SaveData('payroll_payments_relations_tbl', $payrollRelation);
         $VoucherData = [
        'reason' => '',
        'trans_type' => 5,
        'voucher_type' => 6,
        'payment_no' =>$instit_transno ,
        'trans_no' => $instit_transno
    ];
    $this->studentModel->SaveData('voucher_relation_tbl', $VoucherData);

				$approval = [
					'trans_type'=>5,
					'trans_no'=>$instit_transno,
					'name'=>$institution_id ?? null,
					'name_type'=>8,
				];
			$app_hist_id = $this->billmodel->save_approval_data('approval_numbers',$approval);

			/////////// function to insert approval history for Pending /////////////
			$app_history =[
				'app_no'=>$app_hist_id,//temp,
				'user'=>session()->get('user_id'),
				'user_role'=>1,
				'comment'=>$this->request->getPost('bill_comment')?? 'Please Approve',
				'hstatus'=>3,
				'hist_date'=>date('Y-m-d H:i:s'),
			];
			$this->billmodel->save_approval_history_data('approval_history',$app_history);
		}}
			    $this->db->transComplete();
    if ($this->db->transStatus() === TRUE) {
       
    // +++++++++++++++++++++++++====================Message start==========================++++++++++++++++++++++++++++++++++++++++++
        $messagex="<transaction name> <transaction no> to <Name> for <amount> pending approval. Approve now: <link>";
 			$msg = "Voucher  to ".$ledger_name." for ".number_format($total_gov_pay)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
 $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 14,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' =>session()->get('user_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans_id
                  
                );
     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
        $priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
        if(count($priveleged)>0){
            foreach($priveleged as $plv){

            if (ctype_digit((string)$plv->privilege_id)) {
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>session()->get('db_id')));
              $this->smodel->SaveData('message_groups_tbl',$smsdata);
               foreach($assigned_user as $user){
                if($user->phone_no !=""){
  $cleanPhone = sanitize_phone($user->phone_no);
if ($cleanPhone) {
    try {
 $this->SMSsender($cleanPhone,$msg,14,$$user->user_id,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
           $data=array(
           'phone_no'=>$user->phone_no,
           'msg'=>$msg,
           'billto'=>$trans_id,
           'snn'=>$snn,
           );
              }
               }
                }else{
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));

              if(count($assigned_approval)>0){
                   $this->smodel->SaveData('message_groups_tbl',$smsdata);
                foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>session()->get('db_id')));
                if($assigned_user[0]->phone_no !=""){
               $cleanPhone = sanitize_phone($assigned_user[0]->phone_no);
if ($cleanPhone) {
    try {
 $this->SMSsender($cleanPhone,$msg,14,$assigned_user[0]->user_id,$snn,NULL);  
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $assigned_user[0]->phone_no);
}   
            $data=array(
           'msg'=>$msg,
           'billto'=>$trans_id,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

          }
          }
                }
                }

           
            }
        }}
// +++++++++++++++++++++++++====================Message end==========================++++++++++++++++++++++++++++++++++++++
   return $this->response->setJSON([
        'status' => 1,
        'description' => 'Payment saved successfully',
    ]);
 }else{
 	 $this->db->transRollback();
 	     	    return $this->response->setJSON([
        'status' => 2,
        'description' => 'Payment  failed',
    ]);
 }

    }

public function pay_staff_payroll()
{ 
    $year = $this->request->getPost('year');
    $payroll_ids = $this->request->getPost('payroll_id');
    $ledger_key = $this->request->getPost('ledger_key');
    $pay_type = $this->request->getPost('pay_type');
    $gov_ledger = $this->request->getPost('gov_ledger');
    $balance_before = $this->request->getPost('balance_before');
    $to_pay = $this->request->getPost('topay_gvm');
    $amount_before = $this->request->getPost('amount_before');
    $payroll_numbers = $this->request->getPost('payroll_no');
    $ledger_id = $this->request->getPost('ledger_id');
    $transaction_type = $this->request->getPost('transaction_type');
    $ledger_type = $this->request->getPost('ledger_type');
    $name_type_id = $this->request->getPost('name_type_id');
    $transation_nature = $this->request->getPost('transation_nature');
    $total_gov_pay = $this->request->getPost('totalpay_gvm_value');
    $institution_id = $this->request->getPost('institution_id');
    $bank_id = $this->request->getPost('bank_id');
    $total_balance = $this->request->getPost('total_balance');
    $amount = $this->request->getPost('amount');
    $balance = $this->request->getPost('balance');
    $staff_ids = $this->request->getPost('staff_ids');
    $staffpayroll_ids = $this->request->getPost('staffpayroll_ids');
    $staff_count=0;
    // ============================================save bank====================================================>
        $trans_id = "";
        $tkens = $this->smodel->get_max_payroll_payment('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $trans_id = $trans;
        } else {
            $trans_id =  1;
        }
    if($trans_id != ""){
    	        $payrollTransaction = [
                'trans_type_id' => 5,
                'trans_number' => $trans_id,
                'trans_date' => date('Y-m-d H:i:s'),
                'updated_by' => session()->get('user_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
 $transction=$this->smodel->SaveData('transaction_numbers_tbl',$payrollTransaction);

 if($transction){
 	$newbalance=$total_balance-$total_gov_pay;
 	    $bankData = [
        'ledger_id' => $bank_id ?? null,
        'ledger_type' => 9,
        'amount' => $total_gov_pay,
        'name_id' => session()->get('user_id'),
        'name_type_id' => 7,
        'trans_type' => 5,
        'trans_item' => 0,
        'balance' => $newbalance,
        'transation_nature' => 1,
        'creater_status' => 1,
        'trans_no' => $trans_id
    ];

    $this->studentModel->SaveData('ledger_transaction_tbl', $bankData);
          
}}
    // ============================================Update staff balance=====================================================>

     $final_net_salary=0;
 	foreach ($ledger_key as $index => $ledger_keys) {
 		    $toPayRaw = $to_pay[$index] ?? '';
    $cleanedToPay = str_replace(',', '', $toPayRaw);
    $toPay = floatval($cleanedToPay);
    if (trim($cleanedToPay) === '' || $toPay <= 0) {
        continue;
    }
    $this->db->transStart();
 $final_net_salary+=$toPay;
    $balances = floatval(str_replace(',', '', $balance[$index] ?? 0));

    $new_balance = $balances - $toPay;

    $condition = [
        'id' => $ledger_keys ?? null
    ];
      $updateData = [
        'balance' => $new_balance
      ];
$this->billmodel->update_current_balance($condition,$updateData);
 $this->db->transComplete();
}
$staff_transno=$trans_id;
   foreach ($staffpayroll_ids as $index => $payroll_no) {
   	    $toPayRaw = $to_pay[$index] ?? '';
    $cleanedToPay = str_replace(',', '', $toPayRaw);
    $toPay = floatval($cleanedToPay);
    if (trim($cleanedToPay) === '' || $toPay <= 0) {
        continue;
    }

    $this->db->transStart();
    $staff_transno+=1;
    if($trans_id != ""){
    	        $payrollTransaction = [
                'trans_type_id' => 5,
                'trans_number' => $staff_transno,
                'trans_date' => date('Y-m-d H:i:s'),
                'updated_by' => session()->get('user_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
 $transction=$this->smodel->SaveData('transaction_numbers_tbl',$payrollTransaction);
 if($transction){

 $final_net_salary+=$toPay;
    $balances = floatval(str_replace(',', '', $balance_before[$index] ?? 0));

    $staff_balance = $balances - $toPay;

   	$staff_id = $staff_ids[$index] ?? '';
   	$staff_data = [
        'staff_id' => $staff_id ?? null,
        'staffpayroll_id' => $payroll_no ?? null
    ];
        $staffbalance = [
       
            'net_salary_balances' => $staff_balance
        ];
        $saved=$this->billmodel->update_staff_balance($staff_data, $staffbalance);

         
    

 $payrollstafftData = [
        'ledger_id' => $ledger_id ?? null,
        'ledger_type' => $ledger_type ?? null,
        'amount' => $toPay,
        'name_id' =>$staff_id,
        'name_type_id' => $name_type_id ?? null,
        'trans_type' => 5,
        'trans_item' => 0,
        'balance' => $staff_balance,
        'transation_nature' => 2,
        'trans_no' => $staff_transno
    ];
    $this->studentModel->SaveData('ledger_transaction_tbl', $payrollstafftData);
 $bankstafftData = [
        'ledger_id' => $bank_id ?? null,
        'ledger_type' => 9,
        'amount' => $toPay,
        'name_id' =>$staff_id,
        'name_type_id' => $name_type_id ?? null,
        'trans_type' => 5,
        'trans_item' => 0,
        'balance' => $staff_balance,
        'transation_nature' => 1,
         'creater_status' => 0,
        'trans_no' => $staff_transno
    ];
    $this->studentModel->SaveData('ledger_transaction_tbl', $bankstafftData);
    $payroll_id = $payroll_ids[$index] ?? '';
 $payrollRelation = [
        'payroll_id' => $payroll_id ?? null,
        'amount_paid' => $toPay,
        'staff_id' =>$staff_id,
        'payroll_payment_id' => $staff_transno
    ];
    $this->studentModel->SaveData('payroll_payments_relations_tbl', $payrollRelation);
				$approval = [
					'trans_type'=>5,
					'trans_no'=>$staff_transno,
					'name'=>$staff_id ?? null,
					'name_type'=>7,
				];

			 
			$app_hist_id = $this->billmodel->save_approval_data('approval_numbers',$approval);
			$app_history =[
				'app_no'=>$app_hist_id,//temp,
				'user'=>session()->get('user_id'),
				'user_role'=>1,
				'comment'=>$this->request->getPost('bill_comment')?? 'Please Approve',
				'hstatus'=>3,
				'hist_date'=>date('Y-m-d H:i:s'),
			];
			$this->billmodel->save_approval_history_data('approval_history',$app_history);
			   $VoucherData = [
        'reason' => '',
        'trans_type' => 5,
        'voucher_type' => 6,
        'payment_no' =>$staff_transno ,
        'trans_no' => $staff_transno
    ];
    $this->studentModel->SaveData('voucher_relation_tbl', $VoucherData);
      $staff_count+=1;
$this->db->transComplete();

    }}}
    // +++++++++++++++++++++++++====================Message start==========================++++++++++++++++++++++++++++++++++++++++++
    $number_staff = count($staffpayroll_ids);
        $messagex="<transaction name> <transaction no> to <Name> for <amount> pending approval. Approve now: <link>";
 		$msg = "Voucher  with ".$staff_count." transactions for ".number_format($total_gov_pay)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
 $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 14,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' =>session()->get('user_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans_id
                  
                );
     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
        $priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
        if(count($priveleged)>0){
            foreach($priveleged as $plv){

            if (ctype_digit((string)$plv->privilege_id)) {
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>session()->get('db_id')));
              $this->smodel->SaveData('message_groups_tbl',$smsdata);
               foreach($assigned_user as $user){
                if($user->phone_no !=""){
      $cleanPhone = sanitize_phone($user->phone_no);
if ($cleanPhone) {
    try {
        $this->SMSsender($cleanPhone,$msg,14,$user->user_id,$snn,NULL); 
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $assigned_user[0]->phone_no);
} 
           $data=array(
           'phone_no'=>$user->phone_no,
           'msg'=>$msg,
           'billto'=>$trans_id,
           'snn'=>$snn,
           );
              }
               }
                }else{
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));

              if(count($assigned_approval)>0){
                   $this->smodel->SaveData('message_groups_tbl',$smsdata);
                foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>session()->get('db_id')));
                if($assigned_user[0]->phone_no !=""){
                   $cleanPhone = sanitize_phone($assigned_user[0]->phone_no);
if ($cleanPhone) {
    try {
   $this->SMSsender($cleanPhone,$msg,14,$assigned_user[0]->user_id,$snn,NULL); 
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $assigned_user[0]->phone_no);
}   
            $data=array(
           'msg'=>$msg,
           'billto'=>$trans_id,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

          }
          }
                }
                }

           
            }
        }}
// +++++++++++++++++++++++++====================Message end==========================++++++++++++++++++++++++++++++++++++++
    
}

    function search_staff_payroll()
	{
		$search = $this->request->getPost('data');
            $name_like=$this->billmodel->search_staff_names($search);
          if(count($name_like) > 0){

            echo
            '<table class="table table-hover">
            <thead>
                 <tr>
                    <th>ID</th>
                    <th>Staff Name</th>
                    <th>User type</th>
                    <th>Phone</th>
                    <th></th>
                </tr>
            </thead><tbody>';
            foreach ($name_like as $supl){
               $staff = $this->billmodel->get_item_name('users',$where = array('user_id' => $supl->user_id,'database_id'=>session()->get('db_id')));
                if(count($staff)>0){
                $types = $this->billmodel->get_item_name('users_type_tbl',$where = array('id' => $staff[0]->user_type));

                $fullname = $staff[0]->first_name.' '.$staff[0]->last_name;
                echo '<tr><td>'.$supl->user_id.'</td>';
                echo '<td>'.$fullname.'</td>';
                echo '<td>'.$types[0]->type_name.'</td>';
                echo '<td>'.$staff[0]->phone_no.'</td>';
               echo '<td><button class="btn btn-primary btn-sm" onclick="choose_staff('.$supl->user_id.',\''.$fullname.'\',event)">select</button></td></tr>';
            }
        
            }
            echo '</tbody>';
        }else{
          echo "<span style='color:red'>No any data Found</span>";
        }

        
	}
      function salary_advances($id,$bank){
      	$this->smodel->update_table_details('months', [], ['is_current' => 0]);
 $mon_id = intval(date('m'));
 $data=['is_current'=>1];
    $current_month=$this->smodel->update_table_details('months',$where = array('month_id' => $mon_id),$data);
      	 $data['months']=$this->billmodel->get_item_name('months',$where = array('month_id >' => 0));
      	 $data['staff_id']=$id;
      	 $data['bank_ids']=$bank;
echo view('bills/forms/salary_advances',$data);
    }

    	function fetch_payroll_month()
	{
		$payroll_month = $this->request->getPost('payroll_month');
		  	$builder = $this->db->table('months');
            $builder->select('month_id,month');
            $builder->where('month_id',$payroll_month);
            $query = $builder->get();
            $month_result = $query->getResult();
        if(count($month_result) > 0){
           $data = [];

    foreach ($month_result as $result) {
        $data[] = [
            "month_id" => $result->month_id,
            "month" => $result->month,
        ];
    }

    echo json_encode($data);
        }  
	}
public function save_advances(){
    $year = $this->request->getPost('year');
    $month = $this->request->getPost('month');
    $advance_amount = $this->request->getPost('advance_amount');
    $staffs_id = $this->request->getPost('staffs_id');
    $bank_id = $this->request->getPost('bank_id');
    $ttls = $this->request->getPost('ttl');  
    $payroll_years = $this->request->getPost('payroll_year');
    $payroll_months = $this->request->getPost('payroll_month');
    $amounts = $this->request->getPost('amount');
    $total_amount = $this->request->getPost('total_amount');
         $trans_id = "";
        $tkens = $this->smodel->get_max_advance_payment('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $trans_id = $trans;
        } else {
            $trans_id =  1;
        }
    if($trans_id != ""){
    	        $payrollTransaction = [
                'trans_type_id' => 5,
                'trans_number' => $trans_id,
                'trans_date' => date('Y-m-d H:i:s'),
                'updated_by' => session()->get('user_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
 $transction=$this->smodel->SaveData('transaction_numbers_tbl',$payrollTransaction);
 if($transction){
 	    $bankData = [
        'ledger_id' => $bank_id ?? null,
        'ledger_type' => 9,
        'amount' => $total_amount,
        'name_id' => $staffs_id,
        'name_type_id' => 7,
        'trans_type' => 5,
        'trans_item' => 0,
        'balance' => $total_amount,
        'transation_nature' => 1,
        'trans_no' => $trans_id
    ];

    $this->studentModel->SaveData('ledger_transaction_tbl', $bankData);
     	    $advance_ledger = [
        'ledger_id' => 48,
        'ledger_type' => 7,
        'amount' => $total_amount,
        'name_id' => $staffs_id,
        'name_type_id' => 7,
        'trans_type' => 5,
        'trans_item' => 0,
        'balance' => $total_amount,
        'transation_nature' => 2,
        'trans_no' => $trans_id
    ];

    $this->studentModel->SaveData('ledger_transaction_tbl', $advance_ledger);

    if (is_array($ttls) && is_array($payroll_years) && is_array($payroll_months)) {
        foreach ($ttls as $index => $ttl) {
            $p_year = $payroll_years[$index];
            $p_month = $payroll_months[$index];
            $amt = $amounts[$index];
             $advances = [
        'payroll_year' => $p_year ?? null,
        'payroll_month' => $p_month ?? null,
        'advance_amount' => $amt,
        'staff_id' =>$staffs_id,
        'transaction_id' => $trans_id
    ];
            $saved=$this->studentModel->SaveData('salary_advances_schedule_tbl', $advances);
        }
    }
    if($saved){
   			$approval = [
					'trans_type'=>5,
					'trans_no'=>$trans_id,
					'name'=>$staffs_id ?? null,
					'name_type'=>7,
				];

			 
			$app_hist_id = $this->billmodel->save_approval_data('approval_numbers',$approval);
			$app_history =[
				'app_no'=>$app_hist_id,
				'user'=>session()->get('user_id'),
				'user_role'=>1,
				'comment'=>$this->request->getPost('bill_comment') ?? 'Please Approve',
				'hstatus'=>3,
				'hist_date'=>date('Y-m-d H:i:s'),
			];
			$this->billmodel->save_approval_history_data('approval_history',$app_history);
			   $VoucherData = [
        'reason' => '',
        'trans_type' => 5,
        'voucher_type' => 8,
        'payment_no' =>$trans_id ,
        'trans_no' => $trans_id
    ];
    $this->studentModel->SaveData('voucher_relation_tbl', $VoucherData);

    }
    if($saved){
    	 $staff_data=$this->staffmodel->view_staffData($staffs_id);

// +++++++++++++++++++++++++====================Message start==========================++++++++++++++++++++++++++++++++++++++++++
    $total_amount = (float) $this->request->getPost('totalsum0');
        $messagex="<transaction name> <transaction no> to <Name> for <amount> pending approval. Approve now: <link>";
 			$msg = "Voucher ".$trans_id." to ".$staff_data->first_name." ".$staff_data->last_name." for ".number_format($total_amount)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";
 $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 14,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' =>session()->get('user_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans_id
                  
                );
     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
        $priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
        if(count($priveleged)>0){
            foreach($priveleged as $plv){

            if (ctype_digit((string)$plv->privilege_id)) {
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>session()->get('db_id')));
              $this->smodel->SaveData('message_groups_tbl',$smsdata);
               foreach($assigned_user as $user){
                if($user->phone_no !=""){

                $cleanPhone = sanitize_phone($user->phone_no);
if ($cleanPhone) {
    try {
        $this->SMSsender($cleanPhone,$msg,14,$staffs_id,$snn,NULL); 
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
           $data=array(
           'phone_no'=>$user->phone_no,
           'msg'=>$msg,
           'billto'=>$trans_id,
           'snn'=>$snn,
           );
              }
               }
                }else{
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));

              if(count($assigned_approval)>0){
                   $this->smodel->SaveData('message_groups_tbl',$smsdata);
                foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>session()->get('db_id')));
                if($assigned_user[0]->phone_no !=""){
          
     $cleanPhone = sanitize_phone($assigned_user[0]->phone_no);
if ($cleanPhone) {
    try {
    $this->SMSsender($cleanPhone,$msg,14,$staffs_id,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $assigned_user[0]->phone_no);
}
            $data=array(
           'msg'=>$msg,
           'billto'=>$trans_id,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

          }
          }
                }
                }

           
            }
        }
// +++++++++++++++++++++++++====================Message end==========================++++++++++++++++++++++++++++++++++++++
    return $this->response->setJSON([
        'status' => 1,
        'description' => 'Advances saved successfully',
    ]);
    }else{
    	    return $this->response->setJSON([
        'status' => 2,
        'description' => 'Advances saved failed',
    ]);

    }

    return;
	}}


}}
	public function get_slip_data(){
	$name_id = $this->request->getPost('data');
	// print_r($name_id);
	// return;
	$data['history']=$this->billmodel->get_staff_data($name_id);
		return view('bills/forms/salary_slip',$data);

	}
	
	function directPay_purchase(){
 echo view('bills/forms/direct_pay_purchase');
    }

    function save_directPay_purchase(){
    	$placed_amount=0;
    	//$lg_id = $this->request->getPost('aid');
	 
	// if(!$lg_id){
    //   return json_encode(array('status' => 2,'description' => 'PLease!, Expenses can not be 0'));
	// }
    	helper('file');
		$transno = $this->generate_payment_no();
		//$trans = $this->generate_payment_no();

			$uploadedfiles = $this->request->getFiles();
			foreach($uploadedfiles['uploadFiles'] as $file){
				$fileName = null;
   				if($file->isValid() && !$file->hasMoved()){
               $fileName = $file->getName();
               if($file->move(ROOTPATH . 'public/transaction_files/',$fileName)){
                $attach = [
  						'transaction_number'=>$transno,
						'image_attachment'=>$fileName,
						'transaction_type_id'=>5,
					];
		  $this->billmodel->save_image_attachment('transaction_attachments_tbl',$attach);
         // print_r($attach);
				}else{
					echo $file->getErrorString();
				}
  				}
           }
          
          // $this->save_looped_direct_ledgers($transno,$lg_id);

           $db_id=session()->get('db_id');
		$account_ttl = 0;
		
		
			$ledgers = [
					'trans_type_id'=>5,
					'trans_number'=>$transno,
					'trans_date'=>$this->request->getPost('voucher_date'),
					'trans_desc'=>"",
					'updated_by'=>$this->request->getPost('header_id'),
					'updated_date'=>date('Y-m-d H:i:s'),

				];
$this->billmodel->save_transcation_data('transaction_numbers_tbl',$ledgers);
//print_r($ledgers);
			$invoice_type = [
             'trans_no' => $transno,
             'transaction_type_id' => 5,
             'invoice_type_id' => 3
         ];
        // print_r($invoice_type);
        $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);
          
          $iid = $this->request->getPost('iid');
			foreach($iid as $c){
				$itm = $this->studentModel->gettable_data('price_tbl',$where = array('item_id' => $c));
				$avg_cost1=$itm[0]->item_balance*$itm[0]->avg_cost;
				$avg_cost2=$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.'');
			$avg_cost=($avg_cost1+$avg_cost2)/($itm[0]->item_balance+$this->request->getPost('quantity'.$c.''));
			$upd_item = [
					'avg_cost'=>$avg_cost,
					'item_balance'=>$itm[0]->item_balance+$this->request->getPost('quantity'.$c.''),
				];
			$this->billmodel->update_table_details('price_tbl',$where = array('item_id' =>$c),$upd_item);

             $itm = $this->studentModel->gettable_data('items_tbl',$where = array('id' => $c));
            foreach($itm as $i){
                $itype = $i->item_type;
            }

            $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $transno,'trans_type' =>5 , 'quantity' => $this->request->getPost('quantity'.$c.''), 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $this->request->getPost('price'.$c.''));

            $itm_trans = $this->studentModel->SaveData_n_get_id('item_transation_tbl',$itemData);
			
 			 $leger_items = $this->studentModel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
            $account_ttl+=$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.'');
            
            foreach($leger_items as $lg){
                $legers = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                // if($legers[0]->account_type_id !=2){
                //     continue;
                // }
                $ledger = [
                    'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $c,
                     'trans_no' => $transno,
                     'trans_type' => 5,
                     'amount' =>  $this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.''),
                     'transation_nature' => 2,
                     'name_type_id' => 2,
                     'name_id' => $this->request->getPost('billto'),
                     'balance'=>$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.''),
                ];
                
                 $retid = $this->billmodel->save_transcation_data('ledger_transaction_tbl',$ledger); 

            }
			
		}

		$relation_transation = [
                       'trans_no' => $transno,
                       'payment_no ' => $transno,
                       'voucher_type ' => $this->request->getPost('voucher_type'),
                       'trans_type ' =>5,
                       'reason' =>"",
                         ];
                $this->studentModel->SaveData('voucher_relation_tbl',$relation_transation);
                        // print_r($relation_transation);

		 		$ledgertype = $this->billmodel->get_item_name('accounts_tbl',$where = array('id' => $this->request->getPost('bank')));			
				$ledgers = [
					'ledger_id'=>$this->request->getPost('bank'),
					'ledger_type'=>$ledgertype[0]->account_type_id,
					'trans_item'=>0,
					'trans_no'=>$transno,
					'trans_type'=>5,
					'amount'=>$account_ttl,
					'transation_nature'=>1,
					'name_type_id'=>2,
					'name_id'=>$this->request->getPost('billto'),
					'balance'=>$account_ttl,
					

				];
				//print_r($ledgers);
				$this->billmodel->save_transcation_data('ledger_transaction_tbl',$ledgers);
                //return;
			////////////function to insert approval data /////////////
					$approval = [
					'trans_type'=>5,
					'trans_no'=>$transno,
					'name'=>$this->request->getPost('billto'),
					'name_type'=>2,
				];

			 
			$app_hist_id = $this->billmodel->save_approval_data('approval_numbers',$approval);

			/////////// function to insert approval history for Pending /////////////
			$app_history =[
				'app_no'=>$app_hist_id,//temp,
				'user'=>$this->request->getPost('header_id'),
				'user_role'=>1,
				'comment'=>$this->request->getPost('bill_comment') ?? 'Please Approve',
				'hstatus'=>3,
				'hist_date'=>date('Y-m-d H:i:s'),
			];
			$this->billmodel->save_approval_history_data('approval_history',$app_history);

			//send message to approvals
			 $billto=$this->request->getPost('billto');
			 $url=base_url("?redirect=reapproval");
           $supplier_name = $this->billmodel->get_item_name('supplier_tbl',$where = array('supplier_id' => $billto));

			$messagex="<transaction name> <transaction no> to <Name> with amount <amount> is pending your approval.";
              $msg = "Purchase ".$transno." from ".$supplier_name[0]->supplier_name." for ".number_format($account_ttl)." pending approval. Approve now: https://econnect.advaensure.co.tz/?redirect=reapproval";

     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 14,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $transno
                  
                );
    
   
     $module_id = $this->billmodel->get_item_name('modules_tbl',$where = array('collapse' => 2));
    if(count($module_id)>0){
    	$priveleged = $this->billmodel->get_item_name('modules_privileges',$where = array('module_id' => $module_id[0]->module_id));
    	if(count($priveleged)>0){
    		foreach($priveleged as $plv){

    		if (ctype_digit((string)$plv->privilege_id)) {
    			//echo "yes ".$plv->privilege_id;
               $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_type' => $plv->privilege_id,'database_id'=>$db_id));
              // print_r($assigned_user);
               foreach($assigned_user as $user){
               	if($user->phone_no !=""){
          // $this->studentModel->SaveData('message_groups_tbl',$smsdata);

           // $this->SMSsender($user->phone_no,$msg,13,$billto,$snn,NULL);

           $data=array(
           'phone_no'=>$user->phone_no,
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           );
              }
               }
    			}else{
             // echo "no-".$plv->privilege_id;
              $assigned_approval = $this->billmodel->get_item_name('users_session_tbl',$where = array('initial_username' => $plv->privilege_id));

              if(count($assigned_approval)>0){
                foreach($assigned_approval as $user){
              $assigned_user = $this->billmodel->get_item_name('users',$where = array('user_id' => $user->user_id,'database_id'=>$db_id));
              	if($assigned_user[0]->phone_no !=""){
 //          $this->studentModel->SaveData('message_groups_tbl',$smsdata);

            // $this->SMSsender($assigned_user[0]->phone_no,$msg,13,$billto,$snn,NULL);
             //print_r($assigned_user);
            
            $data=array(
           'msg'=>$msg,
           'billto'=>$billto,
           'snn'=>$snn,
           'phone_no'=>$assigned_user[0]->phone_no,
           );

          }
          }
                }
    			}

    	
    		}
    	}
    }

   //  end message to approvals;

 	echo json_encode(array('status' => 1,'description' => 'Purchase Voucher created successful'));
    }
    
    
    public function delete_payroll_payment(){
	$trans=$this->request->getPost("trans_no");
	$paid_amount=$this->request->getPost("paid_amount");
	$name_id=$this->request->getPost("staff_id");
	$ledger_id=$this->request->getPost("ledger_id");
	$nametype=$this->billmodel->GetNameType($trans);
	$payroll=$this->billmodel->GetpayrollID($trans);
	$payroll_no=$payroll->payroll_id;
$bank_id=$this->billmodel->GetBankID($trans,$name_id);
$bank=$bank_id->ledger_id;
$bank_balance=$bank_id->balance;
	$payroll_transno=$payroll->transaction_id;
	if($nametype->name_type_id==7){
		// ==============================================staff Transaction====================


		$staff_data = [
        'staff_id' => $name_id ?? null,
        'payroll_ids' => $payroll_no ?? null
    ];
  $pre_balance=$this->billmodel->GetStaffBalance($staff_data);

			$approval = [
					'trans_type'=>5,
					'trans_no'=>$trans,
					'name'=>$name_id ?? null,
					'name_type'=>7,
				];
		
		$netsalary_ifo = [
        'ledger_id' => 54 ?? null,
        'trans_no' => $payroll_transno ?? null,
        'trans_type' => 10
    ];
  $net_salaryData=$this->billmodel->GetNetSalaryData($netsalary_ifo);

  $approvalData=$this->billmodel->GetAppData($approval);
  $approva_id=$approvalData->app_id;

$this->db->transStart();
 $staff_balance=$pre_balance->net_salary_balances+$paid_amount;
 $new_balance=$net_salaryData->balance+$paid_amount;
  	$new_bank_balance=$bank_balance+$paid_amount;
        $staffbalance = [
            'net_salary_balances' => $staff_balance
        ];
        	   $VoucherData = [
                'trans_type' => 5,
        'voucher_type' => 6,
        'payment_no' =>$trans ,
        'trans_no' => $trans
    ];
        $smsdata = [
                    'send_type' => 1,
                    'message_type' => 14,
                    'trans_number' => $trans 
                ];
    $condition = [
    	'ledger_id' => 54 ?? null,
        'trans_no' => $payroll_transno ?? null,
        'trans_type' => 10
    ];
      $updateData = [
        'balance' => $new_balance
      ];

       $bank_condition = [
    	'ledger_id' => $bank ?? null,
        'trans_no' => $trans ?? null,
        'name_type_id' => 7,
        'ledger_type' => 9,
          'transation_nature' => 1,
        'creater_status' => 1,
        'trans_item' => 0,
        'trans_type' => 5
    ];
$this->billmodel->update_current_balance($condition,$updateData);
$this->billmodel->Delete_bank_balance($bank_condition);
$this->billmodel->update_staffpaybalance($staff_data,$staffbalance);
$this->billmodel->DeleteLedgertafftData($trans,$name_id);
$this->billmodel->DeletePaymentRelationData($trans,$name_id,$payroll_no);
$this->billmodel->DeleteVoucherRelationData($VoucherData);
$this->billmodel->DeleteSMSgroupData($smsdata);
$this->billmodel->DeleteApprovalData($trans,$name_id,$payroll_no);
$this->staffmodel->Deleteapproval_history($approva_id);
$this->staffmodel->Deletetransaction_numbers(5,$trans,$payroll_no);
    $this->db->transComplete();
    if ($this->db->transStatus() === FALSE) {
        $this->db->transRollback();
    	    return $this->response->setJSON([
        'status' => 2,
        'description' => 'Payment deletion failed',
    ]);
    }else{
    		    return $this->response->setJSON([
        'status' => 1,
        'description' => 'Payment deleted successfully',
    ]);
    }
		// ==============================================staff Transaction====================

	}elseif($nametype->name_type_id==8){
		// ==============================================Government Transaction====================
					$gov_approval = [
					'trans_type'=>5,
					'trans_no'=>$trans,
					'name'=>$name_id ?? null,
					'name_type'=>8,
				];
				      	   $VoucherData = [
                'trans_type' => 5,
        'voucher_type' => 6,
        'payment_no' =>$trans ,
        'trans_no' => $trans
    ];
		    $gov_condition = [
    	'ledger_id' => $ledger_id ?? null,
        'trans_no' => $payroll_transno ?? null,
        'trans_type' => 10
    ];
     $ledgerData=$this->billmodel->GetNetSalaryData($gov_condition);
      $new_balance=$ledgerData->balance+$paid_amount;
       $gov_updateData = [
        'balance' => $new_balance
      ];
		        $smsdata2 = [
                    'send_type' => 1,
                    'message_type' => 14,
                    'trans_number' => $trans 
                ];

        $bank_condition = [
    	'ledger_id' => $bank ?? null,
        'trans_no' => $trans ?? null,
        'name_type_id' => 8,
        'ledger_type' => 9,
          'transation_nature' => 1,
        'creater_status' => 1,
        'trans_item' => 0,
        'trans_type' => 5
    ];
		  $approvalGove=$this->billmodel->GetAppData($gov_approval);
  $gov_approva_id=$approvalGove->app_id;
$this->db->transStart();
$this->billmodel->update_current_balance($gov_condition,$gov_updateData);
$this->billmodel->Delete_bank_balance($bank_condition);
$this->billmodel->DeleteLedgertafftData($trans,$name_id);
$this->billmodel->DeletePaymentRelationData($trans,$name_id,$payroll_no);
$this->billmodel->DeleteSMSgroupData($smsdata2);
$this->billmodel->DeleteVoucherRelationData($VoucherData);
$this->billmodel->DeleteGovApprovalData($trans,$name_id,$payroll_no);
$this->staffmodel->Deleteapproval_history($gov_approva_id);
$this->staffmodel->Deletetransaction_numbers(5,$trans,$payroll_no);
    $this->db->transComplete();
    if ($this->db->transStatus() === FALSE) {
        $this->db->transRollback();
    	    return $this->response->setJSON([
        'status' => 2,
        'description' => 'Payment deletion failed',
    ]);
    }else{
    		    return $this->response->setJSON([
        'status' => 1,
        'description' => 'Payment deleted successfully',
    ]);
    }
		// ==============================================Government Transaction====================


	}



	}

}
?>

