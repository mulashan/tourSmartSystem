<?php 
    namespace App\Controllers;

    use CodeIgniter\Controller;
    use App\Models\BillingModel;
    use App\Models\StudentModel;
    use App\Models\SystemModel;
    use App\Models\PaymentsModel;
  

    class PaymentsController extends BaseController{
        public $StudentModel;
        public $sytm_model;
        public $databaseName;
        public function __construct(){
           $this->billingModel = new BillingModel; 
           $this->studentModel = new StudentModel; 
           $this->sytm_model = new SystemModel;
           $this->payment_model = new PaymentsModel;
           
         
        }
   
 function generate_transaction_no_2($db) {
        $ino = "";
        $tkens = $this->payment_model->get_max_receipt('transaction_numbers_tbl','trans_number',$db);
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
     
 function SMSsender2($dest,$msg,$type,$ref_no,$snn,$show_response=0,$db) {
     
           $tmsg = $this->payment_model->get_item_name('message_status_tbl',$where = array('status' => 1,), $db);
                  if(count($tmsg)==0){
                   return;   
                  }
             $messag = $this->payment_model->load_messages_balances($db);

            $get_db = $this->payment_model->get_item_name('database_list_tbl',$where = array('db_name' => $db),$db);
            $senderid=constant('SENDER_ID_' . $get_db[0]->db_id);
             $time_sent = time();
             $username=SMS_UNAME;
             $password=SMS_PASSWORD;
              $api_key=API_KEY;
            //  $senderid=SENDER_ID;
              $destination=str_replace('-', '', $dest);
             $message=urlencode($msg);
             $senderid = urlencode($senderid);
        //   $fetch=file_get_contents("https://www.sms.co.tz/api.php?do=sms&username={$username}&password={$password}&senderid={$senderid}&dest={$destination}&msg={$message}");
           try {
 $fetch=file_get_contents("https://www.sms.co.tz/api.php?do=sms&api_key={$api_key}&senderid={$senderid}&dest={$destination}&msg={$message}");
    } catch (\Throwable $e) {
        // log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
        return;
    }
           
            list($status, $note, $smsid) = explode(',', $fetch);
            if($show_response == 2){
              echo '<th>Message status:</th>';
              echo '<td><i>' . $note . '</i></td>';
            }
            if ($status == 'OK') {
                $msgid = $smsid;
                $snt_status = 1;    // Message sent successfully
                $cost = 45;
                $acc_cost = $cost;
                if($type!=2){
                echo 'Message sent successfully';
                  }  
            } else {
                $msgid = '';
                $snt_status = 2;    // Message just sent 
                $cost = 45;
                $acc_cost = $cost;
            }

            if($type == 2){
                //Receipt BILL
                $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
            }elseif($type == 7){
                //Transport
                $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
            } elseif($type == 3){
                //Balance
                $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
            } elseif($type == 4){
                // birthday
                $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
            } elseif($type == 6){
                // Application// not applied
                $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
            } elseif($type == 5){
                // deposit// 
                $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
            } 
            $this->payment_model->SaveData('messages',$tempsmsdata,$db);
          //  echo 'msg saved';

            $balance = ($messag[0]->balance - $acc_cost);

           $smsDt = array(
                'balance' => $balance,
                'created_at' => date('Y/m/d H:i:s')
            );
            $this->payment_model->update_sms_balance($smsDt, $messag[0]->b_id,$db);

          //  curl_close($curl);
     // echo 'successful sent';
    }

   
public function test_here_now($db){
      $resp = json_decode(trim(file_get_contents('php://input')), TRUE);
$resp = json_decode(trim(file_get_contents('php://input')), TRUE);
         file_put_contents('Apifeedback/crdb_payments' . $resp['transaction_date']. '.txt', json_encode($resp));
         
      $inv_details = $this->payment_model->gettable_data('payment_request',$where = array('reference_no' => $resp['reference_number']),$db);
      $student_id=$inv_details[0]->student_id;

      $trans = $this->generate_transaction_no_2($db);
        $trans_response = [
              'reference_no' => $resp['reference_number'],
              'amount_payed' =>$resp['amount'],
              'transaction_receipt' => $resp['payment_receipt'],
              'transaction_date' => $resp['transaction_date'],
              'customer_name' => $resp['customer_name'],
              'account_no' =>$resp['account_number'],
              'transaction_channel' => $resp['channel'],
              'system_receipt_no' => $resp['transaction_ref']
      ];
      $this->payment_model->SaveData('payment_response',$trans_response,$db);


      ///*************sum rcpt*******************************
       file_put_contents('Apifeedback/crdb_payments' . $resp['payment_receipt']. '.txt', json_encode($resp));
       ///*********************************************
     
      $transaction = [
              'trans_type_id' => 2,
              'trans_number' => $trans,
              'trans_date' => $resp['transaction_date'],
              'updated_by' => 9,
              'updated_date' => date('Y-m-d H:i:s')
      ];
      $this->payment_model->SaveData('transaction_numbers_tbl',$transaction,$db); 
        $total_cost = 0;
     $studentId="";
         $i=0;
         $name_type=1;
         $total_amount =$resp['amount'];
         if($inv_details[0]->paid_charges==1){
            $payedamount = $resp['amount']; 

        }else{
            $payedamount = $resp['amount']-$inv_details[0]->charges;
             $charged_update = array(
            'paid_charges' => 1
                );
         $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$charged_update,$db); 

          $ledger = [
               'ledger_id' => 22,
               'ledger_type' => 13,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $inv_details[0]->charges,
               'transation_nature' =>1,
               'name_type_id' => 1,
               'name_id' => $student_id,
               'balance' =>$inv_details[0]->charges
           ];

 $this->payment_model->SaveData('ledger_transaction_tbl',$ledger,$db);

            }
         
             $trno = $inv_details[0]->trans_no;
             //echo $trno;
            
                $itm_trans = $this->payment_model->select_inv_id($trno,$db);
                $trans_item=$itm_trans[0]->invoice_type_id;
                $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 2,
             'invoice_type_id' => $itm_trans[0]->invoice_type_id //
         ];
        $itm_trans = $this->payment_model->SaveData_n_get_id('invoice_type_transaction',$invoice_type,$db);

        // $db = \Config\Database::connect($this->dbname);
        //      $result = $db->query('SELECT * FROM  ledger_transaction_tbl  
        //             WHERE name_id = '.$student_id.' AND ledger_type = 7 and name_type_id ='.$name_type.' and trans_no ='.$trno.' AND transation_nature = 2 and trans_type = 1');
        //                 $billspending = $result->getResult(); 

                        $billspending = $this->payment_model->get_item_name('ledger_transaction_tbl',$where = array('name_id' => $student_id,'ledger_type' => 7,'name_type_id' => $name_type,'trans_no' => $trno,'transation_nature' => 2,'trans_type' => 1),$db);

        ///*************sum rcpt*******************************
         $inv_no = $this->payment_model->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $trno),$db);
            $total_paid=0;
            foreach($inv_no as $no){
                $charges=0;
                $rcpt_am = $this->payment_model->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2),$db);

                $charged = $this->payment_model->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 1,'trans_type' => 2,'ledger_id'=>22),$db);
                if(count($charged)>0){
                    $charges=$charged[0]->amount; 
                }
            if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                  
                  $total_paid=$total_paid+$am->amount-$charges;
              }
                }
            }
              
     if($inv_details[0]->amount -($total_paid + $resp['amount']) == 0){
     $payment_status = array(
            'payment_status' => 1
                );
        }elseif($inv_details[0]->amount -($total_paid + $resp['amount'])> 0){
         $payment_status = array(
            'payment_status' => 2
                );
              }else{
                $payment_status = array(
            'payment_status' => 1
                );
              } 
        $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$payment_status,$db); 
        

               ///*********************************************

             foreach($billspending as $ledger){
                if($ledger->amount -$total_paid- $payedamount >= 0){
                    $balance = $ledger->amount -$total_paid- $payedamount;
                    //echo $ledger->balance;
                    $amount = $payedamount;
                   
                }else{
                   $balance = 0;
                   $amount = $payedamount;
                  // $payedamount = $payedamount - $ledger->balance;
                }

                    $rcledger = [
                       'ledger_id' => $ledger->ledger_id,
                       'ledger_type' => 7,
                       'trans_item' => $trans_item,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $amount,
                       'transation_nature' => 1,
                       'name_type_id' => $name_type,
                       'name_id' => $student_id,
                       'balance' => $balance
                   ];
  //   print_r($rcledger);
               $payid = $this->payment_model->SaveData_n_get_id('ledger_transaction_tbl',$rcledger,$db);


                $balance = array(
                    'balance' => $balance
                );
                $this->payment_model->update_table_details('ledger_transaction_tbl',$where = array('id' => $ledger->id),$balance,$db);   
                $relation_transation = [
                       'invoice_trans_no' => $trno,
                       'receipt_trans_no ' => $trans
                         ];
          $this->payment_model->SaveData('transactions_relation',$relation_transation,$db);
  //   print_r($relation_transation);
               
             }
       ///*********************************************
              $student_details = $this->payment_model->gettable_data('students',$where = array('id' => $student_id),$db);
             //***start**check if transport************//
                  $transport = $this->payment_model->gettable_data('transport_details',$where = array('trans_numb' => $trno),$db);
                  if(count($transport)>0){
                  //checking for expired
             $date1 = date('Y-m-d');
            $date2 = $transport[0]->end_date;

            $timestamp1 = strtotime($date1);
             $timestamp2 = strtotime($date2);

              $difference = $timestamp2 - $timestamp1;
         //checking for expired
                     $status = array(
                    'status' => 1
                );
            if($difference>0){
                $this->payment_model->update_table_details('transport_details',$where = array('trans_numb' => $trno),$status,$db);
                   }
                  }
           //*****end check if transport************//

///////////////////////////////////////////////////////////////////////////////////
    
     $l=17;

       
        $Bank_leger = $this->payment_model->gettable_data('accounts_tbl',$where = array('id' => $l),$db); 
        
       $id = $this->payment_model->gettable_data('parents_students_tbl',$where = array('student_id' => $student_id),$db);


           $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $total_amount,
               'transation_nature' =>2,
               'name_type_id' => 5,
               'name_id' => $id[0]->parent_id
           ];

 $this->payment_model->SaveData('ledger_transaction_tbl',$Bledger,$db);
//print_r($Bledger);

           
         $bill = $this->payment_model->gettable_billingdata($student_id,$db);
        $phone=$bill[0]->phone1;
        $messagex="Malipo yamekamilika. Risiti: xxx, Tarehe:TZS xxx, kiasi: xxx, Mwanafunzi: #fullname.";
     $snn = $this->generate_msg_no_2($db);
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 2,
                    'send_number' => $snn,
                    'massage_date' =>  date('Y-m-d H:i:s'),
                    'send_by' =>10,
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
      
 $this->payment_model->SaveData('message_groups_tbl',$smsdata,$db);
               if($phone != ""){
                    $msg = "Malipo yamekamilika. Risiti:".$trans.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($amount).", Mwanafunzi:".$student_details[0]->full_name;
                   $this->SMSsender2($phone,$msg,2,$student_id,$snn,NULL,$db);
                  
                }  
////////////////////////////////////////////////////////////////////////
 if(count($transport)>0){
$mess="#firstname, Usafiri wako kuanzia tar dd/mm/yy na kuishia tar dd/mm/yy kibali namba xxx cha tar dd/mm/yy";
     $snn2 = $this->generate_msg_no_2($db);
      $sdata = array(
                    'send_type' => 1,
                    'message_type' => 7,
                    'send_number' => $snn2,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' =>10,
                    'messagex' => $mess,
                    'trans_number' => $trans
                  
                );
      
    $this->payment_model->SaveData('message_groups_tbl',$sdata,$db);
               if($phone != ""){
                    $msg2 = $student_details[0]->first_name.", Usafiri wako kuanzia tar ".date('d/m/Y',strtotime($transport[0]->start_date)).", na kuishia tar ".date('d/m/Y',strtotime($transport[0]->end_date)). " kibali namba ".$transport[0]->permit_id."  cha tar ".date('d/m/Y',strtotime($transport[0]->date_created));
            $this->SMSsender2($phone,$msg2,7,$student_id,$snn2,NULL,$db);
                  
                }  
                }

}



    function receive_crdb_app($db){
             $resp = json_decode(trim(file_get_contents('php://input')), TRUE);

      $inv_details = $this->payment_model->gettable_data('payment_request',$where = array('reference_no' => $resp['reference_number']),$db);
      $student_id=$inv_details[0]->student_id;

//FOR TEMPORARY
  if($resp['reference_number'] == "EG1241000157" || $resp['reference_number'] == "EG1241000158"){
            $app_details = $this->payment_model->gettable_data('payment_response',$where = array('reference_no' => $resp['reference_number']),$db);
            $added_amount = array(
            'amount_payed' => $app_details[0]->amount_payed +$resp['amount']
                );
         $this->payment_model->update_table_details('payment_response',$where = array('reference_no' => $resp['reference_number']),$added_amount,$db); 
           return;
        }

      $trans = $this->generate_transaction_no_2($db);
        $trans_response = [
              'reference_no' => $resp['reference_number'],
              'amount_payed' =>$resp['amount'],
              'transaction_receipt' => $resp['payment_receipt'],
              'transaction_date' => $resp['transaction_date'],
              'customer_name' => $resp['customer_name'],
              'account_no' =>$resp['account_number'],
              'transaction_channel' => $resp['channel'],
              'system_receipt_no' => $resp['transaction_ref']
      ];
      $this->payment_model->SaveData('payment_response',$trans_response,$db);


      ///*************sum rcpt*******************************
       file_put_contents('Apifeedback/crdb_payments_application' . $resp['payment_receipt']. '.txt', json_encode($resp));
       ///*********************************************

             // return;
        $transaction = [
            'trans_type_id' => 2,
            'trans_number' => $trans,
            'trans_date' =>$resp['transaction_date'],
            'updated_by' => 9,
            'updated_date' => date('Y-m-d H:i:s')
        ];   
        $this->payment_model->SaveData('transaction_numbers_tbl',$transaction,$db);

         $total_cost = 0;

          //start charges payment control
    // $total_amount =$resp['amount'];
         if($inv_details[0]->paid_charges==1){
            $payedamount = $resp['amount']; 

        }else{
            $payedamount = $resp['amount']-$inv_details[0]->charges;
             $charged_update = array(
            'paid_charges' => 1
                );
         $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$charged_update,$db); 

          $ledger = [
               'ledger_id' => 22,
               'ledger_type' => 13,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $inv_details[0]->charges,
               'transation_nature' =>1,
               'name_type_id' => 4,
               'name_id' => $student_id,
               'balance' =>$inv_details[0]->charges
           ];

 $this->payment_model->SaveData('ledger_transaction_tbl',$ledger,$db);
            }
         //end charges payment control

        $temp_id = $this->payment_model->gettable_data('temp_item_transation_tbl',$where = array('student_id' => $student_id,'bill_status'=>0),$db);
            $invoice_id = $student_id;
            foreach($temp_id as $price){
                  $itm = [
                    'item_id' => $price->item_id,
                    'item_type_id' => $price->item_type_id,
                    'trans_number' => $trans,
                    'trans_type' => 2,
                    'quantity ' => $price->quantity,
                    'before_qty' => 0,
                    'after_qty' => 0,
                    'unit_price' => $price->unit_price,
                ];
         $itm_trans = $this->payment_model->SaveData_n_get_id('item_transation_tbl',$itm,$db);
         $leger_items = $this->payment_model->gettable_data('items_ledgers_tbl',$where = array('item_id' => $price->item_id),$db);
                $total_cost+=$price->unit_price * $price->quantity;
                foreach($leger_items as $lg){
                    $legers = $this->payment_model->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id),$db); 
                    $ledger = [
                        'ledger_id' => $lg->account_id,
                        'ledger_type' => $legers[0]->account_type_id,
                        'trans_no' => $trans,
                        'trans_type' => 2,
                        'amount' => $price->unit_price * $price->quantity,
                        'transation_nature' => 1,
                        'name_type_id' => 4,
                        'name_id' => $student_id,
                    ];
                $this->payment_model->SaveData('ledger_transaction_tbl',$ledger,$db); 
                }
                $temptrans = [
                   'bill_status' => 1
                ];
                $this->payment_model->update_table_details('temp_item_transation_tbl',$where = array('id' => $price->id),$temptrans,$db);

                $app = [
                    'application_status' => 0
                ]; 
                $this->payment_model->update_table_details('students_application_tbl',$where = array('id' => $student_id),$app,$db);
                  }

             $paymentstatus = [
                    'payment_status' => 1
                ]; 
                $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$paymentstatus,$db);

                $student_details = $this->payment_model->gettable_data('students_application_tbl',$where = array('id' => $student_id),$db);
                $phone = $student_details[0]->phone_number;   
                $total_amount = 0;
                $l=17;
                
        $Bank_leger = $this->payment_model->get_account_details('accounts_tbl','account_name',$db);
         if(count($Bank_leger)>0){

         }else{
           $Bank_leger = $this->payment_model->gettable_data('accounts_tbl',$where = array('id' => $l),$db);  
         } 
         
                    $total_amount = $resp['amount'];
                    // $Bank_leger = $this->payment_model->gettable_data('accounts_tbl',$where = array('id' => $l),$db); 
                   
                       $Bledger = [
                           'ledger_id' => $Bank_leger[0]->id,
                           'ledger_type' => $Bank_leger[0]->account_type_id,
                           'trans_no' => $trans,
                           'trans_type' => 2,
                           'amount' =>  $resp['amount'],
                           'transation_nature' => 2,
                           'name_type_id' => 5,
                           'name_id' => $student_id,
                       ];

                       $this->payment_model->SaveData('ledger_transaction_tbl',$Bledger,$db);
                       
    //vfd receipt start
$tn = $this->payment_model->get_item_name('transaction_numbers_tbl',$where = array('trans_number' => $trans,'trans_type_id' => 2),$db);
    $vfd_settngs = $this->payment_model->get_item_name('vfd_settings_tbl',$where = array('status' =>1),$db);
    $get_db = $this->payment_model->get_item_name('database_list_tbl',$where = array('db_name' => $db),$db);
  if(count($vfd_settngs)>0){
    helper('vfd_helper');
    helper('qrcode_helper');

     $result=process_vfd_receipt_now($tn[0]->id,$payedamount,$student_details[0]->full_name,$db,$get_db[0]->db_id);
  }
  //vfd receipt end
                      
                   
                  $messagex="Malipo yamekamilika. Risiti: xxx, Tarehe:TZS xxx, kiasi: xxx, Muombaji: #fullname.";
           $snn = $this->generate_msg_no_2($db);
            $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 2,
                    'send_number' => $snn,
                    'massage_date' =>  date('Y-m-d H:i:s'),
                    'send_by' =>10,
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
      
         $this->payment_model->SaveData('message_groups_tbl',$smsdata,$db);
                    if($phone != ""){
                    $msg = "Malipo yamekamilika. Risiti:".$trans.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($payedamount).", Muombaji:".$student_details[0]->full_name;
            $this->SMSsender2($phone,$msg,2,$student_id,$snn,NULL,$db);
                 
                    }
                    
     //vfd receipt start  ////////////////////////////////////////
$tn = $this->payment_model->get_item_name('transaction_numbers_tbl',$where = array('trans_number' => $trans,'trans_type_id' => 2),$db);
    $vfd_settngs = $this->payment_model->get_item_name('vfd_settings_tbl',$where = array('status' =>1),$db);
    $get_db = $this->payment_model->get_item_name('database_list_tbl',$where = array('db_name' => $db),$db);
  if(count($vfd_settngs)>0){
    helper('vfd_helper');
    helper('qrcode_helper');

     $result=process_vfd_receipt_now($tn[0]->id,$payedamount,$student_details[0]->full_name,$db,$get_db[0]->db_id);
  }
  //vfd receipt end //////////////////////
                    echo 'paid successfully';  
        }

        function receive_crdb_deposit($db){
     $resp = json_decode(trim(file_get_contents('php://input')), TRUE);

      $inv_details = $this->payment_model->gettable_data('payment_request',$where = array('reference_no' => $resp['reference_number']),$db);
      $student_id=$inv_details[0]->student_id; 


        $trans_response = [
              'reference_no' => $resp['reference_number'],
              'amount_payed' =>$resp['amount'],
              'transaction_receipt' => $resp['payment_receipt'],
              'transaction_date' => $resp['transaction_date'],
              'customer_name' => $resp['customer_name'],
              'account_no' =>$resp['account_number'],
              'transaction_channel' => $resp['channel'],
              'system_receipt_no' => $resp['transaction_ref']
      ];
      $this->payment_model->SaveData('payment_response',$trans_response,$db);

       $temptrans = [
                   'status' => 1,
                    'trans_date' =>date('Y-m-d H:i:s'),
                   'updated_by'=>9,
                    'updated_date' => date('Y-m-d H:i:s')
                ];
        $this->payment_model->update_table_details('transaction_numbers_tbl',$where = array('trans_number' => $inv_details[0]->trans_no,'trans_type_id'=>3),$temptrans,$db);

         $ledger = [
               'ledger_id' => 22,
               'ledger_type' => 13,
               'trans_no' => $inv_details[0]->trans_no,
               'trans_type' => 3,
               'amount' => $inv_details[0]->charges,
               'transation_nature' =>1,
               'name_type_id' => 1,
               'name_id' => $student_id,
               'balance' =>$inv_details[0]->charges
           ];

            $pstatus = [
                   'paid_charges' => 1,
                   'payment_status'=>1
                ];
                $lgAmount = [
                    'amount'=>$resp['amount']
                ];

 if($inv_details[0]->paid_charges==1){
        
        }else{
    $this->payment_model->SaveData('ledger_transaction_tbl',$ledger,$db); 
      $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$pstatus,$db);
      $this->payment_model->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $inv_details[0]->trans_no,'trans_type'=>3,'transation_nature'=>2),$lgAmount,$db); 
        }
       
       //send message to depositer
        $student_details = $this->payment_model->get_item_name('students',$where = array('id' => $student_id),$db);
        $bill = $this->payment_model->gettable_billingdata($student_id,$db);

         $phone=$bill[0]->phone1;
            if($phone != ""){
                 $received=$resp['amount']-$inv_details[0]->charges;
       $msg = "Mzazi wa ".$student_details[0]->first_name."; Malipo ya TZS ".number_format($received)." yamekamilika. Deposit namba ".$inv_details[0]->trans_no." tar ".date('d/m/Y H:i:s').".";
        $messagex="Mzazi wa FirstName; Malipo ya TZS xxxxx yamekamilika. Deposit namba xxxx tar xx/xx/xx xx:xx.";

       $snn = $this->generate_msg_no_2($db);
       $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 5,
                    'send_number' => $snn,
                    'massage_date' =>  date('Y-m-d H:i:s'),
                    'send_by' =>10,
                    'messagex' => $messagex,
                    'trans_number' => $inv_details[0]->trans_no
                  
                );
    //  print_r( $smsdata);
$this->payment_model->SaveData('message_groups_tbl',$smsdata,$db);

      }
        if($phone != ""){
        $msg = "Malipo yamekamilika. Risiti:".$inv_details[0]->trans_no.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($resp['amount']).", Muombaji: ".$student_details[0]->full_name;
       $this->SMSsender2($phone,$msg,5,$student_id,$snn,NULL,$db);
      
        }
        echo 'Successfully paid'; 
        }

        function generate_msg_no_2($db) {
        $ino = "";
        $tkens = $this->payment_model->get_max_id('message_groups_tbl','send_number',$db);
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
    public function testing(){
        echo 'tested well';
    }
public function receive_aliens($db){
      $resp = json_decode(trim(file_get_contents('php://input')), TRUE);

      $inv_details = $this->payment_model->gettable_data('payment_request',$where = array('reference_no' => $resp['reference_number']),$db);
      $student_id=$inv_details[0]->student_id;

      $trans = $this->generate_transaction_no_2($db);
        $trans_response = [
              'reference_no' => $resp['reference_number'],
              'amount_payed' =>$resp['amount'],
              'transaction_receipt' => $resp['payment_receipt'],
              'transaction_date' => $resp['transaction_date'],
              'customer_name' => $resp['customer_name'],
              'account_no' =>$resp['account_number'],
              'transaction_channel' => $resp['channel'],
              'system_receipt_no' => $resp['transaction_ref']
      ];
      $this->payment_model->SaveData('payment_response',$trans_response,$db);


      ///*************sum rcpt*******************************
       file_put_contents('Apifeedback/crdb_payments' . $resp['payment_receipt']. '.txt', json_encode($resp));
       ///*********************************************
     
      $transaction = [
              'trans_type_id' => 2,
              'trans_number' => $trans,
              'trans_date' => $resp['transaction_date'],
              'updated_by' => 9,
              'updated_date' => date('Y-m-d H:i:s')
      ];
      $this->payment_model->SaveData('transaction_numbers_tbl',$transaction,$db); 
        $total_cost = 0;
     $studentId="";
         $i=0;
         $name_type=6;
         $total_amount =$resp['amount'];
         if($inv_details[0]->paid_charges==1){
            $payedamount = $resp['amount']; 

        }else{
            $payedamount = $resp['amount']-$inv_details[0]->charges;
             $charged_update = array(
            'paid_charges' => 1
                );
         $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$charged_update,$db); 

          $ledger = [
               'ledger_id' => 22,
               'ledger_type' => 13,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $inv_details[0]->charges,
               'transation_nature' =>1,
               'name_type_id' => 6,
               'name_id' => $student_id,
               'balance' =>$inv_details[0]->charges
           ];

 $this->payment_model->SaveData('ledger_transaction_tbl',$ledger,$db);

            }
         
             $trno = $inv_details[0]->trans_no;
             //echo $trno;
            
                $itm_trans = $this->payment_model->select_inv_id($trno,$db);
                $trans_item=$itm_trans[0]->invoice_type_id;
                $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 2,
             'invoice_type_id' => $itm_trans[0]->invoice_type_id //
         ];
        $itm_trans = $this->payment_model->SaveData_n_get_id('invoice_type_transaction',$invoice_type,$db);

        // $db = \Config\Database::connect($this->dbname);
        //      $result = $db->query('SELECT * FROM  ledger_transaction_tbl  
        //             WHERE name_id = '.$student_id.' AND ledger_type = 7 and name_type_id ='.$name_type.' and trans_no ='.$trno.' AND transation_nature = 2 and trans_type = 1');
        //                 $billspending = $result->getResult(); 

                        $billspending = $this->payment_model->get_item_name('ledger_transaction_tbl',$where = array('name_id' => $student_id,'ledger_type' => 7,'name_type_id' => $name_type,'trans_no' => $trno,'transation_nature' => 2,'trans_type' => 1),$db);

        ///*************sum rcpt*******************************
         $inv_no = $this->payment_model->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $trno),$db);
            $total_paid=0;
            foreach($inv_no as $no){
                $charges=0;
                $rcpt_am = $this->payment_model->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2),$db);

                $charged = $this->payment_model->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 1,'trans_type' => 2,'ledger_id'=>22),$db);
                if(count($charged)>0){
                    $charges=$charged[0]->amount; 
                }
            if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                  
                  $total_paid=$total_paid+$am->amount-$charges;
              }
                }
            }
              
     if($inv_details[0]->amount -($total_paid + $resp['amount']) == 0){
     $payment_status = array(
            'payment_status' => 1
                );
        }elseif($inv_details[0]->amount -($total_paid + $resp['amount'])> 0){
         $payment_status = array(
            'payment_status' => 2
                );
              }else{
                $payment_status = array(
            'payment_status' => 1
                );
              } 
        $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$payment_status,$db); 
        

               ///*********************************************

             foreach($billspending as $ledger){
                if($ledger->amount -$total_paid- $payedamount >= 0){
                    $balance = $ledger->amount -$total_paid- $payedamount;
                    //echo $ledger->balance;
                    $amount = $payedamount;
                   
                }else{
                   $balance = 0;
                   $amount = $payedamount;
                  // $payedamount = $payedamount - $ledger->balance;
                }

                    $rcledger = [
                       'ledger_id' => $ledger->ledger_id,
                       'ledger_type' => 7,
                       'trans_item' => $trans_item,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $amount,
                       'transation_nature' => 1,
                       'name_type_id' => $name_type,
                       'name_id' => $student_id,
                       'balance' => $balance
                   ];
  //   print_r($rcledger);
               $payid = $this->payment_model->SaveData_n_get_id('ledger_transaction_tbl',$rcledger,$db);


                $balance = array(
                    'balance' => $balance
                );
                $this->payment_model->update_table_details('ledger_transaction_tbl',$where = array('id' => $ledger->id),$balance,$db);   
                $relation_transation = [
                       'invoice_trans_no' => $trno,
                       'receipt_trans_no ' => $trans
                         ];
          $this->payment_model->SaveData('transactions_relation',$relation_transation,$db);
  //   print_r($relation_transation);
               
             }
       ///*********************************************
              $student_details = $this->payment_model->gettable_data('other_students_tbl',$where = array('id' => $student_id),$db);
             //***start**check if transport************//
                  $transport = $this->payment_model->gettable_data('transport_details',$where = array('trans_numb' => $trno),$db);
                  if(count($transport)>0){
                     $status = array(
                    'status' => 1
                );
                $this->payment_model->update_table_details('transport_details',$where = array('trans_numb' => $trno),$status,$db);

                     }
           //*****end check if transport************//

///////////////////////////////////////////////////////////////////////////////////
    
     $l=17;

       
        $Bank_leger = $this->payment_model->gettable_data('accounts_tbl',$where = array('id' => $l),$db); 
        
       
      $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $total_amount,
               'transation_nature' =>2,
               'name_type_id' => 6,
               'name_id' => $student_id
           ];

 $this->payment_model->SaveData('ledger_transaction_tbl',$Bledger,$db);
//print_r($Bledger);

           $bill = $this->payment_model->gettable_data('other_students_tbl',$where = array('id' => $student_id),$db);
      
        $phone=$bill[0]->phone;
        $messagex="Malipo yamekamilika. Risiti: xxx, Tarehe:TZS xxx, kiasi: xxx, Mwanafunzi: #fullname.";
     $snn = $this->generate_msg_no_2($db);
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 2,
                    'send_number' => $snn,
                    'massage_date' =>  date('Y-m-d H:i:s'),
                    'send_by' =>10,
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
      
 $this->payment_model->SaveData('message_groups_tbl',$smsdata,$db);
               if($phone != ""){
                    $msg = "Malipo yamekamilika. Risiti:".$trans.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($amount).", Mwanafunzi:".$student_details[0]->full_name;
                   $this->SMSsender2($phone,$msg,2,$student_id,$snn,NULL,$db);
                  
                }  
////////////////////////////////////////////////////////////////////////
     if(count($transport)>0){
$mess="#firstname, Usafiri wako kuanzia tar dd/mm/yy na kuishia tar dd/mm/yy kibali namba xxx cha tar dd/mm/yy";
     $snn2 = $this->generate_msg_no_2($db);
      $sdata = array(
                    'send_type' => 1,
                    'message_type' => 7,
                    'send_number' => $snn2,
                    'massage_date' =>  date('Y-m-d H:i:s'),
                    'send_by' =>10,
                    'messagex' => $mess,
                    'trans_number' => $trans
                  
                );
      
    $this->payment_model->SaveData('message_groups_tbl',$sdata,$db);
               if($phone != ""){
                    $msg2 = $student_details[0]->first_name.", Usafiri wako kuanzia tar ".date('d/m/Y',strtotime($transport[0]->start_date)).", na kuishia tar ".date('d/m/Y',strtotime($transport[0]->end_date)). " kibali namba ".$transport[0]->permit_id."  cha tar ".date('d/m/Y',strtotime($transport[0]->date_created));
            $this->SMSsender2($phone,$msg2,7,$student_id,$snn2,NULL,$db);
                  
                }  
                }

}

function receive_crdb_payment($db){
    // echo $db;
    // return;
    $resp = json_decode(trim(file_get_contents('php://input')), TRUE);
       file_put_contents('Apifeedback/crdb_payments' . $resp['transaction_date']. '.txt', json_encode($resp));

      $inv_details = $this->payment_model->gettable_data('payment_request',$where = array('reference_no' => $resp['reference_number']),$db);
      $student_id=$inv_details[0]->student_id;
      
      $checkIfPresent = $this->payment_model->gettable_data('payment_response',$where = array('transaction_receipt' => $resp['payment_receipt'],'reference_no' => $resp['reference_number']),$db);
      if(count($checkIfPresent)>0){
        return;
      }

      $trans = $this->generate_transaction_no_2($db);
        $trans_response = [
              'reference_no' => $resp['reference_number'],
              'amount_payed' =>$resp['amount'],
              'transaction_receipt' => $resp['payment_receipt'],
              'transaction_date' => $resp['transaction_date'],
              'customer_name' => $resp['customer_name'],
              'account_no' =>$resp['account_number'],
              'transaction_channel' => $resp['channel'],
              'system_receipt_no' => $resp['transaction_ref']
      ];
      $this->payment_model->SaveData('payment_response',$trans_response,$db);

        $year=date('Y') +1;
       
        if($inv_details[0]->academic_year ==$year){
          $this->make_temporaly_deposit($resp,$db);
          echo "deposited";
          return;
        }
         

      ///*************sum rcpt*******************************
      
       ///*********************************************
     
      $transaction = [
              'trans_type_id' => 2,
              'trans_number' => $trans,
              'trans_date' => $resp['transaction_date'],
              'updated_by' => 9,
              'updated_date' => date('Y-m-d H:i:s')
      ];
      $this->payment_model->SaveData('transaction_numbers_tbl',$transaction,$db); 
        $total_cost = 0;
     $studentId="";
         $i=0;
         $name_type=1;
         $total_amount =$resp['amount'];
         if($inv_details[0]->paid_charges==1 && $inv_details[0]->charge_every_trans==0){
            $payedamount = $resp['amount']; 

        }else if($inv_details[0]->paid_charges==1 && $inv_details[0]->charge_every_trans==1 && $inv_details[0]->charges >=$resp['amount']){
            $payedamount = $resp['amount']; 
        }
        else{
            $payedamount = $resp['amount']-$inv_details[0]->charges;
             $charged_update = array(
            'paid_charges' => 1
                );
         $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$charged_update,$db); 

          $ledger = [
               'ledger_id' => 22,
               'ledger_type' => 13,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $inv_details[0]->charges,
               'transation_nature' =>1,
               'name_type_id' => 1,
               'name_id' => $student_id,
               'balance' =>$inv_details[0]->charges
           ];

 $this->payment_model->SaveData('ledger_transaction_tbl',$ledger,$db);

            }
         
             $trno = $inv_details[0]->trans_no;
             //echo $trno;
            
                $itm_trans = $this->payment_model->select_inv_id($trno,$db);
                $trans_item=$itm_trans[0]->invoice_type_id;
                $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 2,
             'invoice_type_id' => $itm_trans[0]->invoice_type_id //
         ];
        $itm_trans = $this->payment_model->SaveData_n_get_id('invoice_type_transaction',$invoice_type,$db);

        $billspending = $this->payment_model->get_item_name('ledger_transaction_tbl',$where = array('name_id' => $student_id,'ledger_type' => 7,'name_type_id' => $name_type,'trans_no' => $trno,'transation_nature' => 2,'trans_type' => 1),$db);

        ///*************sum rcpt*******************************
         $inv_no = $this->payment_model->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $trno),$db);
            $total_paid=0;
             $charges=0;
            foreach($inv_no as $no){
               
                $rcpt_am = $this->payment_model->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2),$db);

                $charged = $this->payment_model->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 1,'trans_type' => 2,'ledger_id'=>22),$db);
                if(count($charged)>0){
                    $charges=$charges+$charged[0]->amount; 
                }
            if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                  
                  $total_paid=$total_paid+$am->amount-$charges;
              }
                }
            }
              
     if($inv_details[0]->amount -($total_paid + $resp['amount']) == 0){
     $payment_status = array(
            'payment_status' => 1
                );
        }elseif($inv_details[0]->amount -($total_paid + $resp['amount'])> 0){
         $payment_status = array(
            'payment_status' => 2
                );
              }else{
                $payment_status = array(
            'payment_status' => 1
                );
              } 
        $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$payment_status,$db); 
        

               ///*********************************************

             foreach($billspending as $ledger){
                if($ledger->amount -$total_paid- $payedamount >= 0){
                    $balance = $ledger->amount -$total_paid- $payedamount;
                    //echo $ledger->balance;
                    $amount = $payedamount;
                    $remain=0;
                     $finalremain=0;
                }else{
                   $balance = 0;
                   $amount = $payedamount;
                   $remain= ($total_paid+ $payedamount)-$ledger->amount;
                    $finalremain=$ledger->amount- ($total_paid+ $payedamount);
                   //----overpayments start
                    if($remain >0){
                 $overP = [
                       'ledger_id' => 21,
                       'ledger_type' => 7,
                       'trans_item' => $trans_item,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $remain,
                       'transation_nature' => 2,
                       'name_type_id' => $name_type,
                       'name_id' => $student_id,
                       'balance' => $remain
                   ];
  //   print_r($rcledger);
               $overpayid = $this->payment_model->SaveData_n_get_id('ledger_transaction_tbl',$overP,$db);
               }
  //--overpayments ends
                  // $payedamount = $payedamount - $ledger->balance;
                }

                    $rcledger = [
                       'ledger_id' => $ledger->ledger_id,
                       'ledger_type' => 7,
                       'trans_item' => $trans_item,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $amount-$remain,
                       'transation_nature' => 1,
                       'name_type_id' => $name_type,
                       'name_id' => $student_id,
                       'balance' => $balance
                   ];
  //   print_r($rcledger);
               $payid = $this->payment_model->SaveData_n_get_id('ledger_transaction_tbl',$rcledger,$db);


                $balance = array(
                    'balance' => $balance
                );
                $this->payment_model->update_table_details('ledger_transaction_tbl',$where = array('id' => $ledger->id),$balance,$db);   
                $relation_transation = [
                       'invoice_trans_no' => $trno,
                       'receipt_trans_no ' => $trans
                         ];
          $this->payment_model->SaveData('transactions_relation',$relation_transation,$db);
  //   print_r($relation_transation);
               
             }
       ///*********************************************
              $student_details = $this->payment_model->gettable_data('students',$where = array('id' => $student_id),$db);
             //***start**check if transport************//
                  $transport = $this->payment_model->gettable_data('transport_details',$where = array('trans_numb' => $trno),$db);
                  if(count($transport)>0){
                     $status = array(
                    'status' => 1
                );
                $this->payment_model->update_table_details('transport_details',$where = array('trans_numb' => $trno),$status,$db);

                     }
           //*****end check if transport************//

///////////////////////////////////////////////////////////////////////////////////
    
     $l=17;

       
      $Bank_leger = $this->payment_model->get_account_details('accounts_tbl','account_name',$db);
         if(count($Bank_leger)>0){

         }else{
           $Bank_leger = $this->payment_model->gettable_data('accounts_tbl',$where = array('id' => $l),$db);  
         } 
        
       $id = $this->payment_model->gettable_data('parents_students_tbl',$where = array('student_id' => $student_id),$db);


           $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $total_amount,
               'transation_nature' =>2,
               'name_type_id' => 5,
               'name_id' => $id[0]->parent_id
           ];

 $this->payment_model->SaveData('ledger_transaction_tbl',$Bledger,$db);
//print_r($Bledger);

 ///mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm/start////
   $invT=$this->payment_model->get_item_name('invoice_type_transaction',$where=array('trans_no'=>$trno,'transaction_type_id'=>1),$db);
   $bill = $this->payment_model->gettable_billingdata($student_id,$db);
        $phone=$bill[0]->phone1;

//*****Installment Calculations ****************//
   if($invT[0]->invoice_type_id==2){
          $this->send_balance_msg($trno,$student_id,$db,$phone,2,$total_amount,$trans,$payedamount); 
                  }else{
         
        $messagex="Malipo yamekamilika. Risiti: xxx, Tarehe:TZS xxx, kiasi: xxx, Mwanafunzi: #fullname.";
     $snn = $this->generate_msg_no_2($db);
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 2,
                    'send_number' => $snn,
                    'massage_date' =>  date('Y-m-d H:i:s'),
                    'send_by' =>10,
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
      
 $this->payment_model->SaveData('message_groups_tbl',$smsdata,$db);
                  
            if($phone != ""){
                if($invT[0]->invoice_type_id==2){
                    
                   }else{
                  $msg = "Malipo yamekamilika. Risiti:".$trans.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($payedamount).", Mwanafunzi ".$student_details[0]->full_name;
                }
                   $this->SMSsender2($phone,$msg,2,$student_id,$snn,NULL,$db);
                
                  }
                }  
////////////////////////////////////////////////////////////////////////
     if(count($transport)>0){
$mess="#firstname, Usafiri wako kuanzia tar dd/mm/yy na kuishia tar dd/mm/yy kibali namba xxx cha tar dd/mm/yy";
     $snn2 = $this->generate_msg_no_2($db);
      $sdata = array(
                    'send_type' => 1,
                    'message_type' => 7,
                    'send_number' => $snn2,
                    'massage_date' =>  date('Y-m-d H:i:s'),
                    'send_by' =>10,
                    'messagex' => $mess,
                    'trans_number' => $trans
                  
                );
      
    $this->payment_model->SaveData('message_groups_tbl',$sdata,$db);
               if($phone != ""){
                    $msg2 = $student_details[0]->first_name.", Usafiri wako kuanzia tar ".date('d/m/Y',strtotime($transport[0]->start_date)).", na kuishia tar ".date('d/m/Y',strtotime($transport[0]->end_date)). " kibali namba ".$transport[0]->permit_id."  cha tar ".date('d/m/Y',strtotime($transport[0]->date_created));
            $this->SMSsender2($phone,$msg2,7,$student_id,$snn2,NULL,$db);
                  
                }  
                }
                
                
     //vfd receipt start  ////////////////////////////////////////
$tn = $this->payment_model->get_item_name('transaction_numbers_tbl',$where = array('trans_number' => $trans,'trans_type_id' => 2),$db);
    $vfd_settngs = $this->payment_model->get_item_name('vfd_settings_tbl',$where = array('status' =>1),$db);
    $get_db = $this->payment_model->get_item_name('database_list_tbl',$where = array('db_name' => $db),$db);
  if(count($vfd_settngs)>0){
    helper('vfd_helper');
    helper('qrcode_helper');

     $result=process_vfd_receipt_now($tn[0]->id,$payedamount,$student_details[0]->full_name,$db,$get_db[0]->db_id);
  }
  //vfd receipt end //////////////////////
  
                 //update table payment balance start
                 if($finalremain >=0 && $inv_details[0]->charge_every_trans==1){
                   
                 $this->updateControlNumber($trno,$finalremain,3,$db);   
                }
}

function test_blc_msg(){
//$this->send_balance_msg(1240,136,'advamhwe_elimu_db','0747672438',2,1000,5072);
}
function send_balance_msg($trno,$student_id,$db,$phone,$inv,$total_amount,$tnumber,$payedamount){
     helper('calc');
  $get_yr = $this->payment_model->gettable_data('transaction_numbers_tbl',$where = array('trans_number' => $trno,'trans_type_id' => 1),$db);
$year=date('Y',strtotime($get_yr[0]->trans_date));

$cld=$this->payment_model->get_item_name('admission_tbl',$where=array('student_id'=>$student_id,'academic_year'=>$year),$db);
$adm_id=$cld[0]->class_id;
$level_id=$cld[0]->level_id;
$hst=$cld[0]->admission_type;

$lvtbl = $this->payment_model->get_item_name('class_level_tbl', $where = array('id' => $level_id),$db);

  $tinvoice = $this->payment_model->get_total_invoice_amount($student_id,$year,$db); 
  $dbc = \Config\Database::connect($db);
  $results=findCalc($student_id,$db,$year);
   // print_r($results);
   $dateterm = $this->payment_model->checkTerm_date(date('Y-m-d'),$year,$db,$lvtbl[0]->academic_type);
                 
                  //print_r($dateterm);
                 if (is_countable($dateterm) && count($dateterm) > 0) {
                    $term_name=$dateterm[0]->term_name;
                   }else{
                    $dateterm = $this->payment_model->checkTerm_date2(date('Y-m-d'),$year,$db,$lvtbl[0]->academic_type);
                     
                     $term_name=$dateterm[0]->term_name;
                   }

                   $installments =$this->payment_model->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$lvtbl[0]->academic_type),$db);
                    
                    $ttlAmount = 0;
                     $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                      $ddate="";
                    foreach ($installments as $r) {
                     //   $paid_amount=0;
                    
                     $i++;
                    
                    
                     if($i==1){
                      $openingbalance=$results[0]['openingbalance'];
                       $ment=$results[0]['ment'];
                        $mbalance=$results[0]['mbalance'];
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[0]['today']==1){
                       $todaybalance=$results[0]['todaybalance']; 
                     }
                  
                     }
                      if($i==2){
        
                          $ment=$results[1]['ment'];
                        $mbalance=$results[1]['mbalance'];
                        $paid_amount=$results[1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[1]['today']==1){
                       $todaybalance=$results[1]['todaybalance']; 
                     } 
                     }
                   if($i==3){

                      $ment=$results[2]['ment'];
                        $mbalance=$results[2]['mbalance'];
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[2]['today']==1){
                       $todaybalance=$results[2]['todaybalance']; 
                     }
                     }
                     
                      if($i==4){

                      $ment=$results[3]['ment'];
                        $mbalance=$results[3]['mbalance'];
                        $paid_amount=$results[3]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[3]['today']==1){
                       $todaybalance=$results[3]['todaybalance']; 
                     }
                     }
                    
                 }
             
    //***end istallment calculations***//
  ///mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm/////
        $student_details = $this->payment_model->get_item_name('students',$where = array('id' => $student_id),$db);
       if($phone != ""){
           
        if($inv==2){
            if($todaybalance < 0){
                $todaybal=0;
            }else{
               $todaybal=$todaybalance;  
            }
     $msg = $student_details[0]->first_name.", Malipo yamekamilika. Risiti:".$tnumber.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($payedamount).". bank charge ".number_format($total_amount-$payedamount).". Baki- (".$term_name.")  ".number_format($todaybal).". Baki kuu ".number_format($mbalance);
                }else{
       $msg = "Malipo yamekamilika. Risiti:".$tnumber.", Tarehe:".date('d/m/Y H:i').
                       ", Kiasi:TZS ".number_format($total_amount).", Mwanafunzi:".$student_details[0]->full_name;
                   }
        $messagex="Malipo yamekamilika. Risiti: x, Tarehe: d/m/Y H:i, Kiasi:TZS xxx, Mwanafunzi: #student fullname";
     $snn = $this->generate_msg_no_2($db);
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 2,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' => 10,
                    'messagex' => $messagex,
                    'trans_number' => $tnumber
                  
                );
    
  $data=array(
      'phone'=>$phone,
       'msg'=>$msg,
        'stid'=>$student_id,
        'snn'=>$snn
      );
      //return $data;
    //print_r($data);
    
$this->payment_model->SaveData('message_groups_tbl',$smsdata,$db);

    $this->SMSsender2($phone,$msg,2,$student_id,$snn,NULL,$db);
 
   
       }  
}

function make_temporaly_deposit($resp,$db){
  //print_r($resp); 
    $inv_details = $this->payment_model->gettable_data('payment_request',$where = array('reference_no' => $resp['reference_number']),$db);
      $student_id=$inv_details[0]->student_id;
      $trno=$inv_details[0]->trans_no;
      $original_amount=$inv_details[0]->amount;
  $trans=$this->generate_transaction_deposit($db);
  $transaction = [
              'trans_type_id' => 3,
              'trans_number' => $trans,
              'trans_date' => $resp['transaction_date'],
              'updated_by' => 9,
              'updated_date' => date('Y-m-d H:i:s'),
              'trans_desc' =>  $inv_details[0]->academic_year,
                 ];
      $this->payment_model->SaveData('transaction_numbers_tbl',$transaction,$db); 

      $total_amount =$resp['amount'];
         if($inv_details[0]->paid_charges==1){
            $payedamount = $resp['amount']; 

        }else{
            $payedamount = $resp['amount']-$inv_details[0]->charges;
             $charged_update = array(
            'paid_charges' => 1
                );
         $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$charged_update,$db); 

          $ledger = [
               'ledger_id' => 22,
               'ledger_type' => 13,
               'trans_no' => $trans,
               'trans_type' => 3,
               'amount' => $inv_details[0]->charges,
               'transation_nature' =>1,
               'name_type_id' => 1,
               'name_id' => $student_id,
               'balance' =>$inv_details[0]->charges
           ];

 $this->payment_model->SaveData('ledger_transaction_tbl',$ledger,$db);

            }

             $total_cost = 0;
                $invoice_type = [
                'trans_no' => $trans,
                'transaction_type_id' => 3,
                'invoice_type_id' => 2
                ];
   
     $this->payment_model->SaveData('invoice_type_transaction',$invoice_type,$db);

    $itm = $this->payment_model->gettable_data('items_tbl',$where = array('item_group' => 10),$db);
        foreach($itm as $i){
        $itype = $i->item_type;
        $c = $i->id;
        }

        $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $trans,'trans_type' => 3, 'quantity' => 1, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $total_amount);
$this->payment_model->SaveData('item_transation_tbl',$itemData,$db);
 $leger_items = $this->payment_model->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c),$db);

 $legers = $this->payment_model->gettable_data('accounts_tbl',$where = array('id' => $leger_items[0]->account_id),$db);
                $ledger = [
                'ledger_id' => $leger_items[0]->account_id,
                'ledger_type' => $legers[0]->account_type_id,
                'trans_item' => $c,
                'trans_no' => $trans,
                'trans_type' => 3,
                'amount' => $payedamount,
                'transation_nature' => 1,
                'name_type_id' => 1,
                'name_id' => $student_id,
                ];
              
     $this->payment_model->SaveData('ledger_transaction_tbl',$ledger,$db);

               $l=17;
         $pid = $this->payment_model->gettable_billingdata($student_id,$db);
       $Bank_leger = $this->payment_model->get_account_details('accounts_tbl','account_name',$db);
                $ac_ledger = [
                'ledger_id' => $Bank_leger[0]->id,
                'ledger_type' => $Bank_leger[0]->account_type_id,
                'trans_no' => $trans,
                'trans_type' => 3,
                'amount' =>  $total_amount,
                'transation_nature' => 2,
                'name_type_id' => 5,
                'name_id' => $pid[0]->id,
                'balance' => $payedamount,
                ];   
       
        $this->payment_model->SaveData('ledger_transaction_tbl',$ac_ledger,$db);
       $phone=$pid[0]->phone1;

       $relation=array(
          'deposit_number'=>$trans,
          'invoice_number'=>$trno,
          'amount'=>$payedamount,
             );
     $this->payment_model->SaveData('deposit_receipt_tbl',$relation,$db);
      //$this->send_balance_msg($trno,$student_id,$db,$phone,2,$payedamount,$trans); 
      $balance = $this->payment_model->gettable_data('deposit_receipt_tbl',$where = array('invoice_number' => $trno),$db);
      $payed=0;
      foreach($balance as $b){
   $payed=$payed+$b->amount;
      }
      $todaybal=$original_amount -$payed;
      $student_details = $this->payment_model->gettable_data('students',$where = array('id' => $student_id),$db);  
     $msg = $student_details[0]->first_name.", Malipo yamekamilika. Deposit:".$trans.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($payedamount).". Baki- ".number_format($todaybal)." Ada ".$inv_details[0]->academic_year.".";
  $messagex=" #student fullname Malipo yamekamilika. Risiti: x, Tarehe: d/m/Y H:i, Kiasi:TZS xxx, baki x";
     $snn = $this->generate_msg_no_2($db);
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 5,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => 10,
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
    
  $data=array(
      'phone'=>$phone,
       'msg'=>$msg,
        'stid'=>$student_id,
        'snn'=>$snn
      );
  //  print_r($data);
$this->payment_model->SaveData('message_groups_tbl',$smsdata,$db);

    $this->SMSsender2($phone,$msg,2,$student_id,$snn,NULL,$db);
 

}

 public function generate_transaction_deposit($db)
    {
   $ino = "";
        $num=array();
        $tkens = $this->payment_model->get_max_deposit('transaction_numbers_tbl','trans_number',$db);
        
     
        $j=count($tkens);
     if (count($tkens) > 0) {
              foreach($tkens as $n){
            list($n1,$n2)=explode('DEP',$n->trans_number);
            array_push($num, $n2);
        }
     //   print_r(max($num));
          
            $maxid=max($num) +1;
            $ino = 'DEP'.$maxid;
        } else {
            $ino =  'DEP1';
        }
      //  $ino=SUBSTRING($col, 4);
       return $ino;

    }
    
     function updateControlNumber($trans,$amount,$type,$db){
     //$db_id=session()->get('db_id');
         $dbname='default';
         $get_db = $this->payment_model->get_item_name('database_list_tbl',$where = array('db_name' => $db),$dbname);
         if(count($get_db)==0){
            return;
         } 

          $bank_requirements = $this->payment_model->get_item_name('payments_requirements_tbl',$where = array('db_id' => $get_db[0]->db_id, 'status'=>1),$dbname);  
          
       $facility_id=$bank_requirements[0]->facility_id;


   $data=array(
            'receipt_no' => $trans,
            'amount' => $amount,
            'facility_id' => $facility_id,
            'charges' => $bank_requirements[0]->charges,
            'type' => $type,
            );
       // print_r($data); 
          $crdb_url=CRDB_URL_1;
       $url = $crdb_url."updateInvoice";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                echo $response;
                $err = curl_error($ch); 
                curl_close($ch);
    }
    
    
    
function make_temporaly_deposit_recorrect(){
  //print_r($resp); 
 return;
  $db="advamhwe_guardian_angles_db";
   $l_details = $this->payment_model->gettable_data('ledger_transaction_tbl',$where = array('trans_type' => 3,'ledger_id' => 22),$db);
  
   foreach($l_details as $dt){
        $inv_details = $this->payment_model->gettable_data('payment_request',$where = array('student_id' => $dt->name_id,'academic_year'=>'2026'),$db);
         
        $student_id=$inv_details[0]->student_id;
      $trno=$inv_details[0]->trans_no;
      $original_amount=$inv_details[0]->amount;
      
      $trans=$dt->trans_no;
      
      $payed_details = $this->payment_model->gettable_data('payment_response',$where = array('reference_no' =>$inv_details[0]->reference_no),$db);
       $payedamount = $payed_details[0]->amount_payed-$dt->amount;
       
       $total_amount=$payedamount;
   
   

    $itm = $this->payment_model->gettable_data('items_tbl',$where = array('item_group' => 10),$db);
    
        foreach($itm as $i){
        $itype = $i->item_type;
        $c = $i->id;
        }

        $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $trans,'trans_type' => 3, 'quantity' => 1, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $total_amount);
$this->payment_model->SaveData('item_transation_tbl',$itemData,$db);
 $leger_items = $this->payment_model->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c),$db);

 $legers = $this->payment_model->gettable_data('accounts_tbl',$where = array('id' => $leger_items[0]->account_id),$db);
                $ledger = [
                'ledger_id' => $leger_items[0]->account_id,
                'ledger_type' => $legers[0]->account_type_id,
                'trans_item' => $c,
                'trans_no' => $trans,
                'trans_type' => 3,
                'amount' => $payedamount,
                'transation_nature' => 1,
                'name_type_id' => 1,
                'name_id' => $student_id,
                ];
              
     $this->payment_model->SaveData('ledger_transaction_tbl',$ledger,$db);

               $l=17;
         $pid = $this->payment_model->gettable_billingdata($student_id,$db);
       $Bank_leger = $this->payment_model->get_account_details('accounts_tbl','account_name',$db);
                $ac_ledger = [
                'ledger_id' => $Bank_leger[0]->id,
                'ledger_type' => $Bank_leger[0]->account_type_id,
                'trans_no' => $trans,
                'trans_type' => 3,
                'amount' =>   $payed_details[0]->amount_payed,
                'transation_nature' => 2,
                'name_type_id' => 5,
                'name_id' => $pid[0]->id,
                'balance' => $payedamount,
                ];   
       
        $this->payment_model->SaveData('ledger_transaction_tbl',$ac_ledger,$db);
       $phone=$pid[0]->phone1;

       $relation=array(
          'deposit_number'=>$trans,
          'invoice_number'=>$trno,
          'amount'=>$payedamount,
             );
     $this->payment_model->SaveData('deposit_receipt_tbl',$relation,$db);
      //$this->send_balance_msg($trno,$student_id,$db,$phone,2,$payedamount,$trans); 
      $balance = $this->payment_model->gettable_data('deposit_receipt_tbl',$where = array('invoice_number' => $trno),$db);
      $payed=0;
      foreach($balance as $b){
   $payed=$payed+$b->amount;
      }
      $todaybal=$original_amount -$payed;
      $student_details = $this->payment_model->gettable_data('students',$where = array('id' => $student_id),$db);  
     $msg = $student_details[0]->first_name.", Malipo yamekamilika. Deposit:".$trans.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($payedamount).". Baki- ".number_format($todaybal)." Ada ".$inv_details[0]->academic_year.".";
  $messagex=" #student fullname Malipo yamekamilika. Risiti: x, Tarehe: d/m/Y H:i, Kiasi:TZS xxx, baki x";
     $snn = $this->generate_msg_no_2($db);
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 5,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => 10,
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
    
  $data=array(
      'phone'=>$phone,
       'msg'=>$msg,
        'stid'=>$student_id,
        'snn'=>$snn
      );
  //  print_r($data);
//$this->payment_model->SaveData('message_groups_tbl',$smsdata,$db);

    //$this->SMSsender2($phone,$msg,2,$student_id,$snn,NULL,$db);
 
}
echo "Success";
}
//marks the end
}


    
?>