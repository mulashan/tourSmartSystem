<?php
// By Chanangwa E,
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\UsersModel;
use App\Models\AcademicModel;
use App\Models\LoginModel;
use App\Models\StudentModel;
use App\Models\ExamModel;
use App\Models\ResultsModel;
class ResultsController extends BaseController{
    
     public function view_results(){
          $this->ResultsModel = new ResultsModel();
         $user=session()->get('user_id');
          $data['my_subjects'] = $this->ResultsModel->My_Allocated_subject($user);
          return view('templates/header')
        .view('exam_results/results_view',$data)
        .view('templates/footer');    
         }

     function get_eligible_students(){
           $this->ExamModel = new ExamModel();
             $year = $this->request->getPost('year');
         $hostel = $this->request->getPost('hostel');
        $class = $this->request->getPost('class');
            $classlevel = $this->request->getPost('classlevel');
            $stream = $this->request->getPost('stream');
            $data['classlevel']=$this->request->getPost('classlevel');
            $data['class']=$this->request->getPost('class');
            $data['stream']=$this->request->getPost('stream');
            $data['year']=$this->request->getPost('year');
            $data['term']=$this->request->getPost('term');
            $data['admission']=$this->ExamModel->get_student_info();

      echo view('exam_results/forms/students_list',$data); 
     }
public function exam_report(){
  $this->ExamModel = new ExamModel();
  $this->AcademicModel = new AcademicModel();
        $status = $this->request->getPost('status');
        $year = $this->request->getPost('year');
        $class = $this->request->getPost('class');
            $classlevel = $this->request->getPost('classlevel');
            $stream = $this->request->getPost('stream');
            $data['classlevel']=$this->request->getPost('classlevel');
            $data['class']=$this->request->getPost('class');
            $data['stream']=$this->request->getPost('stream');
            $data['year']=$this->request->getPost('year');
            $data['time']=1;
            $data['cl']=$this->ExamModel->get_student_info($class,$classlevel,$stream,$year,$status);
            $data['students']=$this->ExamModel->get_student_details($class,$classlevel,$stream,$year,$status);
           echo view('exam_results/forms/student_list',$data); 
         }

    public  function get_terms(){
        $this->ResultsModel = new ResultsModel();
           $year=$this->request->getPost('year');
           $data = $this->ResultsModel->term_list($year); 
 return $this->response->setJSON($data);
        } 
         public  function get_exams(){
        $this->ResultsModel = new ResultsModel();
           $term=$this->request->getPost('tem');
           $data = $this->ResultsModel->exam_list($term); 
          return $this->response->setJSON($data);
        }
    public function ViewMySubjects(){
        $user=session()->get('user_id');
       $data= array(
        'my_subjects' => $this->AcademicModel->My_Allocated_subject($user)
    );
           return view('templates/header')
            .view('academic/teacher/subject_allocation',$data)
            .view('templates/footer');
    }        
}
?>