<?php
$smodel = new App\Models\StudentModel();
$department = $smodel->gettable_data('departments_tbl',$where = array('id >' => 0));
$job_title = $smodel->gettable_data('job_tittle_tbl',$where = array('id >' => 0));

?>

<div class="row">
  
 <div class="col-md-6">
        <div class="card invoice">
            <!-- <div class="card-header">
                <h5>Staff Information</h5>
            </div>
            </hr>
 -->

            <div class="card-body">
               
                <table class="table table-borderless">
                    <?php
         if(isset($det) && !empty($det)):
         $user_photo=$det[0]->user_photo;
                        ?>
                    <tr>
                    <td>
                        <?php
                         if($user_photo !=''){
                        ?>
                        <img src="<?=base_url('public/users_photos').'/'.$user_photo;?>" width="90" height="90" alt="User Image" style="border:2px solid black;">
                        <?php
                        }else{
                        ?>
                        <img src="<?=base_url('public/users_photos/default_picture.png');?>" width="90" height="90" alt="User Image" style="border:2px solid black;">
                        <?php
                    }
                        ?> 
                    </td>
                    </tr>

                    <tr>
                        <th>Name:</th>
                        <td><?= $det[0]->first_name." ".$det[0]->last_name; ?></td>
                    </tr>
                    <tr>
                        <th>Gender:</th>
                        <td><?= $det[0]->gender; ?></td>
                    </tr>
                    <tr>
                        <th>Address:</th>
                        <td><?= $det[0]->physical_adress; ?></td>
                    </tr>
                    <tr>
                        <?php
           $user_type = $smodel->gettable_data('users_type_tbl',$where = array('id' => $det[0]->user_type));
                        ?>
                        <th>user type:</th>
                        <td><?= $user_type[0]->type_name??""; ?></td>
                    </tr>
                   
                    <tr>
                        <th>Phone:</th>
                        <td><?= $det[0]->phone_no; ?></td>
                    </tr>
                     <tr>
                        <th>Email:</th>
                        <td><?= $det[0]->email; ?></td>
                    </tr>

                      <tr>
                        <th>DOB:</th>
                        <td><?= $det[0]->birth_date; ?></td>
                    </tr>
<?php
endif;
?>
                </table>
            </div>
        </div>
    </div>

     <div class="col-md-6">
        <div class="card invoice">
            <!-- <div class="card-header">
                <h5>Staff Information</h5>
            </div>
            </hr> -->

            <div class="card-body">
               
                <table class="table table-borderless">
                    <tr>
                        <?php 
                        $dep="--";
                        if(count($staff_details)>0){ 
                          $dep_type = $smodel->gettable_data('departments_tbl',$where = array('id' => $staff_details[0]->dep_id));
                          $dep=$dep_type[0]->dep_name??"";
                            }?> 
                        <th>Department:</th>
                        <td><?= $dep; ?></td>
                    </tr>
                    <tr>
                        <?php 
                        $jonname="--";
                        if(count($staff_details)>0){ 
                          $job = $smodel->gettable_data('job_tittle_tbl',$where = array('id' => $staff_details[0]->job_id));
                          $jonname=$job[0]->job_tittle??"";
                            }?> 
                        <th>job tittle:</th>
                        <td><?= $jonname; ?></td>
                    </tr>
                    <tr>
                        <?php 
                        $bsalary="--";
                        if(count($staff_details)>0){ 
                            $bsalary=$staff_details[0]->basic_salary;
                            }?> 
                        <th>Basic Salary:</th>
                        <td><?= $bsalary; ?></td>
                    </tr>
                    <tr>
                        <?php 
                        $allowance="--";
                        if(count($staff_details)>0){ 
                            $allowance=$staff_details[0]->allowances;
                            }?> 
                        <th>Allowances:</th>
                        <td><?= $allowance??""; ?></td>
                    </tr>
                   
                    <tr>
                            <?php 
                        $expiry="--";
                        if(count($staff_details)>0){ 
                            $expiry=date('Y-m-d',strtotime($staff_details[0]->contract_expiry_date));
                            }?>
                        <th>Contract Expiry:</th>
                        <td><?= $expiry; ?></td>
                    </tr>
                     <tr>
                        <?php 
                        $account="--";
                        if(count($staff_details)>0){ 
                            $account=$staff_details[0]->account_number;
                            }?>
                        <th>Bank Account Number:</th>
                        <td><?= $account; ?></td>
                    </tr>

                    <tr>
                        <?php 
                        $pension="--";
                        if(count($staff_details)>0){ 
                            $pension=$staff_details[0]->pension_no;
                            }?>
                        <th>pension:</th>
                        <td><?= $pension; ?></td>
                    </tr>

                    <tr>
                        <?php 
                        $tin="--";
                        if(count($staff_details)>0){ 
                            $tin=$staff_details[0]->tin_no;
                            }?>
                        <th>Tin No:</th>
                        <td><?= $tin; ?></td>
                    </tr>

                     <tr>
                         <?php 
                        $nhf="--";
                        if(count($staff_details)>0){ 
                            $nhf=$staff_details[0]->nhf_no;
                            }?>
                        <th>nhf No:</th>
                        <td><?= $nhf; ?></td>
                    </tr>

                    <tr>
                          <?php 
                        $wcf="--";
                        if(count($staff_details)>0){ 
                            $wcf=$staff_details[0]->wcf_no;
                            }?>
                        <th>wcf:</th>
                        <td><?= $wcf; ?></td>
                    </tr>

                </table>
            </div>
        </div>
    </div>

</div>
