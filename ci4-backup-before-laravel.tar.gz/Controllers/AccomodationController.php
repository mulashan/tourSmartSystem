<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AccomodationModel;
use App\Models\ClassesModel;
use App\Models\BillingModel;

class AccomodationController extends BaseController
{
   public $accomodationModel;
   public $cmodel;
   public function __construct(){
        if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
    $this->accomodationModel = new AccomodationModel();
    $this->bModel = new BillingModel; 
    $this->cmodel = new ClassesModel();
     $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    $this->validation = \Config\Services::validation();
    }

    public function accomodation()
    {
        $data['list']=$this->accomodationModel->accomodationList();

        return view('templates/header')
        .view('accomodation/accomodation',$data)
        .view('templates/footer');
    }
    
    function selectColor($item_type){
         $color="#3D40E1"; 
        if($item_type==1){
         $color="red";
        }else if($item_type==2){
         $color="brown";   
        }else if($item_type==3){
         $color="green";   
        }else if($item_type==4){
         $color="blue";   
        }else if($item_type==5){
         $color="pink";   
        }else if($item_type==6){
         $color="#45D999";   
        }else if($item_type==7){
         $color="#45CFD9";   
        }else if($item_type==8){
         $color="#E39D3B";   
        }else if($item_type==8){
         $color="#D5E33B";   
        }
        return $color;
  }
  
public function load_accomodation_data()
{

$request = service('request');
$postData = $request->getPost();
$item_data = array();
$builder = $this->db->table("items_tbl");

if(isset($postData['query'])){

    $builder->select('id,item_name,item_price,item_size,item_attribute,item_type');
    $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
    $builder->like('item_name',$postData['query'],'both');
    // $builder->where('item_group',3);
    $builder->limit(100);
    $query = $builder->get();
    $item_result = $query->getResult();
}else{

    $builder->select('id,item_name,item_price,item_size,item_attribute,item_type');
    $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
    // $builder->where('item_group',3);
    $builder->limit(100);
    $query = $builder->get();
    $item_result = $query->getResult();
}

if(count($item_result) > 0){
    foreach($item_result as $result){
        $name=$result->item_name;
        $size=$result->item_size;
        $attr=$result->item_attribute;
        $prc=number_format($result->item_price);
      $item_type=$result->item_type;
        $typename=$this->bModel->get_item_name('items_types_tbl',$where = array('id' => $item_type));
          
         $color=$this->selectColor($item_type);

        $item_data[] = array('id'=>$result->id,'text'=>'<i style="color: '.$color.'"> '.$name.' | item type: '.$typename[0]->type_name.' | Attribute: '.'   '.$attr.'| Size: '.$size.' | Price: '.$prc.'/=</i>');
    }
}    
$response['data'] = $item_data;

return $this->response->setJSON($response);
}

public function load_diposit_data()
{

$request = service('request');
$postData = $request->getPost();
$item_data = array();
$builder = $this->db->table("items_tbl");

if(isset($postData['query'])){

    $builder->select('id,item_name,item_price,item_size,item_attribute');
    $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
    $builder->like('item_name',$postData['query'],'both');
   // $builder->whereIn('item_type', [6,8]);
    $builder->limit(100);
    $query = $builder->get();
    $item_result = $query->getResult();
}else{

    $builder->select('id,item_name,item_price,item_size,item_attribute');
    $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
    //$builder->whereIn('item_type', [6,10]);
    $builder->limit(100);
    $query = $builder->get();
    $item_result = $query->getResult();
}

if(count($item_result) > 0){
    foreach($item_result as $result){
        $name=$result->item_name;
        $size=$result->item_size;
        $attr=$result->item_attribute;
        $prc=number_format($result->item_price);
        $item_data[] = array('id'=>$result->id,'text'=>'  '.' '.' '.$name.' Attribute: '.'   '.$attr.' Size: '.$size.' Price: '.$prc.'/=');
    }
}    
$response['data'] = $item_data;

return $this->response->setJSON($response);
}
public function load_accomodation_data1()
{
$postedData = $this->request->getRawInput();
    // print_r($postedData['selected_items_array']);
    //print_r($postedData['item_selected']);
$selectedItem = explode(',', $postedData['selected_items_array']);
$check_ledger=$this->bModel->get_item_name('items_ledgers_tbl',$where = array('item_id' => $postedData['item_selected']));
 if(count($check_ledger)==0){
      echo "2";
        return;
 }
  $legers = $this->bModel->get_item_name('accounts_tbl',$where = array('id' => $check_ledger[0]->account_id));
  if(count($legers)==0){
      echo "2";
        return;
 }
 
foreach ($selectedItem as $sdi) {
    if($sdi == $postedData['item_selected']){
        echo "1";
        return;
    }
}

$data = $this->accomodationModel->items_chargedList1($postedData['item_selected']);
$item_data = array();
if(count($data) > 0){

   foreach($data as $dt){

   $item_data[] = array("id" => $dt->id,"iprice" => $dt->item_price, "iname" => $dt->item_name, "isize" => $dt->item_size,"iattribute" => $dt->item_attribute,"account_name" => $dt->account_name,"avg_cost" => $dt->avg_cost,"item_balance" => $dt->item_balance,"last_price" => $dt->last_price);
}
}
echo json_encode($item_data);
}

public function load_accomodation_data2($id)
{
$postedData = $this->request->getRawInput();
    // print_r($postedData['selected_items_array']);
    //print_r($postedData['item_selected']);
$selectedItem = explode(',', $postedData['selected_items_array']);
$data['itemId']=$this->accomodationModel->selectItemId($id);
$array=$data['itemId'];


foreach ($selectedItem as $sdi) {
    for ($i=0;$i<sizeof($array);$i++) {
        $itemId=$array[$i]->item_id;


        if($sdi == $postedData['item_selected']||$itemId==$postedData['item_selected']){
            echo "1";
            return;
        }
    }
}

$data = $this->accomodationModel->items_chargedList1($postedData['item_selected']);
$item_data = array();
if(count($data) > 0){

   foreach($data as $dt){

    $item_data[] = array("id" => $dt->id,"iprice" => $dt->item_price, "iname" => $dt->item_name, "isize" => $dt->item_size,"iattribute" => $dt->item_attribute);
}
}
echo json_encode($item_data);
}

public function saveAccomodation()
{
$validation = [
    'hostel' => 'required',
    'block' => 'required',
    'bed' => 'required',
    'gender' => 'required',
   
];
if($this->validate($validation)){
    $checkIfexists = $this->cmodel->check_ifExist('hostel_tbl', $where = array('hostel_name' => $this->request->getPost('hostel')));

    if($checkIfexists){
        echo json_encode(array('status' =>'1','statusDesc' => 'Hostel With <b>Name: '.$checkIfexists[0]->hostel_name.' & ID:'.$checkIfexists[0]->id.'</b> Already registerd.'));
    }else{
        $data = [
            'hostel_name' => ucwords(strtolower($this->request->getPost('hostel'))),
            'updated_by' => $_SESSION['user_id'],
            'updated_date' => date('Y/m/d H:i:s')
        ];

        $hostel=$this->accomodationModel->add_hostel($data);

        if($hostel != 0){
            $data1 = [
                'block_name' => ucwords(strtolower($this->request->getPost('block'))),
                'gender' => $this->request->getPost('gender'),
                'capacity' => $this->request->getPost('bed'),
                'start_age' => $this->request->getPost('start'),
                'end_age' => $this->request->getPost('fnsh'),
                'hostel_id' => $hostel,
                'balance' => 1400,
                'updated_by' => $_SESSION['user_id'],
                'updated_date' => date('Y/m/d H:i:s')
            ];
            $this->accomodationModel->save_hostelBlocks($data1);
            }

            if($hostel != 0){
                $installment = $this->accomodationModel->saveInstallmentData($hostel);
                //$charged_item = array();
        }
        if($hostel != 0){
            $accomodationItem = $this->request->getPost('id');
           if(!empty($accomodationItem)){
            foreach ($accomodationItem as $i) {
                $charged_item = array('item_id' => $i, 'hostel_id' => $hostel, 'quantity' => $this->request->getPost('qty'.$i),'account_receivable' => $this->request->getPost('account'));
                $this->accomodationModel->save_charged_items($charged_item);
            }
            }else{
                
            }
        }
            echo json_encode(array('status' =>'0','statusDesc' => 'Hostel Added Successful'));
    }

}else{
    echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));
}
}

public function update_accomodation_hostel()
{

$hostel=$this->request->getPost('hostel_id');
        //echo $hostel;
$data = [
'hostel_id' => $this->request->getPost('hostel_id'),
'block_name' => $this->request->getPost('block'),
'capacity' => $this->request->getPost('bed'),
'gender' => $this->request->getPost('gender'),
'start_age' => $this->request->getPost('start'),
'end_age' => $this->request->getPost('fnsh'),
'status' => 1,
'updated_by' =>$_SESSION['user_id'],
'updated_date' => date('Y/m/d H:i:s')
];
//print_r($data);
$data1 = [
'id' => $this->request->getPost('hostel_id'),
'hostel_name' => $this->request->getPost('hostel'),
'status' => 1,
'updated_by' => $_SESSION['user_id'],
'updated_date' => date('Y/m/d H:i:s')
];



$this->accomodationModel->edit_accomodation($this->request->getPost('hostel_id'),$data,$data1);
echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
<span class="glyphicon glyphicon-ok"></span> Accomodation Hostel Updated Successfully.</div> ';
   // return redirect()->to( base_url('accomodation') )->with('msg', 'Accomodation updated Successfully');
}
public function update_accomodation_item()
{

$hostel=$this->request->getPost('hostel_id');
$accomodationItem = $this->request->getPost('id');
$ac = $this->request->getPost('account');
$this->accomodationModel->delete_hostelId($hostel);
foreach ($accomodationItem as $i) {
$charged_item = array('item_id' => $i, 'hostel_id' => $hostel, 'quantity' => $this->request->getPost('qty'.$i),'account_receivable' => $ac);
$this->accomodationModel->edit_charged_items($hostel,$charged_item);


}

echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
<span class="glyphicon glyphicon-ok"></span> Accomodation Charged Items Updated Successfully.</div> ';

$this->accomodationModel->edit_accomodation($this->request->getPost('hostel_id'),$data,$data1);
echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
<span class="glyphicon glyphicon-ok"></span> Accomodation Updated Successfully.</div> ';

   // return redirect()->to( base_url('accomodation') )->with('msg', 'Accomodation updated Successfully');
}
public function deleteAcc($id)
{


$this->accomodationModel->deleteAcc($id);
}

public function deletehostelItem($id)
{


$this->accomodationModel->deletehostelItem($id);
}

public function editAcc()
{
$id = $this->request->getVar('ids');    
$data['list']=$this->accomodationModel->singleAccomodation($id);
$data['tabledata']=$this->accomodationModel->tabledata($id);
$data['hostel_id']=$id;

echo view('accomodation/form/edit_accomodation',$data); 
}    

public function get_hostel_chargedItems()
{
$builder = $this->db->table('class_charged_items_tbl');
$builder->select('quantity,item_name,item_attribute,item_size,item_group,item_id,class_charged_items_tbl.id,class_id');
$builder->join('items_tbl', 'items_tbl.id = class_charged_items_tbl.item_id');
$builder->where('item_group = 0');
$builder->where('class_id',$this->request->getGet('class_id'));
$class_result = $builder->get()->getResult();

$class_data = array();

if(count($class_result) > 0){

    $iprice = "";
    foreach ($class_result as $cr)
    {
        $datas = $this->cmodel->get_ChargedItems_list($cr->item_id);
        foreach ($datas as $dts) {
            $iprice = $dts->item_price;
        }

        $data = array("id" => $cr->id,"item_id" => $cr->item_id, "quantity" => $cr->quantity, "name" => $cr->item_name, "size" => $cr->item_size, "attribute" => $cr->item_attribute, "price" => $iprice);
        array_push($class_data, $data);
    }

         
        $this->accomodationModel->deletehostelItem($id);
    }
}
public function adding_temporary_data2()
{
     $exit=$this->accomodationModel->check_temp($this->request->getPost('installname'));

    if($exit>0){
        echo '1';
    }else{
        $data = [
            'istallment_name' => $this->request->getPost('installname'),
            'amount' => $this->request->getPost('amount'),
            'tbl_id' => $this->request->getPost('id'),
            'installment_type' =>2,
            
        ];

        if($exit>0){
            echo '1';
        }else{
    $data = [
        'istallment_name' => $this->request->getPost('installname'),
        'amount' => $this->request->getPost('amount'),
        'tbl_id' => $this->request->getPost('id'),
        
        'installment_type' =>2,
        
    ];

        $inst = $this->accomodationModel->add_temporary($data);
    }
}
}
public function getting_tempo2()
{
    $builder = $this->db->table('installments_tbl ');
    $builder->select('*');
    $builder->where('tbl_id',$this->request->getGet('acc_id'));
    $builder->where('installment_type',2);
    $ments_result = $builder->get()->getResult();
    
    $ments_dta = array();
   
    if(count($ments_result) > 0){
        $total=0;
        foreach ($ments_result as $sr)
        {
    $builder = $this->db->table('school_terms_tbl');
    $builder->select('*');
    $builder->where('id',$sr->istallment_name);
    $result = $builder->get()->getResult();

            $amount=$sr->amount;
            
            $total=$total+$amount;
            $data = array("id" => $sr->id,"installname" => $result[0]->term_name, "amount" => $sr->amount,"due_date" => $result[0]->end_date,
             "classid" => $sr->tbl_id,"tamount"=>$total);
            array_push($ments_dta, $data);
        }

        echo json_encode($ments_dta);
    }
    }

public function getting_installments2()
    {
        $builder = $this->db->table('installments_tbl ');
        $builder->select('*');
        $builder->where('tbl_id',$this->request->getGet('acc_id'));
        $builder->where('installment_type',2);
        $ments_result = $builder->get()->getResult();
        
        $builder = $this->db->table('hostel_charged_items_tbl');
        $builder->select('hostel_charged_items_tbl.item_id,hostel_charged_items_tbl.quantity,
        price_tbl.item_price');
        $builder->join('price_tbl', 'price_tbl.item_id = hostel_charged_items_tbl.item_id');
        $builder->where('hostel_charged_items_tbl.hostel_id',$this->request->getGet('acc_id'));
        $price_result = $builder->get()->getResult();

        $ments_dta = array();
        if(count($price_result) > 0){
            $total=0;
            foreach ($price_result as $pr)
            {
                $qty=$pr->quantity;
                $price=$pr->item_price;
                $tprice=$qty*$price;
                $total=$total+$tprice;
            }
            }else{
             $total=0;   
            }
        if(count($ments_result) > 0){
            
            foreach ($ments_result as $sr)
            {
    $builder = $this->db->table('school_terms_tbl');
    $builder->select('*');
    $builder->where('id',$sr->istallment_name);
    $result = $builder->get()->getResult();

                $data = array("id" => $sr->id,"installname" => $result[0]->term_name, "amount" => $sr->amount,"due_date" => $result[0]->end_date,
                "classid" => $sr->tbl_id,"tprice"=>$total);
                array_push($ments_dta, $data);
            }

            echo json_encode($ments_dta);
        }
    }
public function adding_installment_data2($id)
    {
         $exit = $this->accomodationModel->check_inst($id,$this->request->getPost('installname'));
        if($exit>0){
            echo '1';
        }else{
        $data = [
            'istallment_name' => $this->request->getPost('installname'),
            'amount' => $this->request->getPost('amount'),
            'tbl_id' => $this->request->getPost('id'),
            'installment_type' =>2,
            
        ];

        $inst = $this->accomodationModel->add_installment($data);
    }}

    public function load_deposit_data($id)
{

$data = $this->accomodationModel->deposit_data($id);
$item_data = array();
if(count($data) > 0){

   foreach($data as $dt){

    $item_data[] = array("id" => $dt->id,"iprice" => $dt->unit_price, "iname" => $dt->item_name, "isize" => $dt->item_size,"iattribute" => $dt->item_attribute);
}
}
echo json_encode($item_data);
}  

public function load_purchase_data()
{

$request = service('request');
$postData = $request->getPost();
$item_data = array();
$builder = $this->db->table("items_tbl");

if(isset($postData['query'])){

    $builder->select('id,item_name,item_price,item_size,item_attribute,item_type');
    $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
    $builder->like('item_name',$postData['query'],'both');
    $builder->whereIn('item_type',[1,4]);
    $builder->limit(100);
    $query = $builder->get();
    $item_result = $query->getResult();
}else{

    $builder->select('id,item_name,item_price,item_size,item_attribute,item_type');
    $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
    $builder->whereIn('item_type',[1,4]);
    $builder->limit(100);
    $query = $builder->get();
    $item_result = $query->getResult();
}

if(count($item_result) > 0){
    foreach($item_result as $result){
        $name=$result->item_name;
        $size=$result->item_size;
        $attr=$result->item_attribute;
        $prc=number_format($result->item_price);
        $item_type=$result->item_type;
        $typename=$this->bModel->get_item_name('items_types_tbl',$where = array('id' => $item_type));
          
         $color=$this->selectColor($item_type);

        $item_data[] = array('id'=>$result->id,'text'=>'<i style="color: '.$color.'"> '.$name.' | item type: '.$typename[0]->type_name.' | Attribute: '.'   '.$attr.'| Size: '.$size.' | Price: '.$prc.'/=</i>');
    }
}    
$response['data'] = $item_data;

return $this->response->setJSON($response);
}
}

