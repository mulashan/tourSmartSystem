<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AdmissionModel;
use App\Models\StudentModel;
use App\Models\ClassesModel;
use App\Models\BillingModel;
use App\Models\SystemModel;
use App\Models\ReportsModel;
use App\Models\PaymentsModel;

class AdmissionController extends BaseController
{
    public $amodel;
    public $smodel;
    public $cmodel;
    public $bmodel;
    public $sytm_model;
    public function __construct(){
         if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
        $this->amodel = new AdmissionModel();
        $this->smodel = new StudentModel();
        $this->cmodel = new ClassesModel();
        $this->bmodel = new BillingModel();
        $this->sytm_model = new SystemModel();
        $this->report = new ReportsModel();
        $this->payment_model = new PaymentsModel;
        
        $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
            helper('age');


    }
    public function student_admission()
    {
        return view('templates/header')
        .view('student/student_admision')
        .view('templates/footer');   
    }

    
     public function student_admission_details()
    {
        $id = $this->request->getVar('id');
        $data['lv']=$this->request->getVar('level');
        $data['cl']=$this->request->getVar('class');
        $data['bod']=$this->request->getVar('bod');
        $data['year']=$this->request->getVar('year');
        $data['str']=$this->request->getVar('stream');
        $data['for']=$this->request->getVar('for');
        $data['student_dtl'] = $this->amodel->get_student_details('students', $where = array('id' => $id));

        // $data['classes'] = $this->amodel->get_student_details('classes_tbl', $where = array('status' => 1));
        $data['studentparent'] = $this->amodel->get_student_details('parents_students_tbl', $where = array('student_id' => $id));

        echo view('student/admission_details',$data);
    }
 public function student_pending_details()
    {
        $id = $this->request->getVar('id');
         $data['year']=$this->request->getVar('year');
    $data['student_dtl'] = $this->amodel->get_student_details('students', $where = array('id' => $id));

        // $data['classes'] = $this->amodel->get_student_details('classes_tbl', $where = array('status' => 1));
        $data['studentparent'] = $this->amodel->get_student_details('parents_students_tbl', $where = array('student_id' => $id));

        echo view('student/admission_pending_details',$data);
    }
    public function load_class_details()
    {

        $id = $this->request->getVar('level');
        $classes = $this->amodel->get_student_details('classes_tbl', $where = array('class_level' => $id,'status' => 1));

        if(count($classes) > 0){
            $select_class = array();
            foreach ($classes as $cl) {
                $streamdta = $this->amodel->get_student_details('streams_tbl', $where = array('class_id' => $cl->id,'status' => 1));
                $sum_sd = 0;
                foreach ($streamdta as $sd) {
                    $count = $this->amodel->get_total_stream_capacity($cl->id,$sd->id);
                    $stm_ttl = $sd->stream_capacity - $count[0]->stream_id;
                    $sum_sd += $stm_ttl;
                }

                $select_class []=array('id' => $cl->id, 'cname' => $cl->class_name, 'capcity' => $sum_sd);
                // if($sum_sd <= 0){
                //     echo '<option value="'.$cl->id.'" disabled style="color:red">'.$cl->class_name.' - '.$sum_sd.' (<p>No Room for New Student</p>)</option>';
                // }else{
                //     echo '<option value="'.$cl->id.'">'.$cl->class_name.' - '.$sum_sd.'</option>';
                // }
            }
            echo json_encode($select_class);
        }
    }


public function class_streams_details()
{
    $id = $this->request->getVar('id');
    $streamdta = $this->amodel->get_student_details('streams_tbl', ['class_id' => $id, 'status' => 1]);

    if (!empty($streamdta)) {
        $select_stream = [];
        foreach ($streamdta as $sd) {
            $count = $this->amodel->get_total_stream_capacity($id, $sd->id);
            $used_capacity = isset($count[0]->stream_id) ? $count[0]->stream_id : 0;
            $stm_ttl = $sd->stream_capacity - $used_capacity;
            $combdetails = $this->amodel->get_stream_comb_allocatiion($sd->id);
            $comb = (isset($combdetails[0])) ? $combdetails[0]->comb_name : 'no comb';

            $select_stream[] = [
                "id" => $sd->id,
                "name" => $sd->stream_name,
                "stream" => $stm_ttl,
                "comb" => $comb
            ];
        }

        echo json_encode($select_stream);
    } else {
        echo json_encode([]);
    }
}

 public function getStationdata()
    {
        $builder = $this->db->table('station_tbl');
        $builder->select('');
        $result = $builder->get()->getResult();

        if(count($result) > 0){
            $select = array();
            foreach($result as $sd){
                //$count = $this->amodel->get_total_stream_capacity($id,$sd->id);
                //$stm_ttl = $sd->stream_capacity - $count[0]->stream_id;

                $select []=array("id" => $sd->id,"name" => $sd->station_name);
            }

            echo json_encode($select);
        }
    }

     public function getSessiondta()
    {
        $id = $this->request->getVar('id');
        $streamdta = $this->amodel->get_student_details('station_session_tbl', $where = array('station_id' => $id));

        if(count($streamdta) > 0){
            $select = array();
            foreach($streamdta as $sd){
                if($sd->session_name==1){
                    $session_name="Morning";
                }else if($sd->session_name==2){
                  $session_name="Afternoon";  
                }else if($sd->session_name==3){
                  $session_name="Evening";  
                }
                //$count = $this->amodel->get_total_stream_capacity($id,$sd->id);
                //$stm_ttl = $sd->stream_capacity - $count[0]->stream_id;

                $select []=array("id" => $sd->session_name,"name" => $session_name,"time" => $sd->session_time);
            }

            echo json_encode($select);
        }
    }

    public function get_hostel_chargedItems()
    {

        $builder = $this->db->table('class_charged_items_tbl');
        $builder->select('class_id,quantity,item_name,item_attribute,item_size,item_group,item_id,class_charged_items_tbl.id,account_receivable');

        $builder->join('items_tbl', 'items_tbl.id = class_charged_items_tbl.item_id');
       // $builder->where('item_group = 3');
        $names = [3, 4];
        if($this->request->getGet('admfor')==2){
            if($this->request->getGet('class_id')==7 || $this->request->getGet('class_id')==6 ){
              $builder->where('item_group', 4);
            }else{
         $builder->whereIn('item_group', $names);
           }
        }else{
          $builder->where('item_group', 3);  
        }
        $builder->where('class_id',$this->request->getGet('class_id'));
        $hostel_result = $builder->get()->getResult();

        $hostel_data = array();

        if(count($hostel_result) > 0){

            $iprice = "";
            foreach ($hostel_result as $hr)
            {
                $datas = $this->amodel->get_student_details('price_tbl', $where = array('item_id' => $hr->item_id));
                foreach ($datas as $dts) {
                    $iprice = $dts->item_price;
                }

                $data = array("id" => $hr->id,"item_id" => $hr->item_id, "quantity" => $hr->quantity, "name" => $hr->item_name, "size" => $hr->item_size, "attribute" => $hr->item_attribute, "price" => $iprice, "accounts" => $hr->account_receivable, "hostel_id" => $hr->class_id);
                array_push($hostel_data, $data);
            }

            //echo json_encode($hostel_data);
        }

        $level = $this->amodel->get_student_details('classes_tbl', $where = array('id' => $this->request->getGet('class_id')));

          $builder = $this->db->table('class_level_items_tbl');
        $builder->select('quantity,item_name,item_attribute,item_size,item_group,item_id,class_level_items_tbl.id,level_id,account_receivable');

        $builder->join('items_tbl', 'items_tbl.id = class_level_items_tbl.item_id'); 
         $names = [3, 4];  
          if($this->request->getGet('admfor')==2){
          $builder->whereIn('item_group', $names);
         }else{
            $builder->where('item_group', 3);   
         }
         $builder->where('level_id',$level[0]->class_level);
          $hostel_result = $builder->get()->getResult();

            if(count($hostel_result) > 0){

            $iprice = "";
            foreach ($hostel_result as $hr)
            {
                $datas = $this->amodel->get_student_details('price_tbl', $where = array('item_id' => $hr->item_id));
                foreach ($datas as $dts) {
                    $iprice = $dts->item_price;
                }

                $data = array("id" => $hr->id,"item_id" => $hr->item_id, "quantity" => $hr->quantity, "name" => $hr->item_name, "size" => $hr->item_size, "attribute" => $hr->item_attribute, "price" => $iprice, "accounts" => $hr->account_receivable, "hostel_id" => $level[0]->id);
                array_push($hostel_data, $data);
            }

           
        }
         echo json_encode($hostel_data);

        
    }


    public function get_hostel_chargedItemsbod()
    {
        $qty=$this->request->getGet('qty');
        $builder = $this->db->table('class_charged_items_tbl');
        $builder->select('class_id,quantity,item_name,item_attribute,item_size,item_group,item_id,class_charged_items_tbl.id,account_receivable');

        $builder->join('items_tbl', 'items_tbl.id = class_charged_items_tbl.item_id');
       // $builder->where('item_group = 3');
        $names = [3, 4];
        if($this->request->getGet('admfor')==2){
            if($this->request->getGet('class_id')==7 || $this->request->getGet('class_id')==6 ){
              $builder->where('item_group', 4);
            }else{
         $builder->whereIn('item_group', $names);
           }
        }else{
          $builder->where('item_group', 3);  
        }
        $builder->where('class_id',$this->request->getGet('class_id'));
        $hostel_result = $builder->get()->getResult();

        $hostel_data = array();

        if(count($hostel_result) > 0){

            $iprice = "";
            foreach ($hostel_result as $hr)
            {
                $datas = $this->amodel->get_student_details('price_tbl', $where = array('item_id' => $hr->item_id));
                foreach ($datas as $dts) {
                    $iprice = $dts->item_price;
                }

                $data = array("id" => $hr->id,"item_id" => $hr->item_id, "quantity" => $qty, "name" => $hr->item_name, "size" => $hr->item_size, "attribute" => $hr->item_attribute, "price" => $iprice, "accounts" => $hr->account_receivable, "hostel_id" => $hr->class_id);
                array_push($hostel_data, $data);
            }

            echo json_encode($hostel_data);
        }
    }
    public function get_transport_chargedItems()
    {
        $builder = $this->db->table('transport_item_tbl');
        $builder->select('quantity,item_name,item_attribute,item_size,item_group,item_id,transport_item_tbl.id,transport_id,account_receivable');
        $builder->join('items_tbl', 'items_tbl.id = transport_item_tbl.item_id');
        $builder->where('item_group = 0');
        $builder->where('transport_id', $this->request->getGet('vehicle_id'));
        $trans_reslt = $builder->get()->getResult();

        $transData = array();

        if(count($trans_reslt) > 0){
            $iprce = "";
            foreach ($trans_reslt as $tr) 
            {

                $data = $this->amodel->get_student_details('price_tbl', $where = array('item_id' => $tr->item_id));
                foreach ($data as $d) {
                    $iprce = $d->item_price;
                }

                $data = array("id" => $tr->id,"item_id" => $tr->item_id, "quantity" => $tr->quantity, "name" => $tr->item_name, "size" => $tr->item_size, "attribute" => $tr->item_attribute, "price" => $iprce, "RecAccnt" => $tr->account_receivable);
                array_push($transData, $data);
            }

            echo json_encode($transData);
        }
    }

    public function save_admission_details()
    {

        $AdmnValidation = [
            'clevel' => 'required',
            'state' => 'required',
           
        ];

        if($this->validate($AdmnValidation)){
            // $checkIfExists = $this->cmodel->check_ifExist('admission_tbl', $where = array('student_id' => $this->request->getPost('sid')));
            // if($checkIfExists){
            //      echo json_encode(array('status' =>'1','statusDesc' => 'Student With the <b>ID:'.$checkIfExists[0]->id.'</b> Already Exists.'));
            //  }else{
                if($this->request->getPost('hstl')>0){
                
                $hostel= $this->request->getPost('hstl'); 
            }else{
                $hostel=0;
            }
            
            $dateyear=$this->request->getPost('djoin');
          $year=date('Y',strtotime($dateyear));
                $data = [
                    'student_id' => $this->request->getPost('sid'),
                    'academic_year' => $year,
                    'date_joined' => $this->request->getPost('djoin'),
                    'level_id' => $this->request->getPost('clevel'),
                    'class_id' => $this->request->getPost('croom'),
                    'stream_id' => $this->request->getPost('stream'),
                    'admission_type' => $this->request->getPost('state'),
                    'hostel_id' =>  $hostel,
                    'transport' => 'No',
                    'vehicle_id' => 0,
                    'adimit_for' => $this->request->getPost('admit'),
                    'admitted_by ' => $this->request->getPost('header_id'),
                    'admitted_date' => date('Y/m/d H:i:s')
                ];

                $data2 = [
                    'status' => 2
                ];

                $this->amodel->SaveDetails('admission_tbl',$data);
              $this->smodel->update_table_details('students',$where = array('id' => $this->request->getPost('sid')),$data2); 
                  
                  if($this->request->getPost('hstl')>0){
                 $pno = $this->generate_boarding_pno();
          
          $datah = [
                    'student_id' => $this->request->getPost('sid'),
                    'academic_year' => $this->request->getPost('acdy'),
                    'permit_id' => $pno,
                    'admission_type' => $this->request->getPost('admit'),
                    'hostel' => $this->request->getPost('hstl'),
                    'month' => 0,
                    'start_date' => $this->request->getPost('djoin'),
                    'end_date' => $this->request->getPost('end'),
                      'created_date' => $this->request->getPost('djoin'),
                    'created_by' =>$this->request->getPost('header_id'),
                    'status ' => 1
                   
                ];
                 $this->amodel->SaveDetails('boarding_tbl',$datah);
                  }  
    ///             echo json_encode(array('status' =>'0','statusDesc' => 'Student Admitted Successful'));
               $this->save_admission_transaction_items($this->request->getPost('sid'));
           
        }else{
            echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));
        }
    }

    public function generate_boarding_pno()
    {
        $ino = "";
        $tkens = $this->smodel->get_max_id('boarding_tbl','permit_id');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
    public function close_academic_year(){
        for($i=1; $i <= $this->request->getPost('total_admitted'); $i++){
            $data = [
                'status' => 1,
            ];
            $this->smodel->update_table_details('students',$where = array('id' => $this->request->getPost('student_'.$i.'')),$data);

            $datta = [
                'status' => 0,
            ];
            $this->smodel->update_table_details('admission_tbl',$where = array('id' => $this->request->getPost('admission_'.$i.'')),$datta);
        }
        echo 1;
    }

    public function save_admission_transaction_items($student_id){
        $transNo = $this->generate_transaction_no();
        $dateyear=$this->request->getPost('djoin');
          $year=date('Y',strtotime($dateyear));
        $admnTransaction = [
                'trans_type_id' => 1,
                'trans_number' => $transNo,
                'trans_date' => $dateyear,
                'updated_by' => $this->request->getPost('header_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
        // $this->smodel->SaveData('transaction_numbers_tbl',$admnTransaction);
         $trans_id = $this->smodel->SaveData_n_get_id('transaction_numbers_tbl',$admnTransaction);
        $check_class = $this->smodel->gettable_data('company_tbl',$where = array('classification' => 1));
        if(count($check_class)>0){
            $classification = [
                'trans_id' => $trans_id,
               'classification_id' => $this->request->getPost('class_id'),
                
                 ];
        $this->smodel->SaveData('invoice_classification_tbl',$classification);
         }

        $total_cost = 0;
        $invoice_type = [
             'trans_no' => $transNo,
             'transaction_type_id' => 1,
             'invoice_type_id' => 2
         ];
         $itm_trans = $this->smodel->SaveData_n_get_id('invoice_type_transaction',$invoice_type); 

         $itemID = $this->request->getPost('iid');
         $itype ="";
         $amountttl = 0;
         $qtys = 0;
         $id="";
         $discount=0;
        foreach ($itemID as $c) {
            $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c));
            foreach($itm as $i){
                $itype = $i->item_type;
                $item_group = $i->item_group;
            }
            $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $transNo,'trans_type' => 1, 'quantity' => $this->request->getPost('quantity'.$c.''), 'before_qty' => 0,'after_qty' => 0, 'unit_price' => abs($this->request->getPost('price'.$c.'')));

            $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);

            $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
           if($item_group==7){
                 $discount=$this->request->getPost('quantity'.$c.'') * abs($this->request->getPost('price'.$c.''));
            $total_cost-=$this->request->getPost('quantity'.$c.'') * abs($this->request->getPost('price'.$c.''));
            }else{

            $total_cost+=$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.'');
          }
          $amount=0;
          $transactions=0;
            foreach($leger_items as $lg){
                $amount=$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.'');
                $transactions+=$amount;
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                // if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                //     continue;
                // }
                $ledger = [
                     'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $c,
                     'trans_no' => $transNo,
                     'trans_type' => 1,
                     'amount' =>  $this->request->getPost('quantity'.$c.'') * abs($this->request->getPost('price'.$c.'')),
                     'transation_nature' => 1,
                     'name_type_id' => 1,
                     'name_id' => $student_id,
                ];
                $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 
            }
        

        }  
        //for account receivables
        $data = $this->request->getRawInput()['receivable_total_balance'];
        $receivableData = json_decode($data);
        $total= 0;
        $ledgerId = '';
        $i=0;
        foreach ($receivableData as $rd) {
            $i++;
             if($i>1 && $rd->amount==13000){
              continue;
             }else{
            $total += $rd->amount;
            $ledgerId = $rd->account_receivable;
        }
        }

      $paid_amount=0;
        $year=$this->request->getPost('acdy');
    $check_balance= $this->bmodel->get_item_name('student_balance_tbl',$where=array('year'=>$year-1,'student_id'=>$student_id));
             if(count($check_balance)>0){
                        $paid_amount=$check_balance[0]->balance*-1;
                     $total_cost =$total_cost -$paid_amount;
                     }
       $total=$total-$discount;
        $lg_id= $this->bmodel->get_item_name('accounts_tbl',$where=array('account_type_id'=>7));
        if(count($lg_id)>0){
           $ledgerId= $lg_id[0]->id;
        }else{
          $ledgerId=6;   
        }

        $ac_ledger = [
            'ledger_id' => $ledgerId,
            'ledger_type' => 7,
            'trans_no' => $transNo,
            'trans_type' => 1,
            'amount' => $total_cost,
            'transation_nature' => 2,
            'name_type_id' => 1,
            'name_id' => $student_id,
            'balance' => $total_cost,
        ];   
        $this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger); 
       
       // $this->createControl_number($total_cost,$student_id,$transNo);
        $desc='School Fee';
        $dateyear=$this->request->getPost('djoin');
          $year=date('Y',strtotime($dateyear));
        $class=$this->request->getPost('croom');
        $hst=$this->request->getPost('state');
        if($total_cost>0){
            
           $db_id=session()->get('db_id');
               // if($db_id==1 || $db_id==4 || $db_id==5){
        $this->createControl_number_crdb_admission($total_cost,$student_id,$transNo,1,$desc,1,1,$year,$class,$hst);
        // }else{
        //   echo json_encode(array('status' =>'0','statusDesc' => 'Student Admitted Successful'));  
        // }
        
        }
    }

    public function generate_transaction_no()
    {
        $ino = "";
        $tkens = $this->smodel->get_max_invoice('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
       
        return $ino;
        
    }

    public function getToken($tokenUrl) 
    {
        $credentials = array(
            'username' => NMB_USERNAME,
            'password' => NMB_PASSWORD
        );  
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $tokenUrl);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));        
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($credentials));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $output = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
        $tokenOutput = json_decode($output);
        if($error){
            return 'Error: '.$error;
        }else{
            return $tokenOutput;
        }
    }


    public function createControl_number($total,$studentID,$trans_no)
    {
        $student_details = $this->amodel->get_student_details('students',$where = array('id' => $studentID));
        $receipt_request = $this->amodel->get_student_details('payment_request',$where = array('student_id ' => $studentID,'payment_status' => 1));
        $bill = $this->smodel->gettable_billingdata($studentID);
        // $totalAmount = $this->bmodel->get_total_amount($studentID);
        // $amount = $totalAmount[0]->amount;
        $student_name = $student_details[0]->full_name;
        $token_gen = $this->getToken(NMB_URL."auth");

        if(count($receipt_request) == 0){
            if($token_gen->{'status'} == 1){
                $time = date('Y-m-d H:i:s');
                $reference = $this->generate_reference_no();    
                $invoice = array (
                "reference" => $reference,
                "student_name" => $student_name,
                "student_id" => $studentID,
                "amount" => $total,
                "type" => "School Fee",
                "code" => 10,
                "allow_partial" => TRUE,
                "callback_url" => NMB_CALLBACK."receiverPayment",
                "token" => $token_gen->{'token'}
                );
                 file_put_contents('Apifeedback/req' . $reference. '.txt', json_encode($invoice));
                $url = NMB_URL.'invoice_submission';
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($invoice));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                $err = curl_error($ch); 
                curl_close($ch);


                $status = 4;//request notsent
                if ($err) {
                    echo "Error #:" . $err;
                    $status = 5;
                } else {
                    file_put_contents('Apifeedback/nmb_resp.text', $response);
                    $obj2 = json_decode($response,TRUE);
                    $status = $obj2['status'];
                    
                }
                $nmb_data = array(
                    'trans_no' =>  $trans_no,
                    'student_id' =>  $studentID,
                    'reference_no' => $reference,
                    'amount' => $total,
                    'payment_status' => $status,
                    'payment_channel' => '2', //NMB
                    'date_created' => $time,
                    'allow_partial' => 1
                 );
                $this->amodel->SaveDetails('payment_request',$nmb_data);

                $msg = "Kumb No: ".$reference.", Tarehe: ".$time.", Kiasi:TZS ".number_format($total).", Mwanafunzi: ".$student_details[0]->full_name.".".
                 "Tafadhali Fanya Malipo Kupitia NMB.";
                 
               // $this->SMSsender($bill[0]->phone1,$msg,3,$reference);
                // echo ' Student Name '.$student_name.' Reference Number '.$reference .' Created Successful';
                   //************************invoice msg setup*************************************//

        
        $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname.Tafadhali Fanya Malipo Kupitia NMB.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 1,
                    'send_number' => $snn,
                    'massage_date' =>  date('Y-m-d H:i:s'),
                    'send_by' =>$this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans_no
                  
                );
    //  print_r( $smsdata);
$this->smodel->SaveData('message_groups_tbl',$smsdata);

    //  $this->SMSsender($bill[0]->phone1,$msg,1,$studentID,$snn,NULL);
     //   ($dest,$msg,$type,$ref_no,$snn,$show_response=0)
       
        //*************************end msg invoice setup**********************************//    

            }else{
                exit;
            }
        }else{
         if($total != $receipt_request[0]->amount){
            if($token_gen->{'status'} == 1){   
                $invoice = array (
                "reference" => $receipt_request[0]->reference_no ,
                "student_name" => $student_name,
                "student_id" =>$studentID,
                "amount" => $total,
                "type" => "Application Fee",
                "code" => 10,
                "callback_url" => NMB_CALLBACK."receiverPayment",
                "token" => $token_gen->{'token'}
                );
                $url = NMB_URL.'invoice_update';
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($invoice));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                $err = curl_error($ch); 
                curl_close($ch);
                
            $status = 4;//request notsent
            if ($err) {
                echo "Error #:" . $err;
                $status = 5;
            } else {
            $obj2 = json_decode($response, TRUE);
            $status = $obj2->{'status'};
            file_put_contents('Apifeedback/nmb_resp.text', $obj2);
        }
         $nmb_data = array(
            'amount' => $total
         );
         $this->smodel->update_table_details('payment_request',$where = array('id' => $receipt_request[0]->id),$nmb_data); 
       }
       else{
            exit;
        }
        }
      }
    }

    public function generate_reference_no() 
    {
        $ino = "";
        $ref_no =  $this->smodel->get_max_id('payment_request','reference_no');
        if (count($ref_no) > 0) {
            list($mmr_in, $nums) = explode("SAS195", $ref_no[0]->max_id);
            $nwtkn = $nums + 00001;
            $ino = "SAS195".sprintf("%05d", $nwtkn);
        } else {
            $ino ="SAS195". sprintf("%05d", 1);
        }
        return $ino;
    }

     function SMSsender($dest,$msg,$type,$ref_no,$snn,$show_response=0) {
        $tmsg = $this->smodel->gettable_data('message_status_tbl',$where = array('status' => 1,));
                  if(count($tmsg)==0){
                   return;   
                  }
          if($snn==0){
             $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname.Tafadhali Fanya Malipo Kupitia CRDB.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => $type,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i'),
                    'send_by' =>session()->get('user_id'),
                    'messagex' => $messagex,
                    'trans_number' => $this->request->getPost('trno')
                  
                );
                
      
 $this->smodel->SaveData('message_groups_tbl',$smsdata); 
        }
       
             $messag = $this->sytm_model->load_messages_balances();

            $time_sent = time();
             $senderid=constant('SENDER_ID_' . session()->get('db_id'));
                 if($senderid){
              $username=SMS_UNAME;
             $password=SMS_PASSWORD;
                 }else{
                     return;
                 }
        //  if(session()->get('db_id')==1){
        //     $username=SMS_UNAME;
        //      $password=SMS_PASSWORD;
        //      $senderid=SENDER_ID;
        //  }elseif(session()->get('db_id')==4){
        //   $username=SMS_UNAME_USA;
        //      $password=SMS_PASSWORD_USA;
        //      $senderid=SENDER_ID_USA;  
        //  }elseif(session()->get('db_id')==5){
        //   $username=SMS_UNAME_AFYA;
        //      $password=SMS_PASSWORD_AFYA;
        //      $senderid=SENDER_ID_AFYA;  
        //  }elseif(session()->get('db_id')==2){
        //   $username=SMS_UNAME;
        //      $password=SMS_PASSWORD;
        //      $senderid=SENDER_ID_2;  
        //  }elseif(session()->get('db_id')==7){
        //   $username=SMS_UNAME;
        //      $password=SMS_PASSWORD;
        //      $senderid=SENDER_ID_7;  
        //  }elseif(session()->get('db_id')==6){
        //   $username=SMS_UNAME;
        //      $password=SMS_PASSWORD;
        //      $senderid=SENDER_ID_6;  
        //  }
        //  else{
        //     return;
        //  }
             //$destination=str_replace('-', '', $dest);
             // $message=urlencode($msg);
             $destination = preg_replace('/[^0-9]/', '', $dest);
             $message = rawurlencode(trim($msg));
             $senderid = urlencode($senderid);
          $fetch=file_get_contents("https://www.sms.co.tz/api.php?do=sms&username={$username}&password={$password}&senderid={$senderid}&dest={$destination}&msg={$message}");
           
            list($status, $note, $smsid) = explode(',', $fetch);
            if($show_response == 2){
              echo '<th>Message status:</th>';
              echo '<td><i>' . $note . '</i></td>';
            }
            if ($status == 'OK') {
                $msgid = $smsid;
                $snt_status = 1;    // Message sent successfully
                $cost = 45;
                $acc_cost = $cost;
                if($type!=5){
              // echo 'Message sent successfully';
                  }  
            } else {
                $msgid = '';
                $snt_status = 2;    // Message just sent 
                $cost = 45;
                $acc_cost = $cost;
            }

           
                $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
            
           $msg_details = $this->amodel->get_student_details('messages',$where = array('send_no' => $snn,'reference_no' => $ref_no));
             if(count($msg_details)>0){
                 $this->smodel->update_table_details('messages',$where = array('mid' => $msg_details[0]->mid),$tempsmsdata); 
             }else{
                $this->smodel->SaveData('messages',$tempsmsdata); 
             }
          //  echo 'msg saved';

            $balance = ($messag[0]->balance - $acc_cost);

          $smsDt = array(
                'balance' => $balance,
                'created_at' => date('Y/m/d H:i:s')
            );
            $this->sytm_model->update_sms_balance($smsDt, $messag[0]->b_id);
        if($show_response==1){
    echo 'successful sent';
   }

          //  curl_close($curl);
     // echo 'successful sent';
    }

    public function recreate_control_number($total,$studentID,$trans_no)
    {
         $student_details = $this->amodel->get_student_details('students',$where = array('id' => $studentID));
        $receipt_request = $this->amodel->get_student_details('payment_request',$where = array('student_id ' => $studentID,'payment_status' => 1));
        // $bill = $this->amodel->get_student_details('parents_tbl', $where = array('student_id' =>$studentID, 'bill_account' => 1));
        $bill = $this->smodel->gettable_billingdata($studentID);
        // $totalAmount = $this->bmodel->get_total_amount($studentID);
        // $amount = $totalAmount[0]->amount;
        $student_name = $student_details[0]->full_name;
        $token_gen = $this->getToken(NMB_URL."auth");

        if(count($receipt_request) == 0){
            if($token_gen->{'status'} == 1){
                $time = date('Y-m-d H:i:s');
                $reference = $this->generate_reference_no();    
                $invoice = array (
                "reference" => $reference,
                "student_name" => $student_name,
                "student_id" => $studentID,
                "amount" => $total,
                "type" => "School Fee",
                "code" => 10,
                "allow_partial" => TRUE,
                "callback_url" => NMB_CALLBACK."receiverPayment",
                "token" => $token_gen->{'token'}
                );
                 file_put_contents('Apifeedback/req' . $reference. '.txt', json_encode($invoice));
                $url = NMB_URL.'invoice_submission';
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($invoice));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                $err = curl_error($ch); 
                curl_close($ch);


                $status = 4;//request notsent
                if ($err) {
                    echo "Error #:" . $err;
                    $status = 5;
                } else {
                    file_put_contents('Apifeedback/nmb_resp.text', $response);
                    $obj2 = json_decode($response,TRUE);
                    $status = $obj2['status'];
                    
                }
                $nmb_data = array(
                    'trans_no' =>  $trans_no,
                    'student_id' =>  $studentID,
                    'reference_no' => $reference,
                    'amount' => $total,
                    'payment_status' => $status,
                    'payment_channel' => '2', //NMB
                    'date_created' => $time,
                    'allow_partial' => 1
                 );
                $this->amodel->SaveDetails('payment_request',$nmb_data);

                $msg = "Kumb No: ".$reference.", Tarehe: ".$time.", Kiasi:TZS ".number_format($total).", Mwanafunzi: ".$student_details[0]->full_name.".".
                 "Tafadhali Fanya Malipo Kupitia NMB.";
                 
                //$this->SMSsender($bill[0]->phone1,$msg,3,$reference);
                // echo ' Student Name '.$student_name.' Reference Number '.$reference .' Created Successful';
            echo "$reference";
            }
        }
    }

    public function view_admissions_details($id)
    {
        $data = array(
           'admn' => $this->amodel->get_student_details('admission_tbl',$where = array('id' =>$id, 'status' => 1))
        );
        return view('student/forms/view_admission',$data);
    }

    public function save_transferDetails()
    {
        $admID = $this->request->getPost('adm_id');
        $stID = $this->request->getPost('student_id');

        $data = [
            'student_id' => $stID,
            'transfered_to' => ucfirst($this->request->getPost('transfer')),
            'reason' => ucfirst($this->request->getPost('reason'))
        ];

        $this->smodel->SaveData('transfered_students',$data);

        $adm_status = [
            'status' => 2
        ];
        $this->smodel->update_table_details('admission_tbl',$where = array('id' => $admID),$adm_status);

        $_status = [
            'status' => 3
        ];
        $this->smodel->update_table_details('students',$where = array('id' => $stID),$_status);

         echo json_encode(array('status' =>'0','statusDesc' => 'Student transfered Successful'));
    }


    // public function findAge($date){

    //     $bday = new DateTime($date); 
    //     $today = new Datetime(date('Y/m/d'));
    //     $diff = $today->diff($bday);
    //     $age=0;
    //     if($diff->y >0){
           
    //         $age = $diff->y;
    //     }
    //     return $age;
    // }

    public function checkAgeStatus($age)
    { 
        if($age <3){
            return '<div class="alert">message</div>';
        }else if($age > 3 && $age < 5){
            return "<div class='alert'>message</div>";
        }
    }

public function save_newinvoice_transaction_items($student_id){
     $itemID = $this->request->getPost('iid');
    $transport=0;
    foreach ($itemID as $c) {
            $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c,'item_group'=>6));
            if(count($itm)>0){
                $transport=1;
            }
        }
        if($transport==1){
              echo json_encode(array('status' =>0,'statusDesc' => 'Seems like you are trying to create a transport invoice without a transport permit! If this is the case, please use the <a href="'.base_url().'/transport_setup">Transport module </a>instead and the invoice will be created for you automatically <a href="gotomenu"></a>'));
        }else{
        $transNo = $this->generate_transaction_no();
        $admnTransaction = [
                'trans_type_id' => 1,
                'trans_number' => $transNo,
                'trans_date' => $this->request->getPost('invoice_date'),
                'updated_by' => $this->request->getPost('header_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
      //  $this->smodel->SaveData('transaction_numbers_tbl',$admnTransaction
      
      $trans_id = $this->smodel->SaveData_n_get_id('transaction_numbers_tbl',$admnTransaction);
        $check_class = $this->smodel->gettable_data('company_tbl',$where = array('classification' => 1));
        if(count($check_class)>0){
            $classification = [
                'trans_id' => $trans_id,
               'classification_id' => $this->request->getPost('class_id'),
                
                 ];
        $this->smodel->SaveData('invoice_classification_tbl',$classification);
         }


        $total_cost = 0;
        $invoice_type = [
             'trans_no' => $transNo,
             'transaction_type_id' => 1,
             'invoice_type_id' => $this->request->getPost('admission_type')
         ];
          $itm_trans = $this->smodel->SaveData_n_get_id('invoice_type_transaction',$invoice_type); 

         $itemID = $this->request->getPost('iid');
         $itype ="";
         $amountttl = 0;
         $qtys = 0;
         $id="";
         $amount=0;
        foreach ($itemID as $c) {
            $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c));
            foreach($itm as $i){
                $itype = $i->item_type;
            }

            $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $transNo,'trans_type' => 1, 'quantity' => $this->request->getPost('quantity'.$c.''), 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $this->request->getPost('price'.$c.''));

            $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);

            $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
            $total_cost+=$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.'');
            
            foreach($leger_items as $lg){
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                // if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                //     continue;
                // }
                $ledger = [
                    'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $this->request->getPost('admission_type'),
                     'trans_no' => $transNo,
                     'trans_type' => 1,
                     'amount' =>  $this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.''),
                     'transation_nature' => 1,
                     'name_type_id' => $this->request->getPost('customer_type'),
                     'name_id' => $student_id,
                ];
                 $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 

            }
        $amount+=$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.'');
           }  
        //for account receivables
        // $data = $this->request->getRawInput()['receivable_total_balance'];
        // $receivableData = json_decode($data);

        // foreach ($receivableData as $rd) {
         $s= $this->request->getPost('payer_id');
        list($name_type,$payer_id) = explode('_',$s);
            $ac_ledger = [
                'ledger_id' => $this->request->getPost('account'),
                'ledger_type' => 7,
                'trans_item' => $this->request->getPost('admission_type'),
                'trans_no' => $transNo,
                'trans_type' => 1,
                'amount' =>  $amount,
                'transation_nature' => 2,
                'name_type_id' => $this->request->getPost('customer_type'),
                'name_id' => $student_id,
                'balance' => $amount,
            ];   
            $this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger); 
            $invoiceType=$this->request->getPost('admission_type');
          $desc = constant('msgDESC' . $invoiceType);
         //projects transactions added here-------
        if($this->request->getPost('project')>0){
             $pname = $this->smodel->gettable_data('projects_tbl',$where = array('id' => $this->request->getPost('project')));
            $desc=$pname[0]->project_name;
            
              $proje = [
                'project_id' => $this->request->getPost('project'),
                'trans_type' => 1,
                'trans_numba' => $transNo,
                'student_id' => $student_id,
                'amount' => $amount,
                
        ];  
        $this->smodel->SaveData('project_transaction_tbl',$proje);
            }
            //projects transactions ended here-------  
      
    //       echo json_encode(array('status' =>1,'statusDesc' => 'New invoice Created Successfully'));
         
         if($this->request->getPost('admission_type')==3 || $this->request->getPost('admission_type')==7){
            $al=0;
          }else{
            $al=1;
          }
          $customer_type=$this->request->getPost('customer_type');
          if($total_cost>0){
                $db_id=session()->get('db_id');
               // if($db_id==1 || $db_id==4 || $db_id==2){
          $this->createControl_number_crdb($total_cost,$student_id,$transNo,1,$desc,$al,$customer_type);
                // }else{
                //   echo json_encode(array('status' =>1,'statusDesc' => 'Invoice Created Successful.')); 
                // }
          }

    }
}
    function createControl_number_crdb($total_cost,$student_id,$transNo,$type,$des,$alw,$customer_type){
      
        if($alw==0){
            $a='FIXED';
        }else{
           $a='FLEXIBLE'; 
        }
       
        if($customer_type==6){
          $student_details = $this->smodel->gettable_data('other_students_tbl',$where = array('id' => $student_id));
        }else{
         $student_details = $this->smodel->gettable_data('students',$where = array('id' => $student_id));   
        }
         //$desc=$total_cost.' is '.$des.' and '.$charge.' is bank charges';
        
         $db_id=$this->request->getPost('db_id');


         $db='default';
          $bank_requirements = $this->payment_model->get_item_name('payments_requirements_tbl',$where = array('db_id' => $db_id, 'status'=>1),$db);  
          if(count($bank_requirements)>0){
            $charge=$bank_requirements[0]->charges;
    if($type==3){
            $curl=base_url().''.$bank_requirements[0]->deposit_callbackUrl;
         }elseif($customer_type==6){
            $curl=base_url().''.$bank_requirements[0]->aliens_callbackUrl;
         }else{
           $curl=base_url().''.$bank_requirements[0]->invoice_callbackUrl;
         }

         $facility_id=$bank_requirements[0]->facility_id;
         $payment_type=$bank_requirements[0]->payment_type;
         $prefix=$bank_requirements[0]->prefix;
         $crdb_url=CRDB_URL_1;
         $desc=$des.' : '.$total_cost.' and Bank charges : '.$charge;

          }
   elseif($db_id==5)
     {
             $time=date('Y-m-d H:i:s'); 
            $msg = "Kumb No: ---, Tarehe: ".$time.", Kiasi:TZS ".number_format($total_cost).", Mwanafunzi: ".$student_details[0]->full_name.". ".$des.".";
              $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname.(description)";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => $type,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>$this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $transNo
                  
                );
      
 //$this->smodel->SaveData('message_groups_tbl',$smsdata);

     // $this->SMSsender($phone,$msg,$type,$student_id,$snn,NULL);
      echo json_encode(array('status' =>1,'statusDesc' => 'save successfully.'));
    return;
   }
   else{
    echo json_encode(array('status' =>1,'statusDesc' => 'saved successfully.'));
    return;
   }

          $data=array(
            'name' =>$student_details[0]->full_name,
            'receipt_no' => $transNo,
            'amount' => $total_cost+$charge,
            'currency' => 'TZS',
            'payment_desc' => $desc,
            'visit_no'=>$student_id,
            'file_no'=>$student_id,
            'payment_channel' => 1,
            'facility_id' => $facility_id,
            'payment_type' => $payment_type,
            'prefix' =>$prefix,
            'call_back_url' => $curl,
            'allow_partial' => $a

        );

        //  print_r(json_encode($data));
  file_put_contents('Apifeedback/req_crdb' . $transNo. '.txt', json_encode($data));
  //return $data;
    $url = $crdb_url."createPayment";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
            
                $response = curl_exec($ch);
                //echo 'response is '.$response;
                $err = curl_error($ch); 
                curl_close($ch);
               echo 'error is '.$err;
                 if ($err) {
                    //echo "Error #:" . $err;
                    $status = 5;
                    $reference=0;
                     $time=date('Y-m-d H:i:s');

                     echo json_encode(array('status' =>1,'statusDesc' => 'Admited but Control Number Not Created Successful.'));
                } else {
                   
                    $obj2 = json_decode($response,TRUE);
                    if($obj2['status']=='success'){
                      $status = 1;
                    }else{
                       $status = 2;
                    }
                    $time=$obj2['date_created'];
                    
                    $reference= $obj2['paymentReference'];
                
                $crdb_data = array(
                    'trans_no' =>  $transNo,
                    'student_id' =>  $student_id,
                    'reference_no' => $reference,
                    'amount' => $total_cost,
                    'charges' => $charge,
                    'payment_status' => 0,
                    'payment_channel' => 3, //CRDB
                    'date_created' => $time,
                    'allow_partial' => $alw,
                    'trans_type' => $type
                 );
            //print_r($crdb_data);
     $this->amodel->SaveDetails('payment_request',$crdb_data);

          $msg = "Kumb No: ".$reference.", Tarehe: ".$time.", Kiasi:TZS ".number_format($total_cost).", Mwanafunzi: ".$student_details[0]->full_name.". ".$des.".";
   //*******invoice msg setup*************************************//
           $phone=0;
                 if($customer_type==6){
                
                $bill = $this->smodel->gettable_data('other_students_tbl',$where = array('id' => $student_id));
                
                 if(count($bill)>0){
                $phone=$bill[0]->phone;
                  }
                 }else{
                $bill = $this->smodel->gettable_billingdata($student_id);
                if(count($bill)>0){
                $phone=$bill[0]->phone1;
                  }
                 }
        
        $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname.Tafadhali Fanya Malipo Kupitia CRDB.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => $type,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>$this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $transNo
                  
                );
    
          $tmsg=constant('TMSG' . session()->get('db_id'));
            
         
       $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
        $this->smodel->SaveData('message_groups_tbl',$smsdata);
          $this->SMSsender($cleanPhone,$msg,$type,$student_id,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
   // log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
                  
  
      
 
    
      $student_name=$student_details[0]->full_name;
        echo json_encode(array('status' =>1,'statusDesc' => 'Student '.$student_name.' Control Number <b>'.$reference.'</b> Created Successful.'));
  }
    }
    
   function createControl_number_crdb_admission($total_cost,$student_id,$transNo,$type,$des,$alw,$customer_type,$year,$class,$hst){
        if($alw==0){
            $a='FIXED';
        }else{
           $a='FLEXIBLE'; 
        }
       
        if($customer_type==6){
          $student_details = $this->smodel->gettable_data('other_students_tbl',$where = array('id' => $student_id));
        }else{
         $student_details = $this->smodel->gettable_data('students',$where = array('id' => $student_id));   
        }
         //$desc=$total_cost.' is '.$des.' and '.$charge.' is bank charges';
       
         $db_id=$this->request->getPost('db_id');
   $db='default';
          $bank_requirements = $this->payment_model->get_item_name('payments_requirements_tbl',$where = array('db_id' => $db_id, 'status'=>1),$db);  
          if(count($bank_requirements)>0){
            $charge=$bank_requirements[0]->charges;
    if($type==3){
            $curl=base_url().''.$bank_requirements[0]->deposit_callbackUrl;
         }elseif($customer_type==6){
            $curl=base_url().''.$bank_requirements[0]->aliens_callbackUrl;
         }else{
           $curl=base_url().''.$bank_requirements[0]->invoice_callbackUrl;
         }

         $facility_id=$bank_requirements[0]->facility_id;
         $payment_type=$bank_requirements[0]->payment_type;
         $prefix=$bank_requirements[0]->prefix;
         $crdb_url=CRDB_URL_1;
         $desc=$des.' : '.$total_cost.' and Bank charges : '.$charge;

          }
elseif($db_id==5)
     {
             $time=date('Y-m-d H:i:s'); 
            $msg = "Kumb No: ---, Tarehe: ".$time.", Kiasi:TZS ".number_format($total_cost).", Mwanafunzi: ".$student_details[0]->full_name.".". "Ada.";
              $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname. Ada.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => $type,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>$this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $transNo
                  
                );
      
 $this->smodel->SaveData('message_groups_tbl',$smsdata);
 $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
          $this->SMSsender($cleanPhone,$msg,$type,$student_id,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
                  
      echo json_encode(array('status' =>1,'statusDesc' => 'save successfully.'));
    return;
   }
else{
    echo json_encode(array('status' =>1,'statusDesc' => 'saved successfully.'));
    return;
   }
          $data=array(
            'name' =>$student_details[0]->full_name,
            'receipt_no' => $transNo,
            'amount' => $total_cost+$charge,
            'currency' => 'TZS',
            'payment_desc' => $desc,
            'visit_no'=>$student_id,
            'file_no'=>$student_id,
            'payment_channel' => 1,
            'facility_id' => $facility_id,
            'payment_type' => $payment_type,
            'prefix' => $prefix,
            'call_back_url' => $curl,
            'allow_partial' => $a

        );

          //print_r(json_encode($data));
  file_put_contents('Apifeedback/req_crdb' . $transNo. '.txt', json_encode($data));
    $url = $crdb_url."createPayment";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
           
                $response = curl_exec($ch);
              // echo 'response->'.$response;
                $err = curl_error($ch); 
                curl_close($ch);

                 if ($err) {
                    //echo "Error #:" . $err;
                    $status = 5;
                    $reference=0;
                     $time=date('Y-m-d H:i:s');

                     echo json_encode(array('status' =>1,'statusDesc' => ' Control Number Not Created Successful.'));
                } else {
                   
                    $obj2 = json_decode($response,TRUE);
                    if($obj2['status']=='success'){
                      $status = 1;
                    }else{
                       $status = 2;
                    }
                    $time=$obj2['date_created'];
                    
                    $reference= $obj2['paymentReference'];
                
                $crdb_data = array(
                    'trans_no' =>  $transNo,
                    'student_id' =>  $student_id,
                    'reference_no' => $reference,
                    'amount' => $total_cost,
                    'charges' => $charge,
                    'payment_status' => 0,
                    'payment_channel' => 3, //CRDB
                    'date_created' => $time,
                    'allow_partial' => $alw,
                    'trans_type' => $type,
                     'academic_year' => $year
                 );
            //print_r($crdb_data);
     $this->amodel->SaveDetails('payment_request',$crdb_data);

     //mmmmmmmmmmmmmm installments placed here mmmmmmmm//
      
        $semister = $this->smodel->gettable_data('school_terms_tbl',$where = array('academic_year' => $year));
        
        $time=date('Y-m-d H:i:s'); 
            $msg = "Kumb No: ".$reference.", Tarehe: ".$time.", Kiasi:TZS ".number_format($total_cost).", Mwanafunzi: ".$student_details[0]->full_name.".". "Ada ".$year."";
            
       if(count($semister)>0){
       // $msg=$this->generate_installment_msg($transNo,$year,$class,$hst,$reference,$student_id);  
    }else{
         $time=date('Y-m-d H:i:s'); 
            $msg = "Kumb No: ".$reference.", Tarehe: ".$time.", Kiasi:TZS ".number_format($total_cost).", Mwanafunzi: ".$student_details[0]->full_name.".". "Ada ".$year."";
       
    }
       
   //*******invoice msg setup*************************************//
                 $phone=0;
                 if($customer_type==6){
                
                $bill = $this->smodel->gettable_data('other_students_tbl',$where = array('id' => $student_id));
                
                 if(count($bill)>0){
                $phone=$bill[0]->phone;
                  }
                 }else{
                $bill = $this->smodel->gettable_billingdata($student_id);
                if(count($bill)>0){
                $phone=$bill[0]->phone1;
                  }
                 }
        
        
        $messagex="#first_name, Kumb No: xxx, 1st - nnn/- kabla ya Y-m-d, 2nd - nnn/- kabla ya Y-m-d, 3rd - nnn/- kabla ya Y-m-d. Ada Y.";
      $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => $type,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>$this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $transNo
                  
                );
      
 $this->smodel->SaveData('message_groups_tbl',$smsdata);

 
             $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
               $this->SMSsender($cleanPhone,$msg,1,$student_id,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
                  }
     
    //****end msg invoice setup**********************************// 
    
       $student_name=$student_details[0]->full_name;
        echo json_encode(array('status' =>1,'statusDesc' => 'Student '.$student_name.' Control Number <b>'.$reference.'</b> Created Successful.'));
  }

 public function Remove_invoicedItem()
    {


       $item = $this->request->getVar('item'); 
       $student = $this->request->getVar('student'); 
       $transNo = $this->request->getVar('transNo'); 
       $cID = $this->request->getVar('class'); 
       $hID = $this->request->getVar('hostel'); 
      $price = $this->request->getVar('price');  



      $item_trans = $this->amodel->delete_itemTransaction_data($item,$transNo,1);

       $ledgr = $this->smodel->gettable_data('items_ledgers_tbl', $where = array('item_id' => $item));

       $items = $this->smodel->gettable_data('items_tbl', $where = array('id' => $ledgr[0]->item_id));
        if($items[0]->item_group==7){
            
             $ttl = $price*-1;
         }else{
           $ttl = $price; 
         }

       $itemsledger = $this->smodel->gettable_data('ledger_transaction_tbl', 
            $where = array('ledger_type'=>7, 'trans_no'=>$transNo,'trans_type'=>1)
        );

        //break();
        //die();
        //print_r($itemsledger);

        $balance = count($itemsledger)>0?$itemsledger[0]->balance:0;
        $lAmount = count($itemsledger)>0?$itemsledger[0]->amount:0;

        $ids = count($itemsledger)>0?$itemsledger[0]->id:0;
       $data = [
            'amount' => ($lAmount - $ttl),
            'balance' => ($balance - $ttl),
       ];



       $this->smodel->update_table_details('ledger_transaction_tbl', $where = array('id' => $ids),$data);
       
       // $this->smodel->deletetable_data('ledger_transaction_tbl', $where = array('id' => $i_ledger[0]->id));


        $this->amodel->delete_ledger_item($item,$student,$transNo,1);


        //$this->smodel->update_table_details('payment_request', $where = array('student_id' => $student, 'trans_no' => $transNo),$data2);

         // //echo json_encode(array('status' =>'0','statusDesc' => 'Item Removed Successful'));

    }

    function update_invoice()
    {
       $no = $this->request->getVar('trans');
        $id = $this->request->getVar('sID');
        $blance = 0;
        $time = date('Y-m-d H:i:s');
        $ref1 = "";
        $total = 0;
         
         if($this->request->getVar('invoice_type')==7){
            $data=[
               'invoice_type_id'=>$this->request->getVar('invoice_type')
            ];
            $this->smodel->update_table_details('invoice_type_transaction', $where = array('transaction_type_id' => 1, 'trans_no' => $no),$data);

             $proje = [
                'project_id' => $this->request->getPost('pid'),
                'trans_type' => 1,
                'trans_numba' => $no,
                'student_id' => $id,
                'amount' => $this->request->getPost('total'),
                
        ];  
       // print_r($proje);

         $check_p = $this->smodel->gettable_data('project_transaction_tbl', $where = array('student_id' => $id, 'trans_numba' => $no));
         if(count($check_p)>0){
           $this->smodel->update_table_details('project_transaction_tbl', $where = array('student_id' => $id, 'trans_numba' => $no),$proje);  
       }else{
        $this->smodel->SaveData('project_transaction_tbl',$proje);
          }
             
         }else{
            $data=[
               'invoice_type_id'=>$this->request->getVar('invoice_type')
            ];
            $this->smodel->update_table_details('invoice_type_transaction', $where = array('transaction_type_id' => 1, 'trans_no' => $no),$data);
         }
         echo json_encode(array('status' =>'0','statusDesc' => 'Invoice Updated Successful'));
             
    }

    function add_invoice_item()
    {
        $no = $this->request->getVar('trans');
        $id = $this->request->getVar('id');
        $qty = $this->request->getVar('quantity');
        $item = $this->request->getVar('item');
        $itype='';

        $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $item));
        foreach($itm as $i){
            $itype = $i->item_type;
            $item_group=$i->item_group;

            $iprice = $this->smodel->gettable_data('price_tbl', $where = array('item_id' => $i->id));
            $price = $iprice[0]->item_price;
        }
        
        

        $iData = array('item_id' => $item, 'item_type_id'=>$itype,'trans_number' => $no,'trans_type' => 1, 'quantity' => $qty, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $price);

        $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$iData);

        $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $item)); 
        $total_cost=0;
            $total_cost =$qty * $price;
             if($item_group==7){
             $nature=2;
             $qty=$qty*-1;
         }else{
           $nature=1;  
         }
          
            foreach($leger_items as $lg){
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                // if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                //     continue;
                // }
                $ledger = [
                     'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $item,
                     'trans_no' => $no,
                     'trans_type' => 1,
                     'amount' =>  $total_cost,
                     'transation_nature' => $nature,
                     'name_type_id' => 1,
                     'name_id' => $id,
                ];
                $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 
            }
                if($item_group==7){
            $total_cost=$total_cost*-1;
         }else{
             
         }

        $checkdata = $this->smodel->gettable_data('ledger_transaction_tbl', $where = array('name_id' => $id, 'trans_no' => $no,'trans_type' =>1));
        if(count($checkdata) > 0){
            
            $this->amodel->update_ledger_balance($total_cost,$id,$no);

        }else{
            
        }

                 
        echo json_encode(array("data"=>$this->amodel->get_transdetails($no,1),"ledger"=>$this->amodel->ledger_type($no,1)));
    }
    public function admission_dash($year){
          $data=array(
             'year'=>$year
          );
         return view('templates/header')
            .view('student/admission_dash_view',$data)
            .view('templates/footer');
    }
    
     public function save_deposit_transaction_items($student_id){
        $transNo = $this->generate_transaction_deposit();
        $desc="";
        $type=$this->request->getPost('deposit_type');
        $desc = constant('msgDESC' . $type);
        //echo $this->request->getPost('header_id');
        if($this->request->getPost('status')==2){
            $admnTransaction = [
                'trans_type_id' => 3,
                'trans_number' => $transNo,
                'trans_date' => $this->request->getPost('invoice_date'),
                'status' => 2,
                 'trans_desc' => 2024,
                'updated_by' =>  $this->request->getPost('header_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
        }else{
          $admnTransaction = [
                'trans_type_id' => 3,
                'trans_number' => $transNo,
                'trans_date' => $this->request->getPost('invoice_date'),
                'updated_by' =>  $this->request->getPost('header_id'),
               'trans_desc' => 2024,
                'updated_date' => date('Y-m-d H:i:s')
        ];  
        }
        
        $this->smodel->SaveData('transaction_numbers_tbl',$admnTransaction);
//       print_r($admnTransaction);

        $total_cost = 0;
        $invoice_type = [
             'trans_no' => $transNo,
             'transaction_type_id' => 3,
             'invoice_type_id' => $this->request->getPost('deposit_type')
         ];
         $itm_trans = $this->smodel->SaveData_n_get_id('invoice_type_transaction',$invoice_type); 

         $itemID = $this->request->getPost('iid');
         $itype ="";
         $amountttl = 0;
         $qtys = 0;
         $id="";
         $amount=0;
        foreach ($itemID as $c) {
            $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c));
            foreach($itm as $i){
                $itype = $i->item_type;
            }

            $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $transNo,'trans_type' => 3, 'quantity' => 1, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $this->request->getPost('prco'.$c.''));

           $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);
 //           print_r($itemData);

            $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
            $total_cost+=$this->request->getPost('prco'.$c.'');
            
            foreach($leger_items as $lg){
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                // if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                //     continue;
                // }
                $ledger = [
                    'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_no' => $transNo,
                     'trans_type' => 3,
                     'amount' => $this->request->getPost('prco'.$c.''),
                     'transation_nature' => 1,
                     'name_type_id' => 1,
                     'name_id' => $student_id,
                ];
                $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 
   //                print_r($ledger);

            }
        $amount+=$this->request->getPost('prco'.$c.'');
           }  
          $i=0;
       $s= $this->request->getPost('payer_id');
//projects transactions added here-------
        if($this->request->getPost('project')>0){
             $nm = $this->smodel->gettable_data('projects_tbl',$where = array('id' => $this->request->getPost('project')));
            $desc=$nm[0]->project_name;
            
              $proje = [
                'project_id' => $this->request->getPost('project'),
                'trans_type' => 3,
                'trans_numba' => $transNo,
                'student_id' => $student_id,
                'amount' => $amount,
                
        ];  
        $this->smodel->SaveData('project_transaction_tbl',$proje);
            }
            //projects transactions ended here-------
             //mmmmmmmmmmmmmmmmmm start for reversal receipts mmmmmmmmmmmmmmmmmmmm;
        $total_amount = 0;
         list($name_type,$payer_id) = explode('_',$s);
         
          $legers_acc = $this->smodel->gettable_data('accounts_tbl',$where = array('account_type_id' => 9,'id !='=>21));
         if(count($legers_acc)>0){
         $ledgerId=$legers_acc[0]->id;
         }else{
           $legers_acc = $this->smodel->gettable_data('accounts_tbl',$where = array('account_type_id' => 4)); 
                    $ledgerId=$legers_acc[0]->id;
         }
         if($this->request->getPost('status')==2){
            $dbname= $dbname=session()->get('db_name');
            $Bank_leger=$this->payment_model->get_account_details('accounts_tbl','account_name',$dbname);
            
            $ac_ledger = [
                'ledger_id' => $Bank_leger[0]->id,
                'ledger_type' => $Bank_leger[0]->account_type_id,
                'trans_no' => $transNo,
                'trans_type' => 3,
                'amount' =>  $amount,
                'transation_nature' => 2,
                'name_type_id' => $this->request->getPost('paid_by'),
                'name_id' => $payer_id,
                'balance' => $amount
            ];   
           $this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger);

         }else{
           foreach($this->request->getPost('pay_ledger') as $l){
        $total_amount = $this->request->getPost('amount'.$l);
        $Bank_leger = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $l)); 
     

        // foreach ($receivableData as $rd) {
            $ac_ledger = [
                'ledger_id' => $Bank_leger[0]->id,
                'ledger_type' => $Bank_leger[0]->account_type_id,
                'trans_no' => $transNo,
                'trans_type' => 3,
                'amount' =>  $total_amount,
                'transation_nature' => 2,
                'name_type_id' => $this->request->getPost('paid_by'),
                'name_id' => $payer_id,
                'balance' => $total_amount,
            ];   
           $this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger); 
   //         print_r($ac_ledger);
   
   
    if($this->request->getPost('transfer'.$l)>0){

        $revn = $this->generate_reversal_no();
        $reverse_amount=$this->request->getPost('transfer'.$l);
        $reversed_receipt=$this->request->getPost('receipt_number'.$l);
      $tran = [
              'trans_type_id' => 7,
              'trans_number' => $revn,
              'trans_date' => $this->request->getPost('invoice_date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s')
                 ];
      $this->smodel->SaveData('transaction_numbers_tbl',$tran);

          $old_inv = $this->smodel->gettable_data('transactions_relation',$where = array('receipt_trans_no' => $this->request->getPost('receipt_number'.$l))); 
          $o_inv = $this->smodel->gettable_data('ledger_transaction_tbl',$where = array('transation_nature' =>2,'trans_no'=>$old_inv[0]->invoice_trans_no,'trans_type'=>1,'ledger_type'=>7)); 

             $old_student_id=$o_inv[0]->name_id;
             $remain=$o_inv[0]->balance + $this->request->getPost('transfer'.$l);
             $des="School Fee";
       // $this->upadate_control($remain,$old_student_id,$o_inv[0]->trans_no,$des);
       
         $balance = array(
            'balance' => $o_inv[0]->balance+$this->request->getPost('transfer'.$l)
                     );
            $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('id' => $o_inv[0]->id),$balance);

            $rel = [
                'old_receipt_number' => $this->request->getPost('receipt_number'.$l),
                'trans_type' => 3,
                'new_receipt_number' => $transNo,
                'reversal_number' => $revn,
                'amount_transfered' =>  $this->request->getPost('transfer'.$l),
                'reasons' =>  $this->request->getPost('reason'.$l),
                'date_created' => date('Y-m-d H:i:s'),
                     ];
            $this->smodel->SaveData('receipt_transfer_tbl',$rel);

            $old_receipt = $this->smodel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $this->request->getPost('receipt_number'.$l),'trans_type'=>2));
            $r=0; 
            foreach($old_receipt as $old){
                $r++;
                if($r>2){
                   break;
                }else{
                if($old->ledger_type==7){
            $Bl = [
               'ledger_id' => $old->ledger_id,
               'ledger_type' => $old->ledger_type,
               'trans_no' => $revn,
               'trans_type' => 7,
               'amount' => $this->request->getPost('transfer'.$l),
               'transation_nature' =>2,
               'name_type_id' => $old->name_type_id,
               'name_id' => $old->name_id,
           ];

           $this->smodel->SaveData('ledger_transaction_tbl',$Bl);
         }

          if($old->ledger_type==9){
            $Bl = [
               'ledger_id' => $old->ledger_id,
               'ledger_type' => $old->ledger_type,
               'trans_no' => $revn,
               'trans_type' => 7,
               'amount' => $this->request->getPost('transfer'.$l),
               'transation_nature' =>1,
               'name_type_id' => $old->name_type_id,
               'name_id' => $old->name_id,
           ];

           $this->smodel->SaveData('ledger_transaction_tbl',$Bl);
         }
        }
       }

    $rev_st_details = $this->smodel->gettable_data('students',$where = array('id' => $old_student_id));
 $revstudent_parent = $this->smodel->gettable_data('parents_students_tbl',$where = array('student_id' => $old_student_id));
 if(count($revstudent_parent) > 0){
  $reves_parent_details = $this->smodel->gettable_data('parents_tbl',$where = array('id' => $revstudent_parent[0]->parent_id));
               if(count($reves_parent_details) > 0){
                    $revphone = $reves_parent_details[0]->phone1;
                }
           }
     $msg = $rev_st_details[0]->first_name.", malipo ya ".$reverse_amount." kutoka Risiti ".$reversed_receipt." yamefutwa kupitia Reversal namba ".$revn.". Ukihitaji maelezo zaidi piga  0755266243.";//temporary

 $messagex="first_name, malipo ya xxx kutoka Risiti xxx yamefutwa kupitia Reversal namba x. Ukihitaji maelezo zaidi piga xxxxxx.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 9,
                    'send_number' => $snn,
                    'massage_date' =>  date('Y-m-d H:i:s'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $revn
                  
                );
    //  message disabled here;
      if($revphone !=""){
$this->smodel->SaveData('message_groups_tbl',$smsdata);

   
                   $cleanPhone = sanitize_phone($revphone);
if ($cleanPhone) {
    try {
                  $this->SMSsender($cleanPhone,$msg,9,$old_student_id,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
      
     }
 }
//mmmmmmmmmmmmmmmmmm end for reversal receipts mmmmmmmmmmmmmmmmmmmm
//mmmmmmmmmmmmmmmmmm start for reversal deposit mmmmmmmmmmmmmmmmmmmm

 if($this->request->getPost('reverse_deposit'.$l)>0){

    $revn = $this->generate_reversal_no();
        $reverse_amount=$this->request->getPost('reverse_deposit'.$l);
        $reversed_receipt=$this->request->getPost('deposit_number'.$l);
      $tran = [
              'trans_type_id' => 7,
              'trans_number' => $revn,
              'trans_date' => $this->request->getPost('invoice_date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s')
                 ];
      $this->smodel->SaveData('transaction_numbers_tbl',$tran);

   $rel = [
                'old_deposit_number' => $this->request->getPost('deposit_number'.$l),
                'new_deposit_number' => $transNo,
                'reversal_number' => $revn,
                'amount_reversed' =>  $this->request->getPost('reverse_deposit'.$l),
                'reasons' =>  $this->request->getPost('reason'.$l),
                'date_created' => date('Y-m-d H:i:s'),
                     ];
            $this->smodel->SaveData('reverse_deposit_tbl',$rel);

             $old_deposit = $this->smodel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $this->request->getPost('deposit_number'.$l),'trans_type'=>3));
            $r=0; 
            foreach($old_deposit as $old){
                $r++;
                if($r>2){
                   break;
                }else{
                if($old->ledger_type!=9){
            $Bl = [
               'ledger_id' => $old->ledger_id,
               'ledger_type' => $old->ledger_type,
               'trans_no' => $revn,
               'trans_type' => 7,
               'amount' => $this->request->getPost('reverse_deposit'.$l),
               'transation_nature' =>2,
               'name_type_id' => $old->name_type_id,
               'name_id' => $old->name_id,
           ];

           $this->smodel->SaveData('ledger_transaction_tbl',$Bl);
         }

          if($old->ledger_type==9){
            $Bl = [
               'ledger_id' => $old->ledger_id,
               'ledger_type' => $old->ledger_type,
               'trans_no' => $revn,
               'trans_type' => 7,
               'amount' => $this->request->getPost('reverse_deposit'.$l),
               'transation_nature' =>1,
               'name_type_id' => $old->name_type_id,
               'name_id' => $old->name_id,
           ];

           $this->smodel->SaveData('ledger_transaction_tbl',$Bl);
         }
        }
       }

 }
//mmmmmmmmmmmmmmmmmm end for reversal deposit mmmmmmmmmmmmmmmmmmmm
   
        }
    }
        //****************depost message*************************************//
        $student_details = $this->amodel->get_student_details('students',$where = array('id' => $student_id));
 $bill = $this->smodel->gettable_billingdata($student_id);

         $phone=$bill[0]->phone1;
            if($phone != ""){
       $msg = "Mzazi wa ".$student_details[0]->first_name."; Malipo ya TZS ".number_format($total_amount)." yamekamilika. Deposit namba ".$transNo." tar ".date('d/m/Y H:i:s').".";
        $messagex="Mzazi wa FirstName; Malipo ya TZS xxxxx yamekamilika. Deposit namba xxxx tar xx/xx/xx xx:xx.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 5,
                    'send_number' => $snn,
                    'massage_date' =>  date('Y-m-d H:i:s'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $transNo
                  
                );
    //  print_r( $smsdata);
       if($this->request->getPost('status')==2){
       }else{
$this->smodel->SaveData('message_groups_tbl',$smsdata);

     
                         $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
                   $this->SMSsender($cleanPhone,$msg,5,$student_id,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
     
       }

       }
        //***************end*depost message*************************************//
          if($this->request->getPost('status')==2){
           
            
            $this->createControl_number_crdb($amount,$student_id,$transNo,3,$desc,0,1);
          }else{
            echo json_encode(array('status' =>'0','statusDesc' => 'New Deposit Created Successfully'));
          }
        
       
    }
    
    public function generate_transaction_deposit()
    {
        $ino = "";
        $num=array();
        $tkens = $this->smodel->get_max_deposit('transaction_numbers_tbl','trans_number');
        
     
        $j=count($tkens);
     if (count($tkens) > 0) {
              foreach($tkens as $n){
            list($n1,$n2)=explode('DEP',$n->trans_number);
            array_push($num, $n2);
        }
     //   print_r(max($num));
          
            $maxid=max($num) +1;
            $ino = 'DEP'.$maxid;
        } else {
            $ino =  'DEP1';
        }
      //  $ino=SUBSTRING($col, 4);
       return $ino;
    }

       public function update_deposit_transaction($student_id){
        $trans=$this->request->getPost('trans');
        //echo $this->request->getPost('header_id');
        $admnTransaction = [
                'trans_type_id' => 3,
                'trans_number' => $trans,
                'trans_date' => $this->request->getPost('invoice_date'),
                'updated_by' =>  $this->request->getPost('header_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
       // $this->smodel->SaveData('transaction_numbers_tbl',$admnTransaction);
        $this->smodel->update_table_details('transaction_numbers_tbl',$where = array('trans_number' => $trans,'trans_type_id' => 3),$admnTransaction);
//      print_r($admnTransaction);

        $total_cost = 0;
        $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 3,
             'invoice_type_id' => 6
         ];
         //$itm_trans = $this->smodel->SaveData_n_get_id('invoice_type_transaction',$invoice_type); 

         $itemID = $this->request->getPost('iid');
         $itype ="";
         $amountttl = 0;
         $qtys = 0;
         $id="";
         $amount=0;
        foreach ($itemID as $c) {
            $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c));
            foreach($itm as $i){
                $itype = $i->item_type;
            }

           $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $trans,'trans_type' => 3, 'quantity' => 1, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $this->request->getPost('prco'.$c.''));
            $this->smodel->update_table_details('item_transation_tbl',$where = array('trans_number' => $trans,'trans_type' => 3),$itemData);

     //      $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);
 //           print_r($itemData);

            $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
            $total_cost+=$this->request->getPost('prco'.$c.'');
            
            foreach($leger_items as $lg){
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                    continue;
                }
                $ledger = [
                    'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_no' => $trans,
                     'trans_type' => 3,
                     'amount' => $this->request->getPost('prco'.$c.''),
                     'transation_nature' => 1,
                     'name_type_id' => 1,
                     'name_id' => $student_id,
                ];
                $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $trans,'trans_type' => 3,'name_type_id' => 1),$ledger);
                //$this->smodel->SaveData('ledger_transaction_tbl',$ledger); 
 //                  print_r($ledger);

            }
        $amount+=$this->request->getPost('prco'.$c.'');
           }  
          $i=0;
       $s= $this->request->getPost('payer_id');

          //  $i++;
           // echo $i;
        $total_amount = 0;
         //list($name_type,$payer_id) = explode('_',$s);
           foreach($this->request->getPost('pay_ledger') as $l){
        $total_amount = $this->request->getPost('amount'.$l);
        $Bank_leger = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $l)); 
     

        // foreach ($receivableData as $rd) {
            $ac_ledger = [
                'ledger_id' => $Bank_leger[0]->id,
                'ledger_type' => $Bank_leger[0]->account_type_id,
                'trans_no' => $trans,
                'trans_type' => 3,
                'amount' =>  $total_amount,
                'transation_nature' => 2,
                'balance' => $total_amount,
            ];   
              $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $trans,'trans_type' => 3,'name_type_id' => $this->request->getPost('paid_by')),$ac_ledger);
    //     $this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger); 
  //         print_r($ac_ledger);
        }
        echo json_encode(array('status' =>'0','statusDesc' => ' Deposit Updated Successfully'));
        //$this->createControl_number($total_cost,$student_id,$transNo);
    }

    function update_invoice_item()
    {
        $no = $this->request->getVar('trans');
        $id = $this->request->getVar('sID');
        $itemID = $this->request->getVar('itemID');
        $cash = $this->request->getVar('cash');

        $data = [
                'unit_price' =>  $cash
               ];   
               $data1 = [
                'amount' =>  $cash
               ];
          $Ban = $this->smodel->gettable_data('ledger_transaction_tbl',$where =array('trans_no' => $no,'trans_type' => 1,'name_id' => $id,'trans_item' => $itemID)); 

         $this->smodel->update_table_details('item_transation_tbl',$where = array('trans_number' => $no,'trans_type' => 1,'item_id' => $itemID),$data);

         $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $no,'trans_type' => 1,'name_id' => $id,'trans_item' => $itemID),$data1);

          $Bank = $this->smodel->gettable_data('item_transation_tbl',$where =array('trans_number' => $no,'trans_type' => 1)); 
          $ttl=0;
          foreach($Bank as $b){
     $discount = $this->smodel->gettable_data('items_tbl',$where =array('item_group' => 7,'id'=>$b->item_id)); 
           if(count($discount)>0){
           $ttl=$ttl-$b->unit_price;
           }else{
          $ttl=$ttl+$b->unit_price;
           }
          }
         
         //update balance
             $inv_no = $this->bmodel->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $no));
            $total_paid=0;
            foreach($inv_no as $n){
                
                $rcpt_am = $this->bmodel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $n->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2));
                if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                    // echo 'rct='.$am->amount;
                    // echo '</br>'; 
                  $total_paid=$total_paid+$am->amount;
              }
                }
            }

         $amount=$ttl;
         $balance=$ttl-$total_paid;

          $data2 = [
                'amount' =>  $amount,
                'balance' =>  $balance
               ]; 
         $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $no,'trans_type' => 1,'name_id' => $id,'transation_nature' =>2),$data2);
         $tn=$this->bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$no,'trans_type_id'=>1));
         $invID=$tn[0]->id;
         
         $year=date('Y');
         $data = array(
                'inv' => $this->bmodel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$no,'trans_type_id'=>1)),
                   'year'=>$year,
               'class_data'=>$this->bmodel->get_class_data($invID,$year)
            );
            return view('payment/edit_invoice',$data);

        //   echo json_encode(array('status' =>'0','statusDesc' => 'Invoice Item Updated Successful'));

    }
  public function generate_credit_note()
    {
        $ino = "";
        $tkens = $this->smodel->get_max_note('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
    public function save_note_transaction($student_id){
        $transNo = $this->generate_credit_note();
        $admnTransaction = [
                'trans_type_id' => 6,
                'trans_number' => $transNo,
                'trans_date' => $this->request->getPost('invoice_date'),
                'updated_by' => $this->request->getPost('header_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
      $this->smodel->SaveData('transaction_numbers_tbl',$admnTransaction);
//   print_r($admnTransaction);

        $total_cost = 0;
        $invoice_type = [
             'trans_no' => $transNo,
             'transaction_type_id' => 6,
             'invoice_type_id' => $this->request->getPost('admission_type')
         ];
        $itm_trans = $this->smodel->SaveData('invoice_type_transaction',$invoice_type); 
  //        print_r($invoice_type);


         $itemID = $this->request->getPost('iid');
         $itype ="";
         $amountttl = 0;
         $qtys = 0;
         $id="";
         $amount=0;
        foreach ($itemID as $c) {
            $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c));
            foreach($itm as $i){
                $itype = $i->item_type;
            }

            $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $transNo,'trans_type' => 6, 'quantity' => $this->request->getPost('quantity'.$c.''), 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $this->request->getPost('price'.$c.''));
            
           $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);
 //          print_r($itemData);

            $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
            $total_cost+=$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.'');
        //   print_r($leger_items);
            foreach($leger_items as $lg){
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                // if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                //     continue;
                // }
                $ledger = [
                    'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $this->request->getPost('admission_type'),
                     'trans_no' => $transNo,
                     'trans_type' => 6,
                     'amount' =>  $this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.''),
                     'transation_nature' => 2,
                     'name_type_id' => 1,
                     'name_id' => $student_id,
                ];
               $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 
//print_r($ledger);
            }
        $amount+=$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.'');
           }  
        //for account receivables
        // $data = $this->request->getRawInput()['receivable_total_balance'];
        // $receivableData = json_decode($data);

        // foreach ($receivableData as $rd) {
         $s= $this->request->getPost('payer_id');
        list($name_type,$payer_id) = explode('_',$s);
            $ac_ledger = [
                'ledger_id' => $this->request->getPost('account'),
                'ledger_type' => 7,
                'trans_item' => $this->request->getPost('admission_type'),
                'trans_no' => $transNo,
                'trans_type' => 6,
                'amount' =>  $amount,
                'transation_nature' => 1,
                'name_type_id' => $name_type,
                'name_id' => $payer_id,
                'balance' => $amount,
            ];   
           $this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger); 
 //   print_r($ac_ledger);
        ///////////////////update credit balance---///////////////////
       
         ////////////////////end----------//////////////////////////
        echo json_encode(array('status' =>'0','statusDesc' => 'New Note Created Successfully'));
       
        //$this->createControl_number($total_cost,$student_id,$transNo);
    }
        function add_credit_note_item()
    {
        $no = $this->request->getVar('trans');
        $id = $this->request->getVar('id');
        $qty = $this->request->getVar('quantity');
        $item = $this->request->getVar('item');
        $itype='';

        $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $item));
        foreach($itm as $i){
            $itype = $i->item_type;

            $iprice = $this->smodel->gettable_data('price_tbl', $where = array('item_id' => $i->id));
            $price = $iprice[0]->item_price;
        }

        $iData = array('item_id' => $item, 'item_type_id'=>$itype,'trans_number' => $no,'trans_type' => 6, 'quantity' => $qty, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $price);

        $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$iData);

        $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $item)); 
        $total_cost=0;
            $total_cost =$qty * $price;
          
            foreach($leger_items as $lg){
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                    continue;
                }
                $ledger = [
                     'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $item,
                     'trans_no' => $no,
                     'trans_type' => 6,
                     'amount' =>  $qty * $price,
                     'transation_nature' => 2,
                     'name_type_id' => 1,
                     'name_id' => $id,
                ];
                $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 
            }

        $checkdata = $this->smodel->gettable_data('ledger_transaction_tbl', $where = array('name_id' => $id, 'trans_no' => $no,'trans_type' => 6));
        if(count($checkdata) > 0){
            
            $this->amodel->update_credit_balance($total_cost,$id,$no);
        }

                 
        echo json_encode(array("data"=>$this->amodel->get_transdetails($no,6),"ledger"=>$this->amodel->ledger_type($no,6)));
    }

    public function Remove_creditNoteItem()
    {

       $item = $this->request->getVar('item'); 
       $student = $this->request->getVar('student'); 
       $transNo = $this->request->getVar('transNo'); 
       // $cID = $this->request->getVar('class'); 
       // $hID = $this->request->getVar('hostel'); 
       // $tID = $this->request->getVar('transport'); 



      $item_trans = $this->amodel->delete_itemTransaction_data($item,$transNo,6);

       $ledgr = $this->smodel->gettable_data('items_ledgers_tbl', $where = array('item_id' => $item));

       $items = $this->smodel->gettable_data('items_tbl', $where = array('id' => $ledgr[0]->item_id));

        $i_ledger = $this->smodel->gettable_data('ledger_transaction_tbl', $where = array('trans_no' => $transNo, 'trans_item' => $item, 'name_id' => $student, 'trans_type' => 6));
        // print_r($i_ledger[0]->id).'</br>';
        // print_r($i_ledger[0]->amount).'</br>';
        // print_r($i_ledger[0]->trans_item);
        // return;
        $ttl = $i_ledger[0]->amount;
      

        $itemsledger = $this->smodel->gettable_data('ledger_transaction_tbl', 
            $where = array('ledger_type'=>7, 'trans_no'=>$transNo, 'trans_type' => 6)
        );

        //break();
        //die();
       // print_r($itemsledger);

        $balance = count($itemsledger)>0?$itemsledger[0]->balance:0;
        $lAmount = count($itemsledger)>0?$itemsledger[0]->amount:0;

        $ids = count($itemsledger)>0?$itemsledger[0]->id:0;
       $data = [
            'amount' => ($lAmount - $ttl),
            'balance' => ($balance - $ttl),
       ];



       $this->smodel->update_table_details('ledger_transaction_tbl', $where = array('id' => $ids),$data);
       
       // $this->smodel->deletetable_data('ledger_transaction_tbl', $where = array('id' => $i_ledger[0]->id));


        $this->amodel->delete_ledger_item($item,$student,$transNo,6);


        //$this->smodel->update_table_details('payment_request', $where = array('student_id' => $student, 'trans_no' => $transNo),$data2);

         // //echo json_encode(array('status' =>'0','statusDesc' => 'Item Removed Successful'));

    }
      function update_credit_note_item()
    {
        $no = $this->request->getVar('trans');
        $id = $this->request->getVar('sID');
        $itemID = $this->request->getVar('itemID');
        $cash = $this->request->getVar('cash');

        $data = [
                'unit_price' =>  $cash
               ];   
               $data1 = [
                'amount' =>  $cash
               ];
          $Ban = $this->smodel->gettable_data('ledger_transaction_tbl',$where =array('trans_no' => $no,'trans_type' => 6,'name_id' => $id,'trans_item' => $itemID)); 

         $this->smodel->update_table_details('item_transation_tbl',$where = array('trans_number' => $no,'trans_type' => 6,'item_id' => $itemID),$data);

         $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $no,'trans_type' => 1,'name_id' => $id,'trans_item' => $itemID),$data1);

          $Bank = $this->smodel->gettable_data('item_transation_tbl',$where =array('trans_number' => $no,'trans_type' => 6)); 
          $ttl=0;
          foreach($Bank as $b){
           if($b->item_id==64){
           $ttl=$ttl-$b->unit_price;
           }else{
          $ttl=$ttl+$b->unit_price;
           }
          }
         $amount=$ttl;
         $balance=$ttl;

          $data2 = [
                'amount' =>  $amount,
                'balance' =>  $balance
               ]; 
         
         $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $no,'trans_type' => 6,'transation_nature' =>1),$data2);

         echo json_encode(array('status' =>'0','statusDesc' => 'Credit Note Updated Successful'));

    }
    function generate_msg_no() {
        $ino = "";
        $tkens = $this->smodel->get_max_id('message_groups_tbl','send_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
public function update_invoice_account(){
      $no = $this->request->getVar('trans');
        $id = $this->request->getVar('ledger_id');

         $data= [
              
                'ledger_id' =>  $id
               ]; 
         
         $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $no,'trans_type' => 1,'transation_nature' =>2,'ledger_type'=>7),$data);
         echo 'Successfully updated';
}
 
 public function generate_invoice_controlnumber(){
    $total_cost=$this->request->getPost('due');
    $student_id=$this->request->getPost('sID');
    $transNo=$this->request->getPost('trans');
    $type=1;
    $des='School Fee(Ada)';
   
  if($total_cost>0){  
 $invtype=$this->bmodel->get_item_name('invoice_type_transaction',$where = array('trans_no' => $transNo,'transaction_type_id'=>1));
   $des = constant('msgDESC' . $invtype[0]->invoice_type_id);
   if($invtype[0]->invoice_type_id==2){
    $adm=$this->bmodel->get_item_name('admission_tbl',$where = array('student_id' => $student_id));
    $c=count($adm);
    $year=$adm[$c-1]->academic_year;
    $class=$adm[$c-1]->class_id;
    $hst=$adm[$c-1]->hostel_id;
    $this->createControl_number_crdb_admission($total_cost,$student_id,$transNo,1,$des,1,1,$year,$class,$hst);
}else{
   
 $this->createControl_number_crdb($total_cost,$student_id,$transNo,$type,$des,1,1);
}
  }
 }
 
 public function fetch_invoice(){
    $thedate=$this->request->getPost('thedate');
    list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
    $data = array(
            'trans' => $this->bmodel->get_item_name2('transaction_numbers_tbl',$where = array('trans_type_id' => 1),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate)),
           'year' =>date('Y', $sdate)
            );
    
   echo view('payment/invoice_list',$data); 
 }

 public function delete_invoice(){
    $inv_id=$this->request->getPost('inv_id');
   
  $detail=$this->bmodel->get_item_name('transaction_numbers_tbl',$where = array('id' => $inv_id));
    $ctr=$this->bmodel->get_item_name('payment_request',$where = array('trans_no' => $detail[0]->trans_number,'trans_type'=>1,'payment_status'=>0));
    if(count($ctr)>0){
        $data=array(
                'ref_no' => $ctr[0]->reference_no
                );
         $url = CRDB_URL_1."cancelRefNo";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                echo $response;
                $err = curl_error($ch); 
                curl_close($ch);

                 if ($err) {
                    echo "Error #:" . $err;
                    $status = 5;
                    $reference=0;
                     $time=date('Y-m-d H:i:s');
                   return;
                } else {
        $dl=$this->bmodel->delete_ctr_item($detail[0]->trans_number,$ctr[0]->reference_no);
                }
    }
    
$checkProject=$this->bmodel->get_item_name('project_transaction_tbl',$where = array('trans_numba' => $detail[0]->trans_number,'trans_type'=>1));
if(count($checkProject)>0){
 $this->bmodel->delete_detail($checkProject[0]->id,'project_transaction_tbl');   
}

$transp=$this->bmodel->get_item_name('transport_details',$where = array('trans_numb' => $detail[0]->trans_number));
if(count($transp)>0){
   $this->bmodel->delete_invoice_transport($transp[0]->id);
}
    $dlt=$this->bmodel->delete_invoice_item($inv_id,$detail[0]->trans_number);
    echo json_encode(array('status' =>'1','statusDesc' => 'Deleted Successful'));
 }
public function upadate_control($total_cost,$student_id,$transNo,$des){
    $curl=base_url().CRDB_CALLBACK_1;
    $charge=0;
    $desc=$des.' : '.$total_cost.' Bank charges : '.$charge;
     $student_details = $this->smodel->gettable_data('students',$where = array('id' => $student_id));
      $data=array(
            'name' =>$student_details[0]->full_name,
            'receipt_no' => $transNo,
            'amount' => $total_cost+$charge,
            'currency' => 'TZS',
            'payment_desc' => $desc,
            'visit_no'=>$student_id,
            'file_no'=>$student_id,
            'payment_channel' => 1,
            'facility_id' => FACILITY_ID_1,
            'payment_type' => PAYMENT_TYPE_1,
            'prefix' => PREFIX_1,
            'call_back_url' => $curl,
            'allow_partial' => 'FLEXIBLE'

        );
        //print_r($data); 

 $url = CRDB_URL_1."updatePayment";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                echo $response;
                $err = curl_error($ch); 
                curl_close($ch);
                ////dealing with response
            if ($err) {
                    //echo "Error #:" . $err;
                    $status = 5;
                    $reference=0;
                     $time=date('Y-m-d H:i:s');

                     echo json_encode(array('status' =>1,'statusDesc' => ' fail to update. '.$student_details[0]->full_name.''));
                } else {
                   
                    $obj2 = json_decode($response,TRUE);
                    if($obj2['status']=='success'){
                      $status = 1;
                    }else{
                       $status = 2;
                    }
                    $time=$obj2['date_created'];
                    
                    $reference= $obj2['paymentReference'];
                
                $crdb_data = array(
                    'trans_no' =>  $transNo,
                    'student_id' =>  $student_id,
                    'reference_no' => $reference,
                    'amount' => $total_cost,
                    'charges' => $charge,
                    'payment_status' => 0,
                    'payment_channel' => 3, //CRDB
                    'date_created' => $time,
                    
                 );
            //print_r($crdb_data);
    //            $this->smodel->update_table_details('payment_request',$where = array('reference_no' => $reference),$crdb_data); 
     

            $msg = "Kumb No: ".$reference.", Tarehe: ".$time.", Kiasi:TZS ".number_format($total_cost).", ".$des. " 2024, ".$student_details[0]->full_name.".".
                 "Fanya Malipo Kupitia CRDB.";
   // //*******invoice msg setup*************************************//
                 $phone=0;
                 
                $bill = $this->smodel->gettable_billingdata($student_id);
                if(count($bill)>0){
                $phone=$bill[0]->phone1;
                  }
                 
        
        
        $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname.Tafadhali Fanya Malipo Kupitia CRDB.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 1,
                    'send_number' => $snn,
                    'massage_date' =>  date('Y-m-d H:i:s'),
                    'send_by' =>3,
                    'messagex' => $messagex,
                    'trans_number' => $transNo
                  
                );
      
 //$this->smodel->SaveData('message_groups_tbl',$smsdata);
 if($phone==0){

    }else{
//     $this->SMSsender($phone,$msg,1,$student_id,$snn,NULL);
        
    }
      
     
    //****end msg invoice setup**********************************// 
    
      $student_name=$student_details[0]->full_name;
       echo json_encode(array('status' =>1,'statusDesc' => 'Student '.$student_name.' Control Number <b>'.$reference.'</b> Created Successful.'));
 }          ////////////////////////
}
public function cancel_control(){
    $data=array(
                'ref_no' => 'EG1240600030'
                );
         $url = CRDB_URL_1."cancelRefNo";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                echo $response;
                $err = curl_error($ch); 
                curl_close($ch);
 }
 public function check_payment(){
    $data=array(
                'ref_no' => 'EG1240100039'
                );
         $url = CRDB_URL_1."checkPayment";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                echo $response;
                $err = curl_error($ch); 
                curl_close($ch);
                
 }
 
  public function reconciliation(){
    //$recdate=date("Y-m-d");
    $recdate="2024-05-29";
    $data=array(
                "reconcile_date" => $recdate,
                "facility_id" => FACILITY_ID_1
                );
              //  file_put_contents('Apifeedback/req_recocile' . $recdate. '.txt', json_encode($data));
         $url = CRDB_URL_1."reconciliation";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
               // echo $response;
                $err = curl_error($ch); 
                curl_close($ch);
                 $data = json_decode($response,TRUE);
                $i=0;
                echo "<table>";
           if($data['status']=='500'){
         foreach ($data['transactions'] as $transaction) {
            $i++;
            echo "<tr>
            <td>".$i."</td>
            <td>".$transaction['payer_name']."</td>
            <td>".$transaction['amount']."</td>
            <td>".$transaction['transaction_date']."</td>
            <td>".$transaction['reference_no']."</td>
            <td>".$transaction['receipt_no']."</td>
            <td>".$transaction['transaction_ref']."</td>
            <td>".$transaction['phone_no']."</td>
            <td>".$transaction['transaction_channel']."</td>
            </tr>";
              }
          }else{
             echo "<tr>
              <td>No any transaction received</td>
              </tr>";
          }
    echo "</table>";
 }
 
public function continous_admission(){
    $student_id=$this->request->getPost('selected');
    foreach($student_id as $sid){
        
        $checkIfexit= $this->smodel->gettable_data('admission_tbl',$where = array('student_id' => $sid,'academic_year'=>$this->request->getPost('Academic_year')));
        if(count($checkIfexit)>0){
            continue;
        }
          $dateyear=$this->request->getPost('admission_date');
          $year=date('Y',strtotime($dateyear));
          $class=$this->request->getPost('class');
          $hst=$this->request->getPost('hstl'.$sid);
        $data = [
                    'student_id' =>$sid,
                    'academic_year' => $year,
                    'date_joined' => $this->request->getPost('admission_date'),
                    'level_id' => $this->request->getPost('class_level'),
                    'class_id' => $this->request->getPost('class'),
                    'stream_id' => $this->request->getPost('stream'.$sid),
                    'admission_type' => $this->request->getPost('admission_type'.$sid),
                    'hostel_id' => $this->request->getPost('hstl'.$sid),
                    'transport' =>'No',
                    'vehicle_id' =>0,
                    'adimit_for' => $this->request->getPost('for'.$sid),
                    'admitted_by ' => $this->request->getPost('header_id'),
                    'admitted_date' => date('Y/m/d H:i:s')
                ];
               // print_r($data);
         $this->amodel->SaveDetails('admission_tbl',$data);
     
       $transNo = $this->generate_transaction_no();
        $admnTransaction = [
                'trans_type_id' => 1,
                'trans_number' => $transNo,
                'trans_date' => $this->request->getPost('admission_date'),
                'updated_by' => $this->request->getPost('header_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];
        $this->smodel->SaveData('transaction_numbers_tbl',$admnTransaction);

        $total_cost = 0;
        $invoice_type = [
             'trans_no' => $transNo,
             'transaction_type_id' => 1,
             'invoice_type_id' => 2
         ];
         $itm_trans = $this->smodel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);
         ///geting items
         if($this->request->getPost('for'.$sid)==2){
         $levelFee=$this->amodel->fetch_classLevel_fee(2,$this->request->getPost('class_level'));
         }else{
           $levelFee=$this->amodel->fetch_classLevel_fee(0,$this->request->getPost('class_level'));  
         }
              $items=array();
              foreach($levelFee as $lv){
             $items[]=array($lv->item_id);
              }

         ///////start///////////////
              if($this->request->getPost('for'.$sid)==2){
          $classFee=$this->amodel->fetch_class_fee(2, $this->request->getPost('class'));
              }else{
    $classFee=$this->amodel->fetch_class_fee(0, $this->request->getPost('class'));
              }
       
         foreach($classFee as $cl){
       $items[]=array($cl->item_id);
          }
  if($this->request->getPost('admission_type'.$sid)==3){
    if($this->request->getPost('for'.$sid)==2){
      $bFee=$this->amodel->fetch_boarding_fee(2,$this->request->getPost('class'));
      $bFee2=$this->amodel->fetch_boarding_fee2(2,$this->request->getPost('class_level'));  
  }else{
     $bFee=$this->amodel->fetch_boarding_fee(0,$this->request->getPost('class'));
     $bFee2=$this->amodel->fetch_boarding_fee2(0,$this->request->getPost('class_level'));  
  }
    if(count($bFee)>0){
     foreach($bFee as $bf){
     $items[]=array($bf->item_id);
      }
      }

      if(count($bFee2)>0){
     foreach($bFee2 as $bf){
     $items[]=array($bf->item_id);
      }
      }
  }
  //////////loop items
     $itype ="";
         $amountttl = 0;
         $qtys = 0;
         $id="";
         $discount=0;
  foreach ($items as $item) {
    //echo $item[0] . "<br>";
    $c=$item[0];
 $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c));
 $item_price = $this->smodel->gettable_data('price_tbl',$where = array('item_id' => $c));
            foreach($itm as $i){
                $itype = $i->item_type;
            }
            $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $transNo,'trans_type' => 1, 'quantity' => 1, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $item_price[0]->item_price);

            $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);

            $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
            if($itm[0]->item_group==7){
                 $discount=1 * $item_price[0]->item_price;
            $total_cost-=1 * $item_price[0]->item_price;
            }else{

            $total_cost+=1 * $item_price[0]->item_price;
          }
          $amount=0;
          $transactions=0;
            foreach($leger_items as $lg){
                $amount= 1 * $item_price[0]->item_price;
                $transactions+=$amount;
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                // if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                //     continue;
                // }
                $ledger = [
                     'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $c,
                     'trans_no' => $transNo,
                     'trans_type' => 1,
                     'amount' =>  1 * $item_price[0]->item_price,
                     'transation_nature' => 1,
                     'name_type_id' => 1,
                     'name_id' => $sid,
                ];
                $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 
            }
        }

//////////end loop items
          //for account receivables
       $total= 0;
        $ledgerId = '';
        $i=0;
        $total=$this->request->getPost('total_fee'.$sid);
        
        $level=$this->request->getPost('class_level');
          $legers_acc = $this->smodel->gettable_data('class_level_items_tbl',$where = array('level_id' => $level));
        if(count($legers_acc)>0){
          $ledgerId=$legers_acc[0]->account_receivable;
          }else{
         $legers_acc = $this->smodel->gettable_data('accounts_tbl',$where = array('account_type_id' => 7));
         $ledgerId=$legers_acc[0]->id;
          }

        $ac_ledger = [
            'ledger_id' => $ledgerId,
            'ledger_type' => 7,
            'trans_no' => $transNo,
            'trans_type' => 1,
            'amount' => $total,
            'transation_nature' => 2,
            'name_type_id' => 1,
            'name_id' => $sid,
            'balance' => $total,
        ];   
        $this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger); 
       $desc='School Fee';
       if($total>0){
         //$this->createControl_number_crdb_admission($total,$sid,$transNo,1,$desc,1,1,$year,$class,$hst);
        echo 'saved';
       }
    }

 }
 function update_invoice_amount(){
      $i=0;
   $itm = $this->smodel->gettable_data('admission_tbl',$where = array('class_id' =>5,'level_id'=>2,'admission_type'=>0,'adimit_for'=>0,'academic_year'=>2024));
   foreach($itm as $tm){
       if($tm->student_id==1 ||$tm->student_id==2){
    continue;
    }else{
   $ledger = $this->smodel->gettable_data('ledger_transaction_tbl',$where = array('name_id' =>$tm->student_id,'transation_nature'=>2,'name_type_id'=>1,'trans_type'=>1,'ledger_type'=>7,'ledger_id'=>6));
 
    foreach($ledger as $lg){
      $tn = $this->smodel->gettable_data('transaction_numbers_tbl',$where = array('trans_type_id' =>1,'trans_number'=>$lg->trans_no,'trans_date>'=>'2024-01-01'));
      if(count($tn)>0){

        $i++;
      //echo $lg->amount.'/'.$tm->student_id.'/'.$tn[0]->trans_number;
    //  echo '</br>';
 $itemData = array('item_id' => 39, 'item_type_id' => 3,'trans_number' =>$tn[0]->trans_number,'trans_type' => 1, 'quantity' => 1, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => 198000);

       //    $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);
          //  print_r($itemData);

       $ac_ledger = [
            'ledger_id' => 1,
            'ledger_type' => 4,
            'trans_item'=>39,
            'trans_no' => $tn[0]->trans_number,
            'trans_type' => 1,
            'amount' => 198000,
            'transation_nature' => 1,
            'name_type_id' => 1,
            'name_id' => $tm->student_id,
            'balance' => 0,
        ]; 
        //$this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger);
      //print_r($ac_ledger);

        $ledger = [
            'amount' => 198000+ $lg->amount,
             'balance' => 198000+ $lg->amount
        ]; 
        $total= 198000+ $lg->amount;
       // $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('id' => $lg->id),$ledger); 
      //  print_r($ledger);

        $desc='School Fees';
     //    $this->upadate_control($total,$tm->student_id,$tn[0]->trans_number,$desc);
   }
    }
}
   }
  }
  
  public function update_invoice_manually(){
  $total_cost=0; 
  $student_id=645; 
  $transNo=1991;
  $des="School Fee";
 // $this->upadate_control($total_cost,$student_id,$transNo,$des);  
}

public function save_pocket_transaction_items(){
    $selected= $this->request->getPost('selected');
    foreach($selected as $student_id){
                $transNo = $this->generate_transaction_deposit();
                $admnTransaction = [
                'trans_type_id' => 3,
                'trans_number' => $transNo,
                'trans_date' => date('Y-m-d'),
                'status' => 2,
                'trans_desc' =>  $this->request->getPost('year'),
                'updated_by' =>  $this->request->getPost('header_id'),
                'updated_date' => date('Y-m-d H:i:s')
                ];
                

                $this->smodel->SaveData('transaction_numbers_tbl',$admnTransaction);
                //       print_r($admnTransaction);

                $total_cost = 0;
                $invoice_type = [
                'trans_no' => $transNo,
                'transaction_type_id' => 3,
                'invoice_type_id' => 6
                ];
                $itm_trans = $this->smodel->SaveData_n_get_id('invoice_type_transaction',$invoice_type); 

                $itype ="";
                $amountttl = 0;
                $qtys = 0;
                $id="";
                $amount=0;
                $c=$this->request->getPost('item');
                $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c));
                foreach($itm as $i){
                $itype = $i->item_type;
                }

                $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $transNo,'trans_type' => 3, 'quantity' => 1, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $this->request->getPost('item_price'));

                $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);
                //           print_r($itemData);

                $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
                $total_cost+=$this->request->getPost('item_price');

                foreach($leger_items as $lg){
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                $ledger = [
                'ledger_id' => $lg->account_id,
                'ledger_type' => $legers[0]->account_type_id,
                'trans_item' => $this->request->getPost('item'),
                'trans_no' => $transNo,
                'trans_type' => 3,
                'amount' => $this->request->getPost('item_price'),
                'transation_nature' => 1,
                'name_type_id' => 1,
                'name_id' => $student_id,
                ];
                $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 
                //                print_r($ledger);

                }
                $amount+=$this->request->getPost('item_price');
                  
                $i=0;
                $pid=$this->smodel->gettable_billingdata($student_id);
                $s= 5;

                //  $i++;
                // echo $i;
                $total_amount = 0;
               // list($name_type,$payer_id) = explode('_',$s);
                
                $l=17;
                $Bank_leger = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $l)); 
                $ac_ledger = [
                'ledger_id' => $Bank_leger[0]->id,
                'ledger_type' => $Bank_leger[0]->account_type_id,
                'trans_no' => $transNo,
                'trans_type' => 3,
                'amount' =>  $amount,
                'transation_nature' => 2,
                'name_type_id' => 5,
                'name_id' => $pid[0]->id,
                'balance' => $amount
                ];   
                $this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger);

                
                //****************depost message*************************************//
                $student_details = $this->amodel->get_student_details('students',$where = array('id' => $student_id));
               //***************end*depost message*************************************//
                 $desc="Pocket Money";
              
                $this->createControl_number_crdb($amount,$student_id,$transNo,3,$desc,1,1);
                
        
       }
    }
    
     public function manage_gratuation()
    {
        return view('templates/header')
        .view('admission/graduation')
        .view('templates/footer');   
    }
     public function manage_absconds()
    {
        return view('templates/header')
        .view('admission/absconds')
        .view('templates/footer');   
    }
 
 public function generate_installment_msg($transNo,$year,$class,$hst,$reference,$student_id)
    {
        helper('calc');
        $dbname=session()->get('db_name');
        $results=findCalc($student_id,$dbname,$year);
         $level = $this->bmodel->get_item_name('classes_tbl', $where = array('id' => $class));
         $period = $this->bmodel->get_item_name('class_level_tbl', $where = array('id' => $level[0]->class_level));
     $message = "";
    
                $mbalance1=0;
                  $mbalance2=0;
                  $mbalance3=0;

                     $dateterm = $this->report->checkTerm_date(date('Y-m-d'),$year,$period[0]->academic_type);
                  //print_r($dateterm);
                    if (is_countable($dateterm) && count($dateterm) > 0) {
                    $term_name=$dateterm[0]->term_name;
                   }else{
                    $dateterm = $this->report->checkTerm_date2(date('Y-m-d'),$year,$period[0]->academic_type);
                     
                     $term_name=$dateterm[0]->term_name;
                   }
                  
                   $installments = $this->bmodel->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$period[0]->academic_type));
                    
                    $ttlAmount = 0;
                     $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                      $ddate="";
                   
                    foreach ($installments as $r) {
                        // $paid_amount=0;
                        
                  $i++;
                     
                     if($i==1){
                    
                         $duedate1=$r->due_date;
             
                   $openingbalance=$results[0]['openingbalance'];
                       $ment=$results[0]['ment'];
                        $mbalance1=$ment;
                        $mbalance=$results[0]['mbalance'];
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[0]['today']==1){
                       $todaybalance=$results[0]['todaybalance']; 
                     }
                    }
                      if($i==2){
               
                  $duedate2=$r->due_date;
           
                         $ment=$results[1]['ment'];
                        $mbalance2=$ment;
                        $mbalance=$results[1]['mbalance'];
                        $paid_amount=$results[1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[1]['today']==1){
                       $todaybalance=$results[1]['todaybalance']; 
                     }  
                     }
                   if($i==3){
                    $duedate3=$r->due_date;
         
                     $ment=$results[2]['ment'];
                        $mbalance3=$ment;
                        $mbalance=$results[2]['mbalance'];
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[2]['today']==1){
                       $todaybalance=$results[2]['todaybalance']; 
                     }
                     }
                     
                       if($i==4){
                    $duedate3=$r->due_date;
         
                     $ment=$results[3]['ment'];
                        $mbalance3=$ment;
                        $mbalance=$results[3]['mbalance'];
                        $paid_amount=$results[3]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[3]['today']==1){
                       $todaybalance=$results[3]['todaybalance']; 
                     }
                     }
                    
                      } 
           $st_details = $this->bmodel->get_item_name('students',$where=array('id'=>$student_id));
           if($i==2){
               $message=$st_details[0]->first_name.", Kumb No ".$reference.", 1st - ".number_format($mbalance1)."/- kabla ya ".date('Y-m-d',strtotime($duedate1)).", 2nd - ".number_format($mbalance2)."/- kabla ya ".date('Y-m-d',strtotime($duedate2))." . Ada ".$year.".";  
           }else{
            $message=$st_details[0]->first_name.", Kumb No ".$reference.", 1st - ".number_format($mbalance1)."/- kabla ya ".date('Y-m-d',strtotime($duedate1)).", 2nd - ".number_format($mbalance2)."/- kabla ya ".date('Y-m-d',strtotime($duedate2)). ", 3rd- ".number_format($mbalance3)."/- kabla ya ".date('Y-m-d',strtotime($duedate3)).". Ada ".$year.".";    
           }
                
        return $message;
    }
    
      public function update_admission(){
        if($this->request->getPost('state')>0){
                
                $hostel= $this->request->getPost('hstl');
                $data1 = [
                    'hostel' => $hostel,
                    ];
                    $this->smodel->update_table_details('boarding_tbl',$where = array('student_id' => $this->request->getPost('sid'),'academic_year' => $this->request->getPost('acdy')),$data1);
            }else{
                $hostel=0;
            }
                $data = [
                    'student_id' => $this->request->getPost('sid'),
                    'academic_year' => $this->request->getPost('acdy'),
                    'date_joined' => $this->request->getPost('djoin'),
                    'level_id' => $this->request->getPost('clevel'),
                    'class_id' => $this->request->getPost('croom'),
                    'stream_id' => $this->request->getPost('stream'),
                    'admission_type' => $this->request->getPost('state'),
                    'hostel_id' =>  $hostel,
                    'adimit_for' => $this->request->getPost('admit'),
                    'admitted_by ' => $this->request->getPost('header_id'),
                    'admitted_date' => date('Y/m/d H:i:s')
                ];

             $this->smodel->update_table_details('admission_tbl',$where = array('id' => $this->request->getPost('adm_id')),$data);
             echo json_encode(array('status' =>'0','statusDesc' => 'Student Updated Successful')); 
          
    }
    function generate_reversal_no() {
        $ino = "";
        $tkens = $this->smodel->get_max_reversal('transaction_numbers_tbl','trans_number',7);
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
    
    function updateControlType($id,$payid){
        if($id==1){
            $typ="FLEXIBLE";
        }else{
         $typ="FIXED";   
        }
        $payment_details = $this->smodel->gettable_data('payment_request',$where = array('id' => $payid));
    
   
      $data=array(
           'reference_no' => $payment_details[0]->reference_no,
            'allow_partial' => $typ
              );

      $url = CRDB_URL_1."updatePaymentType";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
              // echo $response;
                $err = curl_error($ch); 
                curl_close($ch);
                ////dealing with response
            if ($err) {
                    //echo "Error #:" . $err;
                    $status = 5;
                    $reference=0;
                     $time=date('Y-m-d H:i:s');

                     echo "2";
                } else{
                 $obj2 = json_decode($response,TRUE);
                    if($obj2['status']=='1'){
                      $status = 1;
                    
                
                $crdb_data = array(
                    'allow_partial'=>$id,
                 );
           // print_r($crdb_data);
                $this->smodel->update_table_details('payment_request',$where = array('id' => $payid),$crdb_data);
                    echo '1';
                    }else{
                       $status = 2;
                       echo $status;
                    }
                }
             }
   function automatic_delete(){
     $invoice = $this->smodel->gettable_data('project_transaction_tbl',$where = array('trans_type' =>1)); 

     foreach($invoice as $inv){

       $checkPresent = $this->smodel->gettable_data('transaction_numbers_tbl',$where = array('trans_type_id' =>1,'trans_number'=>$inv->trans_numba)); 
     if(count($checkPresent)>0){

     }else{
        $this->bmodel->delete_detail($inv->id,'project_transaction_tbl'); 
      
      
     }    
     }
      echo 'Deleted successfully'; 
      
    } 
    
    function fetch_invoice_balances(){
       // echo "balances";
        $year=$this->request->getPost('yearb');
        $classlevel=$this->request->getPost('classlevel');
        $class=$this->request->getPost('class');
        $stream=$this->request->getPost('stream');
        $status=$this->request->getPost('status');
        $data=array(
          'year'=>$year,
          'classlevel'=>$classlevel,
          'class'=>$class,
          'stream'=>$stream,
          'status'=>$status,
        );

        $data = array(
            'trans' => $this->bmodel->get_invoice_balances($year,$classlevel,$class,$stream,$status)
             
            );
          //print_r($data);
      
         echo view('payment/invoice_balances_list',$data);
    }

     function create_controlno_group(){
        $i=0;
        foreach($this->request->getPost('selected') as $trans_no){
            $i++;
            $balance=$this->request->getPost('balance'.$trans_no);
            $s=$this->request->getPost('student_id'.$trans_no);
            
            $data=array(
              'balance'=>$balance,
              'trans_no'=>$trans_no,
            );
            //print_r($data);
            $des="School Fees(Ada)";
            $this->createControl_number_crdb($balance,$s,$trans_no,1,$des,1,1);
        }
    }
    
    function update_students_hostel(){
    foreach($this->request->getPost('selected') as $st){
        $acdmc_yr=$this->request->getPost('year');
        $data=array(
              'hostel_id'=>$this->request->getPost('hostel_id'),
             
            );
        $data2=array(
              'hostel'=>$this->request->getPost('hostel_id'),
            );
       

        $this->smodel->update_table_details('admission_tbl',$where = array('academic_year' => $acdmc_yr,'student_id'=>$st),$data);
        $this->smodel->update_table_details('boarding_tbl',$where = array('academic_year' => $acdmc_yr,'student_id'=>$st),$data2);
 }
 echo "1";
}

function updateInvDate($inv,$dt){
    //echo $dt;
    //echo $inv;
      $data=array(
              'trans_date'=>$dt,
            );
$this->smodel->update_table_details('transaction_numbers_tbl',$where = array('trans_number' => $inv,'trans_type_id'=>1),$data);
echo 1;
}

function changeReceiptDate(){
    $date=$this->request->getVar("date");
    $id=$this->request->getVar("id");
  $data=array(
              'trans_date'=>$date,
            );
$this->smodel->update_table_details('transaction_numbers_tbl',$where = array('trans_number' => $id,'trans_type_id'=>2),$data);
echo 1;   
}

 public function fetch_invoice_byname($type){
    $name=$this->request->getPost('name');
    $year=$this->request->getPost('year');
    
   $data = array(
            'trans' => $this->bmodel->get_item_name3($name,$type,$year),
            'year' => $year
             
            );
    // print_r($data);
    //  return;
    if($type==1){
        echo view('payment/invoice_list',$data); 
    }
     if($type==2){
        echo view('payment/receipt2',$data); 
    }
    if($type==3){
        echo view('payment/deposit2',$data);
    }
     if($type==6){
         echo view('payment/credit_note_list',$data); 
    }
 }
 
 function check_reconciliation($ref){
   
    $db_id=session()->get('db_id');
    $id=session()->get('db_id');
     $db='default';
          $bank_requirements = $this->payment_model->get_item_name('payments_requirements_tbl',$where = array('db_id' => $db_id, 'status'=>1),$db);  
          if(count($bank_requirements)>0){
      
         $facilityid=$bank_requirements[0]->facility_id;
         $crdb_url=CRDB_URL_1;
        

          }else{
              return;
          }
    
    
    
    $data=array(
                "reference_number" => $ref,
                'facility_id' => $facilityid,
                );
              
         $url = CRDB_URL_1."check_Payment";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                //echo $response;
                $err = curl_error($ch); 
                curl_close($ch);
                 $data = json_decode($response,TRUE);
                 //print_r($data);
                 $data['ref']=$ref;
                  echo view('payment/payment_reconciliation',$data); 

             }

    function make_receipt(){
      $ref= $this->request->getVar('ref');
      $ctr= $this->request->getVar('ctr');

    $id=session()->get('db_id');
    if($id==1){
   $facilityid=FACILITY_ID_1;
    $crdb_url=CRDB_URL_1;
    }elseif($id==4){
  $facilityid=FACILITY_ID_4;
   $crdb_url=CRDB_URL_4;
    }
    $data=array(
                "reference_number" => $ctr,
                'pay_reference' => $ref,
                );
              //  print_r($data);
              
         $url = CRDB_URL_1."resend_Payment";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
               // echo $response;
                $err = curl_error($ch); 
                curl_close($ch);
                 $data = json_decode($response,TRUE);
                 //print_r($data);
                 $status=$data['status'];
                 echo $status;
             }

             function check_receipt(){
                $refn= $this->request->getVar('ref');
               $ctr= $this->request->getVar('ctr');
               
                $check = $this->smodel->gettable_data('payment_response',$where = array('reference_no' =>$ctr,'transaction_receipt'=>$refn)); 
                if(count($check)>0){
                    echo 1;
                }else{
                    echo 2;
                }
             }
             
   public function save_newinvoice_projects(){
    $selected = $this->request->getPost('selected');
    $itemID = $this->request->getPost('iid');

     
     $transtype = $this->request->getPost('transtype');
    foreach ($selected as $student_id) 
    {
      
     if($transtype==3){
        $status=2;
        $year=date('Y');
        $transNo = $this->generate_transaction_deposit();
     }else{
       $status=1;
       $year=date('Y');
       $transNo = $this->generate_transaction_no();
     }

       $admnTransaction = [
                'trans_type_id' => $transtype,
                'trans_number' => $transNo,
                'trans_date' => $this->request->getPost('inv_date'),
                'status' => $status,
                'trans_desc' => $year,
                'updated_by' => $this->request->getPost('header_id'),
                'updated_date' => date('Y-m-d H:i:s')
        ];

       //$this->smodel->SaveData('transaction_numbers_tbl',$admnTransaction);
         ///here we go
            $trans_id = $this->smodel->SaveData_n_get_id('transaction_numbers_tbl',$admnTransaction);
        $check_class = $this->smodel->gettable_data('company_tbl',$where = array('classification' => 1));
        if(count($check_class)>0){
            $classification = [
                'trans_id' => $trans_id,
               'classification_id' => $this->request->getPost('class_id'),
                
                 ];
        $this->smodel->SaveData('invoice_classification_tbl',$classification);
         }
        ///here we end of

       $total_cost = 0;
        $invoice_type = [
             'trans_no' => $transNo,
             'transaction_type_id' => $transtype,
             'invoice_type_id' => $this->request->getPost('inv_type')
         ];
          $itm_trans = $this->smodel->SaveData_n_get_id('invoice_type_transaction',$invoice_type); 

         $itype ="";
         $amountttl = 0;
         $qtys = 0;
         $id="";
         $amount=0;
         foreach ($itemID as $c) {
            $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c));
            foreach($itm as $i){
                $itype = $i->item_type;
            }

            $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $transNo,'trans_type' => $transtype, 'quantity' => $this->request->getPost('quantity'.$c.''), 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $this->request->getPost('price'.$c.''));

            $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);

            $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
            $total_cost+=$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.'');
            
            if(count($leger_items)==0){
             return json_encode(array('status' =>2,'statusDesc' => 'Invoice Not Created item ledger missing.'));    
            }
            foreach($leger_items as $lg){
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                // if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                //     continue;
                // }
                $ledger = [
                    'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $this->request->getPost('inv_type'),
                     'trans_no' => $transNo,
                     'trans_type' => $transtype,
                     'amount' =>  $this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.''),
                     'transation_nature' => 1,
                     'name_type_id' => 1,
                     'name_id' => $student_id,
                ];
                 $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 

            }
        $amount+=$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.'');
           }
            
            if($transtype==3){
             $ac=17;
            }else{
             $ac=$this->request->getPost('account');
            }
            $leg = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $ac));
//print_r($leg);
 
            $ac_ledger = [
                'ledger_id' => $ac,
                'ledger_type' => $leg[0]->account_type_id,
                'trans_item' => $this->request->getPost('inv_type'),
                'trans_no' => $transNo,
                'trans_type' => $transtype,
                'amount' =>  $amount,
                'transation_nature' => 2,
                'name_type_id' => 1,
                'name_id' => $student_id,
                'balance' => $amount,
            ];   
            $this->smodel->SaveData('ledger_transaction_tbl',$ac_ledger);

             $proje = [
                'project_id' => $this->request->getPost('project_id'),
                'trans_type' => $transtype,
                'trans_numba' => $transNo,
                'student_id' => $student_id,
                'amount' => $amount,
                
        ];  
        $this->smodel->SaveData('project_transaction_tbl',$proje); 

         $desc=$this->request->getPost('project_name');
         $al=0;
         $customer_type=1;
          if($total_cost>0){
            $db_id=session()->get('db_id');
                
           $this->createControl_number_crdb($total_cost,$student_id,$transNo,$transtype,$desc,$al,$customer_type);
     
               
          }
 
 }
echo json_encode(array('status' =>1,'statusDesc' => 'Invoice Created Successful.')); 
}

public function student_not_show()
    {
        return view('templates/header')
        .view('admission/student_not_shown')
        .view('templates/footer');   
    }
    
    public function update_receivable(){
        $trans = $this->request->getVar('trans');
        $student_id = $this->request->getVar('sID');
        $trans_type = $this->request->getVar('trans_type');
        
        $amount = $this->request->getVar('amount');
              $data2 = [
                'amount' =>  $amount,
               ]; 
               if($trans_type==1){
         $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $trans,'trans_type' => $trans_type,'name_id' => $student_id,'transation_nature' =>2,'ledger_type'=>7),$data2);
               }
               if($trans_type==6){
         $this->smodel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' => $trans,'trans_type' => $trans_type,'transation_nature' =>1,'ledger_type'=>7),$data2);
               }

          echo json_encode(array('status' =>'0','statusDesc' => 'Receivable Updated Successful'));
    }
    
    public function transfered_students()
    {
        return view('templates/header')
        .view('admission/transfered_students')
        .view('templates/footer');   
    }
    
    
    function itemsfix(){
        
        return;
        //applicable for missing items only
         $itype ="";
         $amountttl = 0;
         $qtys = 0;
         $id="";
         $discount=0;

$items=array();
$bFee2=$this->amodel->fetch_boarding_fee2(2,4);  
 if(count($bFee2)>0){
     foreach($bFee2 as $bf){
     $items[]=array($bf->item_id);
      }
      }
     $students = $this->smodel->gettable_data('admission_tbl',$where = array('admission_type' => 3,'class_id'=>11)); 
    //  print_r($bFee2);
    //  return;
    foreach($students as $st){
 $lgn = $this->smodel->gettable_data('ledger_transaction_tbl',$where = array('name_id' => $st->student_id,'name_type_id'=>1,'transation_nature'=>2));
  $transNo=$lgn[0]->trans_no;
  $sid=$st->student_id;
  
  foreach ($items as $item) {
  
    $c=$item[0];
 $itm = $this->smodel->gettable_data('items_tbl',$where = array('id' => $c));
 $item_price = $this->smodel->gettable_data('price_tbl',$where = array('item_id' => $c));
            foreach($itm as $i){
                $itype = $i->item_type;
            }
            $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $transNo,'trans_type' => 1, 'quantity' => 1, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $item_price[0]->item_price);

    $itm_trans = $this->smodel->SaveData_n_get_id('item_transation_tbl',$itemData);
            print_r($itemData);

            $leger_items = $this->smodel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
       
          $amount=0;
          $transactions=0;
            foreach($leger_items as $lg){
                $amount= 1 * $item_price[0]->item_price;
                $transactions+=$amount;
                $legers = $this->smodel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                    continue;
                }
                $ledger = [
                     'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $c,
                     'trans_no' => $transNo,
                     'trans_type' => 1,
                     'amount' =>  1 * $item_price[0]->item_price,
                     'transation_nature' => 1,
                     'name_type_id' => 1,
                     'name_id' => $sid,
                ];
                $this->smodel->SaveData('ledger_transaction_tbl',$ledger); 
                print_r($ledger);
            }
        }
        
    }
    }
    
   function editControlnumber_names($id){
      // $ref = $this->request->getVar('ref');
      // $stname = $this->request->getVar('student_name');
     // echo $ref.'-'.$stname;
    $student = $this->smodel->gettable_data('students',$where = array('id' => $id));
    $control_numbers = $this->smodel->gettable_data('payment_request',$where = array('student_id' => $id));
    //return $control_numbers;
    if(count($control_numbers)>0){
        foreach($control_numbers as $cn){
            $stname=$student[0]->full_name;
         $data=array(
            'name' =>$stname,
            'reference_no' =>$cn->reference_no,
             );

       
            $crdb_url=CRDB_URL_1;
       $url = $crdb_url."updatePaymentName";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
            
                $response = curl_exec($ch);
                //echo $response;
                $err = curl_error($ch); 
                curl_close($ch);

                 if ($err) {
                    //echo "Error #:" . $err;
                    $status = 5;
                    $reference=0;
                     echo 2;
                } else {
                   
                    $obj2 = json_decode($response,TRUE);
                    $status=$obj2['status'];
                    echo $status;

                }
                 }
              }
           }
    //the end
    
}
