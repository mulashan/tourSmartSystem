<?php 
    namespace App\Controllers;

    use CodeIgniter\Controller;
    use App\Models\BillingModel;
    use App\Models\StudentModel;
    use App\Models\SystemModel;
    use App\Models\PaymentsModel;
   
//   require_once APPPATH . '../vendor/autoload.php';
   
    use PhpOffice\PhpSpreadsheet\Spreadsheet;
    use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
    
    use Dompdf\Dompdf;
    use Dompdf\Options;

    class BillingController extends BaseController{
        public $StudentModel;
        public $sytm_model;
        public $databaseName;
        public function __construct(){
             if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
           $this->billingModel = new BillingModel; 
           $this->studentModel = new StudentModel; 
           $this->sytm_model = new SystemModel;
           $this->payment_model = new PaymentsModel;
               helper('age');
         $this->dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($this->dbname);
        }
        function invoice(){
        $data = array(
            'trans' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('trans_type_id' => 1))
            );
            return view('templates/header')
            .view('payment/invoice',$data)
            .view('templates/footer');   
        } 

        function receipt(){
            $data = array(
               'trans' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('trans_type_id' => 2))
            );
            return view('templates/header')
            .view('payment/receipt',$data)
            .view('templates/footer');   
        }
         function invoice_receipt($id,$trans_no){
            $data = array(
               'trans' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('trans_type_id' => 2))
            );
            $data['stid']=$id;
            $data['tno']=$trans_no;
            return view('templates/header')
            .view('payment/receipt1',$data)
            .view('templates/footer');   
        }
      function view_invoice_details($id,$year){
            $data = array(
               'inv' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('id' =>$id)),
               'year'=>$year,
               'class_data'=>$this->billingModel->get_class_data($id,$year)
            );

            return view('payment/invoice_detailed',$data);
        }

        function edit_invoice_details($invID,$year){
            $data = array(
                'inv' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('id' =>$invID)),
                   'year'=>$year,
               'class_data'=>$this->billingModel->get_class_data($invID,$year)
            );
            return view('payment/edit_invoice',$data);
        }

        function print_invoice_details($id){
            $data = array(
               'trans' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$id))
            );
            return view('payment/invoice_PrintOut',$data);
        } 

        function view_receipt_details($id){
            $data = array(
               'recpt' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('id' =>$id))
            );
          // Load the view into a variable
        $html = view('payment/receipt_detailed', $data);

        // Initialize Dompdf
        $options = new Options();
        $options->set('defaultFont', 'Courier');
        $options->set('isHtml5ParserEnabled', true);  // Enables better HTML parsing
        $options->set('isRemoteEnabled', true); // Allows loading external images (if any)

        $dompdf = new Dompdf($options);
        $dompdf->loadHtml($html);
        
        // Set Paper size and orientation
       // $dompdf->setPaper('A4', 'portrait');
       // $dompdf->setPaper([0, 0, 300, 500], 'portrait'); 

        // Render PDF (this is required before output)
        $dompdf->render();

        $output = $dompdf->output();
        file_put_contents('receipts/receipt_' . $id . '.pdf', $output);

             $this->whatsapmessage($id);
            return view('payment/receipt_detailed',$data);
        }
        
         function print_receipt_details($id){
            $data = array(
               'leger_transaction' => $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('name_id' =>$id,'name_type_id'=>4,'transation_nature'=>1))
            );
            //echo $id;
            return view('payment/application_receipt',$data);
        }
        function search_customer(){
            $data['search'] = $this->request->getPost('cust_name');
               $data['receipt_type'] = $this->request->getPost('receipt_type');
            $data['ctype'] = $this->request->getPost('type');
           //if($this->request->getPost('type') == 4){
             return view('payment/pending_bills',$data);
//           }else{
//                 echo 'No Details Found';
//           }
        }
         function search_customer_invoice(){
            $data['search'] = $this->request->getPost('cust_name');
            $data['ctype'] = $this->request->getPost('type');
           //if($this->request->getPost('type') == 4){
             return view('payment/partial_invoice',$data);
//           }else{
//                 echo 'No Details Found';
//           }
        }
        function loadInvoices(){
            if($this->request->getPost('type') == 4){
                 $inv = $this->billingModel->get_item_name('temp_item_transation_tbl',$where = array('student_id' =>$this->request->getPost('id')));
                 if(count($inv) > 0){
                     echo '<br><center><h6>Pending Bills</h6></center>';
                     echo '<table class="table"><thead>'
                     .'<tr><td>Sn</td>'
                     .'<td>Description</td>'
                     .'<td>Control No</td>'
                     .'<td>Total</td>'
                     . '</tr></thead><tbody>';
                     $sn=1;
                     $total = 0;
                     foreach($inv as $in){
                        $itm = $this->billingModel->get_item_name('items_tbl',$where = array('id' =>$in->item_id));
                         echo '<tr><td>'.$sn++.'</td>';
                         echo '<td>'.$itm[0]->item_name.'</td>';
                         echo '<td>'.$in->reference_no.'</td>';
                         echo '<td>'.number_format($in->unit_price).'</td></tr>';
                         $total+=$in->unit_price;
                     }
                     echo '</tbody><tfoot>';
                     echo '<tr><td colspan="3"></td><td>'.number_format($total);
                     echo '<button class="btn btn-primary btn-sm pull-right" onclick="prepare_invoice('.$in->id.')"><i class="fa fa-plus" aria-hidden="true"></i> Add</button></td></tr></tfoot>';
                 }
            }
        
        }
 function create_invoice(){
    $db = \Config\Database::connect($this->dbname);
    $query = $db->query('SELECT CONCAT(first_name," ",middle_name," ",last_name) as full_name,temp_item_transation_tbl.item_id,items_tbl.item_name,temp_item_transation_tbl.unit_price,temp_item_transation_tbl.quantity,students_application_tbl.id as student_id FROM temp_item_transation_tbl,students_application_tbl,items_tbl where temp_item_transation_tbl.student_id = students_application_tbl.id AND temp_item_transation_tbl.item_id = items_tbl.id AND student_id ='.$this->request->getPost('id').' AND bill_status = 0 ');
      $result = $query->getResult();
    return json_encode($result);
   }
   function invoice_details($trans,$cost){
       $trans_item = $this->studentModel->gettable_data('transaction_numbers_tbl',$where = array('trans_number' =>$trans)); 
       echo '<tr><td>'.$trans_item[0]->trans_number.'</td>';
       echo '<td>'.$trans_item[0]->trans_type_id.'</td>';
       echo '<td>'.$trans_item[0]->trans_date.'</td>';
       echo '<td>'.number_format($cost).'</td>';
       echo '<td>'.number_format($cost).'</td></tr>';
   }
   function generate_transaction_no() {
        $ino = "";
        $tkens = $this->studentModel->get_max_receipt('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
 
 function process_receipt(){
   
      $trans = $this->generate_transaction_no();
      $transaction = [
              'trans_type_id' => 2,
              'trans_number' => $trans,
              'trans_date' => $this->request->getPost('date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s')
      ];
      $trans_id = $this->studentModel->SaveData_n_get_id('transaction_numbers_tbl',$transaction);

      $check_class = $this->studentModel->gettable_data('company_tbl',$where = array('classification' => 1));
        if(count($check_class)>0){
            $classification = [
                'trans_id' => $trans_id,
               'classification_id' => $this->request->getPost('class_type'),
                
                 ];
        $this->studentModel->SaveData('invoice_classification_tbl',$classification);
         }
        $total_cost = 0;
        // $phone = "";
        $phone = $this->request->getPost('phone');
        
        $studentId="";
         $i=0;
         foreach($this->request->getPost('student') as $s)
      {
            $i++;
           // echo $i;
         list($name_type,$student_id) = explode('_',$s);
         $studentId=$student_id;
         if($name_type == 1){
             $payedamount = $this->request->getPost('amount'.$i);
            
            // echo $trno;
              if ($payedamount <= 0){
                 // echo $i;
                    continue;
                }
                 $trno = $this->request->getPost('trans_no'.$i);
                 
                  //added to check year
                 $nyear=date('Y') +1;
                 $next_year = $this->billingModel->get_item_name('payment_request',$where = array('trans_no' => $trno,'trans_type' => 1,"student_id"=>$studentId,"academic_year"=>$nyear));
                  if(count($next_year)>0){
                    $this->make_temporaly_deposit($next_year,$payedamount);
                    $builder = $this->db->table('transaction_numbers_tbl');
                     $builder->where('trans_type_id',2);
                     $builder->where('trans_number',$trans);
                      $builder->delete();
                    return;
                  }

                  //added to check year
                $itm_trans = $this->studentModel->select_inv_id($trno);
                $trans_item=$itm_trans[0]->invoice_type_id;
                $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 2,
             'invoice_type_id' => $itm_trans[0]->invoice_type_id //temp soln
         ];
        $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);
//print_r($invoice_type);
             $db = \Config\Database::connect($this->dbname);
             $result = $db->query('SELECT * FROM  ledger_transaction_tbl  
                                      WHERE name_id = '.$student_id.' AND ledger_type = 7 and name_type_id ='.$name_type.' and trans_no ='.$trno.' AND transation_nature = 2 and trans_type = 1');
                                  $billspending = $result->getResult(); 

             ///*************sum rcpt*******************************
         $inv_no = $this->billingModel->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $trno));
            $total_paid=0;
              $charges=0;
            foreach($inv_no as $no){
              
                $rcpt_am = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2));
                $charged = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 1,'trans_type' => 2,'ledger_id'=>22));
                if(count($charged)>0){
                    $charges=$charges+$charged[0]->amount; 
                }
                if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                    // echo 'rct='.$am->amount;
                    // echo '</br>'; 
                  $total_paid=$total_paid+$am->amount-$charges;
              }
                }
            }
       ///*********************************************

             foreach($billspending as $ledger){
                if($ledger->amount -$total_paid- $payedamount >= 0){
                    $balance = $ledger->amount -$total_paid- $payedamount;
                    //echo $ledger->balance;
                    $amount = $payedamount;
                   
                }else{
                   $balance = 0;
                   $amount = $payedamount;
                  // $payedamount = $payedamount - $ledger->balance;
                }

                $rcledger = [
                       'ledger_id' => $ledger->ledger_id,
                       'ledger_type' => 7,
                       'trans_item' => $trans_item,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $amount,
                       'transation_nature' => 1,
                       'name_type_id' => $name_type,
                       'name_id' => $student_id,
                       'balance' => $balance
                   ];
  //   print_r($rcledger);
               $payid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$rcledger);
///------------------over start paymnet-------------------------//
               if($this->request->getPost('change')>0){
                 $overP = [
                       'ledger_id' => 21,
                       'ledger_type' => 7,
                       'trans_item' => $trans_item,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $this->request->getPost('change'),
                       'transation_nature' => 2,
                       'name_type_id' => $name_type,
                       'name_id' => $student_id,
                       'balance' => $this->request->getPost('change')
                   ];
  //   print_r($rcledger);
               $overpayid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$overP);
               }
///------------------over paymnet-------------------------//

                $balance = array(
                    'balance' => $balance
                );
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $ledger->id),$balance);   
                $relation_transation = [
                       'invoice_trans_no' => $trno,
                       'receipt_trans_no ' => $trans
                         ];
                $this->studentModel->SaveData('transactions_relation',$relation_transation);
                
               //update Control number here ***********************
                $check_control = $this->studentModel->gettable_data('payment_request',$where = array('student_id' => $student_id,'trans_no'=>$trno,'trans_type'=>1));
                if(count($check_control)>0){
                 $this->updateControlNumber($trno,$amount,1);   
                } 
            
               //end update Control number ********************** 
  //   print_r($relation_transation);
                if ($payedamount <= 0){
                    break;
                }
             }
             $student_details = $this->studentModel->gettable_data('students',$where = array('id' => $student_id));
             //***start**check if transport************//
                  $transport = $this->studentModel->gettable_data('transport_details',$where = array('trans_numb' => $trno));
                  if(count($transport)>0){
                     $status = array(
                    'status' => 1
                );
                $this->studentModel->update_table_details('transport_details',$where = array('trans_numb' => $trno),$status);
                  }
           //*****end check if transport************//

                      }
         
}
     $total_amount = 0;
     $credit_amount =0;
     $over_amount=0;
     $reverse_amount=0;
     foreach($this->request->getPost('pay_ledger') as $l){

        $credit=intval($this->request->getPost('credit'.$l));
                
                if($credit>0){
                    $tc=intval($this->request->getPost('totalcredit'));
                    for($c=1;$c<=$tc;$c++){
                       $credit_amount=intval($this->request->getPost('credit_amount'.$c));
                       if($credit_amount>0) {
                        $credit_no=$this->request->getPost('credit_no'.$c);

                        $credit_details = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $credit_no,'trans_type' => 6,'transation_nature' => 1));


                    $balance = array(
                    'balance' => $credit_details[0]->balance - $credit_amount
                           );
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $credit_details[0]->id),$balance);

                $use_relation = [
                    'receipt_no' => $trans,
                    'used_no' => $credit_no,
                    'trans_type' => 6,
                     'amount'=>$credit_amount
                        ];
            $this->studentModel->SaveData('transaction_use_relation_tbl',$use_relation); 
                       }
                    }
               
         }
         if($this->request->getPost('over'.$l)>0){

              $tov=intval($this->request->getPost('totalover'));
                    for($c=1;$c<=$tov;$c++){
                       $over_amount=intval($this->request->getPost('over_amount'.$c));
                       if($over_amount>0) {
                        $over_no=$this->request->getPost('over_no'.$c);

                        $overpayed_details = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $over_no,'trans_type' => 2,'ledger_id' => 21));

                $balance = array(
                    'balance' => $overpayed_details[0]->balance - $over_amount
                           );
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $overpayed_details[0]->id),$balance);

                $use_relation = [
                    'receipt_no' => $trans,
                    'used_no' => $over_no,
                    'trans_type' => 5,
                     'amount'=>$over_amount
                     ];
            $this->studentModel->SaveData('transaction_use_relation_tbl',$use_relation); 
                       }
                    }
                  }

        //processing paid by using deposit below
   if($this->request->getPost('deposit'.$l)>0){

              $tde=$this->request->getPost('totaldeposit');
                    for($c=1;$c<=$tde;$c++){
                     $deposit_amount=intval($this->request->getPost('deposit_amount'.$c));
                       if($deposit_amount>0) {
                        $deposit_no=$this->request->getPost('deposit_no'.$c);

                        $depositpayed_details = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $deposit_no,'trans_type' => 3,'transation_nature' => 2));

                $balance = array(
                    'balance' => $depositpayed_details[0]->balance - $deposit_amount
                           );
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $depositpayed_details[0]->id),$balance);

                $use_relation = [
                    'receipt_no' => $trans,
                    'used_no' => $deposit_no,
                    'trans_type' => 3,
                     'amount'=>$deposit_amount
                     ];
            $this->studentModel->SaveData('transaction_use_relation_tbl',$use_relation); 
                       }
                    }
                  }

//mmmmmmmmmmmmmmmmmm start for reversal receipts mmmmmmmmmmmmmmmmmmmm
$reverse_amount=0;
    if($this->request->getPost('transfer'.$l)>0){

        $revn = $this->generate_reversal_no();
        $reverse_amount=$this->request->getPost('transfer'.$l);
        $reversed_receipt=$this->request->getPost('receipt_number');
      $tran = [
              'trans_type_id' => 7,
              'trans_number' => $revn,
              'trans_date' => $this->request->getPost('date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s')
                 ];
      $this->studentModel->SaveData('transaction_numbers_tbl',$tran);

          $old_inv = $this->studentModel->gettable_data('transactions_relation',$where = array('receipt_trans_no' => $this->request->getPost('receipt_number'))); 
          $o_inv = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('transation_nature' =>2,'trans_no'=>$old_inv[0]->invoice_trans_no,'trans_type'=>1,'ledger_type'=>7)); 

             $old_student_id=$o_inv[0]->name_id;
             $des="School Fee";
            //  echo $o_inv[0]->amount; echo '</br>';
            //   echo $old_student_id; echo '</br>';
            //      echo $o_inv[0]->trans_no; echo '</br>';
          $this->upadate_control($o_inv[0]->balance,$old_student_id,$o_inv[0]->trans_no,$des);
       
         $balance = array(
            'balance' => $o_inv[0]->balance+$this->request->getPost('transfer'.$l)
                     );
            $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $o_inv[0]->id),$balance);
            
              //update Control number here ***********************
                $check_control = $this->studentModel->gettable_data('payment_request',$where = array('student_id' => $old_student_id,'trans_no'=>$o_inv[0]->trans_no,'trans_type'=>1));
                if(count($check_control)>0){
                    $this->updateControlNumber($o_inv[0]->trans_no,$this->request->getPost('transfer'.$l),2);   
                } 
            
               //end update Control number ********************** 

            $rel = [
                'old_receipt_number' => $this->request->getPost('receipt_number'),
                'new_receipt_number' => $trans,
                'trans_type' => 2,
                'reversal_number' => $revn,
                'amount_transfered' =>  $this->request->getPost('transfer'.$l),
                'reasons' =>  $this->request->getPost('reason'),
                'date_created' => date('Y-m-d H:i:s'),
                     ];
            $this->studentModel->SaveData('receipt_transfer_tbl',$rel);

            $old_receipt = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $this->request->getPost('receipt_number'),'trans_type'=>2));
            $r=0; 
            foreach($old_receipt as $old){
                $r++;
                if($r>2){
                   break;
                }else{
                if($old->ledger_type==7){
            $Bl = [
               'ledger_id' => $old->ledger_id,
               'ledger_type' => $old->ledger_type,
               'trans_no' => $revn,
               'trans_type' => 7,
               'amount' => $this->request->getPost('transfer'.$l),
               'transation_nature' =>2,
               'name_type_id' => $old->name_type_id,
               'name_id' => $old->name_id,
           ];

           $this->studentModel->SaveData('ledger_transaction_tbl',$Bl);
         }

          if($old->ledger_type==9){
            $Bl = [
               'ledger_id' => $old->ledger_id,
               'ledger_type' => $old->ledger_type,
               'trans_no' => $revn,
               'trans_type' => 7,
               'amount' => $this->request->getPost('transfer'.$l),
               'transation_nature' =>1,
               'name_type_id' => $old->name_type_id,
               'name_id' => $old->name_id,
           ];

           $this->studentModel->SaveData('ledger_transaction_tbl',$Bl);
         }
        }
       }

    $rev_st_details = $this->studentModel->gettable_data('students',$where = array('id' => $old_student_id));
 $revstudent_parent = $this->studentModel->gettable_data('parents_students_tbl',$where = array('student_id' => $old_student_id));
 if(count($revstudent_parent) > 0){
  $reves_parent_details = $this->studentModel->gettable_data('parents_tbl',$where = array('id' => $revstudent_parent[0]->parent_id));
               if(count($reves_parent_details) > 0){
                    $revphone = $reves_parent_details[0]->phone1;
                }
           }
     $msg = $rev_st_details[0]->first_name.", malipo ya ".$reverse_amount." kutoka Risiti ".$reversed_receipt." yamefutwa kupitia Reversal namba ".$revn.". Ukihitaji maelezo zaidi piga  0755266243.";//temporary

 $messagex="first_name, malipo ya xxx kutoka Risiti xxx yamefutwa kupitia Reversal namba x. Ukihitaji maelezo zaidi piga xxxxxx.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 9,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $revn
                  
                );
    //  message disabled here;
      if($revphone !=""){
$this->studentModel->SaveData('message_groups_tbl',$smsdata);
             $cleanPhone = sanitize_phone($revphone);
if ($cleanPhone) {
    try {
          $this->SMSsender($cleanPhone,$msg,9,$old_student_id,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
     }
 }
//mmmmmmmmmmmmmmmmmm end for reversal receipts mmmmmmmmmmmmmmmmmmmm
                  //processing paid by using deposit above
        $total_amount += $this->request->getPost('amount'.$l);
        $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $l)); 
        list($name_type,$id) = explode('_',$this->request->getPost('bill_payer'));
       
           $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $this->request->getPost('amount'.$l),
               'transation_nature' =>2,
               'name_type_id' => $name_type,
               'name_id' => $id,
           ];

             $chek_lg = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('ledger_id' => $Bank_leger[0]->id,'ledger_type'=>$Bank_leger[0]->account_type_id,'trans_no'=>$trans,'trans_type'=>2,'transation_nature'=>2)); 
         if(count($chek_lg)>0){

         }else{
           $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);
       }
//print_r($Bledger);

           
           if($name_type == 5){
               $parent_details = $this->studentModel->gettable_data('parents_tbl',$where = array('id' => $id));
               if(count($parent_details) > 0){
                    $phone = $parent_details[0]->phone1;
                }
           }
       }
       
        ///mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm/start////
       $db=$this->dbname;
   $invT=$this->payment_model->get_item_name('invoice_type_transaction',$where=array('trans_no'=>$trno,'transaction_type_id'=>1),$db);

//*****Installment Calculations ****************//
  
     
       $allowed=constant('TMSG' . session()->get('db_id'));
       if($phone != "" && $allowed==1){
           $total_amount=$total_amount-$credit_amount -$over_amount;
        if($invT[0]->invoice_type_id==2){
             
                $this->send_balance_msg($trno,$student_id,$db,$phone,2,$total_amount,$trans); 
             
                }else{
                    
       $msg = "Malipo yamekamilika. Risiti:".$trans.", Tarehe:".date('d/m/Y H:i').
                       ", Kiasi:TZS ".number_format($total_amount).", Mwanafunzi:".$student_details[0]->full_name;
                   
        $messagex="Malipo yamekamilika. Risiti: x, Tarehe: d/m/Y H:i, Kiasi:TZS xxx, Mwanafunzi: #student fullname";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 2,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
    //  message disabled here;
   //  if(session()->get('db_id')==1){
$this->studentModel->SaveData('message_groups_tbl',$smsdata);
                   $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
          $this->SMSsender($cleanPhone,$msg,2,$studentId,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
    // }
                }
       }
  $tn = $this->studentModel->gettable_data('transaction_numbers_tbl',$where = array('trans_number' => $trans,'trans_type_id' => 2));
  
  //vfd starts
  $vfd_settngs = $this->studentModel->gettable_data('vfd_settings_tbl',$where = array('status' =>1));
  if(count($vfd_settngs)>0){
     helper('vfd_helper');
      helper('qrcode_helper');
    $total_amount=$total_amount-$over_amount-$credit_amount-$reverse_amount;

     $dbid=session()->get('db_id');
      if($total_amount >0){
   // $result=process_vfd_receipt_now($tn[0]->id,$total_amount,$student_details[0]->full_name,$this->dbname,$dbid);
      }
  }
  //vfd ends
  
   echo json_encode(array('status' => 1,'description' => 'receipt created successful','id' => $tn[0]->id));
    }


//###############################--start of application payment billing controller##################//
    function process_application(){
        $trans= $this->generate_transaction_no();

        $student_id = $this->request->getPost('studentId');
        $payledger=$this->request->getPost('pay_ledger');
        // $amount=$this->request->getPost('amount')
            // print_r($amount);
            // return;
        $transaction = [
            'trans_type_id' => 2,
            'trans_number' => $trans,
            'trans_date' => date('Y-m-d H:i:s'),
            'updated_by' => $this->request->getPost('header_id'),
            'updated_date' => date('Y-m-d H:i:s')
        ];   
        $this->studentModel->SaveData('transaction_numbers_tbl',$transaction);

         $total_cost = 0;
        $temp_id = $this->studentModel->gettable_data('temp_item_transation_tbl',$where = array('student_id' => $student_id,'bill_status'=>0));
            $invoice_id = $student_id;
            foreach($temp_id as $price){
                  $itm = [
                    'item_id' => $price->item_id,
                    'item_type_id' => $price->item_type_id,
                    'trans_number' => $trans,
                    'trans_type' => 2,
                    'quantity ' => $price->quantity,
                    'before_qty' => 0,
                    'after_qty' => 0,
                    'unit_price' => $price->unit_price,
                ];
         $itm_trans = $this->studentModel->SaveData_n_get_id('item_transation_tbl',$itm);
         $leger_items = $this->studentModel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $price->item_id));
                $total_cost+=$price->unit_price * $price->quantity;
                foreach($leger_items as $lg){
                    $legers = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id)); 
                    if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                    continue;
                }
                    $ledger = [
                        'ledger_id' => $lg->account_id,
                        'ledger_type' => $legers[0]->account_type_id,
                        'trans_no' => $trans,
                        'trans_type' => 2,
                        'amount' => $price->unit_price * $price->quantity,
                        'transation_nature' => 1,
                        'name_type_id' => 4,
                        'name_id' => $student_id,
                    ];
                $this->studentModel->SaveData('ledger_transaction_tbl',$ledger); 
                }
                $temptrans = [
                   'bill_status' => 1
                ];
                $this->studentModel->update_table_details('temp_item_transation_tbl',$where = array('id' => $price->id),$temptrans);

                $app = [
                    'application_status' => 0
                ]; 
                $this->studentModel->update_table_details('students_application_tbl',$where = array('id' => $student_id),$app);
            }   
                $student_details = $this->studentModel->gettable_data('students_application_tbl',$where = array('id' => $student_id));
                $phone = $student_details[0]->phone_number;   
                $total_amount = 0;
                 foreach($this->request->getPost('pay_ledger') as $l){
                    $total_amount += $this->request->getPost('amount'.$l);
                    $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $l)); 
                    list($name_type,$id) = explode('_',$this->request->getPost('bill_payer'));
                       $Bledger = [
                           'ledger_id' => $Bank_leger[0]->id,
                           'ledger_type' => $Bank_leger[0]->account_type_id,
                           'trans_no' => $trans,
                           'trans_type' => 2,
                           'amount' => $this->request->getPost('amount'.$l),
                           'transation_nature' => 2,
                           'name_type_id' => $name_type,
                           'name_id' => $id,
                       ];

                       $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);
                       if($name_type == 5){
                           $parent_details = $this->studentModel->gettable_data('parents_tbl',$where = array('id' => $id));
                           $phone = $parent_details[0]->phone1;
                       }
                   }
                   echo json_encode(array('status' => 1,'description' => 'receipt created successful' ));
                   if($phone != ""){
                   $msg = "Malipo yamekamilika. Risiti:".$trans.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($total_amount).", Muombaji:".$student_details[0]->full_name;
                   
                    $messagex="Malipo yamekamilika. Risiti: x, Tarehe: d/m/Y H:i, Kiasi:TZS xxx, Muombaji: #student fullname";
                    
                   $snn = $this->generate_msg_no();
           $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 2,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
        $this->studentModel->SaveData('message_groups_tbl',$smsdata);
               
                                     $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
          $this->SMSsender($cleanPhone,$msg,2,$studentId,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
                   }        

    }
//################ --the end application payment--##################


    function search_payer(){
        $search = $this->request->getPost('payer_name');
        $db = \Config\Database::connect($this->dbname);
        if($this->request->getPost('paid_by') == 1){
            $names= $db->query('SELECT * FROM students 
                          WHERE `id` = \''.$search.'\' OR `full_name` LIKE \'%'.$search.'%\' OR `first_name` LIKE \'%'.$search.'%\' OR `last_name` LIKE \'%'.$search.'%\'');
            $result = $names->getResult();
                   if(count($result) > 0){

            echo
            '<table class="table table-hover">
            <thead>
                 <tr>
                    <th>ID</th>
                    <th>Payer Name</th>
                    <th>Gender</th>
                    <th>Class</th>
                    <th>Stream</th>
                </tr>
            </thead><tbody>';
            foreach ($result as $rsl){
                $std=$this->studentModel->gettable_stdetail($rsl->id);
                if(count($std)>0){
                $fullname = $rsl->first_name.' '.$rsl->last_name;
                echo '<tr><td>'.$rsl->student_id.'</td>';
                echo '<td>'.$fullname.'</td>';
                echo '<td>'.$rsl->gender.'</td>';
                echo '<td>'.$std[0]->class_name.'</td>';
                echo '<td>'.$std[0]->stream_name.'</td>';
                echo '<td><button class="btn btn-primary btn-sm" onclick="select_payer('.$rsl->id.','.$this->request->getPost('paid_by').',\''.$fullname.'\')">select</button></td></tr>';
            }else{
              echo '<tr>';
                echo '<td>'.$rsl->id.'</td>';
                echo '<td>'.$rsl->full_name.'</td>';
                echo '<td style="color:red">Not Admitted</td>';
                echo '</tr>';
            }
            }
            echo '</tbody>';
        }else{
          echo "<span style='color:red'>No any data Found</span>";
        }

        }else if($this->request->getPost('paid_by') == 5){
            $names= $db->query('SELECT * FROM parents_tbl 
                          WHERE `id` = \''.$search.'\' OR `full_name` LIKE \'%'.$search.'%\' OR `first_name` LIKE \'%'.$search.'%\' OR`last_name` LIKE \'%'.$search.'%\'');
            $result2 = $names->getResult();
        
         if(count($result2) > 0){

            echo
            '<table class="table table-hover">
            <thead>
                 <tr>
                    
                    <th>Payer Name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    
                </tr>
            </thead><tbody>';
            foreach ($result2 as $rsl){
                $std=$this->studentModel->gettable_prdetail($rsl->id);
                if(count($std)>0){
                $fullname = $std[0]->first_name.' '.$std[0]->last_name;
                $fullname2 = $std[0]->first_name;
                
                echo '<tr><td>'.$fullname.'</td>';
                echo '<td>'.$std[0]->address.'</td>';
                echo '<td>'.$std[0]->phone1.'</td>';
               
                echo '<td><button class="btn btn-primary btn-sm" onclick="select_payer('.$rsl->id.','.$this->request->getPost('paid_by').',\''.$fullname2.'\')">select</button></td></tr>';
            }
            }
            echo '</tbody>';
        }else{
       echo "<span style='color:red'>No any data Found</span>";
        } 
       } else if($this->request->getPost('paid_by') == 6){
            $names= $db->query('SELECT * FROM other_students_tbl 
                          WHERE `id` = \''.$search.'\' OR `full_name` LIKE \'%'.$search.'%\' OR `first_name` LIKE \'%'.$search.'%\' OR`last_name` LIKE \'%'.$search.'%\'');
            $result2 = $names->getResult();
        
         if(count($result2) > 0){

            echo
            '<table class="table table-hover">
            <thead>
                 <tr>
                    
                    <th>Payer Name</th>
                    <th>Gender</th>
                    <th>Phone</th>
                    
                </tr>
            </thead><tbody>';
            foreach ($result2 as $rsl){
               $fullname = $rsl->first_name.' '.$rsl->last_name;
                
                echo '<tr><td>'.$fullname.'</td>';
                echo '<td>'.$rsl->gender.'</td>';
                echo '<td>'.$rsl->phone.'</td>';
               
                echo '<td><button class="btn btn-primary btn-sm" onclick="select_payer('.$rsl->id.','.$this->request->getPost('paid_by').',\''.$fullname.'\')">select</button></td></tr>';
            
            }
            echo '</tbody>';
        }else{
       echo "<span style='color:red'>No any data Found</span>";
        } 
       }
    }
    function create_invoices_student(){
        $db = \Config\Database::connect($this->dbname);
        $query = $db->query('SELECT CONCAT(first_name," ",middle_name," ",last_name) as full_name,trans_no,sum(amount) as amount,sum(balance) as balance,trans_date,ledger_transaction_tbl.ledger_id FROM students,ledger_transaction_tbl,transaction_numbers_tbl WHERE students.id = ledger_transaction_tbl.name_id AND'
                . ' ledger_transaction_tbl.name_type_id = 1 AND balance != 0 AND ledger_type = 7 AND name_id ='.$this->request->getPost('id').' AND trans_number ='.$this->request->getPost('trans_no').' AND transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no AND trans_type = 1');
              //  . ' ledger_transaction_tbl.name_type_id = 1 AND balance != 0 AND ledger_type = 7 AND name_id ='. $this->request->getPost('student_id'));
        $result = $query->getResult();
        return json_encode($result);
    }
    function create_invoice_student(){
         $parent=$this->studentModel->gettable_data('parents_students_tbl',$where = array('student_id' => $this->request->getPost('id')));
        $db = \Config\Database::connect($this->dbname);
        $result=$this->studentModel->get_student_recept($this->request->getPost('id'));

         $query = $db->query('SELECT * FROM ledger_transaction_tbl WHERE name_id ='.$this->request->getPost('id').' AND trans_type = 6 AND name_type_id = 1 AND transation_nature = 2');
         $results = $query->getResult();
       //  print_r($results);
        $transNos = array();
        foreach ($results as $item) {
            $transNos[] = $item->trans_no;
        }

        // Output the result
        
         if(count($results)>0){
          $results2=$this->studentModel->get_student_credits($transNos);
        
         }else{
          $results2="";  
          }
     // $res = $db->query('SELECT * FROM ledger_transaction_tbl WHERE name_id ='.$this->request->getPost('id').' AND ledger_id = 21 AND trans_item > 0');
         $over = $this->studentModel->get_student_overpayed($this->request->getPost('id'));
        //print_r($over);
         $depno = array();
         $dep=$this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('name_id' => $this->request->getPost('id'),'trans_type'=>3,'transation_nature'=>1));
        foreach ($dep as $idn) {
            $depno[] = $idn->trans_no;
        }
        if(count($dep)>0){
        $dep_res=$this->studentModel->get_student_deposit($depno);
        }else{
           $dep_res=""; 
        }
        
        $response = [
           'parent' => $parent[0]->parent_id??0,
        'result1' => $result,
        'result2' => $results2,
        'result3' => $over,
        'result4' => $dep_res
         ];
         //print_r($response);
        return json_encode($response);
       
    }

  function get_payer_details(){
         $db = \Config\Database::connect($this->dbname);
         list($name_type,$id) = explode('_',$this->request->getPost('payer'));
         if($name_type == 1){
            //$names= $db->query('SELECT * FROM students WHERE id = '.$id);
            $names = $db->query('SELECT CONCAT(first_name," ",middle_name," ",last_name) as full_name, gender, classes_tbl.class_name, streams_tbl.stream_name 
                     FROM students, classes_tbl, streams_tbl, admission_tbl 
                     WHERE students.id = admission_tbl.student_id 
                     AND admission_tbl.class_id = classes_tbl.id 
                     AND students.id = '.$id.' 
                     AND admission_tbl.stream_id = streams_tbl.id 
                     ORDER BY admission_tbl.class_id DESC');
             $rsl = $names->getResult();
             $fullname = $rsl[0]->full_name;
              echo '<div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Payer Name</label>
                <div class="col-sm-8">
                  <input type="text" readonly  class="form-control"  value="'.$fullname.'" >
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Gender</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value="  '.$rsl[0]->gender.'">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Class</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value=" '.$rsl[0]->class_name.'">
                </div>
                </div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Stream</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value="  '.$rsl[0]->stream_name.'">
                </div></div>';
         }
        else if($name_type == 5)
        {
            $names= $db->query('SELECT * FROM parents_tbl WHERE id = '.$id);
             $rsl = $names->getResult();
            if(count($rsl) > 0){ 
           $fullname = $rsl[0]->first_name.' '.$rsl[0]->last_name;
            echo '<div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Payer Name</label>
                <div class="col-sm-8">
                  <input type="text" readonly  class="form-control"  value="'.$fullname.'" >
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Address</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value="  '.$rsl[0]->address.'">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Phone Number</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value=" '.$rsl[0]->phone1.'">
                </div>
                </div>';
        }
        }else if($name_type == 6)
        {
            $names= $db->query('SELECT * FROM other_students_tbl WHERE id = '.$id);
             $rsl = $names->getResult();
            if(count($rsl) > 0){ 
           $fullname = $rsl[0]->first_name.' '.$rsl[0]->last_name;
            echo '<div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Payer Name</label>
                <div class="col-sm-8">
                  <input type="text" readonly  class="form-control"  value="'.$fullname.'" >
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Gender</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value="  '.$rsl[0]->gender.'">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Phone Number</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value=" '.$rsl[0]->phone.'">
                </div>
                </div>';
        }
        }
       
    }
    function SMSsender($dest,$msg,$type,$ref_no,$snn,$show_response=0) {
              $tmsg = $this->studentModel->gettable_data('message_status_tbl',$where = array('status' => 1,));
                  if(count($tmsg)==0){
                   return;   
                  }
             $messag = $this->sytm_model->load_messages_balances();

                 $time_sent = time();
                 
                 $senderid=constant('SENDER_ID_' . session()->get('db_id'));
                 
                 if($senderid){
              $username=SMS_UNAME;
             $password=SMS_PASSWORD;
                 }else{
                     return;
                 }
              $destination = preg_replace('/[^0-9]/', '', $dest);
             $message = rawurlencode(trim($msg));
             $senderid = urlencode($senderid);
        //   $fetch=file_get_contents("https://www.sms.co.tz/api.php?do=sms&username={$username}&password={$password}&senderid={$senderid}&dest={$destination}&msg={$message}");
        $api_key=API_KEY;
        
         try {
 $fetch=file_get_contents("https://www.sms.co.tz/api.php?do=sms&api_key={$api_key}&senderid={$senderid}&dest={$destination}&msg={$message}");
    } catch (\Throwable $e) {
        // log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
        return;
    }
        
      
           
            list($status, $note, $smsid) = explode(',', $fetch);
            if($show_response == 2){
              echo '<th>Message status:</th>';
              echo '<td><i>' . $note . '</i></td>';
            }
            if ($status == 'OK') {
                $msgid = $smsid;
                $snt_status = 1;    // Message sent successfully
                $cost = 45;
                $acc_cost = $cost;
                if($type!=2){
                echo 'Message sent successfully';
                  }  
            } else {
                $msgid = '';
                $snt_status = 2;    // Message just sent 
                $cost = 45;
                $acc_cost = $cost;
            }

           $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
          
            $this->studentModel->SaveData('messages',$tempsmsdata);
          //  echo 'msg saved';

            $balance = ($messag[0]->balance - $acc_cost);

          $smsDt = array(
                'balance' => $balance,
                'created_at' => date('Y/m/d H:i:s')
            );
            $this->sytm_model->update_sms_balance($smsDt, $messag[0]->b_id);

          //  curl_close($curl);
     // echo 'successful sent';
    }

  function SMSsender2($dest,$msg,$type,$ref_no,$snn,$show_response=0,$dbid) {
        $tmsg = $this->studentModel->gettable_data('message_status_tbl',$where = array('status' => 1,));
                  if(count($tmsg)==0){
                   return;   
                  }
         $username=SMS_UNAME;
            $password=SMS_PASSWORD;
           $senderid = constant('SENDER_ID_' . $dbid);
            $db=constant('DB' . $dbid);
            
             $messag = $this->payment_model->load_messages_balances($db);

             $time_sent = time();
            //   $destination=str_replace('-', '', $dest);
            //  $message=urlencode($msg);
                $destination = preg_replace('/[^0-9]/', '', $dest);
            $message = rawurlencode(trim($msg));
             $senderid = urlencode($senderid);
          $fetch=file_get_contents("https://www.sms.co.tz/api.php?do=sms&username={$username}&password={$password}&senderid={$senderid}&dest={$destination}&msg={$message}");
           
            list($status, $note, $smsid) = explode(',', $fetch);
            if($show_response == 2){
              echo '<th>Message status:</th>';
              echo '<td><i>' . $note . '</i></td>';
            }
            if ($status == 'OK') {
                $msgid = $smsid;
                $snt_status = 1;    // Message sent successfully
                $cost = 45;
                $acc_cost = $cost;
                if($type!=2){
                echo 'Message sent successfully';
                  }  
            } else {
                $msgid = '';
                $snt_status = 2;    // Message just sent 
                $cost = 45;
                $acc_cost = $cost;
            }

            
                $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
            
               
            $this->payment_model->SaveData('messages',$tempsmsdata,$db);
          //  echo 'msg saved';

            $balance = ($messag[0]->balance - $acc_cost);

          $smsDt = array(
                'balance' => $balance,
                'created_at' => date('Y/m/d H:i:s')
            );
            $this->payment_model->update_sms_balance($smsDt, $messag[0]->b_id,$db);

          //  curl_close($curl);
     // echo 'successful sent';
    }

    function receiverPayment(){
       $returned_respo = json_decode(trim(file_get_contents('php://input')), TRUE);
        file_put_contents('Apifeedback/' . $returned_respo['reference'] . '.txt', file_get_contents('php://input'));
        // if ($this->authentication($returned_respo['api_key'],$returned_respo['api_secret']) == TRUE) {
            $check_ref=$this->studentModel->gettable_data('payment_request',$where = array('reference_no' => $returned_respo['reference']));
            $check_ref2=$this->studentModel->gettable_data('payment_request',$where = array('reference_no' => $returned_respo['reference'],'payment_status' => 1,'allow_partial' => 1));
           $check_payment=$this->studentModel->gettable_data('payment_response',$where = array('transaction_receipt' => $returned_respo['receipt']));
            if(count($check_payment)> 0 && $check_ref[0]->payment_status == 1){
                 echo json_encode(array('status' => 0, 'description' => 'Transaction receipt number already received'));
                 return;
            }elseif(count($this->studentModel->gettable_data('payment_response',$where = array('reference_no' => $returned_respo['reference']))) > 0 && $check_ref[0]->allow_partial == 0){
                echo json_encode(array('status' => 0, 'description' => 'Transaction reference number already paid'));
                 return;
            }else{
                echo json_encode(array('status' =>1,'description' =>'Success')); 

                $data = array(
                    'payment_status' => 1
                );

                $this->studentModel->update_table_details('payment_request',$where = array('id' => $check_ref[0]->id),$data);

                $payed_amount = (int)$returned_respo['amount'];

                $resp_data = array(
                    'reference_no' => $returned_respo['reference'],
                    'amount_payed' => $payed_amount,
                    'transaction_receipt' => $returned_respo['receipt'],
                    'transaction_date' => $returned_respo['timestamp'],
                    'customer_name' => $returned_respo['customer_name'],
                    'account_no' => $returned_respo['account_number'],
                    'transaction_channel' => $returned_respo['channel']??""
              );

              $payId = $this->studentModel->SaveData_n_get_id('payment_response',$resp_data);

              $this->process_receipt_nmb($check_ref[0]->student_id,$check_ref[0]->trans_no,$payed_amount,$payId);

//               $receipt=$this->studentModel->gettable_data('parents_tbl',$where = array('id' => $check_ref[0]->student_id));

              $msg = "Malipo yamekamilika. Risiti:".$returned_respo['receipt'].", Ombi namba:".$check_ref[0]->student_id.", Tarehe:".date('d/m/Y H:i').

                      ", Kiasi:TZS ".number_format($returned_respo['amount']).", Muombaji:".$receipt[0]->first_name." ". $receipt[0]->last_name.", Mhamala:".$returned_respo['reference'];

$this->SMSsender($receipt[0]->phone_number,$msg,1,$returned_respo['reference']);
        $cleanPhone = sanitize_phone($receipt[0]->phone_number);
if ($cleanPhone) {
    try {
 $this->SMSsender($receipt[0]->phone_number,$msg,1,$returned_respo['reference']);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}

                

            }

         

      // } 

    }

    function process_receipt_nmb($student_id,$inv_no,$payedamount,$payId){

      $trans = $this->generate_transaction_no();
      $transaction = [
              'trans_type_id' => 2,
              'trans_number' => $trans,
              'trans_date' => date('Y-m-d H:i:s'),
              'updated_by' => 2,
              'updated_date' => date('Y-m-d H:i:s')
      ];

      $this->studentModel->SaveData('transaction_numbers_tbl',$transaction); 
        $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 2,
             'invoice_type_id' => 1 //temp soln
         ];
         $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);
         $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('account_type_id' => 9)); 
             $Bledger = [
                 'ledger_id' => $Bank_leger[0]->id,
                 'ledger_type' => $Bank_leger[0]->account_type_id,
                 'trans_no' => $trans,
                 'trans_type' => 2,
                 'amount' => $payedamount,
                 'transation_nature' => 2,
                 'name_type_id' => 1,
                 'name_id' => $student_id,
             ];
         $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);
         $paymentresp = array(
             'system_receipt_no' => $trans
         );
         $this->studentModel->update_table_details('payment_response ',$where = array('id' => $payId),$paymentresp); 
         $billspending = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $inv_no,'ledger_type' => 7));
         foreach($billspending as $ledger){
                if($ledger->balance - $payedamount > 0){
                    $balance = $ledger->balance - $payedamount;
                    $amount = $payedamount;
                    $payedamount = $payedamount - $ledger->balance;
                }else{
                   $balance = 0;
                   $amount = $ledger->balance;
                   $payedamount = $payedamount - $ledger->balance;
                }
                $rcledger = [
                       'ledger_id' => $ledger->ledger_id,
                       'ledger_type' => 7,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $amount,
                       'transation_nature' => 1,
                       'name_type_id' => 1,
                       'name_id' => $student_id,
                       'balance' => $balance
                   ];
                $payid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$rcledger);
                $balance = array(
                    'balance' => $balance
                );
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $ledger->id),$balance);   
                $relation_transation = [
                       'invoice_trans_no' => $ledger->id,
                       'receipt_trans_no ' => $payid
                         ];
                $this->studentModel->SaveData('transactions_relation',$relation_transation);
            if ($payedamount <= 0){
                    break;
                }
             }
    }
function receipt2(){
        $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            
            $data = array(
               'trans' => $this->billingModel->get_item_name2('transaction_numbers_tbl',$where = array('trans_type_id' => 2),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))
            );
           echo view('payment/receipt2',$data);
    }
 function pay_application($id){
    $data = array(
           'trans' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('trans_type_id' => 2))
        );
        $data['stid']=$id;
  return view('payment/pay_application',$data);
   
}
function loadCustomer(){
  $db = \Config\Database::connect($this->dbname);
   $parent=$this->studentModel->gettable_data('parents_students_tbl',$where = array('student_id' => $this->request->getPost('id')));
        $customer_type= $this->request->getPost('type');
        $id= $this->request->getPost('id');
         if($customer_type == 1){
            $names= $db->query('SELECT * FROM students WHERE id = '.$id);
            } elseif($customer_type == 6){
           $names= $db->query('SELECT * FROM other_students_tbl WHERE id = '.$id);
         } 
             $rsl = $names->getResult();
            //  $fullname = '<div class="form-group row">
            //     <label for="staticEmail" class="col-sm-4 col-form-label">Customer Name</label>
            //     <div class="col-sm-8">
            //       <input type="text" readonly class="form-control-plaintext" id="staticEmail" value="'.$rsl[0]->full_name.'">
            //     </div></div>';

               $response=[
                   'parent'=>$parent[0]->parent_id,
                   'fullname'=>$rsl[0]->full_name,
              ];
              return json_encode($response);
            
         
}   
function deposit(){
            $data = array(
               'trans' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('trans_type_id' => 3))
            );
            return view('templates/header')
            .view('payment/deposit',$data)
            .view('templates/footer');   
        }
        function deposit2(){
          //  echo 'here';
        $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            
            $data = array(
               'trans' => $this->billingModel->get_updated_date('transaction_numbers_tbl',$where = array('trans_type_id' => 3,'status' => 1),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))
            );
          // print_r($data);
           echo view('payment/deposit2',$data);
    }

      function deposit3(){
          //  echo 'here';
        $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            
            $data = array(
               'trans' => $this->billingModel->get_item_name2('transaction_numbers_tbl',$where = array('trans_type_id' => 3,'status' => 2),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))
            );
           // print_r($data);
           echo view('payment/deposit3',$data);
    }
    function view_deposit($id){
            $data = array(
               'recpt' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('id' =>$id))
            );
            return view('payment/deposit_detailed',$data);
        }
         function edit_receipt_details($id){
            $data = array(
               'recpt' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('id' =>$id))
            );
            return view('payment/receipt_detailed_edit',$data);
        }

        function select_invoice_student(){
        $db = \Config\Database::connect($this->dbname);
        $trans=$this->request->getPost('trans');
        $builder = $db->query('SELECT * FROM transactions_relation WHERE receipt_trans_no ='.$this->request->getPost('trans').'');
         $inv = $builder->getResult();


        $result=$this->studentModel->select_student_recept($this->request->getPost('id'),$inv[0]->invoice_trans_no);
             //for credit
        $quer = $db->query('SELECT * FROM transaction_use_relation_tbl WHERE receipt_no ='.$this->request->getPost('trans').' AND trans_type = 6');
         $results_used = $quer->getResult();
          
          //for overpayment
          $quered = $db->query('SELECT * FROM transaction_use_relation_tbl WHERE receipt_no ='.$this->request->getPost('trans').' AND trans_type = 5');
         $results_used3 = $quered->getResult();

       //for deposit
         $depused = $db->query('SELECT * FROM transaction_use_relation_tbl WHERE receipt_no ='.$this->request->getPost('trans').' AND trans_type = 3');
         $results_deposited = $depused->getResult();

       $query = $db->query('SELECT * FROM ledger_transaction_tbl WHERE name_id ='.$this->request->getPost('id').' AND trans_type = 6 AND name_type_id = 1 AND transation_nature = 2');
         $results = $query->getResult();
       //  print_r($results);
        $transNos = array();
        foreach ($results as $item) {
            $transNos[] = $item->trans_no;
        }

        // Output the result
        
         if(count($results)>0){
          $results2=$this->studentModel->get_student_credits($transNos);
        
         }else{
          $results2="";  
          }

    $over = $this->studentModel->get_student_overpayed($this->request->getPost('id'));
        //print_r($result);
    ///-deposit--
     $depno = array();
         $dep=$this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('name_id' => $this->request->getPost('id'),'trans_type'=>3,'transation_nature'=>1));
        foreach ($dep as $idn) {
            $depno[] = $idn->trans_no;
        }
        if(count($dep)>0){
        $dep_res=$this->studentModel->get_student_deposit($depno);
        }else{
           $dep_res=""; 
        }
        //print_r($results2);
           $response = [
        'result1' => $result,
        'result2' => $results2,
        'result3' => $over,
        'result4' => $dep_res,
        'resulted' => $results_used,
        'resulted3' => $results_used3,
        'resulted4' => $results_deposited,
         ];
        return json_encode($response);
    }

      function search_customer_details(){
            $data['search'] = $this->request->getPost('cust_name');
            $data['ctype'] = $this->request->getPost('type');
           //if($this->request->getPost('type') == 4){
             return view('payment/pending_details',$data);
//           }else{
//                 echo 'No Details Found';
//           }
        }

function update_receipt(){

      $trans = $this->request->getPost('rno');

      $transaction = [
              'trans_type_id' => 2,
              'trans_number' => $trans,
              'trans_date' => $this->request->getPost('date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s')
      ];
    
       $this->studentModel->update_table_details('transaction_numbers_tbl',$where = array('trans_number' => $trans,'trans_type_id' => 2),$transaction);
 //     print_r($transaction);
        $total_cost = 0;
          
         $i=0;
         foreach($this->request->getPost('student') as $s)
     {
            $i++;
            //echo $i;
         list($name_type,$student_id) = explode('_',$s);
         if($name_type == 1){
             $payedamount = $this->request->getPost('amount'.$i);

             $trno = $this->request->getPost('trans_no'.$i);
             // echo $trno;
             // echo '/';
             // echo $trans;
              if ($payedamount <= 0){
                 // echo $i;
                    continue;
                }
                $itm_trans = $this->studentModel->select_inv_id($trno);
                $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 2,
             'invoice_type_id' => $itm_trans[0]->invoice_type_id 
         ];
     $check = $this->billingModel->get_item_name('invoice_type_transaction',$where = array('trans_no' =>$trans,'transaction_type_id' =>2,'invoice_type_id' =>$itm_trans[0]->invoice_type_id));
 // echo count($check);
      if(count($check)==0){
     $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);
      }
        
//print_r($invoice_type);
             $db = \Config\Database::connect($this->dbname);
               $resultz = $db->query('SELECT * FROM  ledger_transaction_tbl  
                                      WHERE name_id = '.$student_id.' AND ledger_type = 7 and name_type_id ='.$name_type.' and trans_no ='.$trans.' AND transation_nature = 1 and trans_type = 2');
             $bills = $resultz->getResult(); 
             
             $result = $db->query('SELECT * FROM  ledger_transaction_tbl  
                                      WHERE name_id = '.$student_id.' AND ledger_type = 7 and name_type_id ='.$name_type.' and trans_no ='.$trno.' AND transation_nature = 2 and trans_type = 1');
             $billspending = $result->getResult(); 
            //  echo '.........';
           //  print_r($billspending);
            //   echo '.........';
             foreach($billspending as $ledger){
/////////////////////////////////////////////////////////////////////////////////////
             $relation_transation = [
                       'invoice_trans_no' => $trno,
                       'receipt_trans_no ' => $trans
                         ];

        $check2 = $this->billingModel->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $trno,'receipt_trans_no' => $trans));
        // echo count($check2);
      if(count($check2)==0){
            $this->studentModel->SaveData('transactions_relation',$relation_transation);

                if($ledger->balance - $payedamount > 0){
                    $balance = $ledger->balance - $payedamount;
                    //echo $ledger->balance;
                    $amount = $payedamount;
                   // $payedamount = $payedamount - $ledger->balance;
                }else{
                   $balance = 0;
                   $amount = $ledger->balance;
                   $payedamount = $payedamount - $ledger->balance;
                }
      }else{
         $paid=$bills[0]->amount;
 // //        echo $payedamount;
 //         echo $payedamount;
 //             echo '/';
            $inv_no = $this->billingModel->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $trno));
            $total_paid=0;
            foreach($inv_no as $no){
                
                $rcpt_am = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2));
                if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                    // echo 'rct='.$am->amount;
                    // echo '</br>'; 
                  $total_paid=$total_paid+$am->amount;
              }
                }
            }
           
           // $now_paid=$total_paid -$paid+$payedamount;
            //echo 'Arledy tpaid= '.$now_paid.' paid today='.$payedamount.' paid= '.$paid;
                // echo 'deni='.($ledger->amount-$total_paid);
                //     echo 'paid='.$paid;
                //     echo 'today='.$payedamount;
                //     echo '</br>'; 
            $balance = ($ledger->amount - $total_paid-$payedamount)+$paid;
                    //echo $ledger->balance;
                $amount = $payedamount;
                  //  echo 'balance= '.$balance;
                // echo '</br>';
                
      }  
  //  print_r($relation_transation);
////////////////////////////////////////////////////////////////////////////////////////                

               
                $rcledger = [
                       'ledger_id' => $ledger->ledger_id,
                       'ledger_type' => 7,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $amount,
                       'transation_nature' => 1,
                       'name_type_id' => $name_type,
                       'name_id' => $student_id,
                       'balance' => $balance
                   ];
  //print_r($rcledger);
        if(count($check2)==0){
             //$payid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$rcledger);
            }else{
              $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' =>$bills[0]->id),$rcledger); 
               
           }

                $balance = array(
                    'balance' => $balance
                );
        $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $ledger->id),$balance);   
    ///----------------------------------------------------------------------->


          ///------------------over start paymnet-------------------------//
               if($this->request->getPost('change')>0){
                 $check_over = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('ledger_type' => 7,'ledger_id' => 21,'trans_no' => $trans,'transation_nature' => 2,'trans_type' => 2,'name_id'=>$student_id,'trans_item !=' => 0));
                 $overP = [
                       'ledger_id' => 21,
                       'ledger_type' => 7,
                       'trans_item' => 2,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $this->request->getPost('change'),
                       'transation_nature' => 2,
                       'name_type_id' => $name_type,
                       'name_id' => $student_id,
                       'balance' => $this->request->getPost('change')
                   ];
  //   print_r($rcledger);
             if(count($check_over)>0){
              $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $check_over[0]->id),$overP); 
                   }else{
               $overpayid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$overP);
                }
               }
///------------------over paymnet-------------------------//      
  //   print_r($relation_transation);
               
             }
             $student_details = $this->studentModel->gettable_data('students',$where = array('id' => $student_id));
                      }
        
}
     $total_amount = 0;
     $nn=0;
     $n=0;
     if($this->request->getPost('pay_ledger')==""){

     }else{
     foreach($this->request->getPost('pay_ledger') as $l){
        $n=1;
        //********************update credit note--*********************************
             $credit=$this->request->getPost('credit'.$l);
                
                if($credit>0){
                    $tc=$this->request->getPost('totalcredit');
                    for($c=1;$c<=$tc;$c++){
                       $credit_amount=$this->request->getPost('credit_amount'.$c);
                       if($credit_amount>0) {
                        $credit_no=$this->request->getPost('credit_no'.$c);

                        $credit_details = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $credit_no,'trans_type' => 6,'transation_nature' => 1));

                       $paid_details = $this->studentModel->gettable_data('transaction_use_relation_tbl',$where = array('receipt_no' => $trans,'used_no' => $credit_no,'trans_type' => 6));
                       if(count($paid_details)>0){
                         $paid_det=$paid_details[0]->amount; 
                       }else{
                           $paid_det=0;
                       }

                    $balance = array(
                    'balance' => $credit_details[0]->balance +$paid_det - $credit_amount
                           );
                    
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $credit_details[0]->id),$balance);

                $use_relation = [
                    'receipt_no' => $trans,
                    'used_no' => $credit_no,
                    'trans_type' => 6,
                     'amount'=>$credit_amount
                        ];

         $check_relation = $this->studentModel->gettable_data('transaction_use_relation_tbl',$where = array('receipt_no' => $trans,'used_no' => $credit_no,'trans_type' => 6));

         if(count($check_relation)>0){
             $this->studentModel->update_table_details('transaction_use_relation_tbl',$where = array('id' => $check_relation[0]->id),$use_relation);
         }else{
           $this->studentModel->SaveData('transaction_use_relation_tbl',$use_relation);  
         }

            
                       }
                    }
               
         }
        //*****************end update credit note*************************************************

        //*************start update over payment*************************************************
           if($this->request->getPost('over'.$l)>0){

              $tov=$this->request->getPost('totalover');
                    for($c=1;$c<=$tov;$c++){
                       $over_amount=$this->request->getPost('over_amount'.$c);
                       if($over_amount>0) {
                        $over_no=$this->request->getPost('over_no'.$c);

                        $overpayed_details = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $over_no,'trans_type' => 2,'ledger_id' => 21));
                        $paid_detail = $this->studentModel->gettable_data('transaction_use_relation_tbl',$where = array('receipt_no' => $trans,'used_no' => $over_no,'trans_type' => 5));
                       if(count($paid_detail)>0){
                         $paid_d=$paid_detail[0]->amount; 
                       }else{
                           $paid_d=0;
                       }

                $balance = array(
                    'balance' => $overpayed_details[0]->balance +$paid_d- $over_amount
                           );
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $overpayed_details[0]->id),$balance);

                 

                $use_relation = [
                    'receipt_no' => $trans,
                    'used_no' => $over_no,
                    'trans_type' => 5,
                     'amount'=>$over_amount
                     ];
                $check_relat = $this->studentModel->gettable_data('transaction_use_relation_tbl',$where = array('receipt_no' => $trans,'used_no' => $over_no,'trans_type' => 5));

              if(count($check_relat)>0){
             $this->studentModel->update_table_details('transaction_use_relation_tbl',$where = array('id' => $check_relat[0]->id),$use_relation);
         }else{
           $this->studentModel->SaveData('transaction_use_relation_tbl',$use_relation);  
         }  
             
                       }
                    }
                  }
        //************end update  over payment************************************************
        
        $total_amount += $this->request->getPost('amount'.$l);
        $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $l)); 

          $resultzs = $db->query('SELECT * FROM  ledger_transaction_tbl  
                                      WHERE trans_no ='.$trans.' AND transation_nature = 2 and trans_type = 2');
             $bil = $resultzs->getResult();
        if($this->request->getPost('bill_payer')==""){
          
             $name_type=$bil[0]->name_type_id;
             $id=$bil[0]->name_id;

        }else{
        list($name_type,$id) = explode('_',$this->request->getPost('bill_payer'));

          }
           $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $this->request->getPost('amount'.$l),
               'transation_nature' => 2,
               'name_type_id' => $name_type,
               'name_id' => $id,
           ];

    if($n==1 && $nn!=$l){
        $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' =>$bil[0]->id),$Bledger);
        $nn=$l; 
     }else{
   //  $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);
     }

       }
   }
       echo json_encode(array('status' => 1,'description' => 'receipt updated successful'));
     
        }

  function deposit_edit($id){
            $data = array(
               'deposit' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('id' =>$id))
            );
            return view('payment/deposit_edit',$data);
        }

        function credit_note(){
            $data = array(
                'trans' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('trans_type_id' => 6))
            );
            return view('templates/header')
            .view('payment/credit_note_view',$data)
            .view('templates/footer');   
        }

         function view_note_details($id){
            $data = array(
               'inv' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('id' =>$id))
            );
            return view('payment/note_detailed',$data);
        }
          function print_note($id){
            $data = array(
               'trans' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' =>$id))
            );
            return view('payment/note_PrintOut',$data);
        } 
        function edit_credit_note_details($invID){
            $data = array(
                'inv' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('id' =>$invID))
            );
            return view('payment/edit_credit_note',$data);
        }
   function get_student_details(){
         $db = \Config\Database::connect($this->dbname);
         $id=$this->request->getPost('payer');
         $name_type=$this->request->getPost('nametype');
         if($name_type == 1){
            //$names= $db->query('SELECT * FROM students WHERE id = '.$id);
            $names = $db->query('SELECT CONCAT(first_name," ",middle_name," ",last_name) as full_name,gender,classes_tbl.class_name,streams_tbl.stream_name FROM students,classes_tbl,streams_tbl,admission_tbl WHERE students.id = admission_tbl.student_id AND'
               . ' admission_tbl.class_id = classes_tbl.id  AND students.id ='.$id.' AND admission_tbl.stream_id = streams_tbl.id ');
             $rsl = $names->getResult();
         $fullname = $rsl[0]->full_name;

               $phone = $db->query('SELECT phone1 FROM parents_tbl,parents_students_tbl WHERE parents_tbl.id = parents_students_tbl.parent_id AND'
               . ' parents_tbl.bill_account = 1  AND parents_students_tbl.student_id ='.$id.'');
             $pn = $phone->getResult();
             $phone=0;
             if(count($pn)>0){
                 $phone=$pn[0]->phone1;
             }
            
              echo '<div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Student Name</label>
                <div class="col-sm-8">
                  <input type="text" readonly  class="form-control"  value="'.$fullname.'" >
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Phone</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control" name="phone" value="  '.$phone.'">
                </div></div>';
         }
        else if($name_type == 5)
        {
            $names= $db->query('SELECT * FROM parents_tbl WHERE id = '.$id);
             $rsl = $names->getResult();
            if(count($rsl) > 0){ 
           $fullname = $rsl[0]->first_name.' '.$rsl[0]->last_name;
            echo '<div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Payer Name</label>
                <div class="col-sm-8">
                  <input type="text" readonly  class="form-control"  value="'.$fullname.'" >
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Address</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value="  '.$rsl[0]->address.'">
                </div></div>
                <div class="form-group row">
                <label for="staticEmail" class="col-sm-4 col-form-label">Phone Number</label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control"  value=" '.$rsl[0]->phone1.'">
                </div>
                </div>';
        }
        }
       
    }
    function get_student_balance_message(){
        $id=$this->request->getPost('id');
        $name_type=$this->request->getPost('nametype');
        $data['student_id']=$id;
        $data['name_type']=$name_type;
        $data['year']=$this->request->getPost('year');
      echo view('system/student_message',$data);  
    }

    function message_balance(){
        $send_type=$this->request->getPost('send_type');
         $student_id=$this->request->getPost('student_id');
        $msg_type=$this->request->getPost('msg_type');
        $phone=$this->request->getPost('phone');
        $message=$this->request->getPost('message');
        $user=$this->request->getPost('header_id');
        $msg_date=$this->request->getPost('invoice_date');

     if($msg_type==3){
        $messagex=$this->request->getPost('msgblc');  
      }elseif($msg_type==4){
        $messagex=$this->request->getPost('msgbtdy');
      }
        
        
       $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => $send_type,
                    'message_type' => $msg_type,
                    'send_number' => $snn,
                    'massage_date' =>  date('Y-m-d H:i:s'),
                    'send_by' => $user,
                    'messagex' => $messagex,
                  
                );
    //  print_r( $message);
$this->studentModel->SaveData('message_groups_tbl',$smsdata);
                 $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
  $this->SMSsender($cleanPhone,$message,$msg_type,$student_id,$snn,$show_response=0);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
    }

    function message_group(){
        $data['msg_type']=$this->request->getPost('msgtpy');
        $data['date']= $this->request->getPost('date');
            
       echo view('system/message_balance_list',$data);   
    }

    function message_balance_groupwise(){
         $type=$this->request->getPost('msg_type');
         $user=$this->request->getPost('header_id');
         $msg_date=$this->request->getPost('invoice_date');
         if($type==3){
           $messagex=$this->request->getPost('msgblc');
       }elseif($type==4){
            $messagex=$this->request->getPost('msgbtdy');
       }elseif($type==16){
            $messagex=$this->request->getPost('custom_message');
            
       }
           $send_type=$this->request->getPost('send_type');
         $snn = $this->generate_msg_no();
         $smsdata = array(
                    'send_type' => $send_type,
                    'message_type' => $type,
                    'send_number' => $snn,
                    'massage_date' =>  date('Y-m-d H:i:s'),
                    'send_by' => $user,
                    'messagex' => $messagex,
                   );
       //  print_r( $smsdata);
        $this->studentModel->SaveData('message_groups_tbl',$smsdata);
         $i=0;
          if($type==3){
   
  foreach($this->request->getPost('selected') as $s)
        {
      $phone=$this->request->getPost('phone'.$s.'');
        $message=$this->request->getPost('message'.$s.'');
       $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
   $this->SMSsender($cleanPhone,$message,$type,$s,$snn,$show_response=0);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ');
}  
      }  
      
    }else if($type==16){
        foreach($this->request->getPost('selected') as $s)
        {
      $phone=$this->request->getPost('phone'.$s.'');
      $student_name=$this->request->getPost('studentName'.$s.'');
      $message=$this->request->getPost('message'.$s.'');
      
        // $message=$this->request->getPost('custom_message');

    //   if (strpos($message, "#studentFirstName") !== false) {
        
    //   $message = str_replace("#studentFirstName", $student_name, $message);
                $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
     $this->SMSsender($cleanPhone,$message,$type,$s,$snn,$show_response=0); 
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
        // }    
      }  

    }
    
    else{
     foreach($this->request->getPost('student') as $s)
        {
      $phone=$this->request->getPost('phone'.$s.'');
        $message=$this->request->getPost('message'.$s.'');
              
                               $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
      $this->SMSsender($cleanPhone,$message,$type,$s,$snn,$show_response=0);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
      }   
    }
       echo '1';

    }
    function SMSs(){
       // echo 'Message sent successfully';
    }
  function get_student_message(){
        $id=$this->request->getPost('sid');
        $data['student_id']=$id;
         echo view('system/birthday_message',$data);    
        
 }
function student_birthday(){
  $dt=$this->request->getPost('date');
   $data['date']=$dt;  
 echo view('system/birthday_students',$data);     
}

 function generate_msg_no() {
        $ino = "";
        $tkens = $this->studentModel->get_max_id('message_groups_tbl','send_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }

   function find_receipt_ledger(){
    $db = \Config\Database::connect($this->dbname);
    $query = $db->query('SELECT ledger_id,amount,trans_item,balance FROM ledger_transaction_tbl where transation_nature=2 AND trans_no ='.$this->request->getPost('trans').' AND trans_type = 2 ');
      $result = $query->getResult();
    return json_encode($result);
   } 

   function delete_receipt($id){
    //echo $id;
     $detail=$this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('id' => $id));
     $inv=$this->billingModel->get_item_name('transactions_relation',$where = array('receipt_trans_no' => $detail[0]->trans_number));

      $inv_ledger=$this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $inv[0]->invoice_trans_no,'trans_type' => 1,'transation_nature' => 2,'ledger_type' => 7));

       $rct_amount=$this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $detail[0]->trans_number,'trans_type' => 2,'transation_nature' => 1,'ledger_type' => 7,'name_type_id' => 1));
       $ttl=0;
       foreach($rct_amount as $am){
        $ttl+=$am->amount;
       }
        
        ///*************sum rcpt*******************************
         $inv_no = $this->billingModel->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $inv[0]->invoice_trans_no));
            $total_paid=0;
            foreach($inv_no as $no){
                
                $rcpt_am = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2));
                if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                    // echo 'rct='.$am->amount;
                    // echo '</br>'; 
                  $total_paid=$total_paid+$am->amount;
              }
                }
            }
       ///*********************************************
         $balance = array(
                    'balance' => $inv_ledger[0]->amount-$total_paid +$ttl
                         );
         // echo $inv_ledger[0]->amount-$total_paid +$ttl;
         // echo '</br>';
         // echo $ttl;
          
         $rct_use=$this->billingModel->get_item_name('transaction_use_relation_tbl',$where = array('receipt_no' => $detail[0]->trans_number));

      $dlt=$this->billingModel->deleteReceipt($id,$detail[0]->trans_number);
      if($dlt){
        $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $inv_ledger[0]->id),$balance);

        if(count($rct_use)>0){
        foreach($rct_use as $amt)
        {
        if($amt->trans_type==6){

           $use_amt=$this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $amt->used_no,'trans_type'=>6,'transation_nature'=>1));
           $balance = array(
                    'balance' => $use_amt[0]->balance +$amt->amount
                         );
            $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $use_amt[0]->id),$balance);

        }else{

       $use_amt=$this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $amt->used_no,'trans_type'=>2,'ledger_id'=>21,'transation_nature'=>2));
       if(count($use_amt)>0){
          $balance = array(
                    'balance' => $use_amt[0]->balance +$amt->amount
                         );
            $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $use_amt[0]->id),$balance);  
       }
          
            }
       }
       }
     echo "echo deleted successfully";
    }else{
        echo "Not Deleted successfully";
    }
}

function update_delete_rcpt(){

     $trans=$this->request->getPost('rno');
     $detail=$this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('trans_number' => $trans,'trans_type_id'=>2));
     $id= $detail[0]->id;
     $inv=$this->billingModel->get_item_name('transactions_relation',$where = array('receipt_trans_no' => $detail[0]->trans_number));

      $inv_ledger=$this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $inv[0]->invoice_trans_no,'trans_type' => 1,'transation_nature' => 2,'ledger_type' => 7));

       $rct_amount=$this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $detail[0]->trans_number,'trans_type' => 2,'transation_nature' => 1,'ledger_type' => 7,'name_type_id' => 1));
       $ttl=0;
       foreach($rct_amount as $am){
        $ttl+=$am->amount;
       }

         ///*************sum rcpt*******************************
         $inv_no = $this->billingModel->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $inv[0]->invoice_trans_no));
            $total_paid=0;
            foreach($inv_no as $no){
                
                $rcpt_am = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2));
                if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                    // echo 'rct='.$am->amount;
                    // echo '</br>'; 
                  $total_paid=$total_paid+$am->amount;
              }
                }
            }
       ///*********************************************
         $balance = array(
                    'balance' => $inv_ledger[0]->amount-$total_paid +$ttl
                         );
            
         $rct_use=$this->billingModel->get_item_name('transaction_use_relation_tbl',$where = array('receipt_no' => $detail[0]->trans_number));

       $dlt=$this->billingModel->deleteReceipt($id,$detail[0]->trans_number);
      if($dlt){
        $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $inv_ledger[0]->id),$balance);

        if(count($rct_use)>0){
        foreach($rct_use as $amt)
        {
        if($amt->trans_type==6){

           $use_amt=$this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $amt->used_no,'trans_type'=>6,'transation_nature'=>1));
           $balance = array(
                    'balance' => $use_amt[0]->balance +$amt->amount
                         );
            $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $use_amt[0]->id),$balance);

        }elseif($amt->trans_type==3){
       $use_amt=$this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $amt->used_no,'trans_type'=>3,'transation_nature'=>2));
           $balance = array(
                    'balance' => $use_amt[0]->balance +$amt->amount
                         );
            $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $use_amt[0]->id),$balance);
        }
         else{

       $use_amt=$this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $amt->used_no,'trans_type'=>2,'ledger_id'=>21,'transation_nature'=>1));
           $balance = array(
                    'balance' => $use_amt[0]->balance +$amt->amount
                         );
            $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $use_amt[0]->id),$balance);
            }
       }
       }
   
    }else{
       
    }
    $this->insert_updated_rcpt();
}

function insert_updated_rcpt(){
    $trans=$this->request->getPost('rno');
  
$transaction = [
              'trans_type_id' => 2,
              'trans_number' => $trans,
              'trans_date' => $this->request->getPost('date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s')
      ];
      $this->studentModel->SaveData('transaction_numbers_tbl',$transaction); 
        $total_cost = 0;
        // $phone = "";
        $phone = $this->request->getPost('phone');
        
        $studentId="";
         $i=0;
         foreach($this->request->getPost('student') as $s)
      {
            $i++;
           // echo $i;
         list($name_type,$student_id) = explode('_',$s);
         $studentId=$student_id;
         if($name_type == 1){
             $payedamount = $this->request->getPost('amount'.$i);
             $trno = $this->request->getPost('trans_no'.$i);
             //echo $trno;
              if ($payedamount <= 0){
                 // echo $i;
                    continue;
                }
                $itm_trans = $this->studentModel->select_inv_id($trno);
                $trans_item=$itm_trans[0]->invoice_type_id;
                $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 2,
             'invoice_type_id' => $itm_trans[0]->invoice_type_id //temp soln
         ];
        $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);
//print_r($invoice_type);
             $db = \Config\Database::connect($this->dbname);
             $result = $db->query('SELECT * FROM  ledger_transaction_tbl  
                                      WHERE name_id = '.$student_id.' AND ledger_type = 7 and name_type_id ='.$name_type.' and trans_no ='.$trno.' AND transation_nature = 2 and trans_type = 1');
                                $billspending = $result->getResult();

      ///*************sum rcpt*******************************
         $inv_no = $this->billingModel->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $trno));
            $total_paid=0;
            foreach($inv_no as $no){
                
                $rcpt_am = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2));
                if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                    // echo 'rct='.$am->amount;
                    // echo '</br>'; 
                  $total_paid=$total_paid+$am->amount;
              }
                }
            }
       ///*********************************************

             foreach($billspending as $ledger){
                if($ledger->amount -$total_paid- $payedamount >= 0){
                    $balance = $ledger->amount -$total_paid- $payedamount;
                    //echo $ledger->balance;
                    $amount = $payedamount;
                   
                }else{
                   $balance = 0;
                   $amount = $payedamount;
                   $payedamount = $payedamount - $ledger->balance;
                }
                $rcledger = [
                       'ledger_id' => $ledger->ledger_id,
                       'ledger_type' => 7,
                       'trans_item' => $trans_item,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $amount,
                       'transation_nature' => 1,
                       'name_type_id' => $name_type,
                       'name_id' => $student_id,
                       'balance' => $balance
                   ];
  //   print_r($rcledger);
               $payid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$rcledger);
///------------------over start paymnet-------------------------//
               if($this->request->getPost('change')>0){
                 $overP = [
                       'ledger_id' => 21,
                       'ledger_type' => 7,
                       'trans_item' => $trans_item,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $this->request->getPost('change'),
                       'transation_nature' => 2,
                       'name_type_id' => $name_type,
                       'name_id' => $student_id,
                       'balance' => $this->request->getPost('change')
                   ];
  //   print_r($rcledger);
               $overpayid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$overP);
               }
///------------------over paymnet-------------------------//

                $balance = array(
                    'balance' => $balance
                );
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $ledger->id),$balance);   
                $relation_transation = [
                       'invoice_trans_no' => $trno,
                       'receipt_trans_no ' => $trans
                         ];
                $this->studentModel->SaveData('transactions_relation',$relation_transation);
  //   print_r($relation_transation);
                if ($payedamount <= 0){
                    break;
                }
             }
             $student_details = $this->studentModel->gettable_data('students',$where = array('id' => $student_id));
             //***start**check if transport************//
                  $transport = $this->studentModel->gettable_data('transport_details',$where = array('trans_numb' => $trno));
                  if(count($transport)>0){
                     $status = array(
                    'status' => 1
                );
                $this->studentModel->update_table_details('transport_details',$where = array('trans_numb' => $trno),$status);
                  }
           //*****end check if transport************//

                      }
       
        }
     $total_amount = 0;
     foreach($this->request->getPost('pay_ledger') as $l){

        $credit=$this->request->getPost('credit'.$l);
                
                if($credit>0){
                    $tc=$this->request->getPost('totalcredit');
                    for($c=1;$c<=$tc;$c++){
                       $credit_amount=$this->request->getPost('credit_amount'.$c);
                       if($credit_amount>0) {
                        $credit_no=$this->request->getPost('credit_no'.$c);

                        $credit_details = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $credit_no,'trans_type' => 6,'transation_nature' => 1));


                    $balance = array(
                    'balance' => $credit_details[0]->balance - $credit_amount
                           );
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $credit_details[0]->id),$balance);

                $use_relation = [
                    'receipt_no' => $trans,
                    'used_no' => $credit_no,
                    'trans_type' => 6,
                     'amount'=>$credit_amount
                        ];
            $this->studentModel->SaveData('transaction_use_relation_tbl',$use_relation); 
                       }
                    }
               
         }
         if($this->request->getPost('over'.$l)>0){

              $tov=$this->request->getPost('totalover');
                    for($c=1;$c<=$tov;$c++){
                       $over_amount=$this->request->getPost('over_amount'.$c);
                       if($over_amount>0) {
                        $over_no=$this->request->getPost('over_no'.$c);

                        $overpayed_details = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $over_no,'trans_type' => 2,'ledger_id' => 21));

                $balance = array(
                    'balance' => $overpayed_details[0]->balance - $over_amount
                           );
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $overpayed_details[0]->id),$balance);

                $use_relation = [
                    'receipt_no' => $trans,
                    'used_no' => $over_no,
                    'trans_type' => 5,
                     'amount'=>$over_amount
                     ];
            $this->studentModel->SaveData('transaction_use_relation_tbl',$use_relation); 
                       }
                    }
                  }

                  //deposit added below
                  if($this->request->getPost('deposit'.$l)>0){

              $tde=$this->request->getPost('totaldeposit');
                    for($c=1;$c<=$tde;$c++){
                     $deposit_amount=$this->request->getPost('deposit_amount'.$c);
                       if($deposit_amount>0) {
                        $deposit_no=$this->request->getPost('deposit_no'.$c);

                        $depositpayed_details = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $deposit_no,'trans_type' => 3,'transation_nature' => 2));

                $balance = array(
                    'balance' => $depositpayed_details[0]->balance - $deposit_amount
                           );
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $depositpayed_details[0]->id),$balance);

                $use_relation = [
                    'receipt_no' => $trans,
                    'used_no' => $deposit_no,
                    'trans_type' => 3,
                     'amount'=>$deposit_amount
                     ];
            $this->studentModel->SaveData('transaction_use_relation_tbl',$use_relation); 
                       }
                    }
                  }

                  //processing paid by using deposit above

        $total_amount += $this->request->getPost('amount'.$l);
        $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $l)); 
        list($name_type,$id) = explode('_',$this->request->getPost('bill_payer'));
       
           $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $this->request->getPost('amount'.$l),
               'transation_nature' =>2,
               'name_type_id' => $name_type,
               'name_id' => $id,
           ];

           $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);
//print_r($Bledger);

       }
       
      
   echo json_encode(array('status' => 1,'description' => 'receipt updated successful' ));
}

function bank(){
            $data = array(
                'trans' => $this->billingModel->get_item_name('transaction_numbers_tbl',$where = array('trans_type_id' => 6))
            );
            return view('templates/header')
            .view('payment/bank_payments_view',$data)
            .view('templates/footer');   
        }

        function load_bank_transactions(){
            $thedate=$this->request->getPost('thedate');
            $ledger=$this->request->getPost('ledger');
            $trans=$this->request->getPost('trans');
            $inv=$this->request->getPost('inv');
            $status=$this->request->getPost('status');
            //echo $thedate;
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. '23:59:59');
            $sdate = strtotime($startingdate);
            
            $data = array(
               'trans' => $this->billingModel->get_bank_transactions(date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate),$ledger,$trans,$inv,$status)
            );
           echo view('payment/bank_results_view',$data);
        }

        function view_pyment_details($id){
            $data = array(
               'recpt' => $this->billingModel->get_item_name('payment_request',$where = array('reference_no' =>$id))
            );
            return view('payment/control_number_details',$data);
        }

     public function load_bank_receipt(){
             $thedate=$this->request->getPost('thedate');
            $channel=$this->request->getPost('Channel');
            $ctrtype=$this->request->getPost('Control_type');
         
            //echo $thedate;
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. '23:59:59');
            $sdate = strtotime($startingdate);
            
            $data = array(
               'trans' => $this->billingModel->get_bank_receipt(date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate),$channel,$ctrtype)
            );
            //print_r($data);
           echo view('payment/bank_receipt_list',$data);
        }

      
function test_cronjpobs(){
   $output = shell_exec("/usr/local/bin/php /home/advamhwe/econnect.advaensure.co.tz/index.php BillingController automatic_run 1");
 echo "<pre>$output</pre>";
echo shell_exec('timedatectl');
//echo sha1('m11');
}
 
 public function automatic_run($id) {
    // echo "Billing automation running\n";
  $dbn = constant('DB' . $id);
        $db = \Config\Database::connect($dbn);
        $date=date('Y-m-d');
     $dated=date('-m-d',strtotime($date));
    
         $names= $db->query('SELECT * FROM students 
              WHERE `birth_date` = \''.$date.'\' OR`birth_date`LIKE \'%'.$dated.'\' AND `status`=2');
                $result = $names->getResult();
            //     print_r($result);
            //   return;
                //msg setting
                 $messagex="Happy Birthday# Student first Name. Wishing you a very happy birthday filled with many achievements and success!";
              //  $messagex='testing';
              $snn = $this->generate_msg_no_2($dbn);
         $smsdata = array(
                    'send_type' => 2,
                    'message_type' => 4,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => 10,
                    'messagex' => $messagex
                   );
       
    
   print_r($smsdata);
    if(count($result)>0){
         $this->payment_model->SaveData('message_groups_tbl',$smsdata,$dbn);
    foreach($result as $s)
        {
      
      $parent=$this->payment_model->get_item_name('parents_students_tbl',$where = array('student_id' =>$s->id),$dbn);
      $p_phone=$this->payment_model->get_item_name('parents_tbl',$where = array('id' =>$parent[0]->parent_id),$dbn);

        $phone=$p_phone[0]->phone1;
        $message="Happy Birthday ".$s->first_name.". Wishing you a very happy birthday filled with many achievements and success!";
        
      //  echo $phone.' /'.$message.' /'.$s->id.'</br>';
       
                                    $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
      $this->SMSsender2($cleanPhone,$message,4,$s->id,$snn,$show_response=0,$id);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
       
   
       }

      }          //end msg setting
     }
function send_installment_messages(){
     
         $user=$this->request->getPost('header_id');
         $msg_date=$this->request->getPost('invoice_date');
         $send_type=$this->request->getPost('send_type');
         $messagex="#student first_name, Kumb No: #control number, 1st - xxx/- kabla ya #duedate, 2nd - xxx/- kabla ya #duedate, 3rd - xxx/- kabla ya #duedate. Ada #Year.";
         
            foreach($this->request->getPost('selected') as $s)
        {
      $snn = $this->generate_msg_no();
         $smsdata = array(
                    'send_type' => $send_type,
                    'message_type' => 8,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => $user,
                    'messagex' => $messagex,
                    'trans_number'=>$this->request->getPost('trans'.$s.'')
                   );
      //   print_r( $smsdata);
     

        $phone=$this->request->getPost('phone'.$s.'');
        $message=$this->request->getPost('message'.$s.'');
       // echo $phone;echo $message;echo '</br>';
        if($phone==""){
         continue; 
        }else{
               $this->studentModel->SaveData('message_groups_tbl',$smsdata);
            
         $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
       $this->SMSsender($cleanPhone,$message,8,$s,$snn,$show_response=0);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
        }
        }
   } 
function process_transfer_receipt(){
   
      $trans = $this->generate_transaction_no();
      $transaction = [
              'trans_type_id' => 2,
              'trans_number' => $trans,
              'trans_date' => date('Y-m-d H:i:s'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s')
                 ];
      $this->studentModel->SaveData('transaction_numbers_tbl',$transaction); 
        $total_cost = 0;
        // $phone = "";
       $studentId="";
         $i=0;

           $payedamount = $this->request->getPost('amount');
             $trno = $this->request->getPost('invoice_number');
             //echo $trno;
             
                $itm_trans = $this->studentModel->select_inv_id($trno);
                $trans_item=$itm_trans[0]->invoice_type_id;
                $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 2,
             'invoice_type_id' => $itm_trans[0]->invoice_type_id //temp soln
         ];
        $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);
//print_r($invoice_type);
        $stuid = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $trno,'name_type_id'=>1));
        $student_id=$stuid[0]->name_id;

             $db = \Config\Database::connect($this->dbname);
             $result = $db->query('SELECT * FROM  ledger_transaction_tbl  
                                      WHERE name_id = '.$student_id.' AND ledger_type = 7 and name_type_id ='.$name_type.' and trans_no ='.$trno.' AND transation_nature = 2 and trans_type = 1');
                                  $billspending = $result->getResult(); 

             ///*************sum rcpt*******************************
         $inv_no = $this->billingModel->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $trno));
            $total_paid=0;
            if(count($inv_no)>0){
            foreach($inv_no as $no){
                $charges=0;
                $rcpt_am = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2));
                $charged = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 1,'trans_type' => 2,'ledger_id'=>22));
                if(count($charged)>0){
                    $charges=$charged[0]->amount; 
                }
                if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                    // echo 'rct='.$am->amount;
                    // echo '</br>'; 
                  $total_paid=$total_paid+$am->amount-$charges;
              }
                }
            }
        }

        foreach($billspending as $ledger){
                if($ledger->amount -$total_paid- $payedamount >= 0){
                    $balance = $ledger->amount -$total_paid- $payedamount;
                    //echo $ledger->balance;
                    $amount = $payedamount;
                   
                }else{
                   $balance = 0;
                   $amount = $payedamount;
                  // $payedamount = $payedamount - $ledger->balance;
                }

                $rcledger = [
                       'ledger_id' => $ledger->ledger_id,
                       'ledger_type' => 7,
                       'trans_item' => $trans_item,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $amount,
                       'transation_nature' => 1,
                       'name_type_id' => 1,
                       'name_id' => $student_id,
                       'balance' => $balance
                   ];
  //   print_r($rcledger);
               $payid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$rcledger);
///------------------over start paymnet-------------------------//
              
///------------------over paymnet-------------------------//

                $balance = array(
                    'balance' => $balance
                );
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $ledger->id),$balance);   
                $relation_transation = [
                       'invoice_trans_no' => $trno,
                       'receipt_trans_no ' => $trans
                         ];
                $this->studentModel->SaveData('transactions_relation',$relation_transation);
  //   print_r($relation_transation);
                
             }

               $lid = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $this->request->getPost('receipt_number'),'ledger_type'=>9,'trans_type'=>2));
              // $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $l)); 
        
       
           $Bledger = [
               'ledger_id' => $lid[0]->ledger_id,
               'ledger_type' => $lid[0]->ledger_type,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $this->request->getPost('amount'),
               'transation_nature' =>2,
               'name_type_id' => $lid[0]->name_type_id,
               'name_id' => $lid[0]->name_id,
           ];

           $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);

}
 function generate_reversal_no() {
        $ino = "";
        $tkens = $this->studentModel->get_max_reversal('transaction_numbers_tbl','trans_number',7);
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
    public function update_bill_manually(){
  $total_cost=2017000; 
  $student_id=187; 
  $transNo=1612;
  $des="School Fee";
  $this->upadate_control($total_cost,$student_id,$transNo,$des);  
}
  public function upadate_control($total_cost,$student_id,$transNo,$des){
    $curl=base_url().CRDB_CALLBACK_1;
    $charge=1180;
    $desc=$des.' : '.$total_cost.' Bank charges : '.$charge;
     $student_details = $this->studentModel->gettable_data('students',$where = array('id' => $student_id));
      $data=array(
            'name' =>$student_details[0]->full_name,
            'receipt_no' => $transNo,
            'amount' => $total_cost+$charge,
            'currency' => 'TZS',
            'payment_desc' => $desc,
            'visit_no'=>$student_id,
            'file_no'=>$student_id,
            'payment_channel' => 1,
            'facility_id' => FACILITY_ID_1,
            'payment_type' => PAYMENT_TYPE_1,
            'prefix' => PREFIX_1,
            'call_back_url' => $curl,
            'allow_partial' => 'FLEXIBLE'

        );
       // print_r($data); 

          $url = CRDB_URL_1."updateInvoice";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
               // echo $response;
                $err = curl_error($ch); 
                curl_close($ch);
                ////dealing with response
            if ($err || $response=="") {
                    //echo "Error #:" . $err;
                    $status = 5;
                    $reference=0;
                     $time=date('Y-m-d H:i:s');

                    //  echo json_encode(array('status' =>1,'statusDesc' => ' fail to update. '.$student_details[0]->full_name.''));
                } else {
                   
                    $obj2 = json_decode($response,TRUE);
                    if($obj2['status']=='success'){
                      $status = 1;
                    }else{
                       $status = 2;
                    }
                    $time=$obj2['date_created'];
                    
                    $reference= $obj2['paymentReference'];
                
                $crdb_data = array(
                    'trans_no' =>  $transNo,
                    'student_id' =>  $student_id,
                    'reference_no' => $reference,
                    'amount' => $total_cost,
                    'charges' => $charge,
                    'payment_status' => 0,
                    'payment_channel' => 3, //CRDB
                    'date_created' => $time,
                    
                 );
            //print_r($crdb_data);
                $this->studentModel->update_table_details('payment_request',$where = array('reference_no' => $reference),$crdb_data); 
     

 }
                ////////////////////////
}
function test_blc_msg(){
//$this->send_balance_msg(1356,476,'advamhwe_elimu_db','0747672438',2,99250,4024);
}

function send_balance_msg($trno,$student_id,$db,$phone,$inv,$total_amount,$tnumber){
     helper('calc');
  $get_yr = $this->payment_model->gettable_data('transaction_numbers_tbl',$where = array('trans_number' => $trno,'trans_type_id' => 1),$db);
$year=date('Y',strtotime($get_yr[0]->trans_date));

$cld=$this->payment_model->get_item_name('admission_tbl',$where=array('student_id'=>$student_id,'academic_year'=>$year),$db);
$adm_id=$cld[0]->class_id;
$level_id=$cld[0]->level_id;
$hst=$cld[0]->admission_type;

$lvtbl = $this->billingModel->get_item_name('class_level_tbl', $where = array('id' => $level_id));

  $tinvoice = $this->payment_model->get_total_invoice_amount($student_id,$year,$db); 
  $dbc = \Config\Database::connect($db);
  $results=findCalc($student_id,$db,$year);
   $dateterm = $this->payment_model->checkTerm_date(date('Y-m-d'),$year,$db,$lvtbl[0]->academic_type);
                 
                  //print_r($dateterm);
                 if (is_countable($dateterm) && count($dateterm) > 0) {
                    $term_name=$dateterm[0]->term_name;
                   }else{
                    $dateterm = $this->payment_model->checkTerm_date2(date('Y-m-d'),$year,$db,$lvtbl[0]->academic_type);
                     
                     $term_name=$dateterm[0]->term_name;
                   }

                   $installments =$this->payment_model->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$lvtbl[0]->academic_type),$db);
                    
                    $ttlAmount = 0;
                     $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                      $ddate="";
                    foreach ($installments as $r) {
                        $paid_amount=0;
                    
                     $i++;
                    
                    
                     if($i==1){
                      $openingbalance=$results[0]['openingbalance'];
                       $ment=$results[0]['ment'];
                        $mbalance=$results[0]['mbalance'];
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[0]['today']==1){
                       $todaybalance=$results[0]['todaybalance']; 
                     }
                  
                     }
                      if($i==2){
        
                          $ment=$results[1]['ment'];
                        $mbalance=$results[1]['mbalance'];
                        $paid_amount=$results[1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[1]['today']==1){
                       $todaybalance=$results[1]['todaybalance']; 
                     } 
                     }
                   if($i==3){

                      $ment=$results[2]['ment'];
                        $mbalance=$results[2]['mbalance'];
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[2]['today']==1){
                       $todaybalance=$results[2]['todaybalance']; 
                     }
                     }
                     
                      if($i==4){

                      $ment=$results[3]['ment'];
                        $mbalance=$results[3]['mbalance'];
                        $paid_amount=$results[3]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[3]['today']==1){
                       $todaybalance=$results[3]['todaybalance']; 
                     }
                     }
                    
                 }
             
    //***end istallment calculations***//
  ///mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm/////
        $student_details = $this->studentModel->gettable_data('students',$where = array('id' => $student_id));
       if($phone != ""){
           
        if($inv==2){
            if($todaybalance < 0){
                $todaybal=0;
            }else{
               $todaybal=$todaybalance;  
            }
             if($mbalance < 0){
                $mbalance=0;
            }
                    $msg = $student_details[0]->first_name.", Malipo yamekamilika. Risiti:".$tnumber.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($total_amount).". Baki- (".$term_name.") - ".number_format($todaybal).". Baki kuu ".number_format($mbalance);
                }else{
       $msg = "Malipo yamekamilika. Risiti:".$tnumber.", Tarehe:".date('d/m/Y H:i').
                       ", Kiasi:TZS ".number_format($total_amount).", Mwanafunzi:".$student_details[0]->full_name;
                   }
        $messagex="Malipo yamekamilika. Risiti: x, Tarehe: d/m/Y H:i, Kiasi:TZS xxx, Mwanafunzi: #student fullname";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 2,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' => $this->request->getPost('header_id'),
                    'messagex' => $messagex,
                    'trans_number' => $tnumber
                  
                );
    //  message disabled here;
        if(session()->get('db_id')==3){
            
}else{
  //  echo $msg;
  $data=array(
      'phone'=>$phone,
       'msg'=>$msg,
        'stid'=>$student_id,
        'snn'=>$snn
      );
    //print_r($data);
$this->studentModel->SaveData('message_groups_tbl',$smsdata);
          $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
        $this->SMSsender($cleanPhone,$msg,2,$student_id,$snn,NULL);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $phone);
}
}
     
}  
}


function fetch_creditNote(){
     $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            
             $data = array(
                'trans' => $this->billingModel->get_updated_date('transaction_numbers_tbl',$where = array('trans_type_id' => 6,'status' => 1),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))
            );
           // print_r($data);
           echo view('payment/credit_note_list',$data);
}
function generate_msg_no_2($db) {
        $ino = "";
        $tkens = $this->payment_model->get_max_id('message_groups_tbl','send_number',$db);
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
    
      function updateControlNumber($trans,$amount,$type){
     $db_id=session()->get('db_id');
   if($db_id==1)
      {
           
         $facility_id=FACILITY_ID_1;
         $crdb_url=CRDB_URL_1;
}
elseif($db_id==4)
{
        $facility_id=FACILITY_ID_4;
         $crdb_url=CRDB_URL_4;
   }else{
    
    return;
   }

   $data=array(
            'receipt_no' => $trans,
            'amount' => $amount,
            'facility_id' => $facility_id,
            'type' => $type,
            );
       // print_r($data); 

          $url = $crdb_url."updateInvoice";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                //echo $response;
                $err = curl_error($ch); 
                curl_close($ch);
    }
    
    function DeleteCreditNote($id){

 $note_details = $this->studentModel->gettable_data('transaction_numbers_tbl',$where = array('id' => $id));
 if(count($note_details)>0){
      $dlt=$this->billingModel->deleteCreditNote($id,$note_details[0]->trans_number);
      echo 1;

 }else{
   echo 2; 
 }

    }
    
     function update_invoice_balance(){
        $student_id=$this->request->getPost('student_id');
        $transNo=$this->request->getPost('transNo');
        $balance=$this->request->getPost('due');
          
          if($balance <0){
            $balance=0;  
          }
        $ledgerBalance = array(
                    'balance' => $balance
                );
         $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('trans_no' =>$transNo,'name_id'=>$student_id,'trans_type'=>1,'transation_nature'=>2,'name_type_id'=>1),$ledgerBalance);

         $invoiceHeader = $this->studentModel->get_item_name('transaction_numbers_tbl',$where=array('trans_number'=>$transNo,'trans_type_id'=>1));
         if(count($invoiceHeader)>0){
            $year = date('Y', strtotime($invoiceHeader[0]->trans_date));
            $studentBalance = array(
                'year'=>$year,
                'student_id'=>$student_id,
                'balance'=>$balance>0 ? 0 : $balance,
                'present_debit'=>$balance>0 ? $balance : 0,
                'debted_inv_no'=>$transNo,
            );
            $existingBalance = $this->studentModel->get_item_name('student_balance_tbl',$where=array('student_id'=>$student_id,'year'=>$year));
            if(count($existingBalance)>0){
                $this->studentModel->update_table_details('student_balance_tbl', array('student_id'=>$student_id,'year'=>$year), $studentBalance);
            }else{
                $this->studentModel->SaveData('student_balance_tbl', $studentBalance);
            }
         }
                echo "success";
    }

function make_deposit_to_receipt(){
    $year=date('Y');
    if($year==2026){
       
    }else{
        return;
    }
    //return;
   $invoice = $this->billingModel->admitted_invoices('deposit_receipt_tbl','invoice_number'); 
    $i=0;  
    if(count($invoice)==0){
     return;   
    }
   foreach($invoice as $inv){
   //  echo $inv->invoice_number.'</br>';
    $deposit=$this->billingModel->get_item_name('deposit_receipt_tbl',$where = array('invoice_number' =>$inv->invoice_number,));
   
        foreach($deposit as $dp){
            //echo $dp->deposit_number.'</br>'; 
           
             $i++;
        if($dp->receipt_number != 0){
                continue;
             }
         $trans = $this->generate_transaction_no();
      $transaction = [
              'trans_type_id' => 2,
              'trans_number' => $trans,
              'trans_date' => date('Y-m-d H:i:s'),
              'updated_by' => 10,
              'updated_date' => date('Y-m-d H:i:s')
      ];
     // print_r($transaction);echo "</br>";
     $this->studentModel->SaveData('transaction_numbers_tbl',$transaction); 
        $total_cost = 0;

         $rct = array(
                    'receipt_number' => $trans
                );
        $this->studentModel->update_table_details('deposit_receipt_tbl',$where = array('deposit_number' => $dp->deposit_number),$rct);  

        // $phone = "";
       // $phone = $this->request->getPost('phone');
         $payedamount = $dp->amount;
            
             //echo $payedamount;
              if ($payedamount <= 0){
                 // echo $i;
                    continue;
                }
                 $trno = $inv->invoice_number;
                $itm_trans = $this->studentModel->select_inv_id($trno);
                $trans_item=$itm_trans[0]->invoice_type_id;
                $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 2,
             'invoice_type_id' => $itm_trans[0]->invoice_type_id //temp soln
         ];
     //    print_r($invoice_type);echo "</br>";
        $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);

         $db = \Config\Database::connect($this->dbname);
         $name_type=1;
             $result = $db->query('SELECT * FROM  ledger_transaction_tbl  
             WHERE ledger_type = 7 and name_type_id ='.$name_type.' and trans_no ='.$trno.' AND transation_nature = 2 and trans_type = 1');
              $billspending = $result->getResult(); 

             ///*************sum rcpt*******************************
         $inv_no = $this->billingModel->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $trno));
            $total_paid=0;
            foreach($inv_no as $no){
                $charges=0;
                $rcpt_am = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2));
                $charged = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 1,'trans_type' => 2,'ledger_id'=>22));
                if(count($charged)>0){
                    $charges=$charged[0]->amount; 
                }
                if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                    // echo 'rct='.$am->amount;
                    // echo '</br>'; 
                  $total_paid=$total_paid+$am->amount-$charges;
              }
                }
            }

            ///*********************************************
               $overpay_amount=0;
             foreach($billspending as $ledger){
                if($ledger->amount -$total_paid- $payedamount >= 0){
                    $balance = $ledger->amount -$total_paid- $payedamount;
                    //echo $ledger->balance;
                    $amount = $payedamount;
                   
                }else{
              $overpay_amount=($total_paid+ $payedamount)-$ledger->amount;
                   $balance = 0;
                   $amount = $payedamount;
                  // $payedamount = $payedamount - $ledger->balance;
                }
                   $student_id=$ledger->name_id;
                $rcledger = [
                       'ledger_id' => $ledger->ledger_id,
                       'ledger_type' => 7,
                       'trans_item' => $trans_item,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $amount,
                       'transation_nature' => 1,
                       'name_type_id' => $name_type,
                       'name_id' => $student_id,
                       'balance' => $balance
                   ];
//     print_r($rcledger);echo "</br>";
              $payid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$rcledger);
///------------------over start paymnet-------------------------//
               if($overpay_amount >0){
                 $overP = [
                       'ledger_id' => 21,
                       'ledger_type' => 7,
                       'trans_item' => $trans_item,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $overpay_amount,
                       'transation_nature' => 2,
                       'name_type_id' => $name_type,
                       'name_id' => $student_id,
                       'balance' => $overpay_amount
                   ];
  //   print_r($overP);echo "</br>";
               $overpayid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$overP);
               }
///------------------over paymnet-------------------------//

                $balance = array(
                    'balance' => $balance
                );
               $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $ledger->id),$balance);   
                $relation_transation = [
                       'invoice_trans_no' => $trno,
                       'receipt_trans_no ' => $trans
                         ];
                  //       print_r($relation_transation);echo "</br>";
                $this->studentModel->SaveData('transactions_relation',$relation_transation);

             }

             //processing paid by using deposit below
      
                    
                     $deposit_amount=$dp->amount;
                       if($deposit_amount>0) {
                        $deposit_no=$dp->deposit_number;

                        $depositpayed_details = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $deposit_no,'trans_type' => 3,'transation_nature' => 2));

                $balance = array(
                    'balance' => $depositpayed_details[0]->balance - $deposit_amount
                           );
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $depositpayed_details[0]->id),$balance);

                $use_relation = [
                    'receipt_no' => $trans,
                    'used_no' => $deposit_no,
                    'trans_type' => 3,
                     'amount'=>$deposit_amount
                     ];
               //       print_r($use_relation);echo "</br>";
            $this->studentModel->SaveData('transaction_use_relation_tbl',$use_relation); 
                       }
                    
         $total_amount = $dp->amount;

         $lg_acc = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $deposit_no,'trans_type' => 3,'transation_nature' => 1,'ledger_id !='=>22));
         $l=$lg_acc[0]->ledger_id;
        $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $l)); 
        $name_type=$depositpayed_details[0]->name_type_id;
        $id=$depositpayed_details[0]->name_id;
        
       $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $dp->amount,
               'transation_nature' =>2,
               'name_type_id' => $name_type,
               'name_id' => $id,
           ];
        //   print_r($Bledger);echo "</br>";
         $chek_lg = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('ledger_id' => $Bank_leger[0]->id,'ledger_type'=>$Bank_leger[0]->account_type_id,'trans_no'=>$trans,'trans_type'=>2,'transation_nature'=>2)); 
         if(count($chek_lg)>0){

         }else{
          $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);
       }    

        // if($name_type == 5){
        //       $parent_details = $this->studentModel->gettable_data('parents_tbl',$where = array('id' => $id));
        //       if(count($parent_details) > 0){
        //             $phone = $parent_details[0]->phone1;
        //         }
        //   }     
       //the lst
        }
   } 
   echo json_encode(array('status' => 1,'description' => 'receipt created successful' ));
}

public function exportReceiptToExcel()
    {
        // Fetch data to export

        $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            $year=date('Y', $enddate);
            
            $trans = $this->billingModel->get_item_name2('transaction_numbers_tbl',$where = array('trans_type_id' => 2),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
            $data[]=['RECEIPT LISTS'];
            $data[] = ['invoice Number', 'Student Name', 'Class','Receipt Number','Amount','Receipt Date','Bank Name'];
          
    if(count($trans) >0){
       foreach($trans as $s){
         $student_name = "";
        $student_id = "";
        $control_number = "";
        $name_type = "";
        $amount =0;
        $chargesb=0;
        $leger_transaction = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type' =>2));
        $bank = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type' =>2,'ledger_type'=>9));
        if(count($bank)==0){
            continue;
        }
        $bank_charges = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type' =>2,'ledger_id' =>22,'transation_nature' =>1));
            $rct_inv = $this->studentModel->gettable_data('transactions_relation',$where = array('receipt_trans_no' => $s->trans_number));
          if(count($bank_charges) > 0){
         $chargesb=$bank_charges[0]->amount;  
         }

          if(count($leger_transaction) > 0){
        $total_amount = $this->billingModel->get_total_amount_payed2($s->trans_number,9);
        foreach($total_amount as $tv){
                                           
        if($tv->ledger_type==7 || $tv->ledger_id==6){
         
        }else{
        $amount += $tv->amount;
        }
     
        }

         if($leger_transaction[0]->name_type_id == 4){
        $app = $this->billingModel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $this->billingModel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $class=$this->billingModel->get_item_name('classes_tbl', $where = array('id' =>$app[0]->class));
        
    }
    else if($leger_transaction[0]->name_type_id == 3){
         $app = $this->billingModel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
         $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
         $student_id = $app[0]->id;
         $type_name = $this->billingModel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
         $name_type = $type_name[0]->name_type;
    }else if($leger_transaction[0]->name_type_id == 1){
         $app = $this->billingModel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
         $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
         $student_id = $app[0]->id;
         $type_name = $this->billingModel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
         $name_type = $type_name[0]->name_type;

          $admission= $this->billingModel->get_item_name('admission_tbl', $where = array('student_id' => $student_id,'academic_year'=>$year));
          if(count($admission)==0){
             $admission= $this->billingModel->get_item_name('admission_tbl', $where = array('student_id' => $student_id));
             $n=count($admission);
              $class=$this->billingModel->get_item_name('classes_tbl', $where = array('id' => $admission[$n-1]->class_id));
          }else{
        
         $class=$this->billingModel->get_item_name('classes_tbl', $where = array('id' => $admission[0]->class_id));
          }

    }else if($leger_transaction[0]->name_type_id == 6){
         $app = $this->billingModel->get_item_name('other_students_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
         $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
         $student_id = $app[0]->id;
         $type_name = $this->billingModel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
         $name_type = $type_name[0]->name_type;
    }

    $acc = $this->billingModel->get_item_name('accounts_tbl', $where = array('id' => $bank[0]->ledger_id));
          }

   

          $data[] = [$rct_inv[0]->invoice_trans_no??$student_id, $student_name, $class[0]->class_name??"",$s->trans_number,$amount- $chargesb,date('Y-m-d',strtotime($s->trans_date)),$acc[0]->account_name??""];
      }
      }

       
        // Create new Spreadsheet object
        
        $spreadsheet = new Spreadsheet();

        // Get active sheet
        $sheet = $spreadsheet->getActiveSheet();
    // print_r($data);
    //     return;
        // Fill spreadsheet with data
        $sheet->fromArray($data);

        // Write the file in Excel format
        $writer = new Xlsx($spreadsheet);

        // Create temporary file name
        $fileName = 'ReceiptList_' . date('Y-m-d H:i:s') . '.xlsx';
       
        // Set headers to force download of Excel file
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
        header('Cache-Control: max-age=0');

        // Output Excel file
        $writer->save('php://output');
        //echo "Exported successfully";
        exit;
    }

    function exportInvoiceToExcel(){
         $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            $year=date('Y', $enddate);
            
            $trans = $this->billingModel->get_item_name2('transaction_numbers_tbl',$where = array('trans_type_id' => 1),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
            $data[]=['INVOICE LISTS'];
            $data[] = ['invoice Number', 'Student Name', 'Class','Invoiced Amount','Invoice Type','Invoice Date'];

     if(count($trans) >0){
       foreach($trans as $s){
         $student_name = "";
        $student_id = "";
        $control_number = "";
        $name_type = "";
        $amount =0;
        $totalAmount=0;
        $leger_transaction = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' =>$s->trans_number,'trans_type' =>1));
         
          if(count($leger_transaction) > 0){
        $ledgeramount = $this->billingModel->get_item_name('item_transation_tbl', $where = array('trans_number' => $leger_transaction[0]->trans_no,'trans_type'=>1));
         foreach ($ledgeramount as $a) {
     $item = $this->billingModel->get_item_name('items_tbl', $where = array('id' => $a->item_id));
                    $amount = $a->quantity * $a->unit_price;
                 if($item[0]->item_group==7){
                    $totalAmount -= $amount;
                }else{
                   $totalAmount += $amount;  
                }
                }

         if($leger_transaction[0]->name_type_id == 4){
        $app = $this->billingModel->get_item_name('students_application_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
        $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
        $student_id = $app[0]->id;
        $type_name = $this->billingModel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
        $name_type = $type_name[0]->name_type;
        $class=$this->billingModel->get_item_name('classes_tbl', $where = array('id' =>$app[0]->class));
        
    }
    else if($leger_transaction[0]->name_type_id == 3){
         $app = $this->billingModel->get_item_name('parents_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
         $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
         $student_id = $app[0]->id;
         $type_name = $this->billingModel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
         $name_type = $type_name[0]->name_type;
    }else if($leger_transaction[0]->name_type_id == 1){
         $app = $this->billingModel->get_item_name('students',$where = array('id'=>$leger_transaction[0]->name_id));
         $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
         $student_id = $app[0]->id;
         $type_name = $this->billingModel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
         $name_type = $type_name[0]->name_type;

          $admission= $this->billingModel->get_item_name('admission_tbl', $where = array('student_id' => $student_id,'academic_year'=>$year));
          if(count($admission)==0){
             $admission= $this->billingModel->get_item_name('admission_tbl', $where = array('student_id' => $student_id));
             $n=count($admission);
              $class=$this->billingModel->get_item_name('classes_tbl', $where = array('id' => $admission[$n-1]->class_id));
          }else{
        
         $class=$this->billingModel->get_item_name('classes_tbl', $where = array('id' => $admission[0]->class_id));
          }

    }else if($leger_transaction[0]->name_type_id == 6){
         $app = $this->billingModel->get_item_name('other_students_tbl',$where = array('id'=>$leger_transaction[0]->name_id));
         $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
         $student_id = $app[0]->id;
         $type_name = $this->billingModel->get_item_name('name_type_tbl',$where = array('id'=>$leger_transaction[0]->name_type_id));
         $name_type = $type_name[0]->name_type;
    }

    $invoice_type = $this->billingModel->get_item_join_table11($s->trans_number,1);
          }

   

          $data[] = [$s->trans_number??"", $student_name, $class[0]->class_name??"",$totalAmount,$invoice_type[0]->type_name??"",date('Y-m-d',strtotime($s->trans_date))];
      }
      }

        // print_r($data);
        // return;
        
        $spreadsheet = new Spreadsheet();

        // Get active sheet
        $sheet = $spreadsheet->getActiveSheet();

        // Fill spreadsheet with data
        $sheet->fromArray($data);

        // Write the file in Excel format
        $writer = new Xlsx($spreadsheet);

        // Create temporary file name
        $fileName = 'Invoices_' . date('Y-m-d H:i:s') . '.xlsx';

        // Set headers to force download of Excel file
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
        header('Cache-Control: max-age=0');

        // Output Excel file
        $writer->save('php://output');
        //echo "Exported successfully";
        exit;
    }
    
  function process_vfd_receipt(){ 
     helper('vfd_helper');
      helper('qrcode_helper');
   $id=$this->request->getPost('id');
     $amount=(int)$this->request->getPost('amount');
     $cusName = $this->request->getPost('student_name');
     $dbid=session()->get('db_id');
     $result=process_vfd_receipt_now($id,$amount,$cusName,$this->dbname,$dbid);
     echo $result;
 }

    
  
function tra_receipt_view(){
    $id=$this->request->getPost('id');
  $amount=(int)$this->request->getPost('amount');
  $trans=$this->billingModel->get_item_name('transaction_numbers_tbl', $where = array('id' => $id));
  $trans_no=$trans[0]->trans_number;
  $check_receipt=$this->billingModel->get_item_name('vfd_receipts_details_tbl', $where = array('receipt_number' => $trans_no));
  $vfd=$this->billingModel->get_item_name('vfd_settings_tbl', $where = array('status' => 1));
  $data=array(
    'amount'=>$amount,
    'trans'=>$trans,
    'dtls'=>$vfd,
    'vfd_datas'=>$check_receipt,
    'customer_name'=>$this->request->getPost('student_name'),
  );
  return view('payment/tra_receipt_detailed',$data);
}

function make_temporaly_deposit($inv_details,$payedamount){
  //print_r($resp); 
    $db=$this->dbname;
    
      $student_id=$inv_details[0]->student_id;
      $trno=$inv_details[0]->trans_no;
      $original_amount=$inv_details[0]->amount;
  $trans=$this->generate_transaction_deposit($db);
  $transaction = [
              'trans_type_id' => 3,
              'trans_number' => $trans,
             'trans_date' => $this->request->getPost('date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s'),
              'trans_desc' =>  $inv_details[0]->academic_year,
                 ];
      $this->payment_model->SaveData('transaction_numbers_tbl',$transaction,$db); 

      $total_amount =$payedamount;
        

             $total_cost = 0;
                $invoice_type = [
                'trans_no' => $trans,
                'transaction_type_id' => 3,
                'invoice_type_id' => 2
                ];
   
     $this->payment_model->SaveData('invoice_type_transaction',$invoice_type,$db);

    $itm = $this->payment_model->gettable_data('items_tbl',$where = array('item_group' => 10),$db);
        foreach($itm as $i){
        $itype = $i->item_type;
        $c = $i->id;
        }

        $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $trans,'trans_type' => 3, 'quantity' => 1, 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $total_amount);
$this->payment_model->SaveData('item_transation_tbl',$itemData,$db);
 $leger_items = $this->payment_model->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c),$db);
foreach($leger_items as $lg){
 $legers = $this->payment_model->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id),$db);
 if($legers[0]->account_type_id !=3 || $legers[0]->account_type_id !=4){
                    continue;
                }
                $ledger = [
                'ledger_id' => $leger_items[0]->account_id,
                'ledger_type' => $legers[0]->account_type_id,
                'trans_item' => $c,
                'trans_no' => $trans,
                'trans_type' => 3,
                'amount' => $payedamount,
                'transation_nature' => 1,
                'name_type_id' => 1,
                'name_id' => $student_id,
                ];
              
     $this->payment_model->SaveData('ledger_transaction_tbl',$ledger,$db);
}
        $pid = $this->payment_model->gettable_billingdata($student_id,$db);  
          foreach($this->request->getPost('pay_ledger') as $l){

          $Bank_leger = $this->payment_model->gettable_data('accounts_tbl',$where = array('id' => $l),$db);
                $ac_ledger = [
                'ledger_id' => $Bank_leger[0]->id,
                'ledger_type' => $Bank_leger[0]->account_type_id,
                'trans_no' => $trans,
                'trans_type' => 3,
                'amount' =>  $total_amount,
                'transation_nature' => 2,
                'name_type_id' => 5,
                'name_id' => $pid[0]->id,
                'balance' => $payedamount,
                ];   
       
        $this->payment_model->SaveData('ledger_transaction_tbl',$ac_ledger,$db);
    }
       $phone=$pid[0]->phone1;

       $relation=array(
          'deposit_number'=>$trans,
          'invoice_number'=>$trno,
          'amount'=>$payedamount,
             );
     $this->payment_model->SaveData('deposit_receipt_tbl',$relation,$db);
      //$this->send_balance_msg($trno,$student_id,$db,$phone,2,$payedamount,$trans); 
      $balance = $this->payment_model->gettable_data('deposit_receipt_tbl',$where = array('invoice_number' => $trno),$db);
      $payed=0;
      foreach($balance as $b){
   $payed=$payed+$b->amount;
      }
      $todaybal=$original_amount -$payed;
      $student_details = $this->payment_model->gettable_data('students',$where = array('id' => $student_id),$db);  
     $msg = $student_details[0]->first_name.", Malipo yamekamilika. Deposit:".$trans.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($payedamount).". Baki- ".number_format($todaybal)." Ada ".$inv_details[0]->academic_year.".";
  $messagex=" #student fullname Malipo yamekamilika. Risiti: x, Tarehe: d/m/Y H:i, Kiasi:TZS xxx, baki x";
     $snn = $this->generate_msg_no_2($db);
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 5,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i:s'),
                    'send_by' => 10,
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
    
  $data=array(
      'phone'=>$phone,
       'msg'=>$msg,
        'stid'=>$student_id,
        'snn'=>$snn
      );
    //print_r($data);
$this->payment_model->SaveData('message_groups_tbl',$smsdata,$db);

 $dbid=session()->get('db_id');
   
              $cleanPhone = sanitize_phone($phone);
if ($cleanPhone) {
    try {
         $this->SMSsender2($cleanPhone,$msg,2,$student_id,$snn,NULL,$dbid);
    } catch (\Throwable $e) {
        log_message('error', 'SMS failed to ' . $cleanPhone . ' : ' . $e->getMessage());
    }
} else {
    log_message('error', 'Invalid phone number skipped: ' . $user->phone_no);
}
  echo json_encode(array('status' => 2,'description' => 'Deposit created successful'));

}

   public function generate_transaction_deposit($db)
    {
   $ino = "";
        $num=array();
        $tkens = $this->payment_model->get_max_deposit('transaction_numbers_tbl','trans_number',$db);
        
     
        $j=count($tkens);
     if (count($tkens) > 0) {
              foreach($tkens as $n){
            list($n1,$n2)=explode('DEP',$n->trans_number);
            array_push($num, $n2);
        }
     //   print_r(max($num));
          
            $maxid=max($num) +1;
            $ino = 'DEP'.$maxid;
        } else {
            $ino =  'DEP1';
        }
      //  $ino=SUBSTRING($col, 4);
       return $ino;

    }
    
     function get_control_byname(){
            $year=$this->request->getPost('year');
            $name=$this->request->getPost('name');
            $name=trim($name);
       $name_parts = explode(" ", $name);
       
            $data = array(
               'trans' => $this->billingModel->get_control_byname($name_parts,count($name_parts),$year)
            );
           echo view('payment/bank_results_view',$data);
        }
        
         function whatsapmessage($id){
        // return;
    // WhatsApp API URL
        $url = 'https://graph.facebook.com/v22.0/577092445481206/messages';

        // Your WhatsApp Business API Token (Replace with your actual token)
        $accessToken = 'EAATCVpXXgj0BO9qC0b6nEpxMxHLAmzEGyoD5lruZAVYSVrEFZBeQCGF63fsvHJy6OK7spVUnYokPe4qofDMfirBJlmfXZBpjpiolQhcQCQLanrQJWGWRzCJU7ZBKNA0nZBCYrTNZBqbrtdlTbwGyOV7pdhCn57DZAECowZAC1HBZAzcZAZCb1aeQfSm66NATIgLZC3DJJQZDZD';

        // Recipient phone number (with country code, no + sign)
        $to = '255747672438';

        // URL of the PDF file (must be accessible online, e.g., hosted on your server)
        $pdfUrl = base_url('receipts/receipt_'.$id.'.pdf'); // Adjust path based on where your file is stored
        
        $postData = [
            "messaging_product" => "whatsapp",
            "to" => $to,
            "type" => "template",
            "template" => [
                "name" => "welcome_template",  // Ensure this template exists in your WhatsApp Business account
                "language" => [
                    "code" => "en_US"
                ]
            ]
        ];

       // WhatsApp API request body
        // $postData = [
        //     "messaging_product" => "whatsapp",
        //     "to" => $to,
        //     "type" => "document",
        //     "document" => [
        //         "link" => $pdfUrl,
        //         "filename" => "receipt_".$id.".pdf"
        //     ]
        // ];
        
        

        // Initialize cURL
        $ch = curl_init($url);

        // Set cURL options
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));

        // Execute request & get response
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Return response
        return $this->response->setJSON([
            'status' => $httpCode,
            'response' => json_decode($response, true)
        ]);

    }
    
     function fetch_charged_items(){
      $student_id=$this->request->getPost('student_id');
      $data['student_id']=$student_id;
       echo view('payment/charged_item_form',$data);
    }

    function process_sales_receipt(){
         
         $trans = $this->generate_transaction_no();
      $transaction = [
              'trans_type_id' => 2,
              'trans_number' => $trans,
              'trans_date' => $this->request->getPost('receipt_date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s')
      ];
      $trans_id = $this->studentModel->SaveData_n_get_id('transaction_numbers_tbl',$transaction);

      $check_class = $this->studentModel->gettable_data('company_tbl',$where = array('classification' => 1));
        if(count($check_class)>0){
            $classification = [
                'trans_id' => $trans_id,
               'classification_id' => $this->request->getPost('class_type'),
                
                 ];
        $this->studentModel->SaveData('invoice_classification_tbl',$classification);
         }

        $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 2,
             'invoice_type_id' => 3 //temp soln
         ];
        $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);

         $itype ="";
         $amountttl = 0;
         $qtys = 0;
         $id="";
         $amount=0;
         $student_id=$this->request->getPost('student_id');
         $itemID = $this->request->getPost('iid');
         $total_cost=0;

        foreach ($itemID as $c) {
            $itm = $this->studentModel->gettable_data('items_tbl',$where = array('id' => $c));
            
              $itmq = $this->studentModel->gettable_data('price_tbl',$where = array('item_id' => $c));
                $upd_item = [
                'item_balance'=>$itmq[0]->item_balance-$this->request->getPost('quantity'.$c.''),
                ];
                $this->studentModel->update_table_details('price_tbl',$where = array('item_id' =>$c),$upd_item);
            foreach($itm as $i){
                $itype = $i->item_type;
            }

            $itemData = array('item_id' => $c, 'item_type_id' => $itype,'trans_number' => $trans,'trans_type' => 2, 'quantity' => $this->request->getPost('quantity'.$c.''), 'before_qty' => 0,'after_qty' => 0, 'unit_price' => $this->request->getPost('price'.$c.''));

            $itm_trans = $this->studentModel->SaveData_n_get_id('item_transation_tbl',$itemData);

            $leger_items = $this->studentModel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $c)); 
            $total_cost+=$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.'');
            
            foreach($leger_items as $lg){
                $legers = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id));
                if($legers[0]->account_type_id ==3 || $legers[0]->account_type_id ==4){
                    $nature=1;
                    $tamount=$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.'');
                   
                }else{
                    $tamount=$itmq[0]->last_price*$this->request->getPost('quantity'.$c.'');
                   if($legers[0]->account_type_id ==2){
                  $nature=1;
                   }else if($legers[0]->account_type_id ==5){
                   $nature=2;
                   }else{
                    continue;
                   }
                 
                }
                $ledger = [
                    'ledger_id' => $lg->account_id,
                     'ledger_type' => $legers[0]->account_type_id,
                     'trans_item' => $c,
                     'trans_no' => $trans,
                     'trans_type' => 2,
                     'amount' =>  $tamount,
                     'transation_nature' => $nature,
                     'name_type_id' => $this->request->getPost('customer_type'),
                     'name_id' => $student_id,
                ];
                 $this->studentModel->SaveData('ledger_transaction_tbl',$ledger); 

            }
        $amount+=$this->request->getPost('quantity'.$c.'') * $this->request->getPost('price'.$c.'');
           }

           $transation = [
                       'receipt_type' => $this->request->getPost('receipt_type'),
                       'transNumber' => $trans
                         ];
                  $this->studentModel->SaveData('receipt_type_transaction_tbl',$transation);

            foreach($this->request->getPost('pay_ledger') as $l){
            $ac_ledger = [
                'ledger_id' => $l,
                'ledger_type' => 9,
                'trans_item' => 0,
                'trans_no' => $trans,
                'trans_type' => 2,
                'amount' =>  $this->request->getPost('amount'.$l),
                'transation_nature' => 2,
                'name_type_id' => $this->request->getPost('customer_type'),
                'name_id' => $student_id,
                'balance' => 0,
            ];   
            $this->studentModel->SaveData('ledger_transaction_tbl',$ac_ledger); 
            
            }

            $tn = $this->studentModel->gettable_data('transaction_numbers_tbl',$where = array('trans_number' => $trans,'trans_type_id' => 2));

//vfd starts
  $vfd_settngs = $this->studentModel->gettable_data('vfd_settings_tbl',$where = array('status' =>1));
  // if(count($vfd_settngs)>0){
  //    helper('vfd_helper');
  //     helper('qrcode_helper');
  //   $total_amount=$amount;

  //    $dbid=session()->get('db_id');
  //    if($total_amount >0){
  //   $result=process_vfd_receipt_now($tn[0]->id,$total_amount,$student_details[0]->first_name,$this->dbname,$dbid);
  //    }
  // }
  //vfd ends
   echo json_encode(array('status' => 1,'description' => 'receipt created successful','id' => $tn[0]->id));


    }
    
    /////****** groups receipts **********//////////////////////
  function create_receipts_group(){

      $i=0;
        foreach($this->request->getPost('selected') as $trans_no){
            $i++;
            $balance=$this->request->getPost('balance'.$trans_no);
            
            $date=$this->request->getPost('admission_date');
            
            $payedamount=$this->request->getPost('payed'.$trans_no);
            $payedamount=str_replace(',', '', $payedamount);
            $payedamount = intval($payedamount);
            
            // echo $trno;
              if ($payedamount == 0){
                 // echo $i;
                    continue;
                }

           $account=intval($this->request->getPost('account'.$trans_no));
           if($account==0 ){
            continue;
           }
          ////////////////start receipts////////////////////////////////
            $trans=$trans_no;
             $trans = $this->generate_transaction_no();
      $transaction = [
              'trans_type_id' => 2,
              'trans_number' => $trans,
              'trans_date' => $this->request->getPost('admission_date'),
              'updated_by' => $this->request->getPost('header_id'),
              'updated_date' => date('Y-m-d H:i:s')
      ];
      $this->studentModel->SaveData('transaction_numbers_tbl',$transaction); 
        $total_cost = 0;
        // $phone = "";
        $phone = $this->request->getPost('phone');
        
        $studentId=$this->request->getPost('student_id'.$trans_no);
        $student_id=$this->request->getPost('student_id'.$trans_no);
         $i=0;
          
        $trno = $trans_no;

        $itm_trans = $this->studentModel->select_inv_id($trno);
                $trans_item=$itm_trans[0]->invoice_type_id;
                $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 2,
             'invoice_type_id' => $itm_trans[0]->invoice_type_id //temp soln
         ];
        $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);

             $db = \Config\Database::connect($this->dbname);
             $result = $db->query('SELECT * FROM  ledger_transaction_tbl  
                                      WHERE name_id = '.$student_id.' AND ledger_type = 7 and name_type_id =1 and trans_no ='.$trno.' AND transation_nature = 2 and trans_type = 1');
                                  $billspending = $result->getResult(); 

             ///*************sum rcpt*******************************
         $inv_no = $this->billingModel->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $trno));
            $total_paid=0;

            if(count($inv_no)>0){
            foreach($inv_no as $no){
                $charges=0;
                $rcpt_am = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2));
                $charged = $this->billingModel->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 1,'trans_type' => 2,'ledger_id'=>22));
                if(count($charged)>0){
                    $charges=$charged[0]->amount; 
                }
                if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                    // echo 'rct='.$am->amount;
                    // echo '</br>'; 
                  $total_paid=$total_paid+$am->amount-$charges;
              }
                }
            }
            }

                ///*********************************************

             foreach($billspending as $ledger){
                if($ledger->amount -$total_paid- $payedamount >= 0){
                    $balance = $ledger->amount -$total_paid- $payedamount;
                    //echo $ledger->balance;
                    $amount = $payedamount;
                   
                }else{
                   $balance = 0;
                   $amount = $payedamount;
                  // $payedamount = $payedamount - $ledger->balance;
                }

                $rcledger = [
                       'ledger_id' => $ledger->ledger_id,
                       'ledger_type' => 7,
                       'trans_item' => 0,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $amount,
                       'transation_nature' => 1,
                       'name_type_id' => 1,
                       'name_id' => $student_id,
                       'balance' => $balance
                   ];
  //   print_r($rcledger);
               $payid = $this->studentModel->SaveData_n_get_id('ledger_transaction_tbl',$rcledger);


                $balance = array(
                    'balance' => $balance
                );
                $this->studentModel->update_table_details('ledger_transaction_tbl',$where = array('id' => $ledger->id),$balance);   
                $relation_transation = [
                       'invoice_trans_no' => $trno,
                       'receipt_trans_no ' => $trans
                         ];
                $this->studentModel->SaveData('transactions_relation',$relation_transation);

                 //end update Control number ********************** 
  
                if ($payedamount <= 0){
                    break;
                }
             }

             $student_details = $this->studentModel->gettable_data('students',$where = array('id' => $student_id));

           $account=$this->request->getPost('account'.$trans_no); 
        $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $account)); 

       
           $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $amount,
               'transation_nature' =>2,
               'name_type_id' => 5,
               'name_id' => $this->request->getPost('pid'),
           ];

         $chek_lg = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('ledger_id' => $Bank_leger[0]->id,'ledger_type'=>$Bank_leger[0]->account_type_id,'trans_no'=>$trans,'trans_type'=>2,'transation_nature'=>2)); 
         if(count($chek_lg)>0){

         }else{
           $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);
       }

            ///////////////////////////////////////////
          
        }

        echo json_encode(array('status' => 1,'description' => 'receipt created successful'));
    }
//mark the end    

}


    
?>
