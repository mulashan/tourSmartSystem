<?php
namespace App\Controllers;
use App\Controllers\BaseController;
use App\Models\SupplierModel;
class SupplierController extends BaseController
{
	
	function __construct()
	{
	    
	     if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
		 $this->dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($this->dbname);
		$this->suppliermodel = new SupplierModel();
	}

	function Suppliers()
	{
		$sup_data['supplierinfo']= $this->suppliermodel->get_suppliers();
		return view('templates/header')
		  .view('Suppliers/supplier',$sup_data)
          .view('templates/footer'); 
	}

	////////////////////// function to save new supplier///////////////////////
	function New_Supplier()
	{

		$supplierdata=[
			'supplier_name'=>$this->request->getPost('supp_name'),
			'supplier_address'=>$this->request->getPost('supp_address'),
			'supplier_phone'=>$this->request->getPost('supp_phone'),
			'supplier_email'=>$this->request->getPost('supp_email'),
			'sstatus'=>1,
			'updated_by'=>$_SESSION['user_id'],
			'updated_date'=>date('Y/m/d H:i:s'),
		];
		$this->suppliermodel->SaveSupplier($supplierdata);
		echo json_encode(array('status'=>'0','statusDesc'=>'New Supplier Registered successfully'));
	}

	/////////////////// function to fetch supplier info ///////////////
	function get_supplier_info()
	{
		$supp_id = $this->request->getVar('supplier_id');
		$data['suppliers'] = $this->suppliermodel->get_supp_data($supp_id);
		//print_r($data);
		return view('Suppliers/view_supplier',$data);
	}

	///////////////////// function to fetch single data to update ////////////

	function getSingle_supplier_info()
	{
		$updateid = $this->request->getVar('ids');
		$data['suppl'] = $this->suppliermodel->get_suppl_data($updateid);
		//print_r($data);
		return view('Suppliers/edit_supplier',$data);
	}

	/////////////// function to save supplier data ///////////////////
	function Save_suppl_data()
	{
		$id = $this->request->getVar('supp_id');
		$data = [
			'supplier_name'=>$this->request->getPost('sname'),
			'supplier_address'=>$this->request->getPost('saddress'),
			'supplier_phone'=>$this->request->getPost('sphone'),
			'supplier_email'=>$this->request->getPost('semail'),
			'sstatus'=>$this->request->getPost('sstatus'),
			'updated_by'=>$_SESSION['user_id'],
			'updated_date'=>date('Y/m/d H:i:s'),
		];
		$this->suppliermodel->save_supplier_data($id,$data);
		echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
                <span class="glyphicon glyphicon-ok"></span> Supplier record Updated Successfully.</div> ';

	}
}

 ?>