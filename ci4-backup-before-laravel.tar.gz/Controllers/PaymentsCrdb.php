<?php 
    namespace App\Controllers;

    use CodeIgniter\Controller;
    use App\Models\BillingModel;
    use App\Models\StudentModel;
    use App\Models\SystemModel;
    use App\Models\PaymentsModel;
  

    class PaymentsCrdb extends BaseController{
        public $StudentModel;
        public $sytm_model;
        public $databaseName;
        public function __construct(){
           $this->billingModel = new BillingModel; 
           $this->studentModel = new StudentModel; 
           $this->sytm_model = new SystemModel;
           $this->payment_model = new PaymentsModel;
           
         
        }
   
 function generate_transaction_no_2($db) {
        $ino = "";
        $tkens = $this->payment_model->get_max_receipt('transaction_numbers_tbl','trans_number',$db);
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
     
 function SMSsender2($dest,$msg,$type,$ref_no,$snn,$show_response=0,$db,$id) {
     
      $tmsg = $this->payment_model->get_item_name('message_status_tbl',$where = array('status' => 1,), $db);
                  if(count($tmsg)==0){
                   return;   
                  }
             $messag = $this->payment_model->load_messages_balances($db);

             $time_sent = time();
            if($id==1){
            $username=SMS_UNAME;
             $password=SMS_PASSWORD;
             $senderid=SENDER_ID;
         }elseif($id==4){
           $username=SMS_UNAME_USA;
             $password=SMS_PASSWORD_USA;
             $senderid=SENDER_ID_USA;  
         }else{
           $username=SMS_UNAME_USA;
             $password=SMS_PASSWORD_USA;
             $senderid=SENDER_ID_USA;   
         }
             $destination=$dest;
             $message=urlencode($msg);
          $fetch=file_get_contents("https://www.sms.co.tz/api.php?do=sms&username={$username}&password={$password}&senderid={$senderid}&dest={$destination}&msg={$message}");
           
            list($status, $note, $smsid) = explode(',', $fetch);
            if($show_response == 2){
              echo '<th>Message status:</th>';
              echo '<td><i>' . $note . '</i></td>';
            }
            if ($status == 'OK') {
                $msgid = $smsid;
                $snt_status = 1;    // Message sent successfully
                $cost = 45;
                $acc_cost = $cost;
                if($type!=2){
                echo 'Message sent successfully';
                  }  
            } else {
                $msgid = '';
                $snt_status = 2;    // Message just sent 
                $cost = 45;
                $acc_cost = $cost;
            }

             $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'send_no' => $snn,
                    'reference_no' => $ref_no
                );
            
            $this->payment_model->SaveData('messages',$tempsmsdata,$db);
          //  echo 'msg saved';

            $balance = ($messag[0]->balance - $acc_cost);

           $smsDt = array(
                'balance' => $balance,
                'created_at' => date('Y/m/d H:i:s')
            );
            $this->payment_model->update_sms_balance($smsDt, $messag[0]->b_id,$db);

          //  curl_close($curl);
     // echo 'successful sent';
    }

   
 function receive_crdb_app($id){
      if($id==1){
       $db=DB1;
      }elseif($id==4){
        $db=DB4;
      }
        $resp = json_decode(trim(file_get_contents('php://input')), TRUE);

      $inv_details = $this->payment_model->gettable_data('payment_request',$where = array('reference_no' => $resp['reference_number']),$db);
      $student_id=$inv_details[0]->student_id;

      $trans = $this->generate_transaction_no_2($db);
        $trans_response = [
              'reference_no' => $resp['reference_number'],
              'amount_payed' =>$resp['amount'],
              'transaction_receipt' => $resp['payment_receipt'],
              'transaction_date' => $resp['transaction_date'],
              'customer_name' => $resp['customer_name'],
              'account_no' =>$resp['account_number'],
              'transaction_channel' => $resp['channel'],
              'system_receipt_no' => $resp['transaction_ref']
      ];
      $this->payment_model->SaveData('payment_response',$trans_response,$db);


      ///*************sum rcpt*******************************
       file_put_contents('Apifeedback/crdb_payments_application' . $resp['payment_receipt']. '.txt', json_encode($resp));
       ///*********************************************

             // return;
        $transaction = [
            'trans_type_id' => 2,
            'trans_number' => $trans,
            'trans_date' =>$resp['transaction_date'],
            'updated_by' => 9,
            'updated_date' => date('Y-m-d H:i:s')
        ];   
        $this->payment_model->SaveData('transaction_numbers_tbl',$transaction,$db);

         $total_cost = 0;

          //start charges payment control
    // $total_amount =$resp['amount'];
         if($inv_details[0]->paid_charges==1){
            $payedamount = $resp['amount']; 

        }else{
            $payedamount = $resp['amount']-$inv_details[0]->charges;
             $charged_update = array(
            'paid_charges' => 1
                );
         $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$charged_update,$db); 
         if($id==4){
           $amount=0;
           $balance=1180;
         }else{
           $amount=$inv_details[0]->charges;
           $balance=$inv_details[0]->charges;
         }

          $ledger = [
               'ledger_id' => 22,
               'ledger_type' => 13,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $amount,
               'transation_nature' =>1,
               'name_type_id' => 4,
               'name_id' => $student_id,
               'balance' =>$balance
           ];

 $this->payment_model->SaveData('ledger_transaction_tbl',$ledger,$db);
            }
         //end charges payment control

        $temp_id = $this->payment_model->gettable_data('temp_item_transation_tbl',$where = array('student_id' => $student_id,'bill_status'=>0),$db);
            $invoice_id = $student_id;
            foreach($temp_id as $price){
                  $itm = [
                    'item_id' => $price->item_id,
                    'item_type_id' => $price->item_type_id,
                    'trans_number' => $trans,
                    'trans_type' => 2,
                    'quantity ' => $price->quantity,
                    'before_qty' => 0,
                    'after_qty' => 0,
                    'unit_price' => $price->unit_price,
                ];
         $itm_trans = $this->payment_model->SaveData_n_get_id('item_transation_tbl',$itm,$db);
         $leger_items = $this->payment_model->gettable_data('items_ledgers_tbl',$where = array('item_id' => $price->item_id),$db);
                $total_cost+=$price->unit_price * $price->quantity;
                foreach($leger_items as $lg){
                    $legers = $this->payment_model->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id),$db); 
                    $ledger = [
                        'ledger_id' => $lg->account_id,
                        'ledger_type' => $legers[0]->account_type_id,
                        'trans_no' => $trans,
                        'trans_type' => 2,
                        'amount' => $price->unit_price * $price->quantity,
                        'transation_nature' => 1,
                        'name_type_id' => 4,
                        'name_id' => $student_id,
                    ];
                $this->payment_model->SaveData('ledger_transaction_tbl',$ledger,$db); 
                }
                $temptrans = [
                   'bill_status' => 1
                ];
                $this->payment_model->update_table_details('temp_item_transation_tbl',$where = array('id' => $price->id),$temptrans,$db);

                $app = [
                    'application_status' => 0
                ]; 
                $this->payment_model->update_table_details('students_application_tbl',$where = array('id' => $student_id),$app,$db);
                  }

             $paymentstatus = [
                    'payment_status' => 1
                ]; 
                $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$paymentstatus,$db);

                $student_details = $this->payment_model->gettable_data('students_application_tbl',$where = array('id' => $student_id),$db);
                $phone = $student_details[0]->phone_number;   
                $total_amount = 0;
                $l=17;
                    $total_amount = $resp['amount'];
                    $Bank_leger = $this->payment_model->gettable_data('accounts_tbl',$where = array('id' => $l),$db); 
                   
                       $Bledger = [
                           'ledger_id' => $Bank_leger[0]->id,
                           'ledger_type' => $Bank_leger[0]->account_type_id,
                           'trans_no' => $trans,
                           'trans_type' => 2,
                           'amount' =>  $resp['amount'],
                           'transation_nature' => 2,
                           'name_type_id' => 5,
                           'name_id' => $student_id,
                       ];

                       $this->payment_model->SaveData('ledger_transaction_tbl',$Bledger,$db);
                      
                   
                  $messagex="Malipo yamekamilika. Risiti: xxx, Tarehe:TZS xxx, kiasi: xxx, Muombaji: #fullname.";
           $snn = $this->generate_msg_no_2($db);
            $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 2,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>10,
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
      
         $this->payment_model->SaveData('message_groups_tbl',$smsdata,$db);
                    if($phone != ""){
                    $msg = "Malipo yamekamilika. Risiti:".$trans.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($payedamount).", Muombaji:".$student_details[0]->full_name;
            $this->SMSsender2($phone,$msg,2,$student_id,$snn,NULL,$db,$id);
                 
                    }
                  //  echo 'paid successfully';  
        }

 function receive_crdb_deposit($id){
     if($id==1){
       $db=DB1;
      }elseif($id==4){
        $db=DB4;
      }
      $dtb_id=$id;
     $resp = json_decode(trim(file_get_contents('php://input')), TRUE);

      $inv_details = $this->payment_model->gettable_data('payment_request',$where = array('reference_no' => $resp['reference_number']),$db);
      $student_id=$inv_details[0]->student_id; 


        $trans_response = [
              'reference_no' => $resp['reference_number'],
              'amount_payed' =>$resp['amount'],
              'transaction_receipt' => $resp['payment_receipt'],
              'transaction_date' => $resp['transaction_date'],
              'customer_name' => $resp['customer_name'],
              'account_no' =>$resp['account_number'],
              'transaction_channel' => $resp['channel'],
              'system_receipt_no' => $resp['transaction_ref']
      ];
      $this->payment_model->SaveData('payment_response',$trans_response,$db);

       $temptrans = [
                   'status' => 1,
                   'trans_date' =>date('Y-m-d H:i:s'),
                   'updated_by'=>9,
                    'updated_date' => date('Y-m-d H:i:s')
                ];
        $this->payment_model->update_table_details('transaction_numbers_tbl',$where = array('trans_number' => $inv_details[0]->trans_no,'trans_type_id'=>3),$temptrans,$db);

        $pstatus = [
                   'paid_charges' => 1,
                   'payment_status'=>1
                ];
         $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$pstatus,$db);
       
       //send message to depositer
        $student_details = $this->payment_model->get_item_name('students',$where = array('id' => $student_id),$db);
        $bill = $this->payment_model->gettable_billingdata($student_id,$db);

         $phone=$bill[0]->phone1;
            if($phone != ""){
            $received=$resp['amount']-$inv_details[0]->charges;
       $msg = "Mzazi wa ".$student_details[0]->first_name."; Malipo ya TZS ".number_format($received)." yamekamilika. Deposit namba ".$inv_details[0]->trans_no." tar ".date('d/m/Y H:i:s').".";
        $messagex="Mzazi wa FirstName; Malipo ya TZS xxxxx yamekamilika. Deposit namba xxxx tar xx/xx/xx xx:xx.";

       $snn = $this->generate_msg_no_2($db);
       $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 5,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>10,
                    'messagex' => $messagex,
                    'trans_number' => $inv_details[0]->trans_no
                  
                );
    //  print_r( $smsdata);
$this->payment_model->SaveData('message_groups_tbl',$smsdata,$db);

      }
        if($phone != ""){
        $msg = "Malipo yamekamilika. Risiti:".$inv_details[0]->trans_no.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($resp['amount']).", Muombaji: ".$student_details[0]->full_name;
       $this->SMSsender2($phone,$msg,5,$student_id,$snn,NULL,$db,$id);
      
        }
        echo 'Successfully paid'; 
        }

        function generate_msg_no_2($db) {
        $ino = "";
        $tkens = $this->payment_model->get_max_id('message_groups_tbl','send_number',$db);
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
    public function testing(){
        echo 'tested well';
    }

function receive_crdb_payment($id){
    if($id==1){
       $db=DB1;
      }elseif($id==4){
        $db=DB4;
      }
       $dtb_id=$id;
    $resp = json_decode(trim(file_get_contents('php://input')), TRUE);
       file_put_contents('Apifeedback/crdb_payments' . $resp['transaction_date']. '.txt', json_encode($resp));

      $inv_details = $this->payment_model->gettable_data('payment_request',$where = array('reference_no' => $resp['reference_number']),$db);
      $student_id=$inv_details[0]->student_id;

      $trans = $this->generate_transaction_no_2($db);
        $trans_response = [
              'reference_no' => $resp['reference_number'],
              'amount_payed' =>$resp['amount'],
              'transaction_receipt' => $resp['payment_receipt'],
              'transaction_date' => $resp['transaction_date'],
              'customer_name' => $resp['customer_name'],
              'account_no' =>$resp['account_number'],
              'transaction_channel' => $resp['channel'],
              'system_receipt_no' => $resp['transaction_ref']
      ];
      $this->payment_model->SaveData('payment_response',$trans_response,$db);


      ///*************sum rcpt*******************************
      $transaction = [
              'trans_type_id' => 2,
              'trans_number' => $trans,
              'trans_date' => $resp['transaction_date'],
              'updated_by' => 9,
              'updated_date' => date('Y-m-d H:i:s')
      ];
      $this->payment_model->SaveData('transaction_numbers_tbl',$transaction,$db); 
      $total_cost = 0;
       $studentId="";
         $i=0;
         $name_type=1;
         $total_amount =$resp['amount'];
         if($inv_details[0]->paid_charges==1){
            $payedamount = $resp['amount']; 

        }else{
            $payedamount = $resp['amount']-$inv_details[0]->charges;
             $charged_update = array(
            'paid_charges' => 1
                );
         $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$charged_update,$db); 

          $ledger = [
               'ledger_id' => 22,
               'ledger_type' => 13,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => 0,
               'transation_nature' =>1,
               'name_type_id' => 1,
               'name_id' => $student_id,
               'balance' =>1180
           ];

 $this->payment_model->SaveData('ledger_transaction_tbl',$ledger,$db);

            }
         
             $trno = $inv_details[0]->trans_no;
             //echo $trno;
            
                $itm_trans = $this->payment_model->select_inv_id($trno,$db);
                $trans_item=$itm_trans[0]->invoice_type_id;
                $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 2,
             'invoice_type_id' => $itm_trans[0]->invoice_type_id //
         ];
        $itm_trans = $this->payment_model->SaveData_n_get_id('invoice_type_transaction',$invoice_type,$db);

      $billspending = $this->payment_model->get_item_name('ledger_transaction_tbl',$where = array('name_id' => $student_id,'ledger_type' => 7,'name_type_id' => $name_type,'trans_no' => $trno,'transation_nature' => 2,'trans_type' => 1),$db);

        ///*************sum rcpt*******************************
         $inv_no = $this->payment_model->get_item_name('transactions_relation',$where = array('invoice_trans_no' => $trno),$db);
            $total_paid=0;
            foreach($inv_no as $no){
                $charges=0;
                $rcpt_am = $this->payment_model->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 2,'trans_type' => 2),$db);

                $charged = $this->payment_model->get_item_name('ledger_transaction_tbl',$where = array('trans_no' => $no->receipt_trans_no,'transation_nature' => 1,'trans_type' => 2,'ledger_id'=>22),$db);
                if(count($charged)>0){
                    $charges=$charged[0]->amount; 
                }
            if(count($rcpt_am)>0){
                foreach($rcpt_am as $am){
                  
                  $total_paid=$total_paid+$am->amount-$charges;
              }
                }
            }
              
     if($inv_details[0]->amount -($total_paid + $resp['amount']) == 0){
     $payment_status = array(
            'payment_status' => 1
                );
        }elseif($inv_details[0]->amount -($total_paid + $resp['amount'])> 0){
         $payment_status = array(
            'payment_status' => 2
                );
              }else{
                $payment_status = array(
            'payment_status' => 1
                );
              } 
        $this->payment_model->update_table_details('payment_request',$where = array('reference_no' => $resp['reference_number']),$payment_status,$db); 
        

               ///*********************************************

             foreach($billspending as $ledger){
                if($ledger->amount -$total_paid- $payedamount >= 0){
                    $balance = $ledger->amount -$total_paid- $payedamount;
                    //echo $ledger->balance;
                    $amount = $payedamount;
                   
                }else{
                   $balance = 0;
                   $amount = $payedamount;
                  // $payedamount = $payedamount - $ledger->balance;
                }

                    $rcledger = [
                       'ledger_id' => $ledger->ledger_id,
                       'ledger_type' => 7,
                       'trans_item' => $trans_item,
                       'trans_no' => $trans,
                       'trans_type' => 2,
                       'amount' => $amount,
                       'transation_nature' => 1,
                       'name_type_id' => $name_type,
                       'name_id' => $student_id,
                       'balance' => $balance
                   ];
  //   print_r($rcledger);
               $payid = $this->payment_model->SaveData_n_get_id('ledger_transaction_tbl',$rcledger,$db);


                $balance = array(
                    'balance' => $balance
                );
                $this->payment_model->update_table_details('ledger_transaction_tbl',$where = array('id' => $ledger->id),$balance,$db);   
                $relation_transation = [
                       'invoice_trans_no' => $trno,
                       'receipt_trans_no ' => $trans
                         ];
          $this->payment_model->SaveData('transactions_relation',$relation_transation,$db);
  //   print_r($relation_transation);
               
             }
       ///*********************************************
              $student_details = $this->payment_model->gettable_data('students',$where = array('id' => $student_id),$db);
             //***start**check if transport************//
                  $transport = $this->payment_model->gettable_data('transport_details',$where = array('trans_numb' => $trno),$db);
                  if(count($transport)>0){
                     $status = array(
                    'status' => 1
                );
                $this->payment_model->update_table_details('transport_details',$where = array('trans_numb' => $trno),$status,$db);

                     }
           //*****end check if transport************//

///////////////////////////////////////////////////////////////////////////////////
    
            $l=17;

       
        $Bank_leger = $this->payment_model->gettable_data('accounts_tbl',$where = array('id' => $l),$db); 
        
       $id = $this->payment_model->gettable_data('parents_students_tbl',$where = array('student_id' => $student_id),$db);


           $Bledger = [
               'ledger_id' => $Bank_leger[0]->id,
               'ledger_type' => $Bank_leger[0]->account_type_id,
               'trans_no' => $trans,
               'trans_type' => 2,
               'amount' => $total_amount,
               'transation_nature' =>2,
               'name_type_id' => 5,
               'name_id' => $id[0]->parent_id
           ];

 $this->payment_model->SaveData('ledger_transaction_tbl',$Bledger,$db);
//print_r($Bledger);

 ///mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm/start////
   $invT=$this->payment_model->get_item_name('invoice_type_transaction',$where=array('trans_no'=>$trno,'transaction_type_id'=>1),$db);

//*****Installment Calculations ****************//
   if($invT[0]->invoice_type_id==2)
   {
  $this->installment_calculations($student_id,$db,$dtb_id,$trno,$payedamount,$trans);
  }else
  {
        $bill = $this->payment_model->gettable_billingdata($student_id,$db);
        $phone=$bill[0]->phone1;
        $messagex="Malipo yamekamilika. Risiti: xxx, Tarehe:TZS xxx, kiasi: xxx, Mwanafunzi: #fullname.";
        $snn = $this->generate_msg_no_2($db);
        $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 2,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>10,
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
      
       $this->payment_model->SaveData('message_groups_tbl',$smsdata,$db);
       if($phone != "")
        {
          $msg = "Malipo yamekamilika. Risiti:".$trans.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($payedamount).", Mwanafunzi ".$student_details[0]->full_name;
           $this->SMSsender2($phone,$msg,2,$student_id,$snn,NULL,$db,$id);
        }
  }
                 
////////////////////////////////////////////////////////////////////////
     
}


function installment_calculations($student_id,$db,$id,$trno,$payedamount,$trans){

      helper('calc');
$get_yr = $this->payment_model->gettable_data('transaction_numbers_tbl',$where = array('trans_number' => $trno,'trans_type_id' => 1),$db);
$year=date('Y',strtotime($get_yr[0]->trans_date));
$cld=$this->payment_model->get_item_name('admission_tbl',$where=array('student_id'=>$student_id,'academic_year'=>$year),$db);
$adm_id=$cld[0]->class_id;
$level_id=$cld[0]->level_id;
$hst=$cld[0]->admission_type;
  $tinvoice = $this->payment_model->get_total_invoice_amount($student_id,$year,$db); 
  $dbc = \Config\Database::connect($db);
  $results=findCalc($student_id,$db,$year);

  $lvtbl = $this->payment_model->get_item_name('class_level_tbl', $where = array('id' => $level_id),$db);
   $dateterm = $this->payment_model->checkTerm_date(date('Y-m-d'),$year,$db,$lvtbl[0]->academic_type);
                 
                  //print_r($dateterm);
                 if (is_countable($dateterm) && count($dateterm) > 0) {
                    $term_name=$dateterm[0]->term_name;
                   }else{
                    $dateterm = $this->payment_model->checkTerm_date2(date('Y-m-d'),$year,$db,$lvtbl[0]->academic_type);
                     
                     $term_name=$dateterm[0]->term_name;
                   }

                    
                  
               //$singleArray = array_values(array_column($trans_numbers, 0));
                     // print_r($singleArray);
                   $installments =$this->payment_model->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$lvtbl[0]->academic_type),$db);

                    
                    $ttlAmount = 0;
                     $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                      $ddate="";
                    foreach ($installments as $r) {
                        $paid_amount=0;
                    
                     $i++;
                    
                    
                     if($i==1){
                   $openingbalance=$results[0]['openingbalance'];
                       $ment=$results[0]['ment'];
                        $mbalance=$results[0]['mbalance'];
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[0]['today']==1){
                       $todaybalance=$results[0]['todaybalance']; 
                     }
                     
                   }
                if($i==2){
                      $ment=$results[1]['ment'];
                        $mbalance=$results[1]['mbalance'];
                        $paid_amount=$results[1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[1]['today']==1){
                       $todaybalance=$results[1]['todaybalance']; 
                     }    
                     }
                   if($i==3){
                     $ment=$results[2]['ment'];
                        $mbalance=$results[2]['mbalance'];
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[2]['today']==1){
                       $todaybalance=$results[2]['todaybalance']; 
                     }
                     }
                    
                 }
             
    //***end istallment calculations***//
    $bill = $this->payment_model->gettable_billingdata($student_id,$db);
        $phone=$bill[0]->phone1;
        $messagex="#student firstname, Malipo yamekamilika. Risiti: xxx, Tarehe:TZS xxx, kiasi: xxx, Baki-: (#term_name)-#balance. Baki kuu #balance.";
        $snn = $this->generate_msg_no_2($db);
        $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 2,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d H:i'),
                    'send_by' =>10,
                    'messagex' => $messagex,
                    'trans_number' => $trans
                  
                );
      
       $student_details = $this->payment_model->gettable_data('students',$where = array('id' => $student_id),$db);
       if($todaybalance <=0){
        $todaybalance=0;
      }
       
       if($mbalance <=0){
        $mbalance=0;
      }
      if($phone != ""){
                
              $msg = $student_details[0]->first_name.", Malipo yamekamilika. Risiti:".$trans.", Tarehe:".date('d/m/Y H:i'). ", Kiasi:TZS ".number_format($payedamount).". Baki- (".$term_name.") ".number_format($todaybalance).". Baki kuu ".number_format($mbalance);
              //echo $msg;
              $this->payment_model->SaveData('message_groups_tbl',$smsdata,$db);
             $this->SMSsender2($phone,$msg,2,$student_id,$snn,NULL,$db,$id);
                }
  ///mmmmmmmmmmmmmmmmmwishommmmmmmmmmmmmmmmmmmmmmmmmmmmm/////
}

function runautomatic(){
    $phone="255-754834247";
    $student_id=165;
    $db="advamhwe_usariverseminary";
    $id=4;
    $trno=163;
    $trans=803;
    $payedamount=400000;
//$this->installment_calculations($student_id,$db,$id,$trno,$payedamount,$trans);
}

}


    
?>