<?php

namespace App\Controllers;
use App\Controllers\BaseController;
use App\Models\CompanyModel;
use App\Models\ClassesModel;
use App\Models\StudentModel;


use CodeIgniter\Files\File;
class CompanyController extends BaseController
{

   public function __construct(){
        if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
    $this->CompanyModel = new CompanyModel();
    $this->cmodel = new ClassesModel();
    $this->smodel = new StudentModel();
    
     $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    $this->validation = \Config\Services::validation();
       helper(['form', 'url']);
    }

    public function company()
    {
        $data['comp']=$this->CompanyModel->compList();
        return view('templates/header')
        .view('company/company',$data)
        .view('templates/footer');
    }
    
     public function saveCompany()
    {
             $wcf_status=$this->request->getPost('wcf_status');
            $class_status=$this->request->getPost('classification');
                  $exit=$this->CompanyModel->exit();
                  if($exit>0){
                   echo "1";
                  }else{
                   $img = $this->request->getFile('logo');
                    $img_name = "";
                    if($img->isValid() && !$img->hasMoved()){
                        $img_name = $img->getName();
                        $img->move(ROOTPATH.'public/company_photos/',$img_name); 
                    }
                  if( $wcf_status==1){
                    $wcf_value=1;
                      $wcf_update = [
                         'tax_based' => 1,
                           'updated_date ' => date('Y-m-d H:i:s')
                     ];
                     $this->CompanyModel->UpdateWCFStatus($wcf_update);
                    }else{
                        $wcf_value=0;
                           $wcf_update = [
                         'tax_based' => 0,
                           'updated_date ' => date('Y-m-d H:i:s')
                     ];
                     $this->CompanyModel->UpdateWCFStatus($wcf_update);
                    }
                       if( $class_status==1){
                    $class_value=1;
                    }else{
                        $class_value=0;
                    }

                    $data = [
                         'company_name' => strtoupper($this->request->getPost('company_name')),
                         'address' => strtoupper($this->request->getPost('address')),
                         'phone1' => $this->request->getPost('phone1'),
                         'phone2' => $this->request->getPost('phone2'),
                         'website' => $this->request->getPost('website'),
                         'email' => $this->request->getPost('email'),
                         'tin' => $this->request->getPost('tin'),
                         'vat' => $this->request->getPost('vat'),
                         
                         'created_by' =>$_SESSION['user_id'],
                         'logo_name' => $img_name,
                         'date_created ' => date('Y-m-d H:i:s'),
                         'classification' =>$class_value,
                         'wcf_status' => $wcf_value
                         
                     ];
                 $companyid = $this->CompanyModel->Savecampany($data);
    }}
    function edit_company_details($id){
       $data['camp']= $this->CompanyModel->check_company_with_id($id);
        
            return view('company/form/edit_company',$data);
        }
       function view_company_details($id){
       $data['camp']= $this->CompanyModel->check_company_with_id($id);
        
            return view('company/form/view_company',$data);
        } 
      public function edit_Company()
    {
        $img = $this->request->getFile('logo');
        $img1 = $this->request->getPost('logo1');
        $wcf_status=$this->request->getPost('wcf_status');
        $class_status=$this->request->getPost('classification');
                 if($img!=""){
                    $img_name = "";
                    if($img->isValid() && !$img->hasMoved()){
                        $img_name = $img->getName();
                        $img->move(ROOTPATH.'public/company_photos/',$img_name); 
                    }
                    }
                    else{
                      $img_name=$img1;  
                    }
                    $id=$this->request->getPost('company_id');
                    if( $wcf_status==1){
                    $wcf_value=1;
                      $wcf_update = [
                         'tax_based' => 1,
                           'updated_date ' => date('Y-m-d H:i:s')
                     ];
                     $this->CompanyModel->UpdateWCFStatus($wcf_update);
                    }else{
                        $wcf_value=0;
                           $wcf_update = [
                         'tax_based' => 0,
                           'updated_date ' => date('Y-m-d H:i:s')
                     ];
                     $this->CompanyModel->UpdateWCFStatus($wcf_update);
                    }
                       if( $class_status==1){
                    $class_value=1;
                    }else{
                        $class_value=0;
                    }
                    $data = [
                         'company_name' => strtoupper($this->request->getPost('company_name')),
                         'address' => strtoupper($this->request->getPost('address')),
                         'phone1' => $this->request->getPost('phone1'),
                         'phone2' => $this->request->getPost('phone2'),
                         'website' => $this->request->getPost('website'),
                         'email' => $this->request->getPost('email'),
                         'tin' => $this->request->getPost('tin'),
                         'vat' => $this->request->getPost('vat'),
                         'created_by' =>$_SESSION['user_id'],
                         'logo_name' => $img_name,
                         'date_created ' => date('Y-m-d H:i:s'),
                         'classification' =>$class_value ,
                         'wcf_status' => $wcf_value
                         
                     ];
                  $this->CompanyModel->editcampany($data,$id);
    }
    
    public function delete_company($id)
        {

            $builder = $this->db->table('company_tbl');
            $builder->select('id');
            $builder->where('id',$id);
            $builder->delete();

        }

        public function education_trip(){
         return view('templates/header')
        .view('company/projects')
        .view('templates/footer');
        }

        public function save_new_project(){
            $check= $this->CompanyModel->gettable_data('projects_tbl',$where=array('project_name' =>$this->request->getPost('projectName'),));
            if(count($check)>0){
                echo 1;
            }else{
            $data = [
                        'project_name' => strtoupper($this->request->getPost('projectName')),
                         'project_date' => strtoupper($this->request->getPost('projectDate')),
                         'description' => $this->request->getPost('description'),
                         'created_by' =>$_SESSION['user_id'],
                         'status' =>1,
                         'date_created ' => date('Y-m-d H:i:s'),
                         
                     ];
                 $this->CompanyModel->Save_data('projects_tbl',$data);
                 echo 2;
             }
        }

        function fetch_projects(){
            $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            
            $data = array(
               'prj' => $this->CompanyModel->get_item_name2('projects_tbl',$where = array('status' => 1),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))
            );
           echo view('company/form/projects_list',$data);
        }
         function fetch_project_report(){
            $thedate=$this->request->getVar('thedate');
             list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
            $data = array(
               'prj' => $this->CompanyModel->get_item_name2('projects_tbl',$where = array('status=' => 1),date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate))
            );
           echo view('company/form/projects_report_list',$data);
         }

         function view_project_report($pid){
            $data=array(
              'pid'=>$pid
            );
         echo view('company/form/project_report_view',$data);
         }

         function filter_project_report(){
            $data=array(
              'pid'=>$this->request->getPost('pid'),
              'pstatus'=>$this->request->getPost('pstatus'),
            );
         echo view('company/form/project_report_view_list',$data); 
         }
         
          function manage_projects($id){
           $data=array(
              'pid'=>$id
            );
         echo view('company/form/edit_project',$data); 
         }

         function save_project_update(){
            $data=array(
             'project_name' => strtoupper($this->request->getPost('pname')),
                         'project_date' => strtoupper($this->request->getPost('pdate')),
                         'description' =>$this->request->getPost('pdesc'),
                         'created_by' =>session()->get('user_id'),
                         'status' => $this->request->getPost('pstatus'),
                         'date_created ' => date('Y-m-d H:i:s'),
            );
            //print_r($data);

             $id=$this->request->getPost('pid');
         $this->smodel->update_table_details('projects_tbl',$where = array('id' => $id),$data);
         echo 1;
         }
         
         function students_invoice_projects($id){
    $data=array(
              'pid'=>$id
            );
         echo view('company/form/project_invoices',$data);
      }
      
      function load_content_view($year){
   $data=array(
        'year'=>$year,
        'attendance_summary'=>$this->getDashboardAttendanceSummary((int) $year),
        'attendance_flag_count'=>count($this->getDashboardAttendanceFlagStudents())
            );
     if(session()->get('db_id')==17){
    echo view('templates/hospital_contents',$data);
   }else{
        echo view('templates/contents_view',$data);
   }
}

public function dashboard_attendance_flag_list()
{
    $students = $this->getDashboardAttendanceFlagStudents();
    if (count($students) === 0) {
        echo '<div class="alert alert-info mb-0">No students found.</div>';
        return;
    }

    echo '<div class="table-responsive"><table class="table table-bordered table-hover mb-0">';
    echo '<thead><tr><th>#</th><th>Names</th><th>Class</th><th>Stream</th><th>Last Status</th><th>Consecutive Days</th><th>Last Date</th></tr></thead><tbody>';
    $i = 1;
    foreach ($students as $student) {
        echo '<tr>';
        echo '<td class="text-center">'.($i++).'</td>';
        echo '<td>'.esc($student['name']).'</td>';
        echo '<td>'.esc($student['class']).'</td>';
        echo '<td>'.esc($student['stream']).'</td>';
        echo '<td>'.esc($student['status']).'</td>';
        echo '<td class="text-center">'.esc($student['days']).'</td>';
        echo '<td>'.esc($student['last_date']).'</td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}

private function getDashboardAttendanceFlagStudents(): array
{
    $records = $this->db->table('attendance_record ar')
        ->select('ar.student_id, ar.type, al.date_taken, students.full_name, classes_tbl.class_name, streams_tbl.stream_name')
        ->join('attendance_list_tbl al', 'al.id = ar.attendance_id')
        ->join('students', 'students.id = ar.student_id')
        ->join('classes_tbl', 'classes_tbl.id = al.class_id')
        ->join('streams_tbl', 'streams_tbl.id = al.stream_id')
        ->orderBy('ar.student_id', 'ASC')
        ->orderBy('al.date_taken', 'DESC')
        ->orderBy('al.time_taken', 'DESC')
        ->get()
        ->getResult();

    $grouped = [];
    foreach ($records as $record) {
        $studentId = $record->student_id;
        $date = $record->date_taken;
        if (!isset($grouped[$studentId][$date])) {
            $grouped[$studentId][$date] = [
                'record' => $record,
                'has_present' => false,
                'has_late' => false,
                'has_absent' => false,
            ];
        }
        if ((int) $record->type === 1) {
            $grouped[$studentId][$date]['has_present'] = true;
        } elseif ((int) $record->type === 2) {
            $grouped[$studentId][$date]['has_late'] = true;
        } elseif ((int) $record->type === 0) {
            $grouped[$studentId][$date]['has_absent'] = true;
        }
    }

    $flagged = [];
    foreach ($grouped as $studentDates) {
        $days = 0;
        $last = null;
        $lastStatus = '';
        foreach ($studentDates as $dateRecord) {
            $record = $dateRecord['record'];
            if ($dateRecord['has_present']) {
                break;
            }
            if ($dateRecord['has_absent'] || $dateRecord['has_late']) {
                $days++;
                if ($last === null) {
                    $last = $record;
                    $lastStatus = $dateRecord['has_late'] ? 'Late' : 'Absent';
                }
            }
        }

        if ($days >= 30 && $last) {
            $flagged[] = [
                'name' => $last->full_name,
                'class' => $last->class_name,
                'stream' => $last->stream_name,
                'status' => $lastStatus,
                'days' => $days,
                'last_date' => date('M d, Y', strtotime($last->date_taken)),
            ];
        }
    }

    return $flagged;
}

private function getDashboardAttendanceSummary(int $year): array
{
    $availableRows = $this->db->query("
        SELECT c.id, c.class_name, COUNT(DISTINCT s.id) AS available
        FROM classes_tbl c
        LEFT JOIN admission_tbl a
            ON a.class_id = c.id
            AND a.academic_year = ?
            AND a.status = 1
        LEFT JOIN students s
            ON s.id = a.student_id
            AND EXISTS (
                SELECT 1
                FROM ledger_transaction_tbl lt
                JOIN invoice_type_transaction itt
                    ON itt.trans_no = lt.trans_no
                    AND itt.transaction_type_id = lt.trans_type
                JOIN transaction_numbers_tbl tn
                    ON tn.trans_number = lt.trans_no
                WHERE lt.name_id = s.id
                    AND lt.transation_nature = 1
                    AND lt.trans_type = 1
                    AND lt.name_type_id = 1
                    AND tn.trans_type_id = 1
                    AND tn.trans_date LIKE CONCAT(?, '%')
                    AND itt.invoice_type_id = 2
            )
        WHERE c.status = 1
        GROUP BY c.id, c.class_name
        ORDER BY c.id ASC
    ", [$year, $year])->getResult();

    $attendanceRows = $this->db->query("
        SELECT
            al.class_id,
            SUM(CASE WHEN ar.type = 1 THEN 1 ELSE 0 END) AS present_count,
            SUM(CASE WHEN ar.type = 0 THEN 1 ELSE 0 END) AS absent_count,
            SUM(CASE WHEN ar.type = 2 THEN 1 ELSE 0 END) AS late_count
        FROM attendance_list_tbl al
        JOIN attendance_record ar
            ON ar.attendance_id = al.id
        JOIN admission_tbl a
            ON a.student_id = ar.student_id
            AND a.class_id = al.class_id
            AND a.stream_id = al.stream_id
            AND a.academic_year = ?
            AND a.status = 1
        WHERE al.date_taken = ?
            AND EXISTS (
                SELECT 1
                FROM ledger_transaction_tbl lt
                JOIN invoice_type_transaction itt
                    ON itt.trans_no = lt.trans_no
                    AND itt.transaction_type_id = lt.trans_type
                JOIN transaction_numbers_tbl tn
                    ON tn.trans_number = lt.trans_no
                WHERE lt.name_id = ar.student_id
                    AND lt.transation_nature = 1
                    AND lt.trans_type = 1
                    AND lt.name_type_id = 1
                    AND tn.trans_type_id = 1
                    AND tn.trans_date LIKE CONCAT(?, '%')
                    AND itt.invoice_type_id = 2
            )
        GROUP BY al.class_id
    ", [$year, date('Y-m-d'), $year])->getResult();

    $previousAttendanceRows = $this->db->query("
        SELECT
            al.class_id,
            SUM(CASE WHEN ar.type = 1 THEN 1 ELSE 0 END) AS present_count
        FROM attendance_list_tbl al
        JOIN attendance_record ar
            ON ar.attendance_id = al.id
        JOIN admission_tbl a
            ON a.student_id = ar.student_id
            AND a.class_id = al.class_id
            AND a.stream_id = al.stream_id
            AND a.academic_year = ?
            AND a.status = 1
        WHERE al.date_taken = DATE_SUB(?, INTERVAL 1 DAY)
            AND EXISTS (
                SELECT 1
                FROM ledger_transaction_tbl lt
                JOIN invoice_type_transaction itt
                    ON itt.trans_no = lt.trans_no
                    AND itt.transaction_type_id = lt.trans_type
                JOIN transaction_numbers_tbl tn
                    ON tn.trans_number = lt.trans_no
                WHERE lt.name_id = ar.student_id
                    AND lt.transation_nature = 1
                    AND lt.trans_type = 1
                    AND lt.name_type_id = 1
                    AND tn.trans_type_id = 1
                    AND tn.trans_date LIKE CONCAT(?, '%')
                    AND itt.invoice_type_id = 2
            )
        GROUP BY al.class_id
    ", [$year, date('Y-m-d'), $year])->getResult();

    $attendanceByClass = [];
    foreach ($attendanceRows as $row) {
        $attendanceByClass[(int) $row->class_id] = $row;
    }

    $previousAttendanceByClass = [];
    foreach ($previousAttendanceRows as $row) {
        $previousAttendanceByClass[(int) $row->class_id] = (int) $row->present_count;
    }

    $summary = [];
    foreach ($availableRows as $row) {
        $attendance = $attendanceByClass[(int) $row->id] ?? null;
        $present = $attendance ? (int) $attendance->present_count : 0;
        $absent = $attendance ? (int) $attendance->absent_count : 0;
        $late = $attendance ? (int) $attendance->late_count : 0;
        $previousPresent = $previousAttendanceByClass[(int) $row->id] ?? 0;
        $trendValue = $present - $previousPresent;
        $trend = $trendValue > 0 ? 'up' : ($trendValue < 0 ? 'down' : 'same');
        $summary[] = [
            'class' => $row->class_name,
            'available' => (int) $row->available,
            'present' => $present,
            'absent' => $absent,
            'late' => $late,
            'total' => $present + $absent + $late,
            'previous_present' => $previousPresent,
            'trend' => $trend,
            'trend_value' => $trendValue,
        ];
    }

    return $summary;
}


function classification(){
     $data=array(
              'cid'=>$this->CompanyModel->gettable_data('classification_tbl',$where=array('id >' =>0))
            );
    return view('templates/header')
        .view('company/classification',$data)
        .view('templates/footer');
}

function save_classification(){
     $check= $this->CompanyModel->gettable_data('classification_tbl',$where=array('class_name' =>$this->request->getPost('class_name'),));
            if(count($check)>0){
                echo 1;
            }else{
                 $data = [
                        'class_name' => strtoupper($this->request->getPost('class_name')),
                      'created_by' =>$_SESSION['user_id'],
                         'date_created ' => date('Y-m-d H:i:s'),
                         
                     ];
                 $this->CompanyModel->Save_data('classification_tbl',$data);
                 echo 2;
             }
}

function classification_data($id){
    $data=array(
              'cid'=>$this->CompanyModel->gettable_data('classification_tbl',$where=array('id' =>$id))
            );
         echo view('company/form/classification_edit',$data);
}

function edit_classification(){
    $id=$this->request->getPost('id');
      $data = [
            'class_name' => strtoupper($this->request->getPost('class_name')),
          'created_by' =>$_SESSION['user_id'],
        'date_created ' => date('Y-m-d H:i:s'),
             
         ];
         $this->smodel->update_table_details('classification_tbl',$where = array('id' => $id),$data);
              echo 1;
}
//endup here
}
