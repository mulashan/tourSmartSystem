<?php 
    namespace App\Controllers;

    use CodeIgniter\Controller;
    use App\Models\TransportModel;

    use App\Models\StudentModel;
    use App\Libraries\SchoolLibrary;
    use App\Models\LoginModel;
    use App\Models\SystemModel;
    use App\Models\AdmissionModel;
    use App\Models\ParentModel;
     use App\Models\PaymentsModel;
     
      use PhpOffice\PhpSpreadsheet\IOFactory;

    class StudentController extends BaseController{

        public $transport;
        public $StudentModel;
        protected $lib;
        public $sytm_model;
        public $amodel;
        public $pmodel;
        public function __construct(){
             if(session()->get('logged_in') !=true){
                  header("Location: " . base_url());
            exit;
            }
            $this->studentModel = new StudentModel;
            $this->transport = new TransportModel;
            $this->lib = new SchoolLibrary();
            $this->sytm_model = new SystemModel();
            $this->amodel = new AdmissionModel();
            $this->pmodel = new ParentModel();
             $this->payment_model = new PaymentsModel;
             
           $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
        }
        function student_application(){
            $data = array(
              'clevel'  => $this->studentModel->get_active_item('class_level_tbl'),
              'student' => $this->studentModel->getnationalities('students_application_tbl')
            );
            return view('templates/header')
            .view('student/student_application',$data)
            .view('templates/footer');
        }

        function semister(){
            return view('templates/header')
            .view('student/semister')
            .view('templates/footer');
        } 
        function accomodation(){
            return view('templates/header')
            .view('student/accomodation')
            .view('templates/footer');
        } 
        function transport(){
            $data=array(
            'fetch'=>$this->transport->getAllVehicles(),
            'result'=>$this->transport->ChargedItem(),
            'update'=>$this->transport->getAllVehicles()
            );
            
            return view('templates/header')
            .view('student/transport',$data)
            .view('student/source')
            .view('templates/footer');
        }

        function student_registration(){
            $data = array(
                'nationalities' => $this->studentModel->getnationalities('nationalities'),
                'student' => $this->studentModel->getnationalities('students')
            );
            return view('templates/header')
            .view('student/student_reg',$data)
            .view('templates/footer');   
        }

        public function save_student_details(){
           
           $student_reg = [
                'firstname' => [
                    'label' => 'First Name',
                    'rules' => 'required|min_length[2]|max_length[30]',
                  ] ,
                'mname' => [
                    'label' => 'Middle Name',
                    'rules' => 'required',
                ] ,
                'lname' => [
                    'label' => 'Last Name',
                    'rules' => 'required|max_length[50]',
                ] ,
                'dob' => [
                    'label' => 'Date of Birth',
                    'rules' => 'required',
                ] ,
                'gender' => [
                    'label' => 'Gender',
                    'rules' => 'required',
                ] ,
                'nationalty' => [
                    'label' => 'Nationality',
                    'rules' => 'required',
                ] ,
               'religion' => [
                    'label' => 'Religion',
                    'rules' => 'required',
                   ],
               'regid' => [
                    'label' => 'Student',
                    'rules' => 'required',
                ] 
                ];
           
           if ($this->validate($student_reg)){
                $student_exist = $this->studentModel->check_student('students',$this->request->getPost('firstname'),$this->request->getPost('mname'),$this->request->getPost('lname'));
                $student_id_exist = $this->studentModel->check_student_with_id($where = array('student_id' => $this->request->getPost('regid')));
//                if(!empty($this->request->getPost('gnno'))){
//                    $student_gno_exist = $student->check_student_with_id($where = array('government_no' => $this->request->getPost('gnno'))); 
//                }
                if($student_exist){
                 echo json_encode(array('status' =>'2','statusDesc' => 'Student '.$this->request->getPost('firstname').' '.$this->request->getPost('mname').' '.$this->request->getPost('lname').'  Already registerd'));
                }
                // else if($student_id_exist){
                //    echo json_encode(array('status' =>'2','statusDesc' => 'Student '.$this->request->getPost('firstname').' '.$this->request->getPost('mname').' '.$this->request->getPost('lname').' Already registerd'));
                // }
//                else if($student_gno_exist){
//                   echo '<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
//                    <span class="glyphicon glyphicon-ok"></span>Student With the same Government Number(Name '.$student_id_exist[0]->first_name.' '.$student_id_exist[0]->middle_name.' '.$student_id_exist[0]->last_name.') Already registerd.</div>'; 
//                }
                else{
                    $img = $this->request->getFile('imgFile');
                    if(!$img==""){
                     $img_name = "";
                    if($img->isValid() && !$img->hasMoved()){
                        $img_name = $img->getName().time();
                        $img->move(ROOTPATH.'public/student_photos/',$img_name);
                         }
                         }
  //                   if($img==""){
  //                    $img2 = $this->request->getPost('image');
  //                   $folderPath = "public/student_photos/";

  

  //   $image_parts = explode(";base64,", $img2);

  //   $image_type_aux = explode("image/", $image_parts[0]);

  //   $image_type = $image_type_aux[0];
  //   $image_base64 = base64_decode($image_parts[0]);

  //   $img = uniqid() . '.png';
  //   $file = $folderPath . $img;

  //   file_put_contents($file, $image_base64);

  // $img_name=$img;
                     
  //                   }
                    
                    
                    $data = [
                         'first_name' => ucfirst($this->request->getPost('firstname')),
                         'middle_name' => ucfirst($this->request->getPost('mname')),
                         'last_name' => ucfirst($this->request->getPost('lname')),
                         'birth_date' => $this->request->getPost('dob'),
                         'gender' => $this->request->getPost('gender'),
                         'nationality' => $this->request->getPost('nationalty'),
                         'religion' => $this->request->getPost('religion'),
                         'government_no' => $this->request->getPost('gnno'),
                         'student_id' => $this->request->getPost('regid'),
                         'student_photo' => $this->request->getPost('image'),
                         'created_by' => $_SESSION['user_id'],
                         'student_photo' => $img_name,
                         'date_created ' => date('Y-m-d H:i:s'),
                         'full_name' => ucfirst($this->request->getPost('firstname')).' '.ucfirst($this->request->getPost('mname')).' '.ucfirst($this->request->getPost('lname')),
                         'initial_class' => $this->request->getPost('iclass'),
                     ];
                 $studentid = $this->studentModel->SaveData_n_get_id('students',$data); 

                 if(!empty($studentid)){
                    $aID = $this->request->getPost('appID');

                     $data2 = [
                        // 'id' => $aID,
                        'students_ID' => $studentid,
                     ];

                     $this->studentModel->update_table_details('students_application_tbl', $where = array('id' => $aID),$data2);
                 }
                 echo json_encode(array('status' =>'0','statusDesc' => 'Student '.$this->request->getPost('firstname').' '.$this->request->getPost('mname').' '.$this->request->getPost('lname').' Registration Successful','student' => $studentid));
                  
                }
            }else{
                echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));
                
            }
       }
       public function save_parent_details(){
           $parent_reg = [
                'pname' => [
                    'label' => 'Parent/Guardian First Name',
                    'rules' => 'required'
                ] ,
                'plname' => [
                    'label' => 'Parent/Guardian Last Name',
                    'rules' => 'required'
                ] ,
                'rltn' => [
                    'label' => 'Relation',
                    'rules' => 'required'
                ] ,
                'addrs' => [
                    'label' => 'Parent/Guardian Date of Birth',
                    'rules' => 'required'
                ] ,
                'occp' => [
                    'label' => "Parent/Guardian Occupation",
                    'rules' => 'required',
                ] ,
                'phone1' => [
                    'label' => "Phone Number 1",
                    'rules' => 'required',
                ] ,
                ];
            if ($this->validate($parent_reg)){
                $student_exist = $this->studentModel->check_student_with_id($where = array('id' => $this->request->getPost('studentid')));
                if($student_exist){
                    $parents = $this->studentModel->gettable_data('parents_tbl',$where = array('bill_account' => 0,'first_name' => $this->request->getPost('pname'),'last_name' => $this->request->getPost('plname'))); 
                    if($parents){
                        echo json_encode(array('status' =>'1','statusDesc' => 'Student Name <b>'.$student_exist[0]->first_name.' '. $student_exist[0]->middle_name.' '.$student_exist[0]->last_name.'</b> ,Parent/Guardian With the Name <b>'.$parents[0]->first_name.' And '.$parents[0]->last_name.'</b> Already registerd.'));
                       }else{
                            $data = [
                                'first_name' => ucfirst($this->request->getPost('pname')),
                                'last_name' => ucfirst($this->request->getPost('plname')),
                                'full_name' => ucfirst($this->request->getPost('pname')).' '.ucfirst($this->request->getPost('plname')),
                                'relation' => $this->request->getPost('rltn'),
                                'address' => ucfirst($this->request->getPost('addrs')),
                                'occupation' => ucfirst($this->request->getPost('occp')),
                                'phone1' => $this->request->getPost('phone1'),
                                'phone2' => $this->request->getPost('phone2'),
                                'email' => $this->request->getPost('email'),
                                // 'student_id' => $this->request->getPost('studentid')
                            ];
                            $parentID = $this->studentModel->SaveData_n_get_id('parents_tbl',$data); 

                            if(!empty($parentID)){
                                $childParent = [
                                    'parent_id' => $parentID,
                                    'student_id' => $this->request->getPost('studentid')  
                                ];
                                $this->studentModel->SaveData('parents_students_tbl',$childParent);
                            }
                             echo json_encode(array('status' =>'0','statusDesc' => 'Parent Registration Successful'));
                        }
                }else{
                    echo json_encode(array('status' =>'1','statusDesc' => 'Sorry Register First Student Does Not Exist'));
                }
            }else{
                  echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));
                
            }

    }
    function load_parent_details($pid,$sid){
       $parents = $this->studentModel->gettable_parentdata($pid,$sid); 
       $sn = 1;
       foreach ($parents as $p){
           if($p->relation == 1){
              $relation = 'Mother'; 
           }
           else if($p->relation == 2)
           {
              $relation = 'Father'; 
           }else if($p->relation == 3){
               $relation = 'Guardian'; 
           }
           echo '<tr>';
           echo '<td>'.$sn++.'</td>';
           echo '<td>'.$p->first_name .' '.$p->last_name.'</td>';
           echo '<td>'.$relation.'</td>';
           echo '<td>'.$p->phone1.'</td>';
           echo '<td>'.$p->email.'</td>';
           echo '<td>'.$p->occupation.'</td>';
           echo '<td>'.$p->address.'</td>';
           echo '<td><a href="javascript:void(0)" onclick="edit_item(\'' . $p->sp_id . '\',\'parents_tbl\')"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;'
           . '<a href="javascript:void(0)" onclick="delete_item(\'' . $p->sp_id . '\',\'' . $pid . '\',\'' . $sid. '\',\'parents_tbl\',\'show_parent\')"  class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a></td></tr>';
           
       }
    }
        function load_parent_details1($sid){
            $pid=1;
       $parents = $this->studentModel->gettable_parentdata($pid,$sid); 
       $sn = 1;
       foreach ($parents as $p){
           if($p->relation == 1){
              $relation = 'Mother'; 
           }
           else if($p->relation == 2)
           {
              $relation = 'Father'; 
           }else if($p->relation == 3){
               $relation = 'Guardian'; 
           }
           echo '<tr>';
           echo '<td>'.$sn++.'</td>';
           echo '<td>'.$p->first_name .' '.$p->last_name.'</td>';
           echo '<td>'.$relation.'</td>';
           echo '<td>'.$p->phone1.'</td>';
           echo '<td>'.$p->email.'</td>';
           echo '<td>'.$p->occupation.'</td>';
           echo '<td>'.$p->address.'</td>';
           echo '<td><a href="javascript:void(0)" onclick="edit_item(\'' . $p->sp_id . '\',\'parents_tbl\')"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;'
           . '<a href="javascript:void(0)" onclick="delete_item(\'' . $p->sp_id . '\',\'' . $p->parent_id . '\',\'' . $sid. '\',\'parents_tbl\',\'show_parent\')"  class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a></td></tr>';
           
       }
    }
    function save_previous_school(){
         $previous_school = [
                'scname' => [
                    'label' => 'Previous School Name',
                    'rules' => 'required'
                ] ,
                'scyr' => [
                    'label' => 'Year attended',
                    'rules' => 'required'
                ] 
             ];
          if ($this->validate($previous_school)){
            $student_exist = $this->studentModel->check_student_with_id($where = array('id' => $this->request->getPost('studentid')));
            if($student_exist){
                $previous_sch = $this->studentModel->gettable_data('previous_school',$where = array('school_name' => $this->request->getPost('scname'),'year_attended' => $this->request->getPost('scyr'),'student_id' => $this->request->getPost('studentid'))); 
                if($previous_sch){
                     echo json_encode(array('status' =>'1','statusDesc' => 'Student Name <b>'.$student_exist[0]->first_name.' '. $student_exist[0]->middle_name.' '.$student_exist[0]->last_name.'</b> ,Previous School With the Name <b>'.$previous_sch[0]->school_name.' And '.$previous_sch[0]->year_attended.'</b> Already registerd.'));
                  }else{
                    $data = [
                        'school_name' => ucfirst($this->request->getPost('scname')),
                        'year_attended' => $this->request->getPost('scyr'),
                        'student_id' => $this->request->getPost('studentid')
                    ];
                    $this->studentModel->SaveData('previous_school',$data); 
                    echo json_encode(array('status' =>'0','statusDesc' => 'Previous School Registration Successful'));
                  }
            }else{
                echo json_encode(array('status' =>'1','statusDesc' => 'Sorry Register First Student Does Not Exist'));
            }
            }else{
                echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));
               // echo  $this->validation->listErrors();
                
            }
    }
    function show_previous_school($id){
       $previous_sch = $this->studentModel->gettable_data('previous_school',$where = array('student_id' => $id)); 
       $sn = 1;
       foreach ($previous_sch as $pc){
           echo '<tr>';
           echo '<td>'.$sn++.'</td>';
           echo '<td>'.$pc->school_name.'</td>';
           echo '<td>'.$pc->year_attended.'</td>';
           echo '<td><a href="javascript:void(0)" onclick="edit_item(\'' . $pc->id . '\',\'previous_school\',\'previous_school\')"  class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;'
           . '<a href="javascript:void(0)" onclick="delete_item1(\'' . $pc->id . '\',\'previous_school\',\'previous_school\')"  class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a></td></tr>';
       }  
    }
    function save_bill_info(){
              $parent_reg = [
                'pname' => [
                    'label' => 'Parent/Guardian First Name',
                    'rules' => 'required'
                ] ,
                'plname' => [
                    'label' => 'Parent/Guardian Last Name',
                    'rules' => 'required'
                ] ,
                'baddrs' => [
                    'label' => 'Address',
                    'rules' => 'required'
                ] ,
                'phone1' => [
                    'label' => "Phone",
                    'rules' => 'required',
                ]
                ];
            if ($this->validate($parent_reg)){
                   $student_exist = $this->studentModel->check_student_with_id($where = array('id' => $this->request->getPost('studentid')));
                   if($student_exist){
                   $data = [
                       'first_name' => strtoupper($this->request->getPost('pname')),
                       'last_name' => strtoupper($this->request->getPost('plname')),
                       'address' => ucfirst($this->request->getPost('baddrs')),
                       'postal_address' => $this->request->getPost('paddrs'),
                       'phone1' => $this->request->getPost('phone1'),
                       'email' => $this->request->getPost('email'),
                       // 'student_id' => $this->request->getPost('studentid'),
                       'bill_account' => 1
                   ];
                   $parentID = $this->studentModel->SaveData_n_get_id('parents_tbl',$data);
                   if(!empty($parentID)){
                        $childParent = [
                            'parent_id' => $parentID,
                            'student_id' => $this->request->getPost('studentid')  
                        ];
                        $this->studentModel->SaveData('parents_students_tbl',$childParent);
                    } 
                   $this->session->setTempdata('resp','<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>Student Name <b>'.$student_exist[0]->first_name.' '. $student_exist[0]->middle_name.' '.$student_exist[0]->last_name.'</b>, Bill Information Saved Successful</div>',60);
                   echo '1';
                   }else{
                  echo 'Sorry Register First Student Does Not Exist'; 
               }
         }else{
                echo  $this->validation->listErrors();
            }
    }
    function delete_item(){
        $delete = $this->studentModel->deletetable_data($this->request->getPost('tbl'),$this->request->getPost('id'));  
    }
     function delete_item1(){
        $delete = $this->studentModel->deletetable_data1($this->request->getPost('tbl'),$this->request->getPost('id'));  
    }
    function edit_student_details($id){
       $student= $this->studentModel->check_student_with_id($where = array('id' => $id));
        if(count($student) > 0){
           $data = array(
               'student' => $student,
               'nation' => $this->studentModel->getnationalities('nationalities'),
               'bill' => $this->studentModel->gettable_billingdata($id)
           );
            return view('student/edit_student',$data);
        }
        else{
            echo 'No student details found';
        }
    }
    function update_student(){
         $student_reg = [
                'firstname' => [
                    'label' => 'First Name',
                    'rules' => 'required|min_length[2]|max_length[30]',
                  ] ,
                'mname' => [
                    'label' => 'Middle Name',
                    'rules' => 'required',
                ] ,
                'lname' => [
                    'label' => 'Last Name',
                    'rules' => 'required|max_length[50]',
                ] ,
                'dob' => [
                    'label' => 'Date of Birth',
                    'rules' => 'required',
                ] ,
                'gender' => [
                    'label' => 'Gender',
                    'rules' => 'required',
                ] ,
                'nationalty' => [
                    'label' => 'Nationality',
                    'rules' => 'required',
                ] ,
               'religion' => [
                    'label' => 'Religion',
                    'rules' => 'required',
                   ],
               'regid' => [
                    'label' => 'Student',
                    'rules' => 'required',
                ] 
                ];
           
           if ($this->validate($student_reg)){
                    $img = $this->request->getFile('imgFile');
                    echo $img;
                    $img_name = "";
                    if($img->isValid() && !$img->hasMoved()){
                        $img_name = time().$img->getName();
                        $img->move(ROOTPATH.'public/student_photos/',$img_name); 
                    }
                    
                     $previous_names = $this->studentModel->gettable_data('students',$where = array('id' => $this->request->getPost('studentid')));
                    $data = [
                         'first_name' => strtoupper($this->request->getPost('firstname')),
                         'middle_name' => strtoupper($this->request->getPost('mname')),
                         'last_name' => strtoupper($this->request->getPost('lname')),
                         'birth_date' => $this->request->getPost('dob'),
                         'gender' => $this->request->getPost('gender'),
                         'nationality' => $this->request->getPost('nationalty'),
                         'religion' => $this->request->getPost('religion'),
                         'government_no' => $this->request->getPost('gnno'),
                         'student_id' => $this->request->getPost('regid'),
                         'student_photo' => $this->request->getPost('image'),
                         'created_by' => $_SESSION['user_id'],
                         'student_photo' => $img_name,
                         'date_created ' => date('Y-m-d H:i:s'),
                         'full_name' => ucfirst($this->request->getPost('firstname')).' '.ucfirst($this->request->getPost('mname')).' '.ucfirst($this->request->getPost('lname')),
                         'initial_class' => $this->request->getPost('iclass'),
                     ];
                  $this->studentModel->update_table_details('students',$where = array('id' => $this->request->getPost('studentid')),$data); 
                  
                   $reference = $this->studentModel->gettable_data('payment_request',$where = array('student_id' => $this->request->getPost('studentid')));
               $fname=strtoupper($this->request->getPost('firstname'));
               $mname=strtoupper($this->request->getPost('mname'));
               $lname=strtoupper($this->request->getPost('lname'));
               
               if($previous_names[0]->first_name !=$fname || $previous_names[0]->middle_name !=$mname || $previous_names[0]->last_name !=$lname && count($reference)>0 ){
            // echo " not same";
               echo json_encode(array('status' =>'2','student_id' =>$this->request->getPost('studentid'), 'statusDesc' => 'Student '.$this->request->getPost('firstname').' '.$this->request->getPost('mname').' '.$this->request->getPost('lname').' Updated Successful', ));

             }else{
               //  echo "same";
                  echo json_encode(array('status' =>'0','statusDesc' => 'Student '.$this->request->getPost('firstname').' '.$this->request->getPost('mname').' '.$this->request->getPost('lname').' Updated Successful'));
               
                   }
             }else{
                echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));
                
            }  
    }
    function get_parent_details(){
        if($this->request->getPost('tbl')=='parents_tbl'){

        $parent = $this->studentModel->gettable_data1($this->request->getPost('tbl'),$this->request->getPost('id')); 
    }else{
       
     $parent = $this->studentModel->gettable_data($this->request->getPost('tbl'),$where=array('id' => $this->request->getPost('id')));    
    }
       if(count($parent)>0){
        return json_encode($parent);
    }else{
        echo "1";
    }
}
function update_parent_details(){
   $parent_reg = [
                'pname' => [
                    'label' => 'Parent/Guardian First Name',
                    'rules' => 'required'
                ] ,
                'plname' => [
                    'label' => 'Parent/Guardian Last Name',
                    'rules' => 'required'
                ] ,
                'rltn' => [
                    'label' => 'Relation',
                    'rules' => 'required'
                ] ,
                'addrs' => [
                    'label' => 'Parent/Guardian Date of Birth',
                    'rules' => 'required'
                ] ,
                'occp' => [
                    'label' => "Parent/Guardian Occupation",
                    'rules' => 'required',
                ] ,
                'phone1' => [
                    'label' => "Phone Number 1",
                    'rules' => 'required',
                ] ,
                ];
            if ($this->validate($parent_reg)){
                
                $data = [
                    'first_name' => ucfirst($this->request->getPost('pname')),
                    'last_name' => ucfirst($this->request->getPost('plname')),
                    'relation' => $this->request->getPost('rltn'),
                    'address' => $this->request->getPost('addrs'),
                    'occupation' => ucfirst($this->request->getPost('occp')),
                    'phone1' => $this->request->getPost('phone1'),
                    'phone2' => $this->request->getPost('phone2'),
                    'email' => $this->request->getPost('email')
                ];
                $this->studentModel->update_table_details('parents_tbl',$where = array('id' => $this->request->getPost('parentid')),$data); 
                 echo json_encode(array('status' =>'0','statusDesc' => 'Parent Update Successful'));
            }else{
                  echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));
                
            }
}
function update_previous_school(){
   $previous_school = [
        'scname' => [
            'label' => 'Previous School Name',
            'rules' => 'required'
        ] ,
        'scyr' => [
            'label' => 'Year attended',
            'rules' => 'required'
        ] 
     ];
  if ($this->validate($previous_school)){
    $data = [
        'school_name' => ucfirst($this->request->getPost('scname')),
        'year_attended' => $this->request->getPost('scyr')
    ];
     $this->studentModel->update_table_details('previous_school',$where = array('id' => $this->request->getPost('PcId')),$data);  
     echo json_encode(array('status' =>'0','statusDesc' => 'School Updated Successful'));

    }else{
        echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));
       // echo  $this->validation->listErrors();

    }  
}
function update_bill_info(){
    $parent_reg = [
        'pname' => [
            'label' => 'Parent/Guardian First Name',
            'rules' => 'required'
        ] ,
        'plname' => [
            'label' => 'Parent/Guardian Last Name',
            'rules' => 'required'
        ] ,
        'baddrs' => [
            'label' => 'Address',
            'rules' => 'required'
        ] ,
        'phone1' => [
            'label' => "Phone",
            'rules' => 'required',
        ]
        ];
    if ($this->validate($parent_reg)){
        $student_exist = $this->studentModel->gettable_data('parents_tbl',$where = array('id' => $this->request->getPost('bid')));
           if($student_exist){
                $data = [
                    'first_name' => strtoupper($this->request->getPost('pname')),
                    'last_name' => strtoupper($this->request->getPost('plname')),
                    'address' => ucfirst($this->request->getPost('baddrs')),
                    'postal_address' => $this->request->getPost('paddrs'),
                    'phone1' => $this->request->getPost('phone1'),
                    'email' => $this->request->getPost('email'),
                    'bill_account' => 1
                ];
            $this->studentModel->update_table_details('parents_tbl',$where = array('id' => $this->request->getPost('bid')),$data); 
            echo 1;
           }else{
         // echo 'Sorry Register First Student Does Not Exist'; 
               $this->save_bill_info();
       }
    }else{
        echo  $this->validation->listErrors();
    }
}
function save_application(){


    $student_reg = [
               'fname' => [
                   'label' => 'First Name',
                   'rules' => 'required|min_length[2]|max_length[30]',
                 ] ,
               'mname' => [
                   'label' => 'Middle Name',
                   'rules' => 'required',
               ] ,
               'lname' => [
                   'label' => 'Last Name',
                   'rules' => 'required|max_length[50]',
               ] ,
               'dob' => [
                   'label' => 'Date of Birth',
                   'rules' => 'required',
               ] ,
               'gender' => [
                   'label' => 'Gender',
                   'rules' => 'required',
               ] ,
               'classlevel' => [
                   'label' => 'Class Level',
                   'rules' => 'required',
               ] ,
             'class' => [
                  'label' => 'Class',
                  'rules' => 'required',
                 ],
              'pfname' => [
                   'label' => 'Parent/Gurdian First Name',
                   'rules' => 'required',
               ], 
               'plname' => [
                   'label' => 'Parent/Gurdian Last Name',
                   'rules' => 'required',
               ],
               'bphone' => [
                   'label' => 'Bill Phone Number',
                   'rules' => 'required|min_length[10]|max_length[15]',
               ] 
               ];

           if ($this->validate($student_reg)){
           
               $student_exist = $this->studentModel->check_student_inapplication('students_application_tbl',$this->request->getPost('fname'),$this->request->getPost('mname'),$this->request->getPost('lname'),$this->request->getPost('class'));
               
               if($student_exist){
                   echo json_encode(array('status' =>'error','statusDesc' => 'Student Application With the same Name <b>'.$student_exist[0]->first_name.' '.$student_exist[0]->middle_name.' '.$student_exist[0]->last_name.'</b> Already registerd on selected class'));
                  
               } else{
                   $data = [
                        'first_name' => ucfirst($this->request->getPost('fname')),
                        'middle_name' => ucfirst($this->request->getPost('mname')),
                        'last_name' => ucfirst($this->request->getPost('lname')),
                        'date_of_birth' => $this->request->getPost('dob'),
                        'gender' => $this->request->getPost('gender'),
                        'class_lvl' => $this->request->getPost('classlevel'),
                        'class' => $this->request->getPost('class'),
                        'parent_firstname' => ucfirst($this->request->getPost('pfname')),
                        'parent_lastname' => ucfirst($this->request->getPost('plname')),
                        'phone_number' => $this->request->getPost('bphone'),
                        'created_by' => $_SESSION['user_id'],
                        'date_created ' => date('Y-m-d H:i:s'),
                        'full_name' => ucfirst($this->request->getPost('fname')).' '.ucfirst($this->request->getPost('mname')).' '.ucfirst($this->request->getPost('lname'))
                    ];

                    if($this->request->getPost('class2')==$this->request->getPost('class')){
                         echo json_encode(array('status' =>'error','statusDesc' => 'Student Already applied on the same class'));
                    }else{
                         
                  $studentid = $this->studentModel->SaveData_n_get_id('students_application_tbl',$data); 
                    
                   $this->prepare_invoice($studentid,$this->request->getPost('classlevel'));
                    }
                 }
           }else{
               echo json_encode(array('status' =>'error','statusDesc' =>  $this->validation->listErrors()));

           }
}

 public function getToken($tokenUrl) {
        $credentials = array(
            'username' => NMB_USERNAME,
            'password' => NMB_PASSWORD
        );  
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $tokenUrl);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));        
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($credentials));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $output = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
        $tokenOutput = json_decode($output);
        if($error){
            return 'Error: '.$error;
        }else{
            return $tokenOutput;
        }
}

public function sendinvoice_dtls($total,$reg_no){
        $app_details=$this->studentModel->gettable_data('students_application_tbl',$where = array('id' => $reg_no));
        $receipt=$this->studentModel->gettable_data('payment_request',$where = array('student_id ' => $reg_no,'payment_status' => 0));
        $student_name = $app_details[0]->first_name." ".$app_details[0]->middle_name." ".$app_details[0]->last_name;
        $token_resp = $this->getToken(NMB_URL."auth");
        if(count($receipt) == 0){
            if($token_resp->{'status'} == 1){
                $tym = date('Y-m-d H:i:s');
                $ref = $this->generate_reference_no();    
                $invoice = array (
                "reference" => $ref,
                "student_name" => $student_name,
                "student_id" => $reg_no,
                "amount" => $total,
                "type" => "Application Fee",
                "code" => 10,
                "allow_partial" => FALSE,
                "callback_url" => NMB_CALLBACK."receiverPayment_auto",
                "token" => $token_resp->{'token'}
                );
                 file_put_contents('Apifeedback/req' . $ref. '.txt', json_encode($invoice));
                $url = NMB_URL.'invoice_submission';
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($invoice));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                $err = curl_error($ch); 
                curl_close($ch);
                
        $status = 4;//request notsent
        if ($err) {
            echo "Error #:" . $err;
            $status = 5;
        } else {
            file_put_contents('Apifeedback/nmb_resp.text', $response);
            $obj2 = json_decode($response,TRUE);
            $status = $obj2['status'];
            
        }
          $nmb_data = array(
              //  'trans_no' =>  $trans,
                'student_id' =>  $reg_no,
                'reference_no' => $ref,
                'amount' => $total,
                'payment_status' => 0,
                'payment_channel' => '2', //NMB
                'date_created' => $tym,
                'allow_partial' => 0
             );
          $this->studentModel->SaveData('payment_request',$nmb_data);
          $msg = "Kumb No: ".$ref.", Ombi namba: ".$reg_no.", Tarehe: ".date('d/m/Y H:i').", Kiasi:TZS ".number_format($total).", Muombaji: ".$app_details[0]->first_name." ".$app_details[0]->last_name.".".
                 "Tafadhali lipia kukamilisha ombi lako.";
          //$this->SMSsender($app_details[0]->phone_number,$msg,6,$ref);
          echo ' Student Name '.$student_name.' Reference Number '.$ref .' Created Successful';
        }else{
            exit;
        }
      }
      else{
         if($total != $receipt[0]->amount){
            if($token_resp->{'status'} == 1){   
                $invoice = array (
                "reference" => $receipt[0]->reference_no ,
                "student_name" => $app_details[0]->first_name." ".$app_details[0]->middle_name." ".$app_details[0]->last_name,
                "student_id" =>$reg_no,
                "amount" => $total,
                "type" => "Application Fee",
                "code" => 10,
                "callback_url" => NMB_CALLBACK."receiverPayment_auto",
                "token" => $token_resp->{'token'}
                );
                $url = NMB_URL.'invoice_update';
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($invoice));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                $err = curl_error($ch); 
                curl_close($ch);
                file_put_contents('Apifeedback/nmb_resp.text', $response);
                
            $status = 4;//request notsent
            if ($err) {
                echo "Error #:" . $err;
                $status = 5;
            } else {
            $obj2 = json_decode($response, TRUE);
            $status = $obj2->{'status'};
            file_put_contents('Apifeedback/nmb_resp.text', $obj2);
        }
         $nmb_data = array(
            'amount' => $total
         );
         $this->studentModel->update_table_details('payment_request',$where = array('id' => $receipt[0]->id),$nmb_data); 
       }
       else{
            exit;
        }
        }
      }
    }
 function createControl_number_crdb($total_cost,$reg_no,$des,$invtype){
    $year = (int)date('Y');
    
    $user_id=$this->request->getPost('header_id');
     
    if($invtype!=6){
       $student_details = $this->studentModel->gettable_data('students',$where = array('id' => $student_id)); 
   }else{
    $student_details=$this->studentModel->gettable_data('students_application_tbl',$where = array('id' => $reg_no));
   }
         
          $db_id=$this->request->getPost('db_id');
          $db='default';
          $bank_requirements = $this->payment_model->get_item_name('payments_requirements_tbl',$where = array('db_id' => $db_id, 'status'=>1),$db);  
          if(count($bank_requirements)>0){
            $charge=$bank_requirements[0]->charges;
          $curl=base_url().''.$bank_requirements[0]->application_callbackUrl;

         $facility_id=$bank_requirements[0]->facility_id;
         $payment_type=$bank_requirements[0]->payment_type;
         $prefix=$bank_requirements[0]->prefix;
         $crdb_url=CRDB_URL_1;
         $desc=$des.' : '.$total_cost.' and Bank charges : '.$charge;

          }
        else{
             $msg = "Kumb No: ---, Ombi namba: ".$reg_no.", Tarehe: ".date('d/m/Y H:i').", Kiasi:TZS ".number_format($total_cost).", Muombaji: ".$student_details[0]->first_name." ".$student_details[0]->last_name.". ".$des.
                 "."; 
                  $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname. description.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 6,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>$user_id,
                    'messagex' => $messagex,
                    'trans_number' => $reg_no
                  
                );
      
 $this->studentModel->SaveData('message_groups_tbl',$smsdata);

   $this->SMSsender($student_details[0]->phone_number,$msg,6,$reg_no,$snn,NULL);
    echo json_encode(array('status' =>1,'statusDesc' => 'saved successfully.'));
    return;
   }
          $data=array(
            'name' =>$student_details[0]->full_name,
            'receipt_no' => $year.$reg_no,
            'amount' => $total_cost+$charge,
            'currency' => 'TZS',
            'payment_desc' => $desc,
            'visit_no'=>$student_details[0]->id,
            'file_no'=>$reg_no,
            'payment_channel' => 1,
            'facility_id' => $facility_id,
            'payment_type' => $payment_type,
            'prefix' => $prefix,
            'call_back_url' => $curl,
            'allow_partial' => 'FIXED'
              );
          //print_r(json_encode($data));

    $url = $crdb_url."createPayment";

     $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
              //  echo $response;
                $err = curl_error($ch); 
                curl_close($ch);

                 if ($err) {
                    //echo "Error #:" . $err;
                    $status = 5;
                    $reference=0;
                     $time=date('Y-m-d H:i:s');
                     echo 'Fail to create control number';
                } else {
                   
                    $obj2 = json_decode($response,TRUE);
                    if($obj2['status']=='success'){
                      $status = 1;
                    }else{
                       $status = 2;
                    }
                    $time=$obj2['date_created'];
                    
                    $reference= $obj2['paymentReference'];
                }
//$reference='EDN3345677';
//$time=date('Y-m-d H:i');
                 $crdb_data = array(
                    'trans_no' =>  $reg_no,
                    'student_id' => $reg_no,
                    'reference_no' => $reference,
                    'amount' => $total_cost,
                    'charges' => $charge,
                    'paid_charges' => 0,
                    'payment_status' => 0,
                    'payment_channel' => '3', //CRDB
                    'date_created' => $time,
                    'allow_partial' => 0,
                     'trans_type' => 1,
                     'inv_type' => 1,//application
                 );
            //print_r($crdb_data);
               $this->amodel->SaveDetails('payment_request',$crdb_data);

            // $msg = "Kumb No: ".$reference.", Tarehe: ".$time.", Kiasi:TZS ".number_format($total_cost).", Mwanafunzi: ".$student_details[0]->full_name.".".
            //      "Tafadhali Fanya Malipo Kupitia CRDB.";
                 $msg = "Kumb No: ".$reference.", Ombi namba: ".$reg_no.", Tarehe: ".date('d/m/Y H:i').", Kiasi:TZS ".number_format($total_cost).", bank charges ".number_format($charge)." jumla ".number_format($total_cost+$charge)." Muombaji: ".$student_details[0]->first_name." ".$student_details[0]->last_name.". ".$des.
                 ".";
   //****invoice msg setup*************************************//
         // $bill = $this->studentModel->gettable_billingdata($student_id);
        
        $messagex="Kumb No: xxx, Kiasi:TZS xxx, Mwanafunzi: #fullname. description.";
     $snn = $this->generate_msg_no();
      $smsdata = array(
                    'send_type' => 1,
                    'message_type' => 6,
                    'send_number' => $snn,
                    'massage_date' => date('Y-m-d'),
                    'send_by' =>$user_id,
                    'messagex' => $messagex,
                    'trans_number' => $reg_no
                  
                );
      
 $this->studentModel->SaveData('message_groups_tbl',$smsdata);

   $this->SMSsender($student_details[0]->phone_number,$msg,6,$reg_no,$snn,NULL);
       
       echo json_encode(array('status' =>'success','statusDesc' => 'Student Name '.$student_details[0]->full_name.' Reference Number '.$reference .' Created Successful '));
    
    //**********************end msginvoicesetup**********************************// 
    }

    function generate_reference_no() {
        $ino = "";
        $ref_no =  $this->studentModel->get_max_id('payment_request','reference_no');
        if (count($ref_no) > 0) {
            list($mmr_in, $nums) = explode("SAS195", $ref_no[0]->max_id);
            $nwtkn = $nums + 00001;
            $ino = "SAS195".sprintf("%05d", $nwtkn);
        } else {
            $ino ="SAS195". sprintf("%05d", 1);
        }
        return $ino;
    }
    function get_classes(){
        if($this->request->getPost('clvl')==0){
         $clvl = $this->studentModel->gettable_data('classes_tbl',$where = array('status' => 1 ));
        }else{
           $clvl = $this->studentModel->gettable_data('classes_tbl',$where = array('class_level' => $this->request->getPost('clvl') ));  
        }
      
         $classlist = array();
         //print_r($clvl);
         if(count($clvl) > 0){
             foreach($clvl as $c){
                $streamdta = $this->amodel->get_student_details('streams_tbl', $where = array('class_id' => $c->id,'status' => 1));
                $sum_sd = 0;
                foreach ($streamdta as $sd) {
                    $count = $this->amodel->get_total_stream_capacity($c->id,$sd->id);
                    $stm_ttl = $sd->stream_capacity - $count[0]->stream_id;
                    $sum_sd += $stm_ttl;
                }

                $classlist[] = array("id" => $c->id, "name" => $c->class_name, "total" => $sum_sd);
         }
        }
        echo json_encode($classlist);  
    }
    function get_stream_details(){
      
            $clvl = $this->amodel->get_student_details('streams_tbl', $where = array('class_id' => $this->request->getPost('clvl'),'status' => 1));
        
    
         $classlist = array();
         if(count($clvl) > 0){
             foreach($clvl as $c){
                $streamdta = $this->amodel->get_student_details('streams_tbl', $where = array('class_id' => $this->request->getPost('clvl'),'status' => 1));
                
                $classlist[] = array("id" => $c->id, "name" => $c->stream_name);
         }
        }
        echo json_encode($classlist);  
    }
    function save_transaction_items($student_id){
        $trans = $this->generate_transaction_no();
        $transaction = [
                'trans_type_id' => 2,
                'trans_number' => $trans,
                'trans_date' => date('Y-m-d H:i:s'),
                'updated_by' => 2,
                'updated_date' => date('Y-m-d H:i:s')
        ];
    //    $clvl = $this->studentModel->gettable_data('students_application_tbl',$where = array('id' => $student_id ));
        $this->studentModel->SaveData('transaction_numbers_tbl',$transaction); 
        $total_cost = 0;
        $invoice_type = [
             'trans_no' => $trans,
             'transaction_type_id' => 2,
             'invoice_type_id' => 1
         ];
         $itm_trans = $this->studentModel->SaveData_n_get_id('invoice_type_transaction',$invoice_type);
        // $lvlprice = $this->studentModel->get_level_price($clvl[0]->class_lvl);
         $temp_id = $this->studentModel->gettable_data('temp_item_transation_tbl',$where = array('student_id' => $student_id));
         foreach($temp_id as $price){
           $itm = [
             'item_id' => $price->item_id,
             'item_type_id' => $price->item_type_id,
             'trans_number' => $trans,
             'trans_type' => 2,
             'quantity ' => $price->quantity ,
             'before_qty' => 0,
             'after_qty' => 0,
             'unit_price' => $price->unit_price,
         ];
        //Saving Items
         $itm_trans = $this->studentModel->SaveData_n_get_id('item_transation_tbl',$itm);
         $leger_items = $this->studentModel->gettable_data('items_ledgers_tbl',$where = array('item_id' => $price->item_id)); 
         foreach($leger_items as $lg){
             $total_cost+=$price->unit_price * $price->quantity;
              $legers = $this->studentModel->gettable_data('accounts_tbl',$where = array('id' => $lg->account_id)); 
             $ledger = [
                 'ledger_id' => $lg->account_id,
                 'ledger_type' => $legers[0]->account_type_id,
                 'trans_no' => $trans,
                 'trans_type' => 2,
                 'amount' => $price->unit_price * $price->quantity,
                 'transation_nature' => 1,
                 'item_transaction_id' => $itm_trans,
                 'name_type_id' => 4,
                 'name_id' => $student_id,
             ];
             $this->studentModel->SaveData('ledger_transaction_tbl',$ledger); 
         }
         $Bank_leger = $this->studentModel->gettable_data('accounts_tbl',$where = array('account_type_id' => 9)); 
             $Bledger = [
                 'ledger_id' => $Bank_leger[0]->id,
                 'ledger_type' => $Bank_leger[0]->account_type_id,
                 'trans_no' => $trans,
                 'trans_type' => 2,
                 'amount' => $price->unit_price * $price->quantity,
                 'transation_nature' => 2,
                 'name_type_id' => 4,
                 'name_id' => $student_id,
             ];
         $this->studentModel->SaveData('ledger_transaction_tbl',$Bledger);
          $temptrans = [
            'bill_status' => 1
         ];
         $this->studentModel->update_table_details('students_application_tbl',$where = array('id' => $price->id),$temptrans);
     }
    
   //  $this->sendinvoice_dtls($trans,$total_cost,$studentid);
    
       
    }
     function generate_transaction_no() {
        $ino = "";
        $tkens = $this->studentModel->get_max_receipt('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
    function generate_transaction_appno() {
        $ino = "";
        $tkens = $this->studentModel->get_max_invoice('transaction_numbers_tbl','trans_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
    function edit_application($id){
        $data = array(
            'clevel'  => $this->studentModel->get_active_item('class_level_tbl'),
            'app' => $this->studentModel->gettable_data('students_application_tbl',$where = array('id' => $id)),
            'pay' => $this->studentModel->gettable_data('payment_request',$where = array('student_id' => $id,'trans_type'=>1,'inv_type'=>1))
        );
        return view('student/edit_application',$data);
       
    }
    function update_student_application(){
         $student_reg = [
               'fname' => [
                   'label' => 'First Name',
                   'rules' => 'required|min_length[2]|max_length[30]',
                 ] ,
               'mname' => [
                   'label' => 'Middle Name',
                   'rules' => 'required',
               ] ,
               'lname' => [
                   'label' => 'Last Name',
                   'rules' => 'required|max_length[50]',
               ] ,
               'dob' => [
                   'label' => 'Date of Birth',
                   'rules' => 'required',
               ] ,
               'gender' => [
                   'label' => 'Gender',
                   'rules' => 'required',
               ] ,
               'classlevel' => [
                   'label' => 'Class Level',
                   'rules' => 'required',
               ] ,
              'bphone' => [
                   'label' => 'Bill Phone Number',
                   'rules' => 'required',
               ] 
               ];

          if ($this->validate($student_reg)){
              $app_exist = $this->studentModel->gettable_data('students_application_tbl',$where = array('id' => $this->request->getPost('appid')));
               if($app_exist){
                   $data = [
                        'first_name' => ucfirst($this->request->getPost('fname')),
                        'middle_name' => ucfirst($this->request->getPost('mname')),
                        'last_name' => ucfirst($this->request->getPost('lname')),
                        'date_of_birth' => $this->request->getPost('dob'),
                        'gender' => $this->request->getPost('gender'),
                        'class_lvl' => $this->request->getPost('classlevel'),
                        'class' => $this->request->getPost('class'),
                        'parent_firstname' => ucfirst($this->request->getPost('pfname')),
                        'parent_lastname' => ucfirst($this->request->getPost('plname')),
                        'phone_number' => $this->request->getPost('bphone'),
                        'created_by' => $_SESSION['user_id'],
                        'date_created ' => date('Y-m-d H:i:s'),
                        'full_name' => ucfirst($this->request->getPost('fname')).' '.ucfirst($this->request->getPost('mname')).' '.ucfirst($this->request->getPost('lname'))
                    ];
                   $this->studentModel->update_table_details('students_application_tbl',$where = array('id' => $this->request->getPost('appid')),$data); 

                    // $data2 = [
                    //     'first_name' => ucfirst($this->request->getPost('pfname')),
                    //     'last_name' => ucfirst($this->request->getPost('plname')),
                    //     'full_name' => ucfirst($this->request->getPost('pfname')).' '.ucfirst($this->request->getPost('plname')),
                    //     'relation' => '',
                    //     'address' => '',
                    //     'occupation' => '',
                    //     'phone1' => $this->request->getPost('bphone'),
                    //     'phone2' => $this->request->getPost('bphone'),
                    //     'email' => '',
                    //     'student_id' => $this->request->getPost('appid'),
                    //     'postal_address' => '',
                    //     'bill_account' => 2
                    // ];

                    // $this->studentModel->update_table_details('parents_tbl',$where = array('student_id' => $this->request->getPost('appid')),$data2);

                   echo json_encode(array('status' =>'0','statusDesc' => 'Student '.$this->request->getPost('fname').' '.$this->request->getPost('mname').' '.$this->request->getPost('lname').' Updated Successful'));
               }
               else{ 
                  echo json_encode(array('status' =>'1','statusDesc' =>  'Sorry Something Went Wrong..!'));
               }
           }else{
               echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));

           }
    }
 function prepare_invoice($sid,$lvl){
     $lvlprice = $this->studentModel->get_level_price($lvl);
       $total_cost =0;
       foreach($lvlprice as $price){
           $total_cost += $price->item_price;
          
           $itm = [
             'item_id' => $price->item_id,
             'item_type_id' => $price->item_type,
             'student_id' => $sid,
             'trans_type' => 1,
             'quantity ' => $price->quantity,
             'unit_price' => $price->item_price,
             'name_type_id' => 4,
             'bill_status' => 0
         ];
         $this->studentModel->SaveData('temp_item_transation_tbl',$itm);
       }
        $desc='Application Fee';
  $this->createControl_number_crdb($total_cost,$sid,$desc,6);
   //   $this->sendinvoice_dtls($total_cost,$this->request->getPost('id')); 
   }
   function check_payment(){
     $receipt=$this->studentModel->gettable_data('payment_request',$where = array('reference_no' => $this->request->getPost('ref_no'),'payment_status' => 0));
        if(count($receipt) == 0){
            return ;
        }else{
        $token_resp = $this->getToken(NMB_URL."auth");
        if($token_resp->{'status'} == 1){
         $request = array(
             "reference" => $this->request->getPost('ref_no'),
             "token" => $token_resp->{'token'}
         );
         $url = NMB_URL.'check_payment';
         $ch = curl_init();
         curl_setopt($ch, CURLOPT_URL, $url);
         curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
         curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
         curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
         curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
         curl_setopt($ch, CURLOPT_SSLVERSION, 1);
         curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($request));
         curl_setopt($ch, CURLOPT_HTTPHEADER, array(
             "Content-type: application/json",
         ));
         $response = curl_exec($ch);
         $err = curl_error($ch); 
         curl_close($ch);
         if ($err) {
             echo "Failed To Check Payment #:" . $err;
         } else {
             $returned_respo = json_decode($response, TRUE);
             print_r($returned_respo);
             if ($returned_respo['status'] == 1) {
                $data = array(
                    'payment_status' => 1
                );
              $this->studentModel->update_table_details('payment_request',$where = array('id' => $receipt[0]->id),$data); 
                $resp_data = array(
                     'reference_no' => $returned_respo['transactions'][0]['reference'],
                     'amount_payed' => (int)$returned_respo['transactions'][0]['amount'],
                     'transaction_receipt' => $returned_respo['transactions'][0]['receipt'],
                     'transaction_date' => $returned_respo['transactions'][0]['timestamp'],
                     'customer_name' => $returned_respo['transactions'][0]['customer_name'],
                     'account_no' => $returned_respo['transactions'][0]['account_number'],
                     'transaction_channel' => $returned_respo['transactions'][0]['channel'] ?? 0
              );
               $this->studentModel->SaveData('payment_response',$resp_data);
               $this->save_transaction_items($receipt[0]->student_id);
              
            }
         }

    } 
   }
   }
    function receiverPayment_auto(){
         $returned_respo = json_decode(trim(file_get_contents('php://input')), TRUE);
         file_put_contents('Apifeedback/' . $returned_respo['reference'] . '.txt', file_get_contents('php://input'));
         if ($this->authentication($returned_respo['api_key'],$returned_respo['api_secret']) == TRUE) {
            $check_ref=$this->studentModel->gettable_data('payment_request',$where = array('reference_no' => $returned_respo['reference'],'payment_status' => 0));
            if (count($check_ref) > 0) {
              $data = array(
                    'payment_status' => 1
                );
                $this->studentModel->update_table_details('payment_request',$where = array('id' => $check_ref[0]->id),$data);
                $resp_data = array(
                    'reference_no' => $returned_respo['reference'],
                    'amount_payed' => (int)$returned_respo['amount'],
                    'transaction_receipt' => $returned_respo['receipt'],
                    'transaction_date' => $returned_respo['timestamp'],
                    'customer_name' => $returned_respo['customer_name'],
                    'account_no' => $returned_respo['account_number'],
                    'transaction_channel' => $returned_respo['channel']??""

              );
               $this->studentModel->SaveData('payment_response',$resp_data);
               $this->save_transaction_items($check_ref[0]->student_id);
               $receipt=$this->studentModel->gettable_data('students_application_tbl',$where = array('id' => $check_ref[0]->student_id));
               $msg = "Malipo yamekamilika. Risiti:".$returned_respo['receipt'].", Ombi namba:".$check_ref[0]->student_id.", Tarehe:".date('d/m/Y H:i').
                       ", Kiasi:TZS ".number_format($returned_respo['amount']).", Muombaji:".$receipt[0]->first_name." ". $receipt[0]->last_name.", Mhamala:".$returned_respo['reference'];
               $this->SMSsender($receipt[0]->phone_number,$msg,2,$returned_respo['reference']);
                echo json_encode(array('status' =>1,'description' =>'Success'));
                
          }else{
              echo json_encode(array('status' => 0, 'description' => 'Reference number does not exist'));
                return;
          }
       }
    }  
     function authentication($key,$secrety) {
        $auth = FALSE;
        $loginModel = new LoginModel();
        $authorize =  $loginModel->verfy_user($key,$secrety); 
        if (count($authorize) > 0) {
                $auth = TRUE;
            } else {
                header('HTTP/1.0 401 Unauthorized');
                echo json_encode(array('status' => 0, 'description' => 'Incorrect authentications')); 
                exit;
            }
        return $auth;
    }
    function Api_payment_loader($id,$app_id,$id2){
       $data = array(
           'ref' => $id,
           'phone_no' => $id2,
           'student_id' => $app_id,
           'payment_resp' => $this->studentModel->gettable_data('payment_response',$where = array('reference_no' => $id)),
           // 'msg' => $this->studentModel->gettable_data('messages',$where = array('reference_no' => $id,'message_type' => 2)),
           'checking_status' => $this->studentModel->gettable_data('temp_item_transation_tbl', $where = array('student_id' => $app_id))
       );
       return view('student/Api_payment_response',$data);
      
    } 
   function SMSsender($dest,$msg,$type,$ref_no,$snn,$show_response=0) {
       $tmsg = $this->studentModel->gettable_data('message_status_tbl',$where = array('status' => 1,));
                  if(count($tmsg)==0){
                   return;   
                  }
            $messag = $this->sytm_model->load_messages_balances();

             $time_sent = time();
              $senderid=constant('SENDER_ID_' . session()->get('db_id'));
                 if($senderid){
              $username=SMS_UNAME;
             $password=SMS_PASSWORD;
                 }else{
                     return;
                 }
                 
        
             $destination=str_replace('-', '', $dest);
             $message=urlencode($msg);
             $senderid = urlencode($senderid);
          $resp=file_get_contents("https://www.sms.co.tz/api.php?do=sms&username={$username}&password={$password}&senderid={$senderid}&dest={$destination}&msg={$message}");

            
            list($status, $note, $smsid) = explode(',', $resp);
            if($show_response == 2){
              echo '<th>Message status:</th>';
              echo '<td><i>' . $note . '</i></td>';
            }
            if ($status == 'OK') {
                $msgid = $smsid;
                $snt_status = 1;    // Message sent successfully
                $cost = 45;
                $acc_cost = $cost;
            } else {
                $msgid = '';
                $snt_status = 2;    // Message just sent 
                $cost = 45;
                $acc_cost = $cost;
            }

            
                $tempsmsdata = array(
                    'message_type' => $type,
                    'phone_no' => str_replace(' ', '', $dest),
                    'message' => $msg,
                    'cost' => $cost,
                    'created_at' => $time_sent,
                    'message_id' => $msgid,
                    'status' => $status,
                    'status_description' => $note,
                    'sent_status' => $snt_status,
                    'reference_no' => $ref_no,
                    'send_no'=>$snn
                   
                );
            
            $this->studentModel->SaveData('messages',$tempsmsdata);
          //  echo 'msg saved';

        $balance = ($messag[0]->balance - $acc_cost);

        $smsDt = array(
            'balance' => $balance,
            'created_at' => date('Y/m/d H:i:s')
        );
        $this->sytm_model->update_sms_balance($smsDt, $messag[0]->b_id);
            //curl_close($curl);
        
    }
    function check_sms(){
         $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_URL => 'http://www.sms.co.tz/api.php?do=dlr&id=' . $this->request->getPost('id') . '',
        ));
        $msg_status = curl_exec($curl);
        if($msg_status != ""){ 
           list($sntdate, $stts, $deldate) = explode(',', $msg_status);
           $tempsmsdata = array(
               'sent_status' => 2, //Sent and delivered
               'time_sent' => $sntdate,
               'status_description' => $stts,
               'time_delivered' => $deldate
           );
            $this->studentModel->update_table_details('messages',$where = array('message_id' => $this->request->getPost('id')),$tempsmsdata);
          // echo '<tr>';
           echo '<th>Message status:</th>';
           echo '<td>'
           . '<i>Sent date:' . $sntdate . '<br>Status: ' . $stts . '<br>Date: ' . $deldate . '</i></td>';
          // echo '</tr>';
           }
             
       }
        function resend_sms() {
           return $this->SMSsender($this->request->getPost('phone_no'), $this->request->getPost('msg'),$this->request->getPost('type'),$this->request->getPost('ref_no'),2);
        }
        function search_application(){
              $dbname=session()->get('db_name');
            $db = \Config\Database::connect($dbname);
            $id = $this->request->getPost('appId');
            // $builder = $db->table('students_application_tbl');
            // $builder->select('*');
            // $builder->where('application_status', 0);
            // $builder->where('id',$id);
            // $builder->orwhere('full_name',$id);
            // $result = $builder->get()->getResult();

            $result = $this->studentModel->gettable_data('students_application_tbl',$where = array('id' => $this->request->getPost('appId') ));
            // print_r($result);
            return json_encode($result);
        }

        public function view_student()
        {
            $id = $this->request->getVar('ids');
            
            $data['student'] = $this->studentModel->getSingle_student($id);
            $data['id'] = $id;
                $data['student_key'] = $id;
            echo view('student/forms/view_student',$data);
        

            
        }

function parent_info()
    {
        $info = $this->studentModel->parent_info($this->request->uri->getSegment(2));
        if (count($info) > 0) {
            $sn = 0;
            echo "<h5 style=''>Parent/Guardian Details</h5>";
            echo '<table class="table table-bordered">

                            <tr>
                                <th>S/N</th>
                                <th>Relation</th>
                                <th>Name</th>
                                <th>Phone No</th>
                                <th>Email</th>
                                <th>Accupation</th>
                                <th>Address</th>
                            </tr>';
            foreach ($info as $fo) {
                $rela=$fo->relation;
                if($rela==1){
                    $re="Mother";
                }elseif($rela==2){
                    $re="Father";
                }elseif($rela==3){
                    $re="Guardian";
                }else{
                    $re=" ";
                }
                $sn++;
                echo '<tr>';
                echo '<td>' . $sn . '</td>';
                echo '<td>' . $re . '</td>';
                echo '<td>' . $fo->first_name." ".$fo->last_name . '</td>';
                echo '<td>' . $fo->phone1 . '</td>';
                echo '<td>' . $fo->email . '</td>';
                echo '<td>' . $fo->occupation . '</td>';
                echo '<td>' . $fo->address . '</td>';
                
                echo '</tr>';
            }
            echo '</table';

        } else {
            echo 'No Parent Information.';
        }
    
    }
    function class_info()
    {
        $info = $this->studentModel->class_info($this->request->uri->getSegment(2));
        if (count($info) > 0) {
            $sn = 0;
            echo "<h5>Classes attended</h5>";
            echo '<table class="table table-bordered" style="">

                            <tr>
                                <th>S/N</th>
                                <th>Admission No</th>
                                <th>Admission Date</th>
                                <th>Class Name</th>
                                <th>Stream</th>
                                <th>Level</th>
                               
                            </tr>';
            foreach ($info as $fo) {
                $sn++;
                echo '<tr>';
                echo '<td>' . $sn . '</td>';
                echo '<td>' . $fo->id . '</td>';
                echo '<td>' . $fo->date_joined . '</td>';
                echo '<td>' . $fo->class_name . '</td>';
                echo '<td>' . $fo->stream_name . '</td>';
                echo '<td>' . $fo->level_name . '</td>';
                echo '</tr>';
            }
            echo '</table';
        } else {
            echo "No classes attended.";
        }
    }
    
    function prev_school()
    {
        $info = $this->studentModel->prev_school($this->request->uri->getSegment(2));
        if (count($info) > 0) {
            $sn = 0;
            echo "<h5>Previous Schools</h5>";
            echo '<table class="table table-bordered">

                            <tr>
                                <th>S/N</th>
                                <th>School Name</th>
                                <th>Year attended</th>
                             
                            </tr>';
            foreach ($info as $fo) {
                $sn++;
                echo '<tr>';
                echo '<td>' . $sn . '</td>';
                echo '<td>' . $fo->school_name . '</td>';
                echo '<td>' . $fo->year_attended . '</td>';
                echo '</tr>';
            }
            echo '</table';
        } else {
            echo "No Previous Schools.";
        }
    }
     function bill_address()
    {
        $info = $this->studentModel->bill_address($this->request->uri->getSegment(2));
        if (count($info) > 0) {
            $sn = 0;
            echo "<h5>Billing Address</h5>";
            echo '<table class="table table-bordered">

                            <tr>
                                <th>S/N</th>
                                <th>Names</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Physical Address</th>
                             
                            </tr>';
            foreach ($info as $fo) {
                $sn++;
                echo '<tr>';
                echo '<td>' . $sn . '</td>';
                echo '<td>' . $fo->first_name." ".$fo->last_name . '</td>';
                echo '<td>' . $fo->phone1 . '</td>';
                echo '<td>' . $fo->email . '</td>';
                echo '<td>' . $fo->address . '</td>';
                echo '</tr>';
            }
            echo '</table';
        } else {
            echo "No Billing Address.";
        }
    }


    function load_payerInfo()
    {
        $id = $this->request->getPost('student');
        $relation = $this->request->getPost('relation');
        $p_data = $this->studentModel->gettable_data('parents_students_tbl', $where = array('student_id' => $id));

        // return json_encode($p_data);
        if(count($p_data) > 0){
            $select_parent = array();
            foreach($p_data as $p){
                $parent = $this->studentModel->gettable_data('parents_tbl', $where = array('id' => $p->parent_id,'relation' => $relation));
                   if(count($parent)>0){
                $select_parent []=array("id" => $parent[0]->id,"fname" => $parent[0]->first_name,"lname" => $parent[0]->last_name,"email" => $parent[0]->email,"address" => $parent[0]->address,"phone" => $parent[0]->phone1,"paddress" => $parent[0]->postal_address, "relation" => $parent[0]->relation);
            }
            }

            echo json_encode($select_parent);
        }
    }

private function compareByTransDate($a, $b) {
    return strtotime($a->trans_date) - strtotime($b->trans_date);
}
 function stu_transaction()
    {
        helper('student');
        $student_id=$this->request->getVar('ids');
         $mydate=$this->request->getVar('thedate');
          list($startingdate, $endingdate) = explode('-', $mydate);
             $enddate = strtotime($endingdate);
            $sdate = strtotime($startingdate);
             $res=get_calc($student_id,$sdate,$enddate);
           //  print_r($res); 
         
       $info = $this->studentModel->stu_transaction($student_id,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
        //$student_id=$this->request->uri->getSegment(2);
       
            echo "<h5>Financial Transactions</h5>";
            echo '<table class="table table-bordered">

                            <tr>
                               
                                 <th>Trans Date</th>
                                 <th>Trans No</th>
                                <th>Trans Type</th>
                                <th>Description</th>
                                <th>Debt</th>
                                <th>Credit</th>
                                <th>balance</th>
                             
                            </tr>';
                          $ttl1=0; 
                           $ttl2=0;
                           
                          $balance=$res['balance'];
                           $disc="";
                    //  print_r($info); 
    ////////////////////////////////////////////////////
             // Custom comparison function
echo '<tr>';
                             
 echo '<td>&nbsp;</td>';
 echo '<td>&nbsp;</td>';
 echo '<td>&nbsp;</td>';
 
 echo '<td style=""><b>b/f</b></td>';
  echo '<td class="text-right"></td>';
  echo '<td class="text-right"></td>';
  echo '<td class="text-right"><b>'.number_format($balance).'</b></td>';
echo '</tr>';
if (count($info) > 0) {
            $sn = 0;

// Sort the array using the custom comparison function
usort($info, [$this, 'compareByTransDate']);
        ////////////////////////////////////////////////////     
            foreach ($info as $fo) {
                    $abalance=0;
                  $credit=0;
                $debit=0;
                $sn++;
                $i=1;
                $trno=$fo->trans_no;
               
                $account="";
                if($fo->trans_type==1){
                    $abalance=0;
                $in = $this->studentModel->get_transaction($fo->trans_no,2,$student_id,1);
                //print_r($in);
                 $inv_name=$this->studentModel->get_invoicetype($in[0]->invoice_type_id);
               $disc=$inv_name[0]->type_name;
                $ttl2=$ttl2+$in[0]->amount;
                    $debit=$in[0]->amount;
                    //echo $debit;
                    $balance=$balance+$in[0]->amount;
                    $thedate=$in[0]->trans_date;
                    //echo $thedate;
                     $trno=$fo->trans_no;
                 }elseif($fo->trans_type==2){
                //   echo $fo->trans_no.'/';
                    $in = $this->studentModel->get_transaction2($fo->trans_no,2,$student_id,2); 
                    //print_r($in);
                        if(count($in)>0){
                            $abalance=0;
                            //$inv_name=$this->studentModel->get_invoicetype($in[0]->invoice_type_id);
                            $i=0;
                            $over=0;
                                 foreach($in as $v){
                                    $charges=0;
                                   // echo $v->amount.'</br>';
                                $charged = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $v->trans_no,'transation_nature' => 1,'trans_type' => 2,'ledger_id'=>22));
                                       //reduce charges
                                    if(count($charged)>0){
                                        $charges=$charged[0]->amount;
                                    }

                                    if($v->ledger_type==7){
                                        continue;
                                        $over+=$v->amount;
                                     $ttl1=$ttl1;
                                     $credit=$credit;
                                     $balance=$balance;
                                    }else{
                                       $ttl1=$ttl1+$v->amount-$charges;
                                     $credit+=$v->amount-$charges;
                                      $balance=$balance-$v->amount+$charges;  
                                    }
                                    
                     $inv_name=$this->studentModel->get_invoicetype($v->invoice_type_id);
                  
                      // echo $i;
                     //echo "<br>";
                     if($i==0){
                           $disc1=$inv_name[0]->type_name;
                     $disc=$disc1;
                        
                     }else{
                        $disc2=$inv_name[0]->type_name;
                      $disc=$disc1.' and '.$disc2;
                  // echo $disc;  
                     }
                  
                     $i++;
                }
                           
                        
                    //echo $credit;
                    $thedate=$in[0]->trans_date;
                    //echo $thedate;
                   $account='';
                    $trno=$fo->trans_no;
                    $acc_name=$this->studentModel->get_account_name($trno,2);
                    //print_r($acc_name);
                    if(count($acc_name)>0){
                    $account=$acc_name[0]->account_name;
                       }
                    //echo $balance;
                 }else{
                    $ina = $this->studentModel->get_applicationid($student_id); 
                     if(count($ina)>0){ 
                   $in = $this->studentModel->get_transactionapp($ina[0]->id,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
                  // print_r($in);
                   if(count($in)>0){ 
                    $disc="Application";
                        $ttl1=$ttl1+$in[0]->amount;
                    $credit=$in[0]->amount;
                   // echo $credit;
                    $abalance=$abalance+$in[0]->amount;
                    $thedate=$in[0]->trans_date;
                    $trno=$in[0]->trans_no;
                      $acc_name=$this->studentModel->get_account_name($trno,2);
                      //print_r($acc_name);
                       $account=$acc_name[0]->account_name;
                   // echo $abalance;
                }else{
                    continue;
                }
                     }else{
                          continue;
                     }
                 }
                 }
                 elseif($fo->trans_type==3){
                       $abalance=0;
                $in = $this->studentModel->get_transaction($fo->trans_no,1,$student_id,3);
                //print_r($in[0]->invoice_type_id);
                 $inv_name=$this->studentModel->get_invoicetype($in[0]->invoice_type_id);
               $disc=$inv_name[0]->type_name;
                  $ttl1=$ttl1+$in[0]->amount;
                    $credit=$in[0]->amount;
                    //echo $debit;
                    $abalance=$abalance+$in[0]->amount;
                    $thedate=$in[0]->trans_date;
                    //echo $thedate;
                     $trno=$fo->trans_no;
                      $acc_name=$this->studentModel->get_account_name($trno,3);
                      //print_r($acc_name);
                       $account=$acc_name[0]->account_name??"";
                 }
                 elseif($fo->trans_type==6){
                       //$abalance=0;
                $in = $this->studentModel->get_transaction($fo->trans_no,1,$student_id,6);
                //print_r($in[0]->invoice_type_id);
                 $inv_name=$this->studentModel->get_invoicetype($in[0]->invoice_type_id);
               $disc=$inv_name[0]->type_name;
                  $ttl1=$ttl1+$in[0]->amount;
                    $credit=$in[0]->amount;
                    //echo $debit;
                    //$abalance=$abalance+$in[0]->amount;
                    $balance=$balance-$in[0]->amount;
                    $thedate=$in[0]->trans_date;
                    //echo $thedate;
                     $trno=$fo->trans_no;
                      $acc_name=$this->studentModel->get_account_name($trno,6);
                      //print_r($acc_name);
                       $account=$acc_name[0]->account_name;
                 }elseif($fo->trans_type==7){
                    $reversed = $this->studentModel->gettable_data('receipt_transfer_tbl',$where = array('reversal_number' => $fo->trans_no));
                     $debit= $reversed[0]->amount_transfered;
                     $thedate=$reversed[0]->date_created;
                     $account="";
                     $disc=$reversed[0]->reasons;
                      $balance=$balance+$debit;
                      $trno=$fo->trans_no;
                    $ttl2=$ttl2+$debit;
                 } elseif($fo->trans_type==5){
                    $descp = $this->studentModel->gettable_data('voucher_relation_tbl',$where = array('payment_no' => $fo->trans_no));
                     $debit= $fo->amount;
                     $thedate=$fo->trans_date;
                     $account="";
                     $disc=$descp[0]->reason;
                      $balance=$balance+$debit;
                      $trno=$fo->trans_no;
                    $ttl2=$ttl2+$debit;
                 }
              
                echo '<tr>';
               echo '<td>' . $thedate . '</td>';
                echo '<td>' . $trno . '</td>';
                
                echo '<td>' . $fo->type_name . '</td>';
                if($account==""){
                echo '<td>' . $disc . '</td>';
                }else{
                  echo '<td>' . $disc .' ->'.$account .'</td>';   
                }
               if($debit==0){
                  echo '<td class="text-right"></td>'; 
               }else{
                echo '<td class="text-right">' . number_format($debit) . '</td>';
               }
               if($credit==0){
                echo '<td class="text-right"></td>';   
               }else{
                echo '<td class="text-right">' . number_format($credit) . '</td>';
               }
                if($abalance!=0){
                echo '<td class="text-right">' . number_format($abalance) . '</td>';
            }else{
                if($balance==0){
                     echo '<td class="text-right"></td>';
                }else{
              echo '<td class="text-right">' . number_format($balance) . '</td>';
            }
            }
                echo '</tr>';
            
            }
           echo '<tr>';
                             
                             echo '<td>&nbsp;</td>';
                             echo '<td>&nbsp;</td>';
                             echo '<td>&nbsp;</td>';
                             
                             echo '<td style=""><b>Total</b></td>';
                              echo '<td class="text-right"><b>'.number_format($ttl2).'</b></td>';
                              echo '<td class="text-right"><b>'.number_format($ttl1).'</b></td>';
                         echo '</tr>';
            echo '</table';
        } 
        // else {
        //     echo "No Financial Transactions.";
        // }
    }

    function generate_student_id() {
        $ino = "";
        $sid = $this->studentModel->get_max_id('students','student_id');
        if (count($sid) > 0) {
            $stid = $sid[0]->max_id + 1;
            $ino = $stid;
        } else {
            $ino =  1;
        }
        return $ino;
    }

    function search_parentData(){
        $data['search'] = $this->request->getVar('parentData');
        $data['studentID'] = $this->request->getVar('student');
        return view('parent/parents_information',$data);
    // $db = \Config\Database::connect();
    //     $search = $this->request->getVar('parentData');

    //     $names= $db->query('SELECT * FROM parents_tbl 
    //                       WHERE `first_name`LIKE \'%'.$search.'%\' OR`last_name`LIKE \'%'.$search.'%\' OR`full_name`LIKE \'%'.$search.'%\'');
    //     $result = $names->getResult();
    //     // echo json_encode($result);
    //     $prntAarray = array();

    //     if(count($result) > 0){
    //         // foreach ($result as $r) 
    //         // {
    //             if($result[0]->bill_account == 0){
    //                 $data = array("id" => $result[0]->id, "firstname" => $result[0]->first_name, "last_name" => $result[0]->last_name, "full_name" => $result[0]->full_name, "phone" => $result[0]->phone1, "email" => $result[0]->email, "occupation" => $result[0]->occupation, "address" => $result[0]->address, "relation" => $result[0]->relation);
    //             }
    //             array_push($prntAarray, $data);
    //         // }

    //         echo json_encode($prntAarray);
    //     }else{
    //         $data = array('No Parent Data Found');
    //           array_push($prntAarray, $data);
        
    //         echo json_encode($prntAarray);
    //     }
    }

    function new_ParentInfo(){
        $data['id'] = $this->request->getVar('student');
        return view('parent/new_ParentForm',$data);
    }

    function save_studentParent_details(){
        $data = [
            'parent_id' => $this->request->getVar('pID'),
            'student_id' => $this->request->getVar('student_id')
        ];
        $this->studentModel->SaveData('parents_students_tbl',$data);
        echo json_encode(array('status' =>'0','statusDesc' => 'Parent Registration Successful'));
    }

   public function applications_summary($year){
         //recollected
        $data=[
          'year'=>$year
        ];
         return view('templates/header')
            .view('student/applications_summary',$data)
            .view('templates/footer');
    }
    public function get_classlevel_details($year){
         //recollected
        $tday = date('d-m-Y');
        $level = $this->studentModel->get_level_details();
        $data = array();
        foreach ($level as $l){
            
                $data[]= ['name' => $l->level_name,'total'=>count($this->studentModel->total_level_students($l->id,'students_application_tbl','class_lvl',$year))];
            
        }
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/application_graphs',$send);
      //$this->load->view('graphs/patients_waiting_department',$send);
    }
     public function get_classes_details($year){
         //recollected
        $tday = date('d-m-Y');
        $class = $this->studentModel->get_class_details();
        $data = array();
        foreach ($class as $l){
            
                $data[]= ['name' => $l->class_name,'total'=>count($this->studentModel->total_level_students($l->id,'students_application_tbl','class',$year))];
            
        }
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/classes_graphs',$send);
      //$this->load->view('graphs/patients_waiting_department',$send);
    }
    public function get_gender_details($year){
         //recollected
        $tday = date('d-m-Y');
        //$class = $this->studentModel->get_class_details();
        $data = array();
        for ($i=1;$i<=2; $i++){
            if($i==1){
                $name='Male';
            }else if($i==2){
                $name='Female'; 
            }
            
                $data[]= ['name' =>$name,'total'=>count($this->studentModel->total_level_students($name,'students_application_tbl','gender',$year))];
            
        }
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/gender_graph',$send);
      //$this->load->view('graphs/patients_waiting_department',$send);
    }
     public function get_appsel_details($year){
         //recollected
        $tday = date('d-m-Y');
        //$class = $this->studentModel->get_class_details();
        $data = array();
        for ($i=0;$i<2; $i++){
            if($i==0){
                $name='Application';
            }else if($i==1){
                $name='Selection'; 
            }
            
                $data[]= ['name' =>$name,'total'=>count($this->studentModel->total_selected_students($i,$tday,'selection_status',$year))];
            
        }
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/selection_graph',$send);
      
    }
    public function selection_report(){
        $status = $this->request->getPost('status');
            $classid = $this->request->getPost('class');
            $data['classid']=$classid;
            $data['status']=$status;
            $data['dta'] = $this->studentModel->selection_report($classid,$status);
           echo view('student/forms/selection_report',$data);
          
    }
    public function student_selection(){
           $student=$this->request->getPost('student_id');
                
                foreach ($student as $i) {
                    
                    $type=$this->request->getPost('select['.$i.']');

                    if(empty($type)){
                       continue;
                            
                      }else if($type==1){
                     $this->studentModel->selection_student($i,$type);
                    }else if($type==2){
                        $type=0;
                        $this->studentModel->selection_student($i,$type);
                    }
                    
                
               
                }
    }

       public function get_AdimissionGender_details($year){
         //recollected
        $tday = date('d-m-Y');
        //$class = $this->studentModel->get_class_details();
        $data = array();
        for ($i=1;$i<=2; $i++){
            if($i==1){
                $name='Male';
            }else if($i==2){
                $name='Female'; 
            }
            
                $data[]= ['name' =>$name,'total'=>count($this->studentModel->total_gender_admission($name,$tday,'gender',$year))];
            
        }
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/gender_admission_graph',$send);
      //$this->load->view('graphs/patients_waiting_department',$send);
    } 
    public function get_contVsNew_details($year){
         //recollected
      $tday = date('d-m-Y');
        //$class = $this->studentModel->get_class_details();
        $data = array();
        for ($i=1;$i<=2; $i++){
            if($i==1){
                $type=0;
                $name='CONTINOUS';
            }else if($i==2){
                $type=2;
                $name='NEW'; 
            }
            
                $data[]= ['name' =>$name,'total'=>count($this->studentModel->total_contNew_admission($type,'adimit_for',$year))];
            
        }
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/contnew_admission_graph',$send);  
    }
    
      public function get_admitiontype_details($year){
         //recollected
      $tday = date('d-m-Y');
    
        $data = array();
        for ($i=1;$i<=2; $i++){
            if($i==1){
                $type=0;
                $name='DAY';
            }else if($i==2){
                $type=3;
                $name='BOARDING'; 
            }
            
                $data[]= ['name' =>$name,'total'=>count($this->studentModel->total_contNew_admission($type,'admission_type',$year))];
            
        }
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/type_admission_graph',$send);  
    }
    
     public function get_selColl_details($year){
        //recollected
      $tday = date('d-m-Y');
    
        $data = array();
         $sales = $this->studentModel->get_total_admision_collection('ledger_transaction_tbl','amount',$year);
    $tcol=0;
    $tsales=0;
    foreach ($sales as $sale) {
        $tsales=$tsales+$sale->amount;
        $rcn = $this->studentModel->gettable_data('transactions_relation',$where = array('invoice_trans_no' => $sale->trans_number));

       if(count($rcn)>0){
        foreach ($rcn as $s) {
      $rc_amount = $this->studentModel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $s->receipt_trans_no,'trans_type'=>2,'transation_nature'=>1,'ledger_id!='=>9,'ledger_id!='=>22,));
      if(count($rc_amount)>0){
       $tcol=$tcol+$rc_amount[0]->amount;
          }
        }
    }
        // collected end...
    }
    $data[]= ['name' =>'SELL','total'=>$tsales];
    $data[]= ['name' =>'COLLECTED','total'=>$tcol];
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/selAndColl_admission_graph',$send);  
    }
    
    public function admitionbylevel_details($year){
        $tday = date('d-m-Y');
        $level = $this->studentModel->get_level_details();
        $data = array();
        foreach ($level as $l){
            
                $data[]= ['name' => $l->level_name,'total'=>count($this->studentModel->total_level_admission($l->id,'admission_tbl','level_id',$year))];
            
        }
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/admissionLevel_graphs',$send);
      //$this->load->view('graphs/patients_waiting_department',$send);
    }
    public function admitionbyclass_details($year){
    //recollected
        $tday = date('d-m-Y');
        $class = $this->studentModel->get_class_details();
        $data = array();
        foreach ($class as $l){
            
                $data[]= ['name' => $l->class_name,'total'=>count($this->studentModel->total_level_admission($l->id,'admission_tbl','class_id',$year))];
            
        }
        $level_classes = $this->studentModel->get_classes_bylevel();
       $send['class_data']=$level_classes;
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/admissionClasses_graphs',$send);
      //$this->load->view('graphs/patients_waiting_department',$send);
    }
     public function student_dashboard(){
        
         return view('templates/header')
            .view('student/student_dash_view')
            .view('templates/footer');
    }
      public function parents_dashboard($year){
         $data=[
          'year'=>$year
        ];
         return view('templates/header')
            .view('student/parents_dash_view',$data)
            .view('templates/footer');
    }
      public function get_AdimissionGender_details2($year){
        $tday = date('d-m-Y');
        //$class = $this->studentModel->get_class_details();
        $data = array();
      
 $absconds = $this->studentModel->gettable_data('absconding_tbl',$where = array('absconded_year' => $year));
    $male=0;
    $female=0;
    if(count($absconds)>0){
        foreach ($absconds as $v) {
            $adms = $this->studentModel->gettable_data('admission_tbl',$where = array('id' => $v->adm_id));
             
    if(count($adms)>0){
             $gender = $this->studentModel->gettable_data('students',$where = array('id' => $adms[0]->student_id)); 

             if($gender[0]->gender=='Male') {
               $male=$male+1;
             }else{
              $female=$female+1;
             }
         }else{
            //echo $v->adm_id.'/';
         }

        }
      
    }

    $data[]= ['name' =>'Male','total'=>$male];
    $data[]= ['name' =>'Female','total'=>$female];
      $send['data'] = json_encode($data);

       echo view('graphs/gender_admission_graph',$send);
      //$this->load->view('graphs/patients_waiting_department',$send);
    } 
     public function students_details(){
        $tday = date('d-m-Y');
       // $level = $this->studentModel->get_religon_details();
        $data = array();
         for ($i=1;$i<=4; $i++){
            if($i==1){
                $name='Christianity';
            }else if($i==2){
                $name='Islam'; 
            }else if($i==3){
                $name='Hinduism'; 
            }else if($i==4){
                $name='other'; 
            }
            
                $data[]= ['name' =>$name,'total'=>count($this->studentModel->total_religion_details($name,'religion'))];
            
        }
      $send['data'] = json_encode($data);
       //print_r($send);
       //return;
       echo view('graphs/religion_graphs',$send);
      //$this->load->view('graphs/patients_waiting_department',$send);
    }
    
    public function get_nationality_trends(){
        $tday = date('d-m-Y');
        $ntn = $this->studentModel->get_nationality_details();
        $data = array();
          foreach ($ntn as $l){
            $ttl=count($this->studentModel->total_level_students($l->nation,'students','nationality'));
            if($ttl>0){
                $data[]= ['name' => $l->nation,'total'=>$ttl];
            }
            
        }
       $send['data'] = json_encode($data);
       echo view('graphs/nation_graphs',$send);
      //$this->load->view('graphs/patients_waiting_department',$send);
    }
    public function get_relation_details(){
     //$ntn = $this->studentModel->get_nationality_details();
        $data = array();
         for ($i=1;$i<=3; $i++){
            if($i==1){
                $name='MOTHER';
            }else if($i==2){
                $name='FATHER'; 
            }else if($i==3){
                $name='GUARDIAN'; 
            }
            
                $data[]= ['name' =>$name,'total'=>count($this->studentModel->total_level_students($i,'parents_tbl','relation'))];
            
        }
       $send['data'] = json_encode($data);
       echo view('graphs/relaton_graphs',$send);   
    }

   function students_parents(){
     $res = $this->studentModel->load_customerGroup_sales();

       
            $arr = [];
// print_r($res);
            echo json_encode($res);
//            foreach ($res->result() as $mn) {
//                $a = array_fill_keys($mn->first_name, $mn->qtotal);
//            }
//            print_r($a);
        
   }
   function generate_msg_no() {
        $ino = "";
        $tkens = $this->studentModel->get_max_id('message_groups_tbl','send_number');
        if (count($tkens) > 0) {
            $trans = $tkens[0]->max_id + 1;
            $ino = $trans;
        } else {
            $ino =  1;
        }
        return $ino;
    }
    public function generate_appl_controlnumber(){
  $total_cost=$this->request->getPost('due');
    $student_id=$this->request->getPost('sID');
    $transNo=$this->request->getPost('sID');
    $type=6;
    $des='Application Fee';
   
    
 $this->createControl_number_crdb($total_cost,$student_id,$des,$type);
    }
    function fetch_application(){
    $thedate=$this->request->getPost('thedate');
    list($startingdate, $endingdate) = explode('-', $thedate);
             $enddate = strtotime($endingdate. ' 23:59:59');
            $sdate = strtotime($startingdate);
    $data = array(
            'clevel'  => $this->studentModel->get_active_item('class_level_tbl'),
         'student' => $this->studentModel->get_item_name('students_application_tbl',$where = array('DATE(date_created) >='=>date('Y-m-d H:i', $sdate),'DATE(date_created) <='=> date('Y-m-d H:i', $enddate)))
             
            );
           
           echo view('student/forms/application_list',$data);
        }
        function aliens_others(){
         return view('templates/header')
            .view('student/other_students')
            .view('templates/footer');  
        }
        function save_others(){
         $student_reg = [
               'fname' => [
                   'label' => 'First Name',
                   'rules' => 'required|min_length[2]|max_length[30]',
                 ] ,
               'mname' => [
                   'label' => 'Middle Name',
                   'rules' => 'required',
               ] ,
               'lname' => [
                   'label' => 'Last Name',
                   'rules' => 'required|max_length[50]',
               ] ,
               'dob' => [
                   'label' => 'Date of Birth',
                   'rules' => 'required',
               ] ,
               'gender' => [
                   'label' => 'Gender',
                   'rules' => 'required',
               ] ,
               
               'bphone' => [
                   'label' => 'Bill Phone Number',
                   'rules' => 'required|min_length[10]|max_length[15]',
               ] 
               ];

          if ($this->validate($student_reg)){
               $student_exist = $this->studentModel->check_student('other_students_tbl',$this->request->getPost('fname'),$this->request->getPost('mname'),$this->request->getPost('lname'));

               if($student_exist){
                   echo json_encode(array('status' =>'0','statusDesc' => 'Student With the same Name <b>'.$student_exist[0]->first_name.' '.$student_exist[0]->middle_name.' '.$student_exist[0]->last_name.'</b> Already registerd'));
                  
               }

               else{
                   $data = [
                        'first_name' => ucfirst($this->request->getPost('fname')),
                        'middle_name' => ucfirst($this->request->getPost('mname')),
                        'last_name' => ucfirst($this->request->getPost('lname')),
                        'birth_date' => $this->request->getPost('dob'),
                        'gender' => $this->request->getPost('gender'),
                       'phone' => $this->request->getPost('bphone'),
                        'created_by' => $_SESSION['user_id'],
                        'date_created ' => date('Y-m-d H:i:s'),
                        'full_name' => ucfirst($this->request->getPost('fname')).' '.ucfirst($this->request->getPost('mname')).' '.ucfirst($this->request->getPost('lname'))
                    ];
                 
                   $studentid = $this->studentModel->SaveData_n_get_id('other_students_tbl',$data); 
                    
                   
                    echo json_encode(array('status' =>'0','statusDesc' => 'Student '.$this->request->getPost('fname').' '.$this->request->getPost('mname').' '.$this->request->getPost('lname').' Saved Successful','student' => $studentid));
                
               }
           }else{
               echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));

           }   
        }

        function fetch_otherstudent(){
    $status=$this->request->getPost('status');
    // list($startingdate, $endingdate) = explode('-', $thedate);
    //          $enddate = strtotime($endingdate. ' 23:59:59');
    //         $sdate = strtotime($startingdate);
    if($status>0){
$data = array(
            
         'student' => $this->studentModel->get_item_name('other_students_tbl',$where = array('status'=>$status))
             
            );
    }else{
        $data = array(
            
         'student' => $this->studentModel->get_item_name('other_students_tbl',$where = array('status !='=>$status))
             
            );
    }
    
           
           echo view('student/forms/other_students_list',$data);
        }

        function edit_otherstudents($id){
        $data = array(
            'app' => $this->studentModel->gettable_data('other_students_tbl',$where = array('id' => $id)),
        
        );
        return view('student/forms/edit_otherstudents',$data);
       
    }
     function update_other_students(){
         $student_reg = [
               'fname' => [
                   'label' => 'First Name',
                   'rules' => 'required|min_length[2]|max_length[30]',
                 ] ,
               'mname' => [
                   'label' => 'Middle Name',
                   'rules' => 'required',
               ] ,
               'lname' => [
                   'label' => 'Last Name',
                   'rules' => 'required|max_length[50]',
               ] ,
               'dob' => [
                   'label' => 'Date of Birth',
                   'rules' => 'required',
               ] ,
               'gender' => [
                   'label' => 'Gender',
                   'rules' => 'required',
               ] ,
               'bphone' => [
                   'label' => 'Bill Phone Number',
                   'rules' => 'required',
               ] 
               ];

          if ($this->validate($student_reg)){
              $app_exist = $this->studentModel->gettable_data('other_students_tbl',$where = array('id' => $this->request->getPost('appid')));
               if($app_exist){
                   $data = [
                        'first_name' => ucfirst($this->request->getPost('fname')),
                        'middle_name' => ucfirst($this->request->getPost('mname')),
                        'last_name' => ucfirst($this->request->getPost('lname')),
                        'birth_date' => $this->request->getPost('dob'),
                        'gender' => $this->request->getPost('gender'),
                        'phone' => $this->request->getPost('bphone'),
                        'status' => $this->request->getPost('status'),
                        'created_by' => $_SESSION['user_id'],
                        'date_created ' => date('Y-m-d H:i:s'),
                        'full_name' => ucfirst($this->request->getPost('fname')).' '.ucfirst($this->request->getPost('mname')).' '.ucfirst($this->request->getPost('lname'))
                    ];
                   $this->studentModel->update_table_details('other_students_tbl',$where = array('id' => $this->request->getPost('appid')),$data); 

                   

                   echo json_encode(array('status' =>'0','statusDesc' => 'Student '.$this->request->getPost('fname').' '.$this->request->getPost('mname').' '.$this->request->getPost('lname').' Updated Successful'));
               }
               else{ 
                  echo json_encode(array('status' =>'1','statusDesc' =>  'Sorry Something Went Wrong..!'));
               }
           }else{
               echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));

           }
    }
     function view_aliens($id){
        $data = array(
            'app' => $this->studentModel->gettable_data('other_students_tbl',$where = array('id' => $id)),
        
        );
        return view('student/forms/view_alienstudents',$data);
       
    }
    function fetch_students(){
        $class=$this->request->getPost('initial');
        $status=$this->request->getPost('status');
        $data = array(
                'student' => $this->studentModel->get_student_list($class,$status)
            );
        echo view('student/students_list',$data);
    }

 function delete_application($id,$ref){
      $dlt=$this->studentModel->delete_application_data($id);
      if($dlt){

        $data=array(
                'ref_no' => $ref
                );
         $url = CRDB_URL_1."cancelRefNo";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/json",
                ));
                $response = curl_exec($ch);
                echo $response;
                $err = curl_error($ch); 
                curl_close($ch);

                 if ($err) {
                    echo "Error #:" . $err;
                    $status = 5;
                    $reference=0;
                     $time=date('Y-m-d H:i:s');

                } else {
            $dl=$this->studentModel->delete_reference($ref);
                }

      }
    }
    
     function fetch_student_byname(){
        $name=$this->request->getPost('name');
       $name=trim($name);
       $name_parts = explode(" ", $name);
        $data = array(
                'student' => $this->studentModel->get_student_byname($name_parts,count($name_parts))
            );
        echo view('student/students_list',$data);
    }
    
    function delete_student(){
         $id=$this->request->getPost('id');

         $parents = $this->studentModel->gettable_data('parents_tbl',$where = array('bill_account' => 0,'first_name' => $this->request->getPost('pname'),'last_name' => $this->request->getPost('plname')));

         $parents = $this->studentModel->gettable_data('parents_students_tbl',$where = array('student_id' => $id));
         if(count($parents)>0){
            foreach ($parents as $p) {

         $builder = $this->db->table('parents_tbl');
        $builder->where('id',$p->parent_id);
        $builder->delete();   
            }

         $builder = $this->db->table('parents_students_tbl');
        $builder->where('sp_id',$parents[0]->sp_id);
        $builder->delete();
         }

         $builder = $this->db->table('students');
        $builder->where('students.id',$id);
        $builder->delete();

        echo json_encode(array('status' =>'1','statusDesc' => 'Deleted Successful'));
    }
    
      function edit_stream_data(){
  $id=$this->request->getPost('id');  
 $capacity=$this->request->getPost('capacity'); 
 $stream_name=$this->request->getPost('stream_name'); 

 $levelDta = [
            'stream_name' => 'required',
            'capacity' => 'required',
        ];
           
        if($this->validate($levelDta)){
           $Dta = [
            'stream_name' => $stream_name,
            'stream_capacity' => $capacity,
        ]; 
       $this->studentModel->update_table_details('streams_tbl', $where = array('id' => $id),$Dta);
       echo 1;
        }else{
         echo json_encode(array('status' =>'1','statusDesc' =>  $this->validation->listErrors()));   
        }

    }
    
    function import_students_excel(){
    $file = $this->request->getFile('excelFile');

        if (!$file || !$file->isValid()) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Invalid file uploaded']);
        }

        $filePath = $file->getTempName();
        $spreadsheet = IOFactory::load($filePath);
        $rows = $spreadsheet->getActiveSheet()->toArray();

        $successCount = 0;
        $duplicateCount = 0;
        $errorRows = [];
             //print_r($rows);
        foreach ($rows as $index => $row) {
            if ($index == 0) continue; // skip header

          
                
            $student_exist = $this->studentModel->gettable_data('students',$where = array(
                'first_name' => ucfirst($row[0]),
                'middle_name' => ucfirst($row[1]),
                'last_name' => ucfirst($row[2]),
            )); 
            if(count($student_exist)>0){
                $duplicateCount++;
                continue;
                
            }else{
               // echo $row[12];
                  $classParts = explode('-', $row[9] ?? '');
                  $class_id = $classParts[0] ?? null;

                    $data = [
                         'first_name' => ucfirst($row[0]),
                         'middle_name' => ucfirst($row[1]),
                         'last_name' => ucfirst($row[2]),
                         'birth_date' => date('Y-m-d H:i:s',strtotime($row[3])),
                         'gender' => $row[4],
                         'nationality' => $row[5],
                         'religion' => $row[6],
                         'government_no' =>  $row[7],
                         'student_id' =>  $row[8],
                         'status' =>  1,
                         'student_photo' => '',
                         'created_by' => $_SESSION['user_id'],
                         'date_created' => date('Y-m-d H:i:s'),
                         'full_name' => ucfirst($row[0]).' '.ucfirst($row[1]).' '.ucfirst($row[2]),
                         'initial_class' => $class_id,
                     ];
                  $studentid = $this->studentModel->SaveData_n_get_id('students',$data);
                       //  print_r($data);

                        $relationParts = explode('-', $row[12] ?? '');
                         $relation_id = $relationParts[0] ?? null;
                        $data1 = [
                                'first_name' => ucfirst($row[10]),
                                'last_name' => ucfirst($row[11]),
                                'full_name' => ucfirst($row[10]).' '.ucfirst($row[11]),
                                'relation' => $relation_id,
                                'address' => $row[13],
                                'occupation' => ucfirst($row[14]),
                                'phone1' => '255'.$row[15],
                                'phone2' => 0,
                                'email' => $row[17],
                                  ];

                            $parentID = $this->studentModel->SaveData_n_get_id('parents_tbl',$data1); 

                            //  print_r($data1);
                            //  return;
                            if(!empty($parentID)){
                                $childParent = [
                                    'parent_id' => $parentID,
                                    'student_id' =>$studentid  
                                ];
                                $this->studentModel->SaveData('parents_students_tbl',$childParent);
                            }

                            $data2 = [
                                'first_name' => ucfirst($row[10]),
                                'last_name' => ucfirst($row[11]),
                                'full_name' => ucfirst($row[10]).' '.ucfirst($row[11]),
                                'relation' => $relation_id,
                                'address' => $row[13],
                                'occupation' => ucfirst($row[14]),
                                'phone1' => '255'.$row[16],
                                'phone2' => 0,
                                'email' => $row[17],
                                'bill_account'=>1
                             ];

                            $parentID = $this->studentModel->SaveData_n_get_id('parents_tbl',$data2); 


                            if(!empty($parentID)){
                                $childParent = [
                                    'parent_id' => $parentID,
                                    'student_id' =>$studentid  
                                ];
                                $this->studentModel->SaveData('parents_students_tbl',$childParent);
                            }

                            if($row[18] !=""){
                              $data = [
                        'school_name' => $row[18],
                        'year_attended' => $row[19],
                        'student_id' => $studentid
                    ];
                    $this->studentModel->SaveData('previous_school',$data);   
                            }

             $successCount++;
        }
        }

        return $this->response->setJSON([
            'status' =>'success',
        'statusDesc' =>'students saved Successful',
        'inserted' => $successCount,
        'duplicates' => $duplicateCount,
        ]);
    

    }
//endup
}    
?>