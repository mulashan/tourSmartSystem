<?php 
    namespace App\Libraries;
    
    class SchoolLibrary
    {
        Public function age(){
            return "age";
        }
    }

