<?php
use App\Models\PaymentsModel;
function findCalc($student_id,$db,$year){
     static $payment_model;
     static $dbIdCache = [];
     static $levelCache = [];
     static $currentTermCache = [];
     static $installmentsCache = [];

     if ($payment_model === null) {
        $payment_model = new PaymentsModel;
     }
      $ids=session()->get('db_id');
     if($ids==1){
       $db_id=1;  
     }else if($ids==4){
        $db_id=4;    
     }else if($ids==5){
        $db_id=5;    
     }else if($ids==2){
        $db_id=2;    
     }else{
       if (! array_key_exists($db, $dbIdCache)) {
          $db_tbl = $payment_model->get_item_name('database_list_tbl',$where=array('db_name'=>$db),$db);
          $dbIdCache[$db] = count($db_tbl) > 0 ? $db_tbl[0]->db_id : 1;
       }
       $db_id = $dbIdCache[$db];
     }
     
 $item_data = array();
//$payment_model = new PaymentsModel;

//debit calculation
$debt=0;
 $credit=0;
  $balance= $payment_model->get_item_name('student_balance_tbl',$where=array('year'=>$year-1,'student_id'=>$student_id),$db);
   if(count($balance)>0){
                        $debt=$balance[0]->present_debit;
                        $credit=$balance[0]->balance;
                       }

$cld=$payment_model->get_item_name('admission_tbl',$where=array('student_id'=>$student_id,'academic_year'=>$year),$db);
if(count($cld)==0){
    return 0;
}
$adm_id=$cld[0]->class_id;
$level_id=$cld[0]->level_id;
$hst=$cld[0]->admission_type;

$db = \Config\Database::connect($db);
$db=$db->database;
$levelCacheKey = $db.'|'.$level_id;
if (! array_key_exists($levelCacheKey, $levelCache)) {
    $levelCache[$levelCacheKey] = $payment_model->get_item_name('class_level_tbl', $where = array('id' => $level_id),$db);
}
$lvtbl = $levelCache[$levelCacheKey];
if(count($lvtbl)==0){
    return 0;
}

  $tinvoice = $payment_model->get_total_invoice_amount($student_id,$year,$db); 
   $termTypeId = $lvtbl[0]->academic_type;
   $currentTermKey = $db.'|'.$year.'|'.$termTypeId;
   if (! array_key_exists($currentTermKey, $currentTermCache)) {
        $dateterm = $payment_model->checkTerm_date(date('Y-m-d'),$year,$db,$termTypeId);
        if (! is_countable($dateterm) || count($dateterm) === 0) {
            $dateterm = $payment_model->checkTerm_date2(date('Y-m-d'),$year,$db,$termTypeId);
        }
        $currentTermCache[$currentTermKey] = $dateterm;
   }
   $dateterm = $currentTermCache[$currentTermKey];
   if (! is_countable($dateterm) || count($dateterm) === 0) {
        return 0;
   }

                    $total =0;
                    $amount = 0;
                    $uniform=0;
                    $tea=0;
                    $lunch=0;
                    $new=0;
                      $pocket=0;
                      $gradu=0;
                     if($debt>0){
                        $openingbalance=$debt;
                    }elseif($credit<0){
                       $openingbalance=$credit;
                    }else{
                       $openingbalance=$debt;
                    }
                    
                       $boarding=0;
                       $stationary=0;
                       $exam=0;
                       $remedials=0;
                    $trans_numbers=array();
                   
                     $l=0;
                     if(count($tinvoice)==0){
                        // continue;
                        return 0;
                     }
                    foreach($tinvoice as $it){
                        $trans_numbers[] = $it->trans_no;
                    $result = $payment_model->get_invoice_items_for_calc($it->trans_no, $db);
                    //trans_number='.$it->trans_no
                      foreach($result as $itm){
                         $amount = $itm->quantity * $itm->unit_price;

                      if($itm->item_group==7){
                        $total -= $amount;
                          }else if($itm->invoice_type_id==8){
                        $openingbalance+=$amount;
                          }
                          else{
                            $total += $amount;
                          }
                         if($itm->item_id==22 || $itm->item_id==23 || $itm->item_id==24 || $itm->item_id==55|| $itm->item_id==66 || $itm->item_id==21 || $itm->item_id==1 || $itm->item_id==25 || $itm->item_id==20 && $db_id!=6){
                            $uniform+=$amount; 
                        }
                        
                         if($itm->item_group ==11  && $db_id==6){
                       $uniform+=$amount;
                        }
                         if($itm->item_group ==14){
                       $remedials+=$amount;
                        }
                        
                         if($itm->item_id==38 || $itm->item_id==39 || $itm->item_id==40){
                            $tea=$tea+$amount; 
                            if($itm->item_id==39 || $itm->item_id==40){
                                $lunch+=$amount;
                            }
                        }
                      
                         if($itm->item_group ==2 || $itm->item_group ==1){
                        $new=$new+$amount;
                        }
                        
                         if($itm->item_id ==65){
                       $pocket=$amount;
                        }
                          if($itm->item_group ==4){
                       $gradu+=$amount;
                        }

                        if($itm->item_group ==3){
                       $boarding=$boarding+$amount;
                        }

                    if($itm->item_group ==8){
                       $stationary=$stationary+$amount;
                        }

                        if($itm->item_group ==9){
                       $exam=$exam+$amount;
                        }

                    }
                    }
                  
               $singleArray = $trans_numbers;
                   $installmentsKey = $db.'|'.$year.'|'.$termTypeId;
                   if (! array_key_exists($installmentsKey, $installmentsCache)) {
                       $installmentsCache[$installmentsKey] = $payment_model->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$termTypeId),$db);
                   }
                   $installments = $installmentsCache[$installmentsKey];
                   if(count($installments)==0){
                       return 0;
                   }

        //checking for new comers 
                  $joined_date = $cld;
                   $k=0;
                   $m=0;
                   foreach ($installments as $ts) {
                    $k++;
                    
                   if((strtotime($joined_date[0]->date_joined) >= strtotime($ts->start_date)) && (strtotime($joined_date[0]->date_joined) <= strtotime($ts->end_date))){

                     $m=$k;
                     }else if(strtotime($joined_date[0]->date_joined) < strtotime($ts->start_date) && $m==0){
                       $m=$k;
                     }
                   }
     //end checking for new comers

                    $installmenttotal = array();
                    $installmentname = array();
                    $installmentid = array();
                    $installmentDate = array();
                    $ttlAmount = 0;
                     $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                      $ddate="";
                     
                     
                    foreach ($installments as $r) {
                        $paid_amount=0;
                    
                     $i++;
                     $ment=0;
                     if($total==0){
                       $fee=0;
                       $uniform=0;
                       $tea=0;
                       $lunch=0;
                     }else{
                        $fee=$total-$uniform-$tea; 
                     }
                     $tdy=0;
                      $todaybalance=0;
                     if($i==1){

                         $ddate = strtotime($r->end_date);
                         $date2= strtotime($r->start_date);
                        $data1= $ddate;
                       
                  $paid= $payment_model->get_pai_receipt($singleArray,date('Y-m-d H:i',$date2),date('Y-m-d H:i',$ddate),1,$year,$db,count($installments));
                       
                     
                     //credit transactions
                     $credit= $payment_model->get_paid_credit($student_id,date('Y-m-d H:i',$date2),date('Y-m-d H:i',$ddate),1,$year,$db);
                     $credit_amount=0;
                     if(count($credit)>0){
                    foreach($credit as $cr){
                     $credit_amount=$credit_amount+$cr->amount;  

                   $check_refund= $payment_model->get_item_name('voucher_relation_tbl',$where=array('trans_no'=>$cr->trans_number,'voucher_type'=>5,'trans_type'=>6),$db);  
                   if(count($check_refund)>0){
                    $credit_refund=0;
                    
                     foreach($check_refund as $check){
                 $approval = $payment_model->get_item_name('approval_numbers', $where = array('trans_no' => $check->payment_no,'trans_type'=>5),$db);
                    if(count($approval)>0){
                 $check_approval= $payment_model->get_item_name('approval_history', $where = array('app_no' => $approval[0]->app_id,'hstatus'=>1),$db);
                 if(count($check_approval)==0){
                    continue;
                 }

                     $look_credit= $payment_model->get_item_name('ledger_transaction_tbl',$where=array('trans_no'=>$check->payment_no,'trans_type'=>5,'transation_nature'=>1),$db); 
                    if(count($look_credit)>0){
                    $credit_amount=$credit_amount-$look_credit[0]->amount;
                        }
                    }
                }
                   }
                        }
                     }

                     $check_balance = $balance;
                     $used=0;
                     if(count($check_balance)>0){
                          
                        if($check_balance[0]->balance <0){
                        
                          $checkAllReceipt =$payment_model->get_item_name('transactions_relation',$where=array('invoice_trans_no'=>$check_balance[0]->debted_inv_no,),$db);
                          foreach($checkAllReceipt as $ct){
                           $checkIfused =$payment_model->get_item_name('transaction_use_relation_tbl',$where=array('used_no'=>$ct->receipt_trans_no,'trans_type'=>5),$db);
                          
                           if(count($checkIfused)>0) {
                            $used=1;
                           }
                          }
                      }
                      if($used==0){
                       // $paid_amount=$check_balance[0]->balance*-1;
                         }
                     }
                    $tgmount=0;
                         $dep_amount=0;
                        $amount_transfered=0;
                        $overpayment_refund=0;
                         $overpayment_used=0;
                     foreach($paid as $p){
                        // $dep_amount=0;
                         //mmmmmmmmmmmmchecking deposit mmmmmmmmmmmmmmmmm
                       if($db_id==1){
                         $deposited=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_id'=>23,'trans_no'=>$p->trans_number,'trans_type'=>2),$db);
                         if(count($deposited)>0){
                         $dep_amount+=$deposited[0]->amount;
                         }
                         }
                           //mmmmmmmmmmmmend checking deposit mmmmmmmmmmmmmmmmm
                ///////////////////////removing general receipt ///////////////
                        $charge=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_id'=>22,'trans_no'=>$p->trans_number,'trans_type'=>2),$db);
                        if(count($charge)>0){
                            $cm=$charge[0]->amount;
                        }else{
                            $cm=0;
                        }
                       
                        $in = $payment_model->get_transaction2($p->trans_number,2,$student_id,2,$db);
                        if(count($in)==0){
                          $in=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_id'=>21,'trans_no'=>$p->trans_number,'trans_type'=>2,'transation_nature'=>2),$db);  
                        }
                        
                         $moreInvoice=$payment_model->get_item_name('transactions_relation',$where=array('receipt_trans_no'=>$p->trans_number),$db);
                        if(count($moreInvoice)>1){
                            $rpt=0;
                            foreach($moreInvoice as $more){
                                $rpt++;
                               if (in_array($more->invoice_trans_no, $singleArray)) {
                        $itsAmount=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_type'=>7,'trans_no'=>$p->trans_number,'trans_type'=>2,'transation_nature'=>1),$db); 
                        $paid_amount+=$itsAmount[$rpt-1]->amount; 
                                }
                            }
                        }

                    foreach($in as $in){ 
                       
                       if(count($moreInvoice)>1){

                       }else{
                      $paid_amount+=$in->amount-$cm;
                        }
                    
                          }
                          
                           
                           //mmmmmm transfered amount mmmmmmmmmmmmmmmmmmmm  
                     $transfered=$payment_model->get_item_name('receipt_transfer_tbl',$where=array('old_receipt_number'=>$p->trans_number),$db); 
                     if(count($transfered)>0){
                        foreach($transfered as $trs){
                     $amount_transfered=$amount_transfered+$trs->amount_transfered;     
                        }
                        
                     }     
         //mmmmmm transfered amount mmmmmmmmmmmmmmmmmmmm
         //mmmmmm refunded overpayment mmmmmmmmmmmmmmmmmmmm
            $refund_overpayment= $payment_model->get_item_name('voucher_relation_tbl',$where=array('trans_no'=>$p->trans_number,'voucher_type'=>5,'trans_type'=>2),$db);  
            
                   if(count($refund_overpayment)>0){
                    
                    foreach($refund_overpayment as $check){

                        $approval = $payment_model->get_item_name('approval_numbers', $where = array('trans_no' => $check->payment_no,'trans_type'=>5),$db);
                    if(count($approval)>0){
                 $check_approval= $payment_model->get_item_name('approval_history', $where = array('app_no' => $approval[0]->app_id,'hstatus'=>1),$db);
                 if(count($check_approval)==0){
                    continue;
                 }
                     $look_overpayment= $payment_model->get_item_name('ledger_transaction_tbl',$where=array('trans_no'=>$check->payment_no,'trans_type'=>5,'transation_nature'=>1),$db); 
                    if(count($look_overpayment)>0){
                    $overpayment_refund=$overpayment_refund+$look_overpayment[0]->amount;
                        }
                    }
                }
                   }         
         //mmmmmm end refund amount mmmmmmmmmmmmmmmmmmmm
         //mmmmmm check used overpayment mmmmmmmmmmmmmmmmmmmm
                  
            $used_overpayment= $payment_model->get_item_name('transaction_use_relation_tbl',$where=array('used_no'=>$p->trans_number,'trans_type'=>5,),$db);  
            if(count($used_overpayment)>0){
                $overpayment_used=$overpayment_used+$used_overpayment[0]->amount;
            }
         //mmmmmm end check used overpayment mmmmmmmmmmmmmmmmmmmm
         
         //mmmmmm check deposited receipt mmmmmmmmmmmmmmmmmmmm
            $prepaid_before= $payment_model->get_prepaid_deposited($singleArray,$db);
            if(count($prepaid_before)>0){
               foreach($prepaid_before as $pr){
                $paid_amount=$paid_amount + $pr->amount;
               } 
            }
              //mmmmmm end check deposited receipt mmmmmmmmmmmmmmmmmmmm
                         }
                         $paid_amount=$paid_amount+$credit_amount-$tgmount+$dep_amount-$amount_transfered-$overpayment_refund-$overpayment_used;
                          //return $tgmount; 
                          
                         //class 7 fee
                      if($total>0){
                          if($db_id==4){
                    
                        $new=$new+$gradu;
                        $ment=($total-$new)/2+$new;
                 }else if($db_id==2){
                   
                     $fee=$total-$stationary-$boarding-$gradu-$new;
                     
                    if($adm_id <=2){
                     if($boarding >0){
                      $fee1= (0.487* ($fee+$boarding));
                       $bod1= (42.32/100 * $boarding);
                        }else{
                      $fee1= (0.4301 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3) +$stationary +$new;

                    }else if($adm_id >=3 && $adm_id <=8 && $adm_id !=6){
                        if($boarding >0){
                      $fee1= (0.48717 * ($fee+$boarding));
                       $bod1= (42.32/100 * $boarding);
                        }else{
                      $fee1= (0.5192 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3) +$stationary +$new;
                       //+round($bod1, -3);
                     

                    }else if($adm_id ==6){
                       if($boarding >0){
                      $fee1= (0.4872 * ($fee+$boarding));
                       $bod1= (42.32/100 * $boarding);
                        }else{
                      $fee1= (0.5185 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3) +$stationary+$new;
                    //   +round($bod1, -3);

                    }else if($adm_id ==9){
                     
                      if($boarding >0){
                      $fee1= (0.5384 * ($fee+$boarding));
                       $bod1= (41.66/100 * $boarding);
                        }else{
                      $fee1= (0.59259 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3) +$stationary +$new;
                       //+round($bod1, -4);

                    }else{
                        $ment=0;
                    }
                    
                  }
                  else if($db_id==1){
                          //class 7 fee
                         if($adm_id==10 && $m==1){
                         $ment= ($total/2);
                         }else if($m==1){
                            //other clasess
                         if($hst>0){
                         $ment= ($total-$pocket-$uniform)/2+$uniform+$pocket/3;
                         }else{
                       $ment= ($fee/2)+($tea/3)+$uniform;
                       }
                       //end other clasess
                        }else{
                            $ment=0;
                        }
                        }else if($db_id==13){
                          $ment= ($total/2);
                         }
                         
                //little acorns         
            else if($db_id==6 && $year=="2025"){
           if($adm_id==10){
            $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.3472*$fee, -3)+round(0.375*$remedials, -3)+$exam;
            }else if($adm_id==4 || $adm_id==2){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.3333*$fee, -3)+$uniform;  
            }else if( $adm_id==6){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.3651*$fee, -3)+$uniform;    
            }
            else if($adm_id==5){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.3472*$fee, -3)+round(0.3*$remedials, -3)+$exam+$uniform;  
            }
            else{
                if($uniform > 0){
                     $fee=$total-$pocket-$uniform-$gradu-$remedials;
            $ment = round(0.3472*$fee, -3)+$uniform;  
                }else{
                    $fee=$total-$pocket-$uniform-$gradu-$remedials;
            $ment = round(0.3583*$fee, -3)+$uniform;   
                }
         
            }
             }else if($db_id==6 && $year=="2026"){
           if($adm_id==10){
            $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.4297*$fee, -3)+round(0.375*$remedials, -3)+$exam;
            }else if($adm_id==4 || $adm_id==2 || $adm_id==6){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.4412*$fee, -3)+$uniform;  
            }
            else if($adm_id==5){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.3125*$fee, -3)+round(0.375*$remedials, -3)+$uniform;  
            }
            else{
                
            $fee=$total-$pocket-$uniform-$gradu-$remedials;
            $ment = round(0.3125*$fee, -3)+$uniform;  
            }
             } 
             
             else if($db_id==16){
                 ///winners
                  $fee=$total-$stationary;
            $ment = round(0.35398*$fee, -3)+$stationary; 
             }else if($db_id==10 || $db_id==8 || $db_id==7){
                 ///winners
                  $fee=$total-$stationary;
            $ment = round((60/100)*$fee, -3); 
             }else if($db_id==14){
                 ///kisarika
                  //$fee=$total-$stationary;
                  if($adm_id==11){
                      $ment = round(0.6559*$total, -3); 
                  }else if($adm_id==12){
                       $ment = round(0.7486*$total, -3); 
                  }else if($adm_id==13){
                       $ment = round(0.75301*$total, -3); 
                  }else if($adm_id==14){
                       $ment = round(0.7526*$total, -3); 
                  }else{
                       $ment = round($total/2); 
                  }
            
             }
                  }else{
                   $ment=0; 
                }
                      if($openingbalance !=0 && $used==0){
                          $mbalance=$ment+$openingbalance-$paid_amount;    
                      }else{
                        $mbalance=$ment-$paid_amount; 
                      }
                      if($dateterm[0]->id==$r->id){
                       $todaybalance=$mbalance;
                       $tdy=1;
                      }
                      //$stanne_test='fee='.$fee.'total='.$total.'stationary='.$stationary.'bod-'.$boarding.'gradu='.$gradu.'rounded fee='.round($fee1, -3);
                  
              $mdata1=[
            "ment" => sprintf("%.2f", $ment),
            "mbalance" => $mbalance,
            "paid_amount" => $paid_amount,
            "today" => $tdy,
            "todaybalance" => $todaybalance,
            "openingbalance" => $openingbalance,
            "tinvoice"=>$paid,
           "mm"=>$total.'-remedials'.$remedials.'-uniform'.$uniform.'-gradu'.$gradu.'-exam'.$exam,
            
             ];

                     }
                      if($i==2){
                        $ddate = strtotime($r->end_date);
                         
                         $paid= $payment_model->get_pai_receipt($singleArray,date('Y-m-d H:i',$data1),date('Y-m-d H:i',$ddate),2,$year,$db,count($installments));

                       $credit= $payment_model->get_paid_credit($student_id,date('Y-m-d H:i',$data1),date('Y-m-d H:i',$ddate),2,$year,$db);
                        $tgmount=0;
                        $credit_amount=0;
                     if(count($credit)>0){
                    foreach($credit as $cr){
                     $credit_amount=$credit_amount+$cr->amount;  

                   $check_refund= $payment_model->get_item_name('voucher_relation_tbl',$where=array('trans_no'=>$cr->trans_number,'voucher_type'=>5,'trans_type'=>6),$db);  
                   if(count($check_refund)>0){
                    $credit_refund=0;
                    foreach($check_refund as $check){
                   
                   $approval = $payment_model->get_item_name('approval_numbers', $where = array('trans_no' => $check->payment_no,'trans_type'=>5),$db);
                    if(count($approval)>0){
                 $check_approval= $payment_model->get_item_name('approval_history', $where = array('app_no' => $approval[0]->app_id,'hstatus'=>1),$db);
                 if(count($check_approval)==0){
                    continue;
                 }
                     $look_credit= $payment_model->get_item_name('ledger_transaction_tbl',$where=array('trans_no'=>$check->payment_no,'trans_type'=>5,'transation_nature'=>1),$db); 
                    if(count($look_credit)>0){
                    $credit_amount=$credit_amount-$look_credit[0]->amount;
                        }
                    }
                }
                   }
                        }
                     }
                        
                        $dep_amount=0;
                        $amount_transfered=0;
                        $overpayment_refund=0;
                         $overpayment_used=0;
                     foreach($paid as $p){
                           //mmmmmmmmmmmmchecking deposit mmmmmmmmmmmmmmmmm
                       if($db_id==1){
                         $deposited=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_id'=>23,'trans_no'=>$p->trans_number,'trans_type'=>2),$db);
                         if(count($deposited)>0){
                         $dep_amount+=$deposited[0]->amount;
                         }
                         }

                           //mmmmmmmmmmmmend checking deposit mmmmmmmmmmmmmmmmm
                    ///////////////////////removing general receipt ///////////////
                   $charge=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_id'=>22,'trans_no'=>$p->trans_number,'trans_type'=>2),$db);
                        if(count($charge)>0){
                            $cm=$charge[0]->amount;
                        }else{
                            $cm=0;
                        }
                        
                       
                         $in = $payment_model->get_transaction2($p->trans_number,2,$student_id,2,$db);
                          
                          if(count($in)==0){
                          $in=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_id'=>21,'trans_no'=>$p->trans_number,'trans_type'=>2,'transation_nature'=>2),$db);  
                        }
                          $moreInvoice=$payment_model->get_item_name('transactions_relation',$where=array('receipt_trans_no'=>$p->trans_number),$db);
                        if(count($moreInvoice)>1){
                            $rpt=0;
                            foreach($moreInvoice as $more){
                                $rpt++;
                               if (in_array($more->invoice_trans_no, $singleArray)) {
                        $itsAmount=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_type'=>7,'trans_no'=>$p->trans_number,'trans_type'=>2,'transation_nature'=>1),$db); 
                        $paid_amount+=$itsAmount[$rpt-1]->amount; 
                                }
                            }
                        }

                    foreach($in as $in){ 
                       
                       if(count($moreInvoice)>1){

                       }else{
                      $paid_amount+=$in->amount-$cm;
                        }
                    
                          }
                      //mmmmmm transfered amount mmmmmmmmmmmmmmmmmmmm  
                     $transfered=$payment_model->get_item_name('receipt_transfer_tbl',$where=array('old_receipt_number'=>$p->trans_number),$db); 
                     if(count($transfered)>0){
                        foreach($transfered as $trs){
                     $amount_transfered=$amount_transfered+$trs->amount_transfered;     
                        }
                        
                     }     
         //mmmmmm transfered amount mmmmmmmmmmmmmmmmmmmm
                       //mmmmmm refunded overpayment mmmmmmmmmmmmmmmmmmmm
            $refund_overpayment= $payment_model->get_item_name('voucher_relation_tbl',$where=array('trans_no'=>$p->trans_number,'voucher_type'=>5,'trans_type'=>2),$db);  
            
                   if(count($refund_overpayment)>0){
                    
                    foreach($refund_overpayment as $check){

                     $approval = $payment_model->get_item_name('approval_numbers', $where = array('trans_no' => $check->payment_no,'trans_type'=>5),$db);
                    if(count($approval)>0){
                 $check_approval= $payment_model->get_item_name('approval_history', $where = array('app_no' => $approval[0]->app_id,'hstatus'=>1),$db);
                 if(count($check_approval)==0){
                    continue;
                 }
                     $look_overpayment= $payment_model->get_item_name('ledger_transaction_tbl',$where=array('trans_no'=>$check->payment_no,'trans_type'=>5,'transation_nature'=>1),$db); 
                    if(count($look_overpayment)>0){
                    $overpayment_refund=$overpayment_refund+$look_overpayment[0]->amount;
                        }
                    }
                }
                   }         
         //mmmmmm end refund amount mmmmmmmmmmmmmmmmmmmm
           //mmmmmm check used overpayment mmmmmmmmmmmmmmmmmmmm
                  
            $used_overpayment= $payment_model->get_item_name('transaction_use_relation_tbl',$where=array('used_no'=>$p->trans_number,'trans_type'=>5,),$db);  
            if(count($used_overpayment)>0){
                $overpayment_used=$overpayment_used+$used_overpayment[0]->amount;
            }
         //mmmmmm end check used overpayment mmmmmmmmmmmmmmmmmmmm
                         }
                 $paid_amount=$paid_amount+$credit_amount-$tgmount+$dep_amount-$amount_transfered-$overpayment_refund-$overpayment_used;
                      //$paid_amount=$paid[0]->amount;
                       //class 7 fee
                       if($total>0){
                         if($db_id==4){
                       if($total==0){
                          $ment=0;
                      }else{
                        $ment=($total-$new)/2;
                      }
                    
                  }else if($db_id==2){
                    if($total==0){
                      $ment=0;
                    }else{
                    ////stanne
                    $fee=$total-$stationary-$boarding-$gradu -$new;
                    if($adm_id <=2){
                     if($boarding >0){
                       $fee1= (0.30769 * ($fee+$boarding));
                       $bod1= (35.38/100 * $boarding);
                        }else{
                      $fee1= (0.32258 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3) + $gradu;

                    }else if($adm_id >=3 && $adm_id <=8 && $adm_id !=6){
                        if($boarding >0){
                       $fee1= (0.30769 * ($fee+$boarding));
                       $bod1= (35.38/100 * $boarding);
                        }else{
                      $fee1= (0.2846 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3) +$gradu;
                       //+round($bod1, -4)+$gradu;
                     

                    }else if($adm_id ==6){
                       if($boarding >0){
                      $fee1= (0.30769 * ($fee+$boarding));
                       $bod1= (35.38/100 * $boarding);
                        }else{
                      $fee1= (0.27778 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3) +$gradu;
                    //   +round($bod1, -4)+$gradu;

                    }else if($adm_id ==9){
                     
                      if($boarding >0){
                      $fee1= (0.4615 *  ($fee+$boarding));
                      // $bod1= (58.33/100 * $boarding);
                        }else{
                      $fee1= (0.4074 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3) +$gradu;
                       //+round($bod1, -4)+$gradu;

                    }else{
                        $ment=0;
                    }
                     ///st anne
                    }
                  }
                  else if($db_id==1){
                       //for class 7
                 if($adm_id==10 && $m==1){
                         $ment= ($total/2);
                         }else if($m==1){
                            //for other classes
                         if($hst>0){
                          $ment= ($total-$pocket-$uniform)/4+$pocket/3;
                         }else{
                              $fee=sprintf("%.2f", $fee);
                          $ment= ($fee/4)+($tea/3);  
                         }
                     }else if($m==2){
                        
                        if($hst>0){
                          $ment= ($total-$pocket-$uniform)/2+$pocket/2+$uniform;
                         }else{
                          $ment= ($fee/2)+($tea/2)+$uniform;  
                         }

                      }else{
                        $ment=0;
                      }

                      //***end other classes
                      }else if($db_id==13){
                          $ment= (0.3*$total);
                }else if($db_id==6 && $year=="2025"){
           if($adm_id==10){
            $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.3472*$fee, -3)+round(0.375*$remedials, -3);
            }else if($adm_id==4 || $adm_id==2){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.3333*$fee, -3);  
            }else if($adm_id==6){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.31746*$fee, -3);  
            }else if($adm_id==5){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.2778*$fee, -3)+round(0.3*$remedials, -3);  
            }else{
                if($uniform >0){
                        $fee=$total-$pocket-$uniform-$gradu-$remedials;
            $ment = round(0.2778*$fee, -3);
                }else{
            $fee=$total-$pocket-$uniform-$gradu-$remedials;
            $ment = round(0.215*$fee, -3); 
                }
        
            }
             }else if($db_id==6 && $year=="2026"){
           if($adm_id==10){
            $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.3125*$fee, -3)+round(0.375*$remedials, -3);
            }else if($adm_id==4 || $adm_id==2 || $adm_id==6){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.2941*$fee, -3);  
            }
            else if($adm_id==5){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.2461*$fee, -3)+round(0.375*$remedials, -3);  
            }
            else{
                
            $fee=$total-$pocket-$uniform-$gradu-$remedials;
            $ment = round(0.2461*$fee, -3);  
            }
             } 
             else if($db_id==16){
                 ///winners
             $fee=$total-$stationary;
            $ment = round(0.146*$fee, -3); 
             }else if($db_id==10 || $db_id==8 || $db_id==7 ){
                 ///winners
                  $fee=$total-$stationary;
            $ment = round((40/100)*$fee, -3); 
             }else if($db_id==14){
                 ///kisarika
                  //$fee=$total-$stationary;
                  if($adm_id==11){
                      $ment = round(0.3441*$total, -3); 
                  }else if($adm_id==12){
                       $ment = round(0.2514*$total, -3); 
                  }else if($adm_id==13){
                       $ment = round(0.24699*$total, -3); 
                  }else if($adm_id==14){
                       $ment = round(0.2473*$total, -3); 
                  }else{
                       $ment = round($total/2); 
                  }
            
             }
                      }else{
                   $ment=0; 
                }
                        $mbalance=($mbalance+$ment)-$paid_amount;
                        $data22=$data1;
                         $data1= $ddate;
                          if($dateterm[0]->id==$r->id){
                       $todaybalance=$mbalance;
                       $tdy=1;
                       }
                 
              $mdata2=[
            "ment" => sprintf("%.2f", $ment),
            "mbalance" => $mbalance,
            "paid_amount" => $paid_amount,
            "today" => $tdy,
            "todaybalance" => $todaybalance,
            "check_refund"=>$overpayment_refund,
            "mm"=>$paid,
             ];
                    
                      
                        
                     }
                     
                     
                   if($i==3){

                     $ddate = strtotime($r->end_date);
                       $paid= $payment_model->get_pai_receipt($singleArray,date('Y-m-d H:i',$data1),date('Y-m-d H:i',$ddate),3,$year,$db,count($installments));

                      $credit= $payment_model->get_paid_credit($student_id,date('Y-m-d H:i',$data1),date('Y-m-d H:i',$ddate),3,$year,$db);
                       $tgmount=0;
                       $credit_amount=0;
                     if(count($credit)>0){
                    foreach($credit as $cr){
                     $credit_amount=$credit_amount+$cr->amount;  

                   $check_refund= $payment_model->get_item_name('voucher_relation_tbl',$where=array('trans_no'=>$cr->trans_number,'voucher_type'=>5,'trans_type'=>6),$db); 

                   if(count($check_refund)>0){
                    $credit_refund=0;
                    foreach($check_refund as $check){

                    $approval = $payment_model->get_item_name('approval_numbers', $where = array('trans_no' => $check->payment_no,'trans_type'=>5),$db);
                    if(count($approval)>0){
                 $check_approval= $payment_model->get_item_name('approval_history', $where = array('app_no' => $approval[0]->app_id,'hstatus'=>1),$db);
                 if(count($check_approval)==0){
                    continue;
                 }
                     $look_credit= $payment_model->get_item_name('ledger_transaction_tbl',$where=array('trans_no'=>$check->payment_no,'trans_type'=>5,'transation_nature'=>1),$db); 
                    if(count($look_credit)>0){
                    $credit_amount=$credit_amount-$look_credit[0]->amount;
                        }
                    }
                }
                   }
                        }
                     }

                     $dep_amount=0;
                        $amount_transfered=0;
                        $overpayment_refund=0;
                         $overpayment_used=0;
                         
                     foreach($paid as $p){
                        //mmmmmmmmmmmmchecking deposit mmmmmmmmmmmmmmmmm
                        if($db_id==1){
                         $deposited=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_id'=>23,'trans_no'=>$p->trans_number,'trans_type'=>2),$db);
                         if(count($deposited)>0){
                         $dep_amount+=$deposited[0]->amount;
                         }
                         }
                           //mmmmmmmmmmmmend checking deposit mmmmmmmmmmmmmmmmm
                ///////////////////////removing general receipt ///////////////
                        $charge=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_id'=>22,'trans_no'=>$p->trans_number,'trans_type'=>2),$db);
                        if(count($charge)>0){
                            $cm=$charge[0]->amount;
                        }else{
                            $cm=0;
                        }
                      $in = $payment_model->get_transaction2($p->trans_number,2,$student_id,2,$db);
                       if(count($in)==0){
                          $in=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_id'=>21,'trans_no'=>$p->trans_number,'trans_type'=>2,'transation_nature'=>2),$db);  
                        }
                        $moreInvoice=$payment_model->get_item_name('transactions_relation',$where=array('receipt_trans_no'=>$p->trans_number),$db);
                        if(count($moreInvoice)>1){
                            $rpt=0;
                            foreach($moreInvoice as $more){
                                $rpt++;
                               if (in_array($more->invoice_trans_no, $singleArray)) {
                        $itsAmount=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_type'=>7,'trans_no'=>$p->trans_number,'trans_type'=>2,'transation_nature'=>1),$db); 
                        //$paid_amount3=$paid_amount;
                        $paid_amount+=$itsAmount[$rpt-1]->amount; 
                        $paid_amount1=$itsAmount[$rpt-1]->amount; 
                        
                                }
                            }
                        }

                    foreach($in as $in){ 
                       
                       if(count($moreInvoice)>1){

                       }else{
                      $paid_amount+=$in->amount-$cm;
                       $paid_amount3=$in->amount-$cm;
                        }
                    
                          }
                      //mmmmmm transfered amount mmmmmmmmmmmmmmmmmmmm  
                     $transfered=$payment_model->get_item_name('receipt_transfer_tbl',$where=array('old_receipt_number'=>$p->trans_number),$db); 
                     if(count($transfered)>0){
                        foreach($transfered as $trs){
                     $amount_transfered=$amount_transfered+$trs->amount_transfered;     
                        }
                        
                     }     
         //mmmmmm transfered amount mmmmmmmmmmmmmmmmmmmm
                       //mmmmmm refunded overpayment mmmmmmmmmmmmmmmmmmmm
            $refund_overpayment= $payment_model->get_item_name('voucher_relation_tbl',$where=array('trans_no'=>$p->trans_number,'voucher_type'=>5,'trans_type'=>2),$db);  
            
                   if(count($refund_overpayment)>0){
                    
                    foreach($refund_overpayment as $check){

                        $approval = $payment_model->get_item_name('approval_numbers', $where = array('trans_no' => $check->payment_no,'trans_type'=>5),$db);
                    if(count($approval)>0){
                 $check_approval= $payment_model->get_item_name('approval_history', $where = array('app_no' => $approval[0]->app_id,'hstatus'=>1),$db);
                 if(count($check_approval)==0){
                    continue;
                 }
                     $look_overpayment= $payment_model->get_item_name('ledger_transaction_tbl',$where=array('trans_no'=>$check->payment_no,'trans_type'=>5,'transation_nature'=>1),$db); 
                    if(count($look_overpayment)>0){
                    $overpayment_refund=$overpayment_refund+$look_overpayment[0]->amount;
                        }
                    }
                }
                   }         
         //mmmmmm end refund amount mmmmmmmmmmmmmmmmmmmm
           //mmmmmm check used overpayment mmmmmmmmmmmmmmmmmmmm
                  
            $used_overpayment= $payment_model->get_item_name('transaction_use_relation_tbl',$where=array('used_no'=>$p->trans_number,'trans_type'=>5,),$db);  
            if(count($used_overpayment)>0){
               $overpayment_used=$overpayment_used+$used_overpayment[0]->amount;
            }
         //mmmmmm end check used overpayment mmmmmmmmmmmmmmmmmmmm
                         }
                         
                     $paid_amount=$paid_amount+$credit_amount-$tgmount+ $dep_amount-$amount_transfered-$overpayment_refund-$overpayment_used;
                    
                     if($total>0){
                      if($db_id==4){
                      $ment=0;
                  }else if($db_id==2){
                       
                         ////stanne
                    $fee=$total-$stationary-$boarding-$gradu-$new;
                    if($adm_id <=2){
                     if($boarding >0){
                       $fee1= (0.2051 * ($fee+$boarding));
                       $bod1= (22.307/100 * $boarding);
                        }else{
                      $fee1= (0.2473 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3);

                    }else if($adm_id >=3 && $adm_id <=8 && $adm_id !=6){
                        if($boarding >0){
                       $fee1= (0.20512 * ($fee+$boarding));
                       $bod1= (22.307/100 * $boarding);
                        }else{
                      $fee1= (0.19615 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3);
                       //+round($bod1, -4);
                     

                    }else if($adm_id ==6){
                       if($boarding >0){
                      $fee1= (0.20512 * ($fee+$boarding));
                       $bod1= (22.307/100 * $boarding);
                        }else{
                      $fee1= (0.2037 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3);
                       //+round($bod1, -4);

                    }else if($adm_id ==9){
                     
                       $ment =0;

                    }else{
                        $ment=0;
                    }
                     ///st anne
                   
                  }
                  else if($db_id==1){
                     if($adm_id==10){
                        //for class 7
                         $ment= 0;
                         }else{
                        if($adm_id==10 && $m==1){
                        //for class 7
                         $ment= 0;
                         }else if($m==1){
                            //for other classes
                         if($hst>0){
                     $ment= ($total-$pocket-$uniform)/4+$pocket/3;
                  }else{
                       $fee=sprintf("%.2f", $fee);
                    $ment= ($fee/4)+($tea/3);
                  }
              }else if($m==2){

              if($hst>0){
                     $ment= ($total-$pocket-$uniform)/2+$pocket/2;
                  }else{
                    $ment= ($fee/2)+($tea/2);
                  }

              }else if($m==3){
              $ment=$total;
              }
              }
          }else if($db_id==7){
              $ment= 0;
             }else if($db_id==13){
              $ment= (0.2*$total);
             }else if($db_id==6 && $year=="2025"){
           if($adm_id==10){
            $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.3056*$fee, -3)+round(0.25*$remedials, -3)+$gradu;
            }else if($adm_id==4 || $adm_id==2){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.16667*$fee, -3);  
            }else if($adm_id==6){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.15873*$fee, -3);  
            }else if($adm_id==5){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.2083*$fee, -3)+round(0.3*$remedials, -3);  
            }else{//
              if($uniform >0){
                  $fee=$total-$pocket-$uniform-$gradu-$remedials;
            $ment = round(0.2083*$fee, -3); 
              }else{
               $fee=$total-$pocket-$uniform-$gradu-$remedials;
            $ment = round(0.215*$fee, -3);    
              }
           
            }
             }else if($db_id==6 && $year=="2026"){
           if($adm_id==10){
            $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.2578*$fee, -3)+round(0.25*$remedials, -3)+$gradu;
            }else if($adm_id==4 || $adm_id==2 || $adm_id==6){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.1470*$fee, -3);  
            }
            else if($adm_id==5){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.2344*$fee, -3)+round(0.25*$remedials, -3);  
            }
            else{
                
            $fee=$total-$pocket-$uniform-$gradu-$remedials;
            $ment = round(0.2344*$fee, -3);  
            }
             } 
             else if($db_id==16){
                 ///winners
             $fee=$total-$stationary;
            $ment = round(0.35398*$fee, -3); 
             }
                   }else{
                   $ment=0; 
                }
                        $mbalance=($mbalance+$ment)-$paid_amount;
                         if($dateterm[0]->id==$r->id){
                       $todaybalance=$mbalance;
                       $tdy=1;
                      }
                     
                     $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     
                     $data22=$data1;
                    $data1= $ddate;

             $mdata3=[
            "ment" => $ment,
            "mbalance" => $mbalance,
            "paid_amount" => $paid_amount,
            "today" => $tdy,
            "todaybalance" => $todaybalance,
            "check_refund"=>$overpayment_refund,
              "mm"=>$paid,
           //"mm"=>$paid_amount.'-credit_amount-'.$credit_amount.'-tgmount-'.$tgmount.'-deposit->'.$dep_amount.'-'.$amount_transfered.'-'.$overpayment_refund.'-'.$overpayment_used
             ];
                 }
                 
                    //#################start#########################
       if($i==4){

                     $ddate = strtotime($r->end_date);
                       $paid= $payment_model->get_pai_receipt($singleArray,date('Y-m-d H:i',$data1),date('Y-m-d H:i',$ddate),4,$year,$db,count($installments));

                      $credit= $payment_model->get_paid_credit($student_id,date('Y-m-d H:i',$data1),date('Y-m-d H:i',$ddate),4,$year,$db);
                       $tgmount=0;
                       $credit_amount=0;
                     if(count($credit)>0){
                    foreach($credit as $cr){
                     $credit_amount=$credit_amount+$cr->amount;  

                   $check_refund= $payment_model->get_item_name('voucher_relation_tbl',$where=array('trans_no'=>$cr->trans_number,'voucher_type'=>5,'trans_type'=>6),$db); 

                   if(count($check_refund)>0){
                    $credit_refund=0;
                    foreach($check_refund as $check){

                    $approval = $payment_model->get_item_name('approval_numbers', $where = array('trans_no' => $check->payment_no,'trans_type'=>5),$db);
                    if(count($approval)>0){
                 $check_approval= $payment_model->get_item_name('approval_history', $where = array('app_no' => $approval[0]->app_id,'hstatus'=>1),$db);
                 if(count($check_approval)==0){
                    continue;
                 }
                     $look_credit= $payment_model->get_item_name('ledger_transaction_tbl',$where=array('trans_no'=>$check->payment_no,'trans_type'=>5,'transation_nature'=>1),$db); 
                    if(count($look_credit)>0){
                    $credit_amount=$credit_amount-$look_credit[0]->amount;
                        }
                    }
                }
                   }
                        }
                     }

                     $dep_amount=0;
                        $amount_transfered=0;
                        $overpayment_refund=0;
                         $overpayment_used=0;
                         
                     foreach($paid as $p){
                        //mmmmmmmmmmmmchecking deposit mmmmmmmmmmmmmmmmm
                        if($db_id==1){
                         $deposited=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_id'=>23,'trans_no'=>$p->trans_number,'trans_type'=>2),$db);
                         if(count($deposited)>0){
                         $dep_amount+=$deposited[0]->amount;
                          
                         }
                        }
                           //mmmmmmmmmmmmend checking deposit mmmmmmmmmmmmmmmmm
                ///////////////////////removing general receipt ///////////////
                        $charge=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_id'=>22,'trans_no'=>$p->trans_number,'trans_type'=>2),$db);
                        if(count($charge)>0){
                            $cm=$charge[0]->amount;
                        }else{
                            $cm=0;
                        }
                      $in = $payment_model->get_transaction2($p->trans_number,2,$student_id,2,$db);
                       if(count($in)==0){
                          $in=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_id'=>21,'trans_no'=>$p->trans_number,'trans_type'=>2,'transation_nature'=>2),$db);  
                        }
                         $moreInvoice=$payment_model->get_item_name('transactions_relation',$where=array('receipt_trans_no'=>$p->trans_number),$db);
                        if(count($moreInvoice)>1){
                            $rpt=0;
                            foreach($moreInvoice as $more){
                                $rpt++;
                               if (in_array($more->invoice_trans_no, $singleArray)) {
                        $itsAmount=$payment_model->get_item_name('ledger_transaction_tbl',$where=array('ledger_type'=>7,'trans_no'=>$p->trans_number,'trans_type'=>2,'transation_nature'=>1),$db); 
                        //$paid_amount3=$paid_amount;
                        $paid_amount+=$itsAmount[$rpt-1]->amount; 
                        $paid_amount1=$itsAmount[$rpt-1]->amount; 
                        
                                }
                            }
                        }

                    foreach($in as $in){ 
                       
                       if(count($moreInvoice)>1){

                       }else{
                      $paid_amount+=$in->amount-$cm;
                       $paid_amount3=$in->amount-$cm;
                        }
                    
                          }
                      //mmmmmm transfered amount mmmmmmmmmmmmmmmmmmmm  
                     $transfered=$payment_model->get_item_name('receipt_transfer_tbl',$where=array('old_receipt_number'=>$p->trans_number),$db); 
                     if(count($transfered)>0){
                        foreach($transfered as $trs){
                     $amount_transfered=$amount_transfered+$trs->amount_transfered;     
                        }
                        
                     }     
         //mmmmmm transfered amount mmmmmmmmmmmmmmmmmmmm
                       //mmmmmm refunded overpayment mmmmmmmmmmmmmmmmmmmm
            $refund_overpayment= $payment_model->get_item_name('voucher_relation_tbl',$where=array('trans_no'=>$p->trans_number,'voucher_type'=>5,'trans_type'=>2),$db);  
            
                   if(count($refund_overpayment)>0){
                    
                    foreach($refund_overpayment as $check){

                        $approval = $payment_model->get_item_name('approval_numbers', $where = array('trans_no' => $check->payment_no,'trans_type'=>5),$db);
                    if(count($approval)>0){
                 $check_approval= $payment_model->get_item_name('approval_history', $where = array('app_no' => $approval[0]->app_id,'hstatus'=>1),$db);
                 if(count($check_approval)==0){
                    continue;
                 }
                     $look_overpayment= $payment_model->get_item_name('ledger_transaction_tbl',$where=array('trans_no'=>$check->payment_no,'trans_type'=>5,'transation_nature'=>1),$db); 
                    if(count($look_overpayment)>0){
                    $overpayment_refund=$overpayment_refund+$look_overpayment[0]->amount;
                        }
                    }
                }
                   }         
         //mmmmmm end refund amount mmmmmmmmmmmmmmmmmmmm
           //mmmmmm check used overpayment mmmmmmmmmmmmmmmmmmmm
                  
            $used_overpayment= $payment_model->get_item_name('transaction_use_relation_tbl',$where=array('used_no'=>$p->trans_number,'trans_type'=>5,),$db);  
            if(count($used_overpayment)>0){
               $overpayment_used=$overpayment_used+$used_overpayment[0]->amount;
            }
         //mmmmmm end check used overpayment mmmmmmmmmmmmmmmmmmmm
                         }
                         
                     $paid_amount=$paid_amount+$credit_amount-$tgmount+ $dep_amount-$amount_transfered-$overpayment_refund-$overpayment_used;
                    
                     if($total>0){
                      if($db_id==4){
                      $ment=0;
                  }else if($db_id==2){
                       
                         ////stanne
                    $fee=$total-$stationary-$boarding-$gradu-$new;
                    if($adm_id <=2){
                     if($boarding >0){
                       $fee1= (20.304/100 * ($fee+$boarding));
                       $bod1= (22.307/100 * $boarding);
                        }else{
                      $fee1= (19.31/100 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3);

                    }else if($adm_id >=3 && $adm_id <=8 && $adm_id !=6){
                        if($boarding >0){
                       $fee1= (20.304/100 * ($fee+$boarding));
                       $bod1= (22.307/100 * $boarding);
                        }else{
                      $fee1= (19.31/100 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3);
                       //+round($bod1, -4);
                     

                    }else if($adm_id ==6){
                       if($boarding >0){
                      $fee1= (20.304/100 * ($fee+$boarding));
                       $bod1= (22.307/100 * $boarding);
                        }else{
                      $fee1= (20.07/100 * $fee);
                      $bod1=0;
                        }
                       $ment = round($fee1, -3);
                       //+round($bod1, -4);

                    }else if($adm_id ==9){
                     
                       $ment =0;

                    }else{
                        $ment=0;
                    }
                     ///st anne
                   
                  }
                  else if($db_id==1){
                     if($adm_id==10){
                        //for class 7
                         $ment= 0;
                         }else{
                        if($adm_id==10 && $m==1){
                        //for class 7
                         $ment= 0;
                         }else if($m==1){
                            //for other classes
                         if($hst>0){
                     $ment= ($total-$pocket-$uniform)/4+$pocket/3;
                  }else{
                       $fee=sprintf("%.2f", $fee);
                    $ment= ($fee/4)+($tea/3);
                  }
              }else if($m==2){

              if($hst>0){
                     $ment= ($total-$pocket-$uniform)/2+$pocket/2;
                  }else{
                    $ment= ($fee/2)+($tea/2);
                  }

              }else if($m==3){
              $ment=$total;
              }
              }
          }else if($db_id==7){
          $ment= 0;
         }else if($db_id==13){
          $ment= (0.2*$total);
         }else if($db_id==6 && $year=="2025"){
            if($adm_id==10 ){
            $ment=0;
            }else if($adm_id==4 || $adm_id==2){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.16667*$fee, -3)+$gradu;  
            }else if($adm_id==6){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.15873*$fee, -3)+$gradu;;  
            }else if($adm_id==5){//p4
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.1667*$fee, -3)+round(0.1*$remedials, -3)+$gradu;  
            }else{
                if($uniform >0){
             $fee=$total-$pocket-$uniform-$gradu;
            $ment = round(0.1667*$fee, -3)+$gradu;
                }else{
            $fee=$total-$pocket-$uniform-$gradu;
            $ment = round(0.2116*$fee, -3)+$gradu;  
                }
           
            }
         }else if($db_id==6 && $year=="2026"){
           if($adm_id==10){
            
            $ment = 0;
            }else if($adm_id==4 || $adm_id==2 || $adm_id==6){
            //   $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            // $ment = round(0.1176*$fee, -3); 
            $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.1176*$fee, -3)+$gradu;  
            
            }
            else if($adm_id==5){
               $fee=$total-$pocket-$uniform-$gradu-$remedials-$exam;
            $ment = round(0.207*$fee, -3)+$gradu+$exam;  
            }
            else{
                
            $fee=$total-$pocket-$uniform-$gradu-$remedials;
            $ment = round(0.207*$fee, -3)+$gradu;  
            }
             } 
         else if($db_id==16){
                 ///winners
                  $fee=$total-$stationary;
            $ment = round(0.146*$fee, -3); 
             }
                   }else{
                   $ment=0; 
                }
                        $mbalance=($mbalance+$ment)-$paid_amount;
                         if($dateterm[0]->id==$r->id){
                       $todaybalance=$mbalance;
                       $tdy=1;
                      }
                     
                     $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;

             $mdata4=[
            "ment" => $ment,
            "mbalance" => $mbalance,
            "paid_amount" => $paid_amount,
            "today" => $tdy,
            "todaybalance" => $todaybalance,
            "check_refund"=>$overpayment_refund,
            "mm"=>$year,
          
             ];
                 }
      //###################end##########################
             }
    //***end istallment calculations***//

         if(count($installments)==1){
        $resultData = [$mdata1];
         }
         elseif(count($installments)==2){
        $resultData = [$mdata1, $mdata2];
         }elseif(count($installments)==3){
         $resultData = [$mdata1, $mdata2, $mdata3]; 
         }
         else{
         $resultData = [$mdata1, $mdata2, $mdata3,$mdata4];   
         }

         return $resultData;
}
?>
