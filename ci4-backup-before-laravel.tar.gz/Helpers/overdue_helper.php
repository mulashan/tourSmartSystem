  <?php  
  use App\Models\StudentModel;


                
                function transport_overdue(){

                 $amodel = new StudentModel();

                              $startingdate=date('Y-m-d');
                           $sdate = strtotime($startingdate);
                               $vhc=$amodel->get_item_name('vehicles_list_tbl', $where = array('status' => 1));
                                  if(count($vhc)>0){

                                  $c=0;
                         $trans_numbers=array();
                           $ttl=0;
                     foreach($vhc as $s){
                               $permits=0;
                              
                                $ttlReceipt=0;
                        $dr=$amodel->get_item_name('users', $where = array('user_id' => $s->driver_name));
                        $route=$amodel->get_item_name('route_tbl', $where = array('vehicle' => $s->id));

                        foreach($route as $rt){
                               
                          $check_station=$amodel->get_item_name('station_session_tbl', $where = array('route_id' => $rt->id));
                          if(count($check_station)>0){
                            foreach($check_station as $st){
                         $check_transp=$amodel->get_item_name('transport_details', $where = array('pickup_station' => $st->station_id,'pickup_session' => $st->session_name,'status'=>3)); 

                          $check_transd=$amodel->get_item_name('transport_details', $where = array('drop_station' => $st->station_id,'drop_session' => $st->session_name,'transport_trip'=>1,'status'=>3));
                         //print_r($check_transd);
                   
                      if(count($check_transp)>0) {

                            foreach($check_transp as $sp){
         //////////////////////////////////

                    $date = $sp->date_created; // your date

                   $days = floor((time() - strtotime($date)) / (60 * 60 * 24));
                    if($days <= '30'){
                        continue;
                    }

             $check=$amodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $sp->trans_numb,'trans_type_id'=>1));
             if(count($check)>0){
          $Transaction = [
               'date_created' => $check[0]->trans_date
                   ];
             $amodel->update_table_details('transport_details',$where = array('trans_numb' =>$sp->trans_numb),$Transaction);
                   }
             /////////////////////////////////////////

                        $trans_numbers[]=array('no'=>$sp->trans_numb);
                        $permits+=1;
                        $check_amount=$amodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $sp->trans_numb,'trans_type'=>1,'transation_nature'=>2));

                         $check_receipt=$amodel->get_item_name('transactions_relation', $where = array('invoice_trans_no' => $sp->trans_numb));

                        if(count($check_amount)>0){
                            //foreach($check_amount as $am){
                                $ttl+=$check_amount[0]->amount;
                            //}
                        }

                      
                        
                         }}

                         if(count($check_transd)>0) {

                          $result = array();
                        foreach ($trans_numbers as $item) {
                        $result[] = $item['no'];
                        }
                      $new_array['no'] = $result;
                      //print_r($new_array);

                            foreach($check_transd as $sd){
                                //////////////////////////////////
                        $date = $sd->date_created; // your date

                   $days = floor((time() - strtotime($date)) / (60 * 60 * 24));
                    if($days <= '30'){
                        continue;
                    }
             $check=$amodel->get_item_name('transaction_numbers_tbl', $where = array('trans_number' => $sd->trans_numb,'trans_type_id'=>1));
             if(count($check)>0){
          $Transaction = [
               'date_created' => $check[0]->trans_date
                   ];
             $amodel->update_table_details('transport_details',$where = array('trans_numb' =>$sd->trans_numb),$Transaction);
                   }
             /////////////////////////////////////////

                        //////////////////////////////////
                          $value_to_check =$sd->trans_numb;

                        if (in_array($value_to_check, $new_array['no'])) {
                            //echo "$value_to_check is present in the array.</br>";
                        } else {
                            $permits+=1;
                            $trans_numbers[]=array('no'=>$value_to_check);
                          //  echo "$value_to_check is not present in the array.</br>";
                            $check_amount=$amodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $sd->trans_numb,'trans_type'=>1,'transation_nature'=>2)); 

                            $check_receipt=$amodel->get_item_name('transactions_relation', $where = array('invoice_trans_no' => $sd->trans_numb));

                          if(count($check_amount)>0){
                            foreach($check_amount as $am){
                                $ttl+=$am->amount;
                            }
                        }

                        
                        }
                        ////////////////////////////////        
                        
                            }
                         }
                            }
                           
                          }  
                            
                        }
                          
                                $ttl=+$ttl;
                               

                            }
                        }
                        return $ttl;

                    }
                              ?>
                         
       