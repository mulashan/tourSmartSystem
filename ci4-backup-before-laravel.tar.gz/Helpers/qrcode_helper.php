<?php

use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel;
use Endroid\QrCode\Label\Alignment\LabelAlignmentCenter;
use Endroid\QrCode\Label\Font\NotoSans;
use Endroid\QrCode\Logo\Logo;
use Endroid\QrCode\RoundBlockSizeMode;

if (!function_exists('generate_qr_code')) {
    function generate_qr_code($data, $filename, $path = ROOTPATH . 'public/qrcodes/')
    {
        $outputFile = $path . $filename;

        try {
            $result = Builder::create()
                ->data($data)
                ->encoding(new Encoding('UTF-8'))
                ->errorCorrectionLevel(ErrorCorrectionLevel::Low) 
                ->size(300)
                ->margin(10)
                ->roundBlockSizeMode(roundBlockSizeMode::Margin) 
                ->build();

            $result->saveToFile($outputFile);

            return $outputFile; // Return the file path of the saved QR code
        } catch (\Exception $e) {
            log_message('error', $e->getMessage());
            return false;
        }
    }
}

