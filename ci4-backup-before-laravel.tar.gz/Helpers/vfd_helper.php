<?php 
use App\Models\PaymentsModel;

function process_vfd_receipt_now($id,$amount,$cusName,$db,$db_id){  
 helper('qrcode_helper');
  $payment_model = new PaymentsModel;

  $trans=$payment_model->get_item_name('transaction_numbers_tbl', $where = array('id' => $id),$db);
  $trans_no=$trans[0]->trans_number;

   $leger=$payment_model->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $trans_no,'trans_type'=>2,'name_type_id'=>1),$db);
   if(count($leger)>0){
      $bill = $payment_model->gettable_billingdata($leger[0]->name_id,$db);
     $cusMobile=$bill[0]->phone1??"2557500000000";  
   }else{
      $leger=$payment_model->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $trans_no,'trans_type'=>2,'name_type_id'=>4),$db); 
        if(count($leger)>0){
            $bill=$payment_model->get_item_name('students_application_tbl', $where = array('id' => $leger[0]->name_id),$db); 
             $cusMobile=$bill[0]->phone_number??"2557500000000";  
        }else{
          $cusMobile="2557500000000";    
        }
   }
  
  
  $check_receipt=$payment_model->get_item_name('vfd_receipts_details_tbl', $where = array('receipt_number' => $trans_no),$db);
if(count($check_receipt)>0){

}
  $setting=$payment_model->get_item_name('vfd_settings_tbl', $where = array('status' => 1),$db);

  if(count($setting)>0){
$serialNum = $setting[0]->serialNum;
$tinNum = $setting[0]->tinNum;
$docTin = $setting[0]->docTin;

$custTIN = $setting[0]->custTIN;
$custVRN = $setting[0]->custVRN;
  
// Your PHP data
$commandCode = 50;
$commandDescr = "Saving Sale Transaction";
$ID=1;
$DESC="School fees";
$QTY=1;
$TAXCODE=1;
$PRICE=sprintf("%.2f", $amount);
$AMT = sprintf("%.2f", $amount);

$permitNum = "RCT/".$trans_no;
$vatAmt = (18*$amount)/118;
$vatAmt = sprintf("%.2f", $vatAmt);
$grossAmt = sprintf("%.2f", $amount);
if($trans[0]->updated_by==9){
$cash = 0;
$ccard = sprintf("%.2f", $amount);
}else{
 $cash = sprintf("%.2f", $amount); 
 $ccard = 0;  
}

$cheque = 0;
$emoney = 0;
$invoice = 0;
$dateTime = trim(date('Y/m/d H:i:s'));
$username = trim($setting[0]->username);
$password = trim($setting[0]->password);
$licence = trim($setting[0]->licence);
$cusMobile = trim(str_replace("-", "", $cusMobile));
  $cusName=trim(str_replace("'","", $cusName));

// Construct the XML
$key="<data><ITEMS><ITEM><ID>{$ID}</ID><DESC>{$DESC}</DESC><QTY>{$QTY}</QTY><TAXCODE>{$TAXCODE}</TAXCODE><PRICE>{$PRICE}</PRICE><AMT>{$AMT}</AMT></ITEM></ITEMS><Serial_num>{$serialNum}</Serial_num><TIN_num>{$tinNum}</TIN_num><DocTin>{$docTin}</DocTin><cusname>{$cusName}</cusname><custMobile>{$cusMobile}</custMobile><custTIN>{$custTIN}</custTIN><custVRN>{$custVRN}</custVRN><permitNum>{$permitNum}</permitNum><vatAmt>{$vatAmt}</vatAmt><grossAmt>{$grossAmt}</grossAmt><CASH>{$cash}</CASH><CHEQUE>{$cheque}</CHEQUE><CCARD>{$ccard}</CCARD><EMONEY>{$emoney}</EMONEY><INVOICE>{$invoice}</INVOICE><DateTime>{$dateTime}</DateTime></data>@{$username}@{$password}";
$signature=strtoupper(sha1($key));
//echo $signature;

$xml1 = "<TransData><Command_Code>{$commandCode}</Command_Code><Command_Descr>{$commandDescr}</Command_Descr><data><ITEMS><ITEM><ID>{$ID}</ID><DESC>{$DESC}</DESC><QTY>{$QTY}</QTY><TAXCODE>{$TAXCODE}</TAXCODE><PRICE>{$PRICE}</PRICE><AMT>{$AMT}</AMT></ITEM></ITEMS><Serial_num>{$serialNum}</Serial_num><TIN_num>{$tinNum}</TIN_num><DocTin>{$docTin}</DocTin><cusname>{$cusName}</cusname><custMobile>{$cusMobile}</custMobile><custTIN>{$custTIN}</custTIN><custVRN>{$custVRN}</custVRN><permitNum>{$permitNum}</permitNum><vatAmt>{$vatAmt}</vatAmt><grossAmt>{$grossAmt}</grossAmt><CASH>{$cash}</CASH><CHEQUE>{$cheque}</CHEQUE><CCARD>{$ccard}</CCARD><EMONEY>{$emoney}</EMONEY><INVOICE>{$invoice}</INVOICE><DateTime>{$dateTime}</DateTime></data><Auth><username>{$username}</username><password>{$password}</password><licence>{$licence}</licence><signature>{$signature}</signature></Auth></TransData>";
// return $xml->asXML();//return $finalxml;

//$db_id=session()->get('db_id');

//file_put_contents('TRA/Request/req'.$db_id.'_'.$trans_no.'.xml', $xml1);
// return $xml1;
$url = $setting[0]->request_url;
//return $url;
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSLVERSION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $xml1);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "Content-type: application/xml",
                ));
               $response = curl_exec($ch);
             //  return 'Response is '.$response;
if ($response === false) {
    $err = curl_error($ch);
   return "cURL Error: $err";
}
if($response==''){
  return 'empty set';
}
curl_close($ch);
 file_put_contents('TRA/feedback.txt', $response);


 $check_rcpt=$payment_model->get_item_name('vfd_receipts_details_tbl', $where = array('submission_status' => 0,'receipt_number'=>$trans_no),$db);
  $xmlResponse = new \SimpleXMLElement($response);

    

  if((string)$xmlResponse->Command_Code=='502'){
    file_put_contents('TRA/Request/receipt'.$db_id.'_'.$trans_no.'.xml', $response);
    
      $verify_link =  (string)$xmlResponse->data->verificationLink;
        $filename = 'qrcode'.$db_id.'_'.$trans_no.'.png';
        $path = ROOTPATH . 'public/qrcodes/';

        // Generate QR Code
        $filePath = generate_qr_code($verify_link, $filename, $path);
        if($filePath) {

         }else{
         $filePath=0;
         }
  $data=array(
      'QR_code'=> (string)$xmlResponse->data->rcptcode,
      'receipt_number'=>$trans_no,
      'status_message'=> (string)$xmlResponse->Command_Descr,
      'DC'=> (string)$xmlResponse->data->dc,
      'GC'=> (string)$xmlResponse->data->gc,
      'QRCODE_PATH'=>$filePath,
      'QRCODE_NAME'=>$filename,
      'created_by'=>9,
      'submission_status'=>1,
      'date_created'=>date('Y-m-d H:i:s'),
      'verify_link'=> (string)$xmlResponse->data->verificationLink
  );
  //print_r($data);
  if(count($check_rcpt)>0){
   $payment_model->update_table_details('vfd_receipts_details_tbl',$where = array('id' => $check_rcpt[0]->id),$data,$db);
  }else{
    $payment_model->SaveData('vfd_receipts_details_tbl',$data,$db); 
  }
 return json_encode(array('status' => 'success','description' => 'Created Successfully'));
}else if((string)$xmlResponse->Command_Code=='59'){
    //duplicate receipt
     $res = file_get_contents('TRA/Request/receipt'.$db_id.'_'.$trans_no.'.xml');
     $xmlResponse = new \SimpleXMLElement($res);
     if($xmlResponse){
         $verify_link =  (string)$xmlResponse->data->verificationLink;
        $filename = 'qrcode'.$db_id.'_'.$trans_no.'.png';
        $path = ROOTPATH . 'public/qrcodes/';

        // Generate QR Code
        $filePath = generate_qr_code($verify_link, $filename, $path);
        if($filePath) {

         }else{
         $filePath=0;
         }
  $data=array(
      'QR_code'=> (string)$xmlResponse->data->rcptcode,
      'receipt_number'=>$trans_no,
      'status_message'=> (string)$xmlResponse->Command_Descr,
      'DC'=> (string)$xmlResponse->data->dc,
      'GC'=> (string)$xmlResponse->data->gc,
      'QRCODE_PATH'=>$filePath,
      'QRCODE_NAME'=>$filename,
      'created_by'=>9,
      'submission_status'=>1,
      'date_created'=>date('Y-m-d H:i:s'),
      'verify_link'=> (string)$xmlResponse->data->verificationLink
  );
//  print_r($data);
  if(count($check_rcpt)>0){
   $payment_model->update_table_details('vfd_receipts_details_tbl',$where = array('id' => $check_rcpt[0]->id),$data,$db);
  }else{
    $payment_model->SaveData('vfd_receipts_details_tbl',$data,$db); 
  } 
     }
return json_encode(array('status' => 'success','description' => 'Created Successfully'));
}
else{
    
       $verify_link =  "https://verify.tra.go.tz/15AEB001";
        $filename = 'qrcode'.$db_id.'_'.$trans_no.'.png';
        $path = ROOTPATH . 'public/qrcodes/';
        $filePath = generate_qr_code($verify_link, $filename, $path);
        if($filePath) {

         }else{
         $filePath=0;
         }

      $data=array(
      'QR_code '=>0,
      'receipt_number'=>$trans_no,
      'status_message'=>$xmlResponse->Command_Descr,
      'DC'=>0,
      'GC'=>0,
       'QRCODE_PATH'=>$filePath,
      'QRCODE_NAME'=>$filename,
      'created_by'=>9,
      'submission_status'=>0,
      'date_created'=>date('Y-m-d H:i:s'),
      'verify_link'=>0
  );
 if(count($check_rcpt)>0){
   $payment_model->update_table_details('vfd_receipts_details_tbl',$where = array('id' => $check_rcpt[0]->id),$data,$db);
  }else{
    $payment_model->SaveData('vfd_receipts_details_tbl',$data,$db); 
  } 
  return json_encode(array('status' => 'error','description' => (string)$xmlResponse->Command_Descr));
 //return $xmlResponse->Command_Descr;
}
           
 // 
    }
    }


?>