 <?php
use App\Models\PaymentsModel;
use App\Models\AdmissionModel;
use App\Models\BillModel;
use App\Models\ItemsModel;

function bank_cash($startingdate, $endingdate){
	
	 $pmodel = new PaymentsModel;
	 $amodel = new AdmissionModel;
	 $billmodel = new BillModel;
	 $imodel = new ItemsModel;

	  $enddate = strtotime($endingdate);
       $sdate = strtotime($startingdate);

	$bank = $amodel->get_student_details('accounts_tbl', $where = array('account_type_id' => 9));
       
       $data_list=array();
         $tbalance=0;
            $tbf=0;
            $tendbal=0;
            $tin=0;
            $tout=0;
            $treconciled=0;
	if(count($bank)>0){
		foreach($bank as $acc){

             //calculating balance before the date----
            $s='01-01-2020';
            $end = strtotime('-1 day',strtotime($startingdate));
            $std = strtotime($s);
             
            // echo date('Y-m-d',$end);
            $before = $imodel->getSingle_view3($acc->id,date('Y-m-d', $std),date('Y-m-d', $end));
            //print_r($before);
            $balanceb=0;
            foreach($before as $bf){

                //check aproval status
                if($bf->trans_type==4 || $bf->trans_type==5){
                $approval_status1 = $amodel->get_student_details('approval_numbers', $where = array('trans_no' =>  $bf->trans_no,'trans_type'=>$bf->trans_type));
                 if(count($approval_status1)==0){
                 continue;
                }
          
                  $approval_status = $amodel->get_student_details('approval_history', $where = array('app_no' =>  $approval_status1[0]->app_id,'hstatus'=>1));
                if(count($approval_status)==0){
                 continue;
                }
              }

              if($bf->ledger_id==10 && $bf->trans_type==3){
                $check_status = $amodel->get_student_details('transaction_numbers_tbl', $where = array('status' => 1,'trans_type_id'=>$bf->trans_type,'trans_number'=>$bf->trans_no,'trans_desc !='=>""));
                if(count($check_status)==0){
                  continue;
                }
               }else if($bf->ledger_id==10 && $bf->trans_type!=3 && $bf->transation_nature==1){
                continue;
               }
         //end check aproval status
              if($bf->transation_nature==2){
                $balanceb=$balanceb+$bf->amount;
              }else{
              //  echo $balanceb;
               $balanceb=$balanceb-$bf->amount;
              }
             }
           //-------end calculation----------

            $ttl1=0; 
             $ttl2=0;
            $balance=0; 
              $data = $imodel->getSingle_view3($acc->id,date('Y-m-d H:i', $sdate),date('Y-m-d H:i', $enddate));
               foreach($data as $ledge){

                //check aproval status
                if($ledge->trans_type==4 || $ledge->trans_type==5){
                $approval_status1 = $amodel->get_student_details('approval_numbers', $where = array('trans_no' =>  $ledge->trans_no,'trans_type'=>$ledge->trans_type));
                 if(count($approval_status1)==0){
                 continue;
                }
          
                  $approval_status = $amodel->get_student_details('approval_history', $where = array('app_no' =>  $approval_status1[0]->app_id,'hstatus'=>1));
                if(count($approval_status)==0){
                 continue;
                }
              }

              if($ledge->ledger_id==10 && $ledge->trans_type==3){
                $check_status = $amodel->get_student_details('transaction_numbers_tbl', $where = array('status' => 1,'trans_type_id'=>$ledge->trans_type,'trans_number'=>$ledge->trans_no,'trans_desc !='=>""));
                if(count($check_status)==0){
                  continue;
                }
               }else if($ledge->ledger_id==10 && $ledge->trans_type!=3 && $ledge->transation_nature==1){
                continue;
               }
         //end check aproval status

              if(($ledge->transation_nature==2 && $ledge->ledger_id!=21) || ($ledge->ledger_id==21 && $ledge->transation_nature==2 && $ledge->trans_item ==0)){

                                if($ledge->ledger_id==22){
                               $ttl2=$ttl2+$ledge->balance;
                                $balance=$balance+$ledge->balance;
                                // echo number_format($ledge->balance);
                                }else{
                               $ttl2=$ttl2+$ledge->amount;
                                $balance=$balance+$ledge->amount;
                                // echo number_format($ledge->amount);
                                }
                                
                              }else{ 
                               // echo 0;
                            }

                            if(($ledge->transation_nature==1 && $ledge->ledger_id!=21) || ($ledge->ledger_id==21 && $ledge->transation_nature==1 && $ledge->trans_item>0)){

                              if($ledge->ledger_id==22){
                              $ttl1=$ttl1+$ledge->balance;
                                $balance=$balance-$ledge->balance;
                               // echo number_format($ledge->balance);
                              }else{
                              $ttl1=$ttl1+$ledge->amount;
                                $balance=$balance-$ledge->amount;
                               // echo number_format($ledge->amount);
                              }
                               
                              }else{ 
                               // echo 0;
                            }
                        }
                        $tin=$tin+$ttl2;
                        $tout=$tout+$ttl1;
                        $tbalance=$tbalance+$balance;
                        $tbf=$tbf+$balanceb;

                         $list=array(
                            'account_name'=>$acc->account_name,
                            'balbf'=>$balanceb,
                            'amount_in'=>$ttl2,
                            'amount_out'=>$ttl1,
                            'c_balance'=>$balance +$balanceb,
                         );
                        $data_list[]=$list;

		}

	}

	return $data_list;
}