<?php

use App\Models\StudentModel;


function getClass($invoice,$name_type_id,$trno){

 $smodel = new StudentModel();

$class_name="";

if($name_type_id==4){
    $name_id = $smodel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $trno,'trans_type' => 2));
     if(count($name_id)>0){
    $adm = $smodel->gettable_data('students_application_tbl',$where = array('id' => $name_id[0]->name_id,));
     if(count($adm)>0){
  $cls = $smodel->gettable_data('classes_tbl',$where = array('id' => $adm[0]->{'class'}));
  if(count($cls)>0){
   //$str = $smodel->gettable_data('streams_tbl',$where = array('id' => $adm[0]->stream_id));
  $class_name=$cls[0]->class_name.'(A)';	
  }
  }
     }
}else{
    $name_id = $smodel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $invoice,'trans_type' => 1));
  $date = $smodel->gettable_data('transaction_numbers_tbl',$where = array('trans_number' => $invoice,'trans_type_id' => 1));
  $year=date('Y',strtotime($date[0]->trans_date));
  
  if(count($name_id)>0){
  $adm = $smodel->gettable_data('admission_tbl',$where = array('student_id' => $name_id[0]->name_id,'academic_year' => $year));
  if(count($adm)>0){
  $cls = $smodel->gettable_data('classes_tbl',$where = array('id' => $adm[0]->class_id));
  if(count($cls)>0){
   $str = $smodel->gettable_data('streams_tbl',$where = array('id' => $adm[0]->stream_id));
  $class_name=$cls[0]->class_name.'('.$str[0]->stream_name.')';	
  }
  }
   }
}
  
   
  return $class_name;

	}