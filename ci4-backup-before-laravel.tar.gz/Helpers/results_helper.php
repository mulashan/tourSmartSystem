<?php 
use App\Models\ReportsModel;
use App\Models\BillingModel;
use App\Models\AdmissionModel;
use App\Models\StudentModel;
use App\Models\ClassesModel;
use App\Models\PaymentsModel;
use App\Models\AcademicOutputsModel;
use App\Models\AcademicInputsModel;
use App\Models\AcademicModel;

    
function getGradeFromAvg($avg, $boundaries) {   
    foreach ($boundaries as $b) {
        if ($avg >= $b->lower_performance && $avg <= $b->upper_performance) {
            return $b->grade_name;
        }
    }
    return '-';
}

function getDivisionFromAvg($avg, $boundaries) {
    if ($avg >= 75) return 'I';
    elseif ($avg >= 60) return 'II';
    elseif ($avg >= 45) return 'III';
    elseif ($avg >= 30) return 'IV';
    else return 'F';
}

function getDivisionAndPoints($subjectGrades, $gradesTable) {
    $totalPoints = 0;
    $validSubjects = 0;
    foreach ($subjectGrades as $grade) {
        foreach ($gradesTable as $row) {
            if (strtoupper($row->grade_name) === strtoupper($grade)) {
                $totalPoints += (int)$row->division_point;
                $validSubjects++;
                break;
            }
        }
    }
    if ($validSubjects === 0) {
        return ['division' => 'Null', 'points' => 'Null'];
    }
    if ($totalPoints >= 7 && $totalPoints <= 17) {
        $division = 'I';
    } elseif ($totalPoints <= 21) {
        $division = 'II';
    } elseif ($totalPoints <= 25) {
        $division = 'III';
    } elseif ($totalPoints <= 30) {
        $division = 'IV';
    } else {
        $division = '0';
    }

    return ['division' => $division, 'points' => $totalPoints];
}

if (!function_exists('getSubjectPoint')) {
    function getSubjectPoint($marks, $gradeBoundaries)
    {
        foreach ($gradeBoundaries as $boundary) {
            if ($marks >= $boundary->lower_performance && $marks <= $boundary->upper_performance) {
                return $boundary->division_point;
            }
        }
        return 0;
    }
}

if (!function_exists('getGradeFromAverage')) {
    function getGradeFromAverage($average, $gradeBoundaries)
    {
        foreach ($gradeBoundaries as $boundary) {
            if ($average >= $boundary->lower_performance && $average <= $boundary->upper_performance) {
                return $boundary->grade_name;
            }
        }
        return 'F';
    }
}

if (!function_exists('calculateBest7Points')) {
    function calculateBest7Points(array $points)
    {
        rsort($points);
        $best7 = array_slice($points, 0, 7);
        return array_sum($best7);
    }
}


if (!function_exists('calculateALevelPoints')) {
    function calculateALevelPoints(array $subjects, array $results, $gradeBoundaries)
    {
        $points = 0;

        foreach ($subjects as $subject) {
            if (!isset($subject['selection']) || (int)$subject['selection'] !== 1) {
                continue;
            }

            $totalmarks=0;
            $avgmarks=0;
            foreach ($results as $r) {
                if ((int)$r['subject_id'] === (int)$subject['subject_id']) {
                    $marks=$r['marks'];
                    foreach($marks as $mk){
                   $totalmarks+=$mk;
                    }
                    $avgmarks=$totalmarks/count($marks);
                    if (isset($r['marks']) || is_numeric($r['marks'])) {
                        $points += getSubjectPoint($avgmarks, $gradeBoundaries);
                    }
                    break;
                }
            }
        }

        return $points;
    }
}


if (!function_exists('getDivisionFromPoints')) {
    function getDivisionFromPoints(int $points, int $government_level_id)
    {
       if ($government_level_id == 3) {
    if ($points >= 7 && $points <= 17) return 'I';
    elseif ($points >= 18 && $points <= 21) return 'II';
    elseif ($points >= 22 && $points <= 25) return 'III';
    elseif ($points >= 26 && $points <= 30) return 'IV';
    elseif ($points == 0) return 'ABS';
    else return '0';
}

        if ($government_level_id == 4) {
            if ($points >= 3 && $points <= 9) return 'I';
            elseif ($points >= 10 && $points <= 12) return 'II';
            elseif ($points >= 13 && $points <= 17) return 'III';
            elseif ($points >= 18 && $points <= 19) return 'IV';
            elseif ($points == 0) return 'ABS';
            else return '0';
        }

        return '-';
    }
}
function calculateAverageALevelPoints($coreSubjects, $subjectAverages, $gradeBoundaries)
{
    $totalPoints = 0;
    foreach ($coreSubjects as $subject) {
        $subject_id = $subject->subject_id;
        if (isset($subjectAverages[$subject_id])) {
            $avg = $subjectAverages[$subject_id];
            foreach ($gradeBoundaries as $boundary) {
                if ($avg >= $boundary->lower_performance && $avg <= $boundary->upper_performance) {
                    $totalPoints += $boundary->division_point;
                    break;
                }
            }
        }
    }
    return $totalPoints;
}

function getStudentNameById($studentId, $students) {
    foreach ($students as $s) {
        if ($s->id == $studentId) {
            return $s->full_name;
        }
    }
    return 'Unknown';
}

function getStudentGenderById($studentId, $students) {
    foreach ($students as $s) {
        if ($s->id == $studentId) {
            return $s->gender;
        }
    }
    return 'Unknown';
}

function calculate_paye($taxable_income, $brackets)
{
    foreach ($brackets as $bracket) {
        if ($taxable_income >= $bracket->from_amount && $taxable_income <= $bracket->to_amount) {
            $excess = $taxable_income - $bracket->excess_above;
            return $bracket->base_tax + ($excess * ($bracket->tax_rate / 100));
        }
    }
    return 0;
}

function num_format($number) {
    $number = (string)$number;
    if (strpos($number, '.') !== false) {
        list($intPart, $decPart) = explode('.', $number, 2);
        $decPart = rtrim($decPart, '1');
        return number_format($intPart) . '.' . ($decPart === '' ? '00' : $decPart);
    } else {
        return number_format($number) . '.00';
    }}

if (!function_exists('format_number_with_decimals')) {
    function format_number_with_decimals($number, $decimals = 2) {
        return number_format((float)$number, $decimals, '.', ',');
    }
}


?>