<?php
use App\Models\ReportsModel;
use App\Models\BillingModel;
use App\Models\AdmissionModel;
use App\Models\StudentModel;
use App\Models\ClassesModel;
use App\Models\PaymentsModel;

function get_calc($student_id,$sdate,$enddate){
// $amodel = new AdmissionModel();
 $smodel = new StudentModel();
 // $bmodel = new BillingModel();
 //  $report = new ReportsModel();
  
  $s='01-01-2020';
  $enddate = strtotime('-1 day',$sdate);
  $sdate = strtotime($s);
$balance=0;
$info = $smodel->stu_transaction($student_id,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));

  if (count($info) > 0)
   {
            $sn = 0;
            $ttl1=0; 
            $ttl2=0;
            
            
            $disc="";

            foreach ($info as $fo) {
              $abalance=0;
                $credit=0;
                $debit=0;
                $sn++;
                $i=1;
                $trno=$fo->trans_no;
                $account="";

                 if($fo->trans_type==1){
                    $abalance=0;
                $in = $smodel->get_transaction($fo->trans_no,2,$student_id,1);
                // print_r($in);
                 $inv_name=$smodel->get_invoicetype($in[0]->invoice_type_id);
               $disc=$inv_name[0]->type_name;
                $ttl2=$ttl2+$in[0]->amount;
                    $debit=$in[0]->amount;
                    //echo $debit;
                    $balance=$balance+$in[0]->amount;
                    $thedate=$in[0]->trans_date;
                    //echo $thedate;
                     $trno=$fo->trans_no;
                 }elseif($fo->trans_type==2){
                    //echo $fo->trans_no.'/';
                    $in = $smodel->get_transaction2($fo->trans_no,2,$student_id,2); 
                    //print_r($in);
                        if(count($in)>0){
                            $abalance=0;
                            //$inv_name=$smodel->get_invoicetype($in[0]->invoice_type_id);
                            $i=0;
                            $over=0;
                                 foreach($in as $v){
                                    $charges=0;
                                   // echo $v->amount.'</br>';
                                $charged = $smodel->gettable_data('ledger_transaction_tbl',$where = array('trans_no' => $v->trans_no,'transation_nature' => 1,'trans_type' => 2,'ledger_id'=>22));
                                       //reduce charges
                                    if(count($charged)>0){
                                        $charges=$charged[0]->amount;
                                    }

                                    if($v->ledger_type==7){
                                        continue;
                                        $over+=$v->amount;
                                     $ttl1=$ttl1;
                                     $credit=$credit;
                                     $balance=$balance;
                                    }else{
                                       $ttl1=$ttl1+$v->amount-$charges;
                                     $credit+=$v->amount-$charges;
                                      $balance=$balance-$v->amount+$charges;  
                                    }
                                    
                     $inv_name=$smodel->get_invoicetype($v->invoice_type_id);
                  
                      // echo $i;
                     //echo "<br>";
                     if($i==0){
                           $disc1=$inv_name[0]->type_name;
                     $disc=$disc1;
                        
                     }else{
                        $disc2=$inv_name[0]->type_name;
                      $disc=$disc1.' and '.$disc2;
                  // echo $disc;  
                     }
                  
                     $i++;
                }
                           
                        
                    //echo $credit;
                    $thedate=$in[0]->trans_date;
                    //echo $thedate;
                   $account='';
                    $trno=$fo->trans_no;
                    $acc_name=$smodel->get_account_name($trno,2);
                    //print_r($acc_name);
                    if(count($acc_name)>0){
                    $account=$acc_name[0]->account_name;
                       }
                    //echo $balance;
                 }else{
                 $ina = $smodel->get_applicationid($student_id); 
                     if(count($ina)>0){ 
                    $in = $smodel->get_transactionapp($ina[0]->id,date('Y-m-d H:i', $sdate), date('Y-m-d H:i', $enddate));
                  // print_r($in);
                   if(count($in)>0){ 
                    $disc="Application";
                        $ttl1=$ttl1+$in[0]->amount;
                    $credit=$in[0]->amount;
                   // echo $credit;
                    $abalance=$abalance+$in[0]->amount;
                    $thedate=$in[0]->trans_date;
                    $trno=$in[0]->trans_no;
                      $acc_name=$smodel->get_account_name($trno,2);
                      //print_r($acc_name);
                       $account=$acc_name[0]->account_name;
                   // echo $abalance;
                }else{
                    continue;
                }
                     }else{
                          continue;
                     }
                 }
                 }
                 elseif($fo->trans_type==3){
                       $abalance=0;
                $in = $smodel->get_transaction($fo->trans_no,1,$student_id,3);
                //print_r($in[0]->invoice_type_id);
                 $inv_name=$smodel->get_invoicetype($in[0]->invoice_type_id);
               $disc=$inv_name[0]->type_name;
                  $ttl1=$ttl1+$in[0]->amount;
                    $credit=$in[0]->amount;
                    //echo $debit;
                    $abalance=$abalance+$in[0]->amount;
                    $thedate=$in[0]->trans_date;
                    //echo $thedate;
                     $trno=$fo->trans_no;
                      $acc_name=$smodel->get_account_name($trno,3);
                      //print_r($acc_name);
                       $account=$acc_name[0]->account_name;
                 }
                 elseif($fo->trans_type==6){
                       //$abalance=0;
                $in = $smodel->get_transaction($fo->trans_no,1,$student_id,6);
                //print_r($in[0]->invoice_type_id);
                 $inv_name=$smodel->get_invoicetype($in[0]->invoice_type_id);
               $disc=$inv_name[0]->type_name;
                  $ttl1=$ttl1+$in[0]->amount;
                    $credit=$in[0]->amount;
                    //echo $debit;
                    //$abalance=$abalance+$in[0]->amount;
                    $balance=$balance-$in[0]->amount;
                    $thedate=$in[0]->trans_date;
                    //echo $thedate;
                     $trno=$fo->trans_no;
                      $acc_name=$smodel->get_account_name($trno,6);
                      //print_r($acc_name);
                       $account=$acc_name[0]->account_name;
                 }elseif($fo->trans_type==7){
                    $reversed = $smodel->gettable_data('receipt_transfer_tbl',$where = array('reversal_number' => $fo->trans_no));
                     $debit= $reversed[0]->amount_transfered;
                     $thedate=$reversed[0]->date_created;
                     $account="";
                     $disc=$reversed[0]->reasons;
                      $balance=$balance+$debit;
                      $trno=$fo->trans_no;
                    $ttl2=$ttl2+$debit;
                 }

           }

           
 }
      $bdata=[
            "balance" => $balance,
            
             ];
             return $bdata;


  }
  
  function capture_name($name_id, $name_type_id,$trans_type,$trans_no){
      $bmodel = new BillingModel();

        ////////////////////////////////////////////////////////////
           if($name_type_id == 4){
            $app = $bmodel->get_item_name('students_application_tbl',$where = array('id'=>$name_id));
            $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
            $student_id = $app[0]->id;
          }
        else if($name_type_id == 3){
             $app = $bmodel->get_item_name('parents_tbl',$where = array('id'=>$name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }else if($name_type_id == 1){
             $app = $bmodel->get_item_name('students',$where = array('id'=>$name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }elseif($name_type_id==2){
         $app = $bmodel->get_item_name('supplier_tbl', $where = array('supplier_id' => $name_id));
         $student_name=$app[0]->supplier_name??"";
             }
        else if($name_type_id == 6){
             $app = $bmodel->get_item_name('other_students_tbl',$where = array('id'=>$name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->middle_name.' '.$app[0]->last_name; 
             $student_id = $app[0]->id;
            
        }else if($name_type_id == 7){
             $app = $bmodel->get_item_name('users',$where = array('user_id'=>$name_id));
             $student_name = $app[0]->first_name.' '.$app[0]->last_name; 
            
            
        }
        elseif($name_type_id==5){
                             
       $pad = $bmodel->get_item_name('ledger_transaction_tbl', $where = array('trans_no' => $trans_no,'trans_type' => $trans_type,'name_type_id' => 1));
      
       if(count($pad)>0){
       $std =$bmodel->get_item_name('students', $where = array('id' => $pad[0]->name_id));
     
      $student_name=$std[0]->full_name??"";
    }else{
      //$fullname="";
       $std = $bmodel->get_item_name('students_application_tbl', $where = array('id' => $name_id));
     $student_name=$std[0]->full_name??"";
      }
    }else{
        $student_name="";
    }
    
    return $student_name;
         //////////////////////////////////////////////////////////// 
  }

?>