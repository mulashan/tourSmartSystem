<?php 
use App\Models\ReportsModel;
use App\Models\BillingModel;
use App\Models\AdmissionModel;
use App\Models\StudentModel;
use App\Models\ClassesModel;
use App\Models\PaymentsModel;


function __construct(){

}
       function findAge($date){

        $bday = new DateTime($date); 
        $today = new Datetime(date('Y/m/d'));
        $diff = $today->diff($bday);
        $age=0;
        if($diff->y >0){
           
            $age = $diff->y.' Yrs';
        }
        return $age;
    }


function getStatus($id){
    helper('calc_helper');
$amodel = new AdmissionModel();
 $smodel = new StudentModel();
 $bmodel = new BillingModel();
  $report = new ReportsModel();

  $dbname=session()->get('db_name');
 $db = \Config\Database::connect($dbname);
  
       $admn = $bmodel->get_item_name('admission_tbl', $where = array('id'=>$id));
       $results=findCalc($admn[0]->student_id,$db,$admn[0]->academic_year);
       if($results==0){
           return 1;
       }
       
    $classlevel=$admn[0]->level_id;
    $year=$admn[0]->academic_year;
    $lvtbl = $bmodel->get_item_name('class_level_tbl', $where = array('id' => $classlevel));
         $installments = $bmodel->get_item_name('school_terms_tbl',$where=array('academic_year'=>$year,'type_id'=>$lvtbl[0]->academic_type));
       ////////////////////////////////////////////////////////
          $i=0;
                     $tments=0;
                     $tpaid=0;
                      $paid_amount=0;
                    foreach ($installments as $r) {
                       
                     $i++;
                    
                     if($i==1){

                        $openingbalance=$results[0]['openingbalance'];
                       $ment=$results[0]['ment'];
                        $mbalance=$results[0]['mbalance'];
                        $paid_amount=$results[0]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[0]['today']==1){
                       $todaybalance=$results[0]['todaybalance'];
                       return $todaybalance; 
                     }
                  
                     }
                      if($i==2){
         
                        $ment=$results[1]['ment'];
                        $mbalance=$results[1]['mbalance'];
                        $paid_amount=$results[1]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[1]['today']==1){
                       $todaybalance=$results[1]['todaybalance']; 
                       return $todaybalance; 
                     } 
                     }
                   if($i==3){
                       $ment=$results[2]['ment'];
                        $mbalance=$results[2]['mbalance'];
                        $paid_amount=$results[2]['paid_amount'];
                         $tments=$tments+$ment;
                     $tpaid= $tpaid+$paid_amount;
                     if($results[2]['today']==1){
                       $todaybalance=$results[2]['todaybalance']; 
                       return $todaybalance; 
                     }
                     }
                     
                     
                      } 
       //////////////////////////////////////////////////////////
       return 1;


          
    }

// function sanitize_phone($phone) {
//     $phone = preg_replace('/\D+/', '', $phone);
//     if (substr($phone, 0, 1) == '0') {
//         $phone = '255' . substr($phone, 1);
//     }
//     if (strlen($phone) == 12 && substr($phone, 0, 3) == '255') {
//         return $phone;
//     }
//     return false;
// }

function sanitize_phone($phone)
{    $phone = preg_replace('/\D+/', '', $phone);
    if (substr($phone, 0, 5) === '00255') {
        $phone = substr($phone, 2);
    }
    if (substr($phone, 0, 1) === '0' && strlen($phone) === 10) {
        $phone = '255' . substr($phone, 1);
    }
    if (substr($phone, 0, 3) === '255' && strlen($phone) === 12) {
        return $phone;
    }
    return false;
}

?>