<?php

namespace App\Models;

use CodeIgniter\Model;

class StaffModel extends Model
{
    
public $db;
    public function __construct(){
         $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    }

  function get_staff(){
    $query = $this->db->table('users_type_tbl');
      $query->select('*');
      
     $result= $query->get()->getResult();
      return $result; 
  }
       public function get_total_staffs($tbl,$condition)
   {
      $builder = $this->db->table($tbl);
      $builder->where($condition);
      return $builder->get()->getResult();

   }

 public function staff_report($status,$staff,$dep,$job,$db_id){
     $query = $this->db->table('users');
      $query->select('users.*,staff_details_tbl.*,users_type_tbl.type_name,staff_status.*'); 
       $query->join('users_type_tbl', 'users_type_tbl.id = users.user_type');
         $query->join('staff_details_tbl', 'staff_details_tbl.user_id = users.user_id');  
         $query->join('staff_status', 'staff_status.status_id = staff_details_tbl.status');
       if($staff > 0 && $dep >0 && $job>0){


      $query->where('user_type',$staff);
      $query->where('staff_details_tbl.dep_id',$dep);
      $query->where('staff_details_tbl.job_id',$job);

    }else if($staff > 0 && $dep >0 && $job==0){

   //  $query->join('staff_details_tbl', 'staff_details_tbl.user_id = users.user_id');
      $query->where('user_type',$staff);
      $query->where('staff_details_tbl.dep_id',$dep);
     

    }else if($staff > 0 && $dep ==0 && $job==0){

      $query->where('user_type',$staff);
    
    }else if($staff > 0 && $dep ==0 && $job >0){

  //   $query->join('staff_details_tbl', 'staff_details_tbl.user_id = users.user_id');
      $query->where('user_type',$staff);
      $query->where('staff_details_tbl.job_id',$job);
      
    }else if($staff == 0 && $dep >0 && $job >0){

    // $query->join('staff_details_tbl', 'staff_details_tbl.user_id = users.user_id');
        $query->where('staff_details_tbl.dep_id',$dep);
      $query->where('staff_details_tbl.job_id',$job);
      
    }else if($staff == 0 && $dep ==0 && $job >0){

   //  $query->join('staff_details_tbl', 'staff_details_tbl.user_id = users.user_id');
      $query->where('staff_details_tbl.job_id',$job);
      
    }else if($staff == 0 && $dep >0 && $job ==0){

     //$query->join('staff_details_tbl', 'staff_details_tbl.user_id = users.user_id');
        $query->where('staff_details_tbl.dep_id',$dep);
      
    }
      if(!$status==0){
       $query->where('staff_details_tbl.status',$status);
      }
       $query->where('database_id',$db_id);
       $query->where('staff',1);
       $result= $query->get()->getResult();
      return $result; 
  }


  function staff_name($staff){
    $query = $this->db->table('users_type_tbl');
      $query->select('*');
      $query->where('id',$staff);
     $result= $query->get()->getResult();
      return $result; 
  }
  public function get_total_user($tbl,$count,$condition)
   {
      $builder = $this->db->table($tbl);
      $builder->selectCount($count);
      $builder->where($condition);

      return $builder->get()->getResult();

   }
   
   public function get_total_application($tbl,$count,$condition,$year)
   {
      $builder = $this->db->table($tbl);
      $builder->selectCount($count);
      $builder->where($condition);
      $builder->like($tbl.'.date_created',$year,'after');
      return $builder->get()->getResult();

   }
   

   public function get_total_students()
   {
    $builder = $this->db->table('students');
    $builder->selectCount('id');
    $builder->where('status != 3');
    return  $builder->get()->getResult();
   }
     public function get_vehicle($tbl,$condition)
   {
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);

      return $builder->get()->getResult();

   }
   
   public function application_students($tbl,$year)
   {
      $builder = $this->db->table($tbl);
      $builder->select('*');
     $builder->like($tbl.'.date_created',$year,'after');
     $builder->groupBy('id');
      return $builder->get()->getResult();

   }

   function get_distinct_religion(){
    $builder = $this->db->table('students');
      $builder->select('religion');
      $builder->groupBy('religion');
      return $builder->get()->getResult();
   }

   function get_total_religion($religion,$year){
     $builder = $this->db->table('admission_tbl');
     $builder->select('*');
     $builder->join('students','students.id=admission_tbl.student_id');
      $builder->where('academic_year',$year);
      $builder->where('religion',$religion);
     return $builder->get()->getResult();
   }

   function get_distinct_nationality(){
    $builder = $this->db->table('students');
      $builder->select('nationality');
      $builder->groupBy('nationality');
      return $builder->get()->getResult();
   }
   function get_total_nationality($nat,$year){
     $builder = $this->db->table('admission_tbl');
     $builder->select('*');
     $builder->join('students','students.id=admission_tbl.student_id');
      $builder->where('academic_year',$year);
      $builder->where('nationality',$nat);
     return $builder->get()->getResult();
   }

   function gettable_data_groupby($tbl,$condition){
    $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
      $builder->groupBy('adm_id');
      return $builder->get()->getResult();
   }
   
public function GetStaffsByJob($id){
    $builder = $this->db->table('staff_details_tbl');
     $builder->select('users.first_name, users.last_name,users.user_photo,departments_tbl.dep_name,users.birth_date,users.gender,staff_details_tbl.contract_expiry_date,users_type_tbl.type_name,users.phone_no,users.email,users.status,users.physical_adress');
     $builder->join('users','users.user_id=staff_details_tbl.user_id');
     $builder->join('job_tittle_tbl','job_tittle_tbl.id=staff_details_tbl.job_id');
     $builder->join('departments_tbl','departments_tbl.id=staff_details_tbl.dep_id');
     $builder->join('users_type_tbl','users_type_tbl.id=users.user_type');
      $builder->where('staff_details_tbl.job_id',$id);
     return $builder->get()->getResult();
}public function GetStaffsByDepartment($id){
    $builder = $this->db->table('staff_details_tbl');
     $builder->select('users.first_name, users.last_name,users.user_photo,job_tittle_tbl.job_tittle,users.birth_date,users.gender,staff_details_tbl.contract_expiry_date,users_type_tbl.type_name,users.phone_no,users.email,users.status,users.physical_adress');
     $builder->join('users','users.user_id=staff_details_tbl.user_id');
     $builder->join('departments_tbl','departments_tbl.id=staff_details_tbl.dep_id');
     $builder->join('job_tittle_tbl','job_tittle_tbl.id=staff_details_tbl.job_id');
     $builder->join('users_type_tbl','users_type_tbl.id=users.user_type');
      $builder->where('staff_details_tbl.dep_id',$id);
     return $builder->get()->getResult();
}
public function GetAllPayroll(){
    $builder = $this->db->table('payrolls_tbl');
$builder->select('payrolls_tbl.payroll_id,payrolls_tbl.transaction_id,months.month,payrolls_tbl.payroll_year,payrolls_tbl.payroll_date,payrolls_tbl.payroll_date, users.first_name, users.last_name,payrolls_tbl.create_date, SUM(staff_payrolls_tbl.net_salary_balances) AS balance,SUM(staff_payrolls_tbl.basic_salary) AS basic_salary,SUM(staff_payrolls_tbl.allowances) AS allowances');

     $builder->join('users','users.user_id=payrolls_tbl.created_by');
     $builder->join('staff_payrolls_tbl','staff_payrolls_tbl.payroll_ids=payrolls_tbl.payroll_id');
     $builder->join('months','months.month_id=payrolls_tbl.payroll_month');
      //$builder->groupBy('staff_payrolls_tbl.payroll_ids');
      $builder->groupBy('payrolls_tbl.payroll_id');
     return $builder->get()->getResult();
}
public function GetAllStaffs(){
     $builder = $this->db->table('staff_details_tbl');
     $builder->select('users.status,users.first_name, users.last_name,departments_tbl.dep_name,job_tittle_tbl.job_tittle,staff_details_tbl.*,staff_status.*');
     $builder->join('users','users.user_id=staff_details_tbl.user_id');
     $builder->join('salary_advances_schedule_tbl','salary_advances_schedule_tbl.staff_id = staff_details_tbl.user_id','left');
     $builder->join('departments_tbl','departments_tbl.id=staff_details_tbl.dep_id');
      $builder->join('job_tittle_tbl','job_tittle_tbl.id=staff_details_tbl.job_id'); 
       $builder->join('staff_status', 'staff_status.status_id = staff_details_tbl.status');
         $builder->where('staff_details_tbl.status !=',4);
      $builder->groupBy('staff_details_tbl.id'); 
     return $builder->get()->getResult();
}
public function GetSalaryAdvances($year,$month){
     $builder = $this->db->table('salary_advances_schedule_tbl');
     $builder->select('salary_advances_schedule_tbl.advance_amount,salary_advances_schedule_tbl.staff_id,staff_details_tbl.user_id');
     $builder->join('staff_details_tbl','staff_details_tbl.user_id=salary_advances_schedule_tbl.staff_id');
    $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = salary_advances_schedule_tbl.transaction_id');
    $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = transaction_numbers_tbl.trans_type_id');
   $builder->join('approval_numbers','approval_numbers.trans_no = salary_advances_schedule_tbl.transaction_id AND transaction_numbers_tbl.trans_type_id = approval_numbers.trans_type');
   $builder->join('approval_history','approval_history.app_no = approval_numbers.app_id');
       $builder->where('salary_advances_schedule_tbl.payroll_month', $month);
       $builder->where('salary_advances_schedule_tbl.payroll_year', $year);  
           $builder->where('transaction_numbers_tbl.trans_type_id', 5);
   $builder->where('approval_history.hstatus', 1);  
     return $builder->get()->getResult();
}
public function get_current_tax_brackets($year)
{    return $this->db->table('tax_brackets')
                    ->where('year', $year)
                    ->orderBy('from_amount', 'ASC')
                    ->get()
                    ->getResult();
}
public function getLedgers()
{    return $this->db->table('accounts_tbl')
                   ->join('account_types_tbl','account_types_tbl.id=accounts_tbl.account_type_id')
        ->join('government_leger_tbl','government_leger_tbl.ledger_id=accounts_tbl.id', 'left')
      ->join('government_tbl','government_tbl.institution_id=government_leger_tbl.government_id', 'left')
                   ->select('accounts_tbl.account_name,accounts_tbl.id AS account_id,account_types_tbl.type_name,account_types_tbl.id AS typ_id,government_tbl.institution_id,government_tbl.institution_name')
                   ->where('accounts_tbl.tax_based',1)
                    ->orderBy('account_types_tbl.type_name', 'ASC')
                    ->get()
                    ->getResult();
}

public function register_payroll($data){
 $builder = $this->db->table('payrolls_tbl');
$builder->insert($data);
$inserted_id = $this->db->insertID();
return $inserted_id;
}


public function GetStaffPayments($staff, $year, $month)
{
    $builder = $this->db->table('payrolls_tbl');
    $builder->select('
        payrolls_tbl.payroll_year,
        payrolls_tbl.payroll_date,
        payrolls_tbl.payroll_id,
        staff_payrolls_tbl.staff_id,
        transaction_types_tbl.type_name,
        staff_payrolls_tbl.net_salary_balances,
        staff_payrolls_tbl.net_salaries,
        payroll_payments_relations_tbl.payroll_payment_id,
        SUM(payroll_payments_relations_tbl.amount_paid) AS paid_amount,
        months.month
    ');

    $builder->join('staff_payrolls_tbl', 'staff_payrolls_tbl.payroll_ids = payrolls_tbl.payroll_id AND staff_payrolls_tbl.staff_id = ' . $this->db->escape($staff), 'inner');
    
    $builder->join('payroll_payments_relations_tbl', 'payroll_payments_relations_tbl.payroll_id = payrolls_tbl.payroll_id AND payroll_payments_relations_tbl.staff_id = staff_payrolls_tbl.staff_id', 'left');

    $builder->join('months', 'months.month_id = payrolls_tbl.payroll_month', 'left');
    $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = payrolls_tbl.transaction_type_id', 'left');

    if ($month > 0) {
        $builder->where('payrolls_tbl.payroll_month', $month);
    }

    if ($year > 0) {
        $builder->where('payrolls_tbl.payroll_year', $year);
    }

    $builder->groupBy('payrolls_tbl.payroll_id');

    return $builder->get()->getResult();
}


public function GetPayments_details($staff,$payroll_id,$year, $month)
{
    $builder = $this->db->table('payroll_payments_relations_tbl');
    $builder->select('
        users.first_name, 
      users.last_name,
        payrolls_tbl.payroll_year,
        payrolls_tbl.payroll_date,
        payrolls_tbl.payroll_id,
        staff_payrolls_tbl.staff_id,
        transaction_types_tbl.type_name,
        staff_payrolls_tbl.net_salary_balances,
        staff_payrolls_tbl.net_salaries,
        transaction_numbers_tbl.trans_date,
        payroll_payments_relations_tbl.payroll_payment_id,
        payroll_payments_relations_tbl.amount_paid,
        approval_history.hstatus,
        voucher_types_tbl.voucher_type_name,
        months.month
    ');
    $builder->join('payrolls_tbl', 'payrolls_tbl.payroll_id = payroll_payments_relations_tbl.payroll_id');
    $builder->join('months', 'months.month_id = payrolls_tbl.payroll_month');
    $builder->join('staff_payrolls_tbl', 'staff_payrolls_tbl.payroll_ids = payrolls_tbl.payroll_id AND staff_payrolls_tbl.staff_id = payroll_payments_relations_tbl.staff_id', 'left');
    $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = payroll_payments_relations_tbl.payroll_payment_id');
    $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = transaction_numbers_tbl.trans_type_id');
     $builder->join('users','users.user_id=transaction_numbers_tbl.updated_by');
   $builder->join('approval_numbers','approval_numbers.trans_no = payroll_payments_relations_tbl.payroll_payment_id AND transaction_numbers_tbl.trans_type_id = approval_numbers.trans_type');
   $builder->join('approval_history','approval_history.app_no = approval_numbers.app_id');
   $builder->join('voucher_relation_tbl','voucher_relation_tbl.trans_no = payroll_payments_relations_tbl.payroll_payment_id AND transaction_numbers_tbl.trans_type_id = voucher_relation_tbl.trans_type');
   $builder->join('voucher_types_tbl','voucher_types_tbl.id = voucher_relation_tbl.voucher_type');
    
    if ($month > 0) {
        $builder->where('payrolls_tbl.payroll_month', $month);
    }
    if ($year > 0) {
        $builder->where('payrolls_tbl.payroll_year', $year);
    }
    
    $builder->where('payroll_payments_relations_tbl.staff_id', $staff);
    $builder->where('payroll_payments_relations_tbl.payroll_id', $payroll_id);
    $builder->where('transaction_numbers_tbl.trans_type_id', 5);
    $builder->where('approval_history.hstatus', 1);
    return $builder->get()->getResult();
}
public function GetStaffData($user_id){
        $builder = $this->db->table('staff_details_tbl');
    $builder->select('staff_details_tbl.*,bank_lists_tbl.bank_name,staff_status.*');
    $builder->join('bank_lists_tbl', 'bank_lists_tbl.bank_id = staff_details_tbl.bank_name','left');
     $builder->join('staff_status', 'staff_status.status_id = staff_details_tbl.status');
     $builder->where('staff_details_tbl.user_id',$user_id);
     return $builder->get()->getResult();
}

public function NetsalariesReport($payroll_year,$payroll_month,$department,$title,$classfication,$bank){
    $builder = $this->db->table('staff_details_tbl');
    $builder->select('
        payrolls_tbl.payroll_year,
        payrolls_tbl.payroll_date,
        payrolls_tbl.payroll_id,
        staff_payrolls_tbl.staff_id,
        staff_payrolls_tbl.net_salary_balances,
        staff_payrolls_tbl.net_salaries,
        staff_details_tbl.account_name,
        staff_details_tbl.account_number,
        users.first_name,
        users.last_name,
        users.other_name,
        users.gender,
        job_tittle_tbl.job_tittle,
        departments_tbl.dep_name,
        classification_tbl.class_name,
        bank_lists_tbl.bank_name,
        payroll_payments_relations_tbl.payroll_payment_id,
        months.month
    ');

    $builder->join('staff_payrolls_tbl', 'staff_payrolls_tbl.staff_id = staff_details_tbl.user_id');
    $builder->join('users', 'users.user_id = staff_details_tbl.user_id');
    $builder->join('payrolls_tbl', 'payrolls_tbl.payroll_id = staff_payrolls_tbl.payroll_ids');
    
    $builder->join('payroll_payments_relations_tbl', 'payroll_payments_relations_tbl.payroll_id = payrolls_tbl.payroll_id AND payroll_payments_relations_tbl.staff_id = staff_payrolls_tbl.staff_id', 'left');

    $builder->join('months', 'months.month_id = payrolls_tbl.payroll_month', 'left');
    $builder->join('job_tittle_tbl', 'job_tittle_tbl.id = staff_details_tbl.job_id');
    $builder->join('departments_tbl', 'departments_tbl.id = staff_details_tbl.dep_id');
    $builder->join('classification_tbl', 'classification_tbl.id = staff_details_tbl.classfication_id','left');
    $builder->join('bank_lists_tbl', 'bank_lists_tbl.bank_id = staff_details_tbl.bank_name', 'left');

    if ($payroll_month > 0) {
        $builder->where('payrolls_tbl.payroll_month', $payroll_month);
    }

    if ($payroll_year > 0) {
        $builder->where('payrolls_tbl.payroll_year', $payroll_year);
    }
        if ($department > 0) {
        $builder->where('staff_details_tbl.dep_id', $department);
    }
       if ($title > 0) {
        $builder->where('staff_details_tbl.job_id', $title);
    }
         if ($classfication > 0) {
        $builder->where('staff_details_tbl.classfication_id', $classfication);
    }
          if ($bank > 0) {
        $builder->where('staff_details_tbl.bank_name', $bank);
    }
    return $builder->get()->getResult();

}
function payeReport($payroll_year,$payroll_month,$department,$title,$classfication,$bank){
    $builder = $this->db->table('staff_details_tbl');
    $builder->select('
        payrolls_tbl.payroll_year,
        payrolls_tbl.payroll_date,
        payrolls_tbl.payroll_id,
        staff_payrolls_tbl.staff_id,
        staff_payrolls_tbl.net_salary_balances,
        staff_payrolls_tbl.pension,
        staff_payrolls_tbl.nhif,
        staff_payrolls_tbl.paye,
        staff_payrolls_tbl.heslb,
        staff_payrolls_tbl.advances,
        staff_details_tbl.account_name,
        staff_details_tbl.account_number,
        users.first_name,
        users.last_name,
        users.gender,
        job_tittle_tbl.job_tittle,
        departments_tbl.dep_name,
        classification_tbl.class_name,
        bank_lists_tbl.bank_name,
        payroll_payments_relations_tbl.payroll_payment_id,
      staff_details_tbl.basic_salary,
      staff_details_tbl.tin_no,
      staff_details_tbl.pension_no,
      staff_details_tbl.employment_type,
      staff_details_tbl.residential_status,
      staff_details_tbl.allowances,
        months.month
    ');

    $builder->join('staff_payrolls_tbl', 'staff_payrolls_tbl.staff_id = staff_details_tbl.user_id');
    $builder->join('users', 'users.user_id = staff_details_tbl.user_id');
    $builder->join('payrolls_tbl', 'payrolls_tbl.payroll_id = staff_payrolls_tbl.payroll_ids');
    
    $builder->join('payroll_payments_relations_tbl', 'payroll_payments_relations_tbl.payroll_id = payrolls_tbl.payroll_id AND payroll_payments_relations_tbl.staff_id = staff_payrolls_tbl.staff_id', 'left');

    $builder->join('months', 'months.month_id = payrolls_tbl.payroll_month', 'left');
    $builder->join('job_tittle_tbl', 'job_tittle_tbl.id = staff_details_tbl.job_id');
    $builder->join('departments_tbl', 'departments_tbl.id = staff_details_tbl.dep_id');
    $builder->join('classification_tbl', 'classification_tbl.id = staff_details_tbl.classfication_id');
    $builder->join('bank_lists_tbl', 'bank_lists_tbl.bank_id = staff_details_tbl.bank_name', 'left');

    if ($payroll_month > 0) {
        $builder->where('payrolls_tbl.payroll_month', $payroll_month);
    }

    if ($payroll_year > 0) {
        $builder->where('payrolls_tbl.payroll_year', $payroll_year);
    }
        if ($department > 0) {
        $builder->where('staff_details_tbl.dep_id', $department);
    }
       if ($title > 0) {
        $builder->where('staff_details_tbl.job_id', $title);
    }
         if ($classfication > 0) {
        $builder->where('staff_details_tbl.classfication_id', $classfication);
    }
          if ($bank > 0) {
        $builder->where('staff_details_tbl.bank_name', $bank);
    }
 
    return $builder->get()->getResult();

}
function WCFReport($payroll_year,$payroll_month,$department,$title,$classfication,$bank){
    $builder = $this->db->table('staff_details_tbl');
    $builder->select('
        payrolls_tbl.payroll_year,
        payrolls_tbl.payroll_date,
        payrolls_tbl.payroll_id,
        staff_payrolls_tbl.staff_id,
        staff_payrolls_tbl.net_salary_balances,
        staff_payrolls_tbl.pension,
        staff_payrolls_tbl.nhif,
        staff_payrolls_tbl.paye,
        staff_payrolls_tbl.heslb,
        staff_payrolls_tbl.advances,
        staff_details_tbl.account_name,
        staff_details_tbl.account_number,
        users.first_name,
        users.last_name,
        users.phone_no,
        users.other_name,
        users.birth_date,
        users.national_id,
        users.gender,
        job_tittle_tbl.job_tittle,
        departments_tbl.dep_name,
        classification_tbl.class_name,
        bank_lists_tbl.bank_name,
        payroll_payments_relations_tbl.payroll_payment_id,
      staff_details_tbl.basic_salary,
      staff_details_tbl.tin_no,
      staff_details_tbl.wcf_no,
      staff_details_tbl.pension_no,
      staff_details_tbl.employment_type,
      staff_details_tbl.residential_status,
      staff_details_tbl.allowances,
        months.month
    ');

    $builder->join('staff_payrolls_tbl', 'staff_payrolls_tbl.staff_id = staff_details_tbl.user_id');
    $builder->join('users', 'users.user_id = staff_details_tbl.user_id');
    $builder->join('payrolls_tbl', 'payrolls_tbl.payroll_id = staff_payrolls_tbl.payroll_ids');
    
    $builder->join('payroll_payments_relations_tbl', 'payroll_payments_relations_tbl.payroll_id = payrolls_tbl.payroll_id AND payroll_payments_relations_tbl.staff_id = staff_payrolls_tbl.staff_id', 'left');

    $builder->join('months', 'months.month_id = payrolls_tbl.payroll_month', 'left');
    $builder->join('job_tittle_tbl', 'job_tittle_tbl.id = staff_details_tbl.job_id');
    $builder->join('departments_tbl', 'departments_tbl.id = staff_details_tbl.dep_id');
    $builder->join('classification_tbl', 'classification_tbl.id = staff_details_tbl.classfication_id');
    $builder->join('bank_lists_tbl', 'bank_lists_tbl.bank_id = staff_details_tbl.bank_name', 'left');

    if ($payroll_month > 0) {
        $builder->where('payrolls_tbl.payroll_month', $payroll_month);
    }

    if ($payroll_year > 0) {
        $builder->where('payrolls_tbl.payroll_year', $payroll_year);
    }
        if ($department > 0) {
        $builder->where('staff_details_tbl.dep_id', $department);
    }
       if ($title > 0) {
        $builder->where('staff_details_tbl.job_id', $title);
    }
         if ($classfication > 0) {
        $builder->where('staff_details_tbl.classfication_id', $classfication);
    }
          if ($bank > 0) {
        $builder->where('staff_details_tbl.bank_name', $bank);
    }

    return $builder->get()->getResult();

}
function NSSFReport($payroll_year,$payroll_month,$department,$title,$classfication,$bank){
    $builder = $this->db->table('staff_details_tbl');
    $builder->select('
        payrolls_tbl.payroll_year,
        payrolls_tbl.payroll_date,
        payrolls_tbl.payroll_id,
        staff_payrolls_tbl.staff_id,
        staff_payrolls_tbl.net_salary_balances,
        staff_payrolls_tbl.pension,
        staff_payrolls_tbl.nhif,
        staff_payrolls_tbl.paye,
        staff_payrolls_tbl.heslb,
        staff_payrolls_tbl.advances,
        staff_details_tbl.account_name,
        staff_details_tbl.account_number,
        users.first_name,
        users.last_name,
        users.other_name,
        users.phone_no,
        users.national_id,
        users.gender,,
        job_tittle_tbl.job_tittle,
        departments_tbl.dep_name,
        classification_tbl.class_name,
        bank_lists_tbl.bank_name,
        payroll_payments_relations_tbl.payroll_payment_id,
      staff_details_tbl.basic_salary,
      staff_details_tbl.tin_no,
      staff_details_tbl.wcf_no,
      staff_details_tbl.pension_no,
      staff_details_tbl.employment_type,
      staff_details_tbl.residential_status,
      staff_details_tbl.allowances,
        months.month
    ');

    $builder->join('staff_payrolls_tbl', 'staff_payrolls_tbl.staff_id = staff_details_tbl.user_id');
    $builder->join('users', 'users.user_id = staff_details_tbl.user_id');
    $builder->join('payrolls_tbl', 'payrolls_tbl.payroll_id = staff_payrolls_tbl.payroll_ids');
    
    $builder->join('payroll_payments_relations_tbl', 'payroll_payments_relations_tbl.payroll_id = payrolls_tbl.payroll_id AND payroll_payments_relations_tbl.staff_id = staff_payrolls_tbl.staff_id', 'left');

    $builder->join('months', 'months.month_id = payrolls_tbl.payroll_month', 'left');
    $builder->join('job_tittle_tbl', 'job_tittle_tbl.id = staff_details_tbl.job_id');
    $builder->join('departments_tbl', 'departments_tbl.id = staff_details_tbl.dep_id');
    $builder->join('classification_tbl', 'classification_tbl.id = staff_details_tbl.classfication_id');
    $builder->join('bank_lists_tbl', 'bank_lists_tbl.bank_id = staff_details_tbl.bank_name', 'left');

    if ($payroll_month > 0) {
        $builder->where('payrolls_tbl.payroll_month', $payroll_month);
    }

    if ($payroll_year > 0) {
        $builder->where('payrolls_tbl.payroll_year', $payroll_year);
    }
        if ($department > 0) {
        $builder->where('staff_details_tbl.dep_id', $department);
    }
       if ($title > 0) {
        $builder->where('staff_details_tbl.job_id', $title);
    }
         if ($classfication > 0) {
        $builder->where('staff_details_tbl.classfication_id', $classfication);
    }
          if ($bank > 0) {
        $builder->where('staff_details_tbl.bank_name', $bank);
    }

    return $builder->get()->getResult();

}
public function DeleteStaff($user_id){
  $builder = $this->db->table('staff_details_tbl');
            $builder->where('user_id',$user_id);
           return $builder->delete();

}
public function GetGroupedData($group){
     $builder = $this->db->table('staff_details_tbl');
     $builder->select('users.status,users.first_name,classification_tbl.class_name, users.last_name,departments_tbl.dep_name,job_tittle_tbl.job_tittle,staff_details_tbl.*,staff_status.*');
     $builder->join('users','users.user_id=staff_details_tbl.user_id');
      $builder->join('departments_tbl','departments_tbl.id=staff_details_tbl.dep_id');
      $builder->join('job_tittle_tbl','job_tittle_tbl.id=staff_details_tbl.job_id'); 
      $builder->join('classification_tbl','classification_tbl.id=staff_details_tbl.classfication_id','left'); 
       $builder->join('staff_status', 'staff_status.status_id = staff_details_tbl.status');
      $builder->where('staff_details_tbl.status !=',4);
      $builder->orderBy('staff_details_tbl.id'); 
     return $builder->get()->getResult();
}
public function GetSalary_Advances($year,$month){
    $builder = $this->db->table('salary_advances_schedule_tbl');
    $builder->select('salary_advances_schedule_tbl.advance_amount,
                      salary_advances_schedule_tbl.staff_id');
    $builder->where('salary_advances_schedule_tbl.payroll_month', $month);
    $builder->where('salary_advances_schedule_tbl.payroll_year', $year);  
    return $builder->get()->getResult();
}
public function check_expireContracts()
{
    $builder = $this->db->table('staff_details_tbl');
    $builder->select('contract_check');
    return $builder->get()->getRow();
}
public function expireContracts(){
      $builder=$this->db->table('staff_details_tbl')
    ->where('staff_details_tbl.contract_expiry_date <',date('Y-m-d'))
    ->where('status', 1)
    ->update(['status' => 2]);

    return $this->db->affectedRows();
}
public function unexpireContracts(){
  $builder=$this->db->table('staff_details_tbl')
    ->where('staff_details_tbl.contract_expiry_date >',date('Y-m-d'))
    ->where('staff_details_tbl.status', 2)
    ->update(['staff_details_tbl.status' => 1]);

    return $this->db->affectedRows();
}

public function update_expire_check()
{
    $builder = $this->db->table('staff_details_tbl');
    $builder->set('contract_check', date('Y-m-d'));
    $builder->update();
    return $this->db->affectedRows();
}

public function view_payrollData($payroll_id){
     $builder = $this->db->table('staff_payrolls_tbl');
     $builder->select('users.status,users.first_name, users.last_name,departments_tbl.dep_name,job_tittle_tbl.job_tittle,staff_payrolls_tbl.*,staff_details_tbl.*,months.month,staff_status.*,payrolls_tbl.payroll_year');
     $builder->join('users','users.user_id=staff_payrolls_tbl.staff_id');
     $builder->join('staff_details_tbl','staff_details_tbl.user_id=staff_payrolls_tbl.staff_id');
     $builder->join('departments_tbl','departments_tbl.id=staff_details_tbl.dep_id');
      $builder->join('job_tittle_tbl','job_tittle_tbl.id=staff_details_tbl.job_id'); 
         $builder->join('staff_status', 'staff_status.status_id = staff_details_tbl.status');
      $builder->join('payrolls_tbl','payrolls_tbl.payroll_id=staff_payrolls_tbl.payroll_ids'); 
        $builder->join('months', 'months.month_id = payrolls_tbl.payroll_month');
       $builder->where('staff_payrolls_tbl.payroll_ids',$payroll_id);
      $builder->groupBy('staff_details_tbl.id'); 
     return $builder->get()->getResult();
}
public function monthname($month_id){
     $builder = $this->db->table('months');
     $builder->select('months.month' );
  $builder->where('months.month_id',$month_id);
     return $builder->get()->getRow();
}

 function get_company_details(){
     $query = $this->db->table('company_tbl');
     $results=$query->get()->getResult();
     $this->db->close();
     return $results;
       
 }
     public function payroll_approval_view($payroll_id,$trans_type){
     $builder = $this->db->table('payrolls_tbl');
    $builder->select('
      payrolls_tbl.created_by,
      payrolls_tbl.payroll_year,
      payrolls_tbl.payroll_date,
      payrolls_tbl.payroll_id,
      transaction_types_tbl.type_name,
      transaction_numbers_tbl.trans_number,
      transaction_numbers_tbl.trans_type_id,
      users.first_name,
      users.last_name,
      transaction_numbers_tbl.trans_date,
      months.month');
      $builder->join('months','months.month_id=payrolls_tbl.payroll_month');
      $builder->join('ledger_transaction_tbl','ledger_transaction_tbl.trans_no=payrolls_tbl.transaction_id');
      $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=payrolls_tbl.transaction_id');
      $builder->join('users','users.user_id=payrolls_tbl.created_by');
       $builder->join('voucher_relation_tbl','voucher_relation_tbl.trans_no=transaction_numbers_tbl.trans_number');
      $builder->join('transaction_types_tbl','transaction_types_tbl.type_id=transaction_numbers_tbl.trans_type_id');
$builder->where('payrolls_tbl.payroll_id', $payroll_id);
$builder->where('transaction_numbers_tbl.trans_type_id', $trans_type);
$builder->groupBy('users.user_id');
     $query = $builder->get()->getResult();
    return $query;
    }

    public function view_payroll_ledger($trans_no,$trans_type){
       $builder = $this->db->table('ledger_transaction_tbl');
    $builder->select('
      accounts_tbl.account_name, 
      account_types_tbl.type_name, 
      accounts_tbl.id,
      ledger_transaction_tbl.id,
      ledger_transaction_tbl.ledger_id,
      ledger_transaction_tbl.amount,
      ledger_transaction_tbl.transation_nature,
      ledger_transaction_tbl.ledger_type');
       $builder->join('accounts_tbl','accounts_tbl.id=ledger_transaction_tbl.ledger_id');
        $builder->join('account_types_tbl','account_types_tbl.id=accounts_tbl.account_type_id');
$builder->where('ledger_transaction_tbl.trans_no', $trans_no);
$builder->where('ledger_transaction_tbl.trans_type', $trans_type);
$builder->groupBy('accounts_tbl.id');
$builder->orderBy('ledger_transaction_tbl.transation_nature', 'DESC');
   $query = $builder->get()->getResult();
    return $query;
    }

public function GetSalaryAdvancesData($user_id){
 $builder = $this->db->table('salary_advances_schedule_tbl');
  $builder->select('salary_advances_schedule_tbl.transaction_id,salary_advances_schedule_tbl.advance_amount,transaction_numbers_tbl.trans_date,ledger_transaction_tbl.amount,transaction_types_tbl.type_name,salary_advances_schedule_tbl.payroll_month,salary_advances_schedule_tbl.payroll_year,salary_advances_schedule_tbl.staff_id');
$builder->join('ledger_transaction_tbl','ledger_transaction_tbl.trans_no=salary_advances_schedule_tbl.transaction_id');
$builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=salary_advances_schedule_tbl.transaction_id');
$builder->join('transaction_types_tbl','transaction_types_tbl.type_id=ledger_transaction_tbl.trans_type');
$builder->where('salary_advances_schedule_tbl.staff_id',$user_id);
$builder->where('ledger_transaction_tbl.ledger_id',48);
$builder->where('ledger_transaction_tbl.trans_type',5);
$builder->where('transaction_numbers_tbl.trans_type_id',5);
$builder->groupBy('salary_advances_schedule_tbl.transaction_id'); 
$names = $builder->get()->getResult();
return $names;
}
public function GetPaidPayrollData($user_id){
 $builder = $this->db->table('payroll_payments_relations_tbl');
 $builder->select('salary_advances_schedule_tbl.advance_amount');
$builder->join('payrolls_tbl','payrolls_tbl.payroll_id=payroll_payments_relations_tbl.payroll_id');
$builder->join('salary_advances_schedule_tbl','salary_advances_schedule_tbl.payroll_year=payrolls_tbl.payroll_year AND salary_advances_schedule_tbl.payroll_month=payrolls_tbl.payroll_month');
$builder->where('payroll_payments_relations_tbl.staff_id',$user_id);
$builder->groupBy('payroll_payments_relations_tbl.payroll_id'); 
$names = $builder->get()->getResult();
return $names;
}
public function GetAdvance_details($transaction_id,$staff)
{
    $builder = $this->db->table('payroll_payments_relations_tbl');
    $builder->select('
        users.first_name, 
      users.last_name,
        payrolls_tbl.payroll_year,
        payrolls_tbl.payroll_date,
        payrolls_tbl.payroll_id,
        staff_payrolls_tbl.staff_id,
        transaction_types_tbl.type_name,
        staff_payrolls_tbl.net_salary_balances,
        staff_payrolls_tbl.net_salaries,
        transaction_numbers_tbl.trans_date,
        payroll_payments_relations_tbl.payroll_payment_id,
        salary_advances_schedule_tbl.advance_amount,
        approval_history.hstatus,
        voucher_types_tbl.voucher_type_name
    ');
    $builder->join('payrolls_tbl', 'payrolls_tbl.payroll_id = payroll_payments_relations_tbl.payroll_id');
    $builder->join('staff_payrolls_tbl', 'staff_payrolls_tbl.payroll_ids = payrolls_tbl.payroll_id AND staff_payrolls_tbl.staff_id = payroll_payments_relations_tbl.staff_id', 'left');
    $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = payroll_payments_relations_tbl.payroll_payment_id');
    $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = transaction_numbers_tbl.trans_type_id');
     $builder->join('users','users.user_id=transaction_numbers_tbl.updated_by');
   $builder->join('approval_numbers','approval_numbers.trans_no = payroll_payments_relations_tbl.payroll_payment_id AND transaction_numbers_tbl.trans_type_id = approval_numbers.trans_type');
   $builder->join('salary_advances_schedule_tbl','salary_advances_schedule_tbl.payroll_year = payrolls_tbl.payroll_year AND salary_advances_schedule_tbl.payroll_month = payrolls_tbl.payroll_month');
   $builder->join('approval_history','approval_history.app_no = approval_numbers.app_id');
   $builder->join('voucher_relation_tbl','voucher_relation_tbl.trans_no = payroll_payments_relations_tbl.payroll_payment_id AND transaction_numbers_tbl.trans_type_id = voucher_relation_tbl.trans_type');
   $builder->join('voucher_types_tbl','voucher_types_tbl.id = voucher_relation_tbl.voucher_type');
    
    $builder->where('payroll_payments_relations_tbl.staff_id', $staff);
    $builder->where('salary_advances_schedule_tbl.transaction_id', $transaction_id);
    $builder->where('transaction_numbers_tbl.trans_type_id', 5);
    $builder->where('approval_history.hstatus', 1);    
    $builder->groupBy('payroll_payments_relations_tbl.payroll_id');    
    return $builder->get()->getResult();
}




        public function view_staffData($staff_id){
       $builder = $this->db->table('staff_details_tbl');
      $builder->select('
       users.first_name,
      users.last_name,
      users.phone_no,
      staff_status.status_name,
      staff_details_tbl.basic_salary,
      staff_status.status_color,
      departments_tbl.dep_name,
      staff_details_tbl.user_id,
      job_tittle_tbl.job_tittle
      ');
       $builder->join('users','users.user_id=staff_details_tbl.user_id');
        $builder->join('departments_tbl','departments_tbl.id=staff_details_tbl.dep_id');
        $builder->join('job_tittle_tbl','job_tittle_tbl.id=staff_details_tbl.job_id');
        $builder->join('staff_status', 'staff_status.status_id = staff_details_tbl.status');
$builder->where('staff_details_tbl.user_id', $staff_id);
   $query = $builder->get()->getRow();
    return $query;
    }

public function GetOvertime($year, $month)
{
    $builder = $this->db->table('overtime_schedule_tbl');
    $builder->select('
        overtime_schedule_tbl.staff_id,
        overtime_schedule_tbl.payroll_month,
        overtime_schedule_tbl.payroll_year,
        SUM(overtime_schedule_tbl.amount) AS overtime_amount,
        SUM(overtime_schedule_tbl.total_hours) AS total_hours
    ');
    $builder->where('overtime_schedule_tbl.payroll_year', $year);
    $builder->where('overtime_schedule_tbl.payroll_month', $month);
$builder->groupBy(['overtime_schedule_tbl.staff_id']);
    return $builder->get()->getResult();
}
 public function DeleteLedgerTransaction($trans_type,$trans_id){
  $builder = $this->db->table('ledger_transaction_tbl');
            $builder->where('trans_type',$trans_type);
            $builder->where('trans_no',$trans_id);
           return $builder->delete();
}
 public function DeleteLedgerPayroll_class($trans_type,$trans_id,$payroll_id){
  $builder = $this->db->table('payroll_classifications_tbl');
            $builder->where('transaction_type_id',$trans_type);
            $builder->where('transaction_id',$trans_id);
            $builder->where('payrolls',$payroll_id);
           return $builder->delete();
} 
public function Deletestaff_payrolls($payroll_id){
  $builder = $this->db->table('staff_payrolls_tbl');
            $builder->where('payroll_ids',$payroll_id);
           return $builder->delete();
}
public function Deletevoucher_relation($trans_type,$trans_id,$payroll_id){
  $builder = $this->db->table('voucher_relation_tbl');
            $builder->where('payment_no',$payroll_id);
            $builder->where('trans_type',$trans_type);
            $builder->where('trans_no',$trans_id);
           return $builder->delete();
}
public function Deleteapproval_numbers($trans_type,$trans_id,$payroll_id){
  $builder = $this->db->table('approval_numbers');
            $builder->where('name',$payroll_id);
            $builder->where('trans_type',$trans_type);
            $builder->where('trans_no',$trans_id);
           return $builder->delete();
}
public function Deleteapproval_history($app_no){
  $builder = $this->db->table('approval_history');
            $builder->where('app_no',$app_no);
           return $builder->delete();
}
public function Deletepayrolls($trans_type,$trans_id,$payroll_id){
  $builder = $this->db->table('payrolls_tbl');
            $builder->where('payroll_id',$payroll_id);
            $builder->where('transaction_type_id',$trans_type);
            $builder->where('transaction_id',$trans_id);
           return $builder->delete();
}
public function Deletetransaction_numbers($trans_type,$trans_id,$payroll_id){
  $builder = $this->db->table('transaction_numbers_tbl');
            $builder->where('trans_type_id',$trans_type);
            $builder->where('trans_number',$trans_id);
           return $builder->delete();
}
public function DeleteMessageGroup($trans_id){
  $builder = $this->db->table('message_groups_tbl');
            $builder->where('message_type',17);
            $builder->where('trans_number',$trans_id);
           return $builder->delete();
}
public function GetApprovalNumber($trans_type,$trans_id,$payroll_id){
     $builder = $this->db->table('approval_numbers');
     $builder->select('app_id' );
          $builder->where('name',$payroll_id);
            $builder->where('trans_type',$trans_type);
            $builder->where('trans_no',$trans_id);
     return $builder->get()->getRow();
}
public function checkApprovalStatus($payroll_id,$trans_type){
          $builder = $this->db->table('approval_numbers');
            $builder->select('approval_numbers.app_id,approval_history.hstatus' );
             $builder->join('approval_history','approval_history.app_no=approval_numbers.app_id');
            $builder->where('trans_type',$trans_type);
            $builder->where('name',$payroll_id);
   $builder->where('approval_history.hstatus', 1); 
   $builder->where('approval_history.user_role', 3); 
          return $builder->get()->getResult();
}
    public function payrollTransID($payroll_id){
               $builder = $this->db->table('payrolls_tbl');
            $builder->select('payrolls_tbl.transaction_id' );
                      $builder->where('payrolls_tbl.payroll_id',$payroll_id);
                      $builder->where('payrolls_tbl.transaction_type_id',10);
          return $builder->get()->getRow();
    }
        public function PayrollApprovalStatus(){
          $builder = $this->db->table('approval_numbers');
     $builder->select('approval_numbers.app_id,approval_history.hstatus,approval_numbers.trans_no,approval_history.user_role' );
             $builder->join('approval_history','approval_history.app_no=approval_numbers.app_id');
            $builder->where('approval_numbers.trans_type',10); 
             $builder->orderBy('approval_history.hist_id', 'DESC');
          return $builder->get()->getResult();
}

public function GetElectricityList(){
     $builder = $this->db->table('electricity_charges');
     $builder->select('electricity_charges.charge_id,SUM(electricity_charges.charge_amount) AS total_amount,electricity_charges.charge_date,electricity_charges.pay_year,electricity_charges.pay_month,electricity_charges.created_on,months.*,users.first_name,users.last_name');
       $builder->join('users', 'users.user_id = electricity_charges.created_by');
       $builder->join('months', 'months.month_id = electricity_charges.pay_month');  
           $builder->groupBy('electricity_charges.pay_month');      
           $builder->groupBy('electricity_charges.pay_year');      
     return $builder->get()->getResult();
}
 public function staff_electricity_list($db_id){
     $query = $this->db->table('users');
      $query->select('users.*,staff_details_tbl.*,users_type_tbl.type_name,staff_status.*,electricity_charges.staff_id,electricity_charges.charge_amount,electricity_charges.pay_month,electricity_charges.pay_year,job_tittle_tbl.job_tittle,departments_tbl.dep_name'); 
       $query->join('users_type_tbl', 'users_type_tbl.id = users.user_type');
         $query->join('staff_details_tbl', 'staff_details_tbl.user_id = users.user_id');  
         $query->join('staff_status', 'staff_status.status_id = staff_details_tbl.status');
         $query->join('job_tittle_tbl', 'job_tittle_tbl.id = staff_details_tbl.job_id');
         $query->join('departments_tbl', 'departments_tbl.id = staff_details_tbl.dep_id');
         $query->join('electricity_charges', 'electricity_charges.staff_id = users.user_id','left');
       $query->where('database_id',$db_id);
       $query->where('staff',1);
       $query->where('staff_details_tbl.electricty_status',1);
       $query->groupBy('staff_details_tbl.user_id');
       $result= $query->get()->getResult();
      return $result; 
  } 
  public function check_saved_charges($year,$month){
     $query = $this->db->table('staff_details_tbl');
      $query->select('staff_status.*,electricity_charges.staff_id,electricity_charges.charge_amount,electricity_charges.pay_month,electricity_charges.pay_year,electricity_charges.created_on,electricity_charges.staff_id,job_tittle_tbl.job_tittle,departments_tbl.dep_name,users.first_name,users.last_name,users.gender,electricity_charges.created_by'); 
         $query->join('staff_status', 'staff_status.status_id = staff_details_tbl.status');
         $query->join('electricity_charges', 'electricity_charges.staff_id = staff_details_tbl.user_id');
              $query->join('job_tittle_tbl', 'job_tittle_tbl.id = staff_details_tbl.job_id');
         $query->join('departments_tbl', 'departments_tbl.id = staff_details_tbl.dep_id');
                 $query->join('users', 'staff_details_tbl.user_id = users.user_id');  
       $query->where('staff_details_tbl.electricty_status',1);
       $result= $query->get()->getResult();
      return $result; 
  }
  public function get_month_name($charge_month){
     $query = $this->db->table('months');
      $query->select('months.*');
    $query->where('months.month_id',$charge_month);
    $result= $query->get()->getRow();
      return $result;  
  }
  public function save_electricity_charges($data){
        $query = $this->db->table('electricity_charges')->insert($data);
 if($query)
    {
        return true;
    }
    else{
        return false;
     }
  }
  public function GetElectricityCharge($year,$month){
     $builder = $this->db->table('electricity_charges');
     $builder->select('electricity_charges.charge_amount,electricity_charges.staff_id,staff_details_tbl.user_id');
     $builder->join('staff_details_tbl','staff_details_tbl.user_id=electricity_charges.staff_id');
       $builder->where('electricity_charges.pay_month', $month);
       $builder->where('electricity_charges.pay_year', $year);    
     return $builder->get()->getResult();
}  
public function GetElectricityChargeList_old($year,$month){
     $builder = $this->db->table('electricity_charges');
     $builder->select('electricity_charges.*,months.*,staff_details_tbl.user_id,users.first_name,users.last_name,users.gender
        ,job_tittle_tbl.job_tittle,departments_tbl.dep_name');
     $builder->join('staff_details_tbl','staff_details_tbl.user_id=electricity_charges.staff_id');
       $builder->join('users', 'users.user_id = electricity_charges.staff_id');
          $builder->join('job_tittle_tbl', 'job_tittle_tbl.id = staff_details_tbl.job_id');
         $builder->join('departments_tbl', 'departments_tbl.id = staff_details_tbl.dep_id');
       $builder->join('months', 'months.month_id = electricity_charges.pay_month');
     if($month>0){
      $builder->where('electricity_charges.pay_month', $month);  
     }if($year>0){
        $builder->where('electricity_charges.pay_year', $year);  
     }         
     return $builder->get()->getResult();
}

    public function getAllusersData($db_id){
       $query=$this->db->table('users');  
          $query->select('users.last_name,users.first_name,users.user_id');
           $Result=$query->get()->getResult();
            $query->where('database_id',$db_id);
        return $Result;
    }
    public function GetUpdateCharges($id){
          $builder = $this->db->table('electricity_charges');
     $builder->select('electricity_charges.*,months.*,staff_details_tbl.user_id,users.first_name,users.last_name');
     $builder->join('staff_details_tbl','staff_details_tbl.user_id=electricity_charges.staff_id');
       $builder->join('users', 'users.user_id = electricity_charges.staff_id');
       $builder->join('months', 'months.month_id = electricity_charges.pay_month');
      $builder->where('electricity_charges.charge_id', $id);          
     return $builder->get()->getRow();
    }
        public function GetMonthlyDeductions($month,$year){
          $builder = $this->db->table('electricity_charges');
     $builder->select('electricity_charges.staff_id,electricity_charges.charge_amount,electricity_charges.pay_month,electricity_charges.pay_year,electricity_charges.created_on,electricity_charges.charge_id,electricity_charges.staff_id,job_tittle_tbl.job_tittle,departments_tbl.dep_name,users.first_name,users.last_name,users.gender,electricity_charges.created_by');
     $builder->join('staff_details_tbl','staff_details_tbl.user_id=electricity_charges.staff_id');
       $builder->join('users', 'users.user_id = electricity_charges.staff_id');
       $builder->join('months', 'months.month_id = electricity_charges.pay_month');
              $builder->join('job_tittle_tbl', 'job_tittle_tbl.id = staff_details_tbl.job_id');
         $builder->join('departments_tbl', 'departments_tbl.id = staff_details_tbl.dep_id');
            $builder->where('electricity_charges.pay_month', $month);  
        $builder->where('electricity_charges.pay_year', $year);            
     return $builder->get()->getResult();
    }
    public function updatechargedata($data,$id){
      $builder=$this->db->table('electricity_charges')
    ->where('charge_id',$id)
    ->update($data);
    return $this->db->affectedRows();
}
public function payrollDeduction($month,$year){
      $builder = $this->db->table('payrolls_tbl');
     $builder->select('payrolls_tbl.*');
      $builder->where('payrolls_tbl.payroll_year', $year);          
      $builder->where('payrolls_tbl.payroll_month', $month);          
     return $builder->get()->getRow();
}
public function Deletecharges($condition){
      $builder = $this->db->table('electricity_charges');
            $builder->where($condition);
           return $builder->delete();
}

  public function save_loan_deductions($data){
  $query = $this->db->table('loan_deductions')->insert($data);
 if($query)
    {
        return true;
    }
    else{
        return false;
     }
  }
    public function GetLoansDeductions($year,$month){
     $builder = $this->db->table('loan_deductions');
     $builder->select('loan_deductions.loan_amount,loan_deductions.staff_id,staff_details_tbl.user_id');
     $builder->join('staff_details_tbl','staff_details_tbl.user_id=loan_deductions.staff_id');
       $builder->where('loan_deductions.pay_month', $month);
       $builder->where('loan_deductions.pay_year', $year);    
     return $builder->get()->getResult();
}  
    public function GetRowDeductions($year,$month,$staff){
     $builder = $this->db->table('loan_deductions');
     $builder->select('loan_deductions.loan_amount,loan_deductions.staff_id,staff_details_tbl.user_id');
     $builder->join('staff_details_tbl','staff_details_tbl.user_id=loan_deductions.staff_id');
       $builder->where('loan_deductions.pay_month', $month);
       $builder->where('loan_deductions.pay_year', $year);    
       $builder->where('loan_deductions.staff_id', $staff);    
     return $builder->get()->getRow();
}
public function GetLoanDeductionsList(){
     $builder = $this->db->table('loan_deductions');
     $builder->select('loan_deductions.charge_id,SUM(loan_deductions.loan_amount) AS total_amount,loan_deductions.charge_date,loan_deductions.pay_year,loan_deductions.pay_month,loan_deductions.created_on,months.*,users.first_name,users.last_name');
       $builder->join('users', 'users.user_id = loan_deductions.created_by');
       $builder->join('months', 'months.month_id = loan_deductions.pay_month');  
           $builder->groupBy('loan_deductions.pay_month');      
           $builder->groupBy('loan_deductions.pay_year');      
     return $builder->get()->getResult();
}
        public function GetMonthlyLoans($month,$year){
          $builder = $this->db->table('loan_deductions');
     $builder->select('loan_deductions.staff_id,loan_deductions.loan_amount,loan_deductions.pay_month,loan_deductions.pay_year,loan_deductions.created_on,loan_deductions.charge_id,loan_deductions.staff_id,job_tittle_tbl.job_tittle,departments_tbl.dep_name,users.first_name,users.last_name,users.gender,loan_deductions.created_by');
     $builder->join('staff_details_tbl','staff_details_tbl.user_id=loan_deductions.staff_id');
       $builder->join('users', 'users.user_id = loan_deductions.staff_id');
       $builder->join('months', 'months.month_id = loan_deductions.pay_month');
              $builder->join('job_tittle_tbl', 'job_tittle_tbl.id = staff_details_tbl.job_id');
         $builder->join('departments_tbl', 'departments_tbl.id = staff_details_tbl.dep_id');
            $builder->where('loan_deductions.pay_month', $month);  
        $builder->where('loan_deductions.pay_year', $year);            
     return $builder->get()->getResult();
    }
        public function GetUpdateLoan($id){
          $builder = $this->db->table('loan_deductions');
     $builder->select('loan_deductions.*,months.*,staff_details_tbl.user_id,users.first_name,users.last_name');
     $builder->join('staff_details_tbl','staff_details_tbl.user_id=loan_deductions.staff_id');
       $builder->join('users', 'users.user_id = loan_deductions.staff_id');
       $builder->join('months', 'months.month_id = loan_deductions.pay_month');
      $builder->where('loan_deductions.charge_id', $id);          
     return $builder->get()->getRow();
    }
        public function updateLoandata($data,$id){
      $builder=$this->db->table('loan_deductions')
    ->where('charge_id',$id)
    ->update($data);
    return $this->db->affectedRows();
}
public function delete_loans($condition){
      $builder = $this->db->table('loan_deductions');
            $builder->where($condition);
           return $builder->delete();
}

}
?>