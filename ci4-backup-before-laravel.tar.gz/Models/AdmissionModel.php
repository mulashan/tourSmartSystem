<?php

namespace App\Models;

use CodeIgniter\Model;

class AdmissionModel extends Model
{
     public function __construct(){
        $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    }
    public function get_student_details($tbl,$id)
    {
        $builder = $this->db->table($tbl);
        $builder->select('');
        $builder->where($id);
        $results=$builder->get()->getResult();
        $this->db->close();
        return $results;
    }


    public function SaveDetails($tbl,$data){
        $builder = $this->db->table($tbl)->insert($data);
        $this->db->close();
        return $builder;
    }

    public function admisiion_details($tbls)
    {
        $builder = $this->db->table($tbls);
        $results=$builder->get()->getResult();
        $this->db->close();
        return $results;
    }

    public function get_total_stream_capacity($cid,$id)
    {
        $builder = $this->db->table('admission_tbl');
        $builder->where('class_id',$cid);
        $builder->where('stream_id',$id);
        $builder->where('status = 1');
        $builder->selectCount('stream_id');
        $results=$builder->get()->getResult();
        $this->db->close();
        return $results;
    }
       public function get_stream_comb_allocatiion($stream){
    $query = $this->db->table('comb_stream cs');
    $query->select('cs.st_id,combination_tbl.comb_name');
    $query->join('combination_tbl', 'combination_tbl.comb_id = cs.comb');
    $query->join('classes_tbl c', 'c.id = cs.class_id');
    $query->where('cs.stream_id', $stream);
   $results=$query->get()->getResult();
    $this->db->close();
     return $results;
}
    public function get_hostel_details($gender,$age)
    {
        $builder = $this->db->table('hostel_tbl');
        $builder->select('hostel_tbl.id,hostel_name,capacity,gender');
        $builder->join('hostel_blocks_tbl', 'hostel_blocks_tbl.hostel_id = hostel_tbl.id');
        $builder->where('hostel_blocks_tbl.gender',$gender);
        $builder->where('hostel_blocks_tbl.start_age <=',$age);
        $builder->where('hostel_blocks_tbl.end_age >=',$age);
        $results=$builder->get()->getResult();
        $this->db->close();
        return $results;
    }

    public function remain_classLevel_capacity($classLevelID)
    {
        $sql = 'SELECT (getCapacityQuery.totalCapacity -  totalAdmittedQuery.totalAdmitted) as remainTotal FROM (SELECT SUM(streams_tbl.stream_capacity) as totalCapacity FROM `classes_tbl`,streams_tbl,class_level_tbl WHERE streams_tbl.class_id = classes_tbl.id  AND class_level_tbl.id = classes_tbl.class_level AND class_level_tbl.id = ?) as getCapacityQuery,(SELECT COUNT(level_id) as totalAdmitted FROM `admission_tbl` WHERE status = 1 AND level_id = ?) as totalAdmittedQuery';
        $query = $this->db->query($sql, [$classLevelID, $classLevelID]);
        return $query->getResult();
    }

    public function class_stream_details($cid,$sid)
    {
        $builder = $this->db->table('classes_tbl');
        $builder->select('class_name,stream_name');
        $builder->join('streams_tbl', 'streams_tbl.class_id = classes_tbl.id');
        $builder->where('classes_tbl.id',$cid);
        $builder->where('streams_tbl.id',$sid);
       $results=$builder->get()->getResult();
       $this->db->close();
        return $results;
    }

    public function admission_classData($id)
    {
        $builder = $this->db->table('admission_tbl');
        $builder->select('admission_tbl.id,class_id,class_name,admission_tbl.status');
        $builder->join('classes_tbl', 'classes_tbl.id = admission_tbl.class_id');
        $builder->where('student_id',$id);
        $builder->groupBy('admission_tbl.id');
        $builder->orderby('admission_tbl.id', 'DESC');
        $results=$builder->get()->getResult();
        $this->db->close();
        return $results;
    }

    public function hostel_remaining_capacity($hostelID)
    {
        $sql = 'SELECT (hostel_block_capacity.capacity -  hostel_assigned.total_assigned) as remaining_capacity FROM (SELECT capacity FROM `hostel_blocks_tbl` WHERE  hostel_id = ?) as hostel_block_capacity,(SELECT COUNT(hostel_id) as total_assigned FROM `admission_tbl` WHERE status = 1 AND hostel_id = ?) as hostel_assigned';
        $query = $this->db->query($sql, [$hostelID, $hostelID]);
        return $query->getResult();
    }

    public function Transprt_remaining_capacity($TransID)
    {
        $sql = 'SELECT (vehcle_capacity.capacity -  vehicle_assigned.total_assigned) as remaining_Vehiclecapacity FROM (SELECT sum(capacity) as capacity FROM `vehicles_tbl` WHERE  vehicles_tbl.route_id = ?) as vehcle_capacity,(SELECT COUNT(vehicle_id) as total_assigned FROM `admission_tbl` WHERE status = 1 AND vehicle_id = ?) as vehicle_assigned';
        $query = $this->db->query($sql, [$TransID, $TransID]);
        return $query->getResult();
    }

    public function delete_itemTransaction_data($item,$transNo,$type)
    {
        $builder = $this->db->table('item_transation_tbl');
        $builder->select('id');
        $builder->where('item_id',$item);
        $builder->where('trans_number',$transNo);
        $builder->where('trans_type',$type);
        $builder->delete();
        $this->db->close();
    }

    public function delete_ledger_item($itm,$std,$no,$type)
    {
       $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('id');
        $builder->where('trans_type',$type);
        $builder->where('trans_item',$itm);
        $builder->where('name_id',$std);
        $builder->where('trans_no',$no);
        $builder->delete();
        $this->db->close(); 
    }

public function get_trans_type($tno)
    {
       $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('accounts_tbl.account_name');
        // $builder->where('ledger_id',$ldg);
        $builder->join('accounts_tbl','accounts_tbl.id=ledger_transaction_tbl.ledger_id');
        $builder->where('ledger_transaction_tbl.trans_no',$tno);
        $item_result = $builder->get()->getResult();
        $this->db->close();
            return $item_result; 
    }
    public function get_transdetails($tranno,$type)
    {
         $query = 'SELECT item_transation_tbl.item_id,item_name,trans_number,quantity,unit_price,account_receivable,account_name FROM item_transation_tbl,items_tbl,accounts_tbl,items_ledgers_tbl where item_transation_tbl.item_id = items_tbl.id AND item_transation_tbl.item_id = items_ledgers_tbl.item_id AND items_ledgers_tbl.account_id = accounts_tbl.id AND item_transation_tbl.trans_type ='.$type.' AND trans_number='.$tranno;
        $result = $this->db->query($query);
        return $result->getResult();

    }

    public function ledger_type($tranno,$type)
    {
        $query = 'SELECT type_name,amount FROM ledger_transaction_tbl,account_types_tbl where ledger_transaction_tbl.ledger_type = account_types_tbl.id AND ledger_transaction_tbl.trans_type='.$type.' AND (ledger_type = 3 OR ledger_type = 4) AND trans_no='.$tranno;
        $result = $this->db->query($query);
        return $result->getResult();
    }

    public function update_ledger_balance($total,$id,$no)
    {
        $query = "UPDATE ledger_transaction_tbl SET amount = amount + $total, balance = balance + $total where ledger_type = 7 AND trans_type=1 AND name_id = $id AND trans_no = $no";
        $result = $this->db->query($query);
        // return $result->getResult();
    }
    function getChargedItems(){
              $builder = $this->db->table("items_tbl");
            $builder->select('id,item_name,item_price,item_size,item_attribute,item_type');
            $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
            //$builder->where('item_type = 1 OR item_type = 2 OR item_type = 3');
            $builder->limit(100);
           
            $query = $builder->get();
            $item_result = $query->getResult();
            $this->db->close();
            return $item_result;
    }
     public function update_credit_balance($total,$id,$no)
    {
        $query = "UPDATE ledger_transaction_tbl SET amount = amount + $total, balance = balance + $total where ledger_type = 7 AND trans_type = 6 AND transation_nature=1 AND trans_no = $no";
        $result = $this->db->query($query);
        // return $result->getResult();
    }
    public function get_student_sheets($tbl,$id,$thedate)
    {
        $builder = $this->db->table($tbl);
        $builder->select('');
        $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = '.$tbl.'.trans_no AND transaction_numbers_tbl.trans_type_id = '.$tbl.'.trans_type');
        // $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
        $builder->where('DATE(transaction_numbers_tbl.updated_date) <=', $thedate);
        $builder->where($id);

        $results=$builder->get()->getResult();
        $this->db->close();
        return $results;
    }
     public function fetch_classLevel_fee($group,$id)
    {
       $builder = $this->db->table('class_level_items_tbl');
        $builder->select('quantity,item_name,item_attribute,item_size,item_group,class_level_items_tbl.item_id,class_level_items_tbl.id,level_id,item_price');
        $builder->join('items_tbl', 'items_tbl.id = class_level_items_tbl.item_id');
        $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
      if($group==0){
         $builder->whereIn('items_tbl.item_group',[0,3,7]);   
     }else{
        $builder->whereIn('items_tbl.item_group',[0,$group,3,7]); 
     }
        
        $builder->where('level_id',$id);
        $builder->where('item_group!=3');
          $builder->where('item_group!=4');
        $levelresult = $builder->get()->getResult();
        $this->db->close();
        return $levelresult;
    }
    public function fetch_class_fee($item_group,$classId){
         $builder = $this->db->table('class_charged_items_tbl');
        $builder->select('quantity,account_receivable,item_name,item_price,item_size,item_group,class_charged_items_tbl.item_id,class_charged_items_tbl.id,class_id');
        $builder->join('items_tbl', 'items_tbl.id = class_charged_items_tbl.item_id');
       $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
        if($item_group==0){
         $builder->whereIn('item_group', [0,8,7,4,9,14]);
        // $builder->where('item_group',$item_group);
        }else{
        //  $builder->where('item_group!=3');
        //   $builder->where('item_group',4);   
        }
          
        $builder->where('class_id',$classId);
        $class_result = $builder->get()->getResult();
        $this->db->close();
        return $class_result;
    }
    
    public function fetch_boarding_fee2($for,$levelId){
        $builder = $this->db->table('class_level_items_tbl');
      $builder->select('quantity,item_name,item_attribute,item_size,item_group,class_level_items_tbl.item_id,class_level_items_tbl.id,level_id,account_receivable,item_price');
  
    $builder->join('items_tbl', 'items_tbl.id = class_level_items_tbl.item_id');
    $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
     $names = [3, 4];
        if($for==2){
          $builder->whereIn('item_group', $names);
        }else{
         $builder->where('item_group', 3);
        } 
      $builder->where('level_id',$levelId);
      $hostel_result = $builder->get()->getResult();
       return $hostel_result;
    }
    
    public function fetch_boarding_fee($for,$classId){
         $builder = $this->db->table('class_charged_items_tbl');
        $builder->select('class_id,quantity,item_name,item_attribute,item_size,item_group,class_charged_items_tbl.item_id,class_charged_items_tbl.id,account_receivable,item_price');

        $builder->join('items_tbl', 'items_tbl.id = class_charged_items_tbl.item_id');
       $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
       $names = [3, 4];
        if($for==2){
            if($classId==7 || $classId==6 ){
              $builder->where('item_group', 4);
            }else{
         $builder->whereIn('item_group', $names);
           }
        }else{
          $builder->where('item_group', 3);  
        }
        $builder->where('class_id',$classId);
        $hostel_result = $builder->get()->getResult();
        $this->db->close();
        return $hostel_result;

    }
    public function check_application($full_name,$class){
        $builder = $this->db->table('students_application_tbl');
        $builder->select('*');
        $builder->like('full_name',$full_name);
       // $builder->where('class', $class);
        //$builder->where('application_status', 1);
         $results=$builder->get()->getResult();
        $this->db->close();
        return $results;
        
   
    }
    public function fetch_boarding_fee_level($for,$lvId){
         $builder = $this->db->table('class_level_items_tbl');
        $builder->select('level_id,quantity,item_name,item_attribute,item_size,item_group,class_level_items_tbl.item_id,class_level_items_tbl.id,account_receivable,item_price');

        $builder->join('items_tbl', 'items_tbl.id = class_level_items_tbl.item_id');
       $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
       $names = [3, 4];
        if($for==2){
         $builder->whereIn('item_group', $names);
           
        }else{
          $builder->where('item_group', 3);  
        }
        $builder->where('level_id',$lvId);
        $hostel_result = $builder->get()->getResult();
        $this->db->close();
        return $hostel_result;

    }
    
      public function get_student_ledger_with_status($id, $thedate)
    {
        $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('
        transaction_numbers_tbl.trans_date,
         ledger_transaction_tbl.trans_type, 
         ledger_transaction_tbl.trans_item, 
         ledger_transaction_tbl.name_type_id, 
         ledger_transaction_tbl.trans_no, 
         amount, 
         ledger_transaction_tbl.transation_nature, 
         ledger_transaction_tbl.balance,
         transaction_types_tbl.type_name,
         ledger_transaction_tbl.name_id,
         ledger_transaction_tbl.ledger_id,
        accounts_tbl.description'
        );
        
        $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id = ledger_transaction_tbl.trans_type');
                $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
                $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
                
                // Adding where conditions
                $builder->where('accounts_tbl.id', $id);
        $builder->where('DATE(transaction_numbers_tbl.trans_date) <=', $thedate);

                $builder->where('transaction_numbers_tbl.status', 1);
                $builder->where('ledger_transaction_tbl.ledger_type', 2);
                
        $builder->orderBy('trans_date', 'asc');
        $query = $builder->get()->getResult();
        
        return $query;
    }
   

    
    public function Account_Receivable($id, $thedate)
    {
        
            $builder = $this->db->table('ledger_transaction_tbl');
            $builder->select('
              transaction_numbers_tbl.trans_date,
               ledger_transaction_tbl.trans_type, 
               ledger_transaction_tbl.trans_item, 
               ledger_transaction_tbl.name_type_id, 
               ledger_transaction_tbl.trans_no, 
               amount, 
               ledger_transaction_tbl.transation_nature, 
               ledger_transaction_tbl.balance,
               transaction_types_tbl.type_name,
               ledger_transaction_tbl.name_id,
               ledger_transaction_tbl.ledger_id,
              accounts_tbl.description'
              );
            $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id =                     ledger_transaction_tbl.trans_type');
            //$builder->join('students', 'students.id = ledger_transaction_tbl.name_id');
            $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
              $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
            $builder->where('ledger_transaction_tbl.ledger_id',$id);
            $builder->where('transaction_numbers_tbl.status', 1);
            if (!is_int($thedate)) {
                $thedate = strtotime($thedate); // Convert string date to timestamp if necessary
            }
            if ($thedate !== false) { // Make sure it's a valid timestamp
                $builder->where('DATE(transaction_numbers_tbl.trans_date) <=', date('Y-m-d H:i:s', $thedate));
            } else {
                // handle invalid date case
            }
            $builder->orderBy('trans_date', 'asc');
            $query = $builder->get()->getResult();
      
            return $query;
    }
    
     public function get_student_details_byYear($tbl,$id,$year)
    {
        $builder = $this->db->table($tbl);
        $builder->select('');
        $builder->where($id);
        $builder->like($tbl.'.trans_date',$year,'after');
        $results=$builder->get()->getResult();
        $this->db->close();
        return $results;
    }
    //end end end 
}
