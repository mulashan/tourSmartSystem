<?php
namespace App\Models;
use CodeIgniter\Model;

class BillModel extends Model
{
   public function __construct(){
        $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    } 
public function get_legers($tbl){
		  $query = $this->db->table($tbl);
         return $query->get()->getResult();
	}
public	function accounts_chargedList1($id)
	{
		$builder = $this->db->table('accounts_tbl');
		$builder->select('id,account_name,description,status');
		$builder->where('id',$id);
		$result = $builder->get()->getResult();
		return $result;
	}

public	function getsupp()
	{
		$builder = $this->db->table('supplier_tbl');
		$builder->select('*');
		$result = $builder->get()->getResult();
		return $result;
	}
	////////////////// function to fetch approvals /////////////////
  public function get_approvals()
{
    $sub = $this->db->table('approval_history')
        ->select('app_no, MAX(hist_id) AS last_id')
        ->groupBy('app_no')
        ->getCompiledSelect(); // returns SQL string
    $builder = $this->db->table('approval_numbers');
    $builder->select('
        approval_numbers.*,
        transaction_types_tbl.*,
        name_type_tbl.*,
        transaction_numbers_tbl.*,
        ledger_transaction_tbl.*,
        approval_history.*,
        users.*
    ');
    $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = approval_numbers.trans_type');
    $builder->join('name_type_tbl', 'name_type_tbl.id = approval_numbers.name_type');
    $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = approval_numbers.trans_no AND transaction_numbers_tbl.trans_type_id = approval_numbers.trans_type');
    $builder->join('ledger_transaction_tbl', 'ledger_transaction_tbl.trans_no = approval_numbers.trans_no AND ledger_transaction_tbl.trans_type = approval_numbers.trans_type');
    $builder->join("($sub) AS latest", 'latest.app_no = approval_numbers.app_id', 'inner', false);
    $builder->join('approval_history', 'approval_history.hist_id = latest.last_id');
    $builder->join('users', 'approval_history.user = users.user_id');
    $builder->where('ledger_transaction_tbl.trans_item', 0);
    $builder->where('approval_history.hstatus', 3);
    $builder->whereIn('transaction_numbers_tbl.trans_type_id', [1, 4, 5, 8, 10]);
    $builder->whereIn('ledger_transaction_tbl.trans_type', [1, 4, 5, 8, 10]);
    $builder->groupBy(['approval_numbers.trans_no', 'approval_numbers.trans_type']);
    return $builder->get()->getResult();
}

	/////////////////// function to count approval ///////////////////
	function get_number_approval()
	{
		$builder = $this->db->table('approval_history');
		//$builder->join('approval_history','approval_history.app_no = approval_numbers.app_id');
		$builder->where('approval_history.hstatus = 3');
		$count = $builder->get()->getResult();
		return $count;
    }

	//function to generate transaction number
	function get_max_trans($tbl,$col){
      $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    $builder->where('trans_type_id', 4);
    return $builder->get()->getResult();
  }

  //function to save transaction data
  function save_transcation_data($tbl,$led)
  {
  	$query = $this->db->table($tbl)->insert($led);
  	 return $this->db->insertID();
  }

  /////////////// function to insert into budget table ///////////////
  function save_transaction_budget($tbl,$budget_ledger)
  {
  	$query = $this->db->table($tbl)->insert($budget_ledger);
  	return $query;
  }

  //////////// function to insert image /////////////////////
  function save_image_attachment($tbl,$atachment)
  {
  	$query = $this->db->table($tbl)->insert($atachment);
  	return $query;
  }

  ///////////////// function to save approval data //////////////////////
  	function save_approval_data($tbl,$data){
  		$query = $this->db->table($tbl)->insert($data);
  		 if($query)
    {
        return $this->db->insertID();
    }
    else{
        return false;
     }
  	}
  	/////////////////// function to insert approval history ////////////
  	function save_approval_history_data($tbl,$app_history)
  	{
  		$query = $this->db->table($tbl)->insert($app_history);
  		return $query;

  	}

   function get_item_name($tbl,$condition)
  {
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
      $query = $builder->get()->getResult();
      return $query;
 	}
   function get_item_name_desc($tbl,$condition,$id)
  {
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
      $builder->orderBy($id,"DESC");
      $query = $builder->get()->getResult();
      return $query;
  }

   public function check_ifExist($tbl,$id)
     {
        $builder = $this->db->table($tbl);
        $builder->select('');
        $builder->where($id);
        return $builder->get()->getResult();
     }

 /////////// function to insert data into table//////////
 function save_other_details($tbl,$data)
 {
 	$query= $this->db->table($tbl)->insert($data);
 	return $query;

 }


 public function get_trans_type($tno)
    {
       $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('accounts_tbl.account_name');
        // $builder->where('ledger_id',$ldg);
        $builder->join('accounts_tbl','accounts_tbl.id=ledger_transaction_tbl.ledger_id');
        $builder->where('ledger_transaction_tbl.trans_no',$tno);
        $item_result = $builder->get()->getResult();
        return $item_result; 
    }

    /////////////// function to get payer ////////////////////
    function get_supplierdetail($id)
    {
    	$builder= $this->db->table('supplier_tbl');
    	$builder->select('*');
    	$builder->where('supplier_id',$id);
    	$resu = $builder->get()->getResult();
    	return $resu;
    }

    //////////////// function to get budget name ////////////
    function get_budget_name($id)
    {
    	$builder = $this->db->table('transaction_budget_tbl');
    	$builder->select('*,transaction_budget_tbl.description');
    	$builder->join('accounts_tbl','accounts_tbl.id = transaction_budget_tbl.budget_ledger');
    	$builder->where('transaction_budget_tbl.lg_no',$id);
    	$resu = $builder->get()->getResult();
    	return $resu;
    }
    ///////////// function to store image data /////////////////
    function insert_imagedata($tbl,$data)
    {
      return $builder = $this->db->table($tbl)->insert($data);
    }

    ///////////////////// function to fetch date range data ///////////////
    function get_item_name2($tbl,$condition,$s,$e){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
      $builder->where('DATE(trans_date) >=', $s);
      $builder->where('DATE(trans_date) <=', $e);
      $builder->orderBy('id','DESC');
      $query = $builder->get()->getResult();
      return $query;
    }

    function get_filtered_bill($tbl,$condition,$s,$e){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->join('approval_numbers','approval_numbers.app_id=approval_history.app_no');
      if($condition != 4){
        $builder->where('hstatus',$condition);
      }
      $builder->where('approval_numbers.trans_type',4);
      $builder->where('DATE(hist_date) >=', $s);
      $builder->where('DATE(hist_date) <=', $e);
     // $builder->groupBy('approval_numbers.trans_no');
      $builder->orderBy('approval_history.hstatus','DESC');
      $query = $builder->get()->getResult();
      return $query;
    }
    ///////////////// function to get message number ///////
      function get_Bill_message($supplId,$tno){
        $builder = $this->db->table('messages');
        $builder->select('*');
        $builder->join('message_groups_tbl', 'message_groups_tbl.send_number = messages.send_no');
        $builder->where('messages.reference_no',$supplId);
        $builder->where('message_groups_tbl.trans_number',$tno);
        $builder->where('message_groups_tbl.message_type',1);
      $query = $builder->get()->getResult();
        return $query;
    }
    ///////////////// function to fetch initiator /////////////
    function get_initiator_name($transno)
    {
      $builder = $this->db->table('approval_history');
      $builder->select('*');
      $builder->join('users', 'users.user_id = approval_history.user');
      $builder->where('approval_history.app_no',$transno);
      $query = $builder->get()->getResult();
      return $query;
    }

    ////////////////////////////////// all bill data ///////////////////////
    function billdata($trans_number,$trans_type)
    {
      $builder = $this->db->table('approval_numbers');
      $builder->select('*');
      //$builder->join('users', 'users.user_id = approval_history.user');
      $builder->where('approval_numbers.trans_no',$trans_number);
       $builder->where('approval_numbers.trans_type',$trans_type);
      $query = $builder->get()->getResult();
      return $query;
    }

    function getdatabill($apid){
      $builder = $this->db->table('approval_history');
      $builder->select('*');
      $builder->join('users', 'users.user_id = approval_history.user');
      $builder->where('approval_history.app_no',$apid);
      $query = $builder->get()->getResult();
      return $query;
    }

    ////////////////////// function to fetch approved or rejected bills /////////////////
    function bill_response($transno)
    {
      $builder = $this->db->table('approval_history');
      $builder->select('*');
      $builder->join('users', 'users.user_id = approval_history.user');
      $builder->where('approval_history.app_no',$transno);
      $query = $builder->get()->getResult();
        return $query;
    }

 		//function to fetch Bills//
 	function get_bills($appno,$stats)
 	{
 		$builder=$this->db->table('ledger_transaction_tbl');
 		$builder->select('*');
 		$builder->join('supplier_tbl','supplier_tbl.supplier_id = ledger_transaction_tbl.name_id');
 		$builder->join('name_type_tbl','name_type_tbl.id = ledger_transaction_tbl.name_type_id');
 		$builder->join('account_types_tbl','account_types_tbl.id = ledger_transaction_tbl.ledger_type');
 		$builder->join('accounts_tbl','accounts_tbl.id = ledger_transaction_tbl.ledger_id');
 		$builder->join('transaction_types_tbl','transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
 		$builder->join('users','users.user_id = ledger_transaction_tbl.updated_by');
 		$builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
    $builder->join('approval_history','approval_history.app_no = transaction_numbers_tbl.trans_number');
 		$builder->where('ledger_transaction_tbl.trans_item = 0');
    $builder->where('approval_history.app_no = ',$appno);
    $builder->where('approval_history.hstatus = ',$stats);
        
 		$query = $builder->get()->getResult();
 		return $query;
 	}

 	//////////////////// function to fetch bill data ///////////////
 	function fetch_view_bill($id)
 	{
 		$builder= $this->db->table('ledger_transaction_tbl');
 		$builder->select('*');
 		$builder->join('supplier_tbl','supplier_tbl.supplier_id = ledger_transaction_tbl.name_id');
 		$builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
 		$builder->join('users','users.user_id = ledger_transaction_tbl.updated_by');
 		$builder->join('transaction_types_tbl','transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
 		$builder->where('ledger_transaction_tbl.trans_no',$id);
 		$builder->where('ledger_transaction_tbl.trans_item = 0');
 		$query = $builder->get()->getResult();
 		return $query;
 	}

	/////////////////////////// function to send approval informtion ////////////////////
    function save_approval_info($tbl,$data)
    {
        $query = $this->db->table($tbl)->insert($data);
        return $query;
    }

    function get_appr_status()
    {
      $builder = $this->db->table('approval_status_tbl');
      $builder->select('*');
      return $builder->get()->getResult();
    }

    //////////////// function to fetch data for bill edit ////////////////
    function get_edit_bill($id)
    {
      $builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('*');
      $builder->join('supplier_tbl','supplier_tbl.supplier_id = ledger_transaction_tbl.name_id');
      $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id=ledger_transaction_tbl.trans_type');
      $builder->join('transaction_other_details_tbl','transaction_other_details_tbl.transaction_no = ledger_transaction_tbl.trans_no');
      $builder->join('name_type_tbl','name_type_tbl.id = ledger_transaction_tbl.name_type_id');
      $builder->where('ledger_transaction_tbl.trans_no',$id);
       $builder->where('transaction_numbers_tbl.trans_type_id',4);
      $builder->where('transaction_other_details_tbl.transaction_type',4);
      $query=$builder->get()->getResult();
      return $query;
    }

    function update_bill($id,$id2,$data)
    {
      $builder=$this->db->table('ledger_transaction_tbl');
      $builder->where('trans_no',$id);
      $builder->where('ledger_id',$id2);
      $builder->update($data);

    }

     function update_table_details($table,$condition,$data){
        $builder = $this->db->table($table);
        $builder->where($condition);
        $builder->update($data);
    }
       function deleteimage($attch_id)
  {
    $builder=$this->db->table('transaction_attachments_tbl');
    $builder->where('id',$attch_id);
    $builder->delete();
  }

function get_all_credits($trans){
   $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('*');
    $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no');
     $builder->join('invoice_types_tbl', 'invoice_types_tbl.id= invoice_type_transaction.invoice_type_id');
        
      $builder->where('ledger_transaction_tbl.trans_no',$trans);
       $builder->where('invoice_type_transaction.transaction_type_id', 6);
       $builder->where('ledger_transaction_tbl.trans_type', 6);
       $builder->where('ledger_transaction_tbl.transation_nature', 1);
       $builder->where('ledger_transaction_tbl.ledger_type', 7);
       $builder->where('ledger_transaction_tbl.balance >', 0);
         $result = $builder->get()->getResult();
        return $result;    
 }
 function get_student_overpayment($nameId){
   $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('*');
    $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no');
     $builder->join('invoice_types_tbl', 'invoice_types_tbl.id= invoice_type_transaction.invoice_type_id');
       // $builder->join('accounts_tbl', 'accounts_tbl.id= ledger_transaction_tbl.ledger_id');
     
      // $builder->where('invoice_type_transaction.transaction_type_id', 2);
       $builder->where('ledger_transaction_tbl.name_id', $nameId);
       $builder->where('ledger_transaction_tbl.trans_item >', 0);
       $builder->where('ledger_transaction_tbl.ledger_id', 21);
       $builder->where('ledger_transaction_tbl.balance >', 0);
         $result = $builder->get()->getResult();
        return $result;    
 }

 function get_credit_items($tbl,$condition,$id){
$builder = $this->db->table($tbl);
$builder->select('*');
$builder->join('students', 'students.id= ledger_transaction_tbl.name_id');
$builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number= ledger_transaction_tbl.trans_no');
            
  $builder->where('transaction_numbers_tbl.trans_type_id', 6);
  $builder->where($condition);
  if($id >0){
    $builder->where('ledger_transaction_tbl.name_id', $id);
  }
  $builder->groupBy('trans_no');
     $result = $builder->get()->getResult();
        return $result; 

 }

 function get_all_overpayment($id){
   $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('*');
    $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no');
     $builder->join('invoice_types_tbl', 'invoice_types_tbl.id= invoice_type_transaction.invoice_type_id');
     $builder->join('students', 'students.id= ledger_transaction_tbl.name_id');
     $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number= ledger_transaction_tbl.trans_no');
       if($id >0){
         $builder->where('ledger_transaction_tbl.name_id', $id);
        }     
       $builder->where('transaction_numbers_tbl.trans_type_id', 2);
       $builder->where('ledger_transaction_tbl.trans_item >', 0);
       $builder->where('ledger_transaction_tbl.ledger_id', 21);
       $builder->where('ledger_transaction_tbl.balance >', 0);
        $builder->groupBy('ledger_transaction_tbl.trans_no');
         $result = $builder->get()->getResult();
        return $result;    
 }
  function get_max_payment($tbl,$col,$type){
     $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    $builder->where('trans_type_id', $type);
    return $builder->get()->getResult();
  }

  function get_refund_receipt($id){
   $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('*, amount as amount,amount as balance');
    $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no');
     $builder->join('invoice_types_tbl', 'invoice_types_tbl.id= invoice_type_transaction.invoice_type_id');
     $builder->join('students', 'students.id= ledger_transaction_tbl.name_id');
     $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number= ledger_transaction_tbl.trans_no');
            
       $builder->where('transaction_numbers_tbl.trans_number', $id);
       $builder->where('transaction_numbers_tbl.trans_type_id', 2);
       $builder->where('ledger_transaction_tbl.trans_type', 2);
       $builder->where('ledger_transaction_tbl.trans_no', $id);
       $builder->where('ledger_transaction_tbl.transation_nature', 1);
       $builder->where('ledger_transaction_tbl.ledger_id !=', 22);
        $builder->groupBy('ledger_transaction_tbl.trans_no');
         $result = $builder->get()->getResult();
        return $result;    
 }

  function get_bill_info($tbl,$condition,$id){
$builder = $this->db->table($tbl);
$builder->select('*,ledger_transaction_tbl.trans_type');
$builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no');
     $builder->join('invoice_types_tbl', 'invoice_types_tbl.id= invoice_type_transaction.invoice_type_id');
//$builder->join('students', 'students.id= ledger_transaction_tbl.name_id');
$builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number= ledger_transaction_tbl.trans_no');
$builder->join('approval_numbers', 'approval_numbers.trans_no= transaction_numbers_tbl.trans_number');
$builder->join('approval_history', 'approval_history.app_no= approval_numbers.app_id');
$builder->join('transaction_other_details_tbl', 'transaction_other_details_tbl.transaction_no= transaction_numbers_tbl.trans_number');
            
  $builder->where('transaction_other_details_tbl.transaction_type', 4);
  $builder->where('approval_history.hstatus', 1);
  $builder->where('transaction_numbers_tbl.trans_type_id', 4);
  $builder->where($condition);
  //$builder->where('ledger_transaction_tbl.trans_type', 4);
  if($id >0){
    $builder->where('ledger_transaction_tbl.name_id', $id);
  }
  $builder->where('invoice_type_transaction.transaction_type_id', 4);
  $builder->where('ledger_transaction_tbl.balance >', 0);
  $builder->groupBy('ledger_transaction_tbl.trans_no');
     $result = $builder->get()->getResult();
        return $result; 

 }
 
 function deletetable_data($tbl,$condition){
    $builder = $this->db->table($tbl);
    $builder->where($condition);
    $builder->delete();
}

function get_control_charges($tbl,$condition,$s,$e){

      $builder = $this->db->table($tbl);
      $builder->select('amount,balance,trans_number,trans_date,name_type_id,name_id');
    $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id=ledger_transaction_tbl.trans_type');
      $builder->where($condition);
      $builder->where('trans_type',2);
      $builder->where('ledger_id',22);
      $builder->where('DATE(trans_date) >=', $s);
      $builder->where('DATE(trans_date) <=', $e);
      //$builder->orderBy('id','DESC');
      $query = $builder->get()->getResult();
      return $query;
}

public function delete_Payment($trans_no,$app_no,$other,$data)
{
    // Start the transaction
    $this->db->transStart();
       
       if(count($data)>0){
        foreach ($data as $val) {

      $builder=$this->db->table('ledger_transaction_tbl');
      $builder->where('trans_no',$val->rct_no);
      $builder->where('trans_type',2);
      $builder->where('ledger_id',22);
      $query = $builder->get()->getResult();

      $rem=array(
        'balance'=>$query[0]->balance + $val->amount,
      );
         
      $builder=$this->db->table('ledger_transaction_tbl');
      $builder->where('trans_no',$val->rct_no);
      $builder->where('trans_type',2);
      $builder->where('ledger_id',22);
      $builder->update($rem);

        }
       }
    // First table deletion
    $builder = $this->db->table('voucher_relation_tbl');
    $builder->where('payment_no', $trans_no);
    $builder->delete();

    // Second table deletion
    $builder = $this->db->table('invoice_type_transaction');
    $builder->where('trans_no', $trans_no);
    $builder->where('transaction_type_id', 5);
    $builder->delete();

    // Third table deletion
    if($other==1){
     $builder = $this->db->table('pocket_money_transaction_tbl');
    $builder->where('transaction_no', $trans_no);
    $builder->delete(); 
    }
    
    if($other==2){
     $builder = $this->db->table('control_number_charges_payments_tbl');
    $builder->where('trans_no', $trans_no);
    $builder->delete(); 
    }

    // Fourth table deletion
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->where('trans_no', $trans_no);
    $builder->where('trans_type', 5);
    $builder->delete();

    // Fourth table deletion
    $builder = $this->db->table('approval_numbers');
    $builder->where('trans_no', $trans_no);
    $builder->where('trans_type', 5);
    $builder->delete();

    $builder = $this->db->table('approval_history');
    $builder->where('app_no', $app_no);
    $builder->delete();

    // Fifth table deletion
    $builder = $this->db->table('transaction_numbers_tbl');
    $builder->where('trans_number', $trans_no);
    $builder->where('trans_type_id', 5);
    $builder->delete();

    // Complete the transaction
    $this->db->transComplete();

    // Check transaction status
    if ($this->db->transStatus() === FALSE) {
        // If there was an error, rollback the transaction
        $this->db->transRollback();
        return false; // Indicate failure
    }

    // Close the database connection
    $this->db->close();
    return true; // Indicate success
}

function gettable_approve_data(){
  $builder = $this->db->table('pocket_money_transaction_tbl');
     $builder->select('transaction_no');
    $builder->join('approval_numbers', 'approval_numbers.trans_no = pocket_money_transaction_tbl.transaction_no');
     $builder->join('approval_history', 'approval_history.app_no = approval_numbers.app_id');
     // $builder->where('hstatus !=', 1);
     // $builder->where('hstatus !=', 2);
     $builder->groupBy('transaction_no');
     $query = $builder->get()->getResult();
      return $query;
}

function get_item_name3($name,$type,$year,$vtype,$table,$fname,$search_id){
      $builder = $this->db->table($table);
      $builder->select('*');
      $builder->like($fname,$name,'both');
      if($search_id==1){
        $builder->join('ledger_transaction_tbl','ledger_transaction_tbl.name_id='.$table.'.id');
      }
      if($search_id==2){
        $builder->join('ledger_transaction_tbl','ledger_transaction_tbl.name_id='.$table.'.supplier_id');
      }
       if($search_id==7){
        $builder->join('ledger_transaction_tbl','ledger_transaction_tbl.name_id='.$table.'.user_id');
      }
     
        $builder->where('ledger_transaction_tbl.name_type_id',$search_id);
     $builder->groupBy('ledger_transaction_tbl.trans_no');
      $builder->where('ledger_transaction_tbl.trans_type',$type);
      $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
       $builder->join('voucher_relation_tbl','voucher_relation_tbl.payment_no=transaction_numbers_tbl.trans_number');
      $builder->where('transaction_numbers_tbl.trans_type_id',$type);
      $builder->where('voucher_relation_tbl.voucher_type',$vtype);
       $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
      $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }
 
 public function delete_Payment_sms($trans_no,$app_no)
{
    // Start the transaction
    $this->db->transStart();
       
    // First table deletion
    $builder = $this->db->table('voucher_relation_tbl');
    $builder->where('payment_no', $trans_no);
    $builder->delete();

    // Second table deletion
    $builder = $this->db->table('invoice_type_transaction');
    $builder->where('trans_no', $trans_no);
    $builder->where('transaction_type_id', 5);
    $builder->delete();

    // Third table deletion
    // Fourth table deletion
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->where('trans_no', $trans_no);
    $builder->where('trans_type', 5);
    $builder->delete();

    // Fourth table deletion
    $builder = $this->db->table('approval_numbers');
    $builder->where('trans_no', $trans_no);
    $builder->where('trans_type', 5);
    $builder->delete();

    $builder = $this->db->table('approval_history');
    $builder->where('app_no', $app_no);
    $builder->delete();

    // Fifth table deletion
    $builder = $this->db->table('transaction_numbers_tbl');
    $builder->where('trans_number', $trans_no);
    $builder->where('trans_type_id', 5);
    $builder->delete();

    // Complete the transaction
    $this->db->transComplete();

    // Check transaction status
    if ($this->db->transStatus() === FALSE) {
        // If there was an error, rollback the transaction
        $this->db->transRollback();
        return false; // Indicate failure
    }

    // Close the database connection
    $this->db->close();
    return true; // Indicate success
}

function delete_Payment_refund($trans_no,$app_no,$ledger_id,$balance){
   $this->db->transStart();
     
     if($ledger_id > 0){
      $rem=array(
        'balance'=>$balance,
      );
         
      $builder=$this->db->table('ledger_transaction_tbl');
      $builder->where('id',$ledger_id);
      $builder->update($rem); 
      } 
    // First table deletion
    $builder = $this->db->table('voucher_relation_tbl');
    $builder->where('payment_no', $trans_no);
    $builder->delete();

    // Second table deletion
    $builder = $this->db->table('invoice_type_transaction');
    $builder->where('trans_no', $trans_no);
    $builder->where('transaction_type_id', 5);
    $builder->delete();

    // Third table deletion
    // Fourth table deletion
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->where('trans_no', $trans_no);
    $builder->where('trans_type', 5);
    $builder->delete();

    // Fourth table deletion
    $builder = $this->db->table('approval_numbers');
    $builder->where('trans_no', $trans_no);
    $builder->where('trans_type', 5);
    $builder->delete();

    $builder = $this->db->table('approval_history');
    $builder->where('app_no', $app_no);
    $builder->delete();

    // Fifth table deletion
    $builder = $this->db->table('transaction_numbers_tbl');
    $builder->where('trans_number', $trans_no);
    $builder->where('trans_type_id', 5);
    $builder->delete();

    // Complete the transaction
    $this->db->transComplete();

    // Check transaction status
    if ($this->db->transStatus() === FALSE) {
        // If there was an error, rollback the transaction
        $this->db->transRollback();
        return false; // Indicate failure
    }

    // Close the database connection
    $this->db->close();
    return true; // Indicate success
}

function get_payments($nature,$account,$sdate,$edate){
      $builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('
        transaction_numbers_tbl.trans_date,
        transaction_numbers_tbl.updated_by,
        transaction_numbers_tbl.trans_number,
         ledger_transaction_tbl.trans_type, 
         ledger_transaction_tbl.trans_item, 
         ledger_transaction_tbl.name_type_id, 
         ledger_transaction_tbl.trans_no, 
         amount, 
         ledger_transaction_tbl.transation_nature, 
         ledger_transaction_tbl.balance,
         transaction_types_tbl.type_name,
         ledger_transaction_tbl.name_id,
         ledger_transaction_tbl.ledger_id,
        accounts_tbl.description'
        );
      $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id =                     ledger_transaction_tbl.trans_type');
       $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
        $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
      $builder->where('ledger_transaction_tbl.ledger_id',$account);
      $builder->where('ledger_transaction_tbl.transation_nature',$nature);
      $builder->where('DATE(transaction_numbers_tbl.trans_date) >=', $sdate);
      $builder->where('DATE(transaction_numbers_tbl.trans_date) <=', $edate);
      $builder->where('transaction_numbers_tbl.status', 1);
      $builder->where('transaction_numbers_tbl.reconciled', 0);
      
      //$builder->groupBy('trans_no');
      $builder->orderBy('trans_date', 'asc');
      $builder->orderBy('trans_no', 'asc');
      $query = $builder->get()->getResult();
         $this->db->close();
      return $query;
 }

 function get_max_reconciliation($tbl,$col){
     $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    // $builder->where('trans_type_id', $type);
    return $builder->get()->getResult();
  }

  function check_reconcilitoion($id){
$builder = $this->db->table('reconciliation_tbl');
$builder->select('*');
$builder->where('account_id', $id);
$builder->orderBy('id', 'DESC');
$builder->limit(1);
return $builder->get()->getResult();
  }

function get_max_trans_open($tbl,$col){
      $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    $builder->where('trans_type_id', 9);
    return $builder->get()->getResult();
  }
  
    function get_reconciled_payments($nature,$account,$trans){
      $builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('
        transaction_numbers_tbl.trans_date,
        transaction_numbers_tbl.updated_by,
        transaction_numbers_tbl.trans_number,
         ledger_transaction_tbl.trans_type, 
         ledger_transaction_tbl.trans_item, 
         ledger_transaction_tbl.name_type_id, 
         ledger_transaction_tbl.trans_no, 
         amount, 
         ledger_transaction_tbl.transation_nature, 
         ledger_transaction_tbl.balance,
         transaction_types_tbl.type_name,
         ledger_transaction_tbl.name_id, 
         ledger_transaction_tbl.ledger_id,
        accounts_tbl.description'
        );
      $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id =                     ledger_transaction_tbl.trans_type');
       $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
        $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
      $builder->where('ledger_transaction_tbl.ledger_id',$account);
      $builder->where('ledger_transaction_tbl.transation_nature',$nature);
     $builder->where('transaction_numbers_tbl.status', 1);
      $builder->where('transaction_numbers_tbl.reconciled', $trans);
      
      //$builder->groupBy('trans_no');
      $builder->orderBy('trans_date', 'asc');
      $builder->orderBy('trans_no', 'asc');
      $query = $builder->get()->getResult();
         $this->db->close();
      return $query;
 }

function get_payments_uncleared($nature,$account,$sdate,$edate,$trans_no){
      $builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('
        transaction_numbers_tbl.trans_date,
        transaction_numbers_tbl.updated_by,
        transaction_numbers_tbl.trans_number,
         ledger_transaction_tbl.trans_type, 
         ledger_transaction_tbl.trans_item, 
         ledger_transaction_tbl.name_type_id, 
         ledger_transaction_tbl.trans_no, 
         amount, 
         ledger_transaction_tbl.transation_nature, 
         ledger_transaction_tbl.balance,
         transaction_types_tbl.type_name,
         ledger_transaction_tbl.name_id, 
         ledger_transaction_tbl.ledger_id,
        accounts_tbl.description'
        );
      $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id =                     ledger_transaction_tbl.trans_type');
       $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
        $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
      $builder->where('ledger_transaction_tbl.ledger_id',$account);
      $builder->where('ledger_transaction_tbl.transation_nature',$nature);
      $builder->where('DATE(transaction_numbers_tbl.trans_date) >=', $sdate);
      $builder->where('DATE(transaction_numbers_tbl.trans_date) <=', $edate);
      $builder->where('transaction_numbers_tbl.status', 1);
      $builder->whereNotIn('transaction_numbers_tbl.reconciled', $trans_no);
      // $builder->where('transaction_numbers_tbl.reconciled', 0);
      
      //$builder->groupBy('trans_no');
      $builder->orderBy('trans_date', 'asc');
      $builder->orderBy('trans_no', 'asc');
      $query = $builder->get()->getResult();
         $this->db->close();
      return $query;
 }
 public function GetGovernmentLedgers($ledger,$gov_ledger,$year,$month){
    $builder = $this->db->table('ledger_transaction_tbl');
          $builder->select('
        users.first_name,
        users.last_name,
        ledger_transaction_tbl.id,
        ledger_transaction_tbl.ledger_id,
        ledger_transaction_tbl.trans_item,
        ledger_transaction_tbl.ledger_type,
        ledger_transaction_tbl.trans_no,
        ledger_transaction_tbl.trans_type,
        ledger_transaction_tbl.amount,
        ledger_transaction_tbl.transation_nature,
        ledger_transaction_tbl.name_type_id,
        ledger_transaction_tbl.name_id,
        MIN(ledger_transaction_tbl.balance) AS balance,
        payrolls_tbl.payroll_id,
        payrolls_tbl.payroll_year,
        payrolls_tbl.payroll_date,
        government_tbl.institution_id,
        government_tbl.institution_name,
        months.month
    ');
      $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
      $builder->join('accounts_tbl','accounts_tbl.id=ledger_transaction_tbl.ledger_id');
      $builder->join('payrolls_tbl','payrolls_tbl.transaction_id=ledger_transaction_tbl.trans_no');
      $builder->join('users','users.user_id=payrolls_tbl.created_by');
      $builder->join('government_leger_tbl','government_leger_tbl.ledger_id=ledger_transaction_tbl.ledger_id');
      $builder->join('government_tbl','government_tbl.institution_id=government_leger_tbl.government_id');
       $builder->join('months','months.month_id=payrolls_tbl.payroll_month');
     $builder->join('approval_numbers','approval_numbers.trans_no=transaction_numbers_tbl.trans_number');
      $builder->join('approval_history','approval_history.app_no=approval_numbers.app_id');
   $builder->where('ledger_transaction_tbl.trans_type', $ledger);
   $builder->where('transaction_numbers_tbl.trans_type_id', $ledger);
   $builder->where('payrolls_tbl.transaction_type_id', $ledger);
   $builder->where('ledger_transaction_tbl.ledger_id', $gov_ledger);
      $builder->where('approval_numbers.trans_type', $ledger);
      $builder->where('approval_history.hstatus', 1);
      $builder->where('approval_history.user_role', 3);
    //  $builder->where('ledger_transaction_tbl.balance !=', 0);
      $builder->having('MIN(ledger_transaction_tbl.balance) >', 0);

         if($month>0 && $year>0){
   $builder->where('payrolls_tbl.payroll_year', $year);
   $builder->where('payrolls_tbl.payroll_month', $month);
      }
      elseif($month>0 && $year==0){
 $builder->where('payrolls_tbl.payroll_month', $month);
      }
      elseif($month==0 && $year>0){
        $builder->where('payrolls_tbl.payroll_year', $year);  
      }
 $builder->groupBy('payrolls_tbl.payroll_id');
 //$builder->groupBy('ledger_transaction_tbl.trans_no');
    $query = $builder->get()->getResult();
    return $query;
 }


 public function GetStaffLedgers($ledger,$year,$month){
          $builder = $this->db->table('payrolls_tbl');
    $builder->select('
      users.first_name, 
      users.last_name,
      ledger_transaction_tbl.id,
      ledger_transaction_tbl.ledger_id,
      ledger_transaction_tbl.ledger_type,
      ledger_transaction_tbl.name_type_id,
      ledger_transaction_tbl.amount,
      ledger_transaction_tbl.balance,
      staff_payrolls_tbl.net_salary_balances,
      staff_payrolls_tbl.net_salaries,
      staff_payrolls_tbl.staff_id,
      staff_payrolls_tbl.staffpayroll_id,
      payrolls_tbl.created_by,
      payrolls_tbl.payroll_year,
      payrolls_tbl.payroll_date,
      payrolls_tbl.payroll_id,
      months.month');
      $builder->join('months','months.month_id=payrolls_tbl.payroll_month');
      $builder->join('staff_payrolls_tbl','staff_payrolls_tbl.payroll_ids=payrolls_tbl.payroll_id');
      $builder->join('ledger_transaction_tbl','ledger_transaction_tbl.trans_no=payrolls_tbl.transaction_id');
      $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
      $builder->join('users','users.user_id=staff_payrolls_tbl.staff_id');
        $builder->join('approval_numbers','approval_numbers.trans_no=transaction_numbers_tbl.trans_number');
      $builder->join('approval_history','approval_history.app_no=approval_numbers.app_id');
      $builder->where('ledger_transaction_tbl.trans_type', $ledger);
      $builder->where('ledger_transaction_tbl.ledger_id',54);
      $builder->where('transaction_numbers_tbl.trans_type_id', $ledger);
            $builder->where('approval_numbers.trans_type', $ledger);
      $builder->where('approval_history.hstatus', 1);
      $builder->where('approval_history.user_role', 3);
      $builder->having('staff_payrolls_tbl.net_salary_balances >', 0);
      if($month>0 && $year>0){
   $builder->where('payrolls_tbl.payroll_year', $year);
   $builder->where('payrolls_tbl.payroll_month', $month);
      }
      elseif($month>0 && $year==0){
 $builder->where('payrolls_tbl.payroll_month', $month);
      }
      elseif($month==0 && $year>0){
        $builder->where('payrolls_tbl.payroll_year', $year);  
      }
    $query = $builder->get()->getResult();
    return $query;
 }

 public function get_creator($creator){
     $builder = $this->db->table('users');
    $builder->select('users.first_name, users.last_name');
    $builder->where('users.user_id',$creator);
    $query = $builder->get()->getRow();
    return $query;
 }
  function get_government_name(){
      $builder = $this->db->table('accounts_tbl');
      $builder->select('accounts_tbl.id, accounts_tbl.account_name,government_tbl.institution_name');
      $builder->join('government_leger_tbl','government_leger_tbl.ledger_id=accounts_tbl.id');
     // $builder->join('ledger_transaction_tbl','ledger_transaction_tbl.ledger_id=accounts_tbl.id');
      $builder->join('government_tbl','government_tbl.institution_id=government_leger_tbl.government_id');
      $builder->groupBy('accounts_tbl.id');
      $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }
   function get_ledgers_name($account){
      $builder = $this->db->table('accounts_tbl');
      $builder->select('accounts_tbl.id, accounts_tbl.account_name,government_tbl.institution_name');
      $builder->join('government_leger_tbl','government_leger_tbl.ledger_id=accounts_tbl.id');
         $builder->join('government_tbl','government_tbl.institution_id=government_leger_tbl.government_id');
      $builder->where('accounts_tbl.id',$account);
      $query = $builder->get()->getRow();
      $this->db->close();
      return $query;
 }
   function get_months_name($month){
      $builder = $this->db->table('months');
      $builder->select('months.month');
      $builder->where('month_id',$month);
      $query = $builder->get()->getRow();
      $this->db->close();
      return $query;
 }
function update_current_balance($condition, $data) {
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->where($condition);
    $builder->update($data);

}

public function search_staff_names($search){
$builder = $this->db->table('staff_details_tbl');
$builder->join('users','users.user_id=staff_details_tbl.user_id');;

$builder->groupStart()
    ->where('first_name', $search)
    ->orLike('other_name', $search)
    ->orLike('first_name', $search)
    ->orLike('last_name', $search)
->groupEnd();
$names = $builder->get()->getResult();
return $names;
}
public function get_staff_data($data,$transNo){
$builder = $this->db->table('staff_payrolls_tbl');
  $builder->select('staff_payrolls_tbl.*,users.first_name,users.last_name,staff_details_tbl.pension_no,staff_details_tbl.tin_no,staff_details_tbl.nhf_no,staff_details_tbl.wcf_no,job_tittle_tbl.job_tittle,departments_tbl.dep_name,months.month,months.month_id,payrolls_tbl.payroll_year,transaction_numbers_tbl.trans_date,transaction_numbers_tbl.trans_number,payroll_payments_relations_tbl.amount_paid');
$builder->join('users','users.user_id=staff_payrolls_tbl.staff_id');
$builder->join('staff_details_tbl','staff_details_tbl.user_id=staff_payrolls_tbl.staff_id');
$builder->join('job_tittle_tbl','job_tittle_tbl.id=staff_details_tbl.job_id');
$builder->join('departments_tbl','departments_tbl.id=staff_details_tbl.dep_id');
$builder->join('payrolls_tbl','payrolls_tbl.payroll_id=staff_payrolls_tbl.payroll_ids');
$builder->join('months','months.month_id=payrolls_tbl.payroll_month');
$builder->join('ledger_transaction_tbl','ledger_transaction_tbl.name_id=staff_payrolls_tbl.staff_id');
$builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id=ledger_transaction_tbl.trans_type');
$builder->join('payroll_payments_relations_tbl','payroll_payments_relations_tbl.payroll_payment_id=transaction_numbers_tbl.trans_number AND payroll_payments_relations_tbl.staff_id=staff_payrolls_tbl.staff_id');
$builder->where('staff_details_tbl.user_id',$data);
$builder->where('ledger_transaction_tbl.trans_type',5);
$builder->where('transaction_numbers_tbl.trans_number',$transNo);
//$builder->join('users','users.user_id=staff_payrolls_tbl.staff_id');
$names = $builder->get()->getRow();
return $names;
}
public function get_staff_netsalary($transNo,$data){
  $builder = $this->db->table('payroll_payments_relations_tbl');
  $builder->select('staff_payrolls_tbl.net_salaries');
  $builder->join('staff_payrolls_tbl','staff_payrolls_tbl.payroll_ids=payroll_payments_relations_tbl.payroll_id');
  $builder->where('staff_payrolls_tbl.staff_id',$data);
  $builder->where('payroll_payments_relations_tbl.staff_id',$data);
$builder->where('payroll_payments_relations_tbl.payroll_payment_id',$transNo);
$names = $builder->get()->getRow();
return $names;
}
    public function get_database($user_id,$db){
             $builder = $this->db->table('users');
        $builder->select('database_list_tbl.db_name');        
             $builder->join('database_list_tbl', 'database_list_tbl.id = users.database_id');
        $builder->where('users.user_id',$user_id);
        $builder->where('database_list_tbl.db_id',$db);
        $query = $builder->get()->getRow();
         $this->db->close();   
         return $query; 

    }
    public function get_staff_payrollData($trans_no){
      $builder = $this->db->table('payroll_payments_relations_tbl');
  $builder->select('users.first_name,users.user_id,users.last_name,users.phone_no,users.database_id,transaction_numbers_tbl.trans_date,payrolls_tbl.payroll_year,months.month,payroll_payments_relations_tbl.amount_paid');
$builder->join('users','users.user_id=payroll_payments_relations_tbl.staff_id');
$builder->join('payrolls_tbl','payrolls_tbl.payroll_id=payroll_payments_relations_tbl.payroll_id');
$builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=payroll_payments_relations_tbl.payroll_payment_id');
$builder->join('months','months.month_id=payrolls_tbl.payroll_month');
$builder->where('payroll_payments_relations_tbl.payroll_payment_id',$trans_no);
$builder->where('transaction_numbers_tbl.trans_type_id',5);
$names = $builder->get()->getRow();
return $names;

    }
            public function get_staff_advance($trans_no){
      $builder = $this->db->table('salary_advances_schedule_tbl');
  $builder->select('users.first_name,users.user_id,users.last_name,users.phone_no,users.database_id,transaction_numbers_tbl.trans_date,salary_advances_schedule_tbl.payroll_year,months.month,SUM(salary_advances_schedule_tbl.advance_amount) AS advance_amount');
$builder->join('users','users.user_id=salary_advances_schedule_tbl.staff_id');
$builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=salary_advances_schedule_tbl.transaction_id');
$builder->join('months','months.month_id=salary_advances_schedule_tbl.payroll_month');
$builder->where('salary_advances_schedule_tbl.transaction_id',$trans_no);
$builder->where('transaction_numbers_tbl.trans_type_id',5);
$names = $builder->get()->getResult();
return $names;
    }
    public function delete_Payment_advance($trans_no){
    $builder=$this->db->table('salary_advances_schedule_tbl');
    $builder->where('transaction_id',$trans_no);
    return $builder->delete();
    }
    public function Check_salary_advance($trans_no){
$builder = $this->db->table('salary_advances_schedule_tbl');
  $builder->select('salary_advances_schedule_tbl.payroll_year,months.month,salary_advances_schedule_tbl.advance_amount');
$builder->join('months','months.month_id=salary_advances_schedule_tbl.payroll_month');
$builder->where('salary_advances_schedule_tbl.transaction_id',$trans_no);
$names = $builder->get()->getResult();
return $names;
    }
    
    public function payroll_approval($trans_no,$trans_type){
     $builder = $this->db->table('payrolls_tbl');
    $builder->select('
      users.first_name, 
      users.last_name,
      ledger_transaction_tbl.id,
      ledger_transaction_tbl.ledger_id,
      ledger_transaction_tbl.ledger_type,
      ledger_transaction_tbl.name_type_id,
      ledger_transaction_tbl.amount,
      ledger_transaction_tbl.trans_type,
      ledger_transaction_tbl.balance,
      staff_payrolls_tbl.net_salary_balances,
      staff_payrolls_tbl.net_salaries,
      staff_payrolls_tbl.staff_id,
      staff_payrolls_tbl.staffpayroll_id,
      payrolls_tbl.created_by,
      payrolls_tbl.payroll_year,
      payrolls_tbl.payroll_date,
      payrolls_tbl.payroll_id,
      transaction_types_tbl.type_name,
      transaction_numbers_tbl.trans_number,
      transaction_numbers_tbl.trans_date,
      months.month');
      $builder->join('months','months.month_id=payrolls_tbl.payroll_month');
      $builder->join('staff_payrolls_tbl','staff_payrolls_tbl.payroll_ids=payrolls_tbl.payroll_id');
      $builder->join('ledger_transaction_tbl','ledger_transaction_tbl.trans_no=payrolls_tbl.transaction_id');
      $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
      $builder->join('users','users.user_id=staff_payrolls_tbl.staff_id');
    $builder->join('voucher_relation_tbl','voucher_relation_tbl.trans_no=transaction_numbers_tbl.trans_number');
      $builder->join('transaction_types_tbl','transaction_types_tbl.type_id=transaction_numbers_tbl.trans_type_id');
$builder->where('transaction_numbers_tbl.trans_number', $trans_no);
$builder->where('transaction_numbers_tbl.trans_type_id', $trans_type);
$builder->groupBy('users.user_id');
     $query = $builder->get()->getResult();
    return $query;
    }

    public function payroll_approval_ledger($trans_no,$trans_type){
       $builder = $this->db->table('ledger_transaction_tbl');
    $builder->select('
      accounts_tbl.account_name, 
      account_types_tbl.type_name, 
      accounts_tbl.id,
      ledger_transaction_tbl.id,
      ledger_transaction_tbl.ledger_id,
      ledger_transaction_tbl.amount,
      ledger_transaction_tbl.transation_nature,
      ledger_transaction_tbl.ledger_type');
       $builder->join('accounts_tbl','accounts_tbl.id=ledger_transaction_tbl.ledger_id');
        $builder->join('account_types_tbl','account_types_tbl.id=accounts_tbl.account_type_id');
$builder->where('ledger_transaction_tbl.trans_no', $trans_no);
$builder->where('ledger_transaction_tbl.trans_type', $trans_type);
$builder->groupBy('accounts_tbl.id');
$builder->orderBy('ledger_transaction_tbl.transation_nature', 'DESC');
   $query = $builder->get()->getResult();
    return $query;
    }
public function viewpayrollData($trans_id){
     $builder = $this->db->table('staff_payrolls_tbl');
     $builder->select('users.status,users.first_name, users.last_name,departments_tbl.dep_name,job_tittle_tbl.job_tittle,staff_payrolls_tbl.*, months.month,payrolls_tbl.payroll_year,months.month,staff_details_tbl.*,staff_status.*');
     $builder->join('users','users.user_id=staff_payrolls_tbl.staff_id');
     $builder->join('staff_details_tbl','staff_details_tbl.user_id=staff_payrolls_tbl.staff_id');
     $builder->join('departments_tbl','departments_tbl.id=staff_details_tbl.dep_id');
      $builder->join('job_tittle_tbl','job_tittle_tbl.id=staff_details_tbl.job_id'); 
      $builder->join('payrolls_tbl','payrolls_tbl.payroll_id=staff_payrolls_tbl.payroll_ids'); 
        $builder->join('months', 'months.month_id = payrolls_tbl.payroll_month');
         $builder->join('staff_status', 'staff_status.status_id = staff_details_tbl.status');
          $builder->where('payrolls_tbl.transaction_id',$trans_id);
      $builder->groupBy('staff_details_tbl.id'); 
     return $builder->get()->getResult();
}
    function get_item_approval($tbl,$s,$e){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where('trans_type_id',5 );
     //$builder->orWhere('trans_type_id', 10);
      $builder->where('DATE(trans_date) >=', $s);
      $builder->where('DATE(trans_date) <=', $e);
      $builder->orderBy('id','DESC');
      $query = $builder->get()->getResult();
      return $query;
    }
 public function GetApprovalPayroll($trans_no){
    $builder = $this->db->table('payrolls_tbl');
     $builder->select('payrolls_tbl.payroll_id,months.month,payrolls_tbl.payroll_year,payrolls_tbl.payroll_date,payrolls_tbl.payroll_date, users.first_name, users.last_name,payrolls_tbl.create_date, SUM(staff_payrolls_tbl.net_salary_balances) AS balance,SUM(staff_payrolls_tbl.basic_salary) AS basic_salary,SUM(staff_payrolls_tbl.allowances) AS allowances');
     $builder->join('users','users.user_id=payrolls_tbl.created_by');
     $builder->join('staff_payrolls_tbl','staff_payrolls_tbl.payroll_ids=payrolls_tbl.payroll_id');
     $builder->join('months','months.month_id=payrolls_tbl.payroll_month');
      $builder->where('payrolls_tbl.transaction_id',$trans_no);
      $builder->groupBy('payrolls_tbl.payroll_id');
     return $builder->get()->getRow();
}
     public function get_vouchername($trans_no){
        $builder = $this->db->table('voucher_relation_tbl');
     $builder->select('voucher_types_tbl.voucher_type_name, voucher_types_tbl.id');
     $builder->join('voucher_types_tbl','voucher_types_tbl.id=voucher_relation_tbl.voucher_type');
            $builder->where('voucher_relation_tbl.trans_no',$trans_no);
            $builder->where('voucher_relation_tbl.trans_type',10);
     return $builder->get()->getRow();
    }
        public function ovetime_approval($trans_no, $trans_type)
{
    $builder = $this->db->table('overtime_schedule_tbl');
    $builder->select('
        users.first_name, 
        users.last_name,
        staff_details_tbl.basic_salary,
        overtime_schedule_tbl.*,
        transaction_numbers_tbl.trans_number,
        transaction_numbers_tbl.trans_date,
        transaction_types_tbl.type_name,
        months.month
    ');

    $builder->join('months','months.month_id=overtime_schedule_tbl.payroll_month');
    $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=overtime_schedule_tbl.transation_number');
    $builder->join('users','users.user_id=overtime_schedule_tbl.staff_id');
    $builder->join('staff_details_tbl','staff_details_tbl.user_id=overtime_schedule_tbl.staff_id');
    $builder->join('transaction_types_tbl','transaction_types_tbl.type_id=transaction_numbers_tbl.trans_type_id');
    $builder->where('transaction_numbers_tbl.trans_number', $trans_no);
    $builder->where('overtime_schedule_tbl.transation_number', $trans_no);
    $builder->where('transaction_numbers_tbl.trans_type_id', $trans_type);

    return $builder->get()->getResult();
}
    public function payrollTransID($payroll_id){
               $builder = $this->db->table('payrolls_tbl');
            $builder->select('payrolls_tbl.transaction_id' );
                      $builder->where('payrolls_tbl.payroll_id',$payroll_id);
                      $builder->where('payrolls_tbl.transaction_type_id',10);
          return $builder->get()->getRow();
    }
    
public function GetpayrollID($trans){
  $builder = $this->db->table('payroll_payments_relations_tbl');
   $builder->select('payrolls_tbl.*');
  $builder->join('payrolls_tbl','payrolls_tbl.payroll_id=payroll_payments_relations_tbl.payroll_id');
$builder->where('payroll_payments_relations_tbl.payroll_payment_id',$trans);
$names = $builder->get()->getRow();
return $names;
}
public function GetStaffBalance($data){
  $builder = $this->db->table('staff_payrolls_tbl');
  $builder->select('staff_payrolls_tbl.net_salary_balances');
$builder->where($data);
$names = $builder->get()->getRow();
return $names;
}
public function GetAppData($data){
  $builder = $this->db->table('approval_numbers');
  $builder->select('approval_numbers.app_id');
$builder->where($data);
$names = $builder->get()->getRow();
return $names;
}
public function GetNameType($trans_no){
  $builder = $this->db->table('ledger_transaction_tbl');
  $builder->select('ledger_transaction_tbl.name_type_id');
    $builder->where('ledger_transaction_tbl.trans_no', $trans_no);
   $builder->where('ledger_transaction_tbl.trans_type', 5);
$names = $builder->get()->getRow();
return $names;
}
public function GetBankID($trans_no,$staff_id){
     $builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('ledger_transaction_tbl.ledger_id,ledger_transaction_tbl.balance');
  $builder->join('accounts_tbl','accounts_tbl.id=ledger_transaction_tbl.ledger_id');
  $builder->join('account_types_tbl','account_types_tbl.id=ledger_transaction_tbl.ledger_type');
    $builder->where('ledger_transaction_tbl.trans_no', $trans_no);
    $builder->where('ledger_transaction_tbl.name_id', $staff_id);
    $builder->where('ledger_transaction_tbl.trans_type', 5);
    $builder->where('ledger_transaction_tbl.ledger_type', 9);
    return $builder->get()->getRow();
}
public function GetNetSalaryData($data){
  $builder = $this->db->table('ledger_transaction_tbl');
  $builder->select('ledger_transaction_tbl.*');
$builder->where($data);
$names = $builder->get()->getRow();
return $names;
}
public function update_staffpaybalance($where,$data){
   $builder=$this->db->table('staff_payrolls_tbl');
      $builder->where($where);
      return $builder->update($data);

}
public function DeleteLedgertafftData($trans_no,$staff_id){
     $builder = $this->db->table('ledger_transaction_tbl');
    $builder->where('trans_no', $trans_no);
    $builder->where('name_id', $staff_id);
    $builder->where('trans_type', 5);
    return $builder->delete();
}
public function DeletePaymentRelationData($trans_no,$staff_id,$payroll_id){
      $builder = $this->db->table('payroll_payments_relations_tbl');
    $builder->where('payroll_id', $payroll_id);
    $builder->where('staff_id', $staff_id);
    $builder->where('payroll_payment_id', $trans_no);
     return $builder->delete();
}
public function DeleteApprovalData($trans_no,$staff_id,$payroll_id){
      $builder = $this->db->table('approval_numbers');
    $builder->where('name_type', 7);
    $builder->where('name', $staff_id);
    $builder->where('trans_no', $trans_no);
    $builder->where('trans_type', 5);
 return $builder->delete();
}
public function DeleteVoucherRelationData($data){
      $builder = $this->db->table('voucher_relation_tbl');
    $builder->where($data);
    return $builder->delete();
}
public function DeleteSMSgroupData($data){
      $builder = $this->db->table('message_groups_tbl');
    $builder->where($data);
   return $builder->delete();
}
public function Delete_bank_balance($condition) {
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->where($condition);
  return  $builder->delete();

}
public function update_staff_balance($condition, $data) {
    $builder = $this->db->table('staff_payrolls_tbl');
    $builder->where($condition);
    $builder->update($data);

}
 public function get_institution_name($inst_id){
      $builder = $this->db->table('government_tbl');
      $builder->select('government_tbl.institution_name,government_tbl.institution_id');
      $builder->where('government_tbl.institution_id',$inst_id);
      $query = $builder->get()->getRow();
      $this->db->close();
      return $query;
 }
 public function DeleteGovApprovalData($trans_no,$staff_id,$payroll_id){
      $builder = $this->db->table('approval_numbers');
    $builder->where('name_type', 8);
    $builder->where('name', $staff_id);
    $builder->where('trans_no', $trans_no);
    $builder->where('trans_type', 5);
 return $builder->delete();
}

}
?>
