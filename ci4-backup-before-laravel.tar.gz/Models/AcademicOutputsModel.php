<?php
// By chanangwa E,
namespace App\Models;
use CodeIgniter\Model;
class AcademicOutputsModel extends Model
{

     public function __construct(){
       $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
      
   }
    function FetchReports($class,$classlevel,$stream,$year,$status){
    $query = $this->db->table('admission_tbl');
    $query->select('
        students.birth_date,
        students.id,
        admission_tbl.date_joined,
        admission_tbl.class_id,
        admission_tbl.level_id,
        admission_tbl.academic_year,
        admission_tbl.admission_type,
        admission_tbl.adimit_for,
        students.gender,
        students.student_id,
        classes_tbl.class_name,
        streams_tbl.stream_name,
        streams_tbl.id AS stream_id,
        class_level_tbl.level_name,
        class_level_tbl.government_level_id,
       students.full_name,
       students.status,
       students.first_name,'
    ); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
    $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
     $query->join('students', 'students.id = admission_tbl.student_id');
     if($class >0 && $classlevel>0 && $stream==0){
    
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
     if($status>0){
      $query->where('students.status', $status);
     }
    }
    elseif($class ==0 && $classlevel>0 && $stream==0){
     
     $query->where('admission_tbl.level_id', $classlevel);
     if($status>0){
      $query->where('students.status', $status);
     }
    }
elseif($class >0 && $classlevel==0 && $stream==0){
    $query->where('admission_tbl.class_id', $class);
    if($status>0){
      $query->where('students.status', $status);
     }
    }
elseif($class >0 && $classlevel>0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
     if($status>0){
      $query->where('students.status', $status);
     }
    }
    elseif($class >0 && $classlevel==0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
     $query->where('admission_tbl.class_id', $class);
     if($status>0){
      $query->where('students.status', $status);
     }
    }
    elseif($class==0 && $classlevel==0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
   if($status>0){
      $query->where('students.status', $status);
     }
     
    }
    if($status>0){
      $query->where('students.status', $status);
     }
    $query->where('admission_tbl.academic_year', $year);
    $query->orderBy('students.full_name','ASC');
   //$query->orderBy('streams_tbl.id','ASC');
      
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
      public function StudentReport($id,$year){
 $query = $this->db->table('admission_tbl');
    $query->select('
        students.birth_date,
        students.id,
        admission_tbl.date_joined,
        admission_tbl.class_id,
        admission_tbl.level_id,
        admission_tbl.academic_year,
        admission_tbl.admission_type,
        admission_tbl.adimit_for,
        students.gender,
        students.student_id,
        classes_tbl.class_name,
        streams_tbl.stream_name,
        class_level_tbl.level_name,
       students.full_name,
       students.status,
       students.first_name,'
    ); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
    $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
     $query->join('students', 'students.id = admission_tbl.student_id');
     $query->where('students.id',$id);
     $query->where('admission_tbl.academic_year',$year);
     $result= $query->get()->getRow();
     $this->db->close();
    return $result;
   }

public function getTotalStudents($year,$class,$pre_stream,$stream)
{
    $query = $this->db->table('admission_tbl');
    $query->selectCount('students.id', 'total_students');
    $query->join('students', 'students.id = admission_tbl.student_id');
    $query->where('admission_tbl.academic_year', $year);
    $query->where('admission_tbl.class_id', $class);
    if($pre_stream>0){
        $query->where('admission_tbl.stream_id', $stream);
            $result = $query->get()->getRow();
    $this->db->close();
    return $result->total_students;
    }else{
  $result = $query->get()->getRow();
    $this->db->close();
    return $result->total_students;
    }

}
public function getStudentRanking($year, $term, $stream_id, $examtype_id, $class_id)
{
    $builder = $this->db->table('exam_results_tbl');
    $builder->select('students.id as student_id, SUM(marks_scored) as total_marks');
    $builder->join('students', 'students.id = exam_results_tbl.student_id');
    $builder->join('admission_tbl', 'admission_tbl.student_id = students.id');
    $builder->where('admission_tbl.academic_year', $year);
    $builder->where('admission_tbl.stream_id', $stream_id);
    $builder->where('admission_tbl.class_id', $class_id);
    // $builder->where('exam_results_tbl.term', $term);
    $builder->where('exam_results_tbl.exam_type_id', $examtype_id);

    $builder->groupBy('students.id');
    $builder->orderBy('total_marks', 'DESC');

    return $builder->get()->getResult(); // returns list of students and their marks
}


   public function StudentCharacterResult($id,$year){
    $query = $this->db->table('character_results_tbl');
     $query->select('character_results_tbl.grade_id, character_results_tbl.character_id, grades_tbl.grade_name ');
       $query->join('grades_tbl', 'character_results_tbl.grade_id=grades_tbl.grade_id');
     $query->where('character_results_tbl.student_id',$id);
         $query->where('character_results_tbl.academic_yr',$year);
     return $query->get()->getResult(); 
   }
      function student_search_byname($name,$year){
    $query = $this->db->table('class_list_view');
    $query->select('');
     $query->where('class_list_view.academic_year', $year);
    $query->orderBy('class_list_view.full_name','ASC');
     $query->like('class_list_view.full_name',$name,'both');
      
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;

   }
   public function GetSubjectsByStreamReport($class,$stream) {
    $query = $this->db->table('comb_stream');
    $query->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb');
    $query->join('combination_subjects', 'combination_subjects.comb_id = comb_stream.comb');
    $query->join('subject_tbl', 'subject_tbl.subject_id = combination_subjects.subject_id');

    if ($stream > 0) {
       // $query->select('subject_tbl.subject_name, subject_tbl.subject_id');
          $query->select('subject_tbl.subject_name, subject_tbl.subject_id,subject_tbl.selection, combination_tbl.comb_id as comb, combination_tbl.comb_name, comb_stream.stream_id');
        $query->where('comb_stream.stream_id', $stream);
        $result = $query->get()->getResult();
    } else {
        
          //$query->select('subject_tbl.subject_name, subject_tbl.subject_id');
          $query->select('subject_tbl.subject_name, subject_tbl.subject_id,subject_tbl.selection, combination_tbl.comb_id as comb, combination_tbl.comb_name, comb_stream.stream_id');
      $query->where('comb_stream.class_id', $class);
      $query->groupBy('subject_tbl.subject_id');
        $result = $query->get()->getResult();
    }

    $this->db->close();
    return $result;
}

      public function GetSubjectsByStreamReport_old($stream){
        if ($stream>0){
 $query = $this->db->table('comb_stream');
    $query->select('subject_tbl.subject_name,
                    subject_tbl.subject_id
                     ');
$query->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb');
$query->join('combination_subjects', 'combination_subjects.comb_id = comb_stream.comb');
$query->join('subject_tbl', 'subject_tbl.subject_id = combination_subjects.subject_id');

  $query->where('comb_stream.stream_id',$stream);
}else{

 $query = $this->db->table('comb_stream');
    $query->select('subject_tbl.subject_name,
                    subject_tbl.subject_id
                     ');
$query->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb');
$query->join('combination_subjects', 'combination_subjects.comb_id = comb_stream.comb');
$query->join('subject_tbl', 'subject_tbl.subject_id = combination_subjects.subject_id');
$query->groupBy('subject_tbl.subject_id');
}
    $result= $query->get()->getResult();
     $this->db->close();
    return $result;

   }

public function GetMonthly_ExamMarksReport($classlevel,$class,$stream,$start_date, $end_date, $year) {
    $query = $this->db->table('exam_results_tbl');
    $query->select('
        exam_results_tbl.result_id,
        exam_results_tbl.student_id,
        exam_results_tbl.subject_id,
        AVG(exam_results_tbl.marks_scored) AS marks_scored, 
        grades_tbl.grade_name,
        admission_tbl.level_id,
        grades_tbl.grade_id
    ');
    $query->join('admission_tbl', 'admission_tbl.academic_year = exam_results_tbl.academic_year');
    $query->join('exam_result_records', 'exam_result_records.result_record_id = exam_results_tbl.result_record');
       $query->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
    $query->where('exam_results_tbl.academic_year', $year);
    $query->where('exam_result_records.academic_year', $year);
    $query->where('exam_result_records.exam_type_id', 1);
    $query->where('exam_results_tbl.exam_id', 1);
   $query->where('admission_tbl.level_id', $classlevel);
    $query->where('admission_tbl.class_id', $class);
     $query->where('exam_result_records.exam_date >=', $start_date);
     $query->where('exam_result_records.exam_date <=', $end_date);
       $query->where('exam_result_records.class',$class);
    $query->where('exam_results_tbl.student_id = admission_tbl.student_id', null, false);
         $query->where('exam_results_tbl.academic_year = exam_result_records.academic_year', null, false);
          $query->where('exam_results_tbl.exam_id = exam_result_records.exam_type_id', null, false);
     $query->groupBy(['exam_results_tbl.student_id', 'exam_results_tbl.subject_id']);
    if($stream>0){
 $query->where('admission_tbl.stream_id', $stream);
 $query->where('exam_result_records.stream',$stream);
    }
    $result = $query->get()->getResult();
    $this->db->close();
    return $result;
}

      public function GetExamMidterm_MarksReport($classlevel,$class,$stream,$start_date,$end_date,$year){
    $query = $this->db->table('exam_results_tbl');
    $query->select('
        exam_results_tbl.result_id,
        exam_results_tbl.student_id,
        exam_results_tbl.subject_id,
        AVG(exam_results_tbl.marks_scored) AS marks_scored, 
        grades_tbl.grade_name,
        grades_tbl.grade_id
    ');
$query->join('admission_tbl', 'admission_tbl.academic_year = exam_results_tbl.academic_year');
  $query->join('exam_result_records', 'exam_result_records.result_record_id = exam_results_tbl.result_record');
    $query->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
    $query->where('exam_results_tbl.academic_year', $year);
    $query->where('exam_result_records.academic_year', $year);
    $query->where('exam_result_records.exam_type_id', 2);
      $query->where('exam_results_tbl.exam_id', 2);
        $query->where('admission_tbl.level_id', $classlevel);
    $query->where('admission_tbl.class_id', $class);
     $query->where('exam_result_records.exam_date >=', $start_date);
    $query->where('exam_result_records.exam_date <=', $end_date);
      $query->where('exam_result_records.class',$class);
     $query->where('exam_results_tbl.student_id = admission_tbl.student_id', null, false);
          $query->where('exam_results_tbl.academic_year = exam_result_records.academic_year', null, false);
          $query->where('exam_results_tbl.exam_id = exam_result_records.exam_type_id', null, false);
         if($stream>0){
 $query->where('admission_tbl.stream_id', $stream);
  $query->where('exam_result_records.stream',$stream);
    }
    $query->groupBy(['exam_results_tbl.student_id', 'exam_results_tbl.subject_id']);
      $result= $query->get()->getResult();
     $this->db->close();
     return $result;
   }
      public function GetExamMarksReport($classlevel,$class,$stream,$examtype,$start_date,$end_date,$year){
    $query = $this->db->table('exam_results_tbl');
    $query->select('exam_results_tbl.result_id, exam_results_tbl.student_id, exam_results_tbl.subject_id, exam_results_tbl.marks_scored, grades_tbl.grade_name,grades_tbl.grade_id');
    $query->join('admission_tbl', 'admission_tbl.academic_year = exam_results_tbl.academic_year');
        $query->join('exam_result_records', 'exam_result_records.result_record_id = exam_results_tbl.result_record');
          $query->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
          $query->where('exam_results_tbl.academic_year',$year);
          $query->where('exam_result_records.exam_type_id',$examtype);
          $query->where('exam_results_tbl.exam_id', $examtype);
          $query->where('exam_result_records.exam_date >=', $start_date);
          $query->where('exam_result_records.exam_date <=', $end_date);
          $query->where('admission_tbl.level_id', $classlevel);
          $query->where('admission_tbl.class_id', $class);
          $query->where('exam_result_records.academic_year',$year);
          $query->where('exam_result_records.class',$class);
          $query->where('exam_results_tbl.student_id = admission_tbl.student_id', null, false);
          $query->where('exam_results_tbl.academic_year = exam_result_records.academic_year', null, false);
          $query->where('exam_results_tbl.exam_id = exam_result_records.exam_type_id', null, false);
                 if($stream>0){
 $query->where('admission_tbl.stream_id', $stream);
 $query->where('exam_result_records.stream',$stream);
    }
        $query->groupBy(['exam_results_tbl.student_id', 'exam_results_tbl.subject_id']);
      $result= $query->get()->getResult();
     $this->db->close();
     return $result;
   }
   public function getGradeBoundaries($classlevel)
{    return $this->db->table('grades_tbl')
                    ->select('grade_name,comments,lower_performance, upper_performance,division_point')
                      ->where('classlevel', $classlevel)
                    ->get()
                    ->getResult();
}

public function StudentSubjects($class,$stream){
    $query = $this->db->table('comb_stream');
    $query->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb');
    $query->join('combination_subjects', 'combination_subjects.comb_id = comb_stream.comb');
    $query->join('subject_tbl', 'subject_tbl.subject_id = combination_subjects.subject_id');
        $query->select('subject_tbl.subject_name, subject_tbl.subject_id,subject_tbl.selection');
        $query->where('comb_stream.stream_id', $stream);   
        $result = $query->get()->getResult();
    $this->db->close();
    return $result;

}
public function StudentExamMarksReport($year, $term, $id, $examtype, $start_date, $end_date)
{
    $query = $this->db->table('exam_results_tbl r')
        ->select('
            r.result_id,
            r.exam_id,
            r.student_id,
            r.subject_id,
            r.marks_scored,
            g.grade_name,
            g.grade_id
        ')
        ->join('exam_result_records rr', 'rr.result_record_id = r.result_record') // ✅ Correct join
        ->join('grades_tbl g', 'g.grade_id = r.grade_id')
        ->where('r.academic_year', $year)
        ->where('rr.academic_year', $year)
        ->where('r.student_id', $id)
      //  ->whereIn('rr.exam_type_id', is_array($examtype) ? $examtype : [$examtype]) // ✅ Accepts single or array
        ->where('rr.exam_date >=', $start_date)
        ->where('rr.exam_date <=', $end_date);

    if ($term > 0) {
        $query->where('rr.term', $term); // ✅ Apply term only if specified
    }

    $result = $query->get()->getResult();
    $this->db->close();
    return $result;
}

//       public function StudentExamMarksReport($year,$term,$id,$examtype,$start_date,$end_date){
//             if($term>0){
//                 $query = $this->db->table('exam_results_tbl');
//     $query->select('exam_results_tbl.result_id, exam_results_tbl.exam_id,exam_results_tbl.student_id, exam_results_tbl.subject_id, exam_results_tbl.marks_scored, grades_tbl.grade_name,grades_tbl.grade_id');
//            $query->join('exam_result_records', 'exam_result_records.exam_type_id = exam_results_tbl.exam_id');
//           $query->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
//           $query->where('exam_results_tbl.academic_year',$year);
//        $query->where('exam_result_records.exam_type_id',$examtype);
//           $query->where('exam_result_records.exam_date >=', $start_date);
//         $query->where('exam_result_records.exam_date <=', $end_date);
//          $query->where('exam_result_records.academic_year',$year);
//             $query->where('exam_results_tbl.academic_year', $year);
//             $query->where('exam_results_tbl.student_id', $id);
//   $query->where('exam_results_tbl.term', $term);
//      $result= $query->get()->getResult();
//      $this->db->close();
//      return $result;
//             }else{

// $query = $this->db->table('exam_results_tbl');
//     $query->select('exam_results_tbl.result_id,exam_results_tbl.exam_id, exam_results_tbl.student_id, exam_results_tbl.subject_id, exam_results_tbl.marks_scored, grades_tbl.grade_name,grades_tbl.grade_id');
//         $query->join('exam_result_records', 'exam_result_records.exam_type_id = exam_results_tbl.exam_id');
//           $query->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
//               $query->where('exam_result_records.exam_date >=', $start_date);
//        $query->where('exam_result_records.exam_date <=', $end_date);
//          $query->where('exam_result_records.academic_year',$year);
//             $query->where('exam_results_tbl.academic_year', $year);
//             $query->where('exam_results_tbl.student_id', $id);
//                $result= $query->get()->getResult();
//      $this->db->close();
//      return $result;
//             }
   
    
//    }
// public function StudentExamAverages($year, $term, $student_id)
// {
//     $query = $this->db->table('exam_results_tbl');
//     $query->select('exam_id, AVG(marks_scored) AS marks_scored,exam_results_tbl.result_id, exam_results_tbl.exam_id,exam_results_tbl.student_id, exam_results_tbl.subject_id, grades_tbl.grade_name,grades_tbl.grade_id');
//      $query->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
//     $query->where('academic_year', $year);
//     $query->where('student_id', $student_id);
//     $query->whereIn('exam_id', [1, 2, 4]); // 1 = monthly, 2 = midterm, 4 = terminal

//     if ($term > 0) {
//         $query->where('term', $term);
//     }

//     $query->groupBy('exam_id');

//     $result = $query->get()->getResult();
//     $this->db->close();

//     return $result;
// }

      public function DetailedCharacterResult($year){
    $query = $this->db->table('character_results_tbl');
     $query->select('character_results_tbl.grade_id,character_results_tbl.student_id, character_results_tbl.character_id, grades_tbl.grade_name ');
       $query->join('grades_tbl', 'character_results_tbl.grade_id=grades_tbl.grade_id');
         $query->where('character_results_tbl.academic_yr',$year);
     return $query->get()->getResult(); 
   }
   public function DetailedExamMarksReport($year)
{
    $query = $this->db->table('exam_results_tbl er')
        ->select('er.student_id, er.subject_id, et.exam_name,er.exam_id, er.marks_scored, g.grade_name')
        ->join('grades_tbl g', 'g.grade_id = er.grade_id')
        ->join('examination_tbl et', 'et.exam_id = er.exam_id')
        ->where('er.academic_year', $year)
        ->get();

    $results = [];

    foreach ($query->getResult() as $row) {
        $results[$row->student_id][$row->subject_id][$row->exam_id] = [
            'marks' => $row->marks_scored,
            'student_id' => $row->student_id,
            'subject_id' => $row->subject_id,
            'grade_name' => $row->grade_name
        ];
    }

    return $results;
}
public function getGrades_forDivision($classlevel){
      $query=$this->db->table('grades_tbl');
        $query->select('*');
        $query->where('classlevel', $classlevel);
      $Result=$query->get()->getResult();
        return $Result;
}
public function getExamtypes(){
      $query=$this->db->table('examination_tbl');
        $query->select('*');
      $Result=$query->get()->getResult();
        return $Result;

}
public function getTop10Students($year)
{
    return $this->db->table('exam_results_tbl r')
        ->select('r.student_id, SUM(r.marks_scored) as total_marks, s.student_name') // adjust student_name if needed
        ->join('students s', 's.id = r.student_id')
        ->where('r.academic_year', $year)
        ->groupBy('r.student_id')
        ->orderBy('total_marks', 'DESC')
        ->limit(10)
        ->get()
        ->getResult();
}

public function getBottom10Students($examId, $term)
{
    return $this->db->table('exam_results_tbl r')
        ->select('r.student_id, SUM(r.marks_scored) as total_marks, s.student_name') // adjust student_name if needed
        ->join('students s', 's.id = r.student_id')
        ->where('r.exam_id', $examId)
        ->where('r.term', $term)
        ->groupBy('r.student_id')
        ->orderBy('total_marks', 'ASC')
        ->limit(10)
        ->get()
        ->getResult();
}

public function getCardSubjectPosition($subjectId, $classId, $examId, $studentId)
{
    $sql = "
        SELECT *
        FROM (
            SELECT 
                r.student_id,
                RANK() OVER (PARTITION BY r.subject_id, r.class_id, r.exam_id ORDER BY r.marks_scored DESC) AS subject_position
            FROM 
                exam_results_tbl r
            WHERE 
                r.subject_id = ? AND
                r.class_id = ? AND
                r.exam_id = ?
        ) AS ranked
        WHERE student_id = ?
    ";

    return $this->db->query($sql, [$subjectId, $classId, $examId, $studentId])->getRow();
}
public function get_governmennt_levels($classlevel)
      {      
     $query = $this->db->table('class_level_tbl');
    $query->select('government_level_id');
    $query->where('id',$classlevel);
   $result = $query->get()->getRow();
    $this->db->close();
    return $result;

}
public function GetClassList($id){
    $query = $this->db->table('classes_tbl');
    $query->select('class_name');
    $query->where('id',$id);
   $result = $query->get()->getRow();
    $this->db->close();
    return $result;
 }
public function GetStreamList($id){
    $query = $this->db->table('comb_stream');
    $query->select('streams_tbl.stream_name,combination_tbl.comb_name');
 $query->join('streams_tbl','streams_tbl.id = comb_stream.stream_id');
    $query->join('combination_tbl','combination_tbl.comb_id = comb_stream.comb');
    $query->where('streams_tbl.id',$id);
   $result = $query->get()->getRow();
    $this->db->close();
    return $result;
 }
public function GetGradeDetails($tbl,$data){
        $query = $this->db->table($tbl);
    $query->select('grades_tbl.*');
 $query->where('grades_tbl.classlevel',$data);
   $result = $query->get()->getResult();
    $this->db->close();
    return $result;
}
      public function GetExamMarksReportByExamType($examtype,$term,$classlevel,$year,$class,$stream){
    $query = $this->db->table('exam_results_tbl');
    $query->select('exam_results_tbl.result_id, exam_results_tbl.student_id, exam_results_tbl.subject_id, exam_results_tbl.marks_scored, grades_tbl.grade_name,grades_tbl.grade_id');
    $query->join('admission_tbl', 'admission_tbl.academic_year = exam_results_tbl.academic_year');
          $query->join('exam_result_records', 'exam_result_records.exam_type_id = exam_results_tbl.exam_id');
          $query->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
          $query->where('exam_results_tbl.academic_year',$year);
          $query->where('exam_result_records.exam_type_id',$examtype);
          $query->where('exam_results_tbl.exam_id', $examtype);
          $query->where('admission_tbl.level_id', $classlevel);
          $query->where('admission_tbl.class_id', $class);
          $query->where('exam_result_records.academic_year',$year);
          $query->where('exam_result_records.class',$class);
          $query->where('exam_results_tbl.student_id = admission_tbl.student_id', null, false);
          $query->where('exam_results_tbl.academic_year = exam_result_records.academic_year', null, false);
          $query->where('exam_results_tbl.exam_id = exam_result_records.exam_type_id', null, false);
                 if($stream>0){
 $query->where('admission_tbl.stream_id', $stream);
 $query->where('exam_result_records.stream',$stream);
    }
        $query->groupBy(['exam_results_tbl.student_id', 'exam_results_tbl.subject_id']);
      $result= $query->get()->getResult();
     $this->db->close();
     return $result;
   }
      public function getStudentDetails($student,$year){
         $query = $this->db->table('admission_tbl');
       $query->select('
        students.birth_date,
        students.id,
        admission_tbl.class_id,
        admission_tbl.level_id,
        admission_tbl.stream_id,
        admission_tbl.academic_year,
        students.student_id,
        classes_tbl.class_name,
        streams_tbl.stream_name,
        class_level_tbl.level_name,
       students.full_name,
       students.status,
       students.first_name,'
    ); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
    $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
     $query->join('students', 'students.id = admission_tbl.student_id');
     $query->where('admission_tbl.student_id',$student);
     $query->where('students.id',$student);
     $query->where('admission_tbl.academic_year',$year);
     $result= $query->get()->getRow();
     $this->db->close();
    return $result;
    
   }
     public function GetcharacterHistory($student,$year){
        $query=$this->db->table('character_results_tbl');
        $query->select('character_results_tbl.student_id,character_results_tbl.character_id,grades_tbl.grade_name');
         $query->join('grades_tbl', 'grades_tbl.grade_id = character_results_tbl.grade_id');
          $query->where('character_results_tbl.student_id',$student);
          $query->where('character_results_tbl.academic_yr',$year);
      $Result=$query->get()->getResult();
        return $Result;
        
    }
//     public function GetStudentTestPerformance($student_id)
// {
//     $builder = $this->db->table('exam_results_tbl');
//     $builder->select('exam_results_tbl.academic_year as year, exam_results_tbl.marks_scored as average,class_level_tbl.government_level_id, subject_tbl.subject_name, exam_id, grades_tbl.grade_name,grades_tbl.comments,grades_tbl.lower_performance, grades_tbl.upper_performance,grades_tbl.division_point,subject_tbl.selection');
//      $builder->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
//       $builder->join('subject_tbl', 'subject_tbl.subject_id = exam_results_tbl.subject_id');
//       $builder->join('admission_tbl', 'admission_tbl.student_id = exam_results_tbl.student_id');
//       $builder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id');
//     $builder->where('exam_results_tbl.student_id', $student_id);
//     $builder->where('exam_id', 1);
//    $builder->groupBy('exam_results_tbl.subject_id');
//     $builder->groupBy('exam_results_tbl.academic_year');
//     $builder->orderBy('exam_results_tbl.academic_year', 'ASC');
//     $query = $builder->get();
//     return $query->getResult();
// }

    public function GetStudentTestPerformance($student_id)
{
    $builder = $this->db->table('exam_results_tbl');
    $builder->select(
        'exam_results_tbl.academic_year as year,
         AVG(exam_results_tbl.marks_scored) as average,
         class_level_tbl.government_level_id,
         subject_tbl.subject_name,
         exam_results_tbl.subject_id,
         exam_id,
         grades_tbl.grade_name,
         grades_tbl.comments,
         grades_tbl.lower_performance,
         grades_tbl.upper_performance,
         grades_tbl.division_point,
         subject_tbl.selection'
    );
    $builder->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
    $builder->join('subject_tbl', 'subject_tbl.subject_id = exam_results_tbl.subject_id');
    $builder->join('admission_tbl', 'admission_tbl.student_id = exam_results_tbl.student_id');
    $builder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id');
    $builder->where('exam_results_tbl.student_id', $student_id);
    $builder->where('exam_id', 1);
    $builder->groupBy('exam_results_tbl.subject_id');
    $builder->groupBy('exam_results_tbl.academic_year');
    $builder->orderBy('exam_results_tbl.academic_year', 'ASC');
    
    $query = $builder->get();
    return $query->getResult();
}

//     public function GetStudentMidtermPerformance($student_id)
// {
//     $builder = $this->db->table('exam_results_tbl');
//     $builder->select('academic_year as year, exam_results_tbl.marks_scored as average, subject_id, exam_id, grade_id');
//     $builder->where('student_id', $student_id);
//     $builder->where('exam_id', 2);
//  //   $builder->groupBy('academic_year');
//     $builder->orderBy('academic_year', 'ASC');
//     $query = $builder->get();
//     return $query->getResult();
// }
public function GetStudentMidtermPerformance($student_id)
{
    $builder = $this->db->table('exam_results_tbl');
    $builder->select(
        'exam_results_tbl.academic_year as year,
         AVG(exam_results_tbl.marks_scored) as average,
         class_level_tbl.government_level_id,
         subject_tbl.subject_name,
         exam_results_tbl.subject_id,
         exam_id,
         grades_tbl.grade_name,
         grades_tbl.comments,
         grades_tbl.lower_performance,
         grades_tbl.upper_performance,
         grades_tbl.division_point,
         subject_tbl.selection'
    );
    $builder->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
    $builder->join('subject_tbl', 'subject_tbl.subject_id = exam_results_tbl.subject_id');
    $builder->join('admission_tbl', 'admission_tbl.student_id = exam_results_tbl.student_id');
    $builder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id');
    $builder->where('exam_results_tbl.student_id', $student_id);
    $builder->where('exam_id', 2);
    $builder->groupBy('exam_results_tbl.subject_id');
    $builder->groupBy('exam_results_tbl.academic_year');
    $builder->orderBy('exam_results_tbl.academic_year', 'ASC');
    
    $query = $builder->get();
    return $query->getResult();
}

//     public function GetStudentTerminalPerformance($student_id)
// {
//     $builder = $this->db->table('exam_results_tbl');
//     $builder->select('academic_year as year, marks_scored as average, subject_id, exam_id, grade_id');
//     $builder->where('student_id', $student_id);
//     $builder->where('exam_id', 3);
//   //  $builder->groupBy('academic_year');
//     $builder->orderBy('academic_year', 'ASC');
//     $query = $builder->get();
//     return $query->getResult();
// }
public function GetStudentTerminalPerformance($student_id)
{
    $builder = $this->db->table('exam_results_tbl');
    $builder->select(
        'exam_results_tbl.academic_year as year,
         AVG(exam_results_tbl.marks_scored) as average,
         class_level_tbl.government_level_id,
         subject_tbl.subject_name,
         exam_results_tbl.subject_id,
         exam_id,
         grades_tbl.grade_name,
         grades_tbl.comments,
         grades_tbl.lower_performance,
         grades_tbl.upper_performance,
         grades_tbl.division_point,
         subject_tbl.selection'
    );
    $builder->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
    $builder->join('subject_tbl', 'subject_tbl.subject_id = exam_results_tbl.subject_id');
    $builder->join('admission_tbl', 'admission_tbl.student_id = exam_results_tbl.student_id');
    $builder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id');
    $builder->where('exam_results_tbl.student_id', $student_id);
    $builder->where('exam_id', 3);
    $builder->groupBy('exam_results_tbl.subject_id');
    $builder->groupBy('exam_results_tbl.academic_year');
    $builder->orderBy('exam_results_tbl.academic_year', 'ASC');
    
    $query = $builder->get();
    return $query->getResult();
}

//     public function GetStudentAnnualPerformance($student_id)
// {
//     $builder = $this->db->table('exam_results_tbl');
//     $builder->select('academic_year as year, marks_scored as average, subject_id, exam_id, grade_id');
//     $builder->where('student_id', $student_id);
//     $builder->where('exam_id', 4);
//     //$builder->groupBy('academic_year');
//     $builder->orderBy('academic_year', 'ASC');
//     $query = $builder->get();
//     return $query->getResult();
// }
    public function GetStudentAnnualPerformance($student_id)
{
    $builder = $this->db->table('exam_results_tbl');
    $builder->select(
        'exam_results_tbl.academic_year as year,
         AVG(exam_results_tbl.marks_scored) as average,
         class_level_tbl.government_level_id,
         subject_tbl.subject_name,
         exam_results_tbl.subject_id,
         exam_id,
         grades_tbl.grade_name,
         grades_tbl.comments,
         grades_tbl.lower_performance,
         grades_tbl.upper_performance,
         grades_tbl.division_point,
         subject_tbl.selection'
    );
    $builder->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
    $builder->join('subject_tbl', 'subject_tbl.subject_id = exam_results_tbl.subject_id');
    $builder->join('admission_tbl', 'admission_tbl.student_id = exam_results_tbl.student_id');
    $builder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id');
    $builder->where('exam_results_tbl.student_id', $student_id);
    $builder->where('exam_id', 4);
    $builder->groupBy('exam_results_tbl.subject_id');
    $builder->groupBy('exam_results_tbl.academic_year');
    $builder->orderBy('exam_results_tbl.academic_year', 'ASC');
    
    $query = $builder->get();
    return $query->getResult();
}

public function getStudentExamMarksReportTerm1($year, $term, $student_id, $start_date = null, $end_date = null)
{
    $builder = $this->db->table('exam_results_tbl');
    $builder->select('
        exam_results_tbl.result_id,
        exam_results_tbl.exam_id,
        exam_results_tbl.student_id,
        exam_results_tbl.subject_id,
        subject_tbl.subject_name,
        exam_results_tbl.marks_scored,
        exam_results_tbl.grade_id,
        grades_tbl.grade_name,
        exam_result_records.exam_type_id,
        exam_result_records.exam_date
    ');
    $builder->join('exam_result_records', 'exam_result_records.exam_type_id = exam_results_tbl.exam_id');
    $builder->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
    $builder->join('subject_tbl', 'subject_tbl.subject_id = exam_results_tbl.subject_id');
    $builder->join('admission_tbl', 'admission_tbl.academic_year = exam_results_tbl.academic_year');
    $builder->where('exam_results_tbl.academic_year', $year);
    $builder->where('exam_result_records.academic_year', $year);
    $builder->where('exam_results_tbl.student_id', $student_id);
            $builder->where('exam_results_tbl.student_id = admission_tbl.student_id', null, false);
          $builder->where('exam_results_tbl.academic_year = exam_result_records.academic_year', null, false);
          $builder->where('exam_results_tbl.exam_id = exam_result_records.exam_type_id', null, false);
    if (!empty($term) && is_numeric($term)) {
        $builder->where('exam_results_tbl.term', $term);
    }
    if (!empty($examtype)) {
        $builder->where('exam_result_records.exam_type_id', $examtype);
    }
    if (!empty($start_date) && !empty($end_date)) {
        $builder->where('exam_result_records.exam_date >=', $start_date);
        $builder->where('exam_result_records.exam_date <=', $end_date);
    }
    $builder->whereIn('exam_result_records.exam_type_id', [1, 2, 3]);
    $builder->whereIn('exam_results_tbl.exam_id', [1, 2, 3]);
    $builder->orderBy('subject_tbl.subject_name', 'ASC');
   // $builder->groupBy('subject_tbl.subject_id');
    $builder->orderBy('exam_result_records.exam_type_id', 'ASC');
    $query = $builder->get();
    return $query->getResult();
}
public function getStudentExamMarksReportTerm2($year, $term, $student_id, $start_date = null, $end_date = null)
{
    $builder = $this->db->table('exam_results_tbl');
    $builder->select('
        exam_results_tbl.result_id,
        exam_results_tbl.exam_id,
        exam_results_tbl.student_id,
        exam_results_tbl.subject_id,
        subject_tbl.subject_name,
        exam_results_tbl.marks_scored,
        exam_results_tbl.grade_id,
        grades_tbl.grade_name,
        exam_result_records.exam_type_id,
        exam_result_records.exam_date
    ');
    $builder->join('exam_result_records', 'exam_result_records.exam_type_id = exam_results_tbl.exam_id');
    $builder->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
    $builder->join('subject_tbl', 'subject_tbl.subject_id = exam_results_tbl.subject_id');
    $builder->join('admission_tbl', 'admission_tbl.academic_year = exam_results_tbl.academic_year');
    $builder->where('exam_results_tbl.academic_year', $year);
    $builder->where('exam_result_records.academic_year', $year);
    $builder->where('exam_results_tbl.student_id', $student_id);
        $builder->where('exam_results_tbl.student_id = admission_tbl.student_id', null, false);
          $builder->where('exam_results_tbl.academic_year = exam_result_records.academic_year', null, false);
          $builder->where('exam_results_tbl.exam_id = exam_result_records.exam_type_id', null, false);
    if (!empty($term) && is_numeric($term)) {
        $builder->where('exam_results_tbl.term', $term);
    }
    if (!empty($start_date) && !empty($end_date)) {
        $builder->where('exam_result_records.exam_date >=', $start_date);
        $builder->where('exam_result_records.exam_date <=', $end_date);
    }
     $builder->whereIn('exam_result_records.exam_type_id', [1, 2, 4]);
     $builder->whereIn('exam_results_tbl.exam_id', [1, 2, 4]);
    $builder->orderBy('subject_tbl.subject_name', 'ASC');
   // $builder->groupBy('subject_tbl.subject_id');
    $builder->orderBy('exam_result_records.exam_type_id', 'ASC');
    $query = $builder->get();
    return $query->getResult();
}


      public function StudentAcademicReport($year,$term,$id,array $examtype,$start_date,$end_date){
            if($term>0){
                $query = $this->db->table('exam_results_tbl');
    $query->select('exam_results_tbl.result_id, exam_results_tbl.exam_id,exam_results_tbl.student_id, exam_results_tbl.subject_id, exam_results_tbl.marks_scored, grades_tbl.grade_name,grades_tbl.grade_id');
           $query->join('exam_result_records', 'exam_result_records.exam_type_id = exam_results_tbl.exam_id');
          $query->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
          $query->where('exam_results_tbl.academic_year',$year);
       $query->whereIn('exam_result_records.exam_type_id',$examtype);
          $query->where('exam_result_records.exam_date >=', $start_date);
        $query->where('exam_result_records.exam_date <=', $end_date);
         $query->where('exam_result_records.academic_year',$year);
            $query->where('exam_results_tbl.academic_year', $year);
            $query->where('exam_results_tbl.student_id', $id);
  //$query->where('exam_results_tbl.term', $term);
     $result= $query->get()->getResult();
     $this->db->close();
     return $result;
            }else{

$query = $this->db->table('exam_results_tbl');
    $query->select('exam_results_tbl.result_id,exam_results_tbl.exam_id, exam_results_tbl.student_id, exam_results_tbl.subject_id, exam_results_tbl.marks_scored, grades_tbl.grade_name,grades_tbl.grade_id');
        $query->join('exam_result_records', 'exam_result_records.exam_type_id = exam_results_tbl.exam_id');
          $query->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
             $query->where('exam_result_records.exam_date >=', $start_date);
             $query->whereIn('exam_result_records.exam_type_id',$examtype);
       $query->where('exam_result_records.exam_date <=', $end_date);
         $query->where('exam_result_records.academic_year',$year);
            $query->where('exam_results_tbl.academic_year', $year);
            //$query->where('exam_results_tbl.student_id', $id);
               $result= $query->get()->getResult();
     $this->db->close();
     return $result;
            }
   
    
   }
   public function getStudentSubjectAverages(int $year,int $stream_id,int $class_id,array $exam_type_ids, string $start_date,string $end_date) {
    return $this->db->table('exam_results_tbl r')
        ->select('
            r.student_id,
            r.subject_id,
            rr.exam_type_id,
            s.subject_name,
            AVG(r.marks_scored) AS avg_marks,
            SUM(r.marks_scored) AS total_marks
        ')
        ->join('subject_tbl s', 's.subject_id = r.subject_id')
        ->join('exam_result_records rr', 'rr.result_record_id = r.result_record')
        ->where('r.academic_year', $year)
        ->where('rr.stream', $stream_id)
        ->where('rr.class', $class_id)
        ->whereIn('rr.exam_type_id', $exam_type_ids)
        ->where('rr.exam_date >=', $start_date)
        ->where('rr.exam_date <=', $end_date)
        ->groupBy(['r.student_id', 'r.subject_id','rr.exam_type_id'])
        ->get()
        ->getResult();
}

// public function getStudentOverallAverages(
//     int $year,
//     int $stream_id,
//     int $class_id,
//     array $exam_type_ids,
//     string $start_date,
//     string $end_date
// ) {
//     return $this->db->table('exam_results_tbl r')
//         ->select('
//             r.student_id,
//             SUM(r.marks_scored) AS overall_total,
//             AVG(r.marks_scored) AS overall_avg
//         ')
//         ->join('exam_result_records rr', 'rr.result_record_id = r.result_record')
//         ->where('r.academic_year', $year)
//         ->where('rr.stream', $stream_id)
//         ->where('rr.class', $class_id)
//         ->whereIn('rr.exam_type_id', $exam_type_ids)
//         ->where('rr.exam_date >=', $start_date)
//         ->where('rr.exam_date <=', $end_date)
//         ->groupBy('r.student_id','rr.exam_type_id')
//         ->get()
//         ->getResult();
// }
public function getStudentOverallAverages(
    int $year,
    int $stream_id,
    int $class_id,
    array $exam_type_ids,
    string $start_date,
    string $end_date
) {
    $builder = $this->db->table('exam_results_tbl r');
    $builder->select('r.student_id, r.subject_id, AVG(r.marks_scored) AS subject_avg');
    $builder->join('exam_result_records rr', 'rr.result_record_id = r.result_record');
    $builder->where('r.academic_year', $year);
    $builder->where('rr.stream', $stream_id);
    $builder->where('rr.class', $class_id);
    $builder->whereIn('rr.exam_type_id', $exam_type_ids);
    $builder->where('rr.exam_date >=', $start_date);
    $builder->where('rr.exam_date <=', $end_date);
    $builder->groupBy(['r.student_id', 'r.subject_id']);
    $subjectAverages = $builder->get()->getResult();

    // Now calculate average of subject_avg per student
    $students = [];

    foreach ($subjectAverages as $row) {
        $students[$row->student_id]['total'] = ($students[$row->student_id]['total'] ?? 0) + $row->subject_avg;
        $students[$row->student_id]['count'] = ($students[$row->student_id]['count'] ?? 0) + 1;
    }

    $final = [];
    foreach ($students as $student_id => $data) {
        $final[] = (object)[
            'student_id' => $student_id,
            'overall_avg' => round($data['total'] / $data['count'], 2),
            'subject_count' => $data['count'],
            'overall_total' => $data['total']
        ];
    }

    return $final;
}

   public function getStudentSubjectPosition(int $year,int $stream_id,int $class_id,array $exam_type_ids, string $start_date,string $end_date) {
    return $this->db->table('exam_results_tbl r')
        ->select('
            r.student_id,
            r.subject_id,
            AVG(r.marks_scored) AS avg_marks,
            SUM(r.marks_scored) AS total_marks
        ')
        ->join('exam_result_records rr', 'rr.result_record_id = r.result_record')
        ->where('r.academic_year', $year)
        ->where('rr.stream', $stream_id)
        ->where('rr.class', $class_id)
        ->whereIn('rr.exam_type_id', $exam_type_ids)
        ->where('rr.exam_date >=', $start_date)
        ->where('rr.exam_date <=', $end_date)
        ->groupBy(['r.student_id', 'r.subject_id'])
        ->get()
        ->getResult();
}
public function getSubjectPositions(
    int $year,
    int $stream_id,
    int $class_id,
    array $exam_type_ids,
    string $start_date,
    string $end_date
) {
    $data = $this->db->table('exam_results_tbl r')
        ->select('r.student_id, r.subject_id, AVG(r.marks_scored) AS avg_marks')
        ->join('exam_result_records rr', 'rr.result_record_id = r.result_record')
        ->where('r.academic_year', $year)
        ->where('rr.stream', $stream_id)
        ->where('rr.class', $class_id)
        ->whereIn('rr.exam_type_id', $exam_type_ids)
        ->where('rr.exam_date >=', $start_date)
        ->where('rr.exam_date <=', $end_date)
        ->groupBy(['r.student_id', 'r.subject_id'])
        ->get()
        ->getResult();
    $ranked = [];
    foreach ($data as $row) {
        $ranked[$row->subject_id][] = $row;
    }
    $positions = [];
    foreach ($ranked as $subject_id => $students) {
        usort($students, fn($a, $b) => $b->avg_marks <=> $a->avg_marks);
        foreach ($students as $index => $s) {
            $positions[] = [
                'student_id' => $s->student_id,
                'subject'    => $subject_id,
                // 'average'    => $avg_marks,
                'position'   => $index + 1
            ];
        }
    }

    return $positions;
}
public function getNumberStudents($year,$class)
{
    $query = $this->db->table('admission_tbl');
    $query->selectCount('students.id', 'total_students');
    $query->join('students', 'students.id = admission_tbl.student_id');
    $query->where('admission_tbl.academic_year', $year);
    $query->where('admission_tbl.class_id', $class);
  $result = $query->get()->getRow();
    $this->db->close();
    return $result->total_students;
    }
public function GetStudentsSubjectPositions(
    int $year,
    int $subject_id,
    int $stream_id,
    int $class_id,
    array $exam_type_ids,
    string $start_date,
    string $end_date
) {
    $data = $this->db->table('exam_results_tbl r')
        ->select('r.student_id, r.subject_id, AVG(r.marks_scored) AS avg_marks')
        ->join('exam_result_records rr', 'rr.result_record_id = r.result_record')
        ->where('r.academic_year', $year)
        ->where('rr.stream', $stream_id)
        ->where('rr.class', $class_id)
        ->whereIn('rr.exam_type_id', $exam_type_ids)
        ->where('rr.exam_date >=', $start_date)
        ->where('rr.exam_date <=', $end_date)
        ->groupBy(['r.student_id', 'r.subject_id'])
        ->get()
        ->getResult();
    $ranked = [];
    foreach ($data as $row) {
        $ranked[$row->subject_id][] = $row;
    }
    $positions = [];
    foreach ($ranked as $subject_id => $students) {
        usort($students, fn($a, $b) => $b->avg_marks <=> $a->avg_marks);
        foreach ($students as $index => $s) {
            $positions[] = [
                'student_id' => $s->student_id,
                'subject'    => $subject_id,
                 'average'    => $s->avg_marks,
                'position'   => $index + 1
            ];
        }
    }
  usort($positions, function($a, $b) {
        return $a['position'] <=> $b['position'];
    });
    return $positions;
}
public function GetSubjectByID($subject_id){
    return $this->db->table('subject_tbl')
        ->where('subject_id', $subject_id)
        ->select('subject_name')
        ->get()
        ->getRow();
}
   public function GetSubjectAverages(int $year, int $subject_id,int $stream_id,int $class_id,array $exam_type_ids, string $start_date,string $end_date){
    return $this->db->table('exam_results_tbl r')
        ->select('
            r.student_id,
            r.subject_id,
            rr.exam_type_id,
            s.subject_name,
            AVG(r.marks_scored) AS avg_marks,
            SUM(r.marks_scored) AS total_marks
        ')
        ->join('subject_tbl s', 's.subject_id = r.subject_id')
        ->join('exam_result_records rr', 'rr.result_record_id = r.result_record')
        ->where('r.academic_year', $year)
        ->where('rr.stream', $stream_id)
        ->where('rr.class', $class_id)
        ->where('r.subject_id', $subject_id)
        ->whereIn('rr.exam_type_id', $exam_type_ids)
        ->where('rr.exam_date >=', $start_date)
        ->where('rr.exam_date <=', $end_date)
        ->groupBy(['r.student_id', 'r.subject_id','rr.exam_type_id'])
        ->get()
        ->getResult();
}

}
 ?>

