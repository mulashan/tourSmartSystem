<?php

namespace App\Models;

use CodeIgniter\Model;

class TransportModel extends Model
{

	 public $db;
    public function __construct(){
    $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    }
public function items_chargedList()
    {
        $builder = $this->db->table('items_tbl');
        $builder->select('id,item_name,item_price');
        $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
        $query = $builder->get()->getResult();
            
         return $query;
    }
    public function items_chargedList1($id)
    {
        $builder = $this->db->table('items_tbl');
        $builder->select('id,item_name,item_price,item_size,item_attribute');
        $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
        $builder->where('id',$id);
        $query = $builder->get()->getResult();
            
         return $query;
    }
    public function addNewVehicle($data)
    {
        $query = $this->db->table('vehicles_tbl')->insert($data);
		if($query){
			return $this->db->insertID();
		}
		else{
			return 0;
		}
       
    }
	//update all vehicle data
	public function Update_Vehicle($id,$data)
    {
        $builder = $this->db->table('vehicles_tbl');
		$builder->where('id',$id);
		$builder->update($data);
       
    }
	public function delete_TransportId($transport)
		{
            $builder = $this->db->table('transport_item_tbl');
			$builder->select('transport_id');
			$builder->where('transport_id',$transport);
			$builder->delete();
		}
  
	public function create_charged_item($charged_item)
    {
      
			$builder = $this->db->table('transport_item_tbl')->insert($charged_item);
    }
		public function Edit_charged_item($transport,$charged_item)
    {
      
			$builder = $this->db->table('transport_item_tbl')->insert($charged_item);
    }
	public function update_charged_item($id)
	
    {
		
			$query=$this->db->table('transport_item_tbl');
			$query->where('transport_id',$id);
			$delete=$query->delete();
			$builder = $this->db->table('transport_item_tbl')->insert($charged_item);
    }
		
		
		
    
	
	
	public function getAllVehicles(){
	$query=$this->db->table('vehicles_tbl');
	$query->select('vehicles_tbl.id,vehicles_list_tbl.vehicle_number,vehicles_list_tbl.vehicle_model,vehicles_list_tbl.capacity,vehicles_list_tbl.driver_name,vehicles_list_tbl.driver_contact,route_tbl.route_name,route_tbl.via,vehicles_tbl.status,vehicles_tbl.capacity,vehicles_tbl.updated_date,vehicles_tbl.updated_by');
			$query->join('vehicles_list_tbl', 'vehicles_list_tbl.id = vehicles_tbl.vehicle_number');
			$query->join('route_tbl', 'route_tbl.id = vehicles_tbl.route_id');
			$result= $query->get()->getResult();
                
		return $result;
	}
	public function updateVehicle($data,$id){
		$update_query= $this->db->table('vehicles_tbl');
		$update_query->where('id',$id);
		$result=$update_query->update($data);
		return $result;
	}
	public function deleteVehicle($id){
		$delete=$this->db->table('vehicles_tbl');
		$delete->where('id',$id);
		$result=$delete->delete();
		return $result;
	}
	public function deleteVehicleItem($tid,$iid){
		$delete=$this->db->table('transport_item_tbl');
		$delete->where('transport_id',$tid);
		$delete->where('item_id',$iid);
		$result=$delete->delete();
		return $result;
	}
	public function deleteTransportItem($id){
		$delete=$this->db->table('transport_item_tbl');
		$delete->where('transport_id',$id);
		$result=$delete->delete();
		return $result;
	}
	/*public function FindChargedItem($item_name){
		$item=$this->db->table('items_tbl');
		$item->select("*");
		$item->where('item_name',$item_name);
		$result=$item->get()->getResult();
		return $result;
	}*/
	public function ChargedItem()
		{
			$builder = $this->db->table('items_tbl');
			//$builder = $this->db->table('price_tbl');
			$builder->select('id,item_name,pid,item_price');
			$builder->join('price_tbl', 'price_tbl.pid = items_tbl.id');
			$result= $builder->get()->getResult();
                return $result;
				echo json_encode($result);
		}
		///////////////////////////////////////////////////////
		public function returnAlldataOfVehicle($id){
			$query=$this->db->table('vehicles_tbl');
			
			$query->select('vehicles_tbl.id,vehicles_list_tbl.vehicle_number,vehicles_list_tbl.vehicle_model,vehicles_list_tbl.year_made,vehicles_list_tbl.driver_name,vehicles_list_tbl.driver_contact,vehicles_list_tbl.driver_license,route_tbl.route_name,route_tbl.via,vehicles_tbl.status,vehicles_tbl.capacity,vehicles_tbl.updated_date,vehicles_tbl.updated_by,vehicles_tbl.route_id');
			$query->join('vehicles_list_tbl', 'vehicles_list_tbl.id = vehicles_tbl.vehicle_number');
			$query->join('route_tbl', 'route_tbl.id = vehicles_tbl.route_id');
			$query->where('vehicles_tbl.id',$id);
			$result=$query->get()->getResult();
			return $result;
		}
		public function vehicleItems($id){
			$query=$this->db->table('transport_item_tbl');
			$query->select('transport_item_tbl.id,transport_id,item_id,quantity,item_name,item_size,item_attribute,account_receivable');
			$query->where('transport_id',$id);
			$query->join('items_tbl', 'items_tbl.id=transport_item_tbl.item_id');
			$result=$query->get()->getResult();
			return $result;
		}
		public function returnVehicleItem($id){
			$query=$this->db->table('transport_item_tbl');
			$query->select('quantity,item_id,transport_id');
			$query->where('transport_id',$id);
			$result=$query->get()->getResult();
			return $result;
		}
		
		function delete_transport_chargedItems($id)
		{
			$builder = $this->db->table('transport_item_tbl');
		
			$builder->where('id',$id);
			$builder->delete();
		}
		public function selectingAllItemsOfVehicle($transport_id){
			
			$query=$this->db->table('transport_item_tbl');
			$query->select('item_id');
			$query->where('transport_id',$transport_id);
			$result=$query->get()->getResult();
			return $result;
			
		}
		public function add_temporary($data)
     {
        $builder = $this->db->table('installments_tbl')->insert($data);

        return $builder;
     }
      public function saveInstallmentData($id)
     {
       $builder = $this->db->table('installments_tbl');
      $builder->set('tbl_id', $id)
                  ->where('tbl_id', 0)
                  ->update();
        return $builder;
     }
     
	 public function add_installment($data)
	 
     {
        $builder = $this->db->table('installments_tbl')->insert($data);

        return $builder;
     }
      public function check_temp($name)
     {
        $builder = $this->db->table('installments_tbl');
        $builder->select('*');
        $builder->where('istallment_name',$name);
        $builder->where('tbl_id=0');
        $builder->where('installment_type=4');
        $query = $builder->get()->getResult();

        return count($query);
     }
     public function check_inst($id,$name)
     {
        $builder = $this->db->table('installments_tbl');
        $builder->select('*');
        $builder->where('istallment_name',$name);
        $builder->where('tbl_id',$id);
        $query = $builder->get()->getResult();

        return count($query);
     }
 function select_driver(){
     	 $builder = $this->db->table('users');
		$builder->select('*');
			$builder->where('users.user_type', 4);
			$query = $builder->get()->getResult();
			return $query;
	}
	function select_route(){
     	 $builder = $this->db->table('route_tbl');
		$builder->select('*');
			$query = $builder->get()->getResult();
			return $query;
	}
	
	function select_vehicle(){
     	 $builder = $this->db->table('vehicles_list_tbl');
		$builder->select('*');
			$query = $builder->get()->getResult();
			return $query;
	}
	function add_route($data){
		$builder = $this->db->table('route_tbl')->insert($data);
		}
		function add_vehicle($data){
		$builder = $this->db->table('vehicles_list_tbl')->insert($data);
		}
		function get_route(){
		$builder = $this->db->table('route_tbl');
		$builder->select('*');
		$query = $builder->get()->getResult();
			return $query;	
		}
		function get_vehicle(){
		$builder = $this->db->table('vehicles_list_tbl');
		$builder->select('*');
		$query = $builder->get()->getResult();
			return $query;	
		}
		function add_vehicle_route($data){
		$builder = $this->db->table('route_vehicles_tbl')->insert($data);	
		}
	function edit_route($data,$id){
          $builder = $this->db->table('route_tbl');
            $builder->where('id',$id);
            $builder->update($data);
            return $builder;
    }
function delete_route($id){
 $builder = $this->db->table('route_tbl');
			$builder->where('id',$id);
			$builder->delete();
			  return $builder;	
}
function edit_vehicle($data,$id){
          $builder = $this->db->table('vehicles_list_tbl');
            $builder->where('id',$id);
            $builder->update($data);
            return $builder;
    }
function delete_vehicle($id){
$builder = $this->db->table('vehicles_list_tbl');
			$builder->where('id',$id);
			$builder->delete();
			  return $builder;	
}
function singleVehicleRoute($id){

   	 $builder = $this->db->table('station_tbl');
    $builder->select('*');
    $builder->where('station_tbl.id',$id);
    $result = $builder->get()->getResult();
    return $result;
}
function edit_vehicle_route($data,$id){
 $builder = $this->db->table('route_vehicles_tbl');
            $builder->where('id',$id);
            $builder->update($data);
            return $builder;
}
function delete_RouteVehicle($id){
	$builder = $this->db->table('route_vehicles_tbl');
			$builder->where('id',$id);
			$builder->delete();
			  return $builder;
	}
	function check_vehicle_route($vid,$rid,$stime,$etime){
 $builder = $this->db->table('route_vehicles_tbl');
    $builder->select('*');
     $builder->where('route_vehicles_tbl.vehicle_id',$vid);
     //$builder->where('route_vehicles_tbl.route_id',$rid);
    // $builder->where('DATE(start_time) >=',  $stime);
    // $builder->where('DATE(end_time) >=', $stime);
    $result = $builder->get()->getResult();
    return $result;
	}

	function search_createdby($id){
		$builder = $this->db->table('users');
		$builder->select('*');
			$builder->where('user_id',$id);
			$result = $builder->get()->getResult();
    return $result;

	}
	function fetch_route_data($id){
			$builder = $this->db->table('route_tbl');
		$builder->select('*');
			$builder->where('id',$id);
			$result = $builder->get()->getResult();
    return $result;
	}
	function search_vehicle($id){
		$builder = $this->db->table('vehicles_list_tbl');
		$builder->select('*');
			$builder->where('id',$id);
			$result = $builder->get()->getResult();
    return $result;

	}
	function get_termsPayments($id){
         $builder = $this->db->table('installments_tbl');
        $builder->select('installments_tbl.amount,school_terms_tbl.term_name,school_terms_tbl.start_date,school_terms_tbl.end_date
        ');
        $builder->join('school_terms_tbl', 'school_terms_tbl.id = installments_tbl.istallment_name');
        $builder->where('installments_tbl.tbl_id',$id);
        $builder->where('installments_tbl.installment_type',4);
        $query = $builder->get()->getResult();
            
         return $query;   
    }
    public function get_receivableAccount($id){
    $builder = $this->db->table('accounts_tbl');
    $builder->select('*');
    $builder->where('id',$id);
        $query = $builder->get()->getResult();
            
         return $query;
    }


     public function check_ifExist($tbl,$id)
     {
        $builder = $this->db->table($tbl);
        $builder->select('');
        $builder->where($id);
        return $builder->get()->getResult();
     }
       public function saveNew_station($data)
     {
        $builder = $this->db->table('station_tbl')->insert($data);

        if($builder){
            return $this->db->insertID();
        }else{
            return false;
        }
     }

     public function saveSessionData($session)
     {
        $builder = $this->db->table('station_session_tbl')->insert($session);

        return $builder;
     }
      public function Save_Stationcharged_items($itemData)
     {
        $builder = $this->db->table('station_charged_items_tbl')->insert($itemData);
        
        return $builder;

     }
     public function Save_Station_items($itemData,$id)
     {
        $builder = $this->db->table('station_charged_items_tbl');
          $builder->where('item_id',$id);
          $builder->where('station_id',0);
            $builder->update($itemData);
            return $builder;

     }
       public function get_ChargedItems_list($id)
    {
        $builder = $this->db->table('price_tbl');
        $builder->select('item_price,item_id');
        $builder->where('item_id',$id);
        $query = $builder->get()->getResult();

        return $query;
    }
      public function updating_session_data($id,$data)
     {
        $builder = $this->db->table('station_tbl');
        $builder->where('id',$id);
        $builder->update($data);
     }
     public function select_station($id){
      $builder = $this->db->table('station_session_tbl');
        $builder->select('station_tbl.station_name,station_session_tbl.session_name,station_session_tbl.session_time');
        $builder->join('station_tbl','station_tbl.id=station_session_tbl.station_id');
        $builder->where('route_id',$id);
        $query = $builder->get()->getResult();

        return $query;	
     }
     public function get_transport_permit($pid){
     	$builder = $this->db->table('transport_details');
        $builder->select('admission_tbl.*,students.*,classes_tbl.*,transport_details.*,transport_details.created_by,transport_details.student_id');
        $builder->join('admission_tbl','admission_tbl.student_id=transport_details.student_id');
        $builder->join('students','students.id=transport_details.student_id');
        $builder->join('classes_tbl','classes_tbl.id=admission_tbl.class_id');
        $builder->where('transport_details.permit_id',$pid);
        $query = $builder->get()->getResult();

        return $query;	
     }
  public function gettable_dataT($sdate,$edate,$sex,$eex,$trans_type,$status){
     	$builder = $this->db->table('transport_details');
     	$builder->select('*');

     $builder->where('DATE(date_created) >=', $sdate);
    $builder->where('DATE(date_created) <=', $edate);
    $builder->where('DATE(end_date) >=', $sex);
    $builder->where('DATE(end_date) <=', $eex);

    if($trans_type>0 && $status>0){
    	if($status==4){
      $builder->where('DATE(start_date) >', date('Y-m-d'));
      $builder->where('transport_trip',$trans_type);
      $builder->where('status', 1);
    	}elseif($status==1){
      	  $builder->where('DATE(start_date) <=', date('Y-m-d'));
          $builder->where('status',$status);	
         $builder->where('transport_trip',$trans_type);
      }else{
      $builder->where('status',$status);	
    $builder->where('transport_trip',$trans_type);
      }	

    }elseif($trans_type>0 && $status==0){
      $builder->where('transport_trip',$trans_type);	
    }elseif($trans_type==0 && $status>0){
    	if($status==4){
     $builder->where('DATE(start_date) >', date('Y-m-d'));
      $builder->where('status', 1);		
      }elseif($status==1){
      	  $builder->where('DATE(start_date) <=', date('Y-m-d'));
          $builder->where('status',$status);	
        
      }else{
      $builder->where('status',$status);
      }		
    }
     
     $query = $builder->get()->getResult();

        return $query;
     }
     
     function fetch_transport_byname($name,$year){
     	$builder = $this->db->table('transport_details');
     	$builder->select('*,transport_details.status');
     $builder->join('students','students.id=transport_details.student_id');
    $builder->join('admission_tbl','admission_tbl.student_id=students.id and admission_tbl.student_id=transport_details.student_id');
      $builder->where('admission_tbl.academic_year', $year);
    $builder->orderBy('students.full_name','ASC');
     $builder->like('students.full_name',$name,'both');
     	 $query = $builder->get()->getResult();
        $this->db->close();
        return $query;
     }
     
     //end mark
}

