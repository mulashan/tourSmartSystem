<?php

namespace App\Models;

use CodeIgniter\Model;

class LoginModel extends Model
{
     protected $table   = 'users_session_tbl';
     public $db;
    
    public function __construct(){
        $this->db=\Config\Database::connect();
    }
    public function verfy_user($username,$pass){
        $builder = $this->db->table('users_session_tbl');
        $builder->SELECT('*');
        $builder->where('username',$username);
        //$builder->where('password', sha1($pass));
        $builder->where('user_status', 1);
        $result = $builder->get()->getResult();
        $this->db->close();
        return $result;
    }
    
    function get_users_details($user_id){
        $builder = $this->db->table('users');
        // $builder->select('users.user_id,users.first_name,users.last_name,users.user_photo,
        // users.gender,users.national_id,users.other_name,users.email,users.status,users.physical_adress,users.updated_date,
        // users.user_type,users.phone_no,users_session_tbl.initial_username,users_session_tbl.username,users_type_tbl.type_name,database_list_tbl.db_name,database_list_tbl.db_id
        // ');
        $builder->select('');
        $builder->join('users_session_tbl', 'users.user_id = users_session_tbl.user_id');
        $builder->join('users_type_tbl', 'users.user_type = users_type_tbl.id');
        $builder->join('database_list_tbl', 'database_list_tbl.id = users.database_id');
        $builder->where('users.user_id',$user_id);
        $query = $builder->get()->getResult();
         $this->db->close();   
         return $query; 
    }
    function get_allowed_menu($priv_id,$username) {
         $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
        $builder = $this->db->table('modules_privileges');
        $builder->select('modules_tbl.label,modules_tbl.module_id,modules_tbl.collapse,modules_tbl.route_path,modules_tbl.parent_id,menu_icons_tbl.menu_icon,menu_icons_tbl.menu_id,modules_tbl.description,modules_tbl.is_dashboard,modules_tbl.new_message');
        
        $builder->join('modules_tbl', 'modules_tbl.module_id = modules_privileges.module_id');
        $builder->join('menu_icons_tbl', 'menu_icons_tbl.menu_id = modules_tbl.module_id');
        $builder->where('modules_tbl.is_menu', 1);
        $builder->groupStart()
            ->where('privilege_id',$priv_id)
            ->orWhere('privilege_id',$username)
            ->groupEnd();
        $builder->orderBy('modules_tbl.module_id', 'ASC');
        $result = $builder->get()->getResult();
        $this->db->close();
        return $result;
    }
        function get_custom_allowed_submenu($priv_id,$username,$parrent_id) {
             $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
        $builder = $this->db->table('modules_privileges');
        $builder->select('modules_tbl.label,modules_tbl.module_id,modules_tbl.route_path,modules_tbl.parent_id,menu_icons_tbl.menu_icon,menu_icons_tbl.menu_id,modules_tbl.description');
        
        $builder->join('modules_tbl', 'modules_tbl.module_id = modules_privileges.module_id');
        $builder->join('menu_icons_tbl', 'menu_icons_tbl.menu_id = modules_tbl.module_id');
        $builder->where('modules_tbl.is_menu', 0);
        $builder->where('modules_tbl.parent_id', $parrent_id);
        $builder->where('privilege_id',$priv_id);
        //$builder->orwhere('privilege_id',$username);
        $result = $builder->get()->getResult();
        $this->db->close();
         return $result;
        
    }
    function get_custom_allowed_dashboard($priv_id,$parrent_id) {
         $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
        $builder = $this->db->table('modules_privileges');
        $builder->select('modules_tbl.label,modules_tbl.module_id,modules_tbl.route_path,modules_tbl.parent_id,menu_icons_tbl.menu_icon,menu_icons_tbl.menu_id,modules_tbl.description');
        
        $builder->join('modules_tbl', 'modules_tbl.module_id = modules_privileges.module_id');
        $builder->join('menu_icons_tbl', 'menu_icons_tbl.menu_id = modules_tbl.module_id');
        
        $builder->where('modules_tbl.is_menu', 0);
        $builder->where('modules_tbl.is_dashboard', 1);
        $builder->where('modules_tbl.parent_id', $parrent_id);
        $builder->where('privilege_id',$priv_id);
        $result = $builder->get()->getResult();
        $this->db->close();
         return $result;
        
    }
    function get_dashboard($module_id){
         $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    $builder = $this->db->table('modules_tbl');
    $builder->select('is_dashboard');
    $builder->where('modules_tbl.is_dashboard', 1); 
    $builder->where('modules_tbl.module_id',$module_id);
    $result = $builder->get()->getResult();
    $this->db->close();
    return $result; 
    }
    function get_new_message($mn,$id){
        $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    $builder = $this->db->table('new_notifications_tbl');
    $builder->select('*');
    $builder->where('update_id', $mn);  
    $builder->where('user_id',$id);
    $result = $builder->get()->getResult();
    $this->db->close();
    return $result; 
    }
    function get_table_details($tbls){
     $query = $this->db->table($tbls);
     $result = $query->get()->getResult();
    $this->db->close();
    return $result; 
 }
  public function get_student_details($tbl,$id)
    {
        $builder = $this->db->table($tbl);
        $builder->select('');
        $builder->where($id);
        $result = $builder->get()->getResult();
    $this->db->close();
    return $result; 
    }
    
     function update_table_details($table,$condition,$data){
        $builder = $this->db->table($table);
        $builder->where($condition);
        $builder->update($data);
    }

    function update_table_details2($table,$condition,$data,$db){
        $this->db=\Config\Database::connect($db);
        $builder = $this->db->table($table);
        $builder->where($condition);
        $builder->update($data);
    }
    
}

