<?php

namespace App\Models;

use CodeIgniter\Model;

class PaymentsModel extends Model
{
    public $db;
    protected $currentDbName;
    protected static $termBalanceContext;
    protected $requestCache = [];
    public function __construct(){
   
    }

    protected function ensureDb($dbname)
    {
        if ($this->db === null || $this->currentDbName !== $dbname) {
            $this->db = \Config\Database::connect($dbname);
            $this->currentDbName = $dbname;
        }

        return $this->db;
    }

    public static function clearTermBalanceContext()
    {
        self::$termBalanceContext = null;
    }

    protected function getTermBalanceContext($dbname)
    {
        if (! is_array(self::$termBalanceContext)) {
            return null;
        }

        return (self::$termBalanceContext['db'] ?? null) === $dbname ? self::$termBalanceContext : null;
    }

    protected function asKey($parts)
    {
        return implode('|', $parts);
    }

    protected function rememberQuery($namespace, $parts, callable $callback)
    {
        $key = $namespace . '|' . md5(json_encode($parts));
        if (array_key_exists($key, $this->requestCache)) {
            return $this->requestCache[$key];
        }

        $this->requestCache[$key] = $callback();
        return $this->requestCache[$key];
    }

    protected function clearRequestCache()
    {
        $this->requestCache = [];
    }

    protected function filterDateRange($transDate, $date1, $date2, $mode, $ment)
    {
        $value = strtotime(date('Y-m-d', strtotime($transDate)));
        $start = strtotime(date('Y-m-d', strtotime($date1)));
        $end = strtotime(date('Y-m-d', strtotime($date2)));

        if ($mode == 1) {
            return $value <= $end;
        }

        if ($mode == 2) {
            return $ment == 2 ? $value > $start : ($value > $start && $value <= $end);
        }

        if ($mode == 3) {
            return $ment == 3 ? $value > $start : ($value > $start && $value <= $end);
        }

        return $value > $start;
    }

    public function primeTermBalanceContext($studentIds, $year, $dbname)
    {
        $studentIds = array_values(array_unique(array_map('intval', $studentIds)));
        if (count($studentIds) === 0) {
            self::clearTermBalanceContext();
            return null;
        }

        $db = $this->ensureDb($dbname);
        $context = [
            'db' => $dbname,
            'database_list' => [],
            'student_balance' => [],
            'admission' => [],
            'class_level' => [],
            'school_terms' => [],
            'invoice_headers' => [],
            'invoice_items' => [],
            'receipt_rel_by_invoice' => [],
            'receipt_rel_by_receipt' => [],
            'transactions_relation_by_invoice' => [],
            'transactions_relation_by_receipt' => [],
            'receipt_dates' => [],
            'credits' => [],
            'voucher_relation' => [],
            'approval_numbers' => [],
            'approval_history' => [],
            'ledger_by_trans_type_nature' => [],
            'ledger_by_trans_type_ledger_id' => [],
            'ledger_by_trans_type_ledger_type_nature' => [],
            'receipt_transfer' => [],
            'transaction_use' => [],
            'deposit_receipt' => [],
        ];

        $dbRow = $db->table('database_list_tbl')->select('*')->where('db_name', $dbname)->get()->getResult();
        if (count($dbRow) > 0) {
            $context['database_list'][$dbname] = $dbRow;
        }

        $balances = $db->table('student_balance_tbl')
            ->select('*')
            ->whereIn('year', [$year - 1, $year])
            ->whereIn('student_id', $studentIds)
            ->get()
            ->getResult();
        foreach ($balances as $row) {
            $context['student_balance'][$this->asKey([$row->year, $row->student_id])] = [$row];
        }

        $admissions = $db->table('admission_tbl')
            ->select('*')
            ->where('academic_year', $year)
            ->whereIn('student_id', $studentIds)
            ->get()
            ->getResult();
        $levelIds = [];
        foreach ($admissions as $row) {
            $context['admission'][$this->asKey([$row->academic_year, $row->student_id])] = [$row];
            $levelIds[] = (int) $row->level_id;
        }

        if (count($levelIds) > 0) {
            $levels = $db->table('class_level_tbl')
                ->select('*')
                ->whereIn('id', array_values(array_unique($levelIds)))
                ->get()
                ->getResult();
            $typeIds = [];
            foreach ($levels as $row) {
                $context['class_level'][(int) $row->id] = [$row];
                $typeIds[] = (int) $row->academic_type;
            }

            if (count($typeIds) > 0) {
                $terms = $db->table('school_terms_tbl')
                    ->select('*')
                    ->where('academic_year', $year)
                    ->whereIn('type_id', array_values(array_unique($typeIds)))
                    ->orderBy('id', 'ASC')
                    ->get()
                    ->getResult();
                foreach ($terms as $row) {
                    $key = $this->asKey([$row->academic_year, $row->type_id]);
                    if (! isset($context['school_terms'][$key])) {
                        $context['school_terms'][$key] = [];
                    }
                    $context['school_terms'][$key][] = $row;
                }
            }
        }

        $invoiceHeaders = $db->table('ledger_transaction_tbl')
            ->select('ledger_transaction_tbl.*, transaction_numbers_tbl.trans_date')
            ->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no and invoice_type_transaction.transaction_type_id=ledger_transaction_tbl.trans_type')
            ->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no')
            ->whereIn('name_id', $studentIds)
            ->where('ledger_transaction_tbl.transation_nature', 1)
            ->where('ledger_transaction_tbl.trans_type', 1)
            ->where('ledger_transaction_tbl.name_type_id', 1)
            ->where('transaction_numbers_tbl.trans_type_id', 1)
            ->whereIn('invoice_type_transaction.invoice_type_id', [2, 5, 8])
            ->like('transaction_numbers_tbl.trans_date', $year, 'after')
            ->groupBy('ledger_transaction_tbl.trans_no')
            ->get()
            ->getResult();

        $invoiceNos = [];
        foreach ($invoiceHeaders as $row) {
            $invoiceNos[] = (int) $row->trans_no;
            if (! isset($context['invoice_headers'][(int) $row->name_id])) {
                $context['invoice_headers'][(int) $row->name_id] = [];
            }
            $context['invoice_headers'][(int) $row->name_id][] = $row;
        }

        $invoiceNos = array_values(array_unique($invoiceNos));

        if (count($invoiceNos) > 0) {
            $invoiceItems = $db->table('item_transation_tbl')
                ->select('item_transation_tbl.item_id, items_tbl.item_name, items_tbl.item_group, item_transation_tbl.trans_number, item_transation_tbl.quantity, item_transation_tbl.unit_price, invoice_type_transaction.invoice_type_id')
                ->join('items_tbl', 'item_transation_tbl.item_id = items_tbl.id')
                ->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = item_transation_tbl.trans_number')
                ->where('invoice_type_transaction.transaction_type_id', 1)
                ->where('item_transation_tbl.trans_type', 1)
                ->whereIn('item_transation_tbl.trans_number', $invoiceNos)
                ->get()
                ->getResult();
            foreach ($invoiceItems as $row) {
                $key = (int) $row->trans_number;
                if (! isset($context['invoice_items'][$key])) {
                    $context['invoice_items'][$key] = [];
                }
                $context['invoice_items'][$key][] = $row;
            }
        }

        $negativeBalanceInvoiceNos = [];
        foreach ($balances as $row) {
            if ((int) $row->year === (int) ($year - 1) && (int) $row->balance < 0 && (int) $row->debted_inv_no > 0) {
                $negativeBalanceInvoiceNos[] = (int) $row->debted_inv_no;
            }
        }

        $relationInvoiceNos = array_values(array_unique(array_merge($invoiceNos, $negativeBalanceInvoiceNos)));
        $receiptNos = [];
        if (count($relationInvoiceNos) > 0) {
            $relations = $db->table('transactions_relation')
                ->select('*')
                ->whereIn('invoice_trans_no', $relationInvoiceNos)
                ->orderBy('id', 'ASC')
                ->get()
                ->getResult();
            foreach ($relations as $row) {
                $invoiceKey = (int) $row->invoice_trans_no;
                $receiptKey = (int) $row->receipt_trans_no;
                if (! isset($context['receipt_rel_by_invoice'][$invoiceKey])) {
                    $context['receipt_rel_by_invoice'][$invoiceKey] = [];
                }
                if (! isset($context['receipt_rel_by_receipt'][$receiptKey])) {
                    $context['receipt_rel_by_receipt'][$receiptKey] = [];
                }
                if (! isset($context['transactions_relation_by_invoice'][$invoiceKey])) {
                    $context['transactions_relation_by_invoice'][$invoiceKey] = [];
                }
                if (! isset($context['transactions_relation_by_receipt'][$receiptKey])) {
                    $context['transactions_relation_by_receipt'][$receiptKey] = [];
                }
                $context['receipt_rel_by_invoice'][$invoiceKey][] = $receiptKey;
                $context['receipt_rel_by_receipt'][$receiptKey][] = $invoiceKey;
                $context['transactions_relation_by_invoice'][$invoiceKey][] = $row;
                $context['transactions_relation_by_receipt'][$receiptKey][] = $row;
                $receiptNos[] = $receiptKey;
            }
        }

        if (count($negativeBalanceInvoiceNos) > 0) {
            $invoiceBalanceRows = $db->table('ledger_transaction_tbl')
                ->select('*')
                ->where('trans_type', 1)
                ->where('transation_nature', 2)
                ->where('ledger_type', 7)
                ->whereIn('trans_no', $negativeBalanceInvoiceNos)
                ->orderBy('id', 'ASC')
                ->get()
                ->getResult();
            foreach ($invoiceBalanceRows as $row) {
                $key1 = $this->asKey([$row->trans_no, $row->trans_type, $row->transation_nature]);
                $key2 = $this->asKey([$row->trans_no, $row->trans_type, $row->ledger_id]);
                $key3 = $this->asKey([$row->trans_no, $row->trans_type, $row->ledger_type, $row->transation_nature]);
                if (! isset($context['ledger_by_trans_type_nature'][$key1])) {
                    $context['ledger_by_trans_type_nature'][$key1] = [];
                }
                if (! isset($context['ledger_by_trans_type_ledger_id'][$key2])) {
                    $context['ledger_by_trans_type_ledger_id'][$key2] = [];
                }
                if (! isset($context['ledger_by_trans_type_ledger_type_nature'][$key3])) {
                    $context['ledger_by_trans_type_ledger_type_nature'][$key3] = [];
                }
                $context['ledger_by_trans_type_nature'][$key1][] = $row;
                $context['ledger_by_trans_type_ledger_id'][$key2][] = $row;
                $context['ledger_by_trans_type_ledger_type_nature'][$key3][] = $row;
            }
        }

        $receiptNos = array_values(array_unique($receiptNos));
        if (count($receiptNos) > 0) {
            $receiptRelations = $db->table('transactions_relation')
                ->select('*')
                ->whereIn('receipt_trans_no', $receiptNos)
                ->orderBy('id', 'ASC')
                ->get()
                ->getResult();
            $seenReceiptRelationIds = [];
            foreach ($receiptRelations as $row) {
                if (isset($seenReceiptRelationIds[(int) $row->id])) {
                    continue;
                }
                $seenReceiptRelationIds[(int) $row->id] = true;
                $receiptKey = (int) $row->receipt_trans_no;
                $invoiceKey = (int) $row->invoice_trans_no;
                if (! isset($context['transactions_relation_by_receipt'][$receiptKey])) {
                    $context['transactions_relation_by_receipt'][$receiptKey] = [];
                }
                $existingReceiptIds = array_map(static fn($item) => (int) $item->id, $context['transactions_relation_by_receipt'][$receiptKey]);
                if (! in_array((int) $row->id, $existingReceiptIds, true)) {
                    $context['transactions_relation_by_receipt'][$receiptKey][] = $row;
                }

                if (! isset($context['transactions_relation_by_invoice'][$invoiceKey])) {
                    $context['transactions_relation_by_invoice'][$invoiceKey] = [];
                }
                $existingInvoiceIds = array_map(static fn($item) => (int) $item->id, $context['transactions_relation_by_invoice'][$invoiceKey]);
                if (! in_array((int) $row->id, $existingInvoiceIds, true)) {
                    $context['transactions_relation_by_invoice'][$invoiceKey][] = $row;
                }
            }

            foreach ($context['transactions_relation_by_receipt'] as &$rows) {
                usort($rows, static function ($a, $b) {
                    return (int) $a->id <=> (int) $b->id;
                });
            }
            unset($rows);

            foreach ($context['transactions_relation_by_invoice'] as &$rows) {
                usort($rows, static function ($a, $b) {
                    return (int) $a->id <=> (int) $b->id;
                });
            }
            unset($rows);

            $receiptDates = $db->table('transaction_numbers_tbl')
                ->select('trans_number, trans_date')
                ->where('trans_type_id', 2)
                ->whereIn('trans_number', $receiptNos)
                ->get()
                ->getResult();
            foreach ($receiptDates as $row) {
                $context['receipt_dates'][(int) $row->trans_number] = $row->trans_date;
            }

            $receiptLedgerRows = $db->table('ledger_transaction_tbl')
                ->select('*')
                ->where('trans_type', 2)
                ->whereIn('trans_no', $receiptNos)
                ->orderBy('id', 'ASC')
                ->get()
                ->getResult();
            foreach ($receiptLedgerRows as $row) {
                $key1 = $this->asKey([$row->trans_no, $row->trans_type, $row->transation_nature]);
                $key2 = $this->asKey([$row->trans_no, $row->trans_type, $row->ledger_id]);
                $key3 = $this->asKey([$row->trans_no, $row->trans_type, $row->ledger_type, $row->transation_nature]);
                if (! isset($context['ledger_by_trans_type_nature'][$key1])) {
                    $context['ledger_by_trans_type_nature'][$key1] = [];
                }
                if (! isset($context['ledger_by_trans_type_ledger_id'][$key2])) {
                    $context['ledger_by_trans_type_ledger_id'][$key2] = [];
                }
                if (! isset($context['ledger_by_trans_type_ledger_type_nature'][$key3])) {
                    $context['ledger_by_trans_type_ledger_type_nature'][$key3] = [];
                }
                $context['ledger_by_trans_type_nature'][$key1][] = $row;
                $context['ledger_by_trans_type_ledger_id'][$key2][] = $row;
                $context['ledger_by_trans_type_ledger_type_nature'][$key3][] = $row;
            }

            $transfers = $db->table('receipt_transfer_tbl')
                ->select('*')
                ->whereIn('old_receipt_number', array_map('strval', $receiptNos))
                ->get()
                ->getResult();
            foreach ($transfers as $row) {
                $context['receipt_transfer'][(string) $row->old_receipt_number][] = $row;
            }

            $usedRows = $db->table('transaction_use_relation_tbl')
                ->select('*')
                ->whereIn('used_no', array_map('strval', $receiptNos))
                ->where('trans_type', 5)
                ->get()
                ->getResult();
            foreach ($usedRows as $row) {
                $context['transaction_use'][$this->asKey([$row->used_no, $row->trans_type])][] = $row;
            }
        }

        if (count($invoiceNos) > 0) {
            $depositRows = $db->table('deposit_receipt_tbl')
                ->select('*')
                ->whereIn('invoice_number', array_map('strval', $invoiceNos))
                ->where('receipt_number', 0)
                ->get()
                ->getResult();
            foreach ($depositRows as $row) {
                $context['deposit_receipt'][(string) $row->invoice_number][] = $row;
            }
        }

        $creditRows = $db->table('ledger_transaction_tbl')
            ->select('ledger_transaction_tbl.name_id, transaction_numbers_tbl.trans_number, transaction_numbers_tbl.trans_date, SUM(ledger_transaction_tbl.amount) as amount')
            ->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no')
            ->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = transaction_numbers_tbl.trans_number')
            ->whereIn('ledger_transaction_tbl.name_id', $studentIds)
            ->like('transaction_numbers_tbl.trans_date', $year, 'after')
            ->where('ledger_transaction_tbl.transation_nature', 2)
            ->where('ledger_transaction_tbl.trans_type', 6)
            ->where('invoice_type_transaction.transaction_type_id', 6)
            ->where('invoice_type_transaction.invoice_type_id', 2)
            ->where('ledger_transaction_tbl.name_type_id', 1)
            ->where('transaction_numbers_tbl.trans_type_id', 6)
            ->groupBy('ledger_transaction_tbl.name_id, transaction_numbers_tbl.trans_number, transaction_numbers_tbl.trans_date')
            ->get()
            ->getResult();

        $creditNos = [];
        foreach ($creditRows as $row) {
            if (! isset($context['credits'][(int) $row->name_id])) {
                $context['credits'][(int) $row->name_id] = [];
            }
            $context['credits'][(int) $row->name_id][] = $row;
            $creditNos[] = (string) $row->trans_number;
        }

        $voucherTransNos = array_values(array_unique(array_merge(array_map('strval', $receiptNos), $creditNos)));
        if (count($voucherTransNos) > 0) {
            $voucherRows = $db->table('voucher_relation_tbl')
                ->select('*')
                ->whereIn('trans_no', $voucherTransNos)
                ->where('voucher_type', 5)
                ->whereIn('trans_type', [2, 6])
                ->get()
                ->getResult();

            $paymentNos = [];
            foreach ($voucherRows as $row) {
                $key = $this->asKey([$row->trans_no, $row->voucher_type, $row->trans_type]);
                if (! isset($context['voucher_relation'][$key])) {
                    $context['voucher_relation'][$key] = [];
                }
                $context['voucher_relation'][$key][] = $row;
                $paymentNos[] = (int) $row->payment_no;
            }

            $paymentNos = array_values(array_unique($paymentNos));
            if (count($paymentNos) > 0) {
                $approvalNumbers = $db->table('approval_numbers')
                    ->select('*')
                    ->where('trans_type', 5)
                    ->whereIn('trans_no', $paymentNos)
                    ->get()
                    ->getResult();
                $appNos = [];
                foreach ($approvalNumbers as $row) {
                    $context['approval_numbers'][$this->asKey([$row->trans_no, $row->trans_type])][] = $row;
                    $appNos[] = (int) $row->app_id;
                }

                if (count($appNos) > 0) {
                    $approvalHistory = $db->table('approval_history')
                        ->select('*')
                        ->where('hstatus', 1)
                        ->whereIn('app_no', $appNos)
                        ->get()
                        ->getResult();
                    foreach ($approvalHistory as $row) {
                        $context['approval_history'][$this->asKey([$row->app_no, $row->hstatus])][] = $row;
                    }
                }

                $type5Ledger = $db->table('ledger_transaction_tbl')
                    ->select('*')
                    ->where('trans_type', 5)
                    ->where('transation_nature', 1)
                    ->whereIn('trans_no', $paymentNos)
                    ->get()
                    ->getResult();
                foreach ($type5Ledger as $row) {
                    $context['ledger_by_trans_type_nature'][$this->asKey([$row->trans_no, $row->trans_type, $row->transation_nature])][] = $row;
                }
            }
        }

        self::$termBalanceContext = $context;

        return $context;
    }

    function gettable_data($tbl,$id,$dbname){
     $this->ensureDb($dbname);
     $query = $this->db->table($tbl);
     $query->select('*');
     $query->where($id);
     return $query->get()->getResult();
 }
 public function SaveData($tbl,$data,$dbname){
    $this->ensureDb($dbname);
    $this->clearRequestCache();
    $query = $this->db->table($tbl)->insert($data);
    return $query;
}
function update_table_details($table,$condition,$data,$dbname){
    $this->ensureDb($dbname);
    $this->clearRequestCache();
    $builder = $this->db->table($table);
    $builder->where($condition);
    $builder->update($data);
}
function select_inv_id($trno,$dbname){
    $this->ensureDb($dbname);
    $builder = $this->db->table('invoice_type_transaction');
        $builder->select('*');
       $builder->where('trans_no', $trno);
       $builder->where('transaction_type_id',1);
      $result = $builder->get()->getResult();
        return $result;    
 } 
   public function SaveData_n_get_id($tbl,$data,$dbname){
    $this->ensureDb($dbname);
    $this->clearRequestCache();
    $query = $this->db->table($tbl)->insert($data);
    if($query)
    {
        return $this->db->insertID();
    }
    else{
        return false;
     }
}
function get_item_name($tbl,$condition,$dbname){
    $context = $this->getTermBalanceContext($dbname);
    if ($context !== null) {
        if ($tbl === 'database_list_tbl' && isset($condition['db_name'])) {
            return $context['database_list'][$condition['db_name']] ?? [];
        }

        if ($tbl === 'student_balance_tbl' && isset($condition['year'], $condition['student_id'])) {
            return $context['student_balance'][$this->asKey([$condition['year'], $condition['student_id']])] ?? [];
        }

        if ($tbl === 'admission_tbl' && isset($condition['academic_year'], $condition['student_id'])) {
            return $context['admission'][$this->asKey([$condition['academic_year'], $condition['student_id']])] ?? [];
        }

        if ($tbl === 'class_level_tbl' && isset($condition['id'])) {
            return $context['class_level'][(int) $condition['id']] ?? [];
        }

        if ($tbl === 'school_terms_tbl' && isset($condition['academic_year'], $condition['type_id'])) {
            return $context['school_terms'][$this->asKey([$condition['academic_year'], $condition['type_id']])] ?? [];
        }

        if ($tbl === 'voucher_relation_tbl' && isset($condition['trans_no'], $condition['voucher_type'], $condition['trans_type'])) {
            return $context['voucher_relation'][$this->asKey([$condition['trans_no'], $condition['voucher_type'], $condition['trans_type']])] ?? [];
        }

        if ($tbl === 'approval_numbers' && isset($condition['trans_no'], $condition['trans_type'])) {
            return $context['approval_numbers'][$this->asKey([$condition['trans_no'], $condition['trans_type']])] ?? [];
        }

        if ($tbl === 'approval_history' && isset($condition['app_no'], $condition['hstatus'])) {
            return $context['approval_history'][$this->asKey([$condition['app_no'], $condition['hstatus']])] ?? [];
        }

        if ($tbl === 'ledger_transaction_tbl' && isset($condition['trans_no'], $condition['trans_type'], $condition['transation_nature'])) {
            if (isset($condition['ledger_id'])) {
                $rows = $context['ledger_by_trans_type_ledger_id'][$this->asKey([$condition['trans_no'], $condition['trans_type'], $condition['ledger_id']])] ?? [];
                return array_values(array_filter($rows, static function ($row) use ($condition) {
                    return (int) $row->transation_nature === (int) $condition['transation_nature'];
                }));
            }

            return $context['ledger_by_trans_type_nature'][$this->asKey([$condition['trans_no'], $condition['trans_type'], $condition['transation_nature']])] ?? [];
        }

        if ($tbl === 'ledger_transaction_tbl' && isset($condition['ledger_id'], $condition['trans_no'], $condition['trans_type'])) {
            $rows = $context['ledger_by_trans_type_ledger_id'][$this->asKey([$condition['trans_no'], $condition['trans_type'], $condition['ledger_id']])] ?? [];
            if (isset($condition['transation_nature'])) {
                $rows = array_values(array_filter($rows, static function ($row) use ($condition) {
                    return (int) $row->transation_nature === (int) $condition['transation_nature'];
                }));
            }
            return $rows;
        }

        if ($tbl === 'ledger_transaction_tbl' && isset($condition['ledger_type'], $condition['trans_no'], $condition['trans_type'], $condition['transation_nature'])) {
            return $context['ledger_by_trans_type_ledger_type_nature'][$this->asKey([$condition['trans_no'], $condition['trans_type'], $condition['ledger_type'], $condition['transation_nature']])] ?? [];
        }

        if ($tbl === 'transactions_relation' && isset($condition['invoice_trans_no'])) {
            $invoiceNo = (int) $condition['invoice_trans_no'];
            return $context['transactions_relation_by_invoice'][$invoiceNo] ?? [];
        }

        if ($tbl === 'transactions_relation' && isset($condition['receipt_trans_no'])) {
            $receiptNo = (int) $condition['receipt_trans_no'];
            return $context['transactions_relation_by_receipt'][$receiptNo] ?? [];
        }

        if ($tbl === 'receipt_transfer_tbl' && isset($condition['old_receipt_number'])) {
            return $context['receipt_transfer'][(string) $condition['old_receipt_number']] ?? [];
        }

        if ($tbl === 'transaction_use_relation_tbl' && isset($condition['used_no'], $condition['trans_type'])) {
            return $context['transaction_use'][$this->asKey([$condition['used_no'], $condition['trans_type']])] ?? [];
        }
    }

    return $this->rememberQuery(__FUNCTION__, [$dbname, $tbl, $condition], function () use ($dbname, $tbl, $condition) {
        $this->ensureDb($dbname);
        $builder = $this->db->table($tbl);
        $builder->select('*');
        $builder->where($condition);
        return $builder->get()->getResult();
    });
}
 function gettable_billingdata($id,$dbname){
    $this->ensureDb($dbname);
    $builder = $this->db->table('parents_students_tbl');
    $builder->select('parents_tbl.id,first_name,last_name,full_name,occupation,address,phone1,email,postal_address');
    $builder->join('parents_tbl', 'parents_tbl.id = parents_students_tbl.parent_id');
    $builder->where('parents_students_tbl.student_id',$id);
    $builder->where('bill_account',1);
    return $builder->get()->getResult();
 }

 //sms models added below
     public function load_messages_balances($dbname)
    {
        $this->db=\Config\Database::connect($dbname);
        $builder = $this->db->table('messages_balances');
        $builder->selectSum('balance');
        $builder->select('b_id');
        $query = $builder->get()->getResult();

        return $query;
    }

    public function save_messages_balances($tbl,$data,$dbname)
    {
        $this->db=\Config\Database::connect($dbname);
        $builder = $this->db->table($tbl)->insert($data);
        return $builder;
    }

    public function update_messages_balances($id,$data2,$dbname)
    {
        $this->db=\Config\Database::connect($dbname);
        $builder = $this->db->table('messages_balances');
        $builder->where('b_id',$id);
        $builder->update($data2);
    }

    public function messages_deposit_details($tbls,$dbname)
    {
        $this->db=\Config\Database::connect($dbname);
        $builder = $this->db->table($tbls);
        return $builder->get()->getResult();
    }

    public function get_messages_details($tbl,$id,$dbname)
    {
        $this->db=\Config\Database::connect($dbname);
        $builder = $this->db->table($tbl);
        $builder->select('');
        $builder->where($id);
        return $builder->get()->getResult();
    }

    public function load_messages($startdate,$enddate,$dbname)
    {
        $this->db=\Config\Database::connect($dbname);
        $builder = $this->db->table('messages');
        $builder->select('*');
        $builder->join('message_groups_tbl', 'message_groups_tbl.send_number = messages.send_no');
        $builder->where('created_at >=', $startdate);
        $builder->where('created_at <=', $enddate);
        $builder->groupBy('messages.send_no');

        return $builder->get()->getResult();
    }

    public function update_sms_balance($smsDt, $id,$dbname)
    {
        $this->db=\Config\Database::connect($dbname);
        $builder = $this->db->table('messages_balances');
        $builder->where('b_id',$id);
        $builder->update($smsDt);
    }

    public function get_total_balance($dbname)
    {
        $this->db=\Config\Database::connect($dbname);
        $builder = $this->db->table('messages');
        $builder->selectSum('cost');
        return $builder->get()->getResult();
    }
function get_max_receipt($tbl,$col,$dbname){
     $this->db=\Config\Database::connect($dbname);
      $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    $builder->where('trans_type_id', 2);
    return $builder->get()->getResult();
  }
  function get_max_id($tbl,$col,$dbname){
    $this->db=\Config\Database::connect($dbname);
     $builder = $this->db->table($tbl);
     $builder->select('max('.$col.') as max_id');
     return $builder->get()->getResult();
  }
   function get_total_invoice_amount($id,$year,$dbname){
       $context = $this->getTermBalanceContext($dbname);
       if ($context !== null) {
           return $context['invoice_headers'][(int) $id] ?? [];
       }
       return $this->rememberQuery(__FUNCTION__, [$dbname, $id, $year], function () use ($dbname, $id, $year) {
           $this->ensureDb($dbname);
           $builder = $this->db->table('ledger_transaction_tbl');
           $builder->select('*');
           $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no and invoice_type_transaction.transaction_type_id=ledger_transaction_tbl.trans_type');
           $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
           $builder->where('name_id',$id);
           $builder->where('transation_nature = 1');
           $builder->where('ledger_transaction_tbl.trans_type', 1);
           $builder->where('transaction_numbers_tbl.trans_type_id', 1);
           $builder->where('ledger_transaction_tbl.name_type_id',1);
           $builder->whereIn('invoice_type_transaction.invoice_type_id', [2, 5, 8]);
           $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
           $builder->groupBy('ledger_transaction_tbl.trans_no');
           return $builder->get()->getResult();
       });
        } 

   function get_total_invoice_amount_type2($id,$year,$dbname){
       return $this->rememberQuery(__FUNCTION__, [$dbname, $id, $year], function () use ($dbname, $id, $year) {
           $this->ensureDb($dbname);
           $builder = $this->db->table('ledger_transaction_tbl');
           $builder->select('*');
           $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no and invoice_type_transaction.transaction_type_id=ledger_transaction_tbl.trans_type');
           $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
           $builder->where('name_id',$id);
           $builder->where('transation_nature = 1');
           $builder->where('ledger_transaction_tbl.trans_type', 1);
           $builder->where('ledger_transaction_tbl.name_type_id',1);
           $builder->where('transaction_numbers_tbl.trans_type_id', 1);
           $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
           $builder->whereIn('invoice_type_transaction.invoice_type_id', [2]);
           $builder->groupBy('ledger_transaction_tbl.trans_no');
           return $builder->get()->getResult();
       });
   }

  function get_pai_receipt($trans,$date1,$date2,$y,$year,$dbname,$ment=3){
    $context = $this->getTermBalanceContext($dbname);
    if ($context !== null) {
        $results = [];
        $seen = [];
        foreach ($trans as $invoiceNo) {
            $receiptNos = $context['receipt_rel_by_invoice'][(int) $invoiceNo] ?? [];
            foreach ($receiptNos as $receiptNo) {
                if (isset($seen[$receiptNo])) {
                    continue;
                }
                $transDate = $context['receipt_dates'][(int) $receiptNo] ?? null;
                if ($transDate === null) {
                    continue;
                }
                if (! $this->filterDateRange($transDate, $date1, $date2, $y, $ment)) {
                    continue;
                }
                $row = new \stdClass();
                $row->trans_number = $receiptNo;
                $results[] = $row;
                $seen[$receiptNo] = true;
            }
        }

        return $results;
    }
    
    return $this->rememberQuery(__FUNCTION__, [$dbname, $trans, $date1, $date2, $y, $year, $ment], function () use ($dbname, $trans, $date1, $date2, $y, $year, $ment) {
        $this->ensureDb($dbname); 
        $builder = $this->db->table('transactions_relation');
        $builder->select('transaction_numbers_tbl.trans_number');
        $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = transactions_relation.receipt_trans_no');
      
        $builder->where('transaction_numbers_tbl.trans_type_id',2);
        $builder->whereIn('transactions_relation.invoice_trans_no', $trans);
        if($y==1){
            $builder->where('DATE(trans_date) <=', $date2);
        }elseif($y==2){
            if($ment==2){
                $builder->where('DATE(trans_date) >', $date1);
            }else{
                $builder->where('DATE(trans_date) >', $date1);
                $builder->where('DATE(trans_date) <=', $date2);
            }
        }elseif($y==3){
            if($ment==3){
                $builder->where('DATE(trans_date) >', $date1);
            }else{
                $builder->where('DATE(trans_date) >', $date1);
                $builder->where('DATE(trans_date) <=', $date2);
            }
        }else{
            $builder->where('DATE(trans_date) >', $date1);    
        }
        
        $builder->groupBy('transaction_numbers_tbl.trans_number');
        return $builder->get()->getResult();
    });
 
 }  
   
    function get_paid_credit($id,$date1,$date2,$y,$year,$dbname){
     $context = $this->getTermBalanceContext($dbname);
     if ($context !== null) {
         $rows = [];
         foreach ($context['credits'][(int) $id] ?? [] as $credit) {
             if (strpos((string) $credit->trans_date, (string) $year) !== 0) {
                 continue;
             }
             if (! $this->filterDateRange($credit->trans_date, $date1, $date2, $y, 0)) {
                 continue;
             }
             $rows[] = $credit;
         }
         return $rows;
     }
     return $this->rememberQuery(__FUNCTION__, [$dbname, $id, $date1, $date2, $y, $year], function () use ($dbname, $id, $date1, $date2, $y, $year) {
        $this->ensureDb($dbname);  
        $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('*,sum(amount) as amount');
        $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
        $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = transaction_numbers_tbl.trans_number');
        $builder->where('name_id',$id);
        $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
        if($y==1){
            $builder->where('DATE(trans_date) <=', $date2);
        }elseif($y==2){
            $builder->where('DATE(trans_date) >', $date1);
            $builder->where('DATE(trans_date) <=', $date2);
        }else{
            $builder->where('DATE(trans_date) >', $date1); 
        }
     
        $builder->where('transation_nature = 2' );
        $builder->where('ledger_transaction_tbl.trans_type', 6);
        $builder->where('invoice_type_transaction.transaction_type_id', 6);
        $builder->where('invoice_type_transaction.invoice_type_id', 2);
        $builder->where('ledger_transaction_tbl.name_type_id',1);
        $builder->where('transaction_numbers_tbl.trans_type_id',6);
        $builder->groupBy('ledger_transaction_tbl.trans_no');
        return $builder->get()->getResult();
     });
 
 }   
   function get_transaction2($id,$type,$nameid,$tp,$dbname) {
       $context = $this->getTermBalanceContext($dbname);
       if ($context !== null) {
            $rows = $context['ledger_by_trans_type_nature'][$this->asKey([$id, $tp, $type])] ?? [];
            $rows = array_values(array_filter($rows, static function ($row) {
                return (int) $row->trans_item === 0 && (int) $row->ledger_type !== 7 && (int) $row->ledger_id !== 22;
            }));
            return count($rows) > 0 ? [$rows[0]] : [];
        }
        return $this->rememberQuery(__FUNCTION__, [$dbname, $id, $type, $nameid, $tp], function () use ($dbname, $id, $type, $tp) {
             $this->ensureDb($dbname);
             $builder = $this->db->table('invoice_type_transaction');
            $builder->select('*');
            $builder->join('ledger_transaction_tbl', 'ledger_transaction_tbl.trans_no = invoice_type_transaction.trans_no');
            $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = invoice_type_transaction.trans_no');
            $builder->where('ledger_transaction_tbl.transation_nature', $type);
            $builder->where('ledger_transaction_tbl.trans_type', $tp);
            $builder->where('invoice_type_transaction.trans_no', $id);
            $builder->where('invoice_type_transaction.transaction_type_id',$tp);
            $builder->where('ledger_transaction_tbl.trans_item',0);
            $builder->where('ledger_transaction_tbl.ledger_type!=',7);
            $builder->where('ledger_transaction_tbl.ledger_id!=',22);
            $builder->where('transaction_numbers_tbl.trans_type_id',$tp);
            $builder->groupBy('ledger_transaction_tbl.trans_no');
            return $builder->get()->getResult();
       });   
         }

   function checkTerm_date($todate,$year,$dbname,$typeid){
         $context = $this->getTermBalanceContext($dbname);
         if ($context !== null) {
             $rows = $context['school_terms'][$this->asKey([$year, $typeid])] ?? [];
             return array_values(array_filter($rows, static function ($row) use ($todate) {
                 return strtotime($row->end_date) >= strtotime($todate);
             }));
         }
         $this->ensureDb($dbname);
    $builder = $this->db->table('school_terms_tbl');
    $builder->select('');
    //$builder->where('DATE(start_date) <=',  $todate);
    $builder->where('DATE(end_date) >=', $todate);
    $builder->where('academic_year', $year);
    $builder->where('type_id', $typeid);
    return $builder->get()->getResult();

   }

  function checkTerm_date2($todate,$year,$dbname,$typeid){
     $context = $this->getTermBalanceContext($dbname);
     if ($context !== null) {
         $rows = $context['school_terms'][$this->asKey([$year, $typeid])] ?? [];
         usort($rows, static function ($a, $b) {
             return (int) $b->id <=> (int) $a->id;
         });
         return $rows;
     }
     $this->ensureDb($dbname);
     $builder = $this->db->table('school_terms_tbl');
    $builder->select('*'); // Select all columns or specify the needed columns
    $builder->orderBy('id','DESC');
    $builder->where('academic_year', $year);
    $builder->where('type_id', $typeid);
    return $builder->get()->getResult();

   }
   
   function get_specific_name($tbl,$condition,$dbname,$data){
    $this->ensureDb($dbname);
      $builder = $this->db->table($tbl);
      $builder->select($data);
      $builder->where($condition);
    //  $builder->orderBy('id','DESC');
      $query = $builder->get()->getResult();
      return $query;
 }
   
  function get_max_deposit($tbl,$col,$dbname){
$this->ensureDb($dbname);
$builder = $this->db->table($tbl);
$builder->select('trans_number');
$builder->where('trans_type_id', 3);
$builder->like($col, "DEP", 'after');

return $builder->get()->getResult();


  }
  
  function get_prepaid_deposited($trans,$dbname){
    $context = $this->getTermBalanceContext($dbname);
    if ($context !== null) {
        $rows = [];
        foreach ($trans as $invoiceNo) {
            foreach ($context['deposit_receipt'][(string) $invoiceNo] ?? [] as $row) {
                $rows[] = $row;
            }
        }
        return $rows;
    }
    $this->ensureDb($dbname); 
    $builder = $this->db->table('deposit_receipt_tbl');
    $builder->select('*');
  $builder->whereIn('deposit_receipt_tbl.invoice_number', $trans);
  $builder->where('receipt_number', 0);
  $query = $builder->get()->getResult();
    return $query;
 
    } 

function get_invoice_items_for_calc($transNo, $dbname)
{
    $context = $this->getTermBalanceContext($dbname);
    if ($context !== null) {
        return $context['invoice_items'][(int) $transNo] ?? [];
    }

    return $this->rememberQuery(__FUNCTION__, [$dbname, $transNo], function () use ($dbname, $transNo) {
        $this->ensureDb($dbname);
        return $this->db->table('item_transation_tbl')
            ->select('item_transation_tbl.item_id, items_tbl.item_name, items_tbl.item_group, item_transation_tbl.trans_number, item_transation_tbl.quantity, item_transation_tbl.unit_price, invoice_type_transaction.invoice_type_id')
            ->join('items_tbl', 'item_transation_tbl.item_id = items_tbl.id')
            ->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = item_transation_tbl.trans_number')
            ->where('invoice_type_transaction.transaction_type_id', 1)
            ->where('item_transation_tbl.trans_type', 1)
            ->where('item_transation_tbl.trans_number', $transNo)
            ->get()
            ->getResult();
    });
}
    
function deleteThisItem($item_id,$trans_number,$student_id,$year, $dbname)
{
 $this->ensureDb($dbname); 
$builder = $this->db->table('ledger_transaction_tbl');
    $builder->where('trans_no',$trans_number);
    $builder->where('trans_type',1);
    $builder->where('trans_item',$item_id);
    $builder->where('name_id',$student_id);
    $builder->delete();

    $builder = $this->db->table('item_transation_tbl');
    $builder->where('trans_number',$trans_number);
    $builder->where('trans_type',1);
    $builder->where('item_id',$item_id);
    $builder->delete();

   $data=array(
      'adimit_for'=>0,
      'date_joined'=>'2025-01-06',
    );
     $builder = $this->db->table("admission_tbl");
   $builder->where('student_id',$student_id);
   $builder->where('academic_year',$year);
   $builder->where('class_id',4);
    $builder->update($data);

    $data2=array(
      'amount'=>2800000,
      'balance'=>2800000,
    );
    $builder = $this->db->table("ledger_transaction_tbl");
   $builder->where('trans_no',$trans_number);
    $builder->where('trans_type',1);
    $builder->where('transation_nature',2);
    $builder->where('name_id',$student_id);
    $builder->update($data2);
}

 function get_account_details($tbl,$col,$dbname){
$this->db=\Config\Database::connect($dbname);
$builder = $this->db->table($tbl);
$builder->select('*');
$builder->like($col, "CRDB", 'both');

return $builder->get()->getResult();

}
   
}

