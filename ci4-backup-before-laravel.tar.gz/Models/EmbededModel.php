<?php

namespace App\Models;

use CodeIgniter\Model;

class EmbededModel extends Model {
    protected $db; // this will hold your connection

    public function __construct($db = null) {
        parent::__construct();
        if ($db) {
            $this->db = $db; // use injected connection
        } else {
            $this->db = \Config\Database::connect(); // fallback to default
        }
    }

    public function setDatabase($db) {
        $this->db = $db;
    }

    public function get_staff_data($data,$transNo,$payroll_id){
        $builder = $this->db->table('staff_payrolls_tbl');
        $builder->select('staff_payrolls_tbl.*,users.first_name,users.last_name,
            staff_details_tbl.pension_no,staff_details_tbl.tin_no,staff_details_tbl.nhf_no,
            staff_details_tbl.wcf_no,job_tittle_tbl.job_tittle,departments_tbl.dep_name,
            months.month,months.month_id,payrolls_tbl.payroll_year,transaction_numbers_tbl.trans_date,classification_tbl.class_name,
            transaction_numbers_tbl.trans_number,payroll_payments_relations_tbl.amount_paid,staff_details_tbl.account_number,bank_lists_tbl.bank_name,staff_details_tbl.account_name');

        $builder->join('users','users.user_id=staff_payrolls_tbl.staff_id');
        $builder->join('staff_details_tbl','staff_details_tbl.user_id=staff_payrolls_tbl.staff_id');
        $builder->join('job_tittle_tbl','job_tittle_tbl.id=staff_details_tbl.job_id');
        $builder->join('departments_tbl','departments_tbl.id=staff_details_tbl.dep_id');
        $builder->join('payrolls_tbl','payrolls_tbl.payroll_id=staff_payrolls_tbl.payroll_ids');
        $builder->join('months','months.month_id=payrolls_tbl.payroll_month');
        $builder->join('ledger_transaction_tbl','ledger_transaction_tbl.name_id=staff_payrolls_tbl.staff_id');
        $builder->join('classification_tbl','classification_tbl.id=staff_details_tbl.classfication_id');
        $builder->join('bank_lists_tbl','bank_lists_tbl.bank_id=staff_details_tbl.bank_name','left');
        $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id=ledger_transaction_tbl.trans_type');
        $builder->join('payroll_payments_relations_tbl','payroll_payments_relations_tbl.payroll_payment_id=transaction_numbers_tbl.trans_number AND payroll_payments_relations_tbl.staff_id=staff_payrolls_tbl.staff_id');

        $builder->where('staff_details_tbl.user_id',$data);
        $builder->where('ledger_transaction_tbl.trans_type',5);
        $builder->where('transaction_numbers_tbl.trans_number',$transNo);
        $builder->where('staff_payrolls_tbl.payroll_ids',$payroll_id);

        $query = $builder->get();

        if ($query === false) {
            // helpful for debugging
            throw new \Exception("SQL Error: ".$this->db->error()['message']);
        }

        return $query->getRow();
    }
     function get_company_details($tbls){
     $query = $this->db->table($tbls);
     $results=$query->get()->getRow();
     $this->db->close();
     return $results;
       
 }
 public function get_pay_data($transno,$staff){
    $builder = $this->db->table('payroll_payments_relations_tbl');
    $builder->select('payroll_payments_relations_tbl.payroll_id');
     $builder->where('payroll_payments_relations_tbl.payroll_payment_id',$transno);
     $builder->where('payroll_payments_relations_tbl.staff_id',$staff);
       $results=$builder->get()->getRow();
     $this->db->close();
     return $results;

 }
 public function get_advance_data($staff,$trans_no){
    $builder = $this->db->table('salary_advances_schedule_tbl');
  $builder->select('job_tittle_tbl.job_tittle,departments_tbl.dep_name,users.first_name,users.user_id,users.last_name,salary_advances_schedule_tbl.payroll_year,months.month,salary_advances_schedule_tbl.advance_amount');
$builder->join('users','users.user_id=salary_advances_schedule_tbl.staff_id');
 $builder->join('staff_details_tbl','staff_details_tbl.user_id=salary_advances_schedule_tbl.staff_id');
        $builder->join('job_tittle_tbl','job_tittle_tbl.id=staff_details_tbl.job_id');
        $builder->join('departments_tbl','departments_tbl.id=staff_details_tbl.dep_id');
$builder->join('months','months.month_id=salary_advances_schedule_tbl.payroll_month');
$builder->where('salary_advances_schedule_tbl.transaction_id',$trans_no);
$builder->where('salary_advances_schedule_tbl.staff_id',$staff);
$names = $builder->get()->getResult();
return $names;
 }
}
?>