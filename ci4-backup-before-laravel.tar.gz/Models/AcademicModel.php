<?php
// By chanangwa E,
namespace App\Models;
use CodeIgniter\Model;
class AcademicModel extends Model
{
     public function __construct(){
       $dbname=session()->get('db_name');
       $db_id=session()->get('db_id');
       $this->db=\Config\Database::connect($dbname);
      
   }
// ==============Examination Field Start==================
                 //========Add EXam======
    public function save_exam_record($data)
    {
        $query = $this->db->table('examination_tbl')->insert($data);
        return $query;
    }
      //========Retriew EXam======
    public function GetAllExams(){
        $query=$this->db->table('examination_tbl');
        $query->select('examination_tbl.*,users.first_name,users.last_name,');
     $query->join('users', 'users.user_id = examination_tbl.created_by');
        $query->orderby('examination_tbl.exam_id','DESC');
        $Result=$query->get()->getResult();

        return $Result;
        
    }
              //========Delete EXam======
    public function DeleteExam($id){
        $query=$this->db->table('examination_tbl');
        $query->where('exam_id',$id);
        $Result=$query->delete();
        return $Result;
    }

     public function remove_examination($id){
        $builder=$this->db->table('examination_tbl');
         $builder->where('exam_id',$id);
        $builder->delete();    
   }
   //========Update EXam======
       public function update_examination($examID,$data){
        $builder=$this->db->table('examination_tbl');
         $builder->where('exam_id',$examID);
        $builder->update($data); 
        return $builder;   
   }
   
 // ==============Examination Field End==================
 // ==============Subect Field Start==================
 public function save_subject_record($data)
    {
       $query = $this->db->table('subject_tbl')->insert($data);
        return $query;
    }
// ===================Fetch Subjects================
        public function GetAllSubjects(){
        $query=$this->db->table('subject_tbl');
        $query->select('subject_tbl.*,users.first_name,users.last_name,');
     $query->join('users', 'users.user_id = subject_tbl.created_by');
        $query->orderby('subject_tbl.subject_id','DESC');
        $Result=$query->get()->getResult();
        return $Result;
        
    }
    //========update Subject======
         public function edit_Subject($subjectID,$data){
        $builder=$this->db->table('subject_tbl');
         $builder->where('subject_id',$subjectID);
        $builder->update($data); 
        return $builder; } 
    // ==================delete===================
             public function delete_subject($id){
        $builder=$this->db->table('subject_tbl');
         $builder->where('subject_id',$id);
        $builder->delete();    
   }
 // ==============Subect Field End==================

 // ==============character Field Start==================
 public function save_character_record($data)
    {
        $query = $this->db->table('student_character_tbl')->insert($data);
        return $query;
    }
// ===================Fetch character================
        public function GetAllcharacter(){
        $query=$this->db->table('student_character_tbl');
        $query->select('student_character_tbl.*,users.first_name,users.last_name,');
     $query->join('users', 'users.user_id = student_character_tbl.created_by');
        $query->orderby('student_character_tbl.character_id','DESC');
      $Result=$query->get()->getResult();
        return $Result;
        
    }
    //========update character======
         public function edit_character($characterID,$data){
        $builder=$this->db->table('student_character_tbl');
         $builder->where('character_id',$characterID);
        $builder->update($data); 
        return $builder; } 
    // ==================delete===================
             public function delete_character($id){
        $builder=$this->db->table('student_character_tbl');
         $builder->where('character_id',$id);
        $builder->delete();    
   }
 // ==============Character Field End==================
   // ==============Subect Field End==================

 // ==============comb Field Start==================
 public function save_comb_record($data)
    {
      $query = $this->db->table('combination_tbl')->insert($data);
       return $this->db->insertID();
    }
public function GetAllsub_edit(){
    $query = $this->db->table('subject_tbl');
    $query->select('*');
    $query->orderBy('subject_tbl.subject_name', 'DESC');
    return $query->get()->getResult();
}
public function CheckCombExist($classlevel,$combname){
    return $this->db->table('combination_tbl')
        ->select('comb_name')
        ->where('comb_name', $combname)
        ->where('classlevel', $classlevel)
        ->get()
        ->getRow();
}
    public function GetAllComb(){ 
      $query = $this->db->table('combination_subjects');
    $query->select('combination_subjects.subject_id,combination_tbl.comb_id, combination_tbl.*,class_level_tbl.level_name, 
                    GROUP_CONCAT(subject_tbl.subject_name SEPARATOR ", ") AS subjects,users.first_name, users.last_name');
    $query->join('subject_tbl', 'subject_tbl.subject_id = combination_subjects.subject_id');
    $query->join('combination_tbl', 'combination_tbl.comb_id = combination_subjects.comb_id'); 
    $query->join('users', 'users.user_id = combination_tbl.created_by');
    $query->join('class_level_tbl', 'combination_tbl.classlevel = class_level_tbl.id');
    $query->groupBy('combination_tbl.comb_id');
    $query->orderBy('combination_tbl.comb_id', 'DESC');
    return $query->get()->getResult();

}
   public function GetCombByClasslevel_new($classlevel){ 
      $query = $this->db->table('combination_subjects');
    $query->select('combination_subjects.subject_id,combination_tbl.comb_id, combination_tbl.*,class_level_tbl.level_name, 
                    GROUP_CONCAT(subject_tbl.subject_name SEPARATOR ", ") AS subjects,users.first_name, users.last_name');
    $query->join('subject_tbl', 'subject_tbl.subject_id = combination_subjects.subject_id');
    $query->join('combination_tbl', 'combination_tbl.comb_id = combination_subjects.comb_id'); 
    $query->join('users', 'users.user_id = combination_tbl.created_by');
    $query->join('class_level_tbl', 'combination_tbl.classlevel = class_level_tbl.id');
    $query->groupBy('combination_tbl.comb_id');
    $query->groupBy('combination_tbl.classlevel',$classlevel);
    $query->orderBy('combination_tbl.comb_id', 'DESC');
    return $query->get()->getResult();

}
    //========update comb======
         public function edit_comb($combID,$data){
        $builder=$this->db->table('combination_tbl');
         $builder->where('comb_id',$combID);
        $builder->update($data); 
        return $builder; } 
       public function insert_comb_sub($data){
        $query = $this->db->table('combination_subjects')->insert($data);
        return $query; 
    }
    public function GetComb_byID($comb_nm){
    $query = $this->db->table('combination_tbl');
    $query->select('combination_tbl.comb_id');
    $query->where('comb_name',$comb_nm);
    return $query->get()->getResult();

}
    // ==================delete===================
             public function delete_comb($id){
        $builder=$this->db->table('combination_tbl');
         $builder->where('comb_id',$id);
        $builder->delete();
    return $this->db->affectedRows() > 0;}
            public function delete_comb_sub($id){
        $builder=$this->db->table('combination_subjects');
         $builder->where('comb_id',$id);
        $builder->delete();  
    return $this->db->affectedRows() > 0;} 
           public function delete_comb_stream($id){
        $builder=$this->db->table('comb_stream');
         $builder->where('comb',$id);
        $builder->delete(); 
        return $this->db->affectedRows() > 0;   
   }
   // ==============comb Field Ends==================
   // ==============Grade Field Start==================
 public function save_grade_record($data)
    {
      $query = $this->db->table('grades_tbl')->insert($data);
        return $query;
    }
// ===================Fetch grade================
        public function GetAllgrade(){
        $query=$this->db->table('grades_tbl');
        $query->select('grades_tbl.*,users.first_name,users.last_name,class_level_tbl.level_name,class_level_tbl.id');
     $query->join('users', 'users.user_id = grades_tbl.created_by');
     $query->join('class_level_tbl', 'class_level_tbl.id = grades_tbl.classlevel');
        $query->orderby('grades_tbl.grade_name','ASCS');
      $Result=$query->get()->getResult();
        return $Result;
        
}
        public function GetClassLevelgrade($level){
        $query=$this->db->table('grades_tbl');
        $query->select('grades_tbl.*,users.first_name,users.last_name,class_level_tbl.level_name,class_level_tbl.id');
     $query->join('users', 'users.user_id = grades_tbl.created_by');
     $query->join('class_level_tbl', 'class_level_tbl.id = grades_tbl.classlevel');
        $query->orderby('grades_tbl.grade_name','ASCS');
        if($level>0){
         $query->where('grades_tbl.classlevel',$level);
          $Result=$query->get()->getResult();
                return $Result;
        }else{
  $Result=$query->get()->getResult();
        return $Result;
        }
    
        
}
        public function GetgradeUpdateForm($grade_id){
        $query=$this->db->table('grades_tbl');
        $query->select('grades_tbl.*,users.first_name,users.last_name,class_level_tbl.level_name,class_level_tbl.id');
     $query->join('users', 'users.user_id = grades_tbl.created_by');
     $query->join('class_level_tbl', 'class_level_tbl.id = grades_tbl.classlevel');
        $query->orderby('grades_tbl.grade_name','ASCS');
         $query->where('grades_tbl.grade_id',$grade_id);
      $Result=$query->get()->getResult();
        return $Result;
        
}
    public function GetCombUpdateForm($comb_id)
{
    return $this->db->table('combination_tbl')
        ->select('
            combination_tbl.comb_id, 
            combination_tbl.created_on, 
            combination_tbl.comb_name, 
            combination_tbl.comb_status, 
            combination_tbl.classlevel,
            class_level_tbl.level_name, 
            GROUP_CONCAT(subject_tbl.subject_name ORDER BY subject_tbl.subject_name SEPARATOR ", ") AS subjects,
            GROUP_CONCAT(subject_tbl.subject_id) AS subject_ids,
            users.first_name, 
            users.last_name
        ')
        ->join('combination_subjects', 'combination_subjects.comb_id = combination_tbl.comb_id', 'left')
        ->join('subject_tbl', 'subject_tbl.subject_id = combination_subjects.subject_id', 'left')
        ->join('users', 'users.user_id = combination_tbl.created_by', 'left')
        ->join('class_level_tbl', 'combination_tbl.classlevel = class_level_tbl.id', 'left')
        ->where('combination_tbl.comb_id', $comb_id)
        ->groupBy('combination_tbl.comb_id')
        ->get()
        ->getRow();
}
        public function GetCombAllocation($comb_id){
        $query=$this->db->table('comb_stream');
        $query->select('streams_tbl.stream_name,classes_tbl.class_name');
     $query->join('streams_tbl', 'streams_tbl.id = comb_stream.stream_id');
     $query->join('classes_tbl', 'classes_tbl.id = comb_stream.class_id');
        $query->orderby('streams_tbl.id','ASC');
         $query->where('comb_stream.comb',$comb_id);
      $Result=$query->get()->getResult();
        return $Result;
        
}
        
public function getSingleCombination($comb_id)
{
    return $this->db->table('combination_tbl')
        ->where('comb_id', $comb_id)
        ->get()
        ->getRow();
}
public function getSubjectsInCombination($comb_id)
{
    $results = $this->db->table('combination_subjects')
        ->select('subject_id')
        ->where('comb_id', $comb_id)
        ->get()
        ->getResult();

    return array_map(fn($row) => $row->subject_id, $results);
}

public function GetAllClassLevels(){
        $query=$this->db->table('class_level_tbl');
        $query->select('class_level_tbl.*');
        $query->orderby('class_level_tbl.id','ASCS');
        $query->where('class_level_tbl.status',1);
      $Result=$query->get()->getResult();
        return $Result;
}
    //========update grade======
         public function edit_grade($gradeID,$data){
        $builder=$this->db->table('grades_tbl');
         $builder->where('grade_id',$gradeID);
        $builder->update($data); 
        return $builder; } 
    // ==================delete===================
             public function delete_grade($id){
        $builder=$this->db->table('grades_tbl');
         $builder->where('grade_id',$id);
        $builder->delete();    
   }
    function get_comb_name($tbl,$condition){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
    //  $builder->orderBy('id','DESC');
      $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }
   public function get_active_subject($tbl)
     {
        $builder = $this->db->table($tbl);
        $builder->select('*');
        $builder->where('status = 1');
        $query = $builder->get()->getResult();
        return $query;
     }
      public function get_active_teacher($tbl)
     {
        $db_id=session()->get('db_id');
        $builder = $this->db->table($tbl);
        $builder->select('*');
        $builder->where('status = 1 ');
       $builder->where('user_type <>',6);
       $builder->where('database_id',$db_id);
        $builder->orderby('users.first_name','ASC');
        $query = $builder->get()->getResult();
        return $query;
     }
                      //========Add EXam======
    public function save_teacher_allocation_records($data)
    {
        $query = $this->db->table('teacher_allocation_tbl')->insert($data);
        return $query;
    }
        public function remove_single_teacher_allocation($teacher_id,$subject_id,$stream){
        $builder=$this->db->table('teacher_allocation_tbl');
        $builder->where('teacher_id',$teacher_id);
         $builder->where('teacher_subject',$subject_id);
         $builder->where('stream',$stream);
           $deleted = $builder->delete();
    if (!$deleted) {
        log_message('error', 'Delete failed: ' . $this->db->getLastQuery());
    }

    return $deleted;
       
   }
    public function GetAll_TeacherAllocation(){
    $db_id = session()->get('db_id');
    $query = $this->db->table('teacher_allocation_tbl');
    $query->select('users.user_id,teacher_allocation_tbl.teacher_id,users.first_name,teacher_allocation_tbl.allocated_by,teacher_allocation_tbl.allocation_date, users.phone_no,teacher_allocation_tbl.allocation_id,users.last_name, users_type_tbl.type_name, COUNT(DISTINCT teacher_allocation_tbl.teacher_subject) AS subject_count');
    
    $query->join('users', 'users.user_id = teacher_allocation_tbl.teacher_id');
    $query->join('users_type_tbl', 'users_type_tbl.id = users.user_type');
    $query->where('users.database_id', $db_id);
    
    $query->groupBy('teacher_allocation_tbl.teacher_id');
    $query->orderBy('users.first_name', 'ASC');
    
    $result = $query->get()->getResult();
    return $result;
}

    public function getAllusers(){
       $query=$this->db->table('users');  
          $query->select('*');
           $Result=$query->get()->getResult();
        return $Result;
    }
    public function remove_teacher_allocation($id){
        $builder=$this->db->table('teacher_allocation_tbl');
         $builder->where('allocation_id',$id);
        $builder->delete();    
   }
   public function Get_Allocation_data($teacher){
    $query=$this->db->table('teacher_allocation_tbl');
    $query->select('subject_tbl.subject_name,
                      teacher_allocation_tbl.allocated_by, 
                      teacher_allocation_tbl.allocation_date,
                      teacher_allocation_tbl.update_date,
                    streams_tbl.stream_name,
                    streams_tbl.stream_name,
                    teacher_allocation_tbl.*, 
                    users.user_id,
                    users.first_name,
                    users.last_name,
                    classes_tbl.class_name,
                    class_level_tbl.level_name'
                   );
    $query->join('users', 'users.user_id = teacher_allocation_tbl.allocated_by');
    $query->join('streams_tbl', 'streams_tbl.id = teacher_allocation_tbl.stream');
    $query->join('subject_tbl', 'subject_tbl.subject_id = teacher_allocation_tbl.teacher_subject');
    $query->join('class_level_tbl', 'class_level_tbl.id = teacher_allocation_tbl.classlevel');
    $query->join('classes_tbl', 'classes_tbl.id = teacher_allocation_tbl.class');
      $query->where('teacher_allocation_tbl.teacher_id',$teacher);
      $query->groupBy('teacher_allocation_tbl.stream');
      $query->groupBy('teacher_allocation_tbl.teacher_subject');
      $query->orderby('streams_tbl.id');
      $Result=$query->get()->getResult();
        return $Result;   

   }
 public function Allocation_updates($id,$data){
        $query=$this->db->table('teacher_allocation_tbl');
        $query->where('allocation_id',$id);
        $Result=$query->update($data);
        return $Result;

}
   public function My_Allocation_data($user){
    $query=$this->db->table('teacher_allocation_tbl');
    $query->select('subject_tbl.subject_name, 
                    teacher_allocation_tbl.*, 
                    users.*,
                    classes_tbl.class_name,
                    class_level_tbl.level_name'
                   );
    $query->join('users', 'users.user_id = teacher_allocation_tbl.teacher_id');
    $query->join('subject_tbl', 'subject_tbl.subject_id = teacher_allocation_tbl.teacher_subject');
    $query->join('class_level_tbl', 'class_level_tbl.id = teacher_allocation_tbl.classlevel');
    $query->join('classes_tbl', 'classes_tbl.id = teacher_allocation_tbl.class');
      $query->where('teacher_allocation_tbl.teacher_id',$user);
      $Result=$query->get()->getResult();
        return $Result;   

   }

 function get_subject_allocatiion($class,$classlevel,$stream){
          $query = $this->db->table('comb_stream');
    $query->select('combination_tbl.comb_name,comb_stream.st_id,streams_tbl.stream_name,class_level_tbl.level_name, streams_tbl.stream_capacity,classes_tbl.class_name, combination_subjects.*,comb_stream.created_on, GROUP_CONCAT(subject_tbl.subject_name SEPARATOR ", ") AS subjects,users.first_name,users.last_name' ); 
    $query->join('combination_subjects', 'combination_subjects.comb_id =comb_stream.comb');
    $query->join('combination_tbl', 'combination_tbl.comb_id =combination_subjects.comb_id');
       $query->join('subject_tbl', 'subject_tbl.subject_id =combination_subjects.subject_id');
     $query->join('streams_tbl', 'streams_tbl.id =comb_stream.stream_id');
    $query->join('classes_tbl', 'classes_tbl.id =comb_stream.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =classes_tbl.class_level');
        $query->join('users', 'users.user_id =comb_stream.created_by');
        $query->where('comb_stream.class_id', $class);
        $query->where('class_level_tbl.id', $classlevel);
          $query->where('comb_stream.stream_id', $stream);
     $query->orderby('comb_stream.st_id');
     $result= $query->get()->getResult();
     $this->db->close();
    return $result; 

   }
   public function get_subject_allocatiion2($class, $classlevel, $stream){
    $query = $this->db->table('comb_stream cs');
    $query->select('cs.st_id,combination_tbl.comb_name');
    $query->join('combination_tbl', 'combination_tbl.comb_id = cs.comb');
    $query->join('classes_tbl c', 'c.id = cs.class_id');
    $query->where('cs.class_id', $class);
    $query->where('c.class_level', $classlevel);
    $query->where('cs.stream_id', $stream);

    return $query->get()->getResult();
}

function get_student_details($class,$classlevel,$stream,$year,$status){
    $query = $this->db->table('admission_tbl');
    $query->select('
        students.birth_date,
        students.id,
        admission_tbl.date_joined,
        admission_tbl.class_id,
        admission_tbl.level_id,
        admission_tbl.academic_year,
        admission_tbl.admission_type,
        admission_tbl.adimit_for,
        students.gender,
        students.student_id,
        classes_tbl.class_name,
        streams_tbl.stream_name,
        class_level_tbl.level_name,
       students.full_name,
       students.status,
       students.first_name,'
    ); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
    $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
     $query->join('students', 'students.id = admission_tbl.student_id');
     if($class >0 && $classlevel>0 && $stream==0){
    
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
     if($status>0){
      $query->where('students.status', $status);
     }
    }
    elseif($class ==0 && $classlevel>0 && $stream==0){
     
     $query->where('admission_tbl.level_id', $classlevel);
     if($status>0){
      $query->where('students.status', $status);
     }
    }
elseif($class >0 && $classlevel==0 && $stream==0){
    $query->where('admission_tbl.class_id', $class);
    if($status>0){
      $query->where('students.status', $status);
     }
    }
elseif($class >0 && $classlevel>0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
     if($status>0){
      $query->where('students.status', $status);
     }
    }
    elseif($class >0 && $classlevel==0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
     $query->where('admission_tbl.class_id', $class);
     if($status>0){
      $query->where('students.status', $status);
     }
    }
    elseif($class==0 && $classlevel==0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
   if($status>0){
      $query->where('students.status', $status);
     }
     
    }
    if($status>0){
      $query->where('students.status', $status);
     }
    $query->where('admission_tbl.academic_year', $year);
   $query->orderBy('students.full_name','ASC');
      
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
   public function save_allocation_record($data){
       $query = $this->db->table('comb_stream')->insert($data);
        return $query;
   }
   public function Get_Allocation_info($id){
   return $this->db->table('combination_subjects')
        ->select('combination_subjects.subject_id, combination_tbl.comb_id, combination_tbl.comb_name, subject_tbl.subject_name')
        ->join('subject_tbl', 'subject_tbl.subject_id = combination_subjects.subject_id')
        ->join('combination_tbl', 'combination_tbl.comb_id = combination_subjects.comb_id')
        ->where('combination_subjects.comb_id', $id)
        ->get()
        ->getResult();
   }
public function Get_stream_Allocated_subjects($streamId, $teacherId)
{
    $subQuery = $this->db->table('teacher_allocation_tbl')
        ->select('teacher_subject')
        ->where('stream', $streamId)
        ->where('teacher_id', $teacherId)
        ->getCompiledSelect();
    return $this->db->table('comb_stream')
        ->join('streams_tbl', 'streams_tbl.id = comb_stream.stream_id')
        ->join('combination_subjects', 'comb_stream.comb = combination_subjects.comb_id')
        ->join('subject_tbl', 'subject_tbl.subject_id = combination_subjects.subject_id')
        ->select('combination_subjects.subject_id, subject_tbl.subject_name, streams_tbl.id, streams_tbl.class_id')
        ->where('comb_stream.stream_id', $streamId)
        ->where("combination_subjects.subject_id NOT IN ($subQuery)", null, false)
        ->get()
        ->getResult();
}

public function Get_teacher_Allocated_subjects($stream,$teacher)
{
    return $this->db->table('teacher_allocation_tbl')
        ->join('streams_tbl', 'streams_tbl.id = teacher_allocation_tbl.stream')
        ->join('users', 'teacher_allocation_tbl.teacher_id = users.user_id')
        ->join('classes_tbl', 'teacher_allocation_tbl.class = classes_tbl.id')
        ->join('subject_tbl', 'subject_tbl.subject_id = teacher_allocation_tbl.teacher_subject')
        ->select('subject_tbl.subject_id, subject_tbl.subject_name,classes_tbl.class_name,streams_tbl.stream_name, streams_tbl.id,users.user_id, streams_tbl.class_id')
        // ->where('teacher_allocation_tbl.stream', $stream)
        ->orderby('streams_tbl.id')
        ->where('users.user_id', $teacher)
        ->get()
        ->getResult();
}

public function GetStreamEdit($id){
           $query = $this->db->table('comb_stream');
    $query->select('combination_tbl.comb_name,comb_stream.st_id,comb_stream.comb,streams_tbl.stream_name,streams_tbl.id,comb_stream.class_id, streams_tbl.stream_capacity,classes_tbl.class_name, combination_subjects.*,comb_stream.created_on, GROUP_CONCAT(subject_tbl.subject_name SEPARATOR ", ") AS subjects,users.first_name,users.last_name,class_level_tbl.level_name' ); 
    $query->join('combination_subjects', 'combination_subjects.comb_id =comb_stream.comb');
    $query->join('combination_tbl', 'combination_tbl.comb_id =combination_subjects.comb_id');
       $query->join('subject_tbl', 'subject_tbl.subject_id =combination_subjects.subject_id');
     $query->join('streams_tbl', 'streams_tbl.id =comb_stream.stream_id');
    $query->join('classes_tbl', 'classes_tbl.id =comb_stream.class_id');
    $query->join('class_level_tbl', 'classes_tbl.class_level =class_level_tbl.id');
        $query->join('users', 'users.user_id =comb_stream.created_by');
        $query->where('comb_stream.st_id', $id);
    // $query->orderby('comb_stream.st_id');
     $result= $query->get()->getResult();
     $this->db->close();
    return $result; 

   }
      public function GetActiveCombination(){
    $builder = $this->db->table('combination_tbl');
       $builder->select('*');
      $builder->where('comb_status = 1');
       return $query = $builder->get()->getResult();
       }
       public function update_allocation_record($streamID,$data){
        $query = $this->db->table('comb_stream');
         $query->where('st_id',$streamID);
        $query->update($data); 
        return $query;
       }
        public function remove_stream_allocations($id){
        $builder=$this->db->table('comb_stream');
         $builder->where('st_id',$id);
      return $builder->delete();    
   }
     public function GetCombByClassLevel($level){ 
      $query = $this->db->table('combination_subjects');
    $query->select('combination_tbl.comb_id, combination_tbl.*,class_level_tbl.level_name, 
                    GROUP_CONCAT(subject_tbl.subject_name SEPARATOR ", ") AS subjects,users.first_name, users.last_name');
    $query->join('subject_tbl', 'subject_tbl.subject_id = combination_subjects.subject_id');
    $query->join('combination_tbl', 'combination_tbl.comb_id = combination_subjects.comb_id'); 
    $query->join('class_level_tbl', 'class_level_tbl.id = combination_tbl.classlevel'); 
    $query->join('users', 'users.user_id = combination_tbl.created_by');
    if($level>0){
     $query->where('combination_tbl.classlevel',$level);  
         $query->groupBy('combination_tbl.comb_id');
    $query->orderBy('combination_tbl.comb_id', 'DESC');
    return $query->get()->getResult(); 
    }
    else{
    $query->groupBy('combination_tbl.comb_id');
    $query->orderBy('combination_tbl.comb_id', 'DESC');
    return $query->get()->getResult();
    }
    

}
    public function get_comb_stream_details($class)
    {
        $builder = $this->db->table("comb_stream");
    $builder->join('streams_tbl', 'streams_tbl.id = comb_stream.stream_id');
    $builder->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb'); 
        $builder->select('streams_tbl.stream_name,combination_tbl.comb_name,streams_tbl.id ');
        $builder->where('comb_stream.class_id',$class);
        $results=$builder->get()->getResult();
        $this->db->close();
        return $results;
    }
    public function GetCharacterDetails($characterID){
              $builder = $this->db->table("student_character_tbl");
    $builder->join('users', 'users.user_id = student_character_tbl.created_by');
        $builder->select('student_character_tbl.*,users.first_name,users.last_name');
        $builder->where('student_character_tbl.character_id',$characterID);
        $results=$builder->get()->getResult();
        $this->db->close();
        return $results;

    }
        public function getTeacher($teacher){
       $query=$this->db->table('users');  
          $query->select('users.user_id,
                    users.first_name,
                    users_type_tbl.type_name,
                    users.gender,
                    users.phone_no,
                    users.last_name,');
          $query->where('users.user_id',$teacher);
           $query->join('users_type_tbl', 'users.user_type = users_type_tbl.id');
           $Result=$query->get()->getRow();
        return $Result;
    }


}
?>
