<?php

namespace App\Models;

use CodeIgniter\Model;

class ClassesModel extends Model
{
    public $db;
    public function __construct(){
        $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    }

function get_item_name($tbl,$condition){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
    //  $builder->orderBy('id','DESC');
      $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }
    public function items_chargedList()
    {
        $builder = $this->db->table('items_tbl');
        $builder->select('id,item_name,item_price');
        $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
        $query = $builder->get()->getResult();
            
         return $query;
    }

  public function get_accounts_items()
    {
        $builder = $this->db->table('accounts_tbl');
        $builder->select('');
         return $builder->get()->getResult();
    }
    public function get_applications_items()
    {
        $builder = $this->db->table('items_tbl');
        $builder->select('item_name,id,item_price');
        $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
        $builder->where('item_group = 1');
        return $builder->get()->getResult();
    }
    public function items_chargedList1($id)
    {
        $builder = $this->db->table('items_tbl');
        $builder->select('id,item_name,item_price,item_size,item_group,item_attribute');
        $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
        $builder->where('id',$id);
        $query = $builder->get()->getResult();
            
         return $query;
    }
public function saveLeve($data)
    {
        $builder = $this->db->table('class_level_tbl')->insert($data);
        if($builder)
        {
            return $this->db->insertID();
        }
        else{
            return 0;
         }
    }
    public function saveLevel($data)
    {
        $builder = $this->db->table('class_level_tbl')->insert($data);
        if($builder)
        {
            return $this->db->insertID();
        }
        else{
            return 0;
         }
    }

    public function Save_newLevel($insert_level)
    {
        $builder = $this->db->table('class_level_items_tbl')->insert( $insert_level);

    }

    public function load_allSaved_Level()
    {
        $builder = $this->db->table('class_level_tbl');
        $builder->select('class_level_tbl.*,first_name,last_name,government_levels.level_name AS g_level');
        $builder->join('users', 'users.user_id = class_level_tbl.updated_by');
        $builder->join('government_levels', 'government_levels.level_id = class_level_tbl.government_level_id');
        $builder->orderby('class_level_tbl.id', 'DESC');
        $query = $builder->get()->getResult();

        return $query;

    }



    public function get_ChargedItems_list($id)
    {
        $builder = $this->db->table('price_tbl');
        $builder->select('item_price,item_id');
        $builder->where('item_id',$id);
        $query = $builder->get()->getResult();

        return $query;
    }

    public function add_items($data)
    {
        $builder = $this->db->table('class_level_items_tbl')->insert($data);

        return $builder;
    }

    public function updating_level($id,$data)
    {
        $builder = $this->db->table('class_level_tbl');
        $builder->where('id',$id);
        $builder->update($data);
    }


    public function delete_class_level($id)
    {
        $builder = $this->db->table('class_level_items_tbl');
        $builder->select('id');
        $builder->where('level_id',$id);
        $builder->delete();

        $builder = $this->db->table('class_level_tbl');
        $builder->where('id',$id);
        $builder->delete();
    }



    //------------------ Star of Classes -----------------//


     public function saveSemisterData($data)
     {
        $builder = $this->db->table('school_terms_tbl')->insert($data);

        return $builder;
     }

     public function Load_SchoolTerms($year){
        $builder = $this->db->table('school_terms_tbl');
        $builder->select('*,school_terms_tbl.id');
        $builder->join('users', 'users.user_id = school_terms_tbl.updated_by');
         $builder->where('academic_year ',$year);
        $builder->orderby('school_terms_tbl.id', 'DESC');
        $query = $builder->get()->getResult();


        return $query;
     }

     public function check_ifExist($tbl,$id)
     {
        $builder = $this->db->table($tbl);
        $builder->select('');
        $builder->where($id);
        return $builder->get()->getResult();
     }

     public function manage_School_terms($id)
     {
        $builder = $this->db->table('school_terms_tbl');
        $builder->select('*');
        $builder->where('id', $id);
        $query = $builder->get()->getResult();


        return $query;
     }


     public function delete_TermsDtls($id)
     {
        $builder = $this->db->table('school_terms_tbl');
        $builder->where('id',$id);
        $builder->delete();
     }

     public function updating_schoolTerms($id,$data)
     {
        $builder = $this->db->table('school_terms_tbl');
        $builder->where('id', $id);
        $builder->update($data);
     }


     public function get_all_classLevel()
     {
        $builder = $this->db->table('class_level_tbl');
        $builder->select('*');
        $builder->where('status = 1');
        $query = $builder->get()->getResult();

        return $query;
     }
	  public function getting_item_details($id)
     {
        $builder = $this->db->table('class_level_items_tbl');
        $builder->select('class_level_items_tbl.id,class_level_items_tbl.level_id,class_level_items_tbl.item_id,
		class_level_items_tbl.quantity,items_tbl.item_name,items_tbl.item_attribute,items_tbl.item_size,
		price_tbl.item_price,account_receivable');
        $builder->join('items_tbl', 'items_tbl.id = class_level_items_tbl.item_id');
        $builder->join('price_tbl', 'price_tbl.item_id = class_level_items_tbl.item_id');
        $builder->where('items_tbl.item_group',0);
		$builder->where('class_level_items_tbl.level_id',$id);
        $query = $builder->get()->getResult();
            
         return $query;
     }
     
      public function getting_item_detailsap($id)
     {
        $builder = $this->db->table('class_level_items_tbl');
        $builder->select('class_level_items_tbl.id,class_level_items_tbl.level_id,class_level_items_tbl.item_id,
        class_level_items_tbl.quantity,items_tbl.item_name,items_tbl.item_attribute,items_tbl.item_size,
        price_tbl.item_price,account_receivable');
        $builder->join('items_tbl', 'items_tbl.id = class_level_items_tbl.item_id');
        $builder->join('price_tbl', 'price_tbl.item_id = class_level_items_tbl.item_id');
        $builder->where('items_tbl.item_group',1);
        $builder->where('class_level_items_tbl.level_id',$id);
        $query = $builder->get()->getResult();
            
         return $query;
     }
     public function load_allSaved_Classes()
     {
        $builder = $this->db->table('classes_tbl');
        $builder->select('classes_tbl.id,classes_tbl.class_name,classes_tbl.class_level,class_level_tbl.level_name,classes_tbl.updated_date,classes_tbl.status,first_name,last_name');
        $builder->join('class_level_tbl', 'class_level_tbl.id = classes_tbl.class_level');
        $builder->join('users','users.user_id=classes_tbl.updated_by');
        $builder->orderby('classes_tbl.id', 'DESC');
        
        return $builder->get()->getResult();
     }

     public function get_number_ofStreams($id)
     {
        $builder = $this->db->table('streams_tbl');
        $builder->where('class_id',$id);
        $builder->selectCount('stream_name');

        return $builder->get()->getResult();

     }
       public function get_number_ofClasses($id)
     {
        $builder = $this->db->table('classes_tbl');
        $builder->where('class_level',$id);
        $builder->selectCount('class_name');

        return $builder->get()->getResult();

     }
     public function selectItemId($id)
    {
        $builder = $this->db->table('class_level_items_tbl');
        $builder->select('item_id');
        $builder->where('level_id',$id);
        $query = $builder->get()->getResult();
            
         return $query;
    }
	public function delete_levelId($level)
		{
            $builder = $this->db->table('class_level_items_tbl');
			$builder->select('level_id');
			$builder->where('level_id',$level);
			$builder->delete();
		}
		 public function edit_charged_items($level,$charged_item)
    {
        	$builder = $this->db->table('class_level_items_tbl')->insert($charged_item);
			
    }
     public function saveNew_Class($data)
     {
        $builder = $this->db->table('classes_tbl')->insert($data);

        if($builder){
            return $this->db->insertID();
        }else{
            return false;
        }
     }

     public function saveStreamData($streamdata)
     {
        $builder = $this->db->table('streams_tbl')->insert($streamdata);

        return $builder;
     }
	  public function saveInstallmentData($id)
     {
       $builder = $this->db->table('installments_tbl');
      $builder->set('tbl_id', $id)
                  ->where('tbl_id', 0)
                  ->update();
        return $builder;
     }

     public function Save_Classcharged_items($itemData)
     {
        $builder = $this->db->table('class_charged_items_tbl')->insert($itemData);
        
        return $builder;

     }

     public function deleting_ClassDetails($id)
     {
        $builder = $this->db->table('class_charged_items_tbl');
        $builder->select('id');
        $builder->where('class_id',$id);
        $builder->delete();

        $builder = $this->db->table('streams_tbl');
        $builder->select('id');
        $builder->where('class_id',$id);
        $builder->delete();

        $builder = $this->db->table('classes_tbl');
        $builder->where('id',$id);
        $builder->delete();
     }

     public function getting_allClass_details($id)
     {
        $builder = $this->db->table('classes_tbl');
        $builder->select('*');
        // $builder->join('streams_tbl', 'streams_tbl.class_id = classes_tbl.id');
        $builder->where('classes_tbl.id',$id);

        return $builder->get()->getResult();
     }

     public function add_Steam($data)
     {
        $builder = $this->db->table('streams_tbl')->insert($data);

        return $builder;
     }

     public function add_Stationsession($data)
     {
        $builder = $this->db->table('station_session_tbl')->insert($data);

        return $builder;
     }
	 public function add_installment($data)
     {
        $builder = $this->db->table('installments_tbl')->insert($data);

        return $builder;
     }
 public function add_temporary($data)
     {
        $builder = $this->db->table('installments_tbl')->insert($data);

        return $builder;
     }
     public function updating_class_data($id,$data)
     {
        $builder = $this->db->table('classes_tbl');
        $builder->where('id',$id);
        $builder->update($data);
     }
      public function updating_session_data($id,$data)
     {
        $builder = $this->db->table('station_tbl');
        $builder->where('id',$id);
        $builder->update($data);
     }

     public function insert_new_charged_item($data)
     {

        $builder = $this->db->table('class_charged_items_tbl')->insert($data);
        return $builder;
     }
          public function insert_new_charged_itemdata($data)
     {

        $builder = $this->db->table('station_charged_items_tbl')->insert($data);
        return $builder;
     }
      public function insert_new_level_item($data)
     {

        $builder = $this->db->table('class_level_items_tbl')->insert($data);
        return $builder;
     }
	 public function deletelevelItem($id)
		{

			$builder = $this->db->table('class_level_items_tbl');
			$builder->select('id');
			$builder->where('id',$id);
			$builder->delete();

		}
     
     public function get_all_terms()
     {
        $builder = $this->db->table('school_terms_tbl');
        $builder->select('*');
        //$builder->where('status = 1');
        $query = $builder->get()->getResult();

        return $query;
     }

 public function check_temp($name)
     {
        $builder = $this->db->table('installments_tbl');
        $builder->select('*');
        $builder->where('istallment_name',$name);
        $builder->where('tbl_id=0');
        $builder->where('installment_type=1');
        $query = $builder->get()->getResult();

        return count($query);
     }
     public function check_temp3($name)
     {
        $builder = $this->db->table('installments_tbl');
        $builder->select('*');
        $builder->where('istallment_name',$name);
        $builder->where('tbl_id=0');
        $builder->where('installment_type=3');
        $query = $builder->get()->getResult();

        return count($query);
     }
     public function check_inst($id,$name)
     {
        $builder = $this->db->table('installments_tbl');
        $builder->select('*');
        $builder->where('istallment_name',$name);
        $builder->where('tbl_id',$id);
        $builder->where('installment_type=1');
        $query = $builder->get()->getResult();

        return count($query);
     }
     public function returnAlldataOfClass($id){
            $query=$this->db->table('classes_tbl');
            
            $query->select('classes_tbl.id,classes_tbl.class_name,classes_tbl.class_level,classes_tbl.status,class_level_tbl.level_name');
            $query->join('class_level_tbl', 'class_level_tbl.id = classes_tbl.class_level');
            $query->where('classes_tbl.id',$id);
            $result=$query->get()->getResult();
            return $result;
        }
        public function ClassItems($id){
            $query=$this->db->table('class_charged_items_tbl');
            $query->select('class_charged_items_tbl.id,class_id,item_id,item_group,quantity,item_name,item_size,item_attribute,account_receivable');
            $query->where('class_id',$id);
            $query->join('items_tbl', 'items_tbl.id=class_charged_items_tbl.item_id');
            $result=$query->get()->getResult();
            return $result;
        }
        function get_termsPayments($id){
         $builder = $this->db->table('installments_tbl');
        $builder->select('installments_tbl.amount,school_terms_tbl.term_name,school_terms_tbl.start_date,school_terms_tbl.end_date
        ');
        $builder->join('school_terms_tbl', 'school_terms_tbl.id = installments_tbl.istallment_name');
        $builder->where('installments_tbl.tbl_id',$id);
        $builder->where('installments_tbl.installment_type',1);
        $query = $builder->get()->getResult();
            
         return $query;   
    }
     public function returnAlldataOfLevel($id){
            $query=$this->db->table('class_level_tbl');
            
            $query->select('class_level_tbl.id,class_level_tbl.status,class_level_tbl.level_name');
            // $query->join('class_level_tbl', 'class_level_tbl.id = classes_tbl.class_level');
            $query->where('class_level_tbl.id',$id);
            $result=$query->get()->getResult();
            return $result;
        }
        public function LevelItems($id){
            $query=$this->db->table('class_level_items_tbl');
            $query->select('class_level_items_tbl.id,level_id,class_level_items_tbl.item_id,item_group,quantity,item_name,item_size,item_attribute,account_receivable,price_tbl.item_price');
            $query->where('level_id',$id);
            $query->join('items_tbl', 'items_tbl.id=class_level_items_tbl.item_id');
            $query->join('price_tbl', 'price_tbl.item_id=items_tbl.id');
            $result=$query->get()->getResult();
            return $result;
        }
        function get_termsLevel($id){
         $builder = $this->db->table('installments_tbl');
        $builder->select('installments_tbl.amount,school_terms_tbl.term_name,school_terms_tbl.start_date,school_terms_tbl.end_date
        ');
        $builder->join('school_terms_tbl', 'school_terms_tbl.id = installments_tbl.istallment_name');
        $builder->where('installments_tbl.tbl_id',$id);
        $builder->where('installments_tbl.installment_type',3);
        $query = $builder->get()->getResult();
            
         return $query;   
    }

    function load_boarding_fee(){
                $builder = $this->db->table('items_tbl');
        $builder->select('*');
        $builder->where('item_group',3);
       $query = $builder->get()->getResult();
            
         return $query; 
    }
    
      function get_accounts_id($id){
                $builder = $this->db->table('class_charged_items_tbl');
        $builder->select('*');
        $builder->where('class_id',$id);
       $query = $builder->get()->getResult();
            
         return $query; 
    }
    function get_account_id($id){
                $builder = $this->db->table('station_charged_items_tbl');
        $builder->select('*');
        $builder->where('station_id',$id);
       $query = $builder->get()->getResult();
            
         return $query; 
    }
      function get_levelAccounts_id($id){
                $builder = $this->db->table('class_level_items_tbl');
        $builder->select('*');
        $builder->where('level_id',$id);
       $query = $builder->get()->getResult();
            
         return $query; 
    }
    function update_account_receivable($cid,$acid){
  $builder = $this->db->table('class_charged_items_tbl');
      $builder->set('account_receivable', $acid)
                  ->where('class_id', $cid)
                  ->update();
        return $builder;
    }
      function update_account_receivablestation($id,$acid){
  $builder = $this->db->table('station_charged_items_tbl');
      $builder->set('account_receivable', $acid)
                  ->where('station_id', $id)
                  ->update();
        return $builder;
    }
    
     function update_account_receivableLevel($lid,$acid){
  $builder = $this->db->table('class_level_items_tbl');
      $builder->set('account_receivable', $acid)
                  ->where('level_id', $lid)
                  ->update();
        return $builder;
    }
    public function government_level(){
         $builder = $this->db->table('government_levels');
    $builder->select('*');
        $builder->orderBy('level_id','ASC');
       $query = $builder->get()->getResult();   
         return $query; 
    }
        public function manage_levelData($id)
    {
        // $builder = $this->db->table('class_level_tbl');
        // $builder->select('');
         $builder = $this->db->table('class_level_tbl');
        $builder->select('class_level_tbl.*,first_name,last_name,government_levels.level_id,government_levels.level_name AS g_level');
        $builder->join('users', 'users.user_id = class_level_tbl.updated_by');
        $builder->join('government_levels', 'government_levels.level_id = class_level_tbl.government_level_id');
         $builder->where('class_level_tbl.id', $id);
        $builder->orderby('class_level_tbl.id', 'DESC');
        $query = $builder->get()->getResult();

        return $query;
    }
    
}
