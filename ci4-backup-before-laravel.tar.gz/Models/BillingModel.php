<?php

namespace App\Models;

use CodeIgniter\Model;

class BillingModel extends Model
{  
 public function __construct(){
        $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    } 
 function get_table_details($tbls){
     $query = $this->db->table($tbls);
     $results=$query->get()->getResult();
     $this->db->close();
     return $results;
       
 }
 function get_item_name($tbl,$condition){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
    //  $builder->orderBy('id','DESC');
      $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }
 function get_item_name_desc($tbl,$condition){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
      $builder->orderBy('id','DESC');
      $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }
  function get_item_name2($tbl,$condition,$s,$e){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
    $builder->where('DATE(trans_date) >=', $s);
     $builder->where('DATE(trans_date) <=', $e);
    //  $builder->orderBy('id','DESC');
      $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }
 
 function get_updated_date($tbl,$condition,$s,$e){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
    $builder->where('DATE(updated_date) >=', $s);
     $builder->where('DATE(updated_date) <=', $e);
    //  $builder->orderBy('id','DESC');
      $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }
 function get_item_join_table($id){
      $builder = $this->db->table('invoice_type_transaction');
        $builder->select('invoice_types_tbl.type_name');
        $builder->join('invoice_types_tbl', 'invoice_type_transaction.invoice_type_id = invoice_types_tbl.id');
        $builder->where('trans_no',$id);
        $query = $builder->get()->getResult();
        $this->db->close();
        return $query;
 }
 function search_by_name($search){
   // return $this->db->query('SELECT * FROM students_application_tbl 
    //WHERE students_application_tbl.id LIKE \'%'.$search.'%\'
   // OR `full_name`LIKE \'%'.$search.'%\' OR `surname` LIKE \'%'.$search.'%\'');
 }

 function get_total_amount($id,$no){
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->selectSum('amount');
    $builder->where('name_id',$id);
    $builder->where('trans_no',$no );
    $builder->where('transation_nature = 1' );
    $query = $builder->get()->getResult();
    $this->db->close();
    return $query;
 }

  function get_total_amount_payed($trans_no,$lg){
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->select('amount,balance');
    $builder->where('trans_no',$trans_no);
    $builder->where('ledger_type',$lg );
      $builder->where('trans_type',1 );
    $query = $builder->get()->getResult();
    $this->db->close();
    return $query;
 }
 function get_total_amount_payed2($trans_no,$lg){
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->select('amount,balance,trans_item,ledger_id,ledger_type');
    $builder->where('trans_no',$trans_no);
    $builder->where('transation_nature',2 );
    $builder->where('trans_type',2 );
    //$builder->where('ledger_id!=21');
    $query = $builder->get()->getResult();
    $this->db->close();
    return $query;
 }
 function get_total_amount_credit($trans_no,$lg){
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->select('amount,balance');
    $builder->where('trans_no',$trans_no);
    $builder->where('transation_nature',2 );
    $builder->where('trans_type',2 );
    $builder->where('ledger_type',$lg);
    $query = $builder->get()->getResult();
    $this->db->close();
    return $query;
 }
  function get__amount_payed($trans_no,$lg,$type){
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->select('amount,balance');
    $builder->where('trans_no',$trans_no);
    $builder->where('ledger_type',$lg );
    $builder->where('trans_type',$type );
    $query = $builder->get()->getResult();
    $this->db->close();
    return $query;
 }
 function get_pending_invoices($studentid,$name_type){
   $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
     $result = $db->query('SELECT * FROM  ledger_transaction_tbl  
                               WHERE name_id = '.$studentid.' AND ledger_type = 7 and name_type_id ='.$name_type.' AND transation_nature = 2 and trans_type = 1');
      return $result->getResult(); 
 }
 function get_customer_dtails($sid){
 $builder = $this->db->table('admission_tbl');
        $builder->select('parents_tbl.phone1,parents_tbl.address,classes_tbl.class_name');
        $builder->join('classes_tbl', 'classes_tbl.id = admission_tbl.class_id');
        $builder->join('parents_students_tbl', 'parents_students_tbl.student_id = admission_tbl.student_id');
        $builder->join('parents_tbl', 'parents_tbl.id = parents_students_tbl.parent_id');
        
        $builder->where('admission_tbl.student_id',$sid);
        $query = $builder->get()->getResult();
        $this->db->close();
        return $query;
 } 
 function get_paid_receipt($id,$date1,$date2,$y,$year){
     
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->select('ledger_transaction_tbl.trans_no,amount');
    $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
    $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no and invoice_type_transaction.transaction_type_id=ledger_transaction_tbl.trans_type');
    $builder->where('name_id',$id);
     if($year>2023){
     $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
    }else{
       $builder->where('transaction_numbers_tbl.trans_date <', ($year) . '-12-31'); 

    }
    if($y==1){
 $builder->where('DATE(trans_date) <=', $date2);
    }elseif($y==2){
  $builder->where('DATE(trans_date) >', $date1);
   $builder->where('DATE(trans_date) <=', $date2);
    }else{
       $builder->where('DATE(trans_date) >', $date1); 
    }
 
    //$builder->where('transation_nature = 1' );
    $builder->where('ledger_transaction_tbl.trans_type', 2);
   $builder->where('ledger_transaction_tbl.name_type_id',1);
   $builder->where('transaction_numbers_tbl.trans_type_id',2);
  $builder->whereIn('invoice_type_transaction.invoice_type_id', [2, 5]);
  $builder->groupBy('ledger_transaction_tbl.trans_no');
    $query = $builder->get()->getResult();
    $this->db->close();
    return $query;
 
 }  
 function get_paid_receipt_iv($id,$date1,$date2,$y,$no){
     
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->select('trans_no,amount');
    $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
    // $builder->join('transactions_relation', 'transactions_relation.invoice_trans_no = transaction_numbers_tbl.trans_number');
    $builder->where('name_id',$id);
    if($y==1){
 $builder->where('DATE(trans_date) <=', $date2);
    }elseif($y==2){
  $builder->where('DATE(trans_date) >', $date1);
   $builder->where('DATE(trans_date) <=', $date2);
    }else{
       $builder->where('DATE(trans_date) >', $date1); 
    }
 
    //$builder->where('transation_nature = 1' );
    $builder->where('ledger_transaction_tbl.trans_type', 2);
   $builder->where('ledger_transaction_tbl.name_type_id',1);
   $builder->where('transaction_numbers_tbl.trans_type_id',2);
   //$builder->where('transactions_relation.invoice_trans_no',$no);
  $builder->groupBy('ledger_transaction_tbl.trans_no');
    $query = $builder->get()->getResult();
    $this->db->close();
    return $query;
 
 }  
 function get_total_invoice_amount($id,$year){
      $builder = $this->db->table('ledger_transaction_tbl');
    $builder->select('*');
      $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no and invoice_type_transaction.transaction_type_id=ledger_transaction_tbl.trans_type');
      $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
    $builder->where('name_id',$id);
    $builder->where('transation_nature = 1');
    $builder->where('ledger_transaction_tbl.trans_type', 1);
   $builder->where('ledger_transaction_tbl.name_type_id',1);
   $builder->where('transaction_numbers_tbl.trans_type_id', 1);
    $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
   $builder->whereIn('invoice_type_transaction.invoice_type_id', [2]);
   $builder->groupBy('ledger_transaction_tbl.trans_no');
    $query = $builder->get()->getResult();
    return $query;
        } 
        
         function get_item_join_table11($id,$type){
      $builder = $this->db->table('invoice_type_transaction');
        $builder->select('invoice_types_tbl.type_name');
        $builder->join('invoice_types_tbl', 'invoice_type_transaction.invoice_type_id = invoice_types_tbl.id');
        $builder->where('trans_no',$id);
        $builder->where('invoice_type_transaction.transaction_type_id',$type);
        $query = $builder->get()->getResult();
        $this->db->close();
        return $query;
 }
  public function updateUpdate($trans,$date)
     {
       $builder = $this->db->table('transaction_numbers_tbl');
      $builder->set('trans_date', $date)
                  ->where('trans_number', $trans)
                  ->where('trans_type_id', 1)
                  ->update();
                  $this->db->close();
        return $builder;
     }  

    function get_invoice_message($stid,$tno){
         $builder = $this->db->table('messages');
        $builder->select('*');
        $builder->join('message_groups_tbl', 'message_groups_tbl.send_number = messages.send_no');
        $builder->where('messages.reference_no',$stid);
        $builder->where('message_groups_tbl.trans_number',$tno);
        $builder->where('message_groups_tbl.message_type',1);
      $query = $builder->get()->getResult();
      $this->db->close();
        return $query;
    }
    function get_invoice_amount_payed($trans_no,$lg){
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->select('sum(amount) as amount,balance,trans_item,ledger_id');
    $builder->where('trans_no',$trans_no);
    $builder->where('transation_nature',1);
    $builder->where('trans_type',2 );
    //$builder->where('ledger_id!=21');
    $query = $builder->get()->getResult();
    $this->db->close();
    return $query;
 }
 function get_paid_receiptex($trno){
     
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->selectSum('amount');
   $builder->where('transation_nature = 2' );
    $builder->where('ledger_transaction_tbl.trans_type', 2);
   $builder->where('ledger_transaction_tbl.trans_no',$trno);
    $query = $builder->get()->getResult();
    $this->db->close();
    return $query;
 
 } 

  function get_paid_credit($id,$date1,$date2,$y,$year){
     
    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->selectSum('amount');
    $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
    $builder->where('name_id',$id);
    $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
    if($y==1){
 $builder->where('DATE(trans_date) <=', $date2);
    }elseif($y==2){
  $builder->where('DATE(trans_date) >', $date1);
   $builder->where('DATE(trans_date) <=', $date2);
    }else{
       $builder->where('DATE(trans_date) >', $date1); 
    }
 
    //$builder->where('transation_nature = 1' );
    $builder->where('ledger_transaction_tbl.trans_type', 6);
   $builder->where('ledger_transaction_tbl.name_type_id',1);
   $builder->where('transaction_numbers_tbl.trans_type_id',6);
 // $builder->groupBy('ledger_transaction_tbl.trans_no');
    $query = $builder->get()->getResult();
    $this->db->close();
    return $query;
 
 }  

 public function deleteReceipt($id,$trans_no)
{
    $builder = $this->db->table('transaction_use_relation_tbl');
    $builder->where('receipt_no',$trans_no);
    $builder->delete();

    $builder = $this->db->table('invoice_type_transaction');
    $builder->where('trans_no',$trans_no);
    $builder->where('transaction_type_id',2);
    $builder->delete();

    $builder = $this->db->table('transactions_relation');
    $builder->where('receipt_trans_no',$trans_no);
    $builder->delete();

    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->where('trans_no',$trans_no);
    $builder->where('trans_type',2);
    $builder->delete();

    $builder = $this->db->table('transaction_numbers_tbl');
    $builder->where('id',$id);
    $builder->delete();

   $this->db->close();
    return $builder;

 } 

 public function trans_types(){
    $builder = $this->db->table('invoice_types_tbl');
        $builder->select('*');
$query = $builder->get()->getResult();
$this->db->close();
        return $query;
 }

 public function trans_types2(){
    $builder = $this->db->table('transaction_types_tbl');
        $builder->select('*');
$query = $builder->get()->getResult();
    $this->db->close();
        return $query;
 }

 public function get_bank_transactions($sdate,$edate,$ledger,$trans,$inv,$status){
   $builder = $this->db->table('payment_request');
    $builder->select('*');
    $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = payment_request.trans_no and invoice_type_transaction.transaction_type_id = payment_request.trans_type');
     $builder->join('invoice_types_tbl', 'invoice_types_tbl.id = invoice_type_transaction.invoice_type_id');
     //$builder->join('students', 'students.id = payment_request.student_id');
        
     $builder->where('DATE(payment_request.date_created) >=', $sdate);
   $builder->where('DATE(payment_request.date_created) <=', $edate);
  
  if($ledger>0 && $trans>0 && $inv>0 && $status!=2){
  $builder->where('payment_request.payment_channel',$ledger);
   $builder->where('payment_request.payment_status', $status);
   $builder->where('invoice_type_transaction.transaction_type_id',$trans);
   $builder->where('invoice_type_transaction.invoice_type_id',$inv);
}else if($ledger==0 && $trans>0 && $inv>0 && $status!=2){
    
   $builder->where('payment_request.payment_status', $status);
   $builder->where('invoice_type_transaction.transaction_type_id',$trans);
   $builder->where('invoice_type_transaction.invoice_type_id',$inv);
}else if($ledger==0 && $trans==0 && $inv>0 && $status!=2){
    
   $builder->where('payment_request.payment_status', $status);
   //$builder->where('invoice_type_transaction.transaction_type_id',$trans);
   $builder->where('invoice_type_transaction.invoice_type_id',$inv);
}else if($ledger==0 && $trans==0 && $inv==0 && $status!=2){
    
   $builder->where('payment_request.payment_status', $status);
   //$builder->where('invoice_type_transaction.transaction_type_id',$trans);
   //$builder->where('invoice_type_transaction.invoice_type_id',$inv);
}else if($ledger>0 && $trans==0 && $inv>0 && $status!=2){

    $builder->where('payment_request.payment_channel',$ledger);
   $builder->where('payment_request.payment_status', $status);
   //$builder->where('invoice_type_transaction.transaction_type_id',$trans);
   $builder->where('invoice_type_transaction.invoice_type_id',$inv);
}else if($ledger>0 && $trans==0 && $inv==0 && $status!=2){
    
    $builder->where('payment_request.payment_channel',$ledger);
   $builder->where('payment_request.payment_status', $status);
   //$builder->where('invoice_type_transaction.transaction_type_id',$trans);
  // $builder->where('invoice_type_transaction.invoice_type_id',$inv);
}else if($ledger>0 && $trans==0 && $inv==0 && $status==2){
    
    $builder->where('payment_request.payment_channel',$ledger);
   //$builder->where('payment_request.payment_status', $status);
   //$builder->where('invoice_type_transaction.transaction_type_id',$trans);
  // $builder->where('invoice_type_transaction.invoice_type_id',$inv);
}else if($ledger>0 && $trans>0 && $inv==0 && $status!=2){
    
    $builder->where('payment_request.payment_channel',$ledger);
   $builder->where('payment_request.payment_status', $status);
   $builder->where('invoice_type_transaction.transaction_type_id',$trans);
   //$builder->where('invoice_type_transaction.invoice_type_id',$inv);
}else if($ledger>0 && $trans>0 && $inv==0 && $status==2){
    
    $builder->where('payment_request.payment_channel',$ledger);
   //$builder->where('payment_request.payment_status', $status);
   $builder->where('invoice_type_transaction.transaction_type_id',$trans);
   //$builder->where('invoice_type_transaction.invoice_type_id',$inv);
}else if($ledger>0 && $trans>0 && $inv>0 && $status==2){
    
    $builder->where('payment_request.payment_channel',$ledger);
   //$builder->where('payment_request.payment_status', $status);
   $builder->where('invoice_type_transaction.transaction_type_id',$trans);
   $builder->where('invoice_type_transaction.invoice_type_id',$inv);
}else if($ledger>0 && $trans==0 && $inv>0 && $status==2){
    
    $builder->where('payment_request.payment_channel',$ledger);
   //$builder->where('payment_request.payment_status', $status);
   //$builder->where('invoice_type_transaction.transaction_type_id',$trans);
   $builder->where('invoice_type_transaction.invoice_type_id',$inv);
}else if($ledger==0 && $trans>0 && $inv==0 && $status==2){
    
    //$builder->where('payment_request.payment_channel',$ledger);
   //$builder->where('payment_request.payment_status', $status);
   $builder->where('invoice_type_transaction.transaction_type_id',$trans);
   //$builder->where('invoice_type_transaction.invoice_type_id',$inv);
}
 // $builder->groupBy('ledger_transaction_tbl.trans_no');
    $query = $builder->get()->getResult();
    $this->db->close();
    return $query;
 }
 public function get_bank_receipt($sdate,$edate,$channel,$ctrtype){
      $builder = $this->db->table('payment_response');
    $builder->select('*');
    $builder->join('payment_request', 'payment_request.reference_no = payment_response.reference_no');
     $builder->where('DATE(payment_response.transaction_date) >=', $sdate);
   $builder->where('DATE(payment_response.transaction_date) <=', $edate);

     if($channel>0 && $ctrtype!=9){
  $builder->where('payment_request.payment_channel',$channel);
   $builder->where('payment_request.allow_partial', $ctrtype);
   
}else if($channel>0 && $ctrtype==9){
   $builder->where('payment_request.payment_channel',$channel);
   //$builder->where('payment_request.allow_partial', $ctrtype);
}else if($channel==0 && $ctrtype!=9){
   //$builder->where('payment_request.payment_channel',$channel);
   $builder->where('payment_request.allow_partial', $ctrtype);

}
$query = $builder->get()->getResult();
$this->db->close();
    return $query;
 }

  public function delete_invoice_item($id,$trans_no)
{
    $builder = $this->db->table('item_transation_tbl');
    $builder->where('trans_number',$trans_no);
    $builder->where('trans_type',1);
    $builder->delete();

    $builder = $this->db->table('invoice_type_transaction');
    $builder->where('trans_no',$trans_no);
    $builder->where('transaction_type_id',1);
    $builder->delete();

    $builder = $this->db->table('transactions_relation');
    $builder->where('invoice_trans_no',$trans_no);
    $builder->delete();

    $builder = $this->db->table('ledger_transaction_tbl');
    $builder->where('trans_no',$trans_no);
    $builder->where('trans_type',1);
    $builder->delete();

    $builder = $this->db->table('transaction_numbers_tbl');
    $builder->where('id',$id);
    $builder->delete();

   $this->db->close();
    return $builder;

 }

 public function delete_ctr_item($trans_no,$ref){
    $builder = $this->db->table('payment_request');
    $builder->where('trans_no',$trans_no);
    $builder->where('reference_no',$ref);
    $builder->delete();
    $this->db->close();
 }
 function delete_invoice_transport($id){
     $builder = $this->db->table('transport_details');
    $builder->where('id',$id);
    $builder->delete();
    $this->db->close();
 }

 function insert_balance($data){
     $builder = $this->db->table('student_balance_tbl')->insert($data);
     $this->db->close();
       // return $builder;
 }
 function update_balance($sid,$year,$data){
      $builder = $this->db->table('student_balance_tbl');
            $builder->where('student_id',$sid);
            $builder->where('year',$year);
            $builder->update($data);
            $this->db->close();
 }
 function get_pai_receipt($trans,$date1,$date2,$y,$year){
     
    $builder = $this->db->table('transactions_relation');
    $builder->select('transaction_numbers_tbl.trans_number');
    $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = transactions_relation.receipt_trans_no');
  
    $builder->where('transaction_numbers_tbl.trans_type_id',2);
  $builder->whereIn('transactions_relation.invoice_trans_no', $trans);
    if($y==1){
 $builder->where('DATE(trans_date) <=', $date2);
    }elseif($y==2){
  $builder->where('DATE(trans_date) >', $date1);
   $builder->where('DATE(trans_date) <=', $date2);
    }else{
       $builder->where('DATE(trans_date) >', $date1); 
    }
 $builder->groupBy('transaction_numbers_tbl.trans_number');
  $query = $builder->get()->getResult();
  $this->db->close();
    return $query;
 
 } 
 
 function delete_detail($id,$table){
     $builder = $this->db->table($table);
    $builder->where('id',$id);
    $builder->delete();
    $this->db->close();
 }
 function get_invoice_balances($year,$classlevel,$class,$stream,$status){
      $builder = $this->db->table('admission_tbl');
    $builder->select('
        admission_tbl.*,
        ledger_transaction_tbl.*,
        students.*,
        transaction_numbers_tbl.*,
        admission_tbl.student_id,
        ');
    $builder->join('ledger_transaction_tbl', 'ledger_transaction_tbl.name_id = admission_tbl.student_id');
    $builder->join('students', 'students.id = admission_tbl.student_id');
    $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
     $builder->where('admission_tbl.academic_year',$year);
     $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
     
     if($stream > 0 && $class >0 && $classlevel>0){
     $builder->where('admission_tbl.stream_id', $stream);
     $builder->where('admission_tbl.class_id', $class);
     $builder->where('admission_tbl.level_id', $classlevel);
    }
    elseif($stream == 0 && $class >0 && $classlevel>0){
     $builder->where('admission_tbl.class_id', $class);
     $builder->where('admission_tbl.level_id', $classlevel);
    }
elseif($stream == 0 && $class ==0 && $classlevel>0){
    $builder->where('admission_tbl.level_id', $classlevel);
    }
    elseif($stream > 0 && $class >0 && $classlevel==0){
     $builder->where('admission_tbl.stream_id', $stream);
     $builder->where('admission_tbl.class_id', $class);
     }
     elseif($stream > 0 && $class ==0 && $classlevel==0){
     $builder->where('admission_tbl.stream_id', $stream);
    
     }
     elseif($stream == 0 && $class >0 && $classlevel==0){
     $builder->where('admission_tbl.class_id', $class);
     }
     elseif($stream > 0 && $class ==0 && $classlevel>0){
     $builder->where('admission_tbl.stream_id', $stream);
     $builder->where('admission_tbl.level_id', $classlevel);
     }
     $builder->where('students.status',$status);
     $builder->where('ledger_transaction_tbl.trans_type',1);
     $builder->where('ledger_transaction_tbl.ledger_type',7);
     $builder->groupBy('ledger_transaction_tbl.trans_no');
      $query = $builder->get()->getResult();
      $this->db->close();
    return $query;
 
 }
 
 function deleteCreditNote($id,$trans_no){
   $builder = $this->db->table('invoice_type_transaction');
    $builder->where('trans_no',$trans_no);
    $builder->where('transaction_type_id',6);
    $builder->delete();
$builder = $this->db->table('ledger_transaction_tbl');
    $builder->where('trans_no',$trans_no);
    $builder->where('trans_type',6);
    $builder->delete();
$builder = $this->db->table('item_transation_tbl');
    $builder->where('trans_number',$trans_no);
    $builder->where('trans_type',6);
    $builder->delete();
$builder = $this->db->table('transaction_numbers_tbl');
    $builder->where('id',$id);
    $builder->delete();
    $this->db->close();

return $builder;
  }
  
  function get_item_name3($name,$type,$year){
      $builder = $this->db->table('students');
      $builder->select('*');
      $builder->like('full_name',$name,'both');
     $builder->join('ledger_transaction_tbl','ledger_transaction_tbl.name_id=students.id');
      $builder->where('ledger_transaction_tbl.name_type_id',1);
     $builder->groupBy('ledger_transaction_tbl.trans_no');
     $builder->where('ledger_transaction_tbl.trans_type',$type);
     $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
     $builder->where('transaction_numbers_tbl.trans_type_id',$type);
      $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
      $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }
 
 function search_student($name){
      $builder = $this->db->table('students');
      $builder->select('*');
      $builder->like('full_name',$name,'both');
     $query = $builder->get();
      $this->db->close();
      return $query;
 }
 
 
 function get_items_total($trans_no){
$builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('sum(amount) as total');
      $builder->where('trans_no',$trans_no);
      $builder->where('trans_type',1);
     $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }
 
 function get_all_creditnote($type,$nature,$tn){
  $builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('sum(amount) as total,name_id,trans_no,name_type_id');
      $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no and transaction_numbers_tbl.trans_type_id=ledger_transaction_tbl.trans_type');
      $builder->where('transation_nature',$nature);
      $builder->where('trans_type',$type);
      $builder->where('trans_type_id',$type);
      
      if($tn !=0){
      $builder->where('trans_no',$tn);
        }
      $builder->groupBy('trans_no');
      $builder->orderBy('trans_date');
     $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }
 
 function admitted_invoices($tbl,$col){
   $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->groupBy($tbl.'.'.$col);
      $builder->where('receipt_number',0);
        $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }
 
 public function get_control_byname($names,$ttl,$year){
   $builder = $this->db->table('payment_request');
    $builder->select('*,payment_request.student_id');
    $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = payment_request.trans_no and invoice_type_transaction.transaction_type_id = payment_request.trans_type');
     $builder->join('invoice_types_tbl', 'invoice_types_tbl.id = invoice_type_transaction.invoice_type_id');
     $builder->join('students', 'students.id = payment_request.student_id');
        
 
   $builder->where('payment_request.inv_type !=',1);
   $builder->like('payment_request.date_created',$year,'after');
    if($ttl==1){
      $builder->like('students.first_name',$names[0],'both');
    }
     if($ttl==2){
      $builder->like('students.first_name',$names[0],'both');
      $builder->like('students.middle_name',$names[1],'both');
    }
    if($ttl==3){
      $builder->like('students.first_name',$names[0],'both');
      $builder->like('students.middle_name',$names[1],'both');
      $builder->like('students.last_name',$names[2],'both');
    }
    $query = $builder->get()->getResult();
      $this->db->close();
      return $query;

}
 function get_class_data($id,$year){
      $builder = $this->db->table('admission_tbl');
      $builder->select('classes_tbl.class_name,streams_tbl.stream_name');
        $builder->join('classes_tbl', 'admission_tbl.class_id = classes_tbl.id');
     $builder->join('streams_tbl', 'admission_tbl.stream_id = streams_tbl.id');
      $builder->where('admission_tbl.student_id',$id);
      $builder->where('admission_tbl.academic_year',$year);
      $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }
  function get_paytype_name($tbl,$ids){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->whereIn('id',$ids);
      $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
 }

}

?>
