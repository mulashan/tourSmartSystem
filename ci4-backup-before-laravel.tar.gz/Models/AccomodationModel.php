<?php

namespace App\Models;

use CodeIgniter\Model;

class AccomodationModel extends Model
{
    public $db;
    public function __construct(){
        $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    }


    public function items_chargedList()
    {
        $builder = $this->db->table('items_tbl');
        $builder->select('id,item_name,item_price');
        $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
        $query = $builder->get()->getResult();
            
         return $query;
    }
    public function accomodationList()

	
    {
        $builder = $this->db->table('hostel_blocks_tbl');
        $builder->select('hostel_blocks_tbl.hostel_id,hostel_blocks_tbl.block_name,hostel_blocks_tbl.gender,hostel_blocks_tbl.start_age,hostel_blocks_tbl.end_age,
		hostel_blocks_tbl.capacity,hostel_tbl.hostel_name,hostel_tbl.status,hostel_tbl.updated_by,hostel_tbl.updated_date
		');
        $builder->join('hostel_tbl', 'hostel_tbl.id = hostel_blocks_tbl.hostel_id');
       $query = $builder->get()->getResult();
            
         return $query;
    }
	function get_termsPayments($id){
         $builder = $this->db->table('installments_tbl');
        $builder->select('installments_tbl.amount,school_terms_tbl.term_name,school_terms_tbl.start_date,school_terms_tbl.end_date
        ');
        $builder->join('school_terms_tbl', 'school_terms_tbl.id = installments_tbl.istallment_name');
        $builder->where('installments_tbl.tbl_id',$id);
        $builder->where('installments_tbl.installment_type',2);
        $query = $builder->get()->getResult();
            
         return $query;   
    }
	public function singleAccomodation($id)
    {
        $builder = $this->db->table('hostel_blocks_tbl');
        $builder->select('hostel_id,block_name,gender,capacity,start_age,end_age');
        $builder->select('hostel_name');
        $builder->join('hostel_tbl', 'hostel_tbl.id = hostel_blocks_tbl.hostel_id');
		$builder->where('hostel_id',$id);
        $query = $builder->get()->getResult();
            
         return $query;
    }
	public function get_receivableAccount($id){
    $builder = $this->db->table('accounts_tbl');
    $builder->select('*');
    $builder->where('id',$id);
        $query = $builder->get()->getResult();
            
         return $query;
    }
	public function tabledata($id)
    {
        $builder = $this->db->table('hostel_charged_items_tbl');
        $builder->select('hostel_charged_items_tbl.id,hostel_charged_items_tbl.account_receivable,hostel_charged_items_tbl.hostel_id,hostel_charged_items_tbl.item_id,
		hostel_charged_items_tbl.quantity,items_tbl.item_name,items_tbl.item_attribute,items_tbl.item_size,
		price_tbl.item_price');
        $builder->join('items_tbl', 'items_tbl.id = hostel_charged_items_tbl.item_id');
        $builder->join('price_tbl', 'price_tbl.item_id = hostel_charged_items_tbl.item_id');
		$builder->where('hostel_charged_items_tbl.hostel_id',$id);
        $query = $builder->get()->getResult();
            
         return $query;
    }
	
    public function items_chargedList1($id)
    {
        $builder = $this->db->table('items_tbl');
        $builder->select('items_tbl.id,item_name,item_price,item_size,item_attribute,account_name,item_balance,avg_cost,last_price');
        $builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
        $builder->join('items_ledgers_tbl', 'items_ledgers_tbl.item_id = items_tbl.id');
         $builder->join('accounts_tbl', 'accounts_tbl.id = items_ledgers_tbl.account_id');
        $builder->where('items_tbl.id',$id);
        $builder->groupBy('items_ledgers_tbl.item_id');
        $query = $builder->get()->getResult();
            
         return $query;
    }
public function selectItemId($id)
    {
        $builder = $this->db->table('hostel_charged_items_tbl');
        $builder->select('item_id');
        $builder->where('hostel_id',$id);
        $query = $builder->get()->getResult();
            
         return $query;
    }
	public function modify($update)
    {
        $builder = $this->db->table('users');
        $builder->select('');
        $builder->where('user_id',$update);
        $query = $builder->get()->getResult();
            
         return $query;
    }
	
    public function add_hostel($data)
    {
        $builder = $this->db->table('hostel_tbl')->insert($data);

        if($builder){
            return $this->db->insertID();
        }else{
            return 0;
        }

    }

    public function save_hostelBlocks($data1){
        $builder = $this->db->table('hostel_blocks_tbl')->insert($data1);

    }

    public function save_charged_items($charged_item)
    {
        $builder = $this->db->table('hostel_charged_items_tbl')->insert($charged_item);
    }
	
	 public function edit_charged_items($hostel,$charged_item)
    {
        	$builder = $this->db->table('hostel_charged_items_tbl')->insert($charged_item);
			//$builder = $this->db->table('hostel_charged_items_tbl');
			//$builder->where('hostel_id',$hostel);
			//$builder->update($charged_item);
    }
  public function delete_hostelId($hostel)
		{
            $builder = $this->db->table('hostel_charged_items_tbl');
			$builder->select('hostel_id');
			$builder->where('hostel_id',$hostel);
			$builder->delete();
		}
  
  
    public function Save_newBlock($insert_Block)
             {
        $builder = $this->db->table('hostel_blocks_tbl')->insert( $insert_Block);

             }
	public function edit_accomodation($id,$data,$data1)
		{
			

			$builder = $this->db->table('hostel_blocks_tbl');
			$builder->where('hostel_id',$id);
			$builder->update($data);

			$builder = $this->db->table('hostel_tbl');
			$builder->where('id',$id);
			$builder->update($data1);
		}
	public function deleteAcc($id)
		{
			$builder = $this->db->table('hostel_blocks_tbl');
			$builder->select('hostel_id');
			$builder->where('hostel_id',$id);
			$builder->delete();

			$builder = $this->db->table('hostel_charged_items_tbl');
			$builder->select('hostel_id');
			$builder->where('hostel_id',$id);
			$builder->delete();

			$builder = $this->db->table('hostel_tbl');
			$builder->select('id');
			$builder->where('id',$id);
			$builder->delete();

		}
		public function deletehostelItem($id)
		{

			$builder = $this->db->table('hostel_charged_items_tbl');
			$builder->select('id');
			$builder->where('id',$id);
			$builder->delete();

			

		}
		public function add_temporary($data)
     {
        $builder = $this->db->table('installments_tbl')->insert($data);

        return $builder;
     }
	 public function saveInstallmentData($id)
     {
       $builder = $this->db->table('installments_tbl');
      $builder->set('tbl_id', $id)
                  ->where('tbl_id', 0)
                  ->update();
        return $builder;
     }	
	 public function add_installment($data)
     {
        $builder = $this->db->table('installments_tbl')->insert($data);

        return $builder;
     }
     public function check_temp($name)
     {
        $builder = $this->db->table('installments_tbl');
        $builder->select('*');
        $builder->where('istallment_name',$name);
        $builder->where('tbl_id=0');
        $builder->where('installment_type=2');
        $query = $builder->get()->getResult();

        return count($query);
     }
     public function check_inst($id,$name)
     {
        $builder = $this->db->table('installments_tbl');
        $builder->select('*');
        $builder->where('istallment_name',$name);
        $builder->where('tbl_id',$id);
        $builder->where('installment_type=2');
        $query = $builder->get()->getResult();

        return count($query);
     }
     public function deposit_data($id){
         $builder = $this->db->table('item_transation_tbl');
        $builder->select('items_tbl.id,item_transation_tbl.unit_price,item_name,item_size,item_attribute');
        $builder->join('items_tbl', 'items_tbl.id = item_transation_tbl.item_id');
        $builder->where('trans_number',$id);
        $builder->where('trans_type',3);
        $query = $builder->get()->getResult();
            
         return $query;
     }
}

