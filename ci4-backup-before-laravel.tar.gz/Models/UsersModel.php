<?php

namespace App\Models;

use CodeIgniter\Model;

class UsersModel extends Model
{


    // protected $table = 'users_type_tbl';
    // protected $primaryKey = 'id';
    // protected $allowedFields = ['type_name', 'description'];
     public function __construct(){
       $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
      
   }

    public function saverecords($data)
    {
        $query = $this->db->table('users_type_tbl')->insert($data);
        return $query;
    }
	public function GetAllUserType(){
		$query=$this->db->table('users_type_tbl');
		$query->select('*');
		$Result=$query->get()->getResult();
		return $Result;
		
	}


    public function getUsertypeList()
    {
    	  $dbname=session()->get('db_name');
       $db=\Config\Database::connect($dbname);
        
        $query = $db->query('SELECT * FROM users_type_tbl');
        $result = $query->getResult();
        if(count($result) > 0){
            return $result;
        }else{
            return false;
        }
    }

    public function addNewUser($data,$dbname)
    {
         $this->db=\Config\Database::connect($dbname);
        $query = $this->db->table('users')->insert($data);
		if($query){
            return $this->db->insertID();
        }else{
            return 0;
        }
        //return $query;
    }
    
	     public function LoginDetails($data1,$dbname)
    {
          $this->db=\Config\Database::connect($dbname);
        $query = $this->db->table('users_session_tbl')->insert($data1);
		
        return $query;
    }
	
	public function getUsers($db_id){
	    $db=\Config\Database::connect();
         $builder = $db->table('users');
        $builder->select('users.user_id,users.first_name,users.last_name,
		users.gender,users.other_name,users.email,users.user_photo,users.status,users.physical_adress,users.updated_date,
		users.user_type,users.phone_no,users_session_tbl.username,users_type_tbl.type_name
		');
        $builder->join('users_session_tbl', 'users.user_id = users_session_tbl.user_id');
        $builder->join('users_type_tbl', 'users.user_type = users_type_tbl.id');
        $builder->where('database_id',$db_id);
                $builder->groupBy('users.user_id');
        $query = $builder->get()->getResult();
            
         return $query;		 
         
	}
		public function selectUsername($db){
			$db=\Config\Database::connect();
	     $builder = $db->table('users_session_tbl');
       $builder->select('initial_username');
       $builder->orderby('initial_username', 'DESC');
        $query = $builder->get()->getResult();
            
         return $query;
	}
	public function select_type(){
	     $builder = $this->db->table('users_type_tbl');
        $builder->select('*');
        $query = $builder->get()->getResult();
            
         return $query;
	}
	public function select_id(){
	     $builder = $this->db->table('users_type_tbl');
        $builder->select('type_name');
        //$builder->where('id',$id);
        $query = $builder->get()->getResult();
            
         return $query;
	}
	public function get_User($id){
		$builder = $this->db->table('users');
        $builder->select('users.user_id,users.first_name,users.last_name,users.user_photo,
		users.gender,users.national_id,users.other_name,users.email,users.status,users.physical_adress,users.updated_date,
		users.user_type,users.phone_no,users_session_tbl.initial_username,users_session_tbl.username,users_type_tbl.type_name,users.staff,users.birth_date
		');
        $builder->join('users_session_tbl', 'users.user_id = users_session_tbl.user_id');
        $builder->join('users_type_tbl', 'users.user_type = users_type_tbl.id');
        $builder->where('users.user_id',$id);
		$query = $builder->get()->getResult();
            
         return $query;
	}
	
	public function deleteUser($id)
    {

        $builder = $this->db->table('users_session_tbl');
        $builder->where('user_id',$id);
        $builder->delete(); 

        $builder = $this->db->table('users');
        $builder->where('user_id',$id);
        $builder->delete();		
    }
	public function DeleteUserType($id){
		$query=$this->db->table('users_type_tbl');
		$query->where('id',$id);
		$Result=$query->delete();
		return $Result;
	}
	public function UpdateUserType($id,$data){
		$query=$this->db->table('users_type_tbl');
		$query->where('id',$id);
		$Result=$query->update($data);
		return $Result;
	}
	
	public function userEdit($id,$data,$data_s){
		$query=$this->db->table('users');
		$query->where('user_id',$id);
		$Result=$query->update($data);
		//return $Result;
		
		 $build=$this->db->table('users_session_tbl');
        $build->where('user_id',$id);
        $Res=$build->update($data_s);
        return $Res;
	}
	function user_inf($id) {
		$builder = $this->db->table('users_type_tbl ');
        $builder->select('');
        $builder->where('id',$id);
        $query = $builder->get()->getResult();
         return $query; 
		
    }
	function user_settings($id) {
		$builder = $this->db->table('modules_privileges');
        $builder->select('modules_tbl.label,modules_tbl.module_id,modules_tbl.route_path,modules_tbl.parent_id,modules_tbl.description');
        $builder->join('modules_tbl', 'modules_tbl.module_id = modules_privileges.module_id');
        $builder->where('modules_privileges.privilege_id', $id);
		$result = $builder->get()->getResult();
        return $result;
    }
	function list_unassigned_privileges($id, $list_assigned) {
		$builder = $this->db->table('modules_tbl');
       $builder->select('modules_tbl.module_id,modules_tbl.name,modules_tbl.label,modules_tbl.description');
        
        $builder->whereNotIn('modules_tbl.module_id', $list_assigned);
        $result = $builder->get()->getResult();
        return $result;
    }
	function assign_menu($add_menu) {
        
		$query = $this->db->table('modules_privileges')->insert($add_menu);
		return $query;
    }
	
	public function remove_menu($modid,$usetype){
		$builder=$this->db->table('modules_privileges');
		 $builder->where('module_id',$modid);
		 $builder->where('privilege_id',$usetype);
        $query=$builder->delete();
		return $query;
	}
	
	public function check_usertype($usetype){
		$builder=$this->db->table('users');
        $builder->select('');
        $builder->where('user_type',$usetype);
        $query = $builder->get()->getResult();
         return $query; 
	}
	public function remove_usertype($usetype){
		$builder=$this->db->table('users_type_tbl');
		 $builder->where('id',$usetype);
        $builder->delete();
		
		$builder=$this->db->table('modules_privileges');
		 $builder->where('privilege_id',$usetype);
        $builder->delete();
		
}
function user_settings_all($id,$username) {
       $builder = $this->db->table('modules_privileges');
        $builder->select('modules_tbl.label,modules_tbl.module_id,modules_tbl.route_path,modules_tbl.parent_id,modules_tbl.description');
        $builder->join('modules_tbl', 'modules_tbl.module_id = modules_privileges.module_id');
        $builder->orwhere('modules_privileges.privilege_id', $id);
        $builder->orwhere('modules_privileges.privilege_id', $username);
		$result = $builder->get()->getResult();
        return $result;
    }
	function remov_user_priv($usr_id, $m_id) {
		$builder = $this->db->table('modules_privileges');
        $builder->where('privilege_id', $usr_id);
        $builder->where('module_id', $m_id);
        $builder->delete();
    }
	function update_users($username, $undata) {
		$builder = $this->db->table('users_session_tbl');
        $builder->where('user_id', $username);
        $builder->update($undata);
    }
    
	function get_current_pass($username) {
		$builder = $this->db->table('users_session_tbl');
        $builder->select('*');
        
        $builder->where('user_id', $username);
        $result = $builder->get()->getResult();
        return $result;
    }
	function change_pass($username, $changes) {
		$builder = $this->db->table('users_session_tbl');
        $builder->where('user_id', $username);
        $builder->update($changes);
    }
    function get_dbn($db){
    	 $builder = $this->db->table('database_list_tbl');
        $builder->select('*');
         $builder->where('db_id', $db);
        $query = $builder->get()->getResult();
            
         return $query;
    }
    function addNewUser_user($datas,$db,$table){
    	$db=\Config\Database::connect($db);
 $query = $db->table($table)->insert($datas);
		
        return $query;
    }

   function addNewUser_parent($datas,$db,$table){
   		$db=\Config\Database::connect($db);
   $query = $db->table($table)->insert($datas);
		if($query){
            return $db->insertID();
        }else{
            return 0;
        }
   }
   function update_users_1($username, $undata,$db,$table,$data_s) {
    	$db=\Config\Database::connect($db);
		$builder = $db->table($table);
        $builder->where('user_id', $username);
        $builder->update($undata);
        
         $query=$db->table('users_session_tbl');
        $query->where('user_id',$username);
        $Result=$query->update($data_s);
        return $Result;
    }

    function change_pass2($username, $changes) {
        $db=\Config\Database::connect();
        $builder = $db->table('users_session_tbl');
        $builder->where('user_id', $username);
        $builder->update($changes);
    }

    function update_users2($username, $undata) {
        $db=\Config\Database::connect();
        $builder = $db->table('users_session_tbl');
        $builder->where('user_id', $username);
        $builder->update($undata);
    }

    public function addNewUser2($data)
    {
         $this->db=\Config\Database::connect();
        $query = $this->db->table('users')->insert($data);
        if($query){
            return $this->db->insertID();
        }else{
            return 0;
        }
    }

     public function LoginDetails2($data1)
    {
        $db=\Config\Database::connect();
        $query = $db->table('users_session_tbl')->insert($data1);
        
        return $query;
    }

    public function checkUsername($username){
     $db=\Config\Database::connect();
      $builder = $db->table('users_session_tbl');
       $builder->select('username');
       $builder->where('username', $username);
        $query = $builder->get()->getResult();
            
         return $query;
    }
    
     public function get_details($tbl,$id)
    {
        $this->db=\Config\Database::connect();
        $builder = $this->db->table($tbl);
        $builder->select('');
        $builder->where($id);
        $results=$builder->get()->getResult();
        $this->db->close();
        return $results;
    }
        public function Check_user_existance($cond1, $cond2, $cond3,$database)
           {
              $builder = $this->db->table('users');
        $builder->where('database_id', $database);
        $builder->groupStart()
            ->where($cond1)
        ->groupEnd();
        $builder->orGroupStart()
            ->where($cond2)
        ->groupEnd();
        $builder->orGroupStart()
            ->where($cond3)
        ->groupEnd();
        $results = $builder->get()->getResult();
        return $results;
        }
     public function get_max_userID($tbl,$col){
     $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    return $builder->get()->getRow();
  }

}
