<?php

namespace App\Models;

use CodeIgniter\Model;

class StudentModel extends Model
{
    public $db;
    public function __construct(){
      $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    }
    
 function getnationalities($tbls){
     $query = $this->db->table($tbls);
     return $query->get()->getResult();
 }
 public function SaveData($tbl,$data){
    $query = $this->db->table($tbl)->insert($data);
    return $query;
}
function check_student($tbl,$fname,$mname,$lname){
    $builder = $this->db->table($tbl);
    $builder->select('');
    $builder->where('first_name',$fname);
    $builder->where('middle_name',$mname);
    $builder->where('last_name',$lname);
    $query = $builder->get()->getResult();

    return $query; 
}
function check_student_with_id($id){
    $builder = $this->db->table('students');
    $builder->select('');
    $builder->where($id);
    $query = $builder->get()->getResult();

    return $query;  
}
function gettable_data1($tbl,$id){
     $query = $this->db->table('parents_students_tbl');
     $query->select('parents_students_tbl.sp_id,parents_tbl.id,parents_tbl.first_name,parents_tbl.relation,parents_tbl.last_name,parents_tbl.last_name,parents_tbl.occupation,parents_tbl.address,parents_tbl.phone1,parents_tbl.email,parents_tbl.phone2');
      $query->join('parents_tbl','parents_tbl.id=parents_students_tbl.parent_id');
     $query->where('parents_students_tbl.sp_id',$id);
     return $query->get()->getResult();
 }
function gettable_data($tbl,$id){
     $query = $this->db->table($tbl);
     $query->select('*');
     $query->where($id);
     return $query->get()->getResult();
 }
 function gettable_data2($tbl,$id){
     $query = $this->db->table($tbl);
     $query->select('*');
       $query->join('students','students.id=admission_tbl.student_id');
       $query->join('ledger_transaction_tbl','ledger_transaction_tbl.name_id=admission_tbl.student_id');
    $query->join('transaction_types_tbl','transaction_types_tbl.type_id=ledger_transaction_tbl.trans_type');
       $query->join('transport_details','transport_details.student_id=ledger_transaction_tbl.name_id');
     $query->where('ledger_transaction_tbl.ledger_id',3);
     $query->where('admission_tbl.status',$id);
     $query->groupBy('ledger_transaction_tbl.trans_no');
     return $query->get()->getResult();
 }
  public function SaveData_n_get_id($tbl,$data){
    $query = $this->db->table($tbl)->insert($data);
    if($query)
    {
        return $this->db->insertID();
    }
    else{
        return false;
     }
}
function deletetable_data($tbl,$id){
    $builder = $this->db->table('parents_students_tbl');
    $builder->where('parents_students_tbl.sp_id',$id);
    $builder->delete();
}
function deletetable_data1($tbl,$id){
    $builder = $this->db->table($tbl);
    $builder->where('id',$id);
    $builder->delete();
}
function update_table_details($table,$condition,$data){
    $builder = $this->db->table($table);
    $builder->where($condition);
    $builder->update($data);
      return $this->db->affectedRows();
}
 function get_max_refno(){
    $this->db->select('max(payment_reference) as payment_reference');
    $this->db->from('gateway_response');
    $this->db->like('payment_reference',"SAS195",'after' );

      return $this->db->get();
  }
  public function get_active_item($tbl)
     {
        $builder = $this->db->table($tbl);
        $builder->select('*');
        $builder->where('status = 1');
        $query = $builder->get()->getResult();
        return $query;
     }
  function get_level_price($lvl){
        $builder = $this->db->table('class_level_items_tbl');
        $builder->select('items_tbl.item_type,price_tbl.item_id,price_tbl.item_price,items_tbl.item_group,class_level_items_tbl.quantity');
        $builder->join('price_tbl', 'price_tbl.item_id = class_level_items_tbl.item_id');
        $builder->join('items_tbl', 'items_tbl.id = class_level_items_tbl.item_id');
        $builder->where('level_id',$lvl);
        $builder->where('item_group', 1);
        $query = $builder->get()->getResult();
            
         return $query;
    //nmeadd condition ya itemgroup
  }
  function get_max_id($tbl,$col){
     $builder = $this->db->table($tbl);
     $builder->select('max('.$col.') as max_id');
     return $builder->get()->getResult();
  }
   function get_max_receipt($tbl,$col){
     $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    $builder->where('trans_type_id', 2);
    return $builder->get()->getResult();
  }
  function get_max_invoice($tbl,$col){
     $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    $builder->where('trans_type_id', 1);
    return $builder->get()->getResult();
  }
  function get_table_data_dsc($tbls){
     $query = $this->db->table($tbls);
     $query->orderBy('id', 'DESC');
     return $query->get()->getResult();
 }

 function get_parentStudent_details($tbl,$tbl1,$condition){
    $builder = $this->db->table($tbl);
    $builder->select('*');
    $builder->join($tbl1);
    $builder->where($condition);
    return $builder->get()->getResult();
 }

 function gettable_billingdata($id){
    $builder = $this->db->table('parents_students_tbl');
    $builder->select('parents_tbl.id,first_name,last_name,full_name,occupation,address,phone1,email,postal_address');
    $builder->join('parents_tbl', 'parents_tbl.id = parents_students_tbl.parent_id');
    $builder->where('parents_students_tbl.student_id',$id);
    $builder->where('bill_account',1);
    return $builder->get()->getResult();
 } 

 function gettable_parentdata($pid,$sid){
    $builder = $this->db->table('parents_students_tbl');
    $builder->select('parents_students_tbl.sp_id,parents_students_tbl.parent_id,first_name,relation,last_name,full_name,occupation,address,phone1,email,postal_address');
    $builder->join('parents_tbl', 'parents_tbl.id = parents_students_tbl.parent_id');
    $builder->where('parents_students_tbl.student_id',$sid);
    //$builder->where('parents_students_tbl.parent_id',$pid);
    $builder->where('bill_account',0);
    return $builder->get()->getResult();
 }   

function getSingle_student($id){
    $builder = $this->db->table('students');
    $builder->select('');
    $builder->where('id',$id);
    $query = $builder->get()->getResult();

    return $query;  
}
function parent_info($id) {
        $builder = $this->db->table('parents_tbl');
        $builder->select('first_name,last_name,relation,address,occupation,phone1,email');
         $builder->join('parents_students_tbl', 'parents_students_tbl.parent_id = parents_tbl.id');
       $builder->where('parents_students_tbl.student_id', $id);
       $builder->where('bill_account', 0);
        $result = $builder->get()->getResult();
        return $result;
    }
    function class_info($id) {
        $builder = $this->db->table('admission_tbl');
        $builder->select('admission_tbl.id,date_joined,admission_tbl.class_id,admission_tbl.level_id,admission_tbl.stream_id,class_name,level_name,stream_name');
         $builder->join('classes_tbl', 'classes_tbl.id = admission_tbl.class_id');
         $builder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id');
         $builder->join('streams_tbl', 'streams_tbl.id = admission_tbl.stream_id');
       $builder->where('student_id', $id);
       $builder->where('admission_tbl.status', 0);
        $result = $builder->get()->getResult();
        return $result;
    }
    
    function prev_school($id) {
        $builder = $this->db->table('previous_school');
        $builder->select('school_name,year_attended');
       $builder->where('student_id', $id);
        $result = $builder->get()->getResult();
        return $result;
    }
    function bill_address($id) {
        $builder = $this->db->table('parents_tbl');
        $builder->select('first_name,last_name,phone1,email,address');
        $builder->join('parents_students_tbl', 'parents_students_tbl.parent_id= parents_tbl.id');
       $builder->where('parents_students_tbl.student_id', $id);
       $builder->where('bill_account', 1);
        $result = $builder->get()->getResult();
        return $result;
    }
    
    function stu_transaction($id,$sdate,$edate) {
        $in=[1,4];
     
        $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('ledger_id,ledger_transaction_tbl.trans_no,ledger_transaction_tbl.trans_type,ledger_transaction_tbl.transation_nature,transaction_numbers_tbl.trans_date,transaction_numbers_tbl.updated_date,transaction_types_tbl.type_name,accounts_tbl.description,ledger_transaction_tbl.amount');
         $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
         $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number= ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id=ledger_transaction_tbl.trans_type');
      $builder->join('accounts_tbl', 'accounts_tbl.id= ledger_transaction_tbl.ledger_id');
          $builder->wherein('ledger_transaction_tbl.name_type_id',$in);
       $builder->where('ledger_transaction_tbl.name_id', $id);
       
       $builder->where('DATE(transaction_numbers_tbl.trans_date) >=', $sdate);
   $builder->where('DATE(transaction_numbers_tbl.trans_date) <=', $edate);
       $builder->groupBy('ledger_transaction_tbl.trans_no');
       $builder->orderBy('updated_date', 'ASC');
      
        $result = $builder->get()->getResult();
        return $result;   
         }
         function get_transaction($id,$type,$nameid,$tp) {
        $builder = $this->db->table('invoice_type_transaction');
        $builder->select('*');
         $builder->join('ledger_transaction_tbl', 'ledger_transaction_tbl.trans_no = invoice_type_transaction.trans_no');
          $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = invoice_type_transaction.trans_no');
         $builder->where('ledger_transaction_tbl.transation_nature', $type);
         $builder->where('ledger_transaction_tbl.trans_type', $tp);
         $builder->where('invoice_type_transaction.trans_no', $id);
       $builder->where('invoice_type_transaction.transaction_type_id',$tp);
         // $builder->where('ledger_transaction_tbl.name_type_id',1);
         //   $builder->where('ledger_transaction_tbl.name_id',$nameid);
            $builder->where('transaction_numbers_tbl.trans_type_id',$tp);
        $result = $builder->get()->getResult();
        return $result;   
         }

          function get_transaction2($id,$type,$nameid,$tp) {
        $builder = $this->db->table('invoice_type_transaction');
        $builder->select('*');
         $builder->join('ledger_transaction_tbl', 'ledger_transaction_tbl.trans_no = invoice_type_transaction.trans_no');
          $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = invoice_type_transaction.trans_no');
         $builder->where('ledger_transaction_tbl.transation_nature', $type);
         $builder->where('ledger_transaction_tbl.trans_type', $tp);
         $builder->where('invoice_type_transaction.trans_no', $id);
       $builder->where('invoice_type_transaction.transaction_type_id',$tp);
         $builder->where('ledger_transaction_tbl.trans_item',0);
         $builder->where('ledger_transaction_tbl.ledger_type!=',7);
         $builder->where('ledger_transaction_tbl.ledger_id!=',22);
         
            $builder->where('transaction_numbers_tbl.trans_type_id',$tp);
               $builder->groupBy('ledger_transaction_tbl.trans_no');
        $result = $builder->get()->getResult();
        return $result;   
         }

      function get_account_name($trno,$type){
     $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('account_name');
          $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
         $builder->where('ledger_transaction_tbl.trans_type', $type);
         $builder->where('ledger_transaction_tbl.name_type_id', 5);
          $builder->where('ledger_transaction_tbl.trans_no', $trno);
         $result = $builder->get()->getResult();
        return $result; 
        }
          function get_transactionapp($id) {
        $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('*');
          $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
         $builder->where('ledger_transaction_tbl.ledger_id', 9);
        // $builder->where('ledger_transaction_tbl.ledger_id!=', 22);
         $builder->where('ledger_transaction_tbl.name_id', $id);
         $result = $builder->get()->getResult();
        return $result;   
         }
         public function get_applicationid($sid){
        $builder = $this->db->table('students_application_tbl');
        $builder->select('*');
        // $builder->join('ledger_transaction_tbl', 'ledger_transaction_tbl.name_id = students_application_tbl.students_ID');
        // $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
        $builder->where('students_ID', $sid);
         //$builder->where('ledger_transaction_tbl.ledger_id', 9);
          //$builder->where('ledger_transaction_tbl.name_id', $sid);
         $result = $builder->get()->getResult();
        return $result; 
         }
   function get_invoicetype($id){
            $builder = $this->db->table('invoice_types_tbl');
        $builder->select('*');
        $builder->where('id', $id);
        $result = $builder->get()->getResult();
        return $result; 
         }
   public function insert_payment($data){
    $query = $this->db->table('ledger_transaction_tbl')->insert($data);
    return $query;
}  
function gettable_stdetail($id) {
   $builder = $this->db->table('admission_tbl');
        $builder->select('admission_tbl.id,date_joined,admission_tbl.class_id,admission_tbl.level_id,admission_tbl.stream_id,class_name,level_name,stream_name');
         $builder->join('classes_tbl', 'classes_tbl.id = admission_tbl.class_id');
         $builder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id');
         $builder->join('streams_tbl', 'streams_tbl.id = admission_tbl.stream_id');
       $builder->where('admission_tbl.student_id', $id);
       $builder->orderBy('admission_tbl.id', "DESC");
      $result = $builder->get()->getResult();
        return $result;  
}   
 function gettable_prdetail($id){
  $builder = $this->db->table('parents_tbl');
        $builder->select('first_name,last_name,phone1,email,address');
       $builder->where('id', $id);
       $builder->where('bill_account', 1);
        $result = $builder->get()->getResult();
        return $result;  
 }
 function get_student_recept($id){
$builder = $this->db->table('ledger_transaction_tbl');
        // $builder->select('CONCAT(first_name," ",middle_name," ",last_name) as full_name,trans_no,amount as amount,balance as balance,trans_date,ledger_transaction_tbl.ledger_id,invoice_types_tbl.type_name');
   $builder->select('ledger_id,invoice_type_transaction.trans_no,invoice_types_tbl.type_name,students.full_name,transaction_numbers_tbl.trans_date,amount,balance');
        $builder->join('invoice_type_transaction','invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no');
         $builder->join('students', 'students.id = ledger_transaction_tbl.name_id');
         $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
         
    $builder->join('invoice_types_tbl', 'invoice_types_tbl.id = invoice_type_transaction.invoice_type_id');
       $builder->where('ledger_transaction_tbl.name_id', $id);
       $builder->where('ledger_transaction_tbl.name_type_id', 1);
       $builder->where('ledger_transaction_tbl.ledger_type', 7);
       $builder->where('ledger_transaction_tbl.trans_type', 1);
       $builder->where('ledger_transaction_tbl.balance >0');
        $builder->where('invoice_type_transaction.transaction_type_id',1);
        $builder->where('transaction_numbers_tbl.trans_type_id',1);
        $builder->groupBy('ledger_transaction_tbl.trans_no');
      $result = $builder->get()->getResult();
        return $result;
 }
 function select_inv_id($trno){
    $builder = $this->db->table('invoice_type_transaction');
        $builder->select('*');
       $builder->where('trans_no', $trno);
       $builder->where('transaction_type_id',1);
      $result = $builder->get()->getResult();
        return $result;    
 }    
 public function get_level_details(){
    $builder = $this->db->table('class_level_tbl');
        $builder->select('*');
       $result = $builder->get()->getResult();
        return $result; 
 }
 
 public function get_class_details(){
    $builder = $this->db->table('classes_tbl');
        $builder->select('*');
        //$builder->join('class_level_tbl','class_level_tbl.id=classes_tbl.class_level');
        //$builder->orderBy('class_level_tbl.id','ASC');
       $result = $builder->get()->getResult();
        return $result; 
 }
  public function get_class_det($id){
    $builder = $this->db->table('classes_tbl');
        $builder->select('*');
        $builder->where('id',$id);
       $result = $builder->get()->getResult();
        return $result; 
 }
public function total_level_students($lv,$tbl,$col,$year){
    $builder = $this->db->table($tbl);
        $builder->select('*');
        $builder->where($col, $lv);
        $builder->like($tbl.'.date_created',$year,'after');
       $result = $builder->get()->getResult();
        return $result;
 }
 
 public function total_level_admission($lv,$tbl,$col,$year){
    $builder = $this->db->table($tbl);
        $builder->select('*');
        $builder->where($col, $lv);
        $builder->like($tbl.'.academic_year',$year,'after');
       $result = $builder->get()->getResult();
        return $result;
 }
  public function total_selected_students($lv,$dt,$col,$year){
    $builder = $this->db->table('students_application_tbl');
        $builder->select('*');
        if($lv==1){
        $builder->where($col, $lv);
          }
        $builder->like('students_application_tbl.date_created',$year,'after');
       $result = $builder->get()->getResult();
        return $result;
 }
 public function selection_report($classid,$status){
        $builder = $this->db->table('students_application_tbl');
        $builder->select('students_application_tbl.id,students_application_tbl.gender,students_application_tbl.full_name,students_application_tbl.date_created,classes_tbl.class_name,students_application_tbl.date_of_birth');
         $builder->join('classes_tbl', 'classes_tbl.id = students_application_tbl.class');
         $builder->where('students_application_tbl.class', $classid);
         $builder->where('students_application_tbl.selection_status', $status);
         $result = $builder->get()->getResult();
        return $result; 
 }
 public function selection_student($id,$s){
     $builder = $this->db->table('students_application_tbl');
           $builder->set('selection_status', $s)
                 ->where('id', $id)
                  ->update();
        return $builder;
 }
  public function total_gender_admission($lv,$dt,$col,$year){
    $builder = $this->db->table('admission_tbl');
        $builder->select('*');
        $builder->join('students', 'students.id = admission_tbl.student_id');
          $builder->where($col, $lv);
          $builder->where('admission_tbl.academic_year',$year);
       $result = $builder->get()->getResult();
        return $result;
 }
   public function total_gender_admission2($lv,$dt,$col){
    $builder = $this->db->table('students');
        $builder->select('*');
         $builder->where($col, $lv);
       $result = $builder->get()->getResult();
        return $result;
 }
  public function total_contNew_admission($type,$col,$year){
    $builder = $this->db->table('admission_tbl');
        $builder->select('*');
       $builder->where($col, $type);
        $builder->where('admission_tbl.academic_year',$year);
       $result = $builder->get()->getResult();
        return $result;
 }
public function total_admision_collection($year)
       {
          $builder = $this->db->table('ledger_transaction_tbl');
          $builder->selectSum('amount');
           $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
          $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
         $builder->where('ledger_id!=9');
         $builder->where('transation_nature=2');
         $builder->where('trans_type=1');
          return $builder->get()->getResult();

       }
          public function total_admision_collected($year)
       {
         $builder = $this->db->table('ledger_transaction_tbl');
          $builder->selectSum('amount');
           $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
          $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
          $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no');
         $builder->where('invoice_type_transaction.transaction_type_id',2);
         $builder->where('invoice_type_transaction.invoice_type_id',2);
         $builder->where('ledger_transaction_tbl.ledger_id!=',22);
         //$builder->where('transation_nature=1');
            $builder->where('ledger_transaction_tbl.transation_nature',1);
          $builder->where('trans_type=2');
          $builder->where('ledger_id!=9');
          return $builder->get()->getResult();
       }
       
    public function total_religion_details($lv,$col){
    $builder = $this->db->table('students');
        $builder->select('*');
         $builder->where($col, $lv);
       $result = $builder->get()->getResult();
        return $result;
 }
 
  public function get_nationality_details(){
    $builder = $this->db->table('nationalities');
        $builder->select('*');
       $result = $builder->get()->getResult();
        return $result;
 }
  function load_customerGroup_sales(){
       $builder = $this->db->table('parents_tbl');
        $builder->select('count(id) as id,relation');
       $result = $builder->get()->getResult();
        return $result;  
    }
     function get_max_deposit($tbl,$col){
  $builder = $this->db->table($tbl);
$builder->select('trans_number');
$builder->where('trans_type_id', 3);
$builder->like($col, "DEP", 'after');

// Use raw SQL for correct sorting
//$builder->orderBy("CAST(SUBSTRING($col, 4) AS UNSIGNED)", 'DESC');

return $builder->get()->getResult();
  }
  function select_student_recept($id,$trans){
$builder = $this->db->table('ledger_transaction_tbl');
       $builder->select('ledger_id,invoice_type_transaction.trans_no,invoice_types_tbl.type_name,students.full_name,transaction_numbers_tbl.trans_date,amount,balance');
        $builder->join('invoice_type_transaction','invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no');
         $builder->join('students', 'students.id = ledger_transaction_tbl.name_id');
         $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
         
          $builder->join('invoice_types_tbl', 'invoice_types_tbl.id = invoice_type_transaction.invoice_type_id');
       $builder->where('ledger_transaction_tbl.name_id', $id);
       $builder->where('ledger_transaction_tbl.name_type_id', 1);
       $builder->where('ledger_transaction_tbl.ledger_type', 7);
       $builder->where('ledger_transaction_tbl.trans_type', 1);
       
        $builder->where('invoice_type_transaction.transaction_type_id',1);
        $builder->where('transaction_numbers_tbl.trans_type_id',1);
        //$builder->where('ledger_transaction_tbl.trans_no',$trans);
        $builder->groupBy('ledger_transaction_tbl.trans_no');
      $result = $builder->get()->getResult();
        return $result;
 }
 function get_max_note($tbl,$col){
     $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    $builder->where('trans_type_id', 6);
    return $builder->get()->getResult();
  }
   function gettable_parent($id){
    $builder = $this->db->table('parents_students_tbl');
    $builder->select('parents_tbl.id,first_name,last_name,full_name,occupation,address,phone1,email,postal_address');
    $builder->join('parents_tbl', 'parents_tbl.id = parents_students_tbl.parent_id');
    $builder->where('parents_students_tbl.student_id',$id);
   // $builder->where('bill_account',1);
    return $builder->get()->getResult();
 } 
 function get_student_credits($in){
   $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('*');
    $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no');
     $builder->join('invoice_types_tbl', 'invoice_types_tbl.id= invoice_type_transaction.invoice_type_id');
       // $builder->join('accounts_tbl', 'accounts_tbl.id= ledger_transaction_tbl.ledger_id');
      $builder->wherein('ledger_transaction_tbl.trans_no',$in);
       $builder->where('invoice_type_transaction.transaction_type_id', 6);
       $builder->where('ledger_transaction_tbl.trans_type', 6);
       $builder->where('ledger_transaction_tbl.transation_nature', 1);
       $builder->where('ledger_transaction_tbl.ledger_type', 7);
       //$builder->where('ledger_transaction_tbl.balance >', 0);
         $result = $builder->get()->getResult();
        return $result;    
 }
 function get_student_overpayed($nameId){
   $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('*');
    $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no');
     $builder->join('invoice_types_tbl', 'invoice_types_tbl.id= invoice_type_transaction.invoice_type_id');
       // $builder->join('accounts_tbl', 'accounts_tbl.id= ledger_transaction_tbl.ledger_id');
     
       $builder->where('invoice_type_transaction.transaction_type_id', 2);
       $builder->where('ledger_transaction_tbl.name_id', $nameId);
       $builder->where('ledger_transaction_tbl.trans_item >', 0);
       $builder->where('ledger_transaction_tbl.ledger_id', 21);
      // $builder->where('ledger_transaction_tbl.balance >', 0);
         $result = $builder->get()->getResult();
        return $result;    
 }
function get_student_deposit($in){
   $builder = $this->db->table('ledger_transaction_tbl');
        $builder->select('*');
    $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no');
     $builder->join('invoice_types_tbl', 'invoice_types_tbl.id= invoice_type_transaction.invoice_type_id');
       // $builder->join('accounts_tbl', 'accounts_tbl.id= ledger_transaction_tbl.ledger_id');
      $builder->wherein('ledger_transaction_tbl.trans_no',$in);
       $builder->where('invoice_type_transaction.transaction_type_id', 3);
       $builder->where('ledger_transaction_tbl.trans_type', 3);
       $builder->where('ledger_transaction_tbl.transation_nature', 2);
       $builder->where('ledger_transaction_tbl.ledger_type', 9);
       //$builder->where('ledger_transaction_tbl.balance >', 0);
         $result = $builder->get()->getResult();
        return $result;    
 }
 function get_item_name($tbl,$condition){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
    $query = $builder->get()->getResult();
      return $query;
 }
 function check_student_inapplication($tbl,$fname,$mname,$lname,$class){
    $builder = $this->db->table($tbl);
    $builder->select('');
    $builder->where('first_name',$fname);
    $builder->where('middle_name',$mname);
    $builder->where('last_name',$lname);
    $builder->where('class',$class);
    $query = $builder->get()->getResult();

    return $query; 
}

function get_max_reversal($tbl,$col,$type){
     $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    $builder->where('trans_type_id', $type);
    return $builder->get()->getResult();
  }
   function get_student_list($class,$status){
       $builder = $this->db->table('students');
    $builder->select('');
    if($class>0 && $status>0){
       $builder->where('initial_class',$class); 
       $builder->where('status',$status); 
    }elseif ($class<0 && $status==0) {
        $builder->where('initial_class',0); 
    }elseif ($class <0 && $status >0) {
        $builder->where('initial_class',0);
        $builder->where('status',$status);  
    }elseif ($class ==0 && $status >0) {
        $builder->where('status',$status);  
    }elseif ($class >0 && $status ==0) {
         $builder->where('initial_class',$class);  
    }
    
    $query = $builder->get()->getResult();

    return $query;  
  }
  
   function gettable_data_groupBy($tbl,$id,$col){
     $query = $this->db->table($tbl);
     $query->select('*');
     $query->where($id);
     $query->groupBy($col);
     return $query->get()->getResult();
 }
 function gettable_dataDes($tbl,$id){
     $query = $this->db->table($tbl);
     $query->select('*');
     $query->where($id);
     $query->orderBy('id', 'DESC');
     return $query->get()->getResult();
 }
 
 public function get_total_admision_collection($tbl,$dt,$year)
       {
          $builder = $this->db->table($tbl);
           $builder->select("amount,trans_number");
         $builder->where('ledger_id!=9');
         $builder->where('ledger_id!=22');
         $builder->where('transation_nature=2');
         $builder->where('trans_type=1');
         $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
           $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no');
         $builder->where('invoice_type_transaction.transaction_type_id',1);
         $builder->where('invoice_type_transaction.invoice_type_id',2);
          $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
          $builder->groupBy('transaction_numbers_tbl.trans_number');
        // $builder->limit(1);
          return $builder->get()->getResult();

       }
       
       function gettable_specific_data($tbl,$id,$data){
     $query = $this->db->table($tbl);
     $query->select($data);
     $query->where($id);
     return $query->get()->getResult();
 }
 
 function delete_application_data($appid){

    $this->db->transStart();

    $builder = $this->db->table('students_application_tbl');
    $builder->where('id',$appid);
    $builder->delete();

     $builder = $this->db->table('temp_item_transation_tbl');
    $builder->where('student_id',$appid);
    $builder->delete();

     $this->db->transComplete();

    
    if ($this->db->transStatus() === FALSE) {
         $this->db->transRollback();
        return false;
    }

    $this->db->close();
    return true;
 }

 function delete_reference($ref){
    $builder = $this->db->table('payment_request');
    $builder->where('reference_no',$ref);
    $builder->delete();
    $this->db->close();
 }
  
   function get_student_byname($names,$ttl){
       $query = $this->db->table('students');
    $query->select('');
     if($ttl==1){
      $query->like('students.first_name',$names[0],'both');
    }
     if($ttl==2){
      $query->like('students.first_name',$names[0],'both');
      $query->like('students.middle_name',$names[1],'both');
    }
    if($ttl==3){
      $query->like('students.first_name',$names[0],'both');
      $query->like('students.middle_name',$names[1],'both');
      $query->like('students.last_name',$names[2],'both');
    }
    
    $query = $query->get()->getResult();

    return $query;  
  }
  
    function admission_byname($names,$ttl,$year){
    $query = $this->db->table('admission_tbl');
    $query->select('admission_tbl.*');
  
     $query->join('students', 'students.id = admission_tbl.student_id');
     $query->where('admission_tbl.academic_year', $year);
     $query->where('admission_tbl.status', 1);
    $query->orderBy('students.full_name','ASC');
    if($ttl==1){
      $query->like('students.first_name',$names[0],'both');
    }
     if($ttl==2){
      $query->like('students.first_name',$names[0],'both');
      $query->like('students.middle_name',$names[1],'both');
    }
    if($ttl==3){
      $query->like('students.first_name',$names[0],'both');
      $query->like('students.middle_name',$names[1],'both');
      $query->like('students.last_name',$names[2],'both');
    }
     
     
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;

   }
   
    function payments_requirements($tbl,$id){
    $this->db=\Config\Database::connect();
     $query = $this->db->table($tbl);
     $query->select('*');
     $query->where($id);
     return $query->get()->getResult();
 
   }
   
   public function get_classes_bylevel(){
    $builder = $this->db->table('classes_tbl');
        $builder->select('class_level,count(id) as id');
         $builder->groupBy('class_level');
       $result = $builder->get()->getResult();
        return $result; 
 }


  function get_max_payroll($tbl,$col){
     $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    $builder->where('trans_type_id', 10);
    return $builder->get()->getResult();
  }
    function get_max_payroll_payment($tbl,$col){
     $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    $builder->where('trans_type_id', 5);
    return $builder->get()->getResult();
  }
 function get_max_payroll_id($tbl,$col){
     $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    $builder->where('transaction_type_id', 10);
    return $builder->get()->getResult();
  }
      function get_max_advance_payment($tbl,$col){
     $builder = $this->db->table($tbl);
    $builder->select('MAX(CAST('.$col.' AS UNSIGNED)) AS max_id');
    $builder->where('trans_type_id', 5);
    return $builder->get()->getResult();
  }
  //endup here

}

