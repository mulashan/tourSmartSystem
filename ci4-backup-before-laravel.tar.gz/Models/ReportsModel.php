<?php

namespace App\Models;

use CodeIgniter\Model;

class ReportsModel extends Model
{
  public $db;
    public function __construct(){
      $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    }
    
function sales($name){
     $query = $this->db->table('account_types_tbl');
     $query->select('id');
     $query->where('type_name',$name);
     $result= $query->get()->getResult();
    $this->db->close();
    return $result;
 }
 function solid($solid){
     $query = $this->db->table('account_types_tbl');
     $query->select('id');
     $query->where('type_name',$solid);
     $result= $query->get()->getResult();
    $this->db->close();
    return $result;
 }
 function other($other){
     $query = $this->db->table('account_types_tbl');
     $query->select('id');
     $query->where('type_name',$other);
     $result= $query->get()->getResult();
    $this->db->close();
    return $result;
 }
 
 function all_sales($saleid,$strtdate, $enddate) {
     $query = $this->db->table('ledger_transaction_tbl');
     $query->select('accounts_tbl.id,accounts_tbl.account_name,accounts_tbl.account_type_id,ledger_transaction_tbl.amount,ledger_transaction_tbl.ledger_id,ledger_transaction_tbl.ledger_type');
     $query->join('accounts_tbl','accounts_tbl.id=ledger_transaction_tbl.ledger_id');
     $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no');
    $query->where('DATE(trans_date) >=', $strtdate);
    $query->where('DATE(trans_date) <=', $enddate);
     $query->where('ledger_type',$saleid);
     $query->groupBy('ledger_id');
     $result= $query->get()->getResult();
    $this->db->close();
    return $result;
 }
 function  cost_sold($cgid,$strtdate, $enddate) {
     $query = $this->db->table('ledger_transaction_tbl');
     $query->select('accounts_tbl.id,accounts_tbl.account_name,accounts_tbl.account_type_id,ledger_transaction_tbl.amount,ledger_transaction_tbl.ledger_id,ledger_transaction_tbl.ledger_type');
     $query->join('accounts_tbl','accounts_tbl.id=ledger_transaction_tbl.ledger_id');
     $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no');
    $query->where('DATE(trans_date) >=', $strtdate);
    $query->where('DATE(trans_date) <=', $enddate);
     $query->where('ledger_type',$cgid);
     $query->groupBy('ledger_id');
    $result= $query->get()->getResult();
    $this->db->close();
    return $result;
 }
 
 function  other_income($othersid,$strtdate, $enddate) {
     $query = $this->db->table('ledger_transaction_tbl');
     $query->select('accounts_tbl.id,accounts_tbl.account_name,accounts_tbl.account_type_id,ledger_transaction_tbl. amount,ledger_transaction_tbl.ledger_id,ledger_transaction_tbl.ledger_type');
     $query->join('accounts_tbl','accounts_tbl.id=ledger_transaction_tbl.ledger_id');
     $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_type_id =                     ledger_transaction_tbl.trans_type and transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no');
    $query->where('DATE(trans_date) >=', $strtdate);
    $query->where('DATE(trans_date) <=', $enddate);
     $query->where('ledger_type',$othersid);
     $query->groupBy('ledger_id');
     $result= $query->get()->getResult();
    $this->db->close();
    return $result;
 }
  function  allofthem($ledger,$type,$strtdate, $enddate, $class_id=0) { 
    $query = $this->db->table('ledger_transaction_tbl');
  $query->select('*');
  // $query->select('amount, trans_date');

  $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_type_id = ledger_transaction_tbl.trans_type and transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
    if($class_id >0){
    $query->join('invoice_classification_tbl', 'invoice_classification_tbl.trans_id = transaction_numbers_tbl.id');
     $query->where('invoice_classification_tbl.classification_id', $class_id);
  }
  $query->where('DATE(trans_date) >=', $strtdate);
  $query->where('DATE(trans_date) <=', $enddate);
  $query->where('ledger_id', $ledger);
  $query->where('ledger_type', $type);
  $result = $query->get()->getResult();
  $this->db->close();
  return $result;
         }

   function  allofthem1($ledger1,$type,$strtdate, $enddate,$class_id=0) {
    $query = $this->db->table('ledger_transaction_tbl');
   $query->select('*');

  // $query->select('amount, trans_date');

  $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_type_id = ledger_transaction_tbl.trans_type and transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
   if($class_id >0){
    $query->join('invoice_classification_tbl', 'invoice_classification_tbl.trans_id = transaction_numbers_tbl.id');
     $query->where('invoice_classification_tbl.classification_id', $class_id);
      }
  $query->where('DATE(trans_date) >=', $strtdate);
  $query->where('DATE(trans_date) <=', $enddate);
  $query->where('ledger_id', $ledger1);
  $query->where('ledger_type', $type);
  $result = $query->get()->getResult();
  $this->db->close();
  return $result;
         }
function  allofthem2($ledger2,$type,$strtdate, $enddate) { 
  $query = $this->db->table('ledger_transaction_tbl');
    $query->select('transaction_numbers_tbl.trans_date, ledger_transaction_tbl.amount,ledger_transaction_tbl.transation_nature');

  // $query->select('amount, trans_date');
  $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_type_id = ledger_transaction_tbl.trans_type and transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
  
  $query->join('admission_tbl', 'admission_tbl.student_id = ledger_transaction_tbl.name_id');
  $query->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
  $query->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');

 
  $query->where('ledger_transaction_tbl.ledger_id', $ledger2);
  $query->where('ledger_transaction_tbl.ledger_type', $type);
  $query->where('transaction_numbers_tbl.trans_date >=', $strtdate);
  $query->where('transaction_numbers_tbl.trans_date <=', $enddate);

 $query->groupBy('ledger_transaction_tbl.trans_no');

  $query = $query->get();
  return $query->getResult();      
     }

 public function getSingle_view($ledgerId,$ledgertype,$strtdate, $enddate)
      {
       $builder = $this->db->table('ledger_transaction_tbl');
$builder->select('
  transaction_numbers_tbl.trans_date,
   ledger_transaction_tbl.trans_type, 
   ledger_transaction_tbl.trans_no, 
   ledger_transaction_tbl.amount, 
   ledger_transaction_tbl.transation_nature, 
   ledger_transaction_tbl.balance,
   transaction_types_tbl.type_name,
   ledger_transaction_tbl.name_id,
ledger_transaction_tbl.name_type_id,
   accounts_tbl.description'
  );
  
$builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_type_id = ledger_transaction_tbl.trans_type and transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
$builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
$builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');

$builder->where('DATE(trans_date) >=', $strtdate);
$builder->where('DATE(trans_date) <=', $enddate);
$builder->where('ledger_id', $ledgerId);
$builder->where('ledger_type', $ledgertype);
$result = $builder->get()->getResult();
$this->db->close();
return $result;     

}
public function getSingle_viewapp($ledgerId,$ledgertype,$strtdate, $enddate)
      {
         $query = $this->db->table('ledger_transaction_tbl');
  $query->select('   
            transaction_numbers_tbl.trans_date, 
            ledger_transaction_tbl.trans_type, 
            ledger_transaction_tbl.trans_no, 
            ledger_transaction_tbl.amount, 
            ledger_transaction_tbl.transation_nature, 
            transaction_types_tbl.type_name,
            ledger_transaction_tbl.name_id,
            ledger_transaction_tbl.name_type_id,
            accounts_tbl.description');
  $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_type_id = ledger_transaction_tbl.trans_type and transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
  $query->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
  $query->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
  
  $query->where('DATE(trans_date) >=', $strtdate);
  $query->where('DATE(trans_date) <=', $enddate);
  $query->where('ledger_id', $ledgerId);
  $query->where('ledger_type', $ledgertype);
  $result = $query->get()->getResult();
  $this->db->close();
  return $result;    
}
function groupedby($trans_no,$type,$id){
  $query = $this->db->table('ledger_transaction_tbl');
    $query->select('amount');
     $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_type_id =                     ledger_transaction_tbl.trans_type and transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no');
      $query->join('admission_tbl', 'admission_tbl.student_id = ledger_transaction_tbl.name_id');
      $query->join('students', 'students.id=admission_tbl.student_id');
      $query->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
    $query->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
    $query->where('trans_no',$trans_no);
    $query->where('ledger_type',$type);
    $query->where('ledger_id',$id);
    // $query->where('transaction_numbers_tbl.trans_type_id',1);
    $result= $query->get()->getResult();
    $this->db->close();
    return $result; 
}
function get_paymode(){
  $query = $this->db->table('transaction_types_tbl');
    $query->select('*');
   $result= $query->get()->getResult();
   $this->db->close();
    return $result; 
}
function cashcollcted_repts($ledgerId,$ledgertype,$strtdate, $enddate,$paymode) {
        
   $builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('
        transaction_numbers_tbl.trans_date,
         ledger_transaction_tbl.trans_type, 
         ledger_transaction_tbl.trans_no, 
         ledger_transaction_tbl.amount, 
         ledger_transaction_tbl.transation_nature, 
         ledger_transaction_tbl.balance,
         transaction_types_tbl.type_name,
         ledger_transaction_tbl.name_id,
         students.full_name,
         accounts_tbl.account_name,
         accounts_tbl.description'
        );
      $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no');
      $builder->join('students', 'students.id = ledger_transaction_tbl.name_id');
      $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
        $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
        $builder->where('DATE(trans_date) >=', $strtdate);
        $builder->where('DATE(trans_date) <=', $enddate);
       $builder->where('ledger_transaction_tbl.ledger_id',$ledgerId);
      $builder->where('ledger_transaction_tbl.ledger_type',$ledgertype);
            if($paymode > 0)
       $builder->where('trans_type', $paymode);
    $builder->groupBy('trans_no');
     $query = $builder->get()->getResult();
      $this->db->close();
      return $query;
    }
   function select_account($ledgerId){
     $query = $this->db->table('accounts_tbl');
    $query->select('*');
    $query->where('id',$ledgerId);
   $result= $query->get()->getResult();
   $this->db->close();
    return $result; 
 
   }
   
   function selectAllclasslevel($strtdate, $enddate){
  $query = $this->db->table('class_level_tbl');
    $query->select('class_level_tbl.id,class_level_tbl.level_name');
    $query->join('admission_tbl','admission_tbl.level_id=class_level_tbl.id');
     $query->where('DATE(date_joined) >=', $strtdate);
     $query->where('DATE(date_joined) <=', $enddate);
     $query->groupBy('level_name');
   $result= $query->get()->getResult();
   $this->db->close();
    return $result; 
}

function getclasses($level,$strtdate, $enddate){
  $query = $this->db->table('classes_tbl');
    $query->select('classes_tbl.id,classes_tbl.class_name');
    $query->join('admission_tbl','admission_tbl.class_id=classes_tbl.id');
     $query->where('DATE(date_joined) >=', $strtdate);
     $query->where('DATE(date_joined) <=', $enddate);
    $query->where('class_level',$level);
    $query->groupBy('class_id');
   $result= $query->get()->getResult();
   $this->db->close();
    return $result; 
}

function countClasses($id,$strtdate, $enddate){
  $query = $this->db->table('admission_tbl');
    $query->select('*');
    //$query->join('ledger_transaction_tbl','ledger_transaction_tbl.name_id=admission_tbl.student_id');
     $query->where('DATE(date_joined) >=', $strtdate);
     $query->where('DATE(date_joined) <=', $enddate);
     //$query->where('ledger_transaction_tbl.ledger_type',3);
    $query->where('class_id',$id);
   $result= $query->get()->getResult();
   $this->db->close();
    return $result; 
}

function get_name_id($id,$strtdate, $enddate){
  $query = $this->db->table('admission_tbl');
    $query->select('ledger_transaction_tbl.amount');
    $query->join('ledger_transaction_tbl','ledger_transaction_tbl.name_id=admission_tbl.student_id');
    $query->where('DATE(date_joined) >=', $strtdate);
     $query->where('DATE(date_joined) <=', $enddate);
    $query->where('ledger_transaction_tbl.ledger_type',3);
    $query->where('admission_tbl.class_id',$id);
   $result= $query->get()->getResult();
   $this->db->close();
    return $result; 
}
public function getSingle_class($classId,$strtdate, $enddate)
      {
        
     $query = $this->db->table('admission_tbl');
    $query->select(
        'ledger_transaction_tbl.trans_type,
        ledger_transaction_tbl.amount,
        transaction_types_tbl.type_name,
        ledger_transaction_tbl.trans_no,
        admission_tbl.date_joined,
        students.full_name'
    );
    $query->join('ledger_transaction_tbl', 'ledger_transaction_tbl.name_id =admission_tbl.student_id');
    $query->join('transaction_types_tbl', 'transaction_types_tbl.type_id =ledger_transaction_tbl.trans_type');
     $query->join('students', 'students.id = admission_tbl.student_id');
     $query->where('DATE(date_joined) >=', $strtdate);
     $query->where('DATE(date_joined) <=', $enddate);
     $query->where('ledger_transaction_tbl.ledger_type',3);
    $query->where('class_id',$classId);
    $query->groupBy('ledger_transaction_tbl.trans_no');
   $result= $query->get()->getResult();
   $this->db->close();
    return $result;

}

function getonlycname($id){
  $query = $this->db->table('classes_tbl');
    $query->select('class_name');
    
    $query->where('classes_tbl.id',$id);
   $result= $query->get()->getResult();
   $this->db->close();
    return $result; 
}

function groupedby2($no,$strtdate, $enddate){
  $query = $this->db->table('ledger_transaction_tbl');
    $query->select('ledger_transaction_tbl.amount');
    $query->join('admission_tbl','ledger_transaction_tbl.name_id=admission_tbl.student_id');
    $query->where('DATE(date_joined) >=', $strtdate);
     $query->where('DATE(date_joined) <=', $enddate);
     $query->where('ledger_transaction_tbl.ledger_type',3);
    $query->where('ledger_transaction_tbl.trans_no',$no);
   $result= $query->get()->getResult();
   $this->db->close();
    return $result; 
}

function select_date($id){
  $query = $this->db->table('transaction_numbers_tbl');
    $query->select('trans_date');
    
    $query->where('trans_number',$id);
   $result= $query->get()->getResult();
   $this->db->close();
    return $result; 
}

function get_classes1(){
  $query = $this->db->table('classes_tbl');
    $query->select('*');
    
   $result= $query->get()->getResult();
   $this->db->close();
    return $result; 
}

function get_stream1(){
  $query = $this->db->table('streams_tbl');
    $query->select('*');
     $query->limit(2);
   $result= $query->get()->getResult();
   $this->db->close();
    return $result; 
}

public function class_statements($classId,$res,$strtdate, $enddate){
   $query = $this->db->table('admission_tbl');
    $query->select('
        admission_tbl.student_id,
        admission_tbl.class_id,
        admission_tbl.hostel_id,
        admission_tbl.vehicle_id,
        admission_tbl.admission_type,
       students.full_name'
    ); 
    $query->join('ledger_transaction_tbl', 'ledger_transaction_tbl.name_id =admission_tbl.student_id');
    $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =ledger_transaction_tbl.trans_no');
     $query->join('students', 'students.id = admission_tbl.student_id');
     $query->where('DATE(date_joined) >=', $strtdate);
     $query->where('DATE(date_joined) <=', $enddate);
     if($classId > 0)
    $query->where('class_id',$classId);
    if(!$res==0){
     $query->where('admission_type',$res);
    }
     $query->groupBy('admission_tbl.student_id');
     $result= $query->get()->getResult();
     $this->db->close();
    return $result; 
}

public function class_invoice($nameId,$start,$end)
      {
        
     $query = $this->db->table('ledger_transaction_tbl');
    $query->select('
        ledger_transaction_tbl.amount');
    $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =ledger_transaction_tbl.trans_no');
     $query->where('ledger_transaction_tbl.trans_type',1);
     // $query->where('DATE(transaction_numbers_tbl.trans_date) >=', $start);
     // $query->where('DATE(transaction_numbers_tbl.trans_date) <=', $end);
    $query->where('name_id',$nameId);
    $result= $query->get()->getResult();
    $this->db->close();
    return $result;

}
/////
public function class_receipt($nameId)
      {
        
     $query = $this->db->table('ledger_transaction_tbl');
    $query->select('
        ledger_transaction_tbl.amount');
   
    $query->where('ledger_transaction_tbl.trans_type',2);
    $query->where('ledger_transaction_tbl.transation_nature',1);
    $query->groupBy('ledger_transaction_tbl.trans_no');
    $query->where('name_id',$nameId);
    $result= $query->get()->getResult();
    $this->db->close();
    return $result;

}

public function parent_number($nameId)
      {
        
     $query = $this->db->table('parents_tbl');
    $query->select('
        parents_tbl.phone1');
   $query->where('student_id',$nameId);
    $result= $query->get()->getResult();
    $this->db->close();
    return $result;

}

public function get_schoolname()
      {
        
     $query = $this->db->table('company_tbl');
    $query->select('*');
   $result= $query->get()->getResult();
   $this->db->close();
    return $result;

}

public function get_resdent()
      {
        
     $query = $this->db->table('admission_tbl');
    $query->select('admission_type');
   $result= $query->get()->getResult();
   $this->db->close();
    return $result;

}

function student_collection($stid,$sdate,$enddate){
  $query = $this->db->table('ledger_transaction_tbl');
    $query->select('ledger_transaction_tbl.amount,
                    transaction_numbers_tbl.trans_date,
                    transaction_numbers_tbl.trans_number,
                    transaction_types_tbl.type_name,
                    accounts_tbl.account_name,
                    students.full_name,accounts_tbl.account_name
                   ');
    $query->join('students','students.id=ledger_transaction_tbl.name_id');
    $query->join('transaction_types_tbl','transaction_types_tbl.type_id=ledger_transaction_tbl.trans_type');
    $query->join('accounts_tbl','accounts_tbl.id=ledger_transaction_tbl.ledger_id');
    $query->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
    $query->where('ledger_transaction_tbl.trans_type',2);
    $query->where('ledger_transaction_tbl.transation_nature',1);
    // $query->where('DATE(transaction_numbers_tbl.trans_date) <=', $sdate);
    //  $query->where('DATE(transaction_numbers_tbl.trans_date) >=', $enddate);
    $query->where('ledger_transaction_tbl.name_id',$stid);
    $query->groupBy('ledger_transaction_tbl.trans_no');
   $result= $query->get()->getResult();
   $this->db->close();
    return $result; 
}

public function studentname($nameId)
      {
        
     $query = $this->db->table('students');
    $query->select('full_name');
    $query->where('id',$nameId);
   $result= $query->get()->getResult();
   $this->db->close();
    return $result;

}

public function get_levels()
      {
        
     $query = $this->db->table('class_level_tbl');
    $query->select('*');
    $result= $query->get()->getResult();
    $this->db->close();
    return $result;

}
public function get_hostels()
      {
        
    $query = $this->db->table('hostel_tbl');
    $query->select('*');
    $result= $query->get()->getResult();
    $this->db->close();
    return $result;

}
function boarding_list2($hostel,$class,$classlevel,$year){
    $query = $this->db->table('admission_tbl');
    $query->select('
        students.birth_date,
        admission_tbl.id,
        students.gender,
        students.student_id,
        classes_tbl.class_name,
        class_level_tbl.level_name,
       students.full_name'
    ); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
     $query->join('students', 'students.id = admission_tbl.student_id');
     $query->where('admission_tbl.academic_year', $year);
     $query->where('students.status', 2);
     if($hostel > 0 && $class >0 && $classlevel>0){
     $query->where('admission_tbl.hostel_id', $hostel);
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
    }
    elseif($hostel == 0 && $class >0 && $classlevel>0){
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
    }
elseif($hostel == 0 && $class ==0 && $classlevel>0){
    $query->where('admission_tbl.level_id', $classlevel);
    }
    elseif($hostel > 0 && $class >0 && $classlevel==0){
     $query->where('admission_tbl.hostel_id', $hostel);
     $query->where('admission_tbl.class_id', $class);
     }
     elseif($hostel > 0 && $class ==0 && $classlevel==0){
     $query->where('admission_tbl.hostel_id', $hostel);
    
     }
     elseif($hostel == 0 && $class >0 && $classlevel==0){
     $query->where('admission_tbl.class_id', $class);
     }
     elseif($hostel > 0 && $class ==0 && $classlevel>0){
     $query->where('admission_tbl.hostel_id', $hostel);
     $query->where('admission_tbl.level_id', $classlevel);
     }
      $query->where('admission_tbl.admission_type', '3');
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }

   function get_hostelname($hostel){
   $query = $this->db->table('hostel_tbl');
    $query->select('*');
    $query->where('id', $hostel);
    $result= $query->get()->getResult();
    $this->db->close();
    return $result;
   }
   
   function class_list21($class,$classlevel,$stream,$year,$status){
        $query = $this->db->table('class_list_view');
    $query->select('*'); 
    // $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    // $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
    // $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
    //  $query->join('students', 'students.id = admission_tbl.student_id');
     if($class >0 && $classlevel>0 && $stream==0){
    
     $query->where('class_list_view.class_id', $class);
     $query->where('class_list_view.level_id', $classlevel);
     if($status>0){
      $query->where('class_list_view.status', $status);
     }
    }
    elseif($class ==0 && $classlevel>0 && $stream==0){
     
     $query->where('class_list_view.level_id', $classlevel);
     if($status>0){
      $query->where('class_list_view.status', $status);
     }
    }
elseif($class >0 && $classlevel==0 && $stream==0){
    $query->where('class_list_view.class_id', $class);
    if($status>0){
      $query->where('class_list_view.status', $status);
     }
    }
elseif($class >0 && $classlevel>0 && $stream>0){
    
     $query->where('class_list_view.stream_id', $stream);
     $query->where('class_list_view.class_id', $class);
     $query->where('class_list_view.level_id', $classlevel);
     if($status>0){
      $query->where('class_list_view.status', $status);
     }
    }
    elseif($class >0 && $classlevel==0 && $stream>0){
    
     $query->where('class_list_view.stream_id', $stream);
     $query->where('class_list_view.class_id', $class);
     if($status>0){
      $query->where('class_list_view.status', $status);
     }
    }
    elseif($class==0 && $classlevel==0 && $stream>0){
    
     $query->where('class_list_view.stream_id', $stream);
   if($status>0){
      $query->where('class_list_view.status', $status);
     }
     
    }
    if($status>0){
      $query->where('class_list_view.status', $status);
     }
    $query->where('class_list_view.academic_year', $year);
   $query->orderBy('class_list_view.full_name','ASC');
      
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
       function class_list2($class,$classlevel,$stream,$year,$status){
               if($status=='2'){
      $status=1;
     
     }
    else if($status=='1'){
      $status=2;
     }
    $query = $this->db->table('admission_tbl');
    $query->select('
        students.birth_date,
        students.id,
        admission_tbl.date_joined,
        admission_tbl.class_id,
        admission_tbl.level_id,
        admission_tbl.academic_year,
        admission_tbl.admission_type,
        admission_tbl.adimit_for,
        students.gender,
        students.student_id,
        classes_tbl.class_name,
        streams_tbl.stream_name,
        class_level_tbl.level_name,
       students.full_name,
       admission_tbl.status,
       students.first_name,'
    ); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
    $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
     $query->join('students', 'students.id = admission_tbl.student_id');
    
     if($class >0 && $classlevel>0 && $stream==0){
    
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
     if($status>0){
      $query->where('admission_tbl.status', $status);
     }
    }
    elseif($class ==0 && $classlevel>0 && $stream==0){
     
     $query->where('admission_tbl.level_id', $classlevel);
     if($status>0){
     $query->where('admission_tbl.status', $status);
     }
    }
elseif($class >0 && $classlevel==0 && $stream==0){
    $query->where('admission_tbl.class_id', $class);
    if($status>0){
     $query->where('admission_tbl.status', $status);
     }
    }
elseif($class >0 && $classlevel>0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
     if($status>0){
      $query->where('admission_tbl.status', $status);
     }
    }
    elseif($class >0 && $classlevel==0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
     $query->where('admission_tbl.class_id', $class);
     if($status>0){
      $query->where('admission_tbl.status', $status);
     }
    }
    elseif($class==0 && $classlevel==0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
   if($status>0){
      $query->where('admission_tbl.status', $status);
     }
     
    }
    if($status>0){
     $query->where('admission_tbl.status', $status);
     }
    $query->where('admission_tbl.academic_year', $year);
   $query->orderBy('students.full_name','ASC');
      
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }

    public function calculateDifference($class,$classlevel,$stream,$stid)
    {
      $query = $this->db->table('ledger_transaction_tbl');
        $query->select('students.birth_date,
        students.id,
        admission_tbl.date_joined,
        students.gender,
        students.student_id,
        classes_tbl.class_name,
        streams_tbl.stream_name,
        class_level_tbl.level_name,
       students.full_name, 
        SUM(CASE WHEN (ledger_transaction_tbl.ledger_type =3 OR ledger_transaction_tbl.ledger_type = 4
        AND ledger_transaction_tbl.trans_type=1) THEN ledger_transaction_tbl.amount ELSE 0 END) - 
                               SUM(CASE WHEN
                                ledger_transaction_tbl.transation_nature = 1 
                                AND ledger_transaction_tbl.trans_type = 2 
                                AND ledger_transaction_tbl.name_type_id = 1 
                                THEN ledger_transaction_tbl.amount ELSE 0 END) as difference');
     $query->join('admission_tbl', 'admission_tbl.student_id=ledger_transaction_tbl.name_id');
      $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
    $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
     $query->join('students', 'students.id = admission_tbl.student_id');
     $query->where('ledger_transaction_tbl.name_id', $stid);
     if($class >0 && $classlevel>0 && $stream==0){
    
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
    }
    elseif($class ==0 && $classlevel>0 && $stream==0){
     
     $query->where('admission_tbl.level_id', $classlevel);
    }
elseif($class >0 && $classlevel==0 && $stream==0){
    $query->where('admission_tbl.class_id', $class);
    }
elseif($class >0 && $classlevel>0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
    }
    elseif($class >0 && $classlevel==0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
     $query->where('admission_tbl.class_id', $class);
     
    }
    elseif($class==0 && $classlevel==0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
   } 
    $query->orderBy('difference', 'desc'); // Sort by difference in descending order
       $result= $query->get()->getResult();
      $this->db->close();
        return $result;
    }

public function get_route()
      {
   $query = $this->db->table('vehicles_list_tbl');
    $query->select('');
   $result= $query->get()->getResult();
   $this->db->close();
    return $result;

}

function route_list2($vno,$class){
    $query = $this->db->table('admission_tbl');
    $query->select('*'); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('students', 'students.id = admission_tbl.student_id');
    $query->join('transport_details', 'transport_details.student_id =students.id');
     $query->join('station_session_tbl', 'station_session_tbl.station_id = transport_details.pickup_station');
    $query->join('route_tbl', 'route_tbl.id =station_session_tbl.route_id');
     if($class >0 && $vno>0 ){
     
     $query->where('route_tbl.vehicle', $vno);
     $query->where('admission_tbl.class_id', $class);
     }
    elseif($vno==0 && $class >0){
     $query->where('admission_tbl.class_id', $class);
    }

    elseif($vno >0 && $class==0){
     //$query->where('admission_tbl.vehicle_id', $vid);
       $query->where('route_tbl.vehicle', $vno);
    }
   
      $query->groupBy('transport_details.student_id');
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
   
   public function route_vehicle($vname,$vno)
      {
        
     $query = $this->db->table('vehicles_tbl');
    $query->select('vehicle_id');
if($vname>0 && $vno>0)
    {
    $query->where('vehicle_name',$vname);
    $query->where('vehicle_number',$vno);
    }
if($vname==0 && $vno>0)
    {
    $query->where('vehicle_number',$vno);
    }
elseif($vname>0 && $vno==0)
    {
    $query->where('vehicle_name',$vname);
    }
   $result= $query->get()->getResult();
   $this->db->close();
    return $result;

}
function get_parent($stid){
$builder = $this->db->table('parents_tbl');
    $builder->select('*');
    $builder->where('student_id',$stid);
    
    $query = $builder->get()->getResult();
    $this->db->close();
    return $query;
    }
    
    function get_driver_detail($d){
$builder = $this->db->table('users');
    $builder->select('*');
    $builder->where('user_id',$d);
    
    $query = $builder->get()->getResult();
    $this->db->close();
    return $query;
    }
    function get_stream($tbl,$id){
     $query = $this->db->table($tbl);
     $query->select('*');
     $query->where($id);
     return $query->get()->getResult();
 }
    public function save_attendance_list($data)
    {
        $query = $this->db->table('attendance_list_tbl')->insert($data);
        if($query){
            return $this->db->insertID();
        }
        else{
            return 0;
        }
       
    }
    public function attendance_record($record)
    {
      
            $builder = $this->db->table('attendance_record')->insert($record);
            $this->db->close();
    }

    function sess_exit($cid,$stid,$sess,$date){
        $builder = $this->db->table('attendance_list_tbl');
      $builder->select('*');
     $builder->where('attendance_list_tbl.date_taken', $date);
     $builder->where('attendance_list_tbl.time_taken', $sess);
     $builder->where('attendance_list_tbl.class_id', $cid);
     $builder->where('attendance_list_tbl.stream_id', $stid);
     $query = $builder->get()->getResult();
     $this->db->close();
    return $query;
    }

    function edit_attendance_list($data,$attendance_id){
        $builder = $this->db->table('attendance_list_tbl');
            $builder->where('id',$attendance_id);
            $builder->update($data);
            $this->db->close();
          return 1;
    }
    
    function attendance_record_edit($studentid,$attendance_id,$type){
        $builder = $this->db->table('attendance_record');
           $builder->set('type', $type)
                  ->where('attendance_id', $attendance_id)
                  ->where('student_id', $studentid)
                  ->update();
                  $this->db->close();
        return $builder;

    }
    function getTotaldays($cid,$lid,$stu_id,$sdate,$enddate,$sess){
        $builder = $this->db->table('attendance_list_tbl');
    $builder->select('attendance_record.student_id,attendance_record.id,attendance_id,attendance_record.type,students.first_name,students.middle_name,students.last_name');
    $builder->join('attendance_record','attendance_record.attendance_id=attendance_list_tbl.id');
    $builder->join('students','students.id=attendance_record.student_id');
  
    $builder->where('attendance_list_tbl.class_id',$cid);
    $builder->where('attendance_list_tbl.stream_id',$lid);
    $builder->where('attendance_record.student_id',$stu_id);
    //$builder->where('attendance_list_tbl.date_taken',$doc);
    //$builder->like('attendance_list_tbl.date_taken', date('Y-m-d', $sdate));
     $builder->where('DATE(date_taken) >=',  $sdate);
    $builder->where('DATE(date_taken) <=', $enddate);
    if($sess!=0){
    $builder->where('attendance_list_tbl.time_taken',$sess);
      }
      
     $result=$builder->get()->getResult();
     $this->db->close();
     return $result;
    }

    function select_attendance_class($sdate,$enddate,$sess){
     $builder = $this->db->table('attendance_list_tbl');
    $builder->select('');
    //$builder->join('classes_tbl','classes_tbl.id=class_name.class_id');
    $builder->where('DATE(date_taken) >=',  $sdate);
    $builder->where('DATE(date_taken) <=', $enddate);
    if($sess!=0){
    $builder->where('attendance_list_tbl.time_taken',$sess);
      }
      $builder->groupBy('class_id');
     $result=$builder->get()->getResult();
     $this->db->close();
     return $result;
    }

    function get_stream_attendance($cid,$sdate,$enddate,$sess){
 $builder = $this->db->table('attendance_list_tbl');
    $builder->select('attendance_list_tbl.id,attendance_list_tbl.stream_id,streams_tbl.stream_name');
    $builder->join('streams_tbl','streams_tbl.id=attendance_list_tbl.stream_id');
    $builder->where('attendance_list_tbl.class_id',  $cid);
    $builder->where('DATE(date_taken) >=',  $sdate);
    $builder->where('DATE(date_taken) <=', $enddate);
    if($sess!=0){
    $builder->where('attendance_list_tbl.time_taken',$sess);
      }
      $builder->groupBy('stream_id');
     $result=$builder->get()->getResult();
     $this->db->close();
     return $result;
    }

    function count_attendance($cid,$stid,$sdate,$enddate,$sess){
   $builder = $this->db->table('attendance_list_tbl');
    $builder->select('attendance_record.attendance_id,attendance_record.type');
    $builder->join('attendance_record','attendance_record.attendance_id=attendance_list_tbl.id');
    $builder->where('attendance_list_tbl.class_id',  $cid);
    $builder->where('attendance_list_tbl.stream_id',  $stid);
    $builder->where('DATE(date_taken) >=',  $sdate);
    $builder->where('DATE(date_taken) <=', $enddate);
    if($sess!=0){
    $builder->where('attendance_list_tbl.time_taken',$sess);
      }
     
     $result=$builder->get()->getResult();
     $this->db->close();
     return $result;
    }
    function classes_att($cid){
$builder = $this->db->table('classes_tbl');
$builder->select('');
$builder->where('id',$cid);
 $result=$builder->get()->getResult();
     $this->db->close();
     return $result;
    }

   function checkTerm($todate){
    $builder = $this->db->table('school_terms_tbl');
    $builder->select('');
    $builder->where('DATE(start_date) <=',  $todate);
    $builder->where('DATE(end_date) >=', $todate);
     $result=$builder->get()->getResult();
     $this->db->close();
     return $result;

   }
  function checkTerm_date2($todate,$year,$typeid){
     $builder = $this->db->table('school_terms_tbl');
    $builder->select('*'); // Select all columns or specify the needed columns
    $builder->orderBy('id','DESC');
    $builder->where('academic_year', $year);
     $builder->where('type_id', $typeid);
   
    $result=$builder->get()->getResult();
     $this->db->close();
     return $result;

   }
    function get_item_name($tbl,$condition){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
    //  $builder->orderBy('id','DESC');
      $query = $builder->get()->getResult();
       $this->db->close();
      return $query;
 }
  function checkTerm_date($todate,$year,$typeid){
    $builder = $this->db->table('school_terms_tbl');
    $builder->select('');
    //$builder->where('DATE(start_date) <=',  $todate);
    $builder->where('DATE(end_date) >=', $todate);
    $builder->where('academic_year', $year);
     $builder->where('type_id', $typeid);
   
    $result=$builder->get()->getResult();
     $this->db->close();
     return $result;

   }
   function class_list_birthday($class,$classlevel,$stream,$date){
    $query = $this->db->table('admission_tbl');
    $query->select('
        students.birth_date,
        students.id,
        admission_tbl.date_joined,
        admission_tbl.admission_type,
        admission_tbl.adimit_for,
        students.gender,
        students.student_id,
        classes_tbl.class_name,
        streams_tbl.stream_name,
        class_level_tbl.level_name,
       students.full_name'
    ); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
    $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
     $query->join('students', 'students.id = admission_tbl.student_id');
     if($class >0 && $classlevel>0 && $stream==0){
    
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
    }
    elseif($class ==0 && $classlevel>0 && $stream==0){
     
     $query->where('admission_tbl.level_id', $classlevel);
    }
elseif($class >0 && $classlevel==0 && $stream==0){
    $query->where('admission_tbl.class_id', $class);
    }
elseif($class >0 && $classlevel>0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
    }
    elseif($class >0 && $classlevel==0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
     $query->where('admission_tbl.class_id', $class);
     
    }
    elseif($class==0 && $classlevel==0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
      }
   $query->orderBy('students.full_name','ASC');
    $query->like('students.birth_date','%-'.$date);
     $result= $query->get()->getResult();
      $this->db->close();
    return $result;
   }

   function get_school_route(){
    $query = $this->db->table('route_tbl');
    $query->select('route_tbl.*,vehicles_list_tbl.*,users.*,route_tbl.id'); 
    $query->join('vehicles_list_tbl', 'vehicles_list_tbl.id =route_tbl.vehicle');
    $query->join('users', 'users.user_id = vehicles_list_tbl.driver_name');
     $query->where('route_tbl.status', 1);
     $result= $query->get()->getResult();
      $this->db->close();
    return $result;
   }
   
   function get_school_station($rid){
    $query = $this->db->table('station_session_tbl');
    $query->select('*'); 
    $query->where('station_session_tbl.route_id', $rid);
    $query->groupBy('station_id');
    $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
function get_school_classes(){
    $query = $this->db->table('classes_tbl');
    $query->select('*'); 
    $query->where('classes_tbl.status', 1);
    $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
function noOfStudentsInRoute($stationCol,$sessCol,$stid,$ses,$sdate,$enddate,$year,$class_id){
    $query = $this->db->table('transport_details');
    $query->select('*'); 
    $query->join('admission_tbl','admission_tbl.student_id=transport_details.student_id');
    $query->join('students','students.id=transport_details.student_id');
    $query->join('classes_tbl','classes_tbl.id=admission_tbl.class_id');
    $query->where($stationCol, $stid);
    $query->where($sessCol, $ses);
    $query->where('transport_details.status', 1);
    $query->where('admission_tbl.academic_year', $year);
    if($class_id>0){
    $query->where('admission_tbl.class_id', $class_id);
    }
    $query->where('DATE(start_date) <=',  $enddate);
   // $query->where('DATE(end_date) >=', $enddate);
   // $query->where('status !=', 2);
   $query->groupBy('transport_details.student_id');
    $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
        function noOfStudentsInRoute2($stationCol,$sessCol,$stid,$ses,$sdate,$enddate){
    $query = $this->db->table('transport_details');
    $query->select('*'); 
    $query->where($stationCol, $stid);
    $query->where($sessCol, $ses);
    $query->where('transport_details.status', 1);
    $query->where('DATE(start_date) <=',  $enddate);
   // $query->where('DATE(end_date) >=', $enddate);
   // $query->where('status !=', 2);
   $query->groupBy('transport_details.student_id');
    $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
    function noOfStudentsInRoutedrop($stid){
    $query = $this->db->table('transport_details');
    $query->select('*'); 
   // $query->where('pickup_station', $stid);
    $query->where('status', 1);
    $query->where('drop_station', $stid);
   $query->groupBy('student_id');
    $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
    function get_specific_route($rid){
    $query = $this->db->table('route_tbl');
    $query->select('route_tbl.*,vehicles_list_tbl.*,users.*,route_tbl.id'); 
    $query->join('vehicles_list_tbl', 'vehicles_list_tbl.id =route_tbl.vehicle');
    $query->join('users', 'users.user_id = vehicles_list_tbl.driver_name');
     $query->where('route_tbl.id', $rid);
     $result= $query->get()->getResult();
      $this->db->close();
    return $result;
   }
   function get_st_station(){
    $query = $this->db->table('station_session_tbl');
    $query->select('*'); 
    $query->where('station_session_tbl.route_id', $rid);
    $query->groupBy('station_id');
    $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
   function getdays($begin, $end) { //get week days within a date range 1525225455
        if ($begin > $end) {
            echo "startdate is in the future!<br />";
            return 0;
        } else {
            $no_days = 0;
            $working_days = [];
            while ($begin <= $end) {
                $no_days++; // no of days in the given interval
                array_push($working_days, $begin);

                $begin += 86400; // +1 day
            }
            return $working_days;
        }
    }

    function check_date($pid,$date){
    $query = $this->db->table('transport_details');
    $query->where('permit_id', $pid);
    $query->where('DATE(end_date) >=', $date);
    $query->where('DATE(start_date) <=', $date);
    $result= $query->get()->getResult();
     $this->db->close();
    return $result;
    }
    function fetch_app_report($sdate,$enddate,$level,$class,$status){
  $query = $this->db->table('students_application_tbl');
    $query->select('students_application_tbl.*,class_level_tbl.*,classes_tbl.*,students_application_tbl.id');
    $query->join('class_level_tbl','class_level_tbl.id=students_application_tbl.class_lvl');
       $query->join('classes_tbl','classes_tbl.id=students_application_tbl.class');
    $query->where('DATE(date_created) >=', $sdate);
    $query->where('DATE(date_created) <=', $enddate);
    if($level>0 && $class>0 && $status<2){
     $query->where('students_application_tbl.class_lvl', $level);
    $query->where('students_application_tbl.class', $class);
    $query->where('students_application_tbl.application_status', $status);
    }elseif($level>0 && $class==0 && $status==2){
   $query->where('students_application_tbl.class_lvl', $level);
    }elseif($level>0 && $class>0 && $status==2){
   $query->where('students_application_tbl.class_lvl', $level);
   $query->where('students_application_tbl.class', $class);
    }elseif($level==0 && $class>0 && $status==2){
  
   $query->where('students_application_tbl.class', $class);
    }elseif($level==0 && $class>0 && $status<2){
  
   $query->where('students_application_tbl.class', $class);
   $query->where('students_application_tbl.application_status', $status);
    }elseif($level==0 && $class==0 && $status<2){
  
    $query->where('students_application_tbl.application_status', $status);
    }elseif($level>0 && $class==0 && $status<2){
  
   $query->where('students_application_tbl.class_lvl', $level);
   $query->where('students_application_tbl.application_status', $status);
    }
    $result= $query->get()->getResult();
     $this->db->close();
    return $result;
    }
    function pocket_money_model($class,$classlevel,$stream,$year,$hostel){
            $query = $this->db->table('boarding_tbl');
            $query->select('
            students.birth_date,
            boarding_tbl.id,
            boarding_tbl.permit_id,
            boarding_tbl.created_date,
            students.gender,
             amount as amount,
            ledger_transaction_tbl.trans_no,
            boarding_tbl.student_id,
            classes_tbl.class_name,streams_tbl.stream_name,
            class_level_tbl.level_name,
            students.full_name,hostel_tbl.hostel_name'
            ); 
            $query->join('admission_tbl', 'admission_tbl.student_id =boarding_tbl.student_id');
            $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
            $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
            $query->join('students', 'students.id = admission_tbl.student_id');
            $query->join('hostel_tbl', 'hostel_tbl.id = boarding_tbl.hostel');
            $query->join('ledger_transaction_tbl', 'ledger_transaction_tbl.name_id = admission_tbl.student_id');
          $query->join('streams_tbl', 'streams_tbl.id = admission_tbl.stream_id');
          $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
           $query->join('item_transation_tbl', 'item_transation_tbl.trans_number = ledger_transaction_tbl.trans_no');
            if($hostel > 0 && $class >0 && $classlevel>0){
            $query->where('admission_tbl.hostel_id', $hostel);
            $query->where('admission_tbl.class_id', $class);
            $query->where('admission_tbl.level_id', $classlevel);
            }
            elseif($hostel == 0 && $class >0 && $classlevel>0){
            $query->where('admission_tbl.class_id', $class);
            $query->where('admission_tbl.level_id', $classlevel);
            }
            elseif($hostel == 0 && $class ==0 && $classlevel>0){
            $query->where('admission_tbl.level_id', $classlevel);
            }
            elseif($hostel > 0 && $class >0 && $classlevel==0){
            $query->where('admission_tbl.hostel_id', $hostel);
            $query->where('admission_tbl.class_id', $class);
            }
            elseif($hostel > 0 && $class ==0 && $classlevel==0){
            $query->where('admission_tbl.hostel_id', $hostel);

            }
            elseif($hostel == 0 && $class >0 && $classlevel==0){
            $query->where('admission_tbl.class_id', $class);
            }
            elseif($hostel > 0 && $class ==0 && $classlevel>0){
            $query->where('admission_tbl.hostel_id', $hostel);
            $query->where('admission_tbl.level_id', $classlevel);
            }
            elseif($hostel > 0 && $class ==0 && $classlevel==0 && $stream==0){
            $query->where('boarding_tbl.hostel', $hostel);
            }
            $query->where('ledger_transaction_tbl.trans_type', '3');
             $query->where('ledger_transaction_tbl.transation_nature', '1');
            $query->where('admission_tbl.academic_year', $year);
            $query->where('boarding_tbl.academic_year', $year);
        
           $query->like('transaction_numbers_tbl.trans_date',$year,'after');
             $query->where('transaction_numbers_tbl.trans_type_id', 3);
            $query->where('transaction_numbers_tbl.status', 1);
              $query->where('item_transation_tbl.item_id', 65);
             $query->groupBy('ledger_transaction_tbl.name_id');
            $query->orderBy('boarding_tbl.permit_id');
           
            $result= $query->get()->getResult();
             $this->db->close();
            return $result;
   }

 function get_bording_detail($class,$classlevel,$stream,$year,$hostel){
          $query = $this->db->table('admission_tbl');
          $query->select('*'); 
          if($hostel > 0 && $class >0 && $classlevel>0){
          $query->where('admission_tbl.hostel_id', $hostel);
          $query->where('admission_tbl.class_id', $class);
          $query->where('admission_tbl.level_id', $classlevel);
          }
          elseif($hostel == 0 && $class >0 && $classlevel>0){
          $query->where('admission_tbl.class_id', $class);
          $query->where('admission_tbl.level_id', $classlevel);
          }
          elseif($hostel == 0 && $class ==0 && $classlevel>0){
          $query->where('admission_tbl.level_id', $classlevel);
          }
          elseif($hostel > 0 && $class >0 && $classlevel==0){
          $query->where('admission_tbl.hostel_id', $hostel);
          $query->where('admission_tbl.class_id', $class);
          }
          elseif($hostel > 0 && $class ==0 && $classlevel==0){
          $query->where('admission_tbl.hostel_id', $hostel);

          }
          elseif($hostel == 0 && $class >0 && $classlevel==0){
          $query->where('admission_tbl.class_id', $class);
          }
          elseif($hostel > 0 && $class ==0 && $classlevel>0){
          $query->where('admission_tbl.hostel_id', $hostel);
          $query->where('admission_tbl.level_id', $classlevel);
          }
          elseif($hostel > 0 && $class ==0 && $classlevel==0 && $stream==0){
          $query->where('boarding_tbl.hostel', $hostel);
          }
          $query->where('admission_tbl.admission_type', '3');
          $query->where('admission_tbl.academic_year', $year);
          $query->orderBy('admission_tbl.student_id');
          $result= $query->get()->getResult();
           $this->db->close();
          return $result;
   }
   
    function class_list_byname($names,$ttl,$year){
    $query = $this->db->table('admission_tbl');
    $query->select('
        students.birth_date,
        students.id,
        admission_tbl.date_joined,
        admission_tbl.class_id,
        admission_tbl.level_id,
        admission_tbl.academic_year,
        admission_tbl.admission_type,
        admission_tbl.adimit_for,
        students.gender,
        admission_tbl.student_id,
        classes_tbl.class_name,
        streams_tbl.stream_name,
        class_level_tbl.level_name,
       students.full_name,
       admission_tbl.status,
       students.first_name,
       classes_tbl.class_level,
       admission_tbl.stream_id'
    ); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
    $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
     $query->join('students', 'students.id = admission_tbl.student_id');
     $query->where('admission_tbl.academic_year', $year);
    $query->orderBy('students.full_name','ASC');
     if($ttl==1){
      $query->like('students.first_name',$names[0],'both');
    }
     if($ttl==2){
      $query->like('students.first_name',$names[0],'both');
      $query->like('students.middle_name',$names[1],'both');
    }
    if($ttl==3){
      $query->like('students.first_name',$names[0],'both');
      $query->like('students.middle_name',$names[1],'both');
      $query->like('students.last_name',$names[2],'both');
    }
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
   
   function refund_pocket_money($student_id){
   $query = $this->db->table('ledger_transaction_tbl');
    $query->select('*,ledger_transaction_tbl.trans_type');
     $query->join('item_transation_tbl', 'item_transation_tbl.trans_number = ledger_transaction_tbl.trans_no');
     $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id=ledger_transaction_tbl.trans_type');
       $query->where('ledger_transaction_tbl.trans_type', 3);
       $query->where('ledger_transaction_tbl.name_id', $student_id);
       $query->where('ledger_transaction_tbl.name_type_id', 1);
       $query->where('item_transation_tbl.item_id', 65);
       $query->where('item_transation_tbl.trans_type', 3);
         $query->groupBy('ledger_transaction_tbl.trans_no');
         $query->orderBy('transaction_numbers_tbl.trans_date');
            $result= $query->get()->getResult();
             $this->db->close();
            return $result;

   }
   
   function expense($id){
  $query = $this->db->table('account_types_tbl');
  $query->select('type_name');
  $query->where('id',$id);
  $result= $query->get()->getResult();
 $this->db->close();
 return $result;
}

function all_expence($expensname, $strtdate, $enddate) {
  $query = $this->db->table('ledger_transaction_tbl');
  $query->select('accounts_tbl.id, accounts_tbl.account_name, accounts_tbl.account_type_id, ledger_transaction_tbl.amount, ledger_transaction_tbl.ledger_id, ledger_transaction_tbl.ledger_type');
  $query->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
  $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
  $query->join('account_types_tbl', 'account_types_tbl.id = accounts_tbl.account_type_id');
  $query->where('DATE(trans_date) >=', $strtdate);
  $query->where('DATE(trans_date) <=', $enddate);
  $query->where('account_types_tbl.type_name', $expensname);
  $query->groupBy('ledger_id');
  $result = $query->get()->getResult();
  $this->db->close();
  return $result;
}  

public function allofthemexpe($ledgerexp, $typek, $strtdate, $enddate,$class_id=0) {
 $query = $this->db->table('ledger_transaction_tbl');
 $query->select('*');
  $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_type_id = ledger_transaction_tbl.trans_type and transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
  $query->join('admission_tbl', 'admission_tbl.student_id = ledger_transaction_tbl.name_id');
  $query->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
  $query->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
  
  // Additional joins for approval
  $query->join('approval_numbers', 'approval_numbers.trans_no = ledger_transaction_tbl.trans_no');
  $query->join('approval_history', 'approval_numbers.app_id = approval_history.app_no');
  
   if($class_id >0){
    $query->join('invoice_classification_tbl', 'invoice_classification_tbl.trans_id = transaction_numbers_tbl.id');
     $query->where('invoice_classification_tbl.classification_id', $class_id);
      }
  // Filtering by parameters
  $query->where('ledger_transaction_tbl.ledger_id', $ledgerexp);
  $query->where('ledger_transaction_tbl.ledger_type', $typek);
  $query->where('transaction_numbers_tbl.trans_date >=', $strtdate);
  $query->where('transaction_numbers_tbl.trans_date <=', $enddate);
  $query->where('approval_history.hstatus', 1); // Adding the condition for hstatus

  $query->groupBy('ledger_transaction_tbl.trans_no');

  $query = $query->get();
  return $query->getResult();
}
   
   function get_name($tbl,$condition)
  {
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
      $query = $builder->get()->getResult();
      return $query;
  }

  public function getTransactions($ledgerId, $ledgerType, $startDate, $endDate) {
  $builder = $this->db->table('ledger_transaction_tbl');
  
  $builder->select('
      transaction_numbers_tbl.trans_date,
      ledger_transaction_tbl.trans_type, 
      ledger_transaction_tbl.trans_no, 
      ledger_transaction_tbl.amount, 
      ledger_transaction_tbl.transation_nature, 
      transaction_types_tbl.type_name,
      ledger_transaction_tbl.name_type_id,
      ledger_transaction_tbl.name_id,
      ledger_transaction_tbl.trans_item,
      accounts_tbl.description'
  );

  // Join tables
  $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_type_id = ledger_transaction_tbl.trans_type and transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no');
  $builder->join('admission_tbl', 'admission_tbl.student_id = ledger_transaction_tbl.name_id');
  $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
  $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
  
  // Additional joins for approval
  $builder->join('approval_numbers', 'approval_numbers.trans_no = ledger_transaction_tbl.trans_no');
  $builder->join('approval_history', 'approval_numbers.app_id = approval_history.app_no');
  
  // Filtering by parameters
  $builder->where('ledger_transaction_tbl.ledger_id', $ledgerId);
  $builder->where('ledger_transaction_tbl.ledger_type', $ledgerType);
  $builder->where('transaction_numbers_tbl.trans_date >=', $startDate);
  $builder->where('transaction_numbers_tbl.trans_date <=', $endDate);
  $builder->where('approval_history.hstatus', 1); // Adding the condition for hstatus

  $builder->groupBy('ledger_transaction_tbl.trans_no');

  $query = $builder->get();
  return $query->getResult();
}
  
  public function selectClassLevelall($academic_year) {
  $queryBuilder = $this->db->table('classes_tbl');
  $queryBuilder->select('class_level_tbl.level_name,classes_tbl.id, classes_tbl.class_name, 
                        ledger_transaction_tbl.amount, ledger_transaction_tbl.trans_no,
                        ledger_transaction_tbl.trans_type,admission_tbl.status'); 
  $queryBuilder->join('admission_tbl', 'admission_tbl.student_id = classes_tbl.id', 'inner');
  $queryBuilder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id', 'inner');
  $queryBuilder->join('ledger_transaction_tbl', 'ledger_transaction_tbl.name_id = admission_tbl.student_id', 'inner');
  $queryBuilder->where('admission_tbl.academic_year', $academic_year);
  $queryBuilder->where('admission_tbl.status', 1);
    $queryBuilder->orderBy('classes_tbl.id', 'ASC');
  $result = $queryBuilder->get()->getResult(); 
  return $result; // Return the fetched results
}
public function selectClassLevelbfall($academic_year) {
  $queryBuilder = $this->db->table('classes_tbl');
  $queryBuilder->select('class_level_tbl.level_name,classes_tbl.id, classes_tbl.class_name, 
                        ledger_transaction_tbl.amount, ledger_transaction_tbl.trans_no,
                        ledger_transaction_tbl.trans_type,admission_tbl.status'); 
  $queryBuilder->join('admission_tbl', 'admission_tbl.student_id = classes_tbl.id', 'inner');
  $queryBuilder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id', 'inner');
  $queryBuilder->join('ledger_transaction_tbl', 'ledger_transaction_tbl.name_id = admission_tbl.student_id', 'inner');
  $queryBuilder->where('admission_tbl.academic_year', $academic_year);
  $queryBuilder->where('admission_tbl.status', 1);
    $queryBuilder->orderBy('classes_tbl.id', 'ASC');
  $result = $queryBuilder->get()->getResult(); 
  return $result; // Return the fetched results
}
public function selectClassLevel($academic_year, $class_level) {
  $queryBuilder = $this->db->table('classes_tbl');
  $queryBuilder->select('class_level_tbl.level_name,classes_tbl.id, classes_tbl.class_name, 
                        ledger_transaction_tbl.amount, ledger_transaction_tbl.trans_no,
                        ledger_transaction_tbl.trans_type,admission_tbl.status'); 
  $queryBuilder->join('admission_tbl', 'admission_tbl.student_id = classes_tbl.id', 'inner');
  $queryBuilder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id', 'inner');
  $queryBuilder->join('ledger_transaction_tbl', 'ledger_transaction_tbl.name_id = admission_tbl.student_id', 'inner');
  $queryBuilder->where('admission_tbl.academic_year', $academic_year);
  $queryBuilder->where('classes_tbl.class_level', $class_level);
  $queryBuilder->where('admission_tbl.status', 1);
    $queryBuilder->orderBy('classes_tbl.id', 'ASC');
  $result = $queryBuilder->get()->getResult(); 
  return $result; // Return the fetched results
}
public function selectClassLevelbf($academic_year, $class_level) {
  $queryBuilder = $this->db->table('classes_tbl');
  $queryBuilder->select('class_level_tbl.level_name,classes_tbl.id, classes_tbl.class_name, 
                        ledger_transaction_tbl.amount, ledger_transaction_tbl.trans_no,
                        ledger_transaction_tbl.trans_type'); 
  $queryBuilder->join('admission_tbl', 'admission_tbl.student_id = classes_tbl.id', 'inner');
  $queryBuilder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id', 'inner');
  $queryBuilder->join('ledger_transaction_tbl', 'ledger_transaction_tbl.name_id = admission_tbl.student_id', 'inner');
  $queryBuilder->where('admission_tbl.academic_year', $academic_year);
  $queryBuilder->where('classes_tbl.class_level', $class_level);
  $queryBuilder->where('admission_tbl.status', 1);
    $queryBuilder->orderBy('classes_tbl.id', 'ASC');
  $result = $queryBuilder->get()->getResult(); 
  return $result; // Return the fetched results
}
function getClassList($year,$id, $startDate, $endDate) {
  $queryBuilder = $this->db->table('ledger_transaction_tbl');
  $queryBuilder->select('  
      admission_tbl.status,
      transaction_numbers_tbl.trans_date,
      ledger_transaction_tbl.trans_type, 
      ledger_transaction_tbl.trans_item, 
      ledger_transaction_tbl.name_type_id, 
      ledger_transaction_tbl.trans_no, 
      ledger_transaction_tbl.amount, 
      ledger_transaction_tbl.transation_nature, 
      ledger_transaction_tbl.balance,
      transaction_types_tbl.type_name,
      ledger_transaction_tbl.name_id,
      ledger_transaction_tbl.ledger_id,
      accounts_tbl.description
      '); 
  $queryBuilder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id = ledger_transaction_tbl.trans_type');
  $queryBuilder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id', 'inner');
  $queryBuilder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type', 'inner');
  
  $queryBuilder->join('admission_tbl', 'admission_tbl.student_id=ledger_transaction_tbl.name_id');
  $queryBuilder->join('classes_tbl', 'classes_tbl.id = admission_tbl.class_id');
  $queryBuilder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id', 'inner');
  
  $queryBuilder->where('admission_tbl.academic_year', $year);
  $queryBuilder->where('classes_tbl.id', $id);
  // Add the date range filter
  $queryBuilder->where('transaction_numbers_tbl.trans_date >= ', $startDate);
  $queryBuilder->where('transaction_numbers_tbl.trans_date <= ', $endDate);
  
  $result = $queryBuilder->get()->getResult(); 
  return $result; // Return the fetched results
}


function get_amount($tbl, $condition) {
  $builder = $this->db->table($tbl);
  $builder->select('ledger_transaction_tbl.amount'); // Adjust selection as necessary
  $builder->join('admission_tbl', 'admission_tbl.student_id = classes_tbl.id', 'inner');
  $builder->join('class_level_tbl', 'class_level_tbl.id = admission_tbl.level_id', 'inner');
  $builder->join('ledger_transaction_tbl', 'ledger_transaction_tbl.name_id = admission_tbl.student_id', 'inner');
  $builder->where($condition);
  $query = $builder->get();
  return $query->getNumRows() > 0 ? $query->getRow()->amount : null;
} 
   
         public function class_list_Summary() {
    $year = $this->request->getGet('year');
    $id = $this->request->getGet('id');

    // Validate the year input to ensure it's a valid number
    if (!is_numeric($year) || strlen($year) !== 4) {
        echo "Please enter a valid year.";
        return;
    }

    // Calculate start and end dates based on the entered year
    $startDate = "{$year}-01-01"; // January 1st of the specified year
    $endDate = "{$year}-12-31";   // December 31st of the specified year

    // Fetch the class list using the year, id, and date range
    $data['list'] = $this->report->getClassList($year, $id, $startDate, $endDate);
    $data['year'] = $year;
    $data['id'] = $id;

    // Debugging output to check if data is fetched correctly
    if (empty($data['list'])) {
        echo "No data found for the selected class and year.";
    } else {
        echo view('reports/forms/view_class_list', $data);
    }
}


public function getonlycnamelevel($classLevel)
{
    $query = $this->db->table('class_level_tbl');
    
    // Only set where clause if classLevel is not 0
    if ($classLevel != 0) {
        $query->where('class_level_tbl.id', $classLevel);
    }
    
    $query->select('id,level_name'); // Ensure you select the necessary columns
    
    // If classLevel is 0, you want to select all levels
    if ($classLevel == 0) {
        // Get all class levels
        $result = $query->get()->getResult();
    } else {
        // Get specific class level
        $result = $query->get()->getResult();
    }

    $this->db->close();
    return $result;
}

function pocket_money_transaction_used($student_id){
$query = $this->db->table('pocket_money_transaction_tbl');
    $query->select('pocket_money_transaction_tbl.*,transaction_numbers_tbl.*,ledger_transaction_tbl.name_id');
      $query->join('ledger_transaction_tbl', 'ledger_transaction_tbl.trans_no = pocket_money_transaction_tbl.transaction_no');
      $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id=ledger_transaction_tbl.trans_type');
        $query->where('ledger_transaction_tbl.trans_type', 5);
        $query->where('transaction_numbers_tbl.trans_type_id', 5);
       $query->where('pocket_money_transaction_tbl.student_id', $student_id);
       
          $query->groupBy('ledger_transaction_tbl.trans_no');
          $query->orderBy('transaction_numbers_tbl.trans_date');
            $result= $query->get()->getResult();
             $this->db->close();
            return $result;
  }
  
  public function getAccountList ()
    {
      $builder = $this->db->table('accounts_tbl');
      $builder->select('
      accounts_tbl.id,
      accounts_tbl.account_name,
      accounts_tbl.account_type_id,
      account_types_tbl.type_name,
      account_types_tbl.ledger_nature');
      $builder->join('account_types_tbl', 'account_types_tbl.id = accounts_tbl.account_type_id');
      $builder->orderby('account_types_tbl.id','asc');
      $query = $builder->get()->getResult();
      return $query;
    } 

     function allledger($id,$sdate, $enddate) {
      
      $builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('
        transaction_numbers_tbl.trans_date,
         ledger_transaction_tbl.trans_type, 
         ledger_transaction_tbl.trans_item, 
         ledger_transaction_tbl.name_type_id, 
         ledger_transaction_tbl.trans_no, 
         amount, 
         ledger_transaction_tbl.transation_nature, 
         ledger_transaction_tbl.balance,
         transaction_types_tbl.type_name,
         ledger_transaction_tbl.name_id,
         ledger_transaction_tbl.ledger_id,
        accounts_tbl.description'
        );
      $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id =                     ledger_transaction_tbl.trans_type');
      //$builder->join('students', 'students.id = ledger_transaction_tbl.name_id');
      $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
        $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
      $builder->where('ledger_transaction_tbl.ledger_id',$id);
      $builder->where('DATE(trans_date) >=', $sdate);
      $builder->where('DATE(trans_date) <=', $enddate);
     //$builder->groupBy('trans_type');
     //  if($id==10){
     // $builder->where('transaction_numbers_tbl.status', 1);
     // $builder->where('transaction_numbers_tbl.trans_desc !=', '');
     //    }
      $builder->orderBy('trans_date', 'asc');
      $query = $builder->get()->getResult();

      return $query;
    }

    function beforeallledge($id,$std,$sdate)
  {
    
      $builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('
        transaction_numbers_tbl.trans_date,
         ledger_transaction_tbl.trans_type, 
         ledger_transaction_tbl.trans_item, 
         ledger_transaction_tbl.name_type_id, 
         ledger_transaction_tbl.trans_no, 
         amount, 
         ledger_transaction_tbl.transation_nature, 
         ledger_transaction_tbl.balance,
         transaction_types_tbl.type_name,
         ledger_transaction_tbl.name_id,
         ledger_transaction_tbl.ledger_id,
        accounts_tbl.description'
        );
      $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id = ledger_transaction_tbl.trans_type');
      //$builder->join('students', 'students.id = ledger_transaction_tbl.name_id');
      $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
        $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
      $builder->where('ledger_transaction_tbl.ledger_id',$id);
      $builder->where('DATE(trans_date) >=', $std);
      $builder->where('DATE(trans_date) <=', $sdate);
      // $builder->where('transaction_numbers_tbl.status', 1);

      $builder->orderBy('trans_date', 'asc');
      $query = $builder->get()->getResult();

      return $query;
  }

    function beforealllequity($id,$std,$enddate)
  {
    
      $builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('
        transaction_numbers_tbl.trans_date,
         ledger_transaction_tbl.trans_type, 
         ledger_transaction_tbl.trans_item, 
         ledger_transaction_tbl.name_type_id, 
         ledger_transaction_tbl.trans_no, 
         amount, 
         ledger_transaction_tbl.transation_nature, 
         ledger_transaction_tbl.balance,
         transaction_types_tbl.type_name,
         ledger_transaction_tbl.name_id,
         ledger_transaction_tbl.ledger_id,
        accounts_tbl.description'
        );
      $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id =                     ledger_transaction_tbl.trans_type');
      //$builder->join('students', 'students.id = ledger_transaction_tbl.name_id');
      $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
        $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
      $builder->where('ledger_transaction_tbl.ledger_id',$id);
      $builder->where('DATE(trans_date) >=', $std);
      $builder->where('DATE(trans_date) <=', $enddate);
      $builder->orderBy('trans_date', 'asc');
      $query = $builder->get()->getResult();

      return $query;
  }
  
   function refund_pocket_money2($student_id,$year=0,$sdate,$enddate){
    $query = $this->db->table('ledger_transaction_tbl');
    $query->select('*,ledger_transaction_tbl.trans_type');
     $query->join('item_transation_tbl', 'item_transation_tbl.trans_number = ledger_transaction_tbl.trans_no');
     $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id=ledger_transaction_tbl.trans_type');
       $query->where('ledger_transaction_tbl.trans_type', 3);
       $query->where('ledger_transaction_tbl.name_id', $student_id);
       $query->where('ledger_transaction_tbl.name_type_id', 1);
       $query->where('item_transation_tbl.item_id', 65);
       $query->where('item_transation_tbl.trans_type', 3);
       if($year !=0){
         $query->where('item_transation_tbl.trans_type', 3);
       }

        $query->where('DATE(trans_date) >=', $sdate);
      $query->where('DATE(trans_date) <=', $enddate);
         $query->groupBy('ledger_transaction_tbl.trans_no');
         $query->orderBy('transaction_numbers_tbl.trans_date');
            $result= $query->get()->getResult();
             $this->db->close();
            return $result;

   }

   function pocket_money_transaction_used2($student_id,$sdate,$enddate){
$query = $this->db->table('pocket_money_transaction_tbl');
    $query->select('pocket_money_transaction_tbl.*,transaction_numbers_tbl.*,ledger_transaction_tbl.name_id');
      $query->join('ledger_transaction_tbl', 'ledger_transaction_tbl.trans_no = pocket_money_transaction_tbl.transaction_no');
      $query->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number = ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id=ledger_transaction_tbl.trans_type');
        $query->where('ledger_transaction_tbl.trans_type', 5);
        $query->where('transaction_numbers_tbl.trans_type_id', 5);
       $query->where('pocket_money_transaction_tbl.student_id', $student_id);
       
         $query->where('DATE(trans_date) >=', $sdate);
        $query->where('DATE(trans_date) <=', $enddate);
          $query->groupBy('ledger_transaction_tbl.trans_no');
          $query->orderBy('transaction_numbers_tbl.trans_date');
            $result= $query->get()->getResult();
             $this->db->close();
            return $result;
  }
  
   function boarding_history($student_id,$sdate,$enddate){
    $query = $this->db->table('boarding_tbl');
    $query->select('boarding_tbl.*,admission_tbl.class_id,users.first_name,users.last_name');
      $query->join('admission_tbl', 'admission_tbl.student_id = boarding_tbl.student_id and admission_tbl.academic_year = boarding_tbl.academic_year');
      $query->join('users', 'users.user_id = boarding_tbl.created_by');

        $query->where('boarding_tbl.student_id', $student_id);
       
         $query->where('DATE(created_date) >=', $sdate);
        $query->where('DATE(created_date) <=', $enddate);
          $query->orderBy('boarding_tbl.start_date');
            $result= $query->get()->getResult();
             $this->db->close();
            return $result;

  }
   //end mark
}
