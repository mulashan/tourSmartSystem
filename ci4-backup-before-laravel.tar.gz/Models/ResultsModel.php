<?php

namespace App\Models;

use CodeIgniter\Model;

class ResultsModel extends Model
{
  public $db;
    public function __construct(){
      $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    }

public function  term_list($year){
    $query = $this->db->table('school_terms_tbl');
     $query->select('term_name,id');
     $query->where('academic_year',$year);
     return $query->get()->getResult();
}
public function  exam_list($term){
 $query = $this->db->table('examination_tbl');
     $query->select('exam_name,exam_id');
     $query->where('term',$term);
     return $query->get()->getResult();
}
public function  subject_list(){
  
}
   public function My_Allocated_subject($user){
    $query=$this->db->table('teacher_allocation_tbl');
    $query->select('subject_tbl.subject_name, 
                    teacher_allocation_tbl.*, 
                    users.*,
                    classes_tbl.class_name,
                    class_level_tbl.level_name'
                   );
    $query->join('users', 'users.user_id = teacher_allocation_tbl.teacher_id');
    $query->join('subject_tbl', 'subject_tbl.subject_id = teacher_allocation_tbl.teacher_subject');
    $query->join('class_level_tbl', 'class_level_tbl.id = teacher_allocation_tbl.classlevel');
    $query->join('classes_tbl', 'classes_tbl.id = teacher_allocation_tbl.class');
      $query->where('teacher_allocation_tbl.teacher_id',$user);
      $Result=$query->get()->getResult();
        return $Result;   

   }
}
?>

    