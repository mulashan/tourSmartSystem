<?php namespace App\Models;

	use CodeIgniter\Model;

	class ItemsModel extends Model
	{
	    // protected $table   = 'accounts_tbl';
	   public $db;
    public function __construct(){
        $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    }

       public function get_total_accounts($tbl,$dt,$year)
	   {
	      $builder = $this->db->table($tbl);
	      $builder->selectCount($dt);

	      return $builder->get()->getResult();

	   }
	     public function get_total_admission($tbl,$dt,$year)
	   {
	      $builder = $this->db->table($tbl);
	      $builder->selectCount($dt);
        $builder->where('academic_year',$year);
	      return $builder->get()->getResult();

	   }

	   public function get_total_application($tbl,$dt,$year){
	   	  $builder = $this->db->table($tbl);
	      $builder->selectCount($dt);
	      $builder->like($tbl.'.date_created',$year,'after');
        
	      return $builder->get()->getResult();
	   }

	      public function get_total_collection($tbl,$dt,$year)
	   {
	      $builder = $this->db->table($tbl);
	      $builder->select('sum(amount) as amount');
         $builder->where('ledger_id',9);
         $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
          $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
          $builder->groupBy('transaction_numbers_tbl.trans_number');
	      return $builder->get()->getResult();

	   }

  public function get_total_admision_collection($tbl,$dt)
	   {
	      $builder = $this->db->table($tbl);
	      $builder->selectSum($dt);
         $builder->where('ledger_id!=9');
         $builder->where('transation_nature=2');
         $builder->where('trans_type=1');
        // $builder->limit(1);
	      return $builder->get()->getResult();

	   }
	     public function get_total_admision_collected($tbl,$dt,$year)
	   {
	     $builder = $this->db->table($tbl);
	      $builder->select("amount");
	      $builder->join('invoice_type_transaction', 'invoice_type_transaction.trans_no = ledger_transaction_tbl.trans_no');
         $builder->where('invoice_type_transaction.transaction_type_id',2);
         $builder->where('invoice_type_transaction.invoice_type_id',2);
	      $builder->join('transaction_numbers_tbl','transaction_numbers_tbl.trans_number=ledger_transaction_tbl.trans_no');
          $builder->like('transaction_numbers_tbl.trans_date',$year,'after');
         $builder->where('ledger_transaction_tbl.transation_nature',1);
         //$builder->where('transation_nature=1');
         $builder->where('trans_type',2);
          $builder->where('ledger_id!=',9);
          $builder->groupBy('transaction_numbers_tbl.trans_number');
	      return $builder->get()->getResult();
	   }
	  function update_table_details($table,$condition,$data){
		    $builder = $this->db->table($table);
		    $builder->where($condition);
		    $builder->update($data);
		}

// 		public function getAccounttypeList()
// 		{
//       //      $dbname=session()->get('db_name');
//       // $this->db=\Config\Database::connect($dbname);
// 			$query = $this->db->query('SELECT * FROM account_types_tbl');
// 			$result = $query->get()->getResult();
// 			if(count($result) > 0){
// 				return $result;
// 			}else{
// 				return false;
// 			}
// 		}

public function getAccounttypeList()
		{
			$builder = $this->db->table('account_types_tbl');
			$builder->select('*');
	$query = $builder->get()->getResult();

			return $query;
		}
		public function Get_Accounttypes_Listdetails()
		{
			$builder = $this->db->table('accounts_tbl');
			$builder->select('account_name,account_type_id,accounts_tbl.id');
			$builder->join('account_types_tbl', 'account_types_tbl.id = accounts_tbl.account_type_id');
			$query = $builder->get()->getResult();

			return $query;
		}
		public function Load_Accounttype_List($id, $inarray=0)
		{
			$builder = $this->db->table('accounts_tbl');
			$builder->select('account_name,account_type_id,accounts_tbl.id');
			$builder->join('account_types_tbl', 'account_types_tbl.id = accounts_tbl.account_type_id');
			if($inarray==0){
     $builder->where('accounts_tbl.id',$id);
			}else{
     $builder->whereIn('accounts_tbl.id',$inarray);
			}
	$query = $builder->get()->getResult();

			return $query;
		}

		public function ledgerItemList($id)
		{
			$builder = $this->db->table('items_ledgers_tbl');
			$builder->select('id,account_id,item_id');
			$builder->where('item_id', $id);
			$query = $builder->get()->getResult();

			return $query;
		}

		public function SaveAccountData($data){
			$query = $this->db->table('accounts_tbl')->insert($data);
        	return $query;
		}


		public function getAccountList ()
		{
		$builder = $this->db->table('accounts_tbl');
			$builder->select('accounts_tbl.id,accounts_tbl.account_code,accounts_tbl.account_name,accounts_tbl.account_type_id,accounts_tbl.updated_by,accounts_tbl.updated_date,accounts_tbl.description,users.first_name,users.last_name,account_types_tbl.type_name');
			$builder->join('users', 'users.user_id = accounts_tbl.updated_by');
			$builder->join('account_types_tbl', 'account_types_tbl.id = accounts_tbl.account_type_id');
			$builder->orderby('accounts_tbl.id','DESC');
			$query = $builder->get()->getResult();
			return $query;
			
		} 


		public function getSingle_data($id)
		{
			$builder = $this->db->table('accounts_tbl');
			$builder->SELECT('*');
			$builder->where('id',$id);
			$result = $builder->get()->getResult();
			
			return $result;
			
		}

		public function updating_account($id,$data)
		{
			$builder = $this->db->table('accounts_tbl');
			$builder->where('id',$id);
			$builder->update($data);
		}

		public function get_sub_account($id)
		{
			$builder = $this->db->table('accounts_tbl');
			$builder->select('*');
			$builder->join('account_types_tbl','account_types_tbl.id = accounts_tbl.account_type_id');
			$builder->where('account_type_id',$id);
			$query = $builder->get()->getResult();
			
			return $query;
		}
		public function get_sub_account2($id)
		{
			$builder = $this->db->table('items_tbl');
			$builder->select('item_name');
			$builder->where('id',$id);
			$query = $builder->get()->getResult();
			
			return $query;
		}

		public function delete_AccountDtls($id)
		{
			$builder = $this->db->table('accounts_tbl');
			$builder->where('id',$id);
			$builder->delete();
		}

// *****************************************************************//
		// ------items------ //

		public function getItemTypeList()
		{
			$builder = $this->db->table('items_types_tbl');
			$builder->select('*');
			$query = $builder->get()->getResult();
			
			return $query;

		}

		public function get_all_ItemLists()
		{
		$builder = $this->db->table('items_tbl');
			$builder->select('items_tbl.id,item_name,sub_item_of,item_price,item_attribute,item_status,item_size,item_group,item_type,items_tbl.updated_by,items_tbl.updated_date,users.first_name,users.last_name,items_types_tbl.type_name');
			$builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
			$builder->join('users', 'users.user_id = items_tbl.updated_by');
			$builder->join('items_types_tbl', 'items_types_tbl.id = items_tbl.item_type');
			//$builder->where('items_tbl.item_status', 1);
			$builder->orderby('items_tbl.id', 'DESC');
			$query = $builder->get()->getResult();


			return $query;
		}

		public function Save_newItem($data)
		{
			$builder = $this->db->table('items_tbl')->insert($data);
			if($builder){
				return $this->db->insertID();
			}else{
			return 0;
			}
		}

		public function saveItemPrice($data1)
		{
			$builder = $this->db->table('price_tbl')->insert( $data1);

			return $builder;
		}

		public function Save_itemLedger($legder_data)
		{
			$builder = $this->db->table('items_ledgers_tbl')->insert($legder_data);

			return $builder;
		}

		public function account_lists()
		{
			$builder = $this->db->table('items_tbl')->select('*');
			$query   = $builder->get()->getResult();

			return $query;

		}
		
		public function get_allItems_details($id)
		{
			$builder = $this->db->table('items_tbl');
			$builder->select('items_tbl.id,items_tbl.item_name,items_tbl.sub_item_of,item_group,items_tbl.item_type,items_tbl.item_size,items_tbl.item_attribute,price_tbl.item_price');
			$builder->join('price_tbl', 'price_tbl.item_id = items_tbl.id');
			$builder->where('items_tbl.id',$id);
			$query = $builder->get()->getResult();

			return $query;
		}

		public function updating_items($id,$data,$data1)
		{
			$builder = $this->db->table('items_tbl');
			$builder->where('id',$id);
			$builder->update($data);

			$builder = $this->db->table('price_tbl');
			$builder->where('item_id',$id);
			$builder->update($data1);
		}

		public function updating_itemsledger($id,$data2)
		{
			
			$builder = $this->db->table('items_ledgers_tbl')->insert($data2);
      return $builder;
			//$builder->update($data2);
		}
public function delete_itemsledger($id)
		{
			$builder = $this->db->table('items_ledgers_tbl');
			$builder->where('item_id',$id);
				$builder->delete();

		}
		public function delete_item($id)
		{
			$builder = $this->db->table('price_tbl');
			$builder->select('pid');
			$builder->where('pid',$id);
			$builder->delete();

			$builder = $this->db->table('items_ledgers_tbl');
			$builder->select('id');
			$builder->where('id',$id);
			$builder->delete();

			$builder = $this->db->table('items_tbl');
			$builder->where('id',$id);
			$builder->delete();

		}

		public function getSingle_view($id)
		{
		$builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('
        transaction_numbers_tbl.trans_date,
         ledger_transaction_tbl.trans_type, 
         ledger_transaction_tbl.trans_item, 
         ledger_transaction_tbl.name_type_id, 
         ledger_transaction_tbl.trans_no, 
         amount, 
         ledger_transaction_tbl.transation_nature, 
         ledger_transaction_tbl.balance,
         transaction_types_tbl.type_name,
         ledger_transaction_tbl.name_id,
         ledger_transaction_tbl.ledger_id,
        accounts_tbl.description'
        );
      $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id =                     ledger_transaction_tbl.trans_type');
      //$builder->join('students', 'students.id = ledger_transaction_tbl.name_id');
      $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
        $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
      $builder->where('ledger_transaction_tbl.ledger_id',$id);
    //   if($id==10){
    //  $builder->where('transaction_numbers_tbl.status', 1);
    //  $builder->where('transaction_numbers_tbl.trans_desc !=', '');
    //     }
     //$builder->groupBy('trans_type');
    // $builder->groupBy('trans_no', 'trans_type');
      $builder->orderBy('trans_date', 'asc');
      $query = $builder->get()->getResult();

      return $query;
}
		public function get_item($item,$id){
          $builder = $this->db->table('item_transation_tbl');
          $builder->select('items_tbl.item_name,items_tbl.item_size,item_attribute,quantity,unit_price');
          $builder->join('items_tbl', 'items_tbl.id = item_transation_tbl.item_id');
          $builder->join('items_ledgers_tbl', 'items_tbl.id = items_ledgers_tbl.item_id');

          $builder->where('item_transation_tbl.trans_number',$item);
          $builder->where('items_ledgers_tbl.account_id',$id);
         // $builder->limit(1);
          $query = $builder->get()->getResult();

			return $query;
		}
		public function get_account($id){
		 $builder = $this->db->table('accounts_tbl');
		 $builder->select('accounts_tbl.account_name,accounts_tbl.account_code,');
          $builder->where('accounts_tbl.id',$id);
           $query = $builder->get()->getResult();

			return $query;
	} 
	
	
	public function balancesheetModel($id,$thedate)
		{
			$builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('
        transaction_numbers_tbl.trans_date,
         ledger_transaction_tbl.trans_type, 
         ledger_transaction_tbl.trans_item, 
         ledger_transaction_tbl.name_type_id, 
         ledger_transaction_tbl.trans_no, 
         sum(amount) as amount, 
         ledger_transaction_tbl.transation_nature, 
         ledger_transaction_tbl.balance,
         transaction_types_tbl.type_name,
         ledger_transaction_tbl.name_id,
         ledger_transaction_tbl.ledger_id,
        accounts_tbl.description'
        );
      $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id =                     ledger_transaction_tbl.trans_type');
      //$builder->join('students', 'students.id = ledger_transaction_tbl.name_id');
      $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
        $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
      $builder->where('ledger_transaction_tbl.ledger_id',$id);
     // $builder->where('ledger_transaction_tbl.name_type_id',1);
      $builder->where('DATE(transaction_numbers_tbl.trans_date) <=', $thedate);
     // $builder->groupBy('trans_no');
      $builder->groupBy('name_id');
    
      $builder->orderBy('trans_date', 'asc');
        $builder->orderBy('ledger_transaction_tbl.trans_no', 'asc');
      $query = $builder->get()->getResult();

      return $query;
}

	public function getSingle_view2($id,$thedate)
		{
			$builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('
        transaction_numbers_tbl.trans_date,
         ledger_transaction_tbl.trans_type, 
         ledger_transaction_tbl.trans_item, 
         ledger_transaction_tbl.name_type_id, 
         ledger_transaction_tbl.trans_no, 
         sum(amount) as amount, 
         ledger_transaction_tbl.transation_nature, 
         ledger_transaction_tbl.balance,
         transaction_types_tbl.type_name,
         ledger_transaction_tbl.name_id,
         ledger_transaction_tbl.ledger_id,
        accounts_tbl.description'
        );
      $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id =                     ledger_transaction_tbl.trans_type');
      //$builder->join('students', 'students.id = ledger_transaction_tbl.name_id');
      $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
        $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
      $builder->where('ledger_transaction_tbl.ledger_id',$id);
        $builder->where('ledger_transaction_tbl.amount >',0);
      $builder->where('DATE(transaction_numbers_tbl.trans_date) <=', $thedate);
      
      //$builder->groupBy('trans_no');
      $builder->orderBy('name_id', 'asc');
      $builder->orderBy('trans_no', 'asc');
      $query = $builder->get()->getResult();

      return $query;
}

public function getSingle_view3($id,$sdate,$edate)
		{
			$builder = $this->db->table('ledger_transaction_tbl');
      $builder->select('
        transaction_numbers_tbl.trans_date,
         ledger_transaction_tbl.trans_type, 
         ledger_transaction_tbl.trans_item, 
         ledger_transaction_tbl.name_type_id, 
         ledger_transaction_tbl.trans_no, 
         amount, 
         ledger_transaction_tbl.transation_nature, 
         ledger_transaction_tbl.balance,
         transaction_types_tbl.type_name,
         ledger_transaction_tbl.name_id,
         ledger_transaction_tbl.ledger_id,
        accounts_tbl.description'
        );
      $builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id =                     ledger_transaction_tbl.trans_type');
       $builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
        $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
      $builder->where('ledger_transaction_tbl.ledger_id',$id);
      $builder->where('DATE(transaction_numbers_tbl.trans_date) >=', $sdate);
      $builder->where('DATE(transaction_numbers_tbl.trans_date) <=', $edate);
      $builder->where('transaction_numbers_tbl.status', 1);
      //$builder->groupBy('trans_no');
      $builder->orderBy('trans_date', 'asc');
      $builder->orderBy('trans_no', 'asc');
      $query = $builder->get()->getResult();

      return $query;
}

function get_selected_data($tbl,$id,$data){
     $query = $this->db->table($tbl);
     $query->select($data);
     $query->where($id);
     return $query->get()->getResult();
 }
 
 public function getSingle_view4($id,$sdate,$edate)
		{
			$builder = $this->db->table('ledger_transaction_tbl');
			$builder->select('
			  transaction_numbers_tbl.trans_date,
			   ledger_transaction_tbl.trans_type, 
			   ledger_transaction_tbl.trans_item, 
			   ledger_transaction_tbl.name_type_id, 
			   ledger_transaction_tbl.trans_no, 
			   amount, 
			   ledger_transaction_tbl.transation_nature, 
			   ledger_transaction_tbl.balance,
			   transaction_types_tbl.type_name,
			   ledger_transaction_tbl.name_id,
			   ledger_transaction_tbl.ledger_id,
			  accounts_tbl.description'
			  );
			$builder->join('transaction_numbers_tbl', 'transaction_numbers_tbl.trans_number =                     ledger_transaction_tbl.trans_no AND transaction_numbers_tbl.trans_type_id =                     ledger_transaction_tbl.trans_type');
			//$builder->join('students', 'students.id = ledger_transaction_tbl.name_id');
			$builder->join('accounts_tbl', 'accounts_tbl.id = ledger_transaction_tbl.ledger_id');
			  $builder->join('transaction_types_tbl', 'transaction_types_tbl.type_id = ledger_transaction_tbl.trans_type');
			$builder->where('ledger_transaction_tbl.ledger_id',$id);
			      $builder->where('DATE(transaction_numbers_tbl.trans_date) >=', $sdate);
      $builder->where('DATE(transaction_numbers_tbl.trans_date) <=', $edate);
		  
			$builder->orderBy('trans_date', 'asc');
			$query = $builder->get()->getResult();
	  
			return $query;

}

//end end end

	} 

?>