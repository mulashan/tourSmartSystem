<?php

namespace App\Models;

use CodeIgniter\Model;

class SystemModel extends Model
{
    public $db;
    public function __construct(){
       $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    }

    public function load_messages_balances()
    {
        $builder = $this->db->table('messages_balances');
        $builder->selectSum('balance');
        $builder->select('b_id');
        $query = $builder->get()->getResult();

        return $query;
    }

    public function save_messages_balances($tbl,$data)
    {
        $builder = $this->db->table($tbl)->insert($data);
        return $builder;
    }

    public function update_messages_balances($id,$data2)
    {
        $builder = $this->db->table('messages_balances');
        $builder->where('b_id',$id);
        $builder->update($data2);
    }

    public function messages_deposit_details($tbls)
    {
        $builder = $this->db->table($tbls);
        return $builder->get()->getResult();
    }

    public function get_messages_details($tbl,$id)
    {
        $builder = $this->db->table($tbl);
        $builder->select('');
        $builder->where($id);
        return $builder->get()->getResult();
    }

      public function load_messages($startdate,$enddate)
    {
        $builder = $this->db->table('messages');
        $builder->select('*');
        $builder->join('message_groups_tbl', 'message_groups_tbl.send_number = messages.send_no');
    $builder->where('CAST(created_at AS UNSIGNED) >=', (int)$startdate);
$builder->where('CAST(created_at AS UNSIGNED) <=', (int)$enddate);
        $builder->groupBy('messages.send_no');
        $builder->orderBy('messages.created_at DESC');
        return $builder->get()->getResult();
    }
    public function update_sms_balance($smsDt, $id)
    {
        $builder = $this->db->table('messages_balances');
        $builder->where('b_id',$id);
        $builder->update($smsDt);
    }

    public function get_total_balance()
    {
        $builder = $this->db->table('messages');
        $builder->selectSum('cost');
        return $builder->get()->getResult();
    }

    public function update_table_details($table,$condition,$data)
    {
        $builder = $this->db->table($table);
        $builder->where($condition);
        $builder->update($data);
    }
    public function gettable_stadm($stid){
    $builder = $this->db->table('students');
        $builder->select('*');
        $builder->join('admission_tbl','admission_tbl.student_id=students.id');
        $builder->where('students.id',$stid);
         return $builder->get()->getResult();
    } 
}
