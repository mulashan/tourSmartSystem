<?php

namespace App\Models;

use CodeIgniter\Model;

class CompanyModel extends Model
{
    
public $db;
    public function __construct(){
         $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    }
 public function Savecampany($data){
    $query = $this->db->table('company_tbl')->insert($data);
    return $query;
}


function compList(){
     $query = $this->db->table('company_tbl');
     $query->select('*');
     return $query->get()->getResult();
 }
 function check_company_with_id($id){
     $query = $this->db->table('company_tbl');
     $query->select('*');
     $query->where('id',$id);
     return $query->get()->getResult();
 }
 
 public function editcampany($data,$id)
      {
         

         $builder = $this->db->table('company_tbl');
         $builder->where('id',$id);
         $builder->update($data);

      }
      function created_by($id){
     $query = $this->db->table('users');
     $query->select('*');
     $query->where('user_id',$id);
     return $query->get()->getResult();
 }
    public function exit()
     {
        $builder = $this->db->table('company_tbl');
        $builder->select('*');
        $query = $builder->get()->getResult();

        return count($query);
     }

     public function Save_data($tbl,$data){
    $query = $this->db->table($tbl)->insert($data);
    return $query;
}
   
   function gettable_data($tbl,$id){
     $query = $this->db->table($tbl);
     $query->select('*');
     $query->where($id);
     return $query->get()->getResult();
}
function get_item_name2($tbl,$condition,$s,$e){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
    $builder->where('DATE(project_date) >=', $s);
     $builder->where('DATE(project_date) <=', $e);
    //  $builder->orderBy('id','DESC');
      $query = $builder->get()->getResult();
      return $query;
 }
  public function UpdateWCFStatus($data){
  $builder = $this->db->table('accounts_tbl');
         $builder->whereIn('id',[53,47]);
         $builder->update($data);  
 }
}
?>