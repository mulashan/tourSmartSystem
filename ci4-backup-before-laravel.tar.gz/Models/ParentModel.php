<?php

namespace App\Models;

use CodeIgniter\Model;

class ParentModel extends Model
{
    public $db;
    public function __construct(){
         $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    }
    function get_parentstable_details()
    {
        $builder = $this->db->table('parents_students_tbl');
        $builder->select('parents_students_tbl.student_id,parent_id,id,first_name,last_name,full_name,occupation,email,phone1,address');
        $builder->join('parents_tbl', 'parents_tbl.id = parents_students_tbl.parent_id');
        $builder->where('bill_account',0);
        $builder->groupBy('parent_id');
        return $builder->get()->getResult();
    }

    function get_totalNumberof_student($id)
    {
        $builder = $this->db->table('parents_students_tbl');
        $builder->selectCount('parents_students_tbl.student_id');
        $builder->join('parents_tbl', 'parents_tbl.id = parents_students_tbl.parent_id');
        $builder->where('parent_id', $id);
        $builder->where('bill_account', 0);
        $builder->groupBy('parent_id');
        return $builder->get()->getResult();
    }

    function get_parent_information($tbl,$condition){
      $builder = $this->db->table($tbl);
      $builder->select('*');
      $builder->where($condition);
      $query = $builder->get()->getResult();
      return $query;
    }
}
