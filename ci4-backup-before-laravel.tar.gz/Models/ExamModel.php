<?php

namespace App\Models;

use CodeIgniter\Model;

class ExamModel extends Model
{
  public $db;
    public function __construct(){
      $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
    }


//  function get_student_info($class,$stream,$year){
//           $query = $this->db->table('class_subject_tbl');
//     $query->select('subject_tbl.*' ); 
//     // $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
//     // $query->join('class_subject_tbl', 'class_subject_tbl.class_id =admission_tbl.class_id');
//     $query->join('subject_tbl', 'subject_tbl.subject_id =class_subject_tbl.subject_id');
//     // $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
//     // $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
//      // $query->join('students', 'students.id = admission_tbl.student_id');

//      if($class >0 && $stream==0){
//            $query->where('class_subject_tbl.class_id', $class);
     
//     }
// elseif($class >0  && $stream>0){  
//      $query->where('class_subject_tbl.class_id', $class);
//       $query->where('admission_tbl.stream_id', $stream);
//          }
//     elseif($class==0  && $stream>0){
//       $query->where('admission_tbl.stream_id', $stream);
     
//     }
//      $query->groupBy('subject_tbl.subject_id');
//      $result= $query->get()->getResult();
//      $this->db->close();
//     return $result; 

//    }
public function get_subject_info(){
  }

function get_student_details($class,$classlevel,$stream,$year){
    $query = $this->db->table('admission_tbl');
    $query->select('
        students.birth_date,
        students.id,
        admission_tbl.date_joined,
        admission_tbl.class_id,
        admission_tbl.level_id,
        admission_tbl.academic_year,
        admission_tbl.admission_type,
        admission_tbl.adimit_for,
        students.gender,
        students.student_id,
        classes_tbl.class_name,
        streams_tbl.stream_name,
        class_level_tbl.level_name,
       students.full_name,
       students.status,
       students.first_name,'
    ); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
    $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
     $query->join('students', 'students.id = admission_tbl.student_id');
     if($class >0 && $classlevel>0 && $stream==0){
    
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
    }
    elseif($class ==0 && $classlevel>0 && $stream==0){
     
     $query->where('admission_tbl.level_id', $classlevel);
  
    }
elseif($class >0 && $classlevel==0 && $stream==0){
    $query->where('admission_tbl.class_id', $class);
   
    }
elseif($class >0 && $classlevel>0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.level_id', $classlevel);
    }
    elseif($class >0 && $classlevel==0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);
     $query->where('admission_tbl.class_id', $class);

    }
    elseif($class==0 && $classlevel==0 && $stream>0){
    
     $query->where('admission_tbl.stream_id', $stream);

     
    }
    $query->where('admission_tbl.academic_year', $year);
   $query->orderBy('students.full_name','ASC');
      
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }

public function GradeValues($marks,$classlevel) {
    return $this->db->table('grades_tbl')
                    ->where('classlevel',$classlevel)
                    ->where('lower_performance <=', $marks)
                    ->where('upper_performance >=', $marks)
                    ->get()
                    ->getRow();
}


}
    ?>
