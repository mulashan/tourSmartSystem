<?php 

namespace App\Models;
use CodeIgniter\Model;
class SupplierModel extends Model
{
	public function __construct(){
		 $this->dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($this->dbname);
	}
	function SaveSupplier($supplierdata)
	{
		$query = $this->db->table('supplier_tbl')->insert($supplierdata);
		return $query;
	}

	//////////////////// function to get all suppliers///////////////////
	function get_suppliers()
	{
		$builder = $this->db->table('supplier_tbl');
		$builder->select('*');
		$builder->join('users','users.user_id = supplier_tbl.updated_by');
		$query = $builder->get()->getResult();
		return $query;
	}

	//function to fetch supplier data to update it
	function get_supp_data($supp_id)
	{
		$builder = $this->db->table('supplier_tbl');
		$builder->select('*');
		$builder->join('users','users.user_id = supplier_tbl.updated_by');
		$builder->where('supplier_id',$supp_id);
		$query = $builder->get()->getResult();
		return $query;
	}

	//////////// function to fetch single supplier data ///////////////
	function get_suppl_data($updateid)
	{
		$builder = $this->db->table('supplier_tbl');
		$builder->select('*');
		$builder->where('supplier_id',$updateid);
		$query = $builder->get()->getResult();
		return $query;
	}

	/////////// function to update supplier data ///////////
	 function save_supplier_data($id,$data)
	 {
	 	$builder = $this->db->table('supplier_tbl');
	 	$builder->where('supplier_id',$id);
	 	$builder->update($data);
	 }
	
}

?>