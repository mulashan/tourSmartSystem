<?php
// By chanangwa E,
namespace App\Models;
use CodeIgniter\Model;
class AcademicInputsModel extends Model
{

     public function __construct(){
       $dbname=session()->get('db_name');
       $this->db=\Config\Database::connect($dbname);
      
   }
       public function GetAllExams(){
        $query=$this->db->table('examination_tbl');
        $query->select('examination_tbl.*,users.first_name,users.last_name,');
     $query->join('users', 'users.user_id = examination_tbl.created_by');
        $query->orderby('examination_tbl.exam_id','DESC');
        $Result=$query->get()->getResult();

        return $Result;
        
    }
    public function list_classes(){
        $query=$this->db->table('classes_tbl');
        $query->select('classes_tbl.class_name,classes_tbl.class_level,classes_tbl.id,');
        $query->orderby('classes_tbl.id','ASC');
        $Result=$query->get()->getResult();
        return $Result;
    }
        public function list_exams(){
        $query=$this->db->table('examination_tbl');
        $query->select('examination_tbl.exam_name,examination_tbl.exam_id');
        $query->where('examination_tbl.status',1);
        $query->orderby('examination_tbl.exam_id','ASC');
        $Result=$query->get()->getResult();
        return $Result;
    }
          public function list_examsBy_midterm(){
        $query=$this->db->table('examination_tbl');
        $query->select('examination_tbl.exam_name,examination_tbl.exam_id');
        $query->where('examination_tbl.status',1);
       $query->whereIn('examination_tbl.exam_id', [1, 2]);
        $query->orderby('examination_tbl.exam_id','ASC');
        $Result=$query->get()->getResult();
        return $Result;
    }
             public function list_examsBy_terminal(){
        $query=$this->db->table('examination_tbl');
        $query->select('examination_tbl.exam_name,examination_tbl.exam_id');
        $query->where('examination_tbl.status',1);
       $query->whereIn('examination_tbl.exam_id', [1, 2, 3]);
        $query->orderby('examination_tbl.exam_id','ASC');
        $Result=$query->get()->getResult();
        return $Result;
    }
             public function list_examsBy_annual(){
        $query=$this->db->table('examination_tbl');
        $query->select('examination_tbl.exam_name,examination_tbl.exam_id');
        $query->where('examination_tbl.status',1);
       $query->whereIn('examination_tbl.exam_id', [1, 2, 4]);
        $query->orderby('examination_tbl.exam_id','ASC');
        $Result=$query->get()->getResult();
        return $Result;
    }
               public function list_examsBy_term1(){
        $query=$this->db->table('examination_tbl');
        $query->select('examination_tbl.exam_name,examination_tbl.exam_id');
        $query->where('examination_tbl.status',1);
        $query->whereIn('examination_tbl.exam_id', [1, 2, 3]);
        $query->orderby('examination_tbl.exam_id','ASC');
        $Result=$query->get()->getResult();
        return $Result;
    }
        public function list_examsBy_term2(){
        $query=$this->db->table('examination_tbl');
        $query->select('examination_tbl.exam_name,examination_tbl.exam_id');
        $query->where('examination_tbl.status',1);
        $query->whereIn('examination_tbl.exam_id', [1, 2, 4]);
        $query->orderby('examination_tbl.exam_id','ASC');
        $Result=$query->get()->getResult();
        return $Result;
    }
    public function  stream_list($class){
    $query = $this->db->table('streams_tbl');
     $query->select('stream_name,id');
     $query->where('class_id',$class);
     return $query->get()->getResult();
}
    public function  Comb_stream_list($class){
    $query = $this->db->table('comb_stream');
     $query->select('combination_tbl.comb_name,streams_tbl.stream_name,streams_tbl.id');
     $query->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb');
     $query->join('streams_tbl', 'streams_tbl.id = comb_stream.stream_id');
     $query->where('comb_stream.class_id',$class);
     return $query->get()->getResult();
}
public function current_terms($year){
 $query = $this->db->table('school_terms_tbl');
     $query->select('term_name,id');
     $query->where('academic_year',$year);
     return $query->get()->getResult();
 }
 public function FetchCharacterData($class,$stream,$term,$year){
  $query = $this->db->table('admission_tbl');
    $query->select('
        students.birth_date,
        students.id,
        admission_tbl.class_id,
        admission_tbl.academic_year,
        students.gender,
        students.student_id,
        classes_tbl.class_name,
        streams_tbl.stream_name,
       students.full_name,
       students.status,school_terms_tbl.term_name,combination_tbl.comb_name'
      
    ); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('school_terms_tbl', 'school_terms_tbl.academic_year = admission_tbl.academic_year');
    $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
     $query->join('students', 'students.id = admission_tbl.student_id');
     $query->join('comb_stream', 'comb_stream.stream_id = admission_tbl.stream_id');
      $query->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb');
     $query->where('admission_tbl.class_id', $class);
     $query->where('admission_tbl.stream_id', $stream);
      $query->where('comb_stream.stream_id', $stream);
     $query->where('school_terms_tbl.id', $term);
     $query->where('admission_tbl.academic_year', $year);
     $query->orderBy('students.full_name ASC');
      $query->where('students.status', 2);//============only admitted students===========
     return $query->get()->getResult();

 }
 public function CharacterList(){
 $query = $this->db->table('student_character_tbl');
     $query->select('character_id,character_name,character_code');
     $query->where('character_status',1);
     return $query->get()->getResult();
 }
  public function exam_type(){
 $query = $this->db->table('examination_tbl');
     $query->select('exam_id,exam_name');
     $query->where('status',1);
     return $query->get()->getResult();
 }
 
  public function GradeList($classlevel){
 $query = $this->db->table('grades_tbl');
$query->select('grade_id,grade_name,comments');
$query->where('classlevel',$classlevel);
 $query->orderby('grades_tbl.grade_name','ASC');
     return $query->get()->getResult();
 }
public function getClassLevelByClass($classId)
{
    $query = $this->db->table('classes_tbl')
        ->select('class_level')
        ->where('status', 1)
        ->where('id', $classId)
        ->get()
        ->getRow();

    return $query ? $query->class_level : null;
}

   public function SaveCharacterResults($data){
      $query = $this->db->table('character_results_tbl')->insert($data);
        return $query;
   }
public function characterResultExist($student_id, $character_id){
$query=$this->db->table('character_results_tbl');
$query->select('*');
$query->where('student_id',$student_id);
$query->where('character_id',$character_id);
 $result= $query->get()->getResult();
     $this->db->close();
    return $result;
}
public function UpdateCharacterResults($where,$update){
       $builder=$this->db->table('character_results_tbl');
         $builder->where($where);
        $builder->update($update); 
        return $builder; 
}
public function SelectedCharacterList(){
  $query = $this->db->table('character_results_tbl');
     $query->select('*');
     return $query->get()->getResult();
   
}

   public function SaveCharacterRecord($data){
      $query = $this->db->table('character_result_records')->insert($data);
        return $query;
   }

   public function DeleteCharacterRecord($data) {
    return $this->db->table('character_result_records')
                    ->where($data)
                    ->delete();
}

   public function ViewRecords($year){
    $query = $this->db->table('admission_tbl');
    $query->select('
        students.birth_date,
        students.id,
        admission_tbl.date_joined,
        admission_tbl.class_id,
        admission_tbl.level_id,
        admission_tbl.academic_year,
        admission_tbl.admission_type,
        admission_tbl.adimit_for,
        students.gender,
        students.student_id,
        classes_tbl.class_name,
        streams_tbl.stream_name,
        class_level_tbl.level_name,
       students.full_name,
       students.status,
       users.first_name,
       users.last_name,
       character_result_records.exam_date,
       character_result_records.term,
       streams_tbl.class_id,
       streams_tbl.id,
       school_terms_tbl.term_name,
       character_result_records.updated_date,
       character_result_records.created_by,
       character_result_records.academic_year'
    ); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
    $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
     $query->join('character_result_records', 'character_result_records.academic_year = admission_tbl.academic_year');
      $query->join('students', 'students.id = admission_tbl.student_id');
      $query->join('school_terms_tbl', 'school_terms_tbl.academic_year = admission_tbl.academic_year');
      $query->join('users', 'character_result_records.created_by = users.user_id');
     $query->where('character_result_records.academic_year',$year);
      $query->where('character_result_records.class = admission_tbl.class_id', null, false);
    $query->where('character_result_records.stream = admission_tbl.stream_id', null, false);
    $query->where('character_result_records.term = school_terms_tbl.id', null, false);
    $query->where('character_result_records.created_by = users.user_id', null, false);
    $query->groupBy('character_result_records.stream'); 
    $query->orderBy('streams_tbl.id'); 
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
   public function CheckExistance($where){
    $query = $this->db->table('character_result_records');
    $query->select('*');
     $query->where($where);
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
         public function ViewStreamRecords($year,$record,$term){

$query = $this->db->table('character_results_tbl');
    $query->select('character_results_tbl.ch_result_id, character_results_tbl.student_id, character_results_tbl.character_id,  grades_tbl.grade_name,grades_tbl.grade_id');
          $query->join('character_result_records', 'character_result_records.term = character_results_tbl.term');
          $query->join('grades_tbl', 'grades_tbl.grade_id = character_results_tbl.grade_id');
          $query->where('character_results_tbl.academic_yr',$year);
         $query->where('character_results_tbl.term',$term);
         $query->where('character_result_records.reco_id',$record);
         $query->where('character_result_records.academic_year',$year);
      $result= $query->get()->getResult();
     $this->db->close();
     return $result;
    
   }
   public function GetSubjectsByStream($stream){
 $query = $this->db->table('comb_stream');
    $query->select('subject_tbl.subject_name,
                    subject_tbl.subject_id
                     ');
$query->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb');
$query->join('combination_subjects', 'combination_subjects.comb_id = comb_stream.comb');
$query->join('subject_tbl', 'subject_tbl.subject_id = combination_subjects.subject_id');
$query->where('comb_stream.stream_id',$stream);
    $result= $query->get()->getResult();
     $this->db->close();
    return $result;

   }
   public function ExamResultExist($student_id,$subject_id,$term,$examtype,$year){
$query=$this->db->table('exam_results_tbl');
$query->select('*');
$query->where('student_id',$student_id);
$query->where('subject_id',$subject_id);
$query->where('academic_year',$year);
$query->where('term',$term);
$query->where('exam_id',$examtype);
 $result= $query->get()->getResult();
     $this->db->close();
    return $result;
}
public function UpdateExamResults($where,$update){
       $builder=$this->db->table('exam_results_tbl');
         $builder->where($where);
        $builder->update($update); 
                 if ($this->db->affectedRows() > 0) {
        return true;
    } else {
        return false;
    }
}
   public function SaveExamResults($data){
      $query = $this->db->table('exam_results_tbl')->insert($data);
           if ($this->db->affectedRows() > 0) {
        return true;
    } else {
        return false;
    }
   }
   public function GetExamResults($examtype,$term,$year,$stream,$class,$classlevel){
$query = $this->db->table('exam_results_tbl');
    $query->select('exam_results_tbl.result_id, exam_results_tbl.student_id, exam_results_tbl.subject_id, exam_results_tbl.marks_scored, grades_tbl.grade_name,grades_tbl.grade_id');
          $query->join('grades_tbl', 'exam_results_tbl.marks_scored BETWEEN grades_tbl.lower_performance AND grades_tbl.upper_performance');
           $query->where('grades_tbl.classlevel',$classlevel);
           $query->where('exam_results_tbl.exam_id',$examtype);
           $query->where('exam_results_tbl.term',$term);
           $query->where('exam_results_tbl.academic_year',$year);
           $result= $query->get()->getResult();
     $this->db->close();
     return $result;
    
   }
   public function getGradeForMarks($marks,$classlevel)
{
    $query = $this->db->table('grades_tbl')
     ->where('classlevel',$classlevel)
        ->where('lower_performance <=', $marks)
        ->where('upper_performance >=', $marks)
        ->get();
    $grade = $query->getRow();
    return $grade ? $grade->grade_name : 'No grade';
}
   public function CheckResultsRecordExistance($where){
    $query = $this->db->table('exam_result_records');
    $query->select('*');
     $query->where($where);
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
public function SaveExamRecord($data){
    $builder = $this->db->table('exam_result_records');
    $inserted = $builder->insert($data);
    if ($inserted) {
        return $this->db->insertID();
    } else {
        return false;
    }
}

      public function DeleteMonthlyRecord($data) {
    return $this->db->table('exam_result_records')
                    ->where($data)
                    ->delete();
}
   public function ViewMonthlyRecords($year){
    $query = $this->db->table('admission_tbl');
    $query->select('
        students.birth_date,
        students.id,
        admission_tbl.date_joined,
        admission_tbl.class_id,
        admission_tbl.level_id,
        admission_tbl.academic_year,
        admission_tbl.admission_type,
        admission_tbl.adimit_for,
        students.gender,
        students.student_id,
        classes_tbl.class_name,
        streams_tbl.stream_name,
        class_level_tbl.level_name,
       students.full_name,
       students.status,
       users.first_name,
       users.last_name,
       exam_result_records.exam_date,
       exam_result_records.term,
       streams_tbl.class_id,
       streams_tbl.id,
       school_terms_tbl.term_name,
       exam_result_records.updated_date,
       exam_result_records.created_by,
       exam_result_records.academic_year'
    ); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
    $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
     $query->join('exam_result_records', 'exam_result_records.academic_year = admission_tbl.academic_year');
      $query->join('students', 'students.id = admission_tbl.student_id');
      $query->join('school_terms_tbl', 'school_terms_tbl.academic_year = admission_tbl.academic_year');
      $query->join('users', 'exam_result_records.created_by = users.user_id');
     $query->where('exam_result_records.academic_year',$year);
      $query->where('exam_result_records.class = admission_tbl.class_id', null, false);
    $query->where('exam_result_records.stream = admission_tbl.stream_id', null, false);
    $query->where('exam_result_records.term = school_terms_tbl.id', null, false);
    $query->where('exam_result_records.created_by = users.user_id', null, false);
    $query->groupBy('exam_result_records.stream'); 
    $query->orderBy('streams_tbl.id'); 
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }

   public function exam_result_list($year){
     $query = $this->db->table('exam_result_records');
    $query->select('
            exam_result_records.result_record_id,
            exam_result_records.exam_date,
            exam_result_records.updated_date,
            exam_result_records.class,
            exam_result_records.term,
            exam_result_records.academic_year,
            streams_tbl.stream_name,
            combination_tbl.comb_name,
            streams_tbl.id,
            classes_tbl.class_name,
            school_terms_tbl.term_name,
             users.first_name,
             examination_tbl.exam_name,
             users.last_name
                 ');
     $query->join('streams_tbl', 'streams_tbl.id = exam_result_records.stream');
     $query->join('comb_stream', 'comb_stream.stream_id = exam_result_records.stream');
     $query->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb');
     $query->join('classes_tbl', 'classes_tbl.id =exam_result_records.class');
     $query->join('school_terms_tbl', 'school_terms_tbl.id =exam_result_records.term');
     $query->join('examination_tbl', 'examination_tbl.exam_id =exam_result_records.exam_type_id');
     $query->join('users', 'users.user_id =exam_result_records.created_by');
      $query->where('exam_result_records.academic_year',$year);
  $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
         public function GetExamMarksReport_list($examtype,$term){
$query = $this->db->table('exam_results_tbl');
    $query->select('exam_results_tbl.result_id, exam_results_tbl.student_id, exam_results_tbl.subject_id, exam_results_tbl.marks_scored, grades_tbl.grade_name,grades_tbl.grade_id');
          $query->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
          $query->where('exam_results_tbl.exam_id',$examtype);
         $query->where('exam_results_tbl.term',$term);
      $result= $query->get()->getResult();
     $this->db->close();
     return $result;
    
   }
      public function GetSubjectsByStreamReport_List($class,$stream) {
    $query = $this->db->table('comb_stream');
    $query->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb');
    $query->join('combination_subjects', 'combination_subjects.comb_id = comb_stream.comb');
    $query->join('subject_tbl', 'subject_tbl.subject_id = combination_subjects.subject_id');
    if ($stream > 0) {
          $query->select('subject_tbl.subject_name, subject_tbl.subject_id, combination_tbl.comb_id as comb, combination_tbl.comb_name, comb_stream.stream_id');
        $query->where('comb_stream.stream_id', $stream);
        $result = $query->get()->getResult();
    } else {
          $query->select('subject_tbl.subject_name, subject_tbl.subject_id, combination_tbl.comb_id as comb, combination_tbl.comb_name, comb_stream.stream_id');
      $query->where('comb_stream.class_id', $class);
      $query->groupBy('subject_tbl.subject_id');
        $result = $query->get()->getResult();
    }

    $this->db->close();
    return $result;
}
   public function getGradeBoundaries($classlevel)
{
    return $this->db->table('grades_tbl')
                    ->select('grade_name,comments,lower_performance, upper_performance,division_point')
                    ->where('classlevel', $classlevel)
                    ->get()
                    ->getResult();
}
    function FetchExam_list($class,$stream,$year){
    $query = $this->db->table('admission_tbl');
    $query->select('
        students.birth_date,
        students.id AS std_ids,
        admission_tbl.date_joined,
        admission_tbl.class_id,
        admission_tbl.level_id,
        admission_tbl.academic_year,
        admission_tbl.admission_type,
        admission_tbl.adimit_for,
        students.gender,
        students.student_id,
        classes_tbl.class_name,
        streams_tbl.stream_name,
        streams_tbl.id AS stream_id,
        class_level_tbl.level_name,
       students.full_name,
       students.status,
       students.first_name,'
    ); 
    $query->join('classes_tbl', 'classes_tbl.id =admission_tbl.class_id');
    $query->join('class_level_tbl', 'class_level_tbl.id =admission_tbl.level_id');
    $query->join('streams_tbl', 'streams_tbl.id =admission_tbl.stream_id');
     $query->join('students', 'students.id = admission_tbl.student_id');
     $query->where('admission_tbl.stream_id', $stream);
     $query->where('admission_tbl.class_id', $class);
    $query->where('admission_tbl.academic_year', $year);
      $query->where('students.status', 2); //===============only admited=================
    $query->orderBy('students.full_name','ASC');
      
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
         public function GetExamMarks_list($year,$record,$term){

$query = $this->db->table('exam_results_tbl');
    $query->select('exam_results_tbl.result_id, exam_results_tbl.student_id, exam_results_tbl.subject_id, exam_results_tbl.marks_scored, grades_tbl.grade_name,grades_tbl.grade_id');
          $query->join('exam_result_records', 'exam_result_records.exam_type_id = exam_results_tbl.exam_id');
          $query->join('grades_tbl', 'grades_tbl.grade_id = exam_results_tbl.grade_id');
          $query->where('exam_results_tbl.academic_year',$year);
         $query->where('exam_results_tbl.term',$term);
         $query->where('exam_result_records.result_record_id',$record);
         $query->where('exam_result_records.academic_year',$year);
      $result= $query->get()->getResult();
     $this->db->close();
     return $result;
    
   }

   public function character_result_list($year){
     $query = $this->db->table('character_result_records');
    $query->select('
            character_result_records.reco_id,
            character_result_records.exam_date,
            character_result_records.updated_date,
            character_result_records.class,
            character_result_records.term,
            character_result_records.academic_year,
            streams_tbl.stream_name,
             combination_tbl.comb_name,
            streams_tbl.id,
            classes_tbl.class_name,
            school_terms_tbl.term_name,
            classes_tbl.id AS class_id,
             users.first_name,
             users.last_name
                 ');
     $query->join('streams_tbl', 'streams_tbl.id = character_result_records.stream');
    $query->join('comb_stream', 'comb_stream.stream_id = character_result_records.stream');
     $query->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb');
     $query->join('classes_tbl', 'classes_tbl.id =character_result_records.class');
     $query->join('school_terms_tbl', 'school_terms_tbl.id =character_result_records.term');
     $query->join('users', 'users.user_id =character_result_records.created_by');
      $query->where('character_result_records.academic_year',$year);
  $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
     public function list_my_classes($username){
        $query=$this->db->table('classes_tbl');
        $query->select('classes_tbl.class_name,classes_tbl.class_level,classes_tbl.id,');
        $query->join('teacher_allocation_tbl', 'teacher_allocation_tbl.class = classes_tbl.id');
        $query->where('teacher_allocation_tbl.teacher_id',$username); 
         $query->where('classes_tbl.id = teacher_allocation_tbl.class', null, false);
        $query->orderby('classes_tbl.id','ASC');
          $query->groupBy('teacher_allocation_tbl.class'); 
        $Result=$query->get()->getResult();
        return $Result;
    }
        public function  my_Comb_stream_list($class,$username){
    $query = $this->db->table('comb_stream');
     $query->select('combination_tbl.comb_name,streams_tbl.stream_name,streams_tbl.id');
     $query->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb');
     $query->join('streams_tbl', 'streams_tbl.id = comb_stream.stream_id');
     $query->join('teacher_allocation_tbl', 'streams_tbl.id = teacher_allocation_tbl.stream');
     $query->where('comb_stream.class_id',$class);
     $query->where('teacher_allocation_tbl.class',$class);
     $query->where('teacher_allocation_tbl.teacher_id',$username);
     $query->orderby('streams_tbl.id','ASC');
          $query->groupBy('teacher_allocation_tbl.stream'); 
     return $query->get()->getResult();
}
   public function GetSubjectsTeacherByStream($stream,$username){
 $query = $this->db->table('comb_stream');
    $query->select('subject_tbl.subject_name,
                    subject_tbl.subject_id
                     ');
$query->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb');
$query->join('combination_subjects', 'combination_subjects.comb_id = comb_stream.comb');
$query->join('subject_tbl', 'subject_tbl.subject_id = combination_subjects.subject_id');
$query->join('teacher_allocation_tbl', 'teacher_allocation_tbl.teacher_subject = combination_subjects.subject_id');
$query->where('comb_stream.stream_id',$stream);
$query->where('teacher_allocation_tbl.stream',$stream);
$query->where('teacher_allocation_tbl.teacher_id',$username);
    $result= $query->get()->getResult();
     $this->db->close();
    return $result;

   }
      public function CheckResultsStatus($where){
    $query = $this->db->table('exam_results_tbl');
    $query->select('*');
     $query->where($where);
     $query->where('results_status !=',0);
     $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
    public function SubmitExamResults($where){
      $query = $this->db->table('exam_results_tbl')
                 ->where($where)
                ->update(['results_status' => 1]);
        return $query;
   }
   public function AllowUpdateExamResults($where){
      $query = $this->db->table('exam_results_tbl')
                 ->where($where)
                ->update(['results_status' => 0]);
        return $query;
   }


   public function filled_exam_result_list($year){
     $query = $this->db->table('exam_results_tbl');
    $query->select('
        
            exam_results_tbl.exam_date,
            exam_results_tbl.created_on,
            exam_results_tbl.class,
            exam_results_tbl.term,
            exam_results_tbl.academic_year,
            streams_tbl.stream_name,
            combination_tbl.comb_name,
            streams_tbl.id,
            classes_tbl.class_name,
            school_terms_tbl.term_name,
             users.first_name,
             examination_tbl.exam_name,
             users.last_name
                 ');
     $query->join('streams_tbl', 'streams_tbl.id = exam_result_records.stream');
     $query->join('comb_stream', 'comb_stream.stream_id = exam_result_records.stream');
     $query->join('combination_tbl', 'combination_tbl.comb_id = comb_stream.comb');
     $query->join('classes_tbl', 'classes_tbl.id =exam_result_records.class');
     $query->join('school_terms_tbl', 'school_terms_tbl.id =exam_result_records.term');
     $query->join('examination_tbl', 'examination_tbl.exam_id =exam_result_records.exam_type_id');
     $query->join('users', 'users.user_id =exam_result_records.created_by');
      $query->where('exam_result_records.academic_year',$year);
  $result= $query->get()->getResult();
     $this->db->close();
    return $result;
   }
      public function Add_record_data($where,$record){
      $query = $this->db->table('exam_results_tbl')
                 ->where($where)
                ->update(['result_record' => $record]);
        return $query;
   }
      public function Update_record_data($where,$record){
      $query = $this->db->table('exam_results_tbl')
                 ->where($where)
                ->update(['result_record' => 0]);
        return $query;
   }
}
?>